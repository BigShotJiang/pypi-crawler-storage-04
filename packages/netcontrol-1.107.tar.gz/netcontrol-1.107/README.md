No Python documentation found for 'vm'.
Use help() to get the interactive help utility.
Use help(str) for help on the str class.
