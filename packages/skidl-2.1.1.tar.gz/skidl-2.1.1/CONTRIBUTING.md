# Contributing

Contributions are welcome, and they are greatly appreciated! Every
little bit helps, and credit will always be given.

You can contribute in many ways:

## Types of Contributions

### Report Bugs

Report bugs at <https://github.com/devbisme/skidl/issues>.

If you are reporting a bug, please include:

- Your operating system name and version.
- Any details about your local setup that might be helpful in
  troubleshooting.
- Detailed steps to reproduce the bug.

### Fix Bugs

Look through the GitHub issues for bugs. Anything tagged with \"bug\" is
open to whoever wants to implement it.

### Implement Features

Look through the GitHub issues for features. Anything tagged with
\"feature\" is open to whoever wants to implement it.

### Write Documentation

skidl could always use more documentation, whether as part of the
official skidl docs, in docstrings, or even on the web in blog posts,
articles, and such.

### Submit Feedback

The best way to send feedback is to file an issue at
<https://github.com/devbisme/skidl/issues>.

If you are proposing a feature:

- Explain in detail how it would work.
- Keep the scope as narrow as possible, to make it easier to implement.
- Remember that this is a volunteer-driven project, and that
  contributions are welcome :)

## Get Started!

Ready to contribute? Here\'s how to set up [skidl]{.title-ref} for local
development.

1.  Fork the [skidl]{.title-ref} repo on GitHub.

2.  Clone your fork locally:

        $ git clone git@github.com:your_name_here/skidl.git

3.  Install your local copy into a virtualenv. Assuming you have
    virtualenvwrapper installed, this is how you set up your fork for
    local development:

        $ mkvirtualenv skidl
        $ cd skidl/
        $ python setup.py develop

4.  Create a branch for local development:

        $ git checkout -b name-of-your-bugfix-or-feature

    Now you can make your changes locally.

5.  When you\'re done making changes, auto-format your code and check
    that your changes pass the tests, including testing other Python
    versions with tox:

        $ black skidl tests setup.py
        $ python setup.py test
        $ tox

    To get black, and tox, just pip install them into your virtualenv.

6.  Commit your changes and push your branch to GitHub:

        $ git add .
        $ git commit -m "Your detailed description of your changes."
        $ git push origin name-of-your-bugfix-or-feature

7.  Submit a pull request through the GitHub website.

## Tips

To run a subset of tests:

    $ python -m unittest tests.test_skidl
