"""The init file of the package."""

__version__ = "1.1.0"
__author__ = "Rodrigo Esteban Principe"
__email__ = "fitoprincipe82@gmail.com"
