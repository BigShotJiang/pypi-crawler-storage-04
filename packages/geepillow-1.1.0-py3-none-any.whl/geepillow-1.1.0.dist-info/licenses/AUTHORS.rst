Thanks goes to these wonderful people (`emoji key <https://allcontributors.org/docs/en/emoji-key>`_):

.. raw:: html

    <table class="table table-bordered">
      <tr>
        <!-- ALL-CONTRIBUTORS-LIST:START - Do not remove or modify this section -->
        <td align="center">
            <a href="#">
               <img src="https://github.com/fitoprincipe.png" width="70px;" alt="fitoprincipe"/><br />
               <sub><b>Rodrigo Esteban Principe</b></sub>
            </a>
            <a href="#code" title="Code">💻</a>
         </td>
        <!-- ALL-CONTRIBUTORS-LIST:END -->
      </tr>
    </table>

This project follows the `all-contributors <https://allcontributors.org>`_ specification.

Contributions of any kind are welcome!
