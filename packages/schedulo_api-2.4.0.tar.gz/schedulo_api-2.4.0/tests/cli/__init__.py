"""Tests for CLI functionality."""
