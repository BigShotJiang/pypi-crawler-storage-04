"""Utility scripts used by tests and CI (not part of the installed package)."""
