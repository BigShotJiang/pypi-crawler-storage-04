# amino.dorks.fix
Telegram:
t.me/aminodorks

**Установка:**

```bash
pip install amino.dorks.fix
```

