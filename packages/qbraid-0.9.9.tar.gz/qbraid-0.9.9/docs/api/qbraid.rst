qbraid
=======

.. automodule:: qbraid
