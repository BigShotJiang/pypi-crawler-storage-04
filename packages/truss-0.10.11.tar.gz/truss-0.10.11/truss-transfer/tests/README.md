Python tests
