"""
Tests for mongodb-logger package
"""