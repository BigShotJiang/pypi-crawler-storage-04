# Research

## Research Results

<details>
<summary>Which studies compare OCR‑free document understanding models (e.g., Donut, Nougat, Pali/PaliGemma‑based methods, ColPali) against OCR+layout pipelines on visually rich PDFs, and what gains in accuracy and latency do they show?</summary>

### Source [6]: https://www.ecva.net/papers/eccv_2022/papers_ECCV/papers/136880493.pdf

Query: Which studies compare OCR‑free document understanding models (e.g., Donut, Nougat, Pali/PaliGemma‑based methods, ColPali) against OCR+layout pipelines on visually rich PDFs, and what gains in accuracy and latency do they show?

Answer: The paper introduces **Donut**, an OCR-free Document Understanding Transformer, and directly compares it against traditional OCR+layout pipelines on visually rich documents. Donut is designed to address the drawbacks of OCR-dependent systems, such as high computational costs, inflexibility with various languages or document types, and error propagation from OCR to downstream tasks. The authors present extensive experiments demonstrating that Donut achieves **state-of-the-art performance on various visual document understanding (VDU) tasks in both speed and accuracy**, as shown in their Figure 2. They highlight that Donut can work well on languages where OCR quality is often low (e.g., Korean or Chinese), and unlike OCR+post-processing systems, Donut's self-contained architecture reduces system size and maintenance costs. The results indicate that Donut achieves **comparable or better accuracy** and is **significantly faster** because it avoids the computational overhead of separate OCR and layout analysis steps.

-----

-----

-----

### Source [8]: https://github.com/clovaai/donut

Query: Which studies compare OCR‑free document understanding models (e.g., Donut, Nougat, Pali/PaliGemma‑based methods, ColPali) against OCR+layout pipelines on visually rich PDFs, and what gains in accuracy and latency do they show?

Answer: This is the official repository for **Donut** (Document Understanding Transformer), which provides a detailed description and experimental results for the OCR-free model. The repository and its linked academic paper report that **Donut achieves state-of-the-art performance on visual document understanding tasks** such as classification and information extraction, outperforming traditional OCR+layout analysis pipelines in both speed and accuracy. Donut's end-to-end transformer architecture eliminates the need for external OCR engines and APIs, resulting in a **faster and more streamlined workflow**. The repository includes links to the academic paper and supplementary materials, which present full experimental comparisons against OCR-based approaches.

-----

-----

</details>

<details>
<summary>Which production APIs or open models provide multimodal (text–image) embeddings in a shared vector space, and what are their capabilities and examples (e.g., Google Vertex AI Multimodal Embeddings, Cohere vision embeddings, Voyage multimodal, OpenCLIP/SigLIP)?</summary>

### Source [16]: https://aws.amazon.com/blogs/machine-learning/cohere-embed-multimodal-embeddings-model-is-now-available-on-amazon-sagemaker-jumpstart/

Query: Which production APIs or open models provide multimodal (text–image) embeddings in a shared vector space, and what are their capabilities and examples (e.g., Google Vertex AI Multimodal Embeddings, Cohere vision embeddings, Voyage multimodal, OpenCLIP/SigLIP)?

Answer: **Cohere Embed 3 Multimodal Embeddings:**

- Cohere Embed 3 is an industry-leading embedding model that is **multimodal**, capable of generating embeddings from both **text and images** in a shared vector space.
- Its key capability is that **both text and image inputs are mapped into the same embedding space**, supporting integrated semantic search and generative AI applications.
- The model is designed for enterprise use cases, such as searching across complex multimodal assets (e.g., reports, product catalogs, design files).
- The resulting embeddings are numerical vectors representing the meaning/content of the data, enabling similarity comparison across modalities.
- Cohere Embed 3 powers advanced search and retrieval-augmented generation (RAG) systems by letting models retrieve the most relevant information regardless of whether it is text or image-based.
- This model is available as a managed API endpoint on Amazon SageMaker JumpStart.

-----

-----

</details>

<details>
<summary>How does ColPali implement late interaction (MaxSim) for document image retrieval, what are its ViDoRe results (e.g., nDCG@5 and latency), and how can multi‑vector indexes be realized in vector databases (Milvus, FAISS) for production RAG?</summary>

### Source [20]: https://blog.vespa.ai/scaling-colpali-to-billions/

Query: How does ColPali implement late interaction (MaxSim) for document image retrieval, what are its ViDoRe results (e.g., nDCG@5 and latency), and how can multi‑vector indexes be realized in vector databases (Milvus, FAISS) for production RAG?

Answer: ColPali implements **late interaction** by generating embeddings for all document pages offline and, at query time, comparing query and document embeddings using a similarity function that facilitates interaction between all the image grid cell vectors (from document pages) and all the query text token vectors. This approach is often called **MaxSim** (or more accurately, *SumMaxSim*), where each query token’s embedding is compared with all document patch embeddings, the maximum similarity per query token is selected, and these maxima are summed to produce a final relevance score. This enables ColPali to precompute document embeddings but requires a scoring step at query time that ranks pages based on the fine-grained interaction between query and document representations.

After retrieval, relevant pages can be further processed by a vision-language model for summarization or question answering in RAG pipelines. This approach enables scalable retrieval across billions of PDFs, as the offline embedding reduces storage and compute costs, while the late interaction maintains retrieval accuracy. Specific ViDoRe benchmarks (such as nDCG@5 and latency) are not detailed on this page.

-----

-----

-----

### Source [21]: https://weaviate.io/blog/late-interaction-overview

Query: How does ColPali implement late interaction (MaxSim) for document image retrieval, what are its ViDoRe results (e.g., nDCG@5 and latency), and how can multi‑vector indexes be realized in vector databases (Milvus, FAISS) for production RAG?

Answer: The **late interaction mechanism** used in models like ColPali involves retaining lower-level representations (tokens for text or patches for images) for both queries and documents. At query time, for each query token, the maximum similarity with any document token (or image patch) is computed. These per-token maxima are then summed to yield the final relevance score (the **MaxSim operation**). This approach enables semantically rich, fine-grained matching rather than relying on a single pooled embedding. The official ColBERT approach is cited as the origin of this method, which ColPali extends to the multi-modal (vision-language) context.

-----

-----

</details>

<details>
<summary>What do peer‑reviewed evaluations (e.g., ICDAR Robust Reading competitions, DocVQA, PubTables‑1M) report about OCR accuracy on low‑quality scans, handwriting, multi‑column layouts, tables, and charts, and how do leading engines (Tesseract, ABBYY FineReader, Google Cloud Vision, AWS Textract) compare?</summary>

### Source [26]: http://rrc.cvc.uab.es/?ch=15&com=evaluation

Query: What do peer‑reviewed evaluations (e.g., ICDAR Robust Reading competitions, DocVQA, PubTables‑1M) report about OCR accuracy on low‑quality scans, handwriting, multi‑column layouts, tables, and charts, and how do leading engines (Tesseract, ABBYY FineReader, Google Cloud Vision, AWS Textract) compare?

Answer: The ICDAR 2019 Robust Reading Challenge on Multi-lingual Scene Text reports **OCR accuracy** for top-performing engines on complex scenarios:

- **CPN (multi-scale, 2024)**: Hmean 85.97%, Precision 89.08%, Recall 83.06%.
- **SituTech_OCR (2021)**: Hmean 84.80%, Precision 93.41%, Recall 77.64%.
- **TH (2020)**: Hmean 84.67%, Precision 89.54%, Recall 80.30%.

These results are from competitions involving multi-lingual text in natural scenes, which often include **low-quality scans, multi-column layouts, and irregular text distribution**. The relatively high Hmean values (>80%) indicate robust performance by leading engines under challenging conditions[2]. However, performance drops are observed for more complex layouts and languages, and no results are reported for tables or charts in this specific challenge.

-----

-----

</details>

<details>
<summary>How do recent multimodal LLM papers compare unified embedding/decoder (token concatenation) versus cross‑modality attention approaches in practice—especially on accuracy, context/token cost, and latency for high‑resolution images—and what trade‑offs are reported by NVLM, Llama 3.2 Vision, LLaVA/BLIP‑2/Fuyu, and Pixtral?</summary>

### Source [30]: https://arxiv.org/html/2509.00320v1

Query: How do recent multimodal LLM papers compare unified embedding/decoder (token concatenation) versus cross‑modality attention approaches in practice—especially on accuracy, context/token cost, and latency for high‑resolution images—and what trade‑offs are reported by NVLM, Llama 3.2 Vision, LLaVA/BLIP‑2/Fuyu, and Pixtral?

Answer: Large multimodal models (LMMs) typically use **token concatenation**—encoding visual inputs into dense token sequences, then concatenating with text tokens to feed into a language model. This approach, while simple, causes **computational and memory costs to increase substantially** with higher image resolutions due to the longer token sequences. The paper analyzes redundancy between visual and textual tokens and finds that **visual tokens are often more redundant**. They propose a mutual information-based visual token pruning strategy to **preserve cross-modal alignment and intra-modal information diversity**, pruning only visual tokens that are semantically misaligned with the text. Their method can **reduce visual tokens by 88.9%** on models like LLaVA-1.5-7B and LLaVA-NEXT-7B, resulting in a **56.7% speedup in inference** while maintaining strong accuracy. The trade-off reported is that while token concatenation is flexible, it is expensive at high resolutions; careful token pruning retains accuracy while dramatically reducing latency and compute cost. **Cross-modality attention** is referenced as an alignment mechanism, but the main practical advance is in reducing token count for concatenation-based models.

-----

-----

-----

### Source [31]: https://openaccess.thecvf.com/content/CVPR2025/papers/Zhao_Accelerating_Multimodal_Large_Language_Models_by_Searching_Optimal_Vision_Token_CVPR_2025_paper.pdf

Query: How do recent multimodal LLM papers compare unified embedding/decoder (token concatenation) versus cross‑modality attention approaches in practice—especially on accuracy, context/token cost, and latency for high‑resolution images—and what trade‑offs are reported by NVLM, Llama 3.2 Vision, LLaVA/BLIP‑2/Fuyu, and Pixtral?

Answer: This work discusses that most **multimodal LLMs** (including LLaVA, BLIP-2, Fuyu, etc.) process images by encoding them as vision tokens and concatenating with text tokens. The paper notes **token counts increase quadratically with image resolution**, leading to high latency and computational overhead. A greedy search (G-Search) algorithm is proposed to find the optimal set of vision tokens to retain, based on attention scores, to minimize tokens without degrading performance. Their results show that **significant token reduction is possible (up to 60–80%) with minimal loss in accuracy** on LLaVA and BLIP-2. The main trade-off: **token concatenation models are highly flexible but become costly with high-res images**; optimal token selection (pruning) can reclaim much of the efficiency lost. No direct comparison with cross-modality attention architectures is made, but the implication is that unified embedding/decoder approaches can be made competitive on latency and context size with careful token management.

-----

-----

</details>

<details>
<summary>Which production‑grade multimodal embedding offerings map text and images into a shared vector space (e.g., Google Vertex AI Multimodal Embeddings, Cohere Embed v4, Voyage AI, OpenCLIP/SigLIP), and what guidance exists for building hybrid multimodal search/RAG over them?</summary>

### Source [41]: https://cloud.google.com/vertex-ai/generative-ai/docs/model-reference/multimodal-embeddings-api

Query: Which production‑grade multimodal embedding offerings map text and images into a shared vector space (e.g., Google Vertex AI Multimodal Embeddings, Cohere Embed v4, Voyage AI, OpenCLIP/SigLIP), and what guidance exists for building hybrid multimodal search/RAG over them?

Answer: The **Multimodal Embeddings API** in Vertex AI supports generating embeddings from combinations of **image, text, and video data**. These embeddings are suitable for downstream tasks like image classification, video moderation, and hybrid search. Supported model: `multimodalembedding@001`. The API can be accessed via REST (curl) or Python SDK, enabling developers to embed diverse data types and use them for **cross-modal retrieval** (e.g., finding images using textual queries). The API is designed for production use, with clear instructions for sending requests. This official guidance ensures developers can leverage multimodal embeddings in building robust hybrid search systems.

-----

-----

</details>

<details>
<summary>For ColPali‑style OCR‑free document retrieval, what do the ColPali and ViDoRe papers report on nDCG@5 and latency, and how can late interaction (MaxSim/SumMaxSim) be implemented and scaled with multi‑vector indexes in FAISS/Milvus/Weaviate (including two‑stage retrieval and pooling/compression techniques)?</summary>

### Source [46]: https://arxiv.org/abs/2407.01449

Query: For ColPali‑style OCR‑free document retrieval, what do the ColPali and ViDoRe papers report on nDCG@5 and latency, and how can late interaction (MaxSim/SumMaxSim) be implemented and scaled with multi‑vector indexes in FAISS/Milvus/Weaviate (including two‑stage retrieval and pooling/compression techniques)?

Answer: The ColPali paper presents an **OCR-free retrieval pipeline** that directly embeds document images using a vision-language model, creating high-quality multi-vector representations. These representations are used within a **late interaction matching mechanism** (such as MaxSim or SumMaxSim) for retrieval. The paper states that ColPali **substantially outperforms baselines on the ViDoRe benchmark**, which covers diverse, visually rich, and multilingual document collections. The abstract and summary emphasize that ColPali is **simpler, faster, and more end-to-end trainable** than OCR-based pipelines. ColPali is shown to be highly competitive in terms of **retrieval speed and latency** (documented as "drastically faster" than prior pipelines), but specific latency figures and nDCG@5 values are not provided in this section. The paper notes that all models, data, code, and benchmarks are released under open licenses for reproducibility.

-----

-----

</details>

<details>
<summary>What do peer‑reviewed benchmarks report about OCR accuracy on complex, visually rich documents and handwriting (e.g., PubTables‑1M, DocVQA/InfographicVQA ANLS, IAM handwriting), and how do pipeline errors compound in layout+OCR workflows?</summary>

### Source [51]: https://arxiv.org/html/2505.05666v1

Query: What do peer‑reviewed benchmarks report about OCR accuracy on complex, visually rich documents and handwriting (e.g., PubTables‑1M, DocVQA/InfographicVQA ANLS, IAM handwriting), and how do pipeline errors compound in layout+OCR workflows?

Answer: A systematic evaluation of **OCR-based pipelines** versus **vision-language model (VLM)-based pipelines** was performed across four document degradation levels. Retrieval and semantic answer accuracy degrade notably as document quality worsens. For the OCR-based pipeline (using Nougat OCR and Llama 3.2), both retrieval performance metrics (Mean Reciprocal Rank, Recall@5, NDCG@5) and semantic answer metrics (Exact Match, BLEU, ROUGE-1, ROUGE-L) decrease with increased noise and layout complexity. The study found that **pipeline errors compound**: errors from layout analysis or OCR propagate, leading to more substantial end-to-end drops in question-answering performance, especially in degraded or visually complex documents. This compounding effect is evident in the lower accuracy of downstream tasks such as document retrieval and QA when initial OCR or layout steps are imperfect.

-----

-----

</details>

<details>
<summary>What do the official docs (Google Gemini, OpenAI, Anthropic) state about supplying images and PDFs via raw bytes, Base64, file upload endpoints, and URLs/cloud buckets (e.g., GCS/S3)—including size limits, supported MIME types, and any direct URI support?</summary>

### Source [54]: https://ai.google.dev/gemini-api/docs/document-processing

Query: What do the official docs (Google Gemini, OpenAI, Anthropic) state about supplying images and PDFs via raw bytes, Base64, file upload endpoints, and URLs/cloud buckets (e.g., GCS/S3)—including size limits, supported MIME types, and any direct URI support?

Answer: The Gemini API allows **inline PDF data** to be sent either as raw bytes or as base64-encoded data in the `generateContent` request for PDFs under 20MB. The Python and JavaScript examples show:
- Supplying PDFs as **bytes** (`data=doc_data`, with proper MIME type) or as a **base64 string**.
- The MIME type required is **'application/pdf'**.
- The documentation does not mention support for providing a direct URL to the PDF in the API call itself; instead, the client code downloads the PDF before encoding and sending it.
- There is a **20MB size limit** for inline PDF data in requests.

-----

-----

-----

### Source [55]: https://ai.google.dev/api/files

Query: What do the official docs (Google Gemini, OpenAI, Anthropic) state about supplying images and PDFs via raw bytes, Base64, file upload endpoints, and URLs/cloud buckets (e.g., GCS/S3)—including size limits, supported MIME types, and any direct URI support?

Answer: Gemini's **File API** supports uploading media files (e.g., images, PDFs) separately from the prompt. Uploaded files get a URI that can be referenced in subsequent requests. Details:
- Files are uploaded using the **media.upload** endpoint.
- Supported file types include images (e.g., JPEG) and likely other media types.
- In Python, files are uploaded using `client.files.upload(file=...)`. In Node.js, the upload call can specify the MIME type (e.g., `"image/jpeg"`).
- After upload, you receive a **file URI** (such as `myfile.uri`) that can be referenced in `generateContent` requests.
- The documentation shows using the file URI in the prompt via `createPartFromUri(myfile.uri, myfile.mimeType)`.
- There is no explicit mention of size limits or supported MIME types in this excerpt, but images (JPEG) are confirmed, and the general pattern implies support for standard types.

-----

-----

-----

### Source [58]: https://cloud.google.com/vertex-ai/generative-ai/docs/model-reference/inference

Query: What do the official docs (Google Gemini, OpenAI, Anthropic) state about supplying images and PDFs via raw bytes, Base64, file upload endpoints, and URLs/cloud buckets (e.g., GCS/S3)—including size limits, supported MIME types, and any direct URI support?

Answer: For Gemini API on Vertex AI:
- The API supports supplying files by **cloud storage URI** (e.g., `gs://bucket/path/image.jpg`) as part of the request.
- Example code shows providing an image with:
  - `FileURI: "gs://cloud-samples-data/generative-ai/image/scones.jpg"`
  - `MIMEType: "image/jpeg"`
- The documentation does not specify maximum file size or provide a full list of supported MIME types in the example.
- This method allows for **direct referencing of files in Google Cloud Storage** (GCS), but does not mention support for other cloud providers (such as S3) or generic URLs.
-----

-----

</details>

<details>
<summary>What are the reported nDCG@5 (and any latency/throughput) results for ColPali on the ViDoRe benchmark, and how do recommended two‑stage late‑interaction (MaxSim/SumMaxSim) retrieval pipelines map to Milvus/FAISS/Vespa/Weaviate implementations?</summary>

### Source [67]: https://qdrant.tech/blog/colpali-qdrant-optimization/

Query: What are the reported nDCG@5 (and any latency/throughput) results for ColPali on the ViDoRe benchmark, and how do recommended two‑stage late‑interaction (MaxSim/SumMaxSim) retrieval pipelines map to Milvus/FAISS/Vespa/Weaviate implementations?

Answer: This article details an optimized retrieval pipeline for ColPali using Qdrant and discusses two-stage retrieval strategies. In their experiment, over 20,000 PDF pages are indexed, and a two-stage retrieval pipeline is implemented:

- **Stage 1:** Pooled embeddings (mean or max) retrieve the top 200 candidates.
- **Stage 2:** Full-resolution embeddings rerank these candidates to produce the final top 20.

The reported metrics are:
- **Mean pooling:** nDCG@20 = 0.952, Recall@20 = 0.917
- **Max pooling:** nDCG@20 = 0.759, Recall@20 = 0.656

Mean pooling is nearly identical in quality to the original ColPali. Critically, this two-stage approach provides a **13x speedup** versus using full-resolution embeddings alone, demonstrating significant gains in throughput and latency. Max pooling is not recommended due to its negative impact on accuracy.

Regarding mapping to vector DBs:
- The first stage (pooled embeddings) is suitable for any vector DB with efficient approximate nearest neighbor (ANN) search, such as **Milvus, FAISS, Vespa, or Weaviate**.
- The second, reranking stage (using full-resolution, multi-vector late interaction like MaxSim or SumMaxSim) requires fetching the top candidates and then applying custom code for the late interaction scoring outside the DB, since most vector DBs do not natively support these complex multi-vector similarity computations.

This pipeline is generalizable and can be mapped to any modern vector search system by combining an initial ANN search over compact embeddings with a custom reranker[4].

-----

-----

</details>

<details>
<summary>How do recent multimodal LLM papers compare token‑concatenation (unified decoder) versus cross‑modality attention approaches on accuracy, context/token cost, and high‑resolution efficiency (e.g., NVIDIA NVLM, Llama 3.2 Vision, Qwen2‑VL, Pixtral)—and what trade‑offs do they report?</summary>

### Source [72]: https://magazine.sebastianraschka.com/p/understanding-multimodal-llms

Query: How do recent multimodal LLM papers compare token‑concatenation (unified decoder) versus cross‑modality attention approaches on accuracy, context/token cost, and high‑resolution efficiency (e.g., NVIDIA NVLM, Llama 3.2 Vision, Qwen2‑VL, Pixtral)—and what trade‑offs do they report?

Answer: Sebastian Raschka’s analysis explicitly compares cross-modality attention and token concatenation (unified decoder) approaches. Cross-modality attention is often considered *more computationally efficient* because it does not require concatenating all tokens from all modalities into one large sequence, which can quickly become infeasible with high-resolution images due to the quadratic scaling of self-attention. In cross-attention, the model separately processes each modality and then fuses information via attention layers, allowing for different sequence lengths and better scalability. The embedding dimensions must match across modalities, but cross-attention’s modularity is a key advantage for efficiency and flexibility. The trade-off is that unified decoders (token concatenation) may provide tighter integration and potentially higher accuracy for tasks where interleaved token-level interaction is critical, but at the cost of much higher compute and memory demands, especially for high-resolution or long-context data.

-----

-----

</details>

<details>
<summary>What are the official Google Gemini and Vertex AI documents that specify how to submit images and PDFs via raw bytes, Base64, and Google Cloud Storage URIs, including size limits, supported MIME types, and example requests?</summary>

### Source [83]: https://cloud.google.com/vertex-ai/generative-ai/docs/samples/generativeaionvertexai-gemini-pdf

Query: What are the official Google Gemini and Vertex AI documents that specify how to submit images and PDFs via raw bytes, Base64, and Google Cloud Storage URIs, including size limits, supported MIME types, and example requests?

Answer: This Vertex AI code sample demonstrates processing a PDF file with Gemini using a **Google Cloud Storage URI**.

- **Submission methods:** The PDF is referenced in the request using a **Google Cloud Storage URI** (`gs://...`) and the correct MIME type (`application/pdf`).
- **Supported MIME types:** The sample uses `application/pdf` for the PDF file.
- **Example request:** In Node.js, the request includes a `filePart` specifying `fileUri` (the GCS URI) and `mimeType`, and a `textPart` with the prompt. Both are included in the `contents` array in the API request to `generateContent`.
- **Size limits:** This sample does not specify maximum file size; users are referred to the main documentation for quota and limits information.
- **Usage:** This method leverages GCS for file storage and references the document by URI in the API call.

-----

-----

</details>

<details>
<summary>What authoritative sources explain Base64’s size overhead (~33%) and the pitfalls of storing binary data in text columns versus BLOBs (e.g., RFC 4648, database vendor docs), and when to prefer object storage over databases for media?</summary>

### Source [84]: https://developer.mozilla.org/en-US/docs/Glossary/Base64

Query: What authoritative sources explain Base64’s size overhead (~33%) and the pitfalls of storing binary data in text columns versus BLOBs (e.g., RFC 4648, database vendor docs), and when to prefer object storage over databases for media?

Answer: **Base64 encoding increases the size of data by approximately one-third**. Each group of 3 bytes (24 bits) of binary data is represented by 4 Base64 characters (each representing 6 bits), so the encoded output is about 33% larger than the original[1]. The exact overhead can vary slightly depending on the length of the input and the presence of padding, but for most practical purposes, the increase is close to 33%. The padding character `=` is used to ensure the output’s length is a multiple of 4, as required by RFC 4648[1].

-----

-----

</details>

<details>
<summary>What are ColPali’s reported ViDoRe results (e.g., average nDCG@5 ~81.3) and latency/throughput comparisons versus OCR pipelines, and what concrete patterns are recommended to implement late interaction (MaxSim/SumMaxSim) in production vector DBs (Milvus/FAISS/Vespa/Weaviate), including two‑stage retrieval and token pooling?</summary>

### Source [89]: https://arxiv.org/html/2407.01449v6

Query: What are ColPali’s reported ViDoRe results (e.g., average nDCG@5 ~81.3) and latency/throughput comparisons versus OCR pipelines, and what concrete patterns are recommended to implement late interaction (MaxSim/SumMaxSim) in production vector DBs (Milvus/FAISS/Vespa/Weaviate), including two‑stage retrieval and token pooling?

Answer: ColPali achieves top results on the ViDoRe benchmark, showing a minor performance drop of approximately -2.2 nDCG@5 compared to the best possible scores, but still outperforming the closest baseline by more than 12 points in nDCG@5. Detailed ablation studies indicate that the ColPali model using 1024 image patches significantly outperforms versions with fewer patches (e.g., a 512-patch variant drops by -24.8 nDCG@5), while also highlighting tradeoffs: reducing patch count improves memory usage but decreases retrieval performance. Alternative models like ColIdefics2 (64 patches) can be faster, but ColPali (1024 patches) retains higher accuracy and is roughly twice as fast in both training and inference latency compared to ColIdefics2 (64), indicating ColPali’s advantage in balancing accuracy and operational speed. The source emphasizes the importance of considering performance (accuracy), online query latency, offline indexing, and index memory size when deploying such systems[1].

-----

-----

</details>

<details>
<summary>What do peer‑reviewed benchmarks report about OCR accuracy on visually rich documents and handwriting (e.g., DocVQA, PubTables‑1M, InfographicVQA, IAM), and how do errors compound across layout detection → OCR → extraction pipelines compared to OCR‑free approaches?</summary>

### Source [112]: https://research.google/blog/advances-in-document-understanding/

Query: What do peer‑reviewed benchmarks report about OCR accuracy on visually rich documents and handwriting (e.g., DocVQA, PubTables‑1M, InfographicVQA, IAM), and how do errors compound across layout detection → OCR → extraction pipelines compared to OCR‑free approaches?

Answer: Google Research identified a **discrepancy between academic OCR/document understanding benchmarks and real-world performance**. While models like FormNet and LayoutLMv2 achieve high scores on curated datasets (such as FUNSD, CORD, SROIE), their **accuracy drops sharply on real-world, visually rich documents**—such as those found in DocVQA, PubTables-1M, and InfographicVQA—due to complex layouts, tables, and visual noise. The blog emphasizes that **benchmark datasets must reflect the complexity of practical use cases** to capture the true limits of OCR and extraction pipelines. Errors introduced at the OCR stage, particularly in visually complex documents, **cascade and compound in downstream tasks** such as layout analysis and information extraction. This motivates the move toward **multimodal, OCR-free approaches** that process the document as an integrated visual entity, demonstrating superior accuracy and robustness in challenging, real-world scenarios.

-----

</details>


## Sources Scraped From Research Results

<details>
<summary>**arXiv:2407.01449** (cs)</summary>

**arXiv:2407.01449** (cs)

\[Submitted on 27 Jun 2024 ( [v1](https://arxiv.org/abs/2407.01449v1)), last revised 28 Feb 2025 (this version, v6)\]

# Title:ColPali: Efficient Document Retrieval with Vision Language Models

Authors: [Manuel Faysse](https://arxiv.org/search/cs?searchtype=author&query=Faysse,+M), [Hugues Sibille](https://arxiv.org/search/cs?searchtype=author&query=Sibille,+H), [Tony Wu](https://arxiv.org/search/cs?searchtype=author&query=Wu,+T), [Bilel Omrani](https://arxiv.org/search/cs?searchtype=author&query=Omrani,+B), [Gautier Viaud](https://arxiv.org/search/cs?searchtype=author&query=Viaud,+G), [Céline Hudelot](https://arxiv.org/search/cs?searchtype=author&query=Hudelot,+C), [Pierre Colombo](https://arxiv.org/search/cs?searchtype=author&query=Colombo,+P)

[View PDF](https://arxiv.org/pdf/2407.01449) [HTML (experimental)](https://arxiv.org/html/2407.01449v6)

> Abstract:Documents are visually rich structures that convey information through text, but also figures, page layouts, tables, or even fonts. Since modern retrieval systems mainly rely on the textual information they extract from document pages to index documents -often through lengthy and brittle processes-, they struggle to exploit key visual cues efficiently. This limits their capabilities in many practical document retrieval applications such as Retrieval Augmented Generation (RAG). To benchmark current systems on visually rich document retrieval, we introduce the Visual Document Retrieval Benchmark ViDoRe, composed of various page-level retrieval tasks spanning multiple domains, languages, and practical settings. The inherent complexity and performance shortcomings of modern systems motivate a new concept; doing document retrieval by directly embedding the images of the document pages. We release ColPali, a Vision Language Model trained to produce high-quality multi-vector embeddings from images of document pages. Combined with a late interaction matching mechanism, ColPali largely outperforms modern document retrieval pipelines while being drastically simpler, faster and end-to-end trainable. We release models, data, code and benchmarks under open licenses at [this https URL](https://hf.co/vidore).

|     |     |
| --- | --- |
| Comments: | Published as a conference paper at ICLR 2025 |
| Subjects: | Information Retrieval (cs.IR); Computation and Language (cs.CL); Computer Vision and Pattern Recognition (cs.CV) |
| Cite as: | [arXiv:2407.01449](https://arxiv.org/abs/2407.01449) \[cs.IR\] |
|  | (or [arXiv:2407.01449v6](https://arxiv.org/abs/2407.01449v6) \[cs.IR\] for this version) |
|  | [https://doi.org/10.48550/arXiv.2407.01449](https://doi.org/10.48550/arXiv.2407.01449)<br>Focus to learn more<br>arXiv-issued DOI via DataCite |

## Submission history

From: Tony Wu \[ [view email](https://arxiv.org/show-email/4cb4f549/2407.01449)\]

**[\[v1\]](https://arxiv.org/abs/2407.01449v1)**
Thu, 27 Jun 2024 15:45:29 UTC (12,102 KB)

**[\[v2\]](https://arxiv.org/abs/2407.01449v2)**
Tue, 2 Jul 2024 13:02:58 UTC (12,102 KB)

**[\[v3\]](https://arxiv.org/abs/2407.01449v3)**
Mon, 7 Oct 2024 07:46:00 UTC (12,117 KB)

**[\[v4\]](https://arxiv.org/abs/2407.01449v4)**
Wed, 5 Feb 2025 08:42:57 UTC (15,111 KB)

**[\[v5\]](https://arxiv.org/abs/2407.01449v5)**
Thu, 6 Feb 2025 09:57:56 UTC (15,111 KB)

**\[v6\]**
Fri, 28 Feb 2025 08:51:57 UTC (15,110 KB)

Full-text links:

## Access Paper:

- [View PDF](https://arxiv.org/pdf/2407.01449)
- [HTML (experimental)](https://arxiv.org/html/2407.01449v6)
- [TeX Source](https://arxiv.org/src/2407.01449)
- [Other Formats](https://arxiv.org/format/2407.01449)

[view license](http://creativecommons.org/publicdomain/zero/1.0/ "Rights to this article")

### References & Citations

- [NASA ADS](https://ui.adsabs.harvard.edu/abs/arXiv:2407.01449)
- [Google Scholar](https://scholar.google.com/scholar_lookup?arxiv_id=2407.01449)
- [Semantic Scholar](https://api.semanticscholar.org/arXiv:2407.01449)

export BibTeX citation

</details>

<details>
<summary>Accelerating Multimodal Large Language Models by Searching Optimal Vision Token Reduction</summary>

# Accelerating Multimodal Large Language Models by Searching Optimal Vision Token Reduction

Shiyu Zhao1 Zhenting Wangl Felix Juefei- $\\mathrm { \\cdot X u ^ { 2 } }$ Xide Xia? Miao Liu? Xiaofang Wang? Mingfu Liang? Ning Zhang? Dimitris N. Metaxas' Licheng $\\mathrm { { Y u ^ { 2 } } }$

1Rutgers University 2Meta

# Abstract

Prevailing Multimodal Large Language Models (MLLMs) encode the input image(s) as vision tokens and feed them into the language backbone, similar to how Large Language Models (LLMs) process the text tokens. However, the number of vision tokens increases quadratically as the image resolutions, leading to huge computational costs. In this paper, we consider improving MLLM's efficiency from two scenarios, (I) Reducing computational cost without degrading the performance. (II) Improving the performance with given budgets. We start with our main finding that the ranking of each vision token sorted by attention scores is similar in each layer except the first layer. Based on it, we assume that the number of essential top vision tokens does not increase along layers. Accordingly, for Scenario I, we propose a greedy search algorithm (G-Search) to find the least number of vision tokens to keep at each layer from the shallow to the deep. Interestingly, G-Search is able to reach the optimal reduction strategy based on our assumption. For Scenario II, based on the reduction strategy from $G$ Search, we design a parametric sigmoid function ( $P$ -Sigmoid) to guide the reduction at each layer of the MLLM, whose parameters are optimized by Bayesian Optimization. Extensive experiments demonstrate that our approach can significantly accelerate those popular MLLMs, e.g. LLaVA, and InternVL2 models, by more than $2 \\times$ without performance drops. Our approach also far outperforms other token reduction methods when budgets are limited, achieving a better trade-off between efficiency and effectiveness.

# 1\. Introduction

Multimodal Large Language Models (MLLMs) usually leverage a pre-trained vision encoder to encode the input image(s) into vision tokens that are fed into pre-trained Large Language Models (LLMs). Recent studies \[25, 45\] demonstrate that increasing the number of vision tokens by using high resolution inputs significantly enhances the effectiveness of MLLMs. However, such large number of vision tokens leads to inefficiency of model inference, preventing MLLMs from real-world applications.

To address such inefficiency, prompt-agnostic approaches are proposed to reduce the number of vision tokens before feeding them into LLMs. Various approaches have been proposed, including local attention pooling \[20, 24, 32\], re-samplers as compression layers \[45, 52\], or deformable convolutions \[3\], etc. One noticeable issue of prompt-agnostic approaches is the ignorance of the input text prompts from the user. Since different prompts may focus on different regions of the image, prompt-agnostic approaches are likely to preserve irrelevant vision tokens that can be potentially further removed. As a remedy, promptaware methods are proposed to leverage text prompts in the vision token reduction. For example, FastV \[5\], VTW \[26\], and PDrop \[44\] remove vision tokens at certain layers of the LLM within the MLLM. However, their token reductions are all designed with handcrafted rules that vary by MLLMs. They also focus more on reducing the computational cost without performance drops, while not addressing how to assign computations for better effectiveness with limited budgets. We believe the latter is in greater demand in practical edge-device applications.

To address the aforementioned drawbacks, in this paper, we propose a prompt-aware approach via the automatic search of optimal vision token reduction strategies for given MLLMs. Moreover, we consider efficiency from two scenarios, i.e., (I) Reducing computational cost with minor performance drops, and (II) Improving the performance with given budgets.

We first investigate correlations between vision tokens and instruction tokens (i.e., text tokens provided by users). Specifically, we sort the vision tokens of each layer based on their attention scores to instruction tokens and calculate the Kendall's Tau correlation coefficient \[17\] between the current layer and the next layer. Figures 1a and 1b illustrate the coefficients along layers for LLaVA-1.5-7B \[28\] and InternVL2-8B \[7\], respectively. As shown, the correlation coefficients are $\\mathrm { \ h i g h ^ { \\mathrm { 1 } } }$ since the second layer. We regard the relative importance of one vision token as its ranking. Our main finding can be stated as the relative importance of one vision token remains similar in each layer of MLLMs after the first layer. Based on the finding, we assume that the importance of vision tokens in deeper layers can be sorted by the attention scores of earlier layers. Concurrent works \[22, 42\] find that only top tokens with high attention scores are essential for LLMs' inference. Based on our main finding, we assume that the essential top vision tokens in deeper layers are also top tokens in earlier layers. Thus, the number of essential top tokens does not increase as the depth of the MLLM layer grows.

https://openaccess.thecvf.com/content/CVPR2025/papers/images/02ee45062c3c3a81840b0490651014343b2664946c0450f04dc45a5ae749b33d.jpg

Figure 1. (a): Kendl's Tu correlation coffcient between the current ayr and the next ayer of LaVA-1.5-7B \[28\]. A value larger than 0.7 is high. (b): Kendalls Tau correlation cofficients for IntenVL2-8B \[7\]. (c): Keeping rates along layers from G-Search (blue solid curve), and the fitted curve with P-Sigmoid (orange dash curve) for LLaVA-1.5-7B.

Based on the above analysis, we propose a greedy search (G-Search) for Scenario I. Specifically, in each layer of a pretrained MLLM from the shallow to the deep, we rank vision tokens using the attention scores of the prior layer. Then, we find a keeping rate to retain the least number of top vision tokens with insignificant performance drops via Bayesian Optimization. Our main finding and assumptions enable G-Search to remove unnecessary vision tokens for current and later layers in the current layer. Sec. 3.2 shows our method can achieve the optimal vision token reduction strategy. We analyze keeping rates from G-Search, and find that they decrease along layers and can be fitted by a Scurve as shown in Fig. 1c. Accordingly, for Scenario II, we design a parametric sigmoid function (P-Sigmoid) to attain keeping rates along layers with given budgets, and search the optimal parameters that maximize the performance via Bayesian Optimization.

We conducted thorough experiments on 12 popular benchmarks with various MLLMs of different sizes, i.e. LLaVA-1.5-7B \[28\], InternVL2 family \[6, 7\] with 1B, 2B, 4B, and 8B models. The extensive experiments demonstrate that for Scenario I, G-Search can significantly accelerate MLLMs by up to $2 . 3 \\times$ with only a $0 . 2 %$ drop of average accuracy. It scales up well, resulting in larger reduction rates for larger models. Compared to existing promptaware methods, it runs $20 %$ or more faster and achieves better performance. Moreover, G-Search can further speed up prompt-agnostic methods \[20, 46\] by up to $1 . 5 \\times$ . For Scenario II, on top of LLaVA-1.5-7B, P-Sigmoid outperforms FastV by $+ 3 . 3 8 %$ of average accuracy when $8 7 . 5 %$ of vision tokens are reduced. It goes to $+ 5 . 4 6 %$ with around $94 %$ of vision tokens reduced. On top of InternVL2-8B, P-Sigmoid achieves a larger gain of $+ 7 . 6 9 %$ when reducing $8 7 . 5 %$ of vision tokens. Moreover, our results indicate that different MLLMs need different reduction strategies. Thus, handcrafted reduction methods are likely to perform well with certain MLLMs and benchmarks but fail in other cases.

Our contributions are summarized as. (1) We present a new insight that the relative importance of each vision token remains similar across layers of MLLMs, which paves the path for automatic reduction search. (2) We consider efficiency from two scenarios, and propose G-Search and P-Sigmoid that find the best reduction strategy by automatic search. G-Search significantly reduces the computational cost with minor performance drops. P-Sigmoid achieves great trade-offs between efficiency and effectiveness. (3) We conducted extensive experiments on various benchmarks and MLLMs, and show clear boosts from the proposed methods in terms of both efficiency and efficacy.

# 2\. Related work

# 2.1. MLLMs

Multimodal models are able to process multiple modalities and benefit various fields \[54-56\]. MLLMs are LLMs with the ability to understand multiple modalities beyond just natural language. Recent focus is the integration of visual perception with language \[8, 15, 57\]. LLaVA \[27, 28\] is one of the most powerful and popular MLLMs. It introduces linear layers to project vision features into the text embedding space, and instruction-tune both the projector and the LLM on large-scale, machine-generated instructionfollowing data. To enhance the effectiveness, later studies explore high resolution inputs \[25, 29\], model design \[1\], and scaling up model size and data \[6, 7\]. Although with great performance, existing MLLMs require substantial computational resources, due to their large model sizes and the large number of vision tokens to handle. In this paper, instead of improving the performance, we focus on improving the efficiency of MLLMs and propose trainingfree solutions for two scenarios.

https://openaccess.thecvf.com/content/CVPR2025/papers/images/eb0d54a492d11a09c3d97220e36df9878c9c42daba14471b2cd8bae4d1f9c7a1.jpg

Figure 2. MLLM tokenization and inference with vision token reductions. The proposed G-Search and P-igmoid automatically search the optimal reduction strategy, i.e. the keeping rate of each layer.

# 2.2. Token reduction

StreamingLLM \[42\] first shows that LLMs are likely to assign high attention scores to the first a few tokens, called attention sinks. With attention sinks and a fixed-length attention window in the key-value (KV) caches, LLMs are able to achieves the similar performance as the full KV caches are used. Later, SnapKV \[22\] automatically compresses KV caches by selecting clustered important KV positions for each attention head. Those methods reduce computational cost of the decoding phrase but still calculate the whole KV caches in the prefilling phrase. In contrast, our methods can reduce the cost of both prefilling and decoding phrases.

Besides text token reduction in LLM, recent studies also explore vision token reduction in MLLMs. LLaVA-HR \[32\] and Mini-Gemini \[24\] fuse vision tokens of high resolution inputs into low resolution ones. LLaVA-UHD \[45\] and Beyond LLaVA-HD \[52\] learns local compression layers.

LLaMA-PruMerge \[37\] removes vision tokens from a ViT model \[11\], which are not highly correlated to the class token. Honeybee \[3\], TokenPacker \[20\], and Deco \[46\] leverage convolutions, local attentions, and average pooling to down-sample the features of high resolution images. Those methods are prompt-agnostic, which reduce vision tokens before feeding them into the LLM. Thus, they ignore the user instructions that are important clues to remove irrelevant vision tokens. Prompt-aware approaches consider user instructions.LLaMA-VID \[23\] and VoCo-LLaMA \[47\] compress vision tokens into a few tokens based on visiontext cross attentions. However, their compression comes with a clear performance drop. FastV \[5\], VTW \[26\], and PDrop \[44\] reduce vision tokens at certain layers of LLM based on the attention scores between vision and instructions tokens. However, their reduction strategy is manually crafted based on a certain MLLM or a benchmark. In contrast, our method automatically finds the optimal reduction strategy, generalizes to various MLLMs and benchmarks, and achieves better efficiency-effectiveness trade-off.

# 3\. Searching optimal reduction strategy

# 3.1. Correlation of vision & instruction tokens

Preliminaries: Prevailing MLLM architecture comprises a vision encoder, a vision-to-text projector, and a pre-trained LLM. The vision encoder is usually a pre-trained vision transformer of CLIP \[36\] that encodes an image into vision tokens. The vision-to-text projector projects vision tokens of the vision encoder into the text space. Q-former \[18\] and

# Algorithm 1 G-Search with Bayesian Optimization

# Input:

Target Function $f ( \\cdot )$ MLLM $\\theta$ Data Samples $\\mathcal { D }$ Number of Bayesian Optimization Iterations $T$ Output: Keeping Rate Sequence $\\mathcal { R }$ $\\triangleright$ Define a function for Bayesian Optimization functiOn BAYESIANOPTIMIZATION $\\left( f , \\mathcal { R } , \\theta , \\mathcal { D } , T \\right)$ Initialize a Gaussian Process model $\\mathcal { G P }$ Define the acquisition function $\\mathrm { A } ( \\cdot )$ $\\triangleright$ Expected Improvement (EI) is adopted as $\\mathrm { A } ( \\cdot )$ Uniformly sample $\\mathcal { X } \_ { 0 } = { \\hat { r } \_ { i < 1 0 } \| \\hat { r } \_ { i } \\in \[ 0 , m i n ( \\mathcal { R } ) \] }$ $\\forall \\widehat { r } \\in \\mathcal { X } \_ { 0 }$ , evaluate the target function $f ( \\hat { r } \| \\mathcal { R } , \\theta , \\mathcal { D } )$ for $n = 0$ to $T - 1$ do Fit $\\mathcal { G P }$ to the observed data $( \\mathcal { X } \_ { n } , f ( \\mathcal { X } \_ { n } \| \\mathcal { R } , \\theta , \\mathcal { D } ) )$ Get the next point $\\hat { r } \_ { n + 1 } = \\arg \\operatorname\* { m a x } \_ { r } \\mathrm { A } ( r ; \\mathcal { G P } )$ Update $\\mathcal { X } \_ { n + 1 } = \\mathcal { X } \_ { n } \\cup \\left{ \\hat { r } \_ { n + 1 } \\right}$ end for Find the point w/ the best observed value by Eq. 1 return $r ^ { \* }$ end function $\\triangleright$ Repeat searching for each layer $\\mathcal { R } \\emptyset$ for layer depth $i \\in \[ 3 , . . , L \]$ do $\\begin{array} { r l } & { r \_ { i } = { \\tt B A Y E S I A N O P T I M I Z I N G } ( f , \\mathcal { R } , \\theta , \\mathcal { D } , T ) } \ & { \\mathcal { R } \\mathcal { R } \\cup r \_ { i } } \\end{array}$ end for

linear layers \[28\] are popular choices for the projector. The pre-trained LLM takes as input system prompt tokens, projected vision tokens, and instruction tokens, and generates responses. Usually, system tokens remain unchanged for a given LLM, and instruction tokens vary as the user inputs. We visualize the tokenization of MLLMs and how to feed tokens into the LLM in the left part of Fig. 2.

Why cross-modality token correlation matters: Different user instructions usually refer to different regions of images or vision tokens, leaving others irrelevant. In this paper, we attempt to leverage instruction tokens as a clue to remove irrelevant vision tokens, thus accelerating MLLMs. Since attention scores are widely used to interpret the alignment between tokens \[4, 22, 42\], we leverage attention scores between vision tokens and instruction tokens to indicate their correlation. Vision tokens of high attention scores are highly correlated to the user instructions and thus are important tokens to keep. We run experiments on a holdout dataset of LLaVA \[28\] and have the following findings.

Main finding: The ranking or relative importance of each vision token remains similar in each layer after the first layer. In each layer of the model, we rank the vision tokens based on their attention scores and calculate the Kendall's Tau correlation coefficient \[17\] between the ranking of the current layer and that of the next layer. Figures 1a and 1b visualize the correlation coefficients along layers for LLaVA-1.5-7B and InternVL2-8B, respectively. As shown, the correlation coefficients are high (usually $\\geq 0 . 7$ ) except the one between the first two layers, which indicate the relative importance of each vision token remains similar across layers except the first layer.

# 3.2. G-Search for Scenario I

Assumption (1): The importance of vision tokens in deeper layers can be decided by attention scores of earlier layers. This is directly derived from our main finding in Sec. 3.1 that the ranking of vision tokens is similar across layers.

Assumption (2): The number of essential top vision tokens does not increase along layers. This assumption is derived by the following. First, recent studies \[22, 42\] demonstrate that only top tokens with high attention scores are essential for LLMs' inference. According to our main finding, those essential top tokens in deeper layers should be top tokens in earlier layers. Second, if some tokens should be kept in deeper layers to preserve the performance, we cannot remove them from earlier layers. Otherwise, deeper layers cannot access those tokens. Thus, essential tokens in deeper layers are a subset of essential tokens in earlier layers.

Greedy Search Algorithm (G-Search): Based on our assumptions, we propose the following greedy algorithm to find the least number of essential tokens at each layer, and prove that it can reach the optimal solution.

For the $i$ -th layer $i = 3 , . . , L$ of a pretrained MLLM, we sort vision tokens based on their attention scores $( \\mathbf { S } ^ { i - 1 } )$ of the last layer, i.e. the $( i - 1 )$ -th layer. Note that we ignore the first layer because it is poorly correlated with other layers. Then, we search a keeping rate $r \_ { i } \\in \[ 0 , 1 \]$ that decides the number of top vision tokens $( n \_ { i } )$ to keep at the $i$ -th layer w.r.t. the total number of input vision tokens $( N )$ .That is, $r \_ { i } = n \_ { i } / N$ .We regard $r \_ { i } ^ { \* }$ as the optimal keeping rate that maximizes the target function $f ( \\cdot )$

$$
\\begin{array} { r } { \\begin{array} { r } { r \_ { i } ^ { \* } = \\underset { r \_ { i } \\leq r \_ { i - 1 } } { \\mathrm { a r g m a x } } f ( r \_ { i } ) } \ { f ( r \_ { i } ) = E ( r \_ { i } \| r \_ { 3 } , r \_ { 4 } , . . . , r \_ { i - 1 } , \\theta , D ) - \\lambda \\cdot r \_ { i } } \\end{array} } \\end{array}
$$

where $E ( \\cdot )$ refers to the performance of the MLLM parameterized by $\\theta$ on the dataset $D$ .The term $E ( \\cdot )$ refers to effectiveness, and the term with $r \_ { i }$ embodies efficiency. We set $\\lambda = 0 . 0 1$ so that efficiency is improved when performance is maintained. Since $n \_ { i }$ and $N$ are bounded integers,. we can always get the optimal $r \_ { i } ^ { \* }$ via brute force. For a faster search, we employ Bayesian Optimization \[35\]. The pseudo implementation is provided in Algorithm 1.

Inference with keeping rates: As shown in Fig. 2, the only different between the standard inference and inference with keeping rates is to add a plug-and-play Sort & Reduce module before each LLM layer. In Sort $&$ Reduce of the $i$ th layer, similar as G-Search, we first sort the vision tokens based on their attention scores of the $( i - 1 )$ -th layer. Then, we keep the top $( r \_ { i } \\cdot N )$ tokens and remove the rest.

https://openaccess.thecvf.com/content/CVPR2025/papers/images/8881f7c1936ae91f614e83d78f373f68d089d3f594fb4eda903ad3263f899e30.jpg

Figure 3. Keeping rates of various MLLMs from G-Search. All curves are S-curve and can be fitted by P-Sigmoid.

Proof of the optimality: Supposing the optimal sequence of keeping rates is $\\mathcal { R } ^ { \* } = \[ r \_ { 3 } ^ { \* } , r \_ { 4 } ^ { \* } , . . . , r \_ { L } ^ { \* } \]$ , the sequence from our search is $\\mathcal { R } = \[ r \_ { 3 } , r \_ { 4 } , . . . , r \_ { L } \]$ , and $\\forall i < j , r \_ { i } = r \_ { i } ^ { \* }$

If $r \_ { j } ^ { \* } > r \_ { j }$ , our method reduces more tokens (noted as $v ^ { + }$ ) than the optimal at the $j$ -th layer. That is, $v ^ { + }$ are not necessary in current layer and can also be removed in later layers. Otherwise, if later layers require $v ^ { + }$ , the current layer also needs $v ^ { + }$ based on our Assumption (2). Thus, we can replace $r \_ { j } ^ { \\ast }$ with $r \_ { j }$ from our search.

If $r \_ { j } ^ { \\ast } < r \_ { j }$ , our method reduces less tokens than the optimal at the $j$ -th layer. Since our method always remains the performance, $r \_ { j } ^ { \* }$ and $r \_ { j }$ results in the same performance. Based on our greedy strategy, we should find $r \_ { j } ^ { \\ast }$ as $r \_ { j }$ . Thus, $r \_ { j } ^ { \* } < r \_ { j }$ is impossible.

In conclusion, we can always convert $\\mathcal { R } ^ { \* }$ to $\\mathcal { R }$ , showing that $\\mathcal { R }$ from our search is optimal.

# 3.3. P-Sigmoid for Scenario II

Scenario $\\mathrm { I I }$ requires improving the performance with a given budget. We start with analyzing the reduction strategies of G-Search and find that keeping rates along layers can be fitted into a sigmoid-like curve as shown in Fig. 1c. Keeping rates of different MLLMs are visualized in Fig. 3, which are all in sigmoid-like curves. We call the the sigmoid-like function to fit as the parametric sigmoid (P-Sigmoid) and define it as,

$$
\\hat { r } ( i ) = \\frac { 2 b } { 1 + e ^ { k ( i - \\alpha ) } }
$$

where $\\hat { r } ( i )$ is the fitted keeping rate for the $i$ -th layer, and $b \\in \ \[ 0 , 1 \]$ refers to the rate of the numbers of vision tokens after and before the reduction. We take $b$ as the budget because computational cost is positively correlated to the number of tokens. $\\alpha$ is the midpoint of the domain of $\\hat { r } ( \\cdot )$ For example, the function $\\hat { r } ( \\cdot )$ for a MLLM has the domain of $\[ 3 , L \]$ , and $\\alpha = 1 7 . 5$ . Note that we do not reduce vision tokens of the first two layers.

The integral of $\\hat { r } ( \\cdot )$ within its domain of $\[ 3 , L \]$ is always $( L - 2 ) \* b$ regardless of $k$ , which enables vision token reduction at a given budget. We assume that, in Scenario $\\mathrm { I I }$ the optimal keeping rates follow similar parametric sigmoid functions as $\\hat { r } ( \\cdot )$ . Since $b$ and $\\alpha$ are known for a specific MLLM, we search the optimal $k$ to maximize the performance on a small dataset. We leverage Bayesian Optimization to search a non-negative real number for $k$

# 4\. Experiments

# 4.1. Experimental setup

Benchmarks: We adopt 12 popular evaluation benchmarks and follow Cambrian-1 \[39\] to categorize them as,

: General VQA: MME, MMBench \[30\], and GQA \[14\]. Those benchmarks include a wide range of visual question answering questions and indicate the general ability of MLLMs on visual understanding. . Knowledge: MMMU \[48\], MathVista \[31\], and AI2D \[16\]. They mainly focus on knowledge test across disciplines, including Art, Business, Health & Medicine,, Humanities, Math, and Tech & Engineering. OCR & Chart: TextVQA \[38\], ChartVQA \[33\], and DocVQA \[34\], which focus on the understanding of charts, diagrams, and documents. .Vision-Centric: POPE \[21\], RealWorldQA \[41\], and HallusionBench \[13\]. They are used to evaluate MLLMs in terms of language hallucination and visual illusion.

Metrics for effectiveness: We adopt default metrics of each benchmark. Specifically, the accuracy is the metric for most benchmarks. And we report the relaxed accuracy \[33\] for ChartQA, Average Normalized Levenshtein Similarity (ANLS) \[2\] for DocVQA, F1 scores for POPE, and the sum of perception and recognition scores for MME. When calculating the average accuracy, we normalize MME scores by dividing the full score, i.e. 2800.

Metrics for efficiency: We evaluate the efficiency in terms of memory cost, FLOPs, and time cost. For the memory cost, we mainly consider the KV-Cache of vision tokens and report the rate of the numbers of kept vision tokens and vision tokens without reduction. To calculate FLOPs, we employ the tool calflops \[43\] and report Tera FLOPs (TFLOPs). For the time cost, we use optimum-benchmark 2 from Huggingface to evaluate the pre-filling time at inference. This tool requires to preset the number of input text tokens and the number of output tokens. To mimic the evaluation on 12 benchmarks, we calculate the mean numbers of input and output text tokens on all samples. It ends up 75 input tokens and 5 output tokens after rounding.

Table 1. Comparison to prompt-aware reduction methods for Scenario I. "Avg. acc." refers to average accuracy on 12 benchmarks.

|     |     |     |     |     |
| --- | --- | --- | --- | --- |
| MeMod |  | cost Memory | TFLOPs | Time |
| LLaVA-1.5-7B | 48.97 | 1.0 | 9.18 | 0.625 |
| \+ VTW | 44.32 | 0.5 | 5.19 | 0.385 |
| \+ PDrop | 48.70 | 0.469 | 5.47 | 0.381 |
| \+ FastV (R=50%) | 48.70 | 0.531 | 5.49 | 0.387 |
| \+ G-Search (Ours) | 48.77 | 0.340 | 3.95 | 0.301 |
| InternVL2-1B | 59.85 | 1.0 | 4.62 | 0.384 |
| \+ VTW | 41.13 | 0.5 | 3.73 | 0.331 |
| \+ PDrop | 53.70 | 0.583 | 3.88 | 0.336 |
| \+ FastV (R=50%) | 54.85 | 0.542 | 3.91 | 0.342 |
| \+ G-Search (Ours) | 59.19 | 0.527 | 3.84 | 0.333 |
| InternVL2-2B | 61.94 | 1.0 | 8.10 | 0.598 |
| \+ VTW | 37.84 | 0.5 | 5.50 | 0.439 |
| \+ PDrop | 58.98 | 0.583 | 5.93 | 0.452 |
| \+ FastV (R=50%) | 59.91 | 0.542 | 5.85 | 0.451 |
| \+ G-Search (Ours) | 61.22 | 0.532 | 5.64 | 0.444 |
| InternVL2-4B | 68.16 | 1.0 | 13.97 | 0.969 |
| \+ VTW | 49.01 | 0.5 | 8.72 | 0.649 |
| \+ PDrop | 66.94 | 0.469 | 8.35 | 0.627 |
| \+ FastV (R=50%) | 66.19 | 0.531 | 9.01 | 0.652 |
| \+ G-Search (Ours) | 67.65 | 0.488 | 8.69 | 0.645 |
| InternVL2-8B | 70.83 | 1.0 | 24.10 | 1.518 |
| \+ VTW | 52.51 | 0.5 | 13.71 | 0.927 |
| \+ PDrop | 69.19 | 0.469 | 13.13 | 0.915 |
| \+ FastV (R=50%) | 69.42 | 0.531 | 14.58 | 0.998 |
| \+ G-Search (Ours) | 70.10 | 0.424 | 12.24 | 0.860 |

MLLMs in experiments: In our experiments, we compare our methods and existing reduction methods on top of various MLLMs, including the popular LLaVA-1.5-7B, and InternVL2-1B/2B/4B/8B from the InternVL family \[6, 7\] that are one of SOTA open sourced MLLMs.

Implementation details: LMMs-Eval \[49\] was adopted to evaluate MLLMs on the 12 aforementioned benchmarks. Note that for LLaVA-1.5-7B, a lower performance on TextVQA is expected because the official evaluation code adds extra reference OCR tokens for inference, which allows MLLMs to make choices between possible answers instead of understanding vision tokens. It is not necessary to search at each layer, as you can see flat regions in Fig. 1c. Thus, we conducted G-Search for every three layers. All searches were conducted on a small split of training data of LLaVA \[28\]. Since our methods are training-free, all experiments can be conducted using 8 NVIDIA A100 GPUs.

# 4.2. Evaluation for Scenario I

For Scenario I, we attempt to accelerate the MLLMs without significant performance drops. We first compare our G-Search with existing prompt-aware methods, i.e.,

Table 2. G-Search improves prompt-agnostic reduction methods.

|     |     |     |     |     |
| --- | --- | --- | --- | --- |
| \+ aCA-1.5-7B |  | Memory | TFLOPs | Tome |
| TokenPacker + G-Search (Ours) 4 | 47.60 | 1.0 | 3.27 | 0.268 |
| 47.68 | 0.411 | 2.12 | 0.182 |
| +0.08 | -0.589 | -1.15 | -0.086 |
| DeCo | 46.97 | 1.0 | 3.26 | 0.268 |
| \+ G-Search (Ours) | 46.71 | 0.432 | 2.16 | 0.198 |
| -0.26 | -0.568 | -1.1 | -0.070 |
|  |  |  |  |

VTW \[26\], PDrop \[44\], and FastV \[5\]. Then, we demonstrate that G-Search can further improve the efficiency on top of two recent prompt-agnostic methods that reduce vision tokens before feeding them into the LLM., i.e. TokenPacker \[20\], and DeCo \[46\].

Comparison to existing prompt-aware methods: We report the main results in Table 1 with the following findings. Please check the supplement for full results on all benchmarks. First, our G-Search reduces TFLOPs by $1 6 . 9 %$ $3 0 . 4 %$ $3 5 . 9 %$ , and $4 9 . 2 %$ on top of InternVL2-1B, 2B, 4B, and 8B, respectively, achieving larger reduction rates on larger models. This is probably because larger models are likely to have more computational redundancy. Second, compared to VTW \[26\], PDrop \[44\], and FastV \[5\], our G-Search either has much lower TFLOPs or achieves better average accuracy. For example, on top of LLaVA1.5-7B, our method gets similar average accuracy as FastV with only $7 2 %$ TFLOPs. Third, on top of InternVL2 models, prior methods hardly maintain the performance as they do on LLaVA-1.5-7B. Since their reduction strategy is manually designed based on LLaVA-1.5-7B and specific benchmarks, their hand crafted reductions do not generalize to different MLLMs and benchmarks. In contrast, thanks to the automatic search, G-Search generalizes well to different MLLMs and benchmarks.

Improving prompt-agnostic methods: We apply our GSearch on top of two recent prompt-agnostic methods, i.e. TokenPacker \[20\], and DeCo \[46\]. As shown in Table 2, our method consistently reduces TFLOPs by more than $3 3 . 9 %$ with less than $0 . 2 1 %$ drop on the average accuracy. TokenPacker and DeCo reduce vision tokens without considering user instructions. In contrast, our method is aware of user instructions and improves them probably by removing more irrelevant vision tokens.

# 4.3. Evaluation for Scenario II

P-Sigmoid with different budgets: FastV is configurable with a filtering ratio (R) that refers to the percentage of vision tokens to remove at the 2nd layer. We instantiate FastV with different R to set up different budgets. The values of R are set as $5 0 %$ $7 5 %$ (i.e. $2 5 %$ vision tokens left), $8 7 . 5 %$ $9 3 . 7 5 %$ .Then, we set $b$ of P-Sigmoid to match the budgets of FastV. For P-Sigmoid, the number of vision tokens are different across layers, which requires slightly more TFLOPs than keeping the same number of vision tokens in every layer as FastV. See theoretical analysis in the supplement. Thus, to get close TFLOPs as FastV, we lower down the budgets for our method by ${ \\sim } 7 %$ . For PDrop, we use different $\\lambda$ to set up different budgets. Our P-Sigmoid is compared with FastV and PDrop on top of LLaVA-1.5- 7B in Fig. 4. As shown, P-Sigmoid outperforms both FastV and PDrop in a large margin when TFLOPs are low, which clearly demonstrates that our method achieves a better trade-off between effectiveness and efficiency.

|     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| MLLM Method |  |  | General VQA | Knowledge | OCR & Chart | Vision-Centric |
|  | SdOIHL | F oe sy |  |  | GOA |  |  | AIEP |  | Chhrey |  | HdOd |  |
| LLaVA -1.5-7B | \+ FastV | 2.74 | 43.14 | 1644.5 | 60.2 | 54.0 | 37.3 21.8 | 52.1 | 38.7 | 14.4 | 18.1 | 66.3 | 49.3 | 46.7 |
| \+ P-Sigmoid | 2.66 | 46.52 | 1700.4 | 63.7 | 58.3 | 37.1 | 22.0 54.5 | 44.1 | 15.7 | 23.3 | 78.0 | 53.6 | 47.1 |
|  | -0.08 | +3.38 | +55.9 | +3.5 | +4.3 | -0.2 | +0.2 +2.4 | +5.4 | +1.3 | +5.2 | +11.7 | +4.3 | +0.4 |
| Intern VL2-1B | \+ FastV | 3.43 | 43.16 | 1581.8 | 52.5 | 47.5 34.0 |  | 23.8 55.0 | 39.6 | 17.2 | 26.5 | 79.4 | 43.3 | 42.8 |
| \+ P-Sigmoid | 3.38 | 47.83 | 1691.7 | 56.6 | 50.8 | 33.3 | 26.6 55.5 | 49.6 | 33.9 | 36.2 | 83.2 | 44.8 | 42.9 |
|  | -0.05 +4.67 |  | +109.9 | +4.1 | +3.3 | -0.7 +2.8 | +0.5 | +10.0 | +16.7 | +9.7 |  | +3.8 +1.5 | +0.1 |
| Intern VL2-2B | \+ FastV | 4.26 47.66 |  | 1661.0 | 68.1 | 52.8 33.3 | 25.9 | 68.0 | 54.5 | 23.8 | 34.0 | 80.1 | 29.7 | 42.3 |
| \+ P-Sigmoid | 4.16 | 51.54 | 1710.7 | 68.1 | 55.0 | 33.2 | 28.6 66.7 | 61.3 | 43.0 | 46.5 | 82.2 | 30.1 | 42.8 |
|  | -0.10 | +3.88 | +49.7 | 0.0 +2.2 | -0.1 | +2.7 | -1.3 | +6.8 | +19.2 | +12.5 | +2.1 | +0.4 | +0.5 |
|  | \+ FastV | 5.48 | 54.83 | 1950.9 | 74.1 | 56.7 44.1 | 25.8 | 70.9 | 57.3 | 34.1 | 42.0 | 81.6 84.0 | 55.8 | 45.9 |
| \+ P-Sigmoid | 5.38 | 61.19 | 2039.1 | 76.3 | 59.4 | 45.8 | 30.0 74.3 | 66.1 | 60.8 | 57.3 |  | 57.8 | 49.7 |
|  | -0.10 | +6.36 | +88.2 | +2.2 +2.7 | +1.7 |  | +4.2 +3.4 | +8.8 | +26.7 | +15.3 |  | +2.4 +2.0 | +3.8 |
| Intern VL2-8B | \+ FastV | 7.71 | 55.17 | 2066.2 | 74.3 | 55.4 44.7 | 25.6 | 72.6 | 60.3 70.5 | 35.0 61.8 | 39.6 59.9 | 78.9 84.1 | 54.5 59.5 | 47.3 |
| \+ P-Sigmoid | 7.46 | 62.86 | 2176.6 | 79.3 | 59.7 | 45.8 | 33.0 76.3 |  |  |  |  |  | 46.7 |
|  | -0.25 +7.69 |  | +110.4 +5.0 +4.3 |  |  |  | +1.1 +7.4 +3.7 |  | +10.2 +26.8 | +20.3 |  | +5.2 +5.0 | -0.6 |

Table 3. P-Sigmoid with different MLLMs. We set $\\mathrm { R { = } } 8 7 . 5 %$ for FastV and set the budget of P-Sigmoid close to that of FastV.

https://openaccess.thecvf.com/content/CVPR2025/papers/images/b9dbacde9f5f4100bc9ab2fac72451e19ab45358c003cdcdf1e041b03441ddbe.jpg

Figure 4. Comparison of reduction methods with different budgets. The average accuracy of LLaVA-1.5-7B with reductions on 12 benchmarks are reported. Compared to others, Our P-Sigmoid achieves the accuracy with no reduction using less TFLOPs.

P-Sigmoid with different MLLMs: We set $\\mathrm { R { = } } 8 7 . 5 %$ for FastV, and compare it with the proposed P-Sigmoid on top of different MLLMs. As shown in Table 3, with similar TFLOPs, our method outperforms FastV by a large margin on top of all MLLMs, i.e., $+ 3 . 3 8 %$ for LLaVA-1.5- 7B, and $+ 4 . 6 7 % / + 3 . 8 8 % / + 6 . 3 6 % / + 7 . 6 9 %$ for InternVL2- 1B/2B/4B/8B. Moreover, our method gets the most improvement on OCR & Chart and Vision-Centric benchmarks, and gets moderate gains on Knowledge benchmarks. For example, on top of InternVL2-8B, P-Sigmoid and FastV get the scores of 61.8 vs 35.0 on ChartQA, while they get 45.8 vs 44.7 on MMMU. Since ChartQA is more about visual recognition and understanding, our P-Sigmoid significantly outperforms FastV by providing a better way to preserve vision tokens. MMMU focuses on knowledge test where texts are usually sufficient to address the questions. Thus, how to reduce vision tokens matters less.

# 4.4. Further Analysis

Smaller $k$ of P-Sigmoid for lower budgets: As shown in Fig. 5, on top of LLaVA-1.5-7B, the value of $k$ of $\\mathrm { \\bf P }$ Sigmoid increases as TFLOPs increase. A larger $k$ means a sharper S-curve, and a smaller $k$ refers to a flatter curve. That is, we are assigning more percentages of the budget to early layers when the budget increases. A possible explanation is that there are a few essential tokens in deep layers. Without those tokens, the performance will significantly drop. As a result, when the budget is limited, we need to assign enough computations to deep layers for those essential tokens. When the budget increases, deep layers get enough computations for essential tokens, and the rest of the budget can be assigned to early layers.

https://openaccess.thecvf.com/content/CVPR2025/papers/images/892fcbb9e05759adeda652cbe6c4b4a2fe5e5c2c6ff5fc747996179a3acd9102.jpg

Figure 5. Values of $k$ of P-Sigmoid vs TFLOPs.

https://openaccess.thecvf.com/content/CVPR2025/papers/images/fc14cedf29a1aacfa8382e14b7682d92a2b6b186dd92c525b11351a40a57d0d9.jpg

Figure 6. Attention scores vs layers of LLaVA-1.5-7B.

Table 4. Exchange reduction strategies of different MLLMs for Scenario I. The strategy (i.e. keeping rates) of one MLLM from the search of P-Sigmoid does not generalizes to others.

|     |     |     |
| --- | --- | --- |
| MLLM | Reduction strategy of | Average accuracy |
| InternVL2-1B InternVL2-1B | Self InternVL2-2B | 59.19 57.58 |
| InternVL2-2B | Self | 61.22 |
| InternVL2-2B | InternVL2-2B | 60.90 |
| InternVL2-4B InternVL2-4B | Self | 67.65 |
| InternVL2-8B | LLaVA-1.5-7B | 65.91 |
| InternVL2-8B | Self LLaVA-1.5-7B | 70.10 69.49 |

MLLMs need flexible reduction methods. For Scenario I, reduction strategies should be customized for different MLLMs with the following evidences. First, as shown in Fig. 3, the S-curves of MLLMs from G-Search are different. Since G-Search reaches the optimal solution based on our assumption (See Sec. 3.2), different MLLMs have their own optimal reduction strategies. Second, we apply the keeping rates of LLaVA-1.5-7B on InternVL2-4B and 8B models, and exchange the keeping rates of InternVL2- 1B and 2B models. As shown in Table 4, all MLLMs suffer from performance drops when using reduction strategies (i.e. keeping rates) of others. As a result, handcrafted methods can hardly provide appropriate reduction strategies for various MLLMs, while our method is flexible and can adjust reduction strategies based on MLLMs.

Why a steady decrease in keeping rates: Figure 3 shows that the keeping rates of G-Search decrease steadily. This is not only because keeping rates cannot increase based on our assumption. Moreover, as shown in Fig. 6, the median of the attention scores of vision tokens drops in deep layers of the LLM within LLaVA-1.5-7B. Check similar visualizations for various MLLMs in the supplement. As shown in recent studies \[22, 42\], tokens of low attention scores in LLMs are not important and can be removed during inference. We assume that the drop in attention scores of vision tokens leads to the drop in the number of important tokens with high attention scores. Thus, keeping rates decrease.

Table 5. Training LLaVA-1.5-7B with reductions. Keeping rates are from G-Search and P-Sigmoid applied on a pretrained LLaVA1.5-7B model.

|     |     |     |
| --- | --- | --- |
| Model | Keeping rates | Avg. acc. |
| Pretrained Train w/ reduction | G-Search for Scenario I | 48.965 48.365 |
| Fintune w/ reduction |  | 48.364 |
| Pretrained | P-Sigmoid | 46.52 |
| Train w/ reduction | for Scenario II | 46.40 |
| Fintune w/ reduction |  | 47.09 |

Training with reductions: Although the proposed GSearch and P-Sigmoid are training-free, MLLMs can be trained with reductions using keeping rates from our method. We collect keeping rates of a pretrained LLaVA1.5-7B model from G-Search and P-Sigmoid for Scenario I and Scenario II, respectively. Then, new LLaVA-1.5-7B models are trained or finetuned with reductions. The budget of P-Sigmoid is set as that of FastV with $\\mathrm { R } { = } 8 7 . 5 %$ . We use the same training data as LLaVA \[28\] for both training and finetuning. As shown in Table 5, there is no performance boost in training/finetuning with reductions for Scenario I. The finetuning slightly improves the performance for Scenario II. Considering the huge cost of MLLM training/finetuning, our method acts as a good plug-and-play reduction solution for MLLMs.

# 5\. Conclusion

This paper improves the efficiency of MLLMs in two scenarios, (I) Reducing computational cost without degrading the performance. (II) Improving the performance with a given budget. We find that the relative importance of each vision token remains similar at different layers. Based on this finding, we come to the assumption that the number of essential top vision tokens does not increase along layers. Accordingly, we propose two training-free solutions, i.e. GSearch and P-Sigmoid, to reduce vision tokens for scenarios I and II, respectively. Extensive experiments demonstrate that our method outperforms other vision token reduction methods in terms of both efficiency and effectiveness on top of various MLLMs and on diverse benchmarks.

# References

\[1\] Jinze Bai, Shuai Bai, Shusheng Yang, Shijie Wang, Sinan Tan, Peng Wang, Junyang Lin, Chang Zhou, and Jingren Zhou. Qwen-vl: A versatile vision-language model for understanding, localization, text reading, and beyond. 2023. 3

\[2\] Ali Furkan Biten, Ruben Tito, Andres Mafla, Lluis Gomez, Marcal Rusinol, Ernest Valveny, CV Jawahar, and Dimosthenis Karatzas. Scene text visual question answering. In Proceedings of the IEEE/CVF international conference on computer vision, pages 4291-4301, 2019. 5

\[3\] Junbum Cha, Wooyoung Kang, Jonghwan Mun, and Byungseok Roh. Honeybee: Locality-enhanced projector for multimodal llm. In Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition, pages 13817-13827, 2024. 1, 3

\[4\] Hila Chefer, Shir Gur, and Lior Wolf. Transformer interpretability beyond attention visualization. In Proceedings of the IEEE/CVF conference on computer vision and pattern recognition, pages 782-791, 2021. 4

\[5\] Liang Chen, Haozhe Zhao, Tianyu Liu, Shuai Bai, Junyang Lin, Chang Zhou, and Baobao Chang. An image is worth 1/2 tokens after layer 2: Plug-and-play inference acceleration for large vision-language models. In European Conference on Computer Vision, 2024. 1, 3, 6, 5

\[6\] Zhe Chen, Weiyun Wang, Hao Tian, Shenglong Ye, Zhangwei Gao, Erfei Cui, Wenwen Tong, Kongzhi Hu, Jiapeng Luo, Zheng Ma, et al. How far are we to gpt-4v? closing the gap to commercial multimodal models with open-source suites. arXiv preprint arXiv:2404.16821, 2024. 2, 3, 6

\[7\] Zhe Chen, Jiannan Wu, Wenhai Wang, Weijie Su, Guo Chen, Sen Xing, Muyan Zhong, Qinglong Zhang, Xizhou Zhu, Lewei Lu, et al. Internvl: Scaling up vision foundation models and aligning for generic visual-linguistic tasks. In Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition, pages 24185-24198, 2024. 2, 3, 6

\[8\] Wenliang Dai, Junnan Li, Dongxu Li, Anthony Meng Huat Tiong, Junqi Zhao, Weisheng Wang, Boyang Li, Pascale Fung, and Steven Hoi. Instructblip: Towards generalpurpose vision-language models with instruction tuning. Advances in neural information processing systems, 36, 2023. 2

\[9\] Tri Dao. FlashAttention-2: Faster attention with better parallelism and work partitioning. arXiv preprint arXiv:2307.08691, 2023. 1, 2

10\] Tri Dao, Dan Fu, Stefano Ermon, Atri Rudra, and Christopher Re. Flashattention: Fast and memory-efficient exact attention with io-awareness. Advances in Neural Information Processing Systems, 35:16344-16359, 2022. 1

11\] Alexey Dosovitskiy, Lucas Beyer, Alexander Kolesnikov, Dirk Weissenborn, Xiaohua Zhai, Thomas Unterthiner, Mostafa Dehghani, Matthias Minderer, Georg Heigold, Sylvain Gelly, Jakob Uszkoreit, and Neil Houlsby. An image is worth 16x16 words: Transformers for image recognition at scale. In International Conference on Learning Representations, 2021. 3

\[12\] Chaoyou Fu, Yuhan Dai, Yondong Luo, Lei Li, Shuhuai Ren, Renrui Zhang, Zihan Wang, Chenyu Zhou, Yunhang Shen, Mengdan Zhang, et al. Video-MME: The first-ever comprehensive evaluation benchmark of multi-modal llms in video analysis. arXiv preprint arXiv:2405.21075, 2024. 4

\[13\] Tianrui Guan, Fuxiao Liu, Xiyang Wu, Ruiqi Xian, Zongxia Li, Xiaoyu Liu, Xijun Wang, Lichang Chen, Furong Huang, Yaser Yacoob, et al. Hallusionbench: an advanced diagnostic suite for entangled language hallucination and visual illusion in large vision-language models. In Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition, pages 14375-14385, 2024. 5

\[14\] Drew A Hudson and Christopher D Manning. GQA: A new dataset for real-world visual reasoning and compositional question answering. In Proceedings of the IEEE/CVF conference on computer vision and pattern recognition, pages 6700-6709, 2019. 5

\[15\] Yiren Jian, Chongyang Gao, and Soroush Vosoughi. Bootstrapping vision-language learning with decoupled language pre-training. Advances in Neural Information Processing Systems, 36, 2024. 2

\[16\] Aniruddha Kembhavi, Mike Salvato, Eric Kolve, Minjoon Seo, Hannaneh Hajishirzi, and Ali Farhadi. A diagram is worth a dozen images. In Computer Vision-ECCV 2016: 14th European Conference, Amsterdam, The Netherlands, October 11-14, 2016, Proceedings, Part IV 14, pages 235- 251. Springer, 2016. 5

\[17\] Maurice G Kendall. A new measure of rank correlation. Biometrika, 30(1-2):81-93, 1938. 1, 4, 6

\[18\] Junnan Li, Dongxu Li, Silvio Savarese, and Steven Hoi. Blip-2: Bootstrapping language-image pre-training with frozen image encoders and large language models. In International conference on machine learning, pages 19730- 19742. PMLR, 2023. 3

\[19\] Kunchang Li, Yali Wang, Yinan He, Yizhuo Li, Yi Wang, Yi Liu, Zun Wang, Jilan Xu, Guo Chen, Ping Luo, et al. MVBench: A comprehensive multi-modal video understanding benchmark. In Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition, pages 22195- 22206, 2024. 4

\[20\] Wentong Li, Yuqian Yuan, Jian Liu, Dongqi Tang, Song Wang, Jianke Zhu, and Lei Zhang. Tokenpacker: Effcient visual projector for multimodal llm. arXiv preprint arXiv:2407.02392, 2024. 1, 2, 3, 6

\[21\] Yifan Li, Yifan Du, Kun Zhou, Jinpeng Wang, Wayne Xin Zhao, and Ji-Rong Wen. Evaluating object hallucination in large vision-language models. arXiv preprint arXiv:2305.10355, 2023. 5

\[22\] Yuhong Li, Yingbing Huang, Bowen Yang, Bharat Venkitesh, Acyr Locatelli, Hanchen Ye, Tianle Cai, Patrick Lewis, and Deming Chen. Snapkv: Llm knows what you are looking for before generation. arXiv preprint arXiv:2404.14469, 2024. 2, 3, 4, 8

\[23\] Yanwei Li, Chengyao Wang, and Jiaya Jia. LLaMA-VID: An image is worth 2 tokens in large language models. In European Conference on Computer Vision, 2024. 3

\[24\] Yanwei Li, Yuechen Zhang, Chengyao Wang, Zhisheng Zhong, Yixin Chen, Ruihang Chu, Shaoteng Liu, and Jiaya Jia. Mini-gemini: Mining the potential of multi-modality vision language models. arXiv preprint arXiv:2403.18814, 2024. 1, 3

\[25\] Zhang Li, Biao Yang, Qiang Liu, Zhiyin Ma, Shuo Zhang, Jingxu Yang, Yabo Sun, Yuliang Liu, and Xiang Bai. Monkey: Image resolution and text label are important things for large multi-modal models. In Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition, pages 26763-26773, 2024. 1, 3

\[26\] Zhihang Lin, Mingbao Lin, Luxi Lin, and Rongrong Ji. Boosting multimodal large language models with visual tokens withdrawal for rapid inference. arXiv preprint arXiv:2405.05803, 2024. 1, 3, 6

\[27\] Haotian Liu, Chunyuan Li, Qingyang Wu, and Yong Jae Lee. Visual instruction tuning. Advances in neural information processing systems, 36, 2023. 2

\[28\] Haotian Liu, Chunyuan Li, Yuheng Li, and Yong Jae Lee. Improved baselines with visual instruction tuning. In Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition, pages 26296-26306, 2024. 2, 4, 6, 8

\[29\] Haotian Liu, Chunyuan Li, Yuheng Li, Bo Li, Yuanhan Zhang, Sheng Shen, and Yong Jae Lee. Llava-next: Improved reasoning, ocr, and world knowledge, 2024. 3

\[30\] Yuan Liu, Haodong Duan, Yuanhan Zhang, Bo Li, Songyang Zhang, Wangbo Zhao, Yike Yuan, Jiaqi Wang, Conghui He, Ziwei Liu, et al. MMBench: Is your multi-modal model an all-around player? In European Conference on Computer Vision, pages 216-233. Springer, 2025. 5

\[31\] Pan Lu, Hritik Bansal, Tony Xia, Jiacheng Liu, Chunyuan Li, Hannaneh Hajishirzi, Hao Cheng, Kai-Wei Chang, Michel Galley, and Jianfeng Gao. Mathvista: Evaluating mathematical reasoning of foundation models in visual contexts. arXiv preprint arXiv:2310.02255, 2023. 5

\[32\] Gen Luo, Yiyi Zhou, Yuxin Zhang, Xiawu Zheng, Xiaoshuai Sun, and Rongrong Ji. Feast your eyes: Mixture-ofresolution adaptation for multimodal large language models. arXiv preprint arXiv:2403.03003, 2024. 1, 3

\[33\] Ahmed Masry, Do Long, Jia Qing Tan, Shafiq Joty, and Enamul Hoque. ChartQA: A benchmark for question answering about charts with visual and logical reasoning. In Findings of the Association for Computational Linguistics: ACL 2022, pages 2263-2279, Dublin, Ireland, 2022. Association for Computational Linguistics. 5

\[34\] Minesh Mathew, Dimosthenis Karatzas, and CV Jawahar. DocVQA: A dataset for vqa on document images. In Proceedings of the IEEE/CVF winter conference on applications of computer vision, pages 2200-2209, 2021. 5

\[35\] Jonas Mockus. The bayesian approach to global optimization. In System Modeling and Optimization: Proceedings of the 1Oth IFIP Conference New York City, USA, August 31- September 4, 1981, pages 473-481. Springer, 2005. 4

\[36\] Alec Radford, Jong Wook Kim, Chris Hallacy, Aditya Ramesh, Gabriel Goh, Sandhini Agarwal, Girish Sastry, Amanda Askell, Pamela Mishkin, Jack Clark, et al. Learning transferable visual models from natural language supervision. In International conference on machine learning, pages 8748-8763. PMLR, 2021. 3

\[37\] Yuzhang Shang, Mu Cai, Bingxin Xu, Yong Jae Lee, and Yan Yan. Llava-prumerge: Adaptive token reduction for efficient large multimodal models. arXiv preprint arXiv:2403.15388, 2024. 3

\[38\] Amanpree Singh, Vivek Natarajan, Meet Shah, Yu Jiang, Xinlei Chen, Dhruv Batra, Devi Parikh, and Marcus Rohrbach. Towards VQA models that can read. In Proceedings of the IEEE/CVF conference on computer vision and pattern recognition, pages 8317-8326, 2019. 5

\[39\] Shengbang Tong, Ellis Brown, Penghao Wu, Sanghyun Woo, Manoj Middepogu, Sai Charitha Akula, Jihan Yang, Shusheng Yang, Adithya Iyer, Xichen Pan, et al. Cambrian1: A fully open, vision-centric exploration of multimodal 1lms. arXiv preprint arXiv:2406.16860, 2024. 5

\[40\] Weiyun Wang, Shuibo Zhang, Yiming Ren, Yuchen Duan, Tiantong Li, Shuo Liu, Mengkang Hu, Zhe Chen, Kaipeng Zhang, Lewei Lu, et al. Needle in a multimodal haystack. Advances in Neural Information Processing Systems, 37: 20540-20565, 2024. 1, 6

\[41\] xAI. RealWordQA: [https://huggingface.co/](https://huggingface.co/) datasets/xai-org/RealworldQA, 2024. 5

\[42\] Guangxuan Xiao, Yuandong Tian, Beidi Chen, Song Han, and Mike Lewis. Efficient streaming language models with attention sinks. In The Twelfth International Conference on Learning Representations, 2024. 2, 3, 4, 8

\[43\] xiaoju ye. calflops: a flops and params calculate tool for neural networks in pytorch framework, 2023. 5

\[44\] Long Xing, Qidong Huang, Xiaoyi Dong, Jiajie Lu, Pan Zhang, Yuhang Zang, Yuhang Cao, Conghui He, Jiaqi Wang, Feng Wu, et al. Pyramiddrop: Accelerating your large vision-language models via pyramid visual redundancy reduction. arXiv preprint arXiv:2410.17247, 2024. 1, 3, 6

\[45\] Ruyi Xu, Yuan Yao, Zonghao Guo, Junbo Cui, Zanlin Ni, Chunjiang Ge, Tat-Seng Chua, Zhiyuan Liu, Maosong Sun, and Gao Huang. Llava-uhd: an lmm perceiving any aspect ratio and high-resolution images. arXiv preprint arXiv:2403.11703, 2024. 1, 3

\[46\] Linli Yao, Lei Li, Shuhuai Ren, Lean Wang, Yuanxin Liu, Xu Sun, and Lu Hou. Deco: Decoupling token compression from semantic abstraction in multimodal large language models. arXiv preprint arXiv:2405.20985, 2024. 2, 3, 6, 1

\[47\] Xubing Ye, Yukang Gan, Xiaoke Huang, Yixiao Ge, Ying Shan, and Yansong Tang. VoCo-LLaMA: Towards vision compression with large language models. ArXiv preprint arXiv:2406.12275, 2024. 3

\[48\] Xiang Yue, Yuansheng Ni, Kai Zhang, Tianyu Zheng, Ruoqi Liu, Ge Zhang, Samuel Stevens, Dongfu Jiang, Weiming Ren, Yuxuan Sun, et al. Mmmu: A massive multi-discipline multimodal understanding and reasoning benchmark for expert agi. In Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition, pages 9556- 9567, 2024. 5

\[49\] Kaichen Zhang, Bo Li, Peiyuan Zhang, Fanyi Pu, Joshua Adrian Cahyono, Kairui Hu, Shuai Liu, Yuanhan Zhang, Jingkang Yang, Chunyuan Li, and Ziwei Liu. LMMsEval: Reality check on the evaluation of large multimodal models, 2024. 6 \[50\] Lin Zhang, Lei Zhang, Xuanqin Mou, and David Zhang. Fsim: A feature similarity index for image quality assessment. IEEE transactions on Image Processing, 20(8):2378-

2386, 2011. 2 \[51\] Peiyuan Zhang, Kaichen Zhang, Bo Li, Guangtao Zeng, Jingkang Yang, Yuanhan Zhang, Ziyue Wang, Haoran Tan, Chunyuan Li, and Ziwei Liu. Long context transfer from language to vision. arXiv preprint arXiv:2406.16852, 2024.

4 \[52\] Yi-Fan Zhang, Qingsong Wen, Chaoyou Fu, Xue Wang, Zhang Zhang, Liang Wang, and Rong Jin. Beyond llava-hd: Diving into high-resolution large multimodal models. arXiv preprint arXiv:2406.08487, 2024. 1, 3 \[53\] Shiyu Zhao, Lin Zhang, Shuaiyi Huang, Ying Shen, and Shengjie Zhao. Dehazing evaluation: Real-world benchmark datasets, criteria, and baselines. IEEE Transactions on Image Processing, 29:6947-6962, 2020. 2 \[54\] Shiyu Zhao, Zhixing Zhang, Samuel Schulter, Long Zhao, BG Vijay Kumar, Anastasis Stathopoulos, Manmohan Chandraker, and Dimitris N Metaxas. Exploiting unlabeled data with vision and language models for object detection. In European conference on computer vision, pages 159-175. Springer, 2022. 2 \[55\] Shiyu Zhao, Samuel Schulter, Long Zhao, Zhixing Zhang, Yumin Suh, Manmohan Chandraker, and Dimitris N Metaxas. Taming self-training for open-vocabulary object detection. In Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition, pages 13938-

13947, 2024. \[56\] Shiyu Zhao, Long Zhao, Yumin Suh, Dimitris N Metaxas, Manmohan Chandraker, and Samuel Schulter. Generating enhanced negatives for training language-based object detectors. In Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition, pages 13592-13602,

2024\. 2 \[57\] Deyao Zhu, Jun Chen, Xiaoqian Shen, Xiang Li, and Mohamed Elhoseiny. MiniGPT-4: Enhancing vision-language understanding with advanced large language models. In The Twelfth International Conference on Learning Representations, 2024. 2

</details>

<details>
<summary>arXiv:2407.01449v6 \[cs.IR\] 28 Feb 2025</summary>

arXiv:2407.01449v6 \[cs.IR\] 28 Feb 2025

# ColPali: Efficient Document Retrieval with Vision Language Models

Manuel Faysse 1,3 Hugues Sibille∗1,4  Tony Wu∗1  Bilel Omrani1

Gautier Viaud1Céline Hudelot3Pierre Colombo2,3

1Illuin Technology  2Equall.ai  3CentraleSupélec, Paris-Saclay  4ETH Zürich

[manuel.faysse@centralesupelec.fr](https://arxiv.org/html/2407.01449v6/manuel.faysse@centralesupelec.fr "")Equal Contribution

###### Abstract

Documents are visually rich structures that convey information through text, but also figures, page layouts, tables, or even fonts. Since modern retrieval systems mainly rely on the textual information they extract from document pages to index documents -often through lengthy and brittle processes-, they struggle to exploit key visual cues efficiently. This limits their capabilities in many practical document retrieval applications such as Retrieval Augmented Generation (RAG).
To benchmark current systems on visually rich document retrieval, we introduce the Visual Document Retrieval Benchmark ViDoRe, composed of various page-level retrieval tasks spanning multiple domains, languages, and practical settings.
The inherent complexity and performance shortcomings of modern systems motivate a new concept; doing document retrieval by directly embedding the images of the document pages. We release ColPali, a Vision Language Model trained to produce high-quality multi-vector embeddings from images of document pages. Combined with a late interaction matching mechanism, ColPali largely outperforms modern document retrieval pipelines while being drastically simpler, faster and end-to-end trainable.
We release models, data, code and benchmarks under open licenses at [https://hf.co/vidore](https://hf.co/vidore "").

## 1 Introduction

Document Retrieval consists of matching a user query to relevant documents in a given corpus. It is central to many widespread industrial applications, either as a standalone ranking system (search engines) or as part of more complex information extraction or Retrieval Augmented Generation (RAG) pipelines.

Over recent years, pretrained language models have enabled large improvements in text embedding models. In practical industrial settings, however, the primary performance bottleneck for efficient document retrieval stems not from embedding model performance but from the prior data ingestion pipeline. Indexing a standard PDF document involves several steps. First, PDF parsers or Optical Character Recognition (OCR) systems are used to extract words from the pages. Document layout detection models can then be run to segment paragraphs, titles, and other page objects such as tables, figures, and headers. A chunking strategy is then defined to group text passages with some semantical coherence, and modern retrieval setups may even integrate a captioning step to describe visually rich elements in a natural language form, more suitable for embedding models.
In our experiments ( [Table 2](https://arxiv.org/html/2407.01449v6#S5.T2 "Table 2 ‣ 5 Results ‣ ColPali: Efficient Document Retrieval with Vision Language Models")), we typically find that optimizing the ingestion pipeline yields much better performance on visually rich document retrieval than optimizing the text embedding model.

Contribution 1: ViDoRe.
In this work, we argue that document retrieval systems should not be evaluated solely on the capabilities of text embedding models (Bajaj et al., [2016](https://arxiv.org/html/2407.01449v6#bib.bib6 ""); Thakur et al., [2021](https://arxiv.org/html/2407.01449v6#bib.bib50 ""); Muennighoff et al., [2022](https://arxiv.org/html/2407.01449v6#bib.bib40 "")), but should also consider the context and visual elements of the documents to be retrieved. To this end, we create and openly release ViDoRe, a comprehensive benchmark to evaluate systems on page-level document retrieval with a wide coverage of domains, visual elements, and languages. ViDoRe addresses practical document retrieval scenarios, where queries often necessitate both textual and visual understanding for accurate document matching. We highlight the shortcomings of current text-centric systems in these settings.111The ViDoRe benchmark leaderboard is hosted publicly at [https://huggingface.co/spaces/vidore/vidore-leaderboard](https://huggingface.co/spaces/vidore/vidore-leaderboard "") to encourage further developments.

Contribution 2: ColPali.
We propose a novel concept and model architecture based on Vision Language Models (VLMs) to efficiently index documents purely from their visual features, allowing for subsequent fast query matching with late interaction mechanisms (Khattab & Zaharia, [2020](https://arxiv.org/html/2407.01449v6#bib.bib26 "")). Our method, ColPali, significantly outperforms all other retrieval systems on ViDoRe while being fast and end-to-end trainable.
These results demonstrate the potential and the many benefits of this novel Retrieval in Vision Space concept, which could significantly alter the way document retrieval is approached in the industry moving forward.
We release all resources at [https://hf.co/vidore](https://hf.co/vidore "").

https://arxiv.org/html/2407.01449v6/extracted/6240861/images/final_architecture.pngFigure 1: ColPali simplifies document retrieval w.r.t. standard retrieval methods while achieving stronger performances with better latencies. Latencies and results are detailed in [section 5](https://arxiv.org/html/2407.01449v6#S5 "5 Results ‣ ColPali: Efficient Document Retrieval with Vision Language Models") and [subsection B.4](https://arxiv.org/html/2407.01449v6#A2.SS4 "B.4 Latency computations ‣ Appendix B Implementation details ‣ ColPali: Efficient Document Retrieval with Vision Language Models").

## 2 Problem Formulation & Related Work

Problem Setting.
In our setting, a retrieval system scores how relevant a document d𝑑ditalic\_d from corpus 𝒟𝒟\\mathcal{D}caligraphic\_D is with respect to a query q𝑞qitalic\_q. Computing the similarity score s⁢(q,d)∈ℝ𝑠𝑞𝑑ℝs(q,d)\\in\\mathbb{R}italic\_s ( italic\_q , italic\_d ) ∈ blackboard\_R for each of the \|𝒟\|𝒟\|\\mathcal{D}\|\| caligraphic\_D \| documents in the corpus creates a ranking we can use to extract the most relevant documents. In this work, we focus on page-level retrieval: given a query, is the correct document page retrieved by the system? For coherence with existing literature, we further use the term document to refer to individual pages, i.e. the atomic retrieved elements in our setting. As we focus on practical industrial retrieval applications (RAG, search engines) with potentially large corpora sizes, latency constraints are imposed on scoring systems. Most current retrieval systems can be decomposed into (1) an offline indexation phase in which a document index is built and (2) an online querying phase in which a query is matched to documents from the index and where low latency is vital to the user experience.

Under these industrial constraints, we identify three main properties an efficient document retrieval systems should exhibit: (R1) strong retrieval performance, as measured by standard retrieval metrics; (R2) fast online querying, measured through average latencies; (R3) high throughput corpus indexation, ie. the number of pages that can be embedded in a given timeframe.

### 2.1 Textual Retrieval Methods

Document Retrieval in Text Space.

Statistical methods based on word frequency like TF-IDF (Sparck Jones, [1972](https://arxiv.org/html/2407.01449v6#bib.bib48 "")) and BM25 (Robertson et al., [1994](https://arxiv.org/html/2407.01449v6#bib.bib45 "")) are still widely used due to their simplicity and efficiency. More recently, neural embedding models based on fine-tuned large language models display state-of-the-art performance on a variety of text embedding tasks and top the retrieval leaderboards (Muennighoff et al., [2022](https://arxiv.org/html/2407.01449v6#bib.bib40 "")).

Neural Retrievers.
In bi-encoder models (Reimers & Gurevych, [2019](https://arxiv.org/html/2407.01449v6#bib.bib44 ""); Karpukhin et al., [2020](https://arxiv.org/html/2407.01449v6#bib.bib25 ""); Wang et al., [2022](https://arxiv.org/html/2407.01449v6#bib.bib52 "")), documents are independently mapped offline to a dense vector space. Queries are embedded online and matched to documents through a fast cosine distance computation.
A slower, but slightly more performant alternative, cross-encoder systems (Wang et al., [2020](https://arxiv.org/html/2407.01449v6#bib.bib55 ""); Cohere, [2024](https://arxiv.org/html/2407.01449v6#bib.bib13 "")) concatenate query and document as a single input sequence and iteratively attribute matching scores to each possible combination. This enables full attention computation between query and document terms but comes at the cost of computational efficiency, as \|𝒟\|𝒟\|\\mathcal{D}\|\| caligraphic\_D \| encoding passes must be done online.

Multi-Vector retrieval via late interaction.
In the late interaction paradigm introduced by ColBERT (Khattab & Zaharia, [2020](https://arxiv.org/html/2407.01449v6#bib.bib26 "")), an embedding is pre-computed and indexed per document token. At runtime, similarity can be computed with individual query token embeddings. The idea is to benefit from the rich interaction between individual query and document terms while taking advantage of the offline computation and fast query matching enabled by bi-encoders. See [Appendix E](https://arxiv.org/html/2407.01449v6#A5.SSx3 "ColBERT ‣ Appendix E Model glossary ‣ ColPali: Efficient Document Retrieval with Vision Language Models") for more details.

Retrieval Evaluation.
Although benchmarks and leaderboards have been developed to evaluate text embedding models (Thakur et al., [2021](https://arxiv.org/html/2407.01449v6#bib.bib50 ""); Muennighoff et al., [2022](https://arxiv.org/html/2407.01449v6#bib.bib40 "")), much of the performance improvements in industrial use cases of embedding models stem from the prior data ingestion pipeline. While documents often rely on visual elements to more efficiently convey information to human readers, text-only systems barely tap into these visual cues. Other work has also independently studied table or chart retrieval systems through repurposed Question Answering datasets (Zhang et al., [2019](https://arxiv.org/html/2407.01449v6#bib.bib59 ""); Nowak et al., [2024](https://arxiv.org/html/2407.01449v6#bib.bib42 "")) but only assessing specialized methods for each task.

To our knowledge, no benchmark evaluates document retrieval systems in practical settings; in an end-to-end manner, across several document types and topics, and by evaluating the use of both textual and visual document features.

### 2.2 Integrating Visual features

Contrastive Vision Language Models.
Mapping latent representations of textual content to corresponding representations of visual content has been done by aligning disjoint visual and text encoders through contrastive losses (Radford et al., [2021](https://arxiv.org/html/2407.01449v6#bib.bib43 ""); Zhai et al., [2023](https://arxiv.org/html/2407.01449v6#bib.bib58 "")). While some OCR capabilities exist in these models, the visual component is often not optimized for text understanding.

The Fine-grained Interactive Language-Image Pre-training (Yao et al., [2021](https://arxiv.org/html/2407.01449v6#bib.bib56 "")) framework extends the late interaction mechanism to cross-modal Vision Language Models, relying on max similarity operations between text tokens and image patches.

Visually Rich Document Understanding.
To go beyond text, some document-focused models jointly encode text tokens alongside visual or document layout features (Appalaraju et al., [2021](https://arxiv.org/html/2407.01449v6#bib.bib4 ""); Kim et al., [2021](https://arxiv.org/html/2407.01449v6#bib.bib27 ""); Huang et al., [2022](https://arxiv.org/html/2407.01449v6#bib.bib22 ""); Tang et al., [2022](https://arxiv.org/html/2407.01449v6#bib.bib49 "")).
Large Language transformer Models (LLMs) with strong reasoning capabilities have recently been combined with Vision Transformers (ViTs) (Dosovitskiy et al., [2020](https://arxiv.org/html/2407.01449v6#bib.bib17 "")) to create VLMs (Alayrac et al., [2022](https://arxiv.org/html/2407.01449v6#bib.bib2 ""); Liu et al., [2023](https://arxiv.org/html/2407.01449v6#bib.bib35 ""); Bai et al., [2023](https://arxiv.org/html/2407.01449v6#bib.bib5 ""); Laurençon et al., [2024b](https://arxiv.org/html/2407.01449v6#bib.bib30 "")) where image patch vectors from contrastively trained ViT models (Zhai et al., [2023](https://arxiv.org/html/2407.01449v6#bib.bib58 "")) are fed as input embeddings to the LLM and concatenated with the text-token embeddings.

PaliGemma.
The PaliGemma-3B model (Beyer et al., [2024](https://arxiv.org/html/2407.01449v6#bib.bib7 "")) extends concepts from Pali3 (Chen et al., [2023](https://arxiv.org/html/2407.01449v6#bib.bib11 "")), and projects SigLIP-So400m/14(Alabdulmohsin et al., [2023](https://arxiv.org/html/2407.01449v6#bib.bib1 "")) patch embeddings into Gemma-2B’s text vector space (Gemma Team et al., [2024](https://arxiv.org/html/2407.01449v6#bib.bib19 "")). Along with its reasonable size w.r.t. other performant VLMs, an interesting property of PaliGemma’s text model is that it is fine-tuned with full-block attention on the prefix (instruction text and image tokens). See [Appendix E](https://arxiv.org/html/2407.01449v6#A5 "Appendix E Model glossary ‣ ColPali: Efficient Document Retrieval with Vision Language Models") for more details.

VLMs display enhanced capabilities in Visual Question Answering, captioning, and document understanding (Yue et al., [2023](https://arxiv.org/html/2407.01449v6#bib.bib57 "")), but are not optimized for retrieval tasks.

## 3 The ViDoRe Benchmark

Existing benchmarks for contrastive vision-language models primarily evaluate retrieval for natural images (Lin et al., [2014](https://arxiv.org/html/2407.01449v6#bib.bib34 ""); Borchmann et al., [2021](https://arxiv.org/html/2407.01449v6#bib.bib9 ""); Thapliyal et al., [2022](https://arxiv.org/html/2407.01449v6#bib.bib51 ""))). On the other hand, textual retrieval benchmarks (Muennighoff et al., [2022](https://arxiv.org/html/2407.01449v6#bib.bib40 "")) are evaluated at at textual passage level and are not tailored for document retrieval tasks. We fill the gap with ViDoRe, a comprehensive benchmark for document retrieval using visual features.

### 3.1 Benchmark Design

ViDoRe is designed to comprehensively evaluate retrieval systems on their capacity to match queries to relevant documents at the page level. This benchmark encompasses multiple orthogonal subtasks, with focuses on various modalities - text, figures, infographics, tables; thematic domains - medical, business, scientific, administrative; or languages - English, French. Tasks also span varying levels of complexity, in order to capture signals from both weaker and stronger systems.
As many systems require large amounts of time to index pages (captioning-based approaches can take dozens of seconds per page for instance), we limit the number of candidate documents for each retrieval task in order to evaluate even complex systems in a reasonable timeframe without sacrificing quality. For trainable retrieval systems, we provide a reference training set that can be used to facilitate comparisons.

| Dataset | Language | \# Queries | \# Documents | Description |
| --- | --- | --- | --- | --- |
| Academic Tasks |  |  |  |  |
| DocVQA | English | 500 | 500 | Scanned documents from UCSF Industry |
| InfoVQA | English | 500 | 500 | Infographics scrapped from the web |
| TAT-DQA | English | 1600 | 1600 | High-quality financial reports |
| arXiVQA | English | 500 | 500 | Scientific Figures from arXiv |
| TabFQuAD | French | 210 | 210 | Tables scrapped from the web |
| Practical Tasks |  |  |  |  |
| Energy | English | 100 | 1000 | Documents about energy |
| Government | English | 100 | 1000 | Administrative documents |
| Healthcare | English | 100 | 1000 | Medical documents |
| AI | English | 100 | 1000 | Scientific documents related to AI |
| Shift Project | French | 100 | 1000 | Environmental reports |

Table 1: ViDoRe comprehensively evaluates multimodal retrieval methods.

Academic Tasks.
We repurpose widely used visual question-answering benchmarks for retrieval tasks: for each page-question-answer triplet, we use the question as the query, and the associated page as the gold document ( [Table 1](https://arxiv.org/html/2407.01449v6#S3.T1 "Table 1 ‣ 3.1 Benchmark Design ‣ 3 The ViDoRe Benchmark ‣ ColPali: Efficient Document Retrieval with Vision Language Models")). These academic datasets either focus on single specific modalities (Mathew et al., [2020](https://arxiv.org/html/2407.01449v6#bib.bib38 ""); [2021](https://arxiv.org/html/2407.01449v6#bib.bib39 ""); Li et al., [2024](https://arxiv.org/html/2407.01449v6#bib.bib33 "")) or target more varied visually rich documents (Zhu et al., [2022](https://arxiv.org/html/2407.01449v6#bib.bib61 "")). Moreover, we consider TabFQuAD, a human-labeled dataset on tables extracted from French industrial PDF documents released with this work. Details can be found in [subsection A.1](https://arxiv.org/html/2407.01449v6#A1.SS1 "A.1 Academic Datasets ‣ Appendix A Benchmark Datasets ‣ ColPali: Efficient Document Retrieval with Vision Language Models").

Practical tasks.
We construct topic-specific retrieval benchmarks spanning multiple domains to go beyond repurposed QA datasets and evaluate retrieval in more realistic industrial situations (e.g. RAG). To achieve this, we collect publicly accessible PDF documents and generate queries pertaining to document pages using Claude-3 Sonnet, a high-quality proprietary vision-language model (Anthropic, [2024](https://arxiv.org/html/2407.01449v6#bib.bib3 "")). In total, we collect 1,000 document pages per topic, which we associate with 100 queries extensively filtered for quality and relevance by human annotators. The corpus topics are intentionally specific to maximize syntactic proximity between documents, creating more challenging retrieval tasks and covering an array of orthogonal domains ( [Table 1](https://arxiv.org/html/2407.01449v6#S3.T1 "Table 1 ‣ 3.1 Benchmark Design ‣ 3 The ViDoRe Benchmark ‣ ColPali: Efficient Document Retrieval with Vision Language Models")).
222Answers are generated alongside queries to (1) ground queries and improve their quality and (2) provide resources to foster future work.

Evaluation Metrics.
We evaluate performance on our benchmark (Requirement R1) using standard metrics from the retrieval literature (nDCG, Recall@K, MRR). We report nDCG@5 values as the main performance metric in this work and release the complete sets of results along with the models333 [https://huggingface.co/vidore](https://huggingface.co/vidore ""). To validate compliance with practical industrial requirements ( [section 2](https://arxiv.org/html/2407.01449v6#S2 "2 Problem Formulation & Related Work ‣ ColPali: Efficient Document Retrieval with Vision Language Models")), we also consider query latencies (R2) and indexing throughputs (R3).

### 3.2 Assessing Current Systems

Unstructured. We evaluate retrieval systems representative of those found in standard industrial RAG pipelines. As is common practice, we rely on the Unstructured444 [www.unstructured.io](https://arxiv.org/html/2407.01449v6/www.unstructured.io "") off-the-shelf tool in the highest resolution settings to construct high-quality text chunks from PDF documents. Unstructured orchestrates the document parsing pipeline, relying on deep learning vision models to detect titles and document layouts (Ge et al., [2021](https://arxiv.org/html/2407.01449v6#bib.bib18 "")), OCR engines (Smith, [2007](https://arxiv.org/html/2407.01449v6#bib.bib47 "")) to extract text in non-native PDFs, specialized methods or models to detect and reconstruct tables, and implements a chunking strategy (by-title) that leverages the detected document structure to preserve section boundaries when concatenating texts. As is common practice, in our simplest Unstructured configuration (text-only), only textual elements are kept and figures, images, and tables are considered noisy information and are filtered out.

Unstructured + X. While Unstructured is a strong baseline by itself, we further augment Unstructured’s output by integrating the visual elements. In (\+ OCR), tables, charts, and images are run through an OCR engine, processed by Unstructured, and chunked independently. In (\+ Captioning), we set up a fully-fledged captioning strategy (Zhao et al., [2023](https://arxiv.org/html/2407.01449v6#bib.bib60 "")), in which we feed visual elements to a strong proprietary Vision Language Model (Claude-3 Sonnet (Anthropic, [2024](https://arxiv.org/html/2407.01449v6#bib.bib3 ""))) to obtain highly detailed textual descriptions of the elements.
Both strategies aim to integrate visual elements in the retrieval pipeline but incur significant latency and resource costs ( [subsection 5.2](https://arxiv.org/html/2407.01449v6#S5.SS2 "5.2 Latencies & Memory Footprint ‣ 5 Results ‣ ColPali: Efficient Document Retrieval with Vision Language Models")).

Embedding Model. To embed textual chunks, we evaluate Okapi BM25, the de facto standard sparse statistical retrieval method, and the dense encoder of BGE-M3 (Chen et al., [2024](https://arxiv.org/html/2407.01449v6#bib.bib10 "")), a multilingual neural method with SOTA performance in its size category. Chunks are embedded and scored independently, and page-level scores are obtained by max-pooling over the page’s chunk scores.555We empirically validated the max-pooling strategy over sub-page chunks to be more effective than concatenating all page chunks before embedding pagewise.

Contrastive VLMs. We also evaluate the strongest available vision-language embedding models; Jina CLIP (Koukounas et al., [2024](https://arxiv.org/html/2407.01449v6#bib.bib28 "")), Nomic Embed Vision (Nomic, [2024](https://arxiv.org/html/2407.01449v6#bib.bib41 "")), and SigLIP-So400m/14(Alabdulmohsin et al., [2023](https://arxiv.org/html/2407.01449v6#bib.bib1 "")).

Results. From a performance perspective, best results are obtained by combining the Unstructured parser with visual information, either from captioning strategies or by running OCR on the visual elements ( [Table 2](https://arxiv.org/html/2407.01449v6#S5.T2 "Table 2 ‣ 5 Results ‣ ColPali: Efficient Document Retrieval with Vision Language Models")). Little difference is seen between BM25 and BGE-M3 embeddings highlighting the visual information bottleneck. Contrastive VLMs lag behind. Beyond retrieval performance (R1), the indexing latencies (R2) reported in [Figure 2](https://arxiv.org/html/2407.01449v6#S3.F2 "Figure 2 ‣ 3.2 Assessing Current Systems ‣ 3 The ViDoRe Benchmark ‣ ColPali: Efficient Document Retrieval with Vision Language Models") illustrate that PDF parsing pipelines can be very lengthy, especially when incorporating OCR or captioning strategies. Querying latencies at runtime (R3) are very good for all evaluated systems (≤22 ms on a NVIDIA L4) due to fast query encoding and cosine similarity matching.

https://arxiv.org/html/2407.01449v6/x1.png

Figure 2: Offline document indexing with ColPali is much simpler and faster compared to standard retrieval methods. The PDF Parser results are obtained following the Unstructured settings with BGE-M3 detailed in [subsection 3.2](https://arxiv.org/html/2407.01449v6#S3.SS2 "3.2 Assessing Current Systems ‣ 3 The ViDoRe Benchmark ‣ ColPali: Efficient Document Retrieval with Vision Language Models"). All indexing speeds are averaged per-page latencies. More details in [subsection B.4](https://arxiv.org/html/2407.01449v6#A2.SS4 "B.4 Latency computations ‣ Appendix B Implementation details ‣ ColPali: Efficient Document Retrieval with Vision Language Models").

## 4 Late interaction based Vision Retrieval

### 4.1 Architecture

Vision-Language Models.
Encouraged by their strong document understanding capabilities, we propose adapting recent VLMs for retrieval. The key concept is to leverage the alignment between output embeddings of text and image tokens acquired during multi-modal fine-tuning.
To this extent, we introduce ColPali, a Paligemma-3B extension that is capable of generating ColBERT-style multi-vector representations of text and images ( [Figure 1](https://arxiv.org/html/2407.01449v6#S1.F1 "Figure 1 ‣ 1 Introduction ‣ ColPali: Efficient Document Retrieval with Vision Language Models")).
PaliGemma-3B is a strong candidate due to its small size, the many released checkpoints fine-tuned for different image resolutions and tasks, and the promising performances on various document understanding benchmarks.
We add a projection layer to map each of the language model’s output token embeddings (whether from text or image tokens) to a vector space of reduced dimension D=128 as used in the ColBERT paper (Khattab & Zaharia, [2020](https://arxiv.org/html/2407.01449v6#bib.bib26 "")) to keep lightweight bag-of-embedding representations.

Late Interaction.
Given query q and document d, we denote as 𝐄𝐪∈ℝNq×D and 𝐄𝐝∈ℝNd×D their respective multi-vector representation in the common embedding space ℝD, where Nq and Nd are respectively the number of vectors in the query and in the document page embeddings. The late interaction operator, LI(q,d), is the sum over all query vectors 𝐄𝐪(i), of its maximum dot product ⟨⋅\|⋅⟩ with each of the Nd document embedding vectors 𝐄𝐝(1:Nd).

|     |     |     |     |
| --- | --- | --- | --- |
|  | LI(q,d)=∑i∈[1,Nq]maxj∈[1,Nd]⟨𝐄𝐪(i)\|𝐄𝐝(j)⟩ |  | (1) |

Contrastive Loss.
The Late Interaction operation is fully differentiable, enabling backpropagation.
Let a batch {qk,dk}k∈[1,b] composed of b query-page pairs, where for all k, the document page dk is the document corresponding to query qk.
Following Khattab & Zaharia ( [2020](https://arxiv.org/html/2407.01449v6#bib.bib26 "")), we define our in-batch contrastive loss ℒ as the softmaxed cross-entropy of the positive scores sk+ = LI(qk,dk) w.r.t. to the maximal in-batch negative scores sk− = maxl,l≠k LI(qk,dl).
We reformulate the loss to leverage the numerically stable softplus function where softplus(x)=log(1+exp(x)):

|     |     |     |     |
| --- | --- | --- | --- |
|  | ℒ=−1b∑k=1blog[exp(sk+) / (exp(sk+)+exp(sk−))] = 1b∑k=1blog(1+exp(sk−−sk+)) |  | (2) |

### 4.2 Model training

Dataset. Our training dataset of 118,695 query-page pairs is comprised of train sets of openly available academic datasets (63%) and a synthetic dataset made up of pages from web-crawled PDF documents and augmented with VLM-generated (Claude-3 Sonnet) pseudo-questions (37%). Dataset split details are given in [subsection A.3](https://arxiv.org/html/2407.01449v6#A1.SS3 "A.3 Training Dataset ‣ Appendix A Benchmark Datasets ‣ ColPali: Efficient Document Retrieval with Vision Language Models").
Our training set is fully English by design, enabling us to study zero-shot generalization to non-English languages. We explicitly verify no multi-page PDF document is used both ViDoRe and in the train set to prevent evaluation contamination. A validation set is created with 2% of the samples to tune hyperparameters. We openly release the training dataset888 [https://huggingface.co/datasets/vidore/colpali_train_set](https://huggingface.co/datasets/vidore/colpali_train_set "") for reproducibility and to encourage further research.

Parameters. All models are trained for 1 epoch on the train set. Unless specified otherwise, we train models in bfloat16 format, use low-rank adapters (LoRA, Hu et al. ( [2021](https://arxiv.org/html/2407.01449v6#bib.bib21 ""))) with α=32 and r=32 on the transformer layers from the language model, as well as the final randomly initialized projection layer, and use a paged_adamw_8bit optimizer. We train on an 8 GPU setup with data parallelism, a learning rate of 5e−5 with linear decay with 2.5% warmup steps, and a batch size of 32.

Query Augmentation. As in Khattab & Zaharia ( [2020](https://arxiv.org/html/2407.01449v6#bib.bib26 "")), we append 5 <unused0> tokens to the query tokens to serve as a soft, differentiable query expansion or re-weighting mechanism.

## 5 Results

|     |     |     |     |     |     |     |     |     |     |     |     |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | ArxivQ | DocQ | InfoQ | TabF | TATQ | Shift | AI | Energy | Gov. | Health. | Avg. |
| Unstructured text-only |  |  |  |  |  |  |  |  |  |  |  |
| \- BM25 | - | 34.1 | - | - | 44.0 | 59.6 | 90.4 | 78.3 | 78.8 | 82.6 | - |
| \- BGE-M3 | - | 28.4↓5.7 | - | - | 36.1↓7.9 | 68.5↑8.9 | 88.4↓2.0 | 76.8↓1.5 | 77.7↓1.1 | 84.6↑2.0 | - |
| Unstructured \+ OCR |  |  |  |  |  |  |  |  |  |  |  |
| \- BM25 | 31.6 | 36.8 | 62.9 | 46.5 | 62.7 | 64.3 | 92.8 | 85.9 | 83.9 | 87.2 | 65.5 |
| \- BGE-M3 | 31.4↓0.2 | 25.7↓11.1 | 60.1↓2.8 | 70.8↑24.3 | 50.5↓12.2 | 73.2↑8.9 | 90.2↓2.6 | 83.6↓2.3 | 84.9↑1.0 | 91.1↑3.9 | 66.1↑0.6 |
| Unstructured \+ Captioning |  |  |  |  |  |  |  |  |  |  |  |
| \- BM25 | 40.1 | 38.4 | 70.0 | 35.4 | 61.5 | 60.9 | 88.0 | 84.7 | 82.7 | 89.2 | 65.1 |
| \- BGE-M3 | 35.7↓4.4 | 32.9↓5.4 | 71.9↑1.9 | 69.1↑33.7 | 43.8↓17.7 | 73.1↑12.2 | 88.8↑0.8 | 83.3↓1.4 | 80.4↓2.3 | 91.3↑2.1 | 67.0↑1.9 |
| Contrastive VLMs |  |  |  |  |  |  |  |  |  |  |  |
| Jina-CLIP | 25.4 | 11.9 | 35.5 | 20.2 | 3.3 | 3.8 | 15.2 | 19.7 | 21.4 | 20.8 | 17.7 |
| Nomic-vision | 17.1 | 10.7 | 30.1 | 16.3 | 2.7 | 1.1 | 12.9 | 10.9 | 11.4 | 15.7 | 12.9 |
| SigLIP (Vanilla) | 43.2 | 30.3 | 64.1 | 58.1 | 26.2 | 18.7 | 62.5 | 65.7 | 66.1 | 79.1 | 51.4 |
| Ours |  |  |  |  |  |  |  |  |  |  |  |
| SigLIP (Vanilla) | 43.2 | 30.3 | 64.1 | 58.1 | 26.2 | 18.7 | 62.5 | 65.7 | 66.1 | 79.1 | 51.4 |
| BiSigLIP (+fine-tuning) | 58.5↑15.3 | 32.9↑2.6 | 70.5↑6.4 | 62.7↑4.6 | 30.5↑4.3 | 26.5↑7.8 | 74.3↑11.8 | 73.7↑8.0 | 74.2↑8.1 | 82.3↑3.2 | 58.6↑7.2 |
| BiPali (+LLM) | 56.5↓-2.0 | 30.0↓-2.9 | 67.4↓-3.1 | 76.9↑14.2 | 33.4↑2.9 | 43.7↑17.2 | 71.2↓-3.1 | 61.9↓-11.7 | 73.8↓-0.4 | 73.6↓-8.8 | 58.8↑0.2 |
| ColPali (+Late Inter.) | 79.1↑22.6 | 54.4↑24.5 | 81.8↑14.4 | 83.9↑7.0 | 65.8↑32.4 | 73.2↑29.5 | 96.2↑25.0 | 91.0↑29.1 | 92.7↑18.9 | 94.4↑20.8 | 81.3↑22.5 |

Table 2: Comprehensive evaluation of baseline models and our proposed method on ViDoRe. Results are presented using nDCG@5 metrics, and illustrate the impact of different components. Text-only metrics are not computed for benchmarks with only visual elements.

### 5.1 Performance (R1)

We show performance is achieved iteratively through the combination of three factors; (1) a carefully crafted task-specific dataset, (2) pairing a pretrained LLM to a vision model to better leverage text semantics from the image, and (3) using multi-vector embeddings rather than a single vector representation to better capture the vast amount of visual information present in a document.

Fine-tuning a Vision Model on a document retrieval oriented dataset: BiSigLIP. SigLIP999 [https://huggingface.co/google/siglip-so400m-patch14-384](https://huggingface.co/google/siglip-so400m-patch14-384 "") is a strong vision-language bi-encoder producing single vector embeddings, and pretrained on billions of image-text pairs from the English split of WebLI (Chen et al., [2023](https://arxiv.org/html/2407.01449v6#bib.bib11 "")). Further fine-tuning the textual component of this model on our document-oriented dataset (BiSigLIP) yields clear improvements across the board, particularly on figure retrieval (ArxivQA) and table retrieval tasks (TabFQuAD).

Feeding image patches to a LLM: BiPali. In the PaliGemma model architecture, SigLIP-generated patch embeddings are fed to a text language model and we can obtain LLM contextualized output patch embeddings. Note that the SigLIP model used in PaliGemma slightly differs in terms of number patches - 1024 patches for PaliGemma’s vision encoder, and 729 for the standalone SigLIP model. This technique aligns the image token representations with the text token embeddings in the LLM’s embeddings space, and augments the vision model embeddings with the language model’s text understanding capabilities. We average pool these representations to obtain a single dense vector, effectively creating a PaliGemma bi-encoder model (BiPali). After fine-tuning on the training dataset, we obtain a model that performs slightly worse in English than the tuned BiSigLIP variant. This can be explained by the fact that contrary to SigLIP, the original PaliGemma is not trained on contrastive matching tasks, but rather on next token prediction. Our contrastive fine-tuning phase on 119K images to transform PaliGemma into a bi-encoder is 5 orders of magnitude smaller than SigLIP’s original contrastive training. However, we see notable improvements in French tasks, indicating that BiPali’s LLM (Gemma 2B) helps multilingual text understanding. This is particularly notable as our training dataset does not contain non-English samples.

Leveraging Multi-Vector Embeddings through Late Interaction: ColPali.
One benefit of inputting image patch embeddings through a language model is that they are natively mapped to a latent space similar to the textual input (query). This enables leveraging the ColBERT strategy to construct one embedding per image patch token, and at inference compute all interactions between text tokens and image patches, resulting in a step-change improvement in performance compared to BiPali.
Results in [Table 2](https://arxiv.org/html/2407.01449v6#S5.T2 "Table 2 ‣ 5 Results ‣ ColPali: Efficient Document Retrieval with Vision Language Models") show that our ColPali model also largely outperforms the strong baselines based on Unstructured and captioning, as well as all evaluated text-image embedding models. The difference is particularly stark on the more visually complex benchmark tasks, such as InfographicVQA, ArxivQA, and TabFQuAD, respectively representing infographics, figures, and tables. However, text-centric documents are also better retrieved by the ColPali models across all evaluated domains and languages, making our approach the overall best-performing document-retrieval model.

Negative Results. For extensiveness, we also train ColSigLIP, a late interaction variant of the BiSigLIP model but obtain abysmal performances. We attribute this to the large gaps w.r.t. SigLIP’s pre-training, in which only a pooled latent representation is used in the contrastive loss, which does not optimize the representations of individual patch and token embeddings. Similarly, we train a BiSigLIPPaliGemma variant, in which we retrieve the image representations from the SigLIP model that has been further updated by PaliGemma fine-tuning, and use the text representations from PaliGemma’s text model. After fine-tuning on our dataset, performance is severely inferior to SigLIPVanilla which simply encodes with SigLIP’s original text and vision components. This indicates a logical misalignment between SigLIP embeddings, and Gemma embeddings after PaliGemma training. We detail these results in [subsection C.1](https://arxiv.org/html/2407.01449v6#A3.SS1 "C.1 Other Metrics ‣ Appendix C Additional results ‣ ColPali: Efficient Document Retrieval with Vision Language Models").

### 5.2 Latencies & Memory Footprint

Online Querying. (R2) Logically, querying latencies differ between ColPali and a BGE-M3 embedding model. For BGE, encoding takes about 22 ms for 15 tokens, while encoding a query with ColPali’s language model takes about 30 ms (Computed for a batch size of 1 (online), and averaged over 1000 queries. See [subsection B.4](https://arxiv.org/html/2407.01449v6#A2.SS4 "B.4 Latency computations ‣ Appendix B Implementation details ‣ ColPali: Efficient Document Retrieval with Vision Language Models")). For smaller corpus sizes, computing the late interaction operation induces marginally small overheads (≈1 ms per 1000 pages in the corpus), and the cosine similarity computation between bi-encoder vectors is even faster. Optimized late interaction engines (Santhanam et al., [2022](https://arxiv.org/html/2407.01449v6#bib.bib46 ""); Lee et al., [2023](https://arxiv.org/html/2407.01449v6#bib.bib32 "")) enable to easily scale corpus sizes to millions of documents with reduced latency degradations.

Offline Indexing. (R3)
Standard retrieval methods using bi-encoders represent each chunk as a single vector embedding, which is easy to store and fast to compute. However, processing a PDF to get the different chunks is the most time-consuming part (layout detection, OCR, chunking), and using captioning to handle multimodal data will only exacerbate this already lengthy process. On the other hand, ColPali directly encodes pages from their image representation. Although the model is larger than standard retrieval encoders, skipping the preprocessing allows large speedups at indexing (Measures a NVIDIA L4 GPU, averaged on 100 pages, with a batch size of 4 pages for ColPali and 8 text chunks for Bi-Encoders. On average, a page is divided into 2.1 chunks. See [subsection B.4](https://arxiv.org/html/2407.01449v6#A2.SS4 "B.4 Latency computations ‣ Appendix B Implementation details ‣ ColPali: Efficient Document Retrieval with Vision Language Models")). As pages are embedded end-to-end in single forward pass, the VRAM usage depends exclusively on the sequence length (number of patches per image) which is fixed as well, enabling efficient batching strategies to fully leverage hardware acceleration. ColPali also benefits from most LLM efficiency improvements introduced in the ecosystem such as Flash Attention (Dao, [2023](https://arxiv.org/html/2407.01449v6#bib.bib14 "")).

Storage Footprint. Our method requires storing a vector per image patch, along with 6 extra text tokens “Describe the image” concatenated to image patches. We project each PaliGemma vector to a lower dimensional space (D=128) to maximize efficiency, leading to a memory footprint of 257.5 KB per page ( [subsection B.3](https://arxiv.org/html/2407.01449v6#A2.SS3 "B.3 Embedding size ‣ Appendix B Implementation details ‣ ColPali: Efficient Document Retrieval with Vision Language Models")). Importantly, the memory footprint of the naive ColBERT indexing strategy can be drastically improved through compression and clustering mechanisms (Santhanam et al., [2022](https://arxiv.org/html/2407.01449v6#bib.bib46 ""); Clavié et al., [2024](https://arxiv.org/html/2407.01449v6#bib.bib12 "")).

Token pooling.
Token pooling (Clavié et al., [2024](https://arxiv.org/html/2407.01449v6#bib.bib12 "")) is a CRUDE-compliant method (document addition/deletion-friendly) that aims to reduce the amount of multi-vector embeddings. For ColPali, many image patches share redundant information, e.g. white background patches. By pooling these patches together, we can reduce the amount of embeddings while retaining most information. Retrieval performance with hierarchical mean token pooling on image embeddings is shown in [Figure 3](https://arxiv.org/html/2407.01449v6#S5.F3 "Figure 3 ‣ 5.3 Interpretability ‣ 5 Results ‣ ColPali: Efficient Document Retrieval with Vision Language Models") (left).
With a pool factor of 3, the total number of vectors is reduced by 66.7% while 97.8% of the original performance is maintained. We note that the Shift dataset—composed of the most text-dense documents—is a clear outlier, showcasing more information dense documents contain less redundant patches and may be prone to worse performance degradation with such pooling techniques.

### 5.3 Interpretability

https://arxiv.org/html/2407.01449v6/x2.png

https://arxiv.org/html/2407.01449v6/extracted/6240861/images/similarity_map_energy.png

Figure 3: (Left: Token Pooling) Relative performance degradation when reducing the number of stored embeddings per document. (Right: Interpretability) For each term in a user query, ColPali identifies the most relevant document image patches (highlighted zones) and computes a query-to-page matching score.

By superimposing the late interaction heatmap on top of the original image, we can visualize the most salient image patches with respect to each term of the query, yielding interpretable insights into model focus zones. As epitomized in [Figure 3](https://arxiv.org/html/2407.01449v6#S5.F3 "Figure 3 ‣ 5.3 Interpretability ‣ 5 Results ‣ ColPali: Efficient Document Retrieval with Vision Language Models") (right), we observe ColPali exhibits strong OCR capabilities as both the words “hourly” and “hours” present a high similarity score with the query token <_hour>. We also note particular focus on other non-trivial image features such as the x-axis representing hours being salient. Other visualization examples are shown in [Appendix D](https://arxiv.org/html/2407.01449v6#A4 "Appendix D More similarity maps ‣ ColPali: Efficient Document Retrieval with Vision Language Models").

## 6 Ablation study

We run various ablations to better understand the mechanisms at play. By default, result deltas reported below refer to nDCG@5 values averaged over all ViDoRe tasks. Detailed results in [C.2](https://arxiv.org/html/2407.01449v6#A3.SS2 "C.2 Model Variants ‣ Appendix C Additional results ‣ ColPali: Efficient Document Retrieval with Vision Language Models").

Tradeoffs between model size and the number of image patches. We train a variant of PaliGemma with half the number of image patches (512). While we observe a clear performance degradation with respects to to the 1024-patch ColPali model (−24.8 nDCG@5), memory usage is much lower.
As an alternative to PaliGemma, we train Idefics2-8B (Laurençon et al., [2024b](https://arxiv.org/html/2407.01449v6#bib.bib30 "")), a VLM with a similar architecture and based on a Mistral-7B (Jiang et al., [2023](https://arxiv.org/html/2407.01449v6#bib.bib23 "")) language backbone and a SigLIP vision encoder paired with a perceiver resampler. The most notable differences with PaliGemma lie in the size of the language model (2B and 7B resp.) and the number of image patches (between 512 and 2048 for PaliGemma, and 64 post-resampling for Idefics2 with the option of adding 4 sub-image crops of 64 tokens each to the sequence, for a total of 320 tokens). Our results suggest better language models enable more efficient representations of image embeddings - ColIdefics2 with 64 patches largely outperforms ColPali with 512 patches (+20.1 nDCG@5). However ColIdefics2 (64) remains less accurate than ColPali (1024) (−4.7 nDCG@5) while being about twice as slow in terms of training and inference latency.
These results suggest there are tradeoffs between performance (R1), latencies during online querying (R2) and offline indexation phases (R3), and index memory size.

Unfreezing the vision component. We train a ColPali variant by also backpropagating through and updating the vision encoder and the projection layer. This leads to a slight performance degradation (−0.7 nDCG@5). These conclusions may change with larger scales of training data.

Impact of “query augmentation” tokens. In ColBERT, special tokens are concatenated to the input query to serve as soft query augmentation buffers. Training without these tokens, we observe no significant performance difference in the English benchmarks. However, performance on the French tasks seems to improve (+9.8 nDCG@5 on Shift, +6.3 nDCG@5 on TabFQuAD, [Table 7](https://arxiv.org/html/2407.01449v6#A3.T7 "Table 7 ‣ C.2 Model Variants ‣ Appendix C Additional results ‣ ColPali: Efficient Document Retrieval with Vision Language Models")).

Impact of the Pairwise CE loss. Training with an in-batch negative contrastive loss, instead of the pairwise CE loss that only considers the hardest negative sample, leads to a slight performance degradation (−1.6 nDCG@5) on the aggregated benchmark.

Adapting models to new tasks. Contrary to more complex multi-step retrieval pipelines, ColPali can be trained end-to-end, directly optimizing the downstream retrieval task which greatly facilitates fine-tuning to boost performance on specialized domains, multilingual retrieval, or specific visual elements the model struggles with. To demonstrate, we add 1552 samples representing French tables and associated queries to the training set. This represents the only French data in the training set, with all other examples being kept unchanged. We see clear nDCG@5 improvements (+2.6) and even starker Recall@1 gains (+5) on the TabFQuAD benchmark, with no performance degradation on the rest of the benchmark tasks (+0.4 nDCG@5 overall).

Better VLMs lead to better visual retrievers. As improved VLMs are released, it is interesting to observe if improved performances on generative tasks translate once these models are adapted for image retrieval tasks through ColPali training strategies. We train the recently released Qwen2-VL 2B (Wang et al., [2024b](https://arxiv.org/html/2407.01449v6#bib.bib54 "")), a SOTA 2 billion parameter generative VLM, with the same data and training strategy, obtaining ColQwen2-VL. To approximately match ColPali’s memory requirements, we limit the number of image patches to 768, slightly less than ColPali’s 1024 patches. We observe clear performance improvements of +5.3 nDCG@5 values over ColPali showcasing clear performance correlations between generative benchmarks performance and retrieving metrics.

Out-of-domain generalization. Some of the datasets in the ViDoRe benchmark have train sets, which we have integrated within the ColPali train set (eg. academic tasks). This is standard in embedding models (Wang et al., [2024a](https://arxiv.org/html/2407.01449v6#bib.bib53 ""); Lee et al., [2024](https://arxiv.org/html/2407.01449v6#bib.bib31 "")), and while ColPali also exhibits strong performance on tasks in which this is not the case (French data is never seen by the model during training for instance), it remains interesting to evaluate model performance when training is done on a fully disjoint data distribution. We train a ColPali variant solely using the recent DocMatix dataset (Laurençon et al., [2024a](https://arxiv.org/html/2407.01449v6#bib.bib29 "")), a large scale, synthetically annotated visual document question answering dataset, which we subsample to obtain a comparably-sized train set. Results on ViDoRe show the performance drop is minor (−2.2 nDCG@5), still outperforming the closest baseline method by over 12 points. These results showcase ColPali generalizes well outside of its training distribution, and demonstrate that our results are not unreasonably boosted with respect to baselines (BGE-M3) that cannot be fine-tuned on the same data. To train with data resembling the one BGE-M3 models would see at inference time would require running complex extraction pipelines for the more than 100K documents in the training set, notably relying on external proprietary captioning models which is both too costly and lengthy. This is not needed to train vision-based models.

## 7 Conclusions

In this work, we introduced the Visual Document Retrieval Benchmark (ViDoRe), which evaluates document retrieval systems in realistic settings involving visually complex documents. We demonstrated that current retrieval pipelines and contrastive vision-language models struggle to efficiently exploit visual information embedded in documents, leading to suboptimal performance. To address this, we presented ColPali, a novel retrieval method that leverages Vision-Language Models to create high-quality, multi-vector embeddings purely from visual document features. ColPali largely outperforms the best existing document retrieval methods while enabling faster corpus indexing times and maintaining low querying latencies, thus circumventing many pain points of modern document retrieval applications. We hope to drive industrial adoption, and to encourage future work by publicly releasing the ViDoRe benchmark, the data, the codebase, and all models and baselines from our work.

Future Work.
Beyond performance improvements that could be obtained through better data, backbone models or training strategies, our vision at term is to combine visual retrieval systems and visually grounded query answering to create end-to-end RAG systems that purely function from image features. This idea is supported by concurrent work (Ma et al., [2024](https://arxiv.org/html/2407.01449v6#bib.bib37 "")) showcasing the strong promises of VLMs for visual QA, and may eventually become a new industrial standard for document processing. In this line of work, reliability is key, and confidence estimation techniques for Information Retrieval methods could become central to implement abstention mechanisms (Gisserot-Boukhlef et al., [2024](https://arxiv.org/html/2407.01449v6#bib.bib20 "")), and are particularly interesting given the information rich multi-vector scoring mechanisms of late interaction systems.
Expanding benchmarking efforts to cover more languages, modalities, and tasks is also a crucial future research direction (Jiang et al., [2024](https://arxiv.org/html/2407.01449v6#bib.bib24 "")).

## Reproducibility Statement

For transparency, reproducibility and to foster future work, we release our training data, model checkpoints (adapters), entire codebase, and complete evaluation benchmark under MIT licenses as detailed in the main paper. We also host a public ViDoRe leaderboard [https://huggingface.co/spaces/vidore/vidore-leaderboard](https://huggingface.co/spaces/vidore/vidore-leaderboard "") to foster concurrent work in the space. The supplementary material further details training configurations for our models (also specified in HuggingFace model repositories), and dives into the process we used to generate synthetic data, how latency computations are performed, as well as provides further detailed evaluation results.

## Acknowledgements

This work is partially supported by Illuin Technology, and by a grant from ANRT France. This work was performed using HPC resources from the CINES ADASTRA through Grant 2024-AD011015443 and from IDRIS with grant 2024-AD011015724R1.
We extend our warm thanks to Jonathan Dong, Caio Corro, Victor Pellegrain and Ender Konukoglu for their valuable feedback on the paper.

## References

- Alabdulmohsin et al. (2023)  
Ibrahim Alabdulmohsin, Xiaohua Zhai, Alexander Kolesnikov, and Lucas Beyer.  
Getting ViT in Shape: Scaling Laws for Compute-Optimal Model Design. 2023. doi: 10.48550/ARXIV.2305.13035. URL [https://arxiv.org/abs/2305.13035](https://arxiv.org/abs/2305.13035 ""). Publisher: arXiv Version Number: 5.

- Alayrac et al. (2022)  
Jean-Baptiste Alayrac, Jeff Donahue, Pauline Luc, Antoine Miech, Iain Barr, Yana Hasson, Karel Lenc, Arthur Mensch, Katie Millican, Malcolm Reynolds, Roman Ring, Eliza Rutherford, Serkan Cabi, Tengda Han, Zhitao Gong, Sina Samangooei, Marianne Monteiro, Jacob Menick, Sebastian Borgeaud, Andrew Brock, Aida Nematzadeh, Sahand Sharifzadeh, Mikolaj Binkowski, Ricardo Barreira, Oriol Vinyals, Andrew Zisserman, and Karen Simonyan.  
Flamingo: a Visual Language Model for Few-Shot Learning. 2022. doi: 10.48550/ARXIV.2204.14198. URL [https://arxiv.org/abs/2204.14198](https://arxiv.org/abs/2204.14198 ""). Publisher: arXiv Version Number: 2.

- Anthropic (2024)  
Anthropic.  
The Claude 3 Model Family: Opus, Sonnet, Haiku, 2024.  
URL [https://www-cdn.anthropic.com/de8ba9b01c9ab7cbabf5c33b80b7bbc618857627/Model\_Card\_Claude\_3.pdf](https://www-cdn.anthropic.com/de8ba9b01c9ab7cbabf5c33b80b7bbc618857627/Model_Card_Claude_3.pdf "").

- Appalaraju et al. (2021)  
Srikar Appalaraju, Bhavan Jasani, Bhargava Urala Kota, Yusheng Xie, and R. Manmatha.  
DocFormer: End-to-End Transformer for Document Understanding, 2021.  
URL [https://arxiv.org/abs/2106.11539](https://arxiv.org/abs/2106.11539 ""). Version Number: 2.

- Bai et al. (2023)  
Jinze Bai, Shuai Bai, Shusheng Yang, Shijie Wang, Sinan Tan, Peng Wang, Junyang Lin, Chang Zhou, and Jingren Zhou.  
Qwen-VL: A Versatile Vision-Language Model for Understanding, Localization, Text Reading, and Beyond. 2023. doi: 10.48550/ARXIV.2308.12966. URL [https://arxiv.org/abs/2308.12966](https://arxiv.org/abs/2308.12966 ""). Publisher: arXiv Version Number: 3.

- Bajaj et al. (2016)  
Payal Bajaj, Daniel Campos, Nick Craswell, Li Deng, Jianfeng Gao, Xiaodong Liu, Rangan Majumder, Andrew McNamara, Bhaskar Mitra, Tri Nguyen, Mir Rosenberg, Xia Song, Alina Stoica, Saurabh Tiwary, and Tong Wang.  
MS MARCO: A Human Generated MAchine Reading COmprehension Dataset, 2016.  
URL [https://arxiv.org/abs/1611.09268](https://arxiv.org/abs/1611.09268 ""). Version Number: 3.

- Beyer et al. (2024)  
Lucas Beyer, Andreas Steiner, André Susano Pinto, Alexander Kolesnikov, Xiao Wang, Daniel Salz, Maxim Neumann, Ibrahim Alabdulmohsin, Michael Tschannen, Emanuele Bugliarello, Thomas Unterthiner, Daniel Keysers, Skanda Koppula, Fangyu Liu, Adam Grycner, Alexey Gritsenko, Neil Houlsby, Manoj Kumar, Keran Rong, Julian Eisenschlos, Rishabh Kabra, Matthias Bauer, Matko Bošnjak, Xi Chen, Matthias Minderer, Paul Voigtlaender, Ioana Bica, Ivana Balazevic, Joan Puigcerver, Pinelopi Papalampidi, Olivier Henaff, Xi Xiong, Radu Soricut, Model release contributors and general support, and others.  
Paligemma: a versatile 3b vlm for transfer, 2024. URL [https://arxiv.org/abs/2407.07726](https://arxiv.org/abs/2407.07726 "").

- Bloom (1970)  
Burton H. Bloom.  
Space/time trade-offs in hash coding with allowable errors. _Commun. ACM_, 13(7):422–426, July 1970. doi: 10.1145/362686.362692. URL [https://doi.org/10.1145/362686.362692](https://doi.org/10.1145/362686.362692 ""). Place: New York, NY, USA Publisher: Association for Computing Machinery.

- Borchmann et al. (2021)  
Łukasz Borchmann, Michał Pietruszka, Tomasz Stanislawek, Dawid Jurkiewicz, Michał Turski, Karolina Szyndler, and Filip Graliński.  
DUE: End-to-End Document Understanding Benchmark. In _Thirty-fifth Conference on Neural Information Processing Systems Datasets and Benchmarks Track (Round 2)_, 2021. URL [https://openreview.net/forum?id=rNs2FvJGDK](https://openreview.net/forum?id=rNs2FvJGDK "").

- Chen et al. (2024)  
Jianlv Chen, Shitao Xiao, Peitian Zhang, Kun Luo, Defu Lian, and Zheng Liu.  
BGE M3-Embedding: Multi-Lingual, Multi-Functionality, Multi-Granularity Text Embeddings Through Self-Knowledge Distillation, 2024. URL [https://arxiv.org/abs/2402.03216](https://arxiv.org/abs/2402.03216 ""). Version Number: 3.

- Chen et al. (2023)  
Xi Chen, Xiao Wang, Lucas Beyer, Alexander Kolesnikov, Jialin Wu, Paul Voigtlaender, Basil Mustafa, Sebastian Goodman, Ibrahim Alabdulmohsin, Piotr Padlewski, Daniel Salz, Xi Xiong, Daniel Vlasic, Filip Pavetic, Keran Rong, Tianli Yu, Daniel Keysers, Xiaohua Zhai, and Radu Soricut.  
PaLI-3 Vision Language Models: Smaller, Faster, Stronger, 2023. URL [https://arxiv.org/abs/2310.09199](https://arxiv.org/abs/2310.09199 ""). Version Number: 2.

- Clavié et al. (2024)  
Benjamin Clavié, Antoine Chaffin, and Griffin Adams.  
Reducing the Footprint of Multi-Vector Retrieval with Minimal Performance Impact via Token Pooling, 2024. URL [https://arxiv.org/abs/2409.14683](https://arxiv.org/abs/2409.14683 ""). Version Number: 1.

- Cohere (2024)  
Cohere.  
Introducing Rerank 3: A New Foundation Model for Efficient Enterprise Search & Retrieval, April 2024. URL [https://cohere.com/blog/rerank-3](https://cohere.com/blog/rerank-3 "").

- Dao (2023)  
Tri Dao.  
Flashattention-2: Faster attention with better parallelism and work partitioning, 2023. URL [https://arxiv.org/abs/2307.08691](https://arxiv.org/abs/2307.08691 "").

- Darcet et al. (2023)  
Timothée Darcet, Maxime Oquab, Julien Mairal, and Piotr Bojanowski.  
Vision Transformers Need Registers. 2023. doi: 10.48550/ARXIV.2309.16588. URL [https://arxiv.org/abs/2309.16588](https://arxiv.org/abs/2309.16588 "").

- Devlin et al. (2018)  
Jacob Devlin, Ming-Wei Chang, Kenton Lee, and Kristina Toutanova.  
BERT: Pre-training of Deep Bidirectional Transformers for Language Understanding, 2018. URL [https://arxiv.org/abs/1810.04805](https://arxiv.org/abs/1810.04805 ""). Version Number: 2.

- Dosovitskiy et al. (2020)  
Alexey Dosovitskiy, Lucas Beyer, Alexander Kolesnikov, Dirk Weissenborn, Xiaohua Zhai, Thomas Unterthiner, Mostafa Dehghani, Matthias Minderer, Georg Heigold, Sylvain Gelly, Jakob Uszkoreit, and Neil Houlsby.  
An Image is Worth 16x16 Words: Transformers for Image Recognition at Scale. 2020. doi: 10.48550/ARXIV.2010.11929. URL [https://arxiv.org/abs/2010.11929](https://arxiv.org/abs/2010.11929 ""). Publisher: arXiv Version Number: 2.

- Ge et al. (2021)  
Zheng Ge, Songtao Liu, Feng Wang, Zeming Li, and Jian Sun.  
YOLOX: Exceeding YOLO Series in 2021, 2021. URL [https://arxiv.org/abs/2107.08430](https://arxiv.org/abs/2107.08430 ""). Version Number: 2.

- Gemma Team et al. (2024)  
Gemma Team, Thomas Mesnard, Cassidy Hardin, Robert Dadashi, Surya Bhupatiraju, Shreya Pathak, Laurent Sifre, Morgane Rivière, Mihir Sanjay Kale, Juliette Love, Pouya Tafti, Léonard Hussenot, Pier Giuseppe Sessa, Aakanksha Chowdhery, Adam Roberts, Aditya Barua, Alex Botev, Alex Castro-Ros, Ambrose Slone, Amélie Héliou, Andrea Tacchetti, Anna Bulanova, Antonia Paterson, Beth Tsai, Bobak Shahriari, Charline Le Lan, Christopher A. Choquette-Choo, Clément Crepy, Daniel Cer, Daphne Ippolito, David Reid, Elena Buchatskaya, Eric Ni, Eric Noland, Geng Yan, George Tucker, George-Christian Muraru, Grigory Rozhdestvenskiy, Henryk Michalewski, Ian Tenney, Ivan Grishchenko, Jacob Austin, James Keeling, Jane Labanowski, Jean-Baptiste Lespiau, Jeff Stanway, Jenny Brennan, Jeremy Chen, Johan Ferret, Justin Chiu, Justin Mao-Jones, Katherine Lee, Kathy Yu, Katie Millican, Lars Lowe Sjoesund, Lisa Lee, Lucas Dixon, Machel Reid, Maciej Mikuła, Mateo Wirth, Michael Sharman, Nikolai Chinaev, Nithum Thain, Olivier Bachem, Oscar Chang, Oscar Wahltinez, Paige Bailey, Paul Michel, Petko Yotov, Rahma Chaabouni, Ramona Comanescu, Reena Jana, Rohan Anil, Ross McIlroy, Ruibo Liu, Ryan Mullins, Samuel L Smith, Sebastian Borgeaud, Sertan Girgin, Sholto Douglas, Shree Pandya, Siamak Shakeri, Soham De, Ted Klimenko, Tom Hennigan, Vlad Feinberg, Wojciech Stokowiec, Yu-hui Chen, Zafarali Ahmed, Zhitao Gong, Tris Warkentin, Ludovic Peran, Minh Giang, Clément Farabet, Oriol Vinyals, Jeff Dean, Koray Kavukcuoglu, Demis Hassabis, Zoubin Ghahramani, Douglas Eck, Joelle Barral, Fernando Pereira, Eli Collins, Armand Joulin, Noah Fiedel, Evan Senter, Alek Andreev, and Kathleen Kenealy.  
Gemma: Open Models Based on Gemini Research and Technology, 2024. URL [https://arxiv.org/abs/2403.08295](https://arxiv.org/abs/2403.08295 ""). Version Number: 4.

- Gisserot-Boukhlef et al. (2024)  
Hippolyte Gisserot-Boukhlef, Manuel Faysse, Emmanuel Malherbe, Céline Hudelot, and Pierre Colombo.  
Towards trustworthy reranking: A simple yet effective abstention mechanism, 2024. URL [https://arxiv.org/abs/2402.12997](https://arxiv.org/abs/2402.12997 "").

- Hu et al. (2021)  
Edward J. Hu, Yelong Shen, Phillip Wallis, Zeyuan Allen-Zhu, Yuanzhi Li, Shean Wang, Lu Wang, and Weizhu Chen.  
LoRA: Low-Rank Adaptation of Large Language Models. 2021. doi: 10.48550/ARXIV.2106.09685. URL [https://arxiv.org/abs/2106.09685](https://arxiv.org/abs/2106.09685 ""). Publisher: arXiv Version Number: 2.

- Huang et al. (2022)  
Yupan Huang, Tengchao Lv, Lei Cui, Yutong Lu, and Furu Wei.  
LayoutLMv3: Pre-training for Document AI with Unified Text and Image Masking. 2022. doi: 10.48550/ARXIV.2204.08387. URL [https://arxiv.org/abs/2204.08387](https://arxiv.org/abs/2204.08387 ""). Publisher: arXiv Version Number: 3.

- Jiang et al. (2023)  
Albert Q. Jiang, Alexandre Sablayrolles, Arthur Mensch, Chris Bamford, Devendra Singh Chaplot, Diego de las Casas, Florian Bressand, Gianna Lengyel, Guillaume Lample, Lucile Saulnier, Lélio Renard Lavaud, Marie-Anne Lachaux, Pierre Stock, Teven Le Scao, Thibaut Lavril, Thomas Wang, Timothée Lacroix, and William El Sayed.  
Mistral 7B. 2023. doi: 10.48550/ARXIV.2310.06825. URL [https://arxiv.org/abs/2310.06825](https://arxiv.org/abs/2310.06825 ""). Publisher: arXiv Version Number: 1.

- Jiang et al. (2024)  
Ziyan Jiang, Rui Meng, Xinyi Yang, Semih Yavuz, Yingbo Zhou, and Wenhu Chen.  
Vlm2vec: Training vision-language models for massive multimodal embedding tasks, 2024. URL [https://arxiv.org/abs/2410.05160](https://arxiv.org/abs/2410.05160 "").

- Karpukhin et al. (2020)  
Vladimir Karpukhin, Barlas Oğuz, Sewon Min, Patrick Lewis, Ledell Wu, Sergey Edunov, Danqi Chen, and Wen-tau Yih.  
Dense Passage Retrieval for Open-Domain Question Answering, 2020. URL [https://arxiv.org/abs/2004.04906](https://arxiv.org/abs/2004.04906 ""). Version Number: 3.

- Khattab & Zaharia (2020)  
Omar Khattab and Matei Zaharia.  
ColBERT: Efficient and Effective Passage Search via Contextualized Late Interaction over BERT. 2020. doi: 10.48550/ARXIV.2004.12832. URL [https://arxiv.org/abs/2004.12832](https://arxiv.org/abs/2004.12832 "").

- Kim et al. (2021)  
Geewook Kim, Teakgyu Hong, Moonbin Yim, Jeongyeon Nam, Jinyoung Park, Jinyeong Yim, Wonseok Hwang, Sangdoo Yun, Dongyoon Han, and Seunghyun Park.  
OCR-free Document Understanding Transformer, 2021. URL [https://arxiv.org/abs/2111.15664](https://arxiv.org/abs/2111.15664 ""). Version Number: 5.

- Koukounas et al. (2024)  
Andreas Koukounas, Georgios Mastrapas, Michael Günther, Bo Wang, Scott Martens, Isabelle Mohr, Saba Sturua, Mohammad Kalim Akram, Joan Fontanals Martínez, Saahil Ognawala, Susana Guzman, Maximilian Werk, Nan Wang, and Han Xiao.  
Jina CLIP: Your CLIP Model Is Also Your Text Retriever, 2024. URL [https://arxiv.org/abs/2405.20204](https://arxiv.org/abs/2405.20204 ""). Version Number: 1.

- Laurençon et al. (2024a)  
Hugo Laurençon, Andrés Marafioti, Victor Sanh, and Léo Tronchon.  
Building and better understanding vision-language models: insights and future directions., 2024a.

- Laurençon et al. (2024b)  
Hugo Laurençon, Léo Tronchon, Matthieu Cord, and Victor Sanh.  
What matters when building vision-language models?, May 2024b. URL [http://arxiv.org/abs/2405.02246](http://arxiv.org/abs/2405.02246 ""). arXiv:2405.02246 \[cs\].

- Lee et al. (2024)  
Chankyu Lee, Rajarshi Roy, Mengyao Xu, Jonathan Raiman, Mohammad Shoeybi, Bryan Catanzaro, and Wei Ping.  
Nv-embed: Improved techniques for training llms as generalist embedding models, 2024. URL [https://arxiv.org/abs/2405.17428](https://arxiv.org/abs/2405.17428 "").

- Lee et al. (2023)  
Jinhyuk Lee, Zhuyun Dai, Sai Meher Karthik Duddu, Tao Lei, Iftekhar Naim, Ming-Wei Chang, and Vincent Y. Zhao.  
Rethinking the Role of Token Retrieval in Multi-Vector Retrieval, 2023. URL [https://arxiv.org/abs/2304.01982](https://arxiv.org/abs/2304.01982 ""). Version Number: 3.

- Li et al. (2024)  
Lei Li, Yuqi Wang, Runxin Xu, Peiyi Wang, Xiachong Feng, Lingpeng Kong, and Qi Liu.  
Multimodal arxiv: A dataset for improving scientific comprehension of large vision-language models, 2024.

- Lin et al. (2014)  
Tsung-Yi Lin, Michael Maire, Serge Belongie, Lubomir Bourdev, Ross Girshick, James Hays, Pietro Perona, Deva Ramanan, C. Lawrence Zitnick, and Piotr Dollár.  
Microsoft COCO: Common Objects in Context, 2014. URL [https://arxiv.org/abs/1405.0312](https://arxiv.org/abs/1405.0312 ""). Version Number: 3.

- Liu et al. (2023)  
Haotian Liu, Chunyuan Li, Qingyang Wu, and Yong Jae Lee.  
Visual Instruction Tuning. 2023. doi: 10.48550/ARXIV.2304.08485. URL [https://arxiv.org/abs/2304.08485](https://arxiv.org/abs/2304.08485 ""). Publisher: arXiv Version Number: 1.

- Lucas Beyer\* et al. (2024)  
Lucas Beyer\*, Andreas Steiner\*, André Susano Pinto\*, Alexander Kolesnikov\*, Xiao Wang\*, Xiaohua Zhai\*, Daniel Salz, Maxim Neumann, Ibrahim Alabdulmohsin, Michael Tschannen, Jeremiah Harmsen, Daniel Keysers, Neil Houlsby, Xi Chen, Emanuele Bugliarello, Thomas Unterthiner, Keran Rong, Matthias Minderer, Ioana Bica, Ivana Balazevic, Joan Puigcerver, Pinelopi Papalampidi, Olivier Henaff, Skanda Koppula, Xi Xiong, Radu Soricut, Model release contributors and general support, Tris Warkentin, Kat Black, Luiz Gustavo Martins, Glenn Cameron, Raj Gundluru, Manvinder Singh, Meg Risdal, Nilay Chauhan, Nate Keating, Nesh Devanathan, Elisa Bandy, Joe Fernandez, Antonia Paterson, Jenny Brennan, Tom Eccles, Pankil Botadra, Ben Bariach, Lav Rai, Minwoo Park, Dustin Luong, Daniel Vlasic, Bo Wu, Wenming Ye, Divyashree Sreepathihalli, Kiranbir Sodhia, Alek Andreev, Armand Joulin, Surya Bhupatiraju, Minh Giang, Joelle Barral, and Zoubin Ghahramani.  
PaliGemma, 2024. URL [https://www.kaggle.com/m/23393](https://www.kaggle.com/m/23393 "").

- Ma et al. (2024)  
Yubo Ma, Yuhang Zang, Liangyu Chen, Meiqi Chen, Yizhu Jiao, Xinze Li, Xinyuan Lu, Ziyu Liu, Yan Ma, Xiaoyi Dong, Pan Zhang, Liangming Pan, Yu-Gang Jiang, Jiaqi Wang, Yixin Cao, and Aixin Sun.  
Mmlongbench-doc: Benchmarking long-context document understanding with visualizations, 2024. URL [https://arxiv.org/abs/2407.01523](https://arxiv.org/abs/2407.01523 "").

- Mathew et al. (2020)  
Minesh Mathew, Dimosthenis Karatzas, and C. V. Jawahar.  
DocVQA: A Dataset for VQA on Document Images. 2020. doi: 10.48550/ARXIV.2007.00398. URL [https://arxiv.org/abs/2007.00398](https://arxiv.org/abs/2007.00398 "").

</details>

<details>
<summary>ColPali + Milvus: Redefining Document Retrieval with Vision-Language Models</summary>

# ColPali + Milvus: Redefining Document Retrieval with Vision-Language Models

Mar 27, 2025 7 min read

By [Stephen Batifol]

https://assets.zilliz.com/large_Col_Pali_Milvus_Redefining_Document_Retrieval_with_Vision_Language_Models_8a25f8769f_min_1ed7217e17.png

In document retrieval and search, we've traditionally relied on complex pipelines that extract text, analyze layouts, and generate embeddings. But what if we could skip all that and simply "see" documents the way humans do? [ColPali](https://zilliz.com/blog/colpali-enhanced-doc-retrieval-with-vision-language-models-and-colbert-strategy) is a groundbreaking approach that combines the power of vision-language models with efficient retrieval techniques to transform how we search through documents.

## The Problem with Traditional Document Retrieval

Traditional document retrieval systems, especially for PDFs and other rich documents, require a cumbersome pipeline:

1. Run OCR to extract text from scanned documents
2. Perform layout detection to identify paragraphs, figures, and tables
3. Reconstruct the document structure and reading order
4. Caption figures and tables using specialized models
5. Chunk text into manageable pieces
6. Generate embeddings for each chunk
7. Store these embeddings in a vector database

This process is slow, error-prone, and often fails to capture the rich visual information in documents. Tables, figures, and layout information get lost or distorted, leading to suboptimal search results.

## Enter ColPali: What You See Is What You Search

[ColPali](https://zilliz.com/blog/colpali-enhanced-doc-retrieval-with-vision-language-models-and-colbert-strategy)(Contextualized Late Interaction over PaliGemma) takes a radically different approach. Instead of extracting text, it treats document pages as images and leverages vision-language models to understand both textual and visual content simultaneously.

The name "ColPali" comes from two key components:

- Col: Refers to [ColBERT](https://zilliz.com/blog/colpali-enhanced-doc-retrieval-with-vision-language-models-and-colbert-strategy)'s multi-vector representation and late interaction strategy

- Pali: Refers to PaliGemma, Google's vision-language model that combines SigLIP-So400m (image encoder) and Gemma-2B (text decoder)

### How ColPali Works

ColPali's architecture is elegant in its simplicity:

1. During indexing: Document pages are converted to images, and a vision-language model (PaliGemma) processes these images to generate a grid of contextualized embeddings (32×32 patches, each represented as a 128-dimensional vector).

2. During querying: The user's query is tokenized and embedded. A "late interaction" mechanism compares each query token with all document patches to find the most relevant matches.

The magic happens in this late interaction. For each term in the query, ColPali finds the document patch with the most similar representation, then sums these similarity scores to produce a final relevance score. This allows for rich interaction between query terms and document elements while maintaining efficient retrieval.

## Implementing ColPali with Milvus

[Milvus](https://milvus.io/), a powerful vector database, is the perfect companion for ColPali's multi-vector approach. Let's see how we can implement this powerful combination.

### Setting Up the Environment

First, we need to install the necessary packages:

```Python
pip install pdf2image pymilvus colpali_engine tqdm pillow
```

### Converting PDFs to Images

Since ColPali works with images, we need to convert our PDF documents to image format:

```Python
from pdf2image import convert_from_path

pdf_path = "pdfs/your_document.pdf"
images = convert_from_path(pdf_path)

for i, image in enumerate(images):
    image.save(f"pages/page_{i + 1}.png", "PNG")
```

### Creating a Milvus Collection for ColPali Embeddings

Now, let's set up a Milvus collection to store our ColPali embeddings:

```Python
from pymilvus import MilvusClient, DataType
import numpy as np
import concurrent.futures

# Initialize Milvus client
client = MilvusClient(uri="milvus.db")  # For local testing with Milvus Lite
# For production: client = MilvusClient(uri="http://your-milvus-server:19530")
```

We'll create a custom retriever class to handle the multi-vector nature of ColPali embeddings:

```Python
class MilvusColbertRetriever:
    def __init__(self, milvus_client, collection_name, dim=128):
        self.collection_name = collection_name
        self.client = milvus_client
        if self.client.has_collection(collection_name=self.collection_name):
            self.client.load_collection(collection_name)
        self.dim = dim

    def create_collection(self):
        if self.client.has_collection(collection_name=self.collection_name):
            self.client.drop_collection(collection_name=self.collection_name)

        schema = self.client.create_schema(
            auto_id=True,
            enable_dynamic_fields=True,
        )
        schema.add_field(field_name="pk", datatype=DataType.INT64, is_primary=True)
        schema.add_field(
            field_name="vector", datatype=DataType.FLOAT_VECTOR, dim=self.dim
        )
        schema.add_field(field_name="seq_id", datatype=DataType.INT16)
        schema.add_field(field_name="doc_id", datatype=DataType.INT64)
        schema.add_field(field_name="doc", datatype=DataType.VARCHAR, max_length=65535)

        self.client.create_collection(
            collection_name=self.collection_name, schema=schema
        )

    def create_index(self):
        self.client.release_collection(collection_name=self.collection_name)
        self.client.drop_index(
            collection_name=self.collection_name, index_name="vector"
        )
        index_params = self.client.prepare_index_params()
        index_params.add_index(
            field_name="vector",
            index_name="vector_index",
            index_type="HNSW",
            metric_type="IP",
            params={
                "M": 16,
                "efConstruction": 500,
            },
        )

        self.client.create_index(
            collection_name=self.collection_name, index_params=index_params, sync=True
        )
```

### The Search Magic: Implementing Late Interaction

The heart of ColPali is its search mechanism, which implements the late interaction approach.

This implementation follows the MaxSim operation described in the ColBERT paper: for each query token, find the document token with the highest similarity, then sum these maximum similarities to get the final score.

https://assets.zilliz.com/Schematic_diagrams_illustrating_query_document_matching_paradigms_in_neural_IR_e54fb966d0.png

```Python
def search(self, data, topk):
    # First, perform a vector search to find candidate documents
    search_params = {"metric_type": "IP", "params": {}}
    results = self.client.search(
        self.collection_name,
        data,
        limit=int(50),
        output_fields=["vector", "seq_id", "doc_id"],
        search_params=search_params,
    )

    # Collect unique document IDs from the results
    doc_ids = set()
    for r_id in range(len(results)):
        for r in range(len(results[r_id])):
            doc_ids.add(results[r_id][r]["entity"]["doc_id"])

    scores = []

    # Rerank function to calculate MaxSim score for each document
    def rerank_single_doc(doc_id, data, client, collection_name):
        # Retrieve all embeddings for this document
        doc_colbert_vecs = client.query(
            collection_name=collection_name,
            filter=f"doc_id in [{doc_id}]",
            output_fields=["seq_id", "vector", "doc"],
            limit=1000,
        )

        # Stack all vectors for this document
        doc_vecs = np.vstack(
            [doc_colbert_vecs[i]["vector"] for i in range(len(doc_colbert_vecs))]
        )

        # Calculate MaxSim score: for each query token, find the most similar document token
        # and sum these maximum similarities
        score = np.dot(data, doc_vecs.T).max(1).sum()
        return (score, doc_id)

    # Use parallel processing to rerank documents
    with concurrent.futures.ThreadPoolExecutor(max_workers=300) as executor:
        futures = {
            executor.submit(
                rerank_single_doc, doc_id, data, client, self.collection_name
            ): doc_id
            for doc_id in doc_ids
        }
        for future in concurrent.futures.as_completed(futures):
            score, doc_id = future.result()
            scores.append((score, doc_id))

    # Sort by score and return top-k results
    scores.sort(key=lambda x: x[0], reverse=True)
    if len(scores) >= topk:
        return scores[:topk]
    else:
        return scores
```

### Generating and Storing ColPali Embeddings

Now, let's use the ColPali model to generate embeddings for our documents:

```Python
from colpali_engine.models import ColPali
from colpali_engine.models.paligemma.colpali.processing_colpali import ColPaliProcessor
from colpali_engine.utils.torch_utils import ListDataset, get_torch_device
from torch.utils.data import DataLoader
import torch
from tqdm import tqdm
from PIL import Image
import os

# Initialize the ColPali model
device = get_torch_device("cpu")  # Use GPU if available
model_name = "vidore/colpali-v1.2"

model = ColPali.from_pretrained(
    model_name,
    torch_dtype=torch.bfloat16,
    device_map=device,
).eval()

processor = ColPaliProcessor.from_pretrained(model_name)

# Process document images
images = [Image.open(f"./pages/{name}") for name in os.listdir("./pages")]

dataloader = DataLoader(
    dataset=ListDataset[str](images),
    batch_size=1,
    shuffle=False,
    collate_fn=lambda x: processor.process_images(x),
)

document_embeddings = []
for batch_doc in tqdm(dataloader):
    with torch.no_grad():
        batch_doc = {k: v.to(model.device) for k, v in batch_doc.items()}
        embeddings_doc = model(**batch_doc)
    document_embeddings.extend(list(torch.unbind(embeddings_doc.to("cpu"))))

# Create and set up the Milvus collection
retriever = MilvusColbertRetriever(collection_name="colpali", milvus_client=client)
retriever.create_collection()
retriever.create_index()

# Insert embeddings into Milvus
filepaths = [f"./pages/{name}" for name in os.listdir("./pages")]
for i in range(len(filepaths)):
    data = {
        "colbert_vecs": document_embeddings[i].float().numpy(),
        "doc_id": i,
        "filepath": filepaths[i],
    }
    retriever.insert(data)
```

### Searching with ColPali

Finally, let's see how we can search for relevant documents using ColPali:

```Python
# Process queries
queries = [\
    "How does ColBERT perform end-to-end retrieval?",\
    "Show me the performance comparison table for ColBERT",\
]

dataloader = DataLoader(
    dataset=ListDataset[str](queries),
    batch_size=1,
    shuffle=False,
    collate_fn=lambda x: processor.process_queries(x),
)

query_embeddings = []
for batch_query in dataloader:
    with torch.no_grad():
        batch_query = {k: v.to(model.device) for k, v in batch_query.items()}
        embeddings_query = model(**batch_query)
    query_embeddings.extend(list(torch.unbind(embeddings_query.to("cpu"))))

# Search for each query
for i, query in enumerate(queries):
    query_embedding = query_embeddings[i].float().numpy()
    results = retriever.search(query_embedding, topk=3)

    print(f"Query: {query}")
    for score, doc_id in results:
        print(f"  Score: {score:.4f}, Document: {filepaths[doc_id]}")
    print()
```

## Why ColPali + Milvus is a Game-Changer

The combination of ColPali and Milvus offers several compelling advantages:

1. Simplified Pipeline: No more complex text extraction, OCR, layout analysis, or chunking. Just convert pages to images and process them directly.

2. Rich Visual Understanding: ColPali captures both textual and visual information, including tables, figures, and layout, leading to more comprehensive document understanding.

3. Superior Performance: ColPali outperforms traditional text-based retrieval methods, especially for visually complex documents containing infographics, figures, and tables.

4. Efficient Storage and Retrieval: Milvus provides fast and scalable vector search capabilities, making it ideal for storing and retrieving ColPali's multi-vector representations.

5. Interpretable Results: ColPali can visualize which parts of a document match specific query terms, providing insights into why a document was retrieved.

## Real-World Applications

The ColPali + Milvus combination is particularly valuable for:

- Legal Document Search: Find relevant cases and precedents in legal documents with complex layouts and tables.

- Scientific Literature Review: Search through research papers with figures, equations, and tables.

- Technical Documentation: Navigate complex technical manuals with diagrams and schematics.

- Financial Analysis: Search through reports with charts, graphs, and financial tables.

## Conclusion

ColPali represents a paradigm shift in document retrieval - moving from "what you extract is what you search" to "what you see is what you search." By leveraging vision-language models and multi-vector representations, it offers a more intuitive and effective way to search through documents.

When combined with Milvus's powerful vector search capabilities, ColPali becomes a practical solution for real-world document retrieval challenges. The simplified pipeline, improved accuracy, and ability to understand visual elements make this combination a compelling choice for modern retrieval-augmented generation systems.

As vision-language models continue to evolve, we can expect even more powerful document understanding capabilities in the future. But for now, ColPali + Milvus represents the state-of-the-art in document retrieval - a solution that truly sees documents the way humans do.

## Getting Started

Ready to try ColPali with Milvus? Check out the [complete code example](https://github.com/milvus-io/bootcamp/blob/master/bootcamp/tutorials/quickstart/use_ColPali_with_milvus.ipynb) on GitHub, or visit the [ColPali repository](https://github.com/illuin-tech/colpali) to learn more about the model.

For more information about Milvus, visit the [official documentation](https://milvus.io/docs).

Updated on Aug 05, 2025

</details>

<details>
<summary>Document understanding</summary>

# Document understanding

Gemini models can process documents in PDF format, using native
vision to understand entire document contexts. This goes beyond
simple text extraction, allowing Gemini to:

- Analyze and interpret content, including text, images, diagrams,
charts, and tables, even in long documents up to 1000 pages.
- Extract information into [structured output](https://ai.google.dev/gemini-api/docs/structured-output) formats.
- Summarize and answer questions based on both the visual and textual elements
in a document.
- Transcribe document content (e.g. to HTML), preserving layouts and
formatting, for use in downstream applications.

## Passing inline PDF data

You can pass inline PDF data in the request to `generateContent`.
For PDF payloads under 20MB, you can choose between uploading base64
encoded documents or directly uploading locally stored files.

The following example shows you how to fetch a PDF from a URL and convert it to
bytes for processing:

### Python

```
from google import genai
from google.genai import types
import httpx

client = genai.Client()

doc_url = "https://discovery.ucl.ac.uk/id/eprint/10089234/1/343019_3_art_0_py4t4l_convrt.pdf"

# Retrieve and encode the PDF byte
doc_data = httpx.get(doc_url).content

prompt = "Summarize this document"
response = client.models.generate_content(
  model="gemini-2.5-flash",
  contents=[\
      types.Part.from_bytes(\
        data=doc_data,\
        mime_type='application/pdf',\
      ),\
      prompt])
print(response.text)

```

### JavaScript

```
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: "GEMINI_API_KEY" });

async function main() {
    const pdfResp = await fetch('https://discovery.ucl.ac.uk/id/eprint/10089234/1/343019_3_art_0_py4t4l_convrt.pdf')
        .then((response) => response.arrayBuffer());

    const contents = [\
        { text: "Summarize this document" },\
        {\
            inlineData: {\
                mimeType: 'application/pdf',\
                data: Buffer.from(pdfResp).toString("base64")\
            }\
        }\
    ];

    const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: contents
    });
    console.log(response.text);
}

main();

```

### Go

```
package main

import (
    "context"
    "fmt"
    "io"
    "net/http"
    "os"
    "google.golang.org/genai"
)

func main() {

    ctx := context.Background()
    client, _ := genai.NewClient(ctx, &genai.ClientConfig{
        APIKey:  os.Getenv("GEMINI_API_KEY"),
        Backend: genai.BackendGeminiAPI,
    })

    pdfResp, _ := http.Get("https://discovery.ucl.ac.uk/id/eprint/10089234/1/343019_3_art_0_py4t4l_convrt.pdf")
    var pdfBytes []byte
    if pdfResp != nil && pdfResp.Body != nil {
        pdfBytes, _ = io.ReadAll(pdfResp.Body)
        pdfResp.Body.Close()
    }

    parts := []*genai.Part{
        &genai.Part{
            InlineData: &genai.Blob{
                MIMEType: "application/pdf",
                Data:     pdfBytes,
            },
        },
        genai.NewPartFromText("Summarize this document"),
    }

    contents := []*genai.Content{
        genai.NewContentFromParts(parts, genai.RoleUser),
    }

    result, _ := client.Models.GenerateContent(
        ctx,
        "gemini-2.5-flash",
        contents,
        nil,
    )

    fmt.Println(result.Text())
}

```

### REST

```
DOC_URL="https://discovery.ucl.ac.uk/id/eprint/10089234/1/343019_3_art_0_py4t4l_convrt.pdf"
PROMPT="Summarize this document"
DISPLAY_NAME="base64_pdf"

# Download the PDF
wget -O "${DISPLAY_NAME}.pdf" "${DOC_URL}"

# Check for FreeBSD base64 and set flags accordingly
if [[ "$(base64 --version 2>&1)" = *"FreeBSD"* ]]; then
  B64FLAGS="--input"
else
  B64FLAGS="-w0"
fi

# Base64 encode the PDF
ENCODED_PDF=$(base64 $B64FLAGS "${DISPLAY_NAME}.pdf")

# Generate content using the base64 encoded PDF
curl "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$GOOGLE_API_KEY" \
    -H 'Content-Type: application/json' \
    -X POST \
    -d '{
      "contents": [{\
        "parts":[\
          {"inline_data": {"mime_type": "application/pdf", "data": "'"$ENCODED_PDF"'"}},\
          {"text": "'$PROMPT'"}\
        ]\
      }]
    }' 2> /dev/null > response.json

cat response.json
echo

jq ".candidates[].content.parts[].text" response.json

# Clean up the downloaded PDF
rm "${DISPLAY_NAME}.pdf"

```

You can also read a PDF from a local file for processing:

### Python

```
from google import genai
from google.genai import types
import pathlib

client = genai.Client()

# Retrieve and encode the PDF byte
filepath = pathlib.Path('file.pdf')

prompt = "Summarize this document"
response = client.models.generate_content(
  model="gemini-2.5-flash",
  contents=[\
      types.Part.from_bytes(\
        data=filepath.read_bytes(),\
        mime_type='application/pdf',\
      ),\
      prompt])
print(response.text)

```

### JavaScript

```
import { GoogleGenAI } from "@google/genai";
import * as fs from 'fs';

const ai = new GoogleGenAI({ apiKey: "GEMINI_API_KEY" });

async function main() {
    const contents = [\
        { text: "Summarize this document" },\
        {\
            inlineData: {\
                mimeType: 'application/pdf',\
                data: Buffer.from(fs.readFileSync("content/343019_3_art_0_py4t4l_convrt.pdf")).toString("base64")\
            }\
        }\
    ];

    const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: contents
    });
    console.log(response.text);
}

main();

```

### Go

```
package main

import (
    "context"
    "fmt"
    "os"
    "google.golang.org/genai"
)

func main() {

    ctx := context.Background()
    client, _ := genai.NewClient(ctx, &genai.ClientConfig{
        APIKey:  os.Getenv("GEMINI_API_KEY"),
        Backend: genai.BackendGeminiAPI,
    })

    pdfBytes, _ := os.ReadFile("path/to/your/file.pdf")

    parts := []*genai.Part{
        &genai.Part{
            InlineData: &genai.Blob{
                MIMEType: "application/pdf",
                Data:     pdfBytes,
            },
        },
        genai.NewPartFromText("Summarize this document"),
    }
    contents := []*genai.Content{
        genai.NewContentFromParts(parts, genai.RoleUser),
    }

    result, _ := client.Models.GenerateContent(
        ctx,
        "gemini-2.5-flash",
        contents,
        nil,
    )

    fmt.Println(result.Text())
}

```

## Uploading PDFs using the File API

You can use the [File API](https://ai.google.dev/gemini-api/docs/files) to upload larger documents. Always use the File
API when the total request size (including the files, text prompt, system
instructions, etc.) is larger than 20MB.

Call [`media.upload`](https://ai.google.dev/api/rest/v1beta/media/upload) to upload a file using the
File API. The following code uploads a document file and then uses the file in a
call to
[`models.generateContent`](https://ai.google.dev/api/generate-content#method:-models.generatecontent).

### Large PDFs from URLs

Use the File API to simplify uploading and processing large PDF files from URLs:

### Python

```
from google import genai
from google.genai import types
import io
import httpx

client = genai.Client()

long_context_pdf_path = "https://www.nasa.gov/wp-content/uploads/static/history/alsj/a17/A17_FlightPlan.pdf"

# Retrieve and upload the PDF using the File API
doc_io = io.BytesIO(httpx.get(long_context_pdf_path).content)

sample_doc = client.files.upload(
  # You can pass a path or a file-like object here
  file=doc_io,
  config=dict(
    mime_type='application/pdf')
)

prompt = "Summarize this document"

response = client.models.generate_content(
  model="gemini-2.5-flash",
  contents=[sample_doc, prompt])
print(response.text)

```

### JavaScript

```
import { createPartFromUri, GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: "GEMINI_API_KEY" });

async function main() {

    const pdfBuffer = await fetch("https://www.nasa.gov/wp-content/uploads/static/history/alsj/a17/A17_FlightPlan.pdf")
        .then((response) => response.arrayBuffer());

    const fileBlob = new Blob([pdfBuffer], { type: 'application/pdf' });

    const file = await ai.files.upload({
        file: fileBlob,
        config: {
            displayName: 'A17_FlightPlan.pdf',
        },
    });

    // Wait for the file to be processed.
    let getFile = await ai.files.get({ name: file.name });
    while (getFile.state === 'PROCESSING') {
        getFile = await ai.files.get({ name: file.name });
        console.log(`current file status: ${getFile.state}`);
        console.log('File is still processing, retrying in 5 seconds');

        await new Promise((resolve) => {
            setTimeout(resolve, 5000);
        });
    }
    if (file.state === 'FAILED') {
        throw new Error('File processing failed.');
    }

    // Add the file to the contents.
    const content = [\
        'Summarize this document',\
    ];

    if (file.uri && file.mimeType) {
        const fileContent = createPartFromUri(file.uri, file.mimeType);
        content.push(fileContent);
    }

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: content,
    });

    console.log(response.text);

}

main();

```

### Go

```
package main

import (
  "context"
  "fmt"
  "io"
  "net/http"
  "os"
  "google.golang.org/genai"
)

func main() {

  ctx := context.Background()
  client, _ := genai.NewClient(ctx, &genai.ClientConfig{
    APIKey:  os.Getenv("GEMINI_API_KEY"),
    Backend: genai.BackendGeminiAPI,
  })

  pdfURL := "https://www.nasa.gov/wp-content/uploads/static/history/alsj/a17/A17_FlightPlan.pdf"
  localPdfPath := "A17_FlightPlan_downloaded.pdf"

  respHttp, _ := http.Get(pdfURL)
  defer respHttp.Body.Close()

  outFile, _ := os.Create(localPdfPath)
  defer outFile.Close()

  _, _ = io.Copy(outFile, respHttp.Body)

  uploadConfig := &genai.UploadFileConfig{MIMEType: "application/pdf"}
  uploadedFile, _ := client.Files.UploadFromPath(ctx, localPdfPath, uploadConfig)

  promptParts := []*genai.Part{
    genai.NewPartFromURI(uploadedFile.URI, uploadedFile.MIMEType),
    genai.NewPartFromText("Summarize this document"),
  }
  contents := []*genai.Content{
    genai.NewContentFromParts(promptParts, genai.RoleUser), // Specify role
  }

    result, _ := client.Models.GenerateContent(
        ctx,
        "gemini-2.5-flash",
        contents,
        nil,
    )

  fmt.Println(result.Text())
}

```

### REST

```
PDF_PATH="https://www.nasa.gov/wp-content/uploads/static/history/alsj/a17/A17_FlightPlan.pdf"
DISPLAY_NAME="A17_FlightPlan"
PROMPT="Summarize this document"

# Download the PDF from the provided URL
wget -O "${DISPLAY_NAME}.pdf" "${PDF_PATH}"

MIME_TYPE=$(file -b --mime-type "${DISPLAY_NAME}.pdf")
NUM_BYTES=$(wc -c < "${DISPLAY_NAME}.pdf")

echo "MIME_TYPE: ${MIME_TYPE}"
echo "NUM_BYTES: ${NUM_BYTES}"

tmp_header_file=upload-header.tmp

# Initial resumable request defining metadata.
# The upload url is in the response headers dump them to a file.
curl "${BASE_URL}/upload/v1beta/files?key=${GOOGLE_API_KEY}" \
  -D upload-header.tmp \
  -H "X-Goog-Upload-Protocol: resumable" \
  -H "X-Goog-Upload-Command: start" \
  -H "X-Goog-Upload-Header-Content-Length: ${NUM_BYTES}" \
  -H "X-Goog-Upload-Header-Content-Type: application/pdf" \
  -H "Content-Type: application/json" \
  -d "{'file': {'display_name': '${DISPLAY_NAME}'}}" 2> /dev/null

upload_url=$(grep -i "x-goog-upload-url: " "${tmp_header_file}" | cut -d" " -f2 | tr -d "\r")
rm "${tmp_header_file}"

# Upload the actual bytes.
curl "${upload_url}" \
  -H "Content-Length: ${NUM_BYTES}" \
  -H "X-Goog-Upload-Offset: 0" \
  -H "X-Goog-Upload-Command: upload, finalize" \
  --data-binary "@${DISPLAY_NAME}.pdf" 2> /dev/null > file_info.json

file_uri=$(jq ".file.uri" file_info.json)
echo file_uri=$file_uri

# Now generate content using that file
curl "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$GOOGLE_API_KEY" \
    -H 'Content-Type: application/json' \
    -X POST \
    -d '{
      "contents": [{\
        "parts":[\
          {"text": "Can you add a few more lines to this poem?"},\
          {"file_data":{"mime_type": "application/pdf", "file_uri": '$file_uri'}}]\
        }]
      }' 2> /dev/null > response.json

cat response.json
echo

jq ".candidates[].content.parts[].text" response.json

```

### Large PDFs stored locally

### Python

```
from google import genai
from google.genai import types
import pathlib
import httpx

client = genai.Client()

# Retrieve and encode the PDF byte
file_path = pathlib.Path('large_file.pdf')

# Upload the PDF using the File API
sample_file = client.files.upload(
  file=file_path,
)

prompt="Summarize this document"

response = client.models.generate_content(
  model="gemini-2.5-flash",
  contents=[sample_file, "Summarize this document"])
print(response.text)

```

### JavaScript

```
import { createPartFromUri, GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: "GEMINI_API_KEY" });

async function main() {
    const file = await ai.files.upload({
        file: 'path-to-localfile.pdf'
        config: {
            displayName: 'A17_FlightPlan.pdf',
        },
    });

    // Wait for the file to be processed.
    let getFile = await ai.files.get({ name: file.name });
    while (getFile.state === 'PROCESSING') {
        getFile = await ai.files.get({ name: file.name });
        console.log(`current file status: ${getFile.state}`);
        console.log('File is still processing, retrying in 5 seconds');

        await new Promise((resolve) => {
            setTimeout(resolve, 5000);
        });
    }
    if (file.state === 'FAILED') {
        throw new Error('File processing failed.');
    }

    // Add the file to the contents.
    const content = [\
        'Summarize this document',\
    ];

    if (file.uri && file.mimeType) {
        const fileContent = createPartFromUri(file.uri, file.mimeType);
        content.push(fileContent);
    }

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: content,
    });

    console.log(response.text);

}

main();

```

### Go

```
package main

import (
    "context"
    "fmt"
    "os"
    "google.golang.org/genai"
)

func main() {

    ctx := context.Background()
    client, _ := genai.NewClient(ctx, &genai.ClientConfig{
        APIKey:  os.Getenv("GEMINI_API_KEY"),
        Backend: genai.BackendGeminiAPI,
    })
    localPdfPath := "/path/to/file.pdf"

    uploadConfig := &genai.UploadFileConfig{MIMEType: "application/pdf"}
    uploadedFile, _ := client.Files.UploadFromPath(ctx, localPdfPath, uploadConfig)

    promptParts := []*genai.Part{
        genai.NewPartFromURI(uploadedFile.URI, uploadedFile.MIMEType),
        genai.NewPartFromText("Give me a summary of this pdf file."),
    }
    contents := []*genai.Content{
        genai.NewContentFromParts(promptParts, genai.RoleUser),
    }

    result, _ := client.Models.GenerateContent(
        ctx,
        "gemini-2.5-flash",
        contents,
        nil,
    )

    fmt.Println(result.Text())
}

```

### REST

```
NUM_BYTES=$(wc -c < "${PDF_PATH}")
DISPLAY_NAME=TEXT
tmp_header_file=upload-header.tmp

# Initial resumable request defining metadata.
# The upload url is in the response headers dump them to a file.
curl "${BASE_URL}/upload/v1beta/files?key=${GEMINI_API_KEY}" \
  -D upload-header.tmp \
  -H "X-Goog-Upload-Protocol: resumable" \
  -H "X-Goog-Upload-Command: start" \
  -H "X-Goog-Upload-Header-Content-Length: ${NUM_BYTES}" \
  -H "X-Goog-Upload-Header-Content-Type: application/pdf" \
  -H "Content-Type: application/json" \
  -d "{'file': {'display_name': '${DISPLAY_NAME}'}}" 2> /dev/null

upload_url=$(grep -i "x-goog-upload-url: " "${tmp_header_file}" | cut -d" " -f2 | tr -d "\r")
rm "${tmp_header_file}"

# Upload the actual bytes.
curl "${upload_url}" \
  -H "Content-Length: ${NUM_BYTES}" \
  -H "X-Goog-Upload-Offset: 0" \
  -H "X-Goog-Upload-Command: upload, finalize" \
  --data-binary "@${PDF_PATH}" 2> /dev/null > file_info.json

file_uri=$(jq ".file.uri" file_info.json)
echo file_uri=$file_uri

# Now generate content using that file
curl "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$GOOGLE_API_KEY" \
    -H 'Content-Type: application/json' \
    -X POST \
    -d '{
      "contents": [{\
        "parts":[\
          {"text": "Can you add a few more lines to this poem?"},\
          {"file_data":{"mime_type": "application/pdf", "file_uri": '$file_uri'}}]\
        }]
      }' 2> /dev/null > response.json

cat response.json
echo

jq ".candidates[].content.parts[].text" response.json

```

You can verify the API successfully stored the uploaded file and get its
metadata by calling [`files.get`](https://ai.google.dev/api/rest/v1beta/files/get). Only the `name`
(and by extension, the `uri`) are unique.

### Python

```
from google import genai
import pathlib

client = genai.Client()

fpath = pathlib.Path('example.txt')
fpath.write_text('hello')

file = client.files.upload(file='example.txt')

file_info = client.files.get(name=file.name)
print(file_info.model_dump_json(indent=4))

```

### REST

```
name=$(jq ".file.name" file_info.json)
# Get the file of interest to check state
curl https://generativelanguage.googleapis.com/v1beta/files/$name > file_info.json
# Print some information about the file you got
name=$(jq ".file.name" file_info.json)
echo name=$name
file_uri=$(jq ".file.uri" file_info.json)
echo file_uri=$file_uri

```

## Passing multiple PDFs

The Gemini API is capable of processing multiple PDF documents (up to 1000 pages)
in a single request, as long as the combined size of the documents and the text
prompt stays within the model's context window.

### Python

```
from google import genai
import io
import httpx

client = genai.Client()

doc_url_1 = "https://arxiv.org/pdf/2312.11805"
doc_url_2 = "https://arxiv.org/pdf/2403.05530"

# Retrieve and upload both PDFs using the File API
doc_data_1 = io.BytesIO(httpx.get(doc_url_1).content)
doc_data_2 = io.BytesIO(httpx.get(doc_url_2).content)

sample_pdf_1 = client.files.upload(
  file=doc_data_1,
  config=dict(mime_type='application/pdf')
)
sample_pdf_2 = client.files.upload(
  file=doc_data_2,
  config=dict(mime_type='application/pdf')
)

prompt = "What is the difference between each of the main benchmarks between these two papers? Output these in a table."

response = client.models.generate_content(
  model="gemini-2.5-flash",
  contents=[sample_pdf_1, sample_pdf_2, prompt])
print(response.text)

```

### JavaScript

```
import { createPartFromUri, GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: "GEMINI_API_KEY" });

async function uploadRemotePDF(url, displayName) {
    const pdfBuffer = await fetch(url)
        .then((response) => response.arrayBuffer());

    const fileBlob = new Blob([pdfBuffer], { type: 'application/pdf' });

    const file = await ai.files.upload({
        file: fileBlob,
        config: {
            displayName: displayName,
        },
    });

    // Wait for the file to be processed.
    let getFile = await ai.files.get({ name: file.name });
    while (getFile.state === 'PROCESSING') {
        getFile = await ai.files.get({ name: file.name });
        console.log(`current file status: ${getFile.state}`);
        console.log('File is still processing, retrying in 5 seconds');

        await new Promise((resolve) => {
            setTimeout(resolve, 5000);
        });
    }
    if (file.state === 'FAILED') {
        throw new Error('File processing failed.');
    }

    return file;
}

async function main() {
    const content = [\
        'What is the difference between each of the main benchmarks between these two papers? Output these in a table.',\
    ];

    let file1 = await uploadRemotePDF("https://arxiv.org/pdf/2312.11805", "PDF 1")
    if (file1.uri && file1.mimeType) {
        const fileContent = createPartFromUri(file1.uri, file1.mimeType);
        content.push(fileContent);
    }
    let file2 = await uploadRemotePDF("https://arxiv.org/pdf/2403.05530", "PDF 2")
    if (file2.uri && file2.mimeType) {
        const fileContent = createPartFromUri(file2.uri, file2.mimeType);
        content.push(fileContent);
    }

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: content,
    });

    console.log(response.text);
}

main();

```

### Go

```
package main

import (
    "context"
    "fmt"
    "io"
    "net/http"
    "os"
    "google.golang.org/genai"
)

func main() {

    ctx := context.Background()
    client, _ := genai.NewClient(ctx, &genai.ClientConfig{
        APIKey:  os.Getenv("GEMINI_API_KEY"),
        Backend: genai.BackendGeminiAPI,
    })

    docUrl1 := "https://arxiv.org/pdf/2312.11805"
    docUrl2 := "https://arxiv.org/pdf/2403.05530"
    localPath1 := "doc1_downloaded.pdf"
    localPath2 := "doc2_downloaded.pdf"

    respHttp1, _ := http.Get(docUrl1)
    defer respHttp1.Body.Close()

    outFile1, _ := os.Create(localPath1)
    _, _ = io.Copy(outFile1, respHttp1.Body)
    outFile1.Close()

    respHttp2, _ := http.Get(docUrl2)
    defer respHttp2.Body.Close()

    outFile2, _ := os.Create(localPath2)
    _, _ = io.Copy(outFile2, respHttp2.Body)
    outFile2.Close()

    uploadConfig1 := &genai.UploadFileConfig{MIMEType: "application/pdf"}
    uploadedFile1, _ := client.Files.UploadFromPath(ctx, localPath1, uploadConfig1)

    uploadConfig2 := &genai.UploadFileConfig{MIMEType: "application/pdf"}
    uploadedFile2, _ := client.Files.UploadFromPath(ctx, localPath2, uploadConfig2)

    promptParts := []*genai.Part{
        genai.NewPartFromURI(uploadedFile1.URI, uploadedFile1.MIMEType),
        genai.NewPartFromURI(uploadedFile2.URI, uploadedFile2.MIMEType),
        genai.NewPartFromText("What is the difference between each of the " +
                              "main benchmarks between these two papers? " +
                              "Output these in a table."),
    }
    contents := []*genai.Content{
        genai.NewContentFromParts(promptParts, genai.RoleUser),
    }

    modelName := "gemini-2.5-flash"
    result, _ := client.Models.GenerateContent(
        ctx,
        modelName,
        contents,
        nil,
    )

    fmt.Println(result.Text())
}

```

### REST

```
DOC_URL_1="https://arxiv.org/pdf/2312.11805"
DOC_URL_2="https://arxiv.org/pdf/2403.05530"
DISPLAY_NAME_1="Gemini_paper"
DISPLAY_NAME_2="Gemini_1.5_paper"
PROMPT="What is the difference between each of the main benchmarks between these two papers? Output these in a table."

# Function to download and upload a PDF
upload_pdf() {
  local doc_url="$1"
  local display_name="$2"

  # Download the PDF
  wget -O "${display_name}.pdf" "${doc_url}"

  local MIME_TYPE=$(file -b --mime-type "${display_name}.pdf")
  local NUM_BYTES=$(wc -c < "${display_name}.pdf")

  echo "MIME_TYPE: ${MIME_TYPE}"
  echo "NUM_BYTES: ${NUM_BYTES}"

  local tmp_header_file=upload-header.tmp

  # Initial resumable request
  curl "${BASE_URL}/upload/v1beta/files?key=${GOOGLE_API_KEY}" \
    -D "${tmp_header_file}" \
    -H "X-Goog-Upload-Protocol: resumable" \
    -H "X-Goog-Upload-Command: start" \
    -H "X-Goog-Upload-Header-Content-Length: ${NUM_BYTES}" \
    -H "X-Goog-Upload-Header-Content-Type: ${MIME_TYPE}" \
    -H "Content-Type: application/json" \
    -d "{'file': {'display_name': '${display_name}'}}" 2> /dev/null

  local upload_url=$(grep -i "x-goog-upload-url: " "${tmp_header_file}" | cut -d" " -f2 | tr -d "\r")
  rm "${tmp_header_file}"

  # Upload the PDF
  curl "${upload_url}" \
    -H "Content-Length: ${NUM_BYTES}" \
    -H "X-Goog-Upload-Offset: 0" \
    -H "X-Goog-Upload-Command: upload, finalize" \
    --data-binary "@${display_name}.pdf" 2> /dev/null > "file_info_${display_name}.json"

  local file_uri=$(jq ".file.uri" "file_info_${display_name}.json")
  echo "file_uri for ${display_name}: ${file_uri}"

  # Clean up the downloaded PDF
  rm "${display_name}.pdf"

  echo "${file_uri}"
}

# Upload the first PDF
file_uri_1=$(upload_pdf "${DOC_URL_1}" "${DISPLAY_NAME_1}")

# Upload the second PDF
file_uri_2=$(upload_pdf "${DOC_URL_2}" "${DISPLAY_NAME_2}")

# Now generate content using both files
curl "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$GOOGLE_API_KEY" \
    -H 'Content-Type: application/json' \
    -X POST \
    -d '{
      "contents": [{\
        "parts":[\
          {"file_data": {"mime_type": "application/pdf", "file_uri": '$file_uri_1'}},\
          {"file_data": {"mime_type": "application/pdf", "file_uri": '$file_uri_2'}},\
          {"text": "'$PROMPT'"}\
        ]\
      }]
    }' 2> /dev/null > response.json

cat response.json
echo

jq ".candidates[].content.parts[].text" response.json

```

## Technical details

Gemini supports a maximum of 1,000 document pages.
Each document page is equivalent to 258 tokens.

While there are no specific limits to the number of pixels in a document besides
the model's [context window](https://ai.google.dev/gemini-api/docs/long-context), larger pages are
scaled down to a maximum resolution of 3072x3072 while preserving their original
aspect ratio, while smaller pages are scaled up to 768x768 pixels. There is no
cost reduction for pages at lower sizes, other than bandwidth, or performance
improvement for pages at higher resolution.

### Document types

Technically, you can pass other MIME types for document understanding, like
TXT, Markdown, HTML, XML, etc. However, document vision **_only meaningfully_**
**_understands PDFs_**. Other types will be extracted as pure text, and the model
won't be able to interpret what we see in the rendering of those files. Any
file-type specifics like charts, diagrams, HTML tags, Markdown formatting, etc.,
will be lost.

### Best practices

For best results:

- Rotate pages to the correct orientation before uploading.
- Avoid blurry pages.
- If using a single page, place the text prompt after the page.

## What's next

To learn more, see the following resources:

- [File prompting strategies](https://ai.google.dev/gemini-api/docs/files#prompt-guide): The
Gemini API supports prompting with text, image, audio, and video data, also
known as multimodal prompting.
- [System instructions](https://ai.google.dev/gemini-api/docs/text-generation#system-instructions):
System instructions let you steer the behavior of the model based on your
specific needs and use cases.

</details>

<details>
<summary>Multimodal embeddings API</summary>

# Multimodal embeddings API

The Multimodal embeddings API generates vectors based on the input you provide, which can include a combination of image, text, and video data. The embedding vectors can then be used for subsequent tasks like image classification or video content moderation.

For additional conceptual information, see [Multimodal embeddings](https://cloud.google.com/vertex-ai/generative-ai/docs/embeddings/get-multimodal-embeddings).

**Supported Models**:

| Model | Code |
| --- | --- |
| Embeddings for Multimodal | `multimodalembedding@001` |

Starting April 29, 2025, Gemini 1.5 Pro and Gemini 1.5 Flash models are not available in projects that have no prior usage of these models, including new projects. For details, see [Model versions and lifecycle](https://cloud.google.com/vertex-ai/generative-ai/docs/learn/model-versions#legacy-stable).

## Example syntax

Syntax to send a multimodal embeddings API request.

```
curl -X POST \
-H "Authorization: Bearer $(gcloud auth print-access-token)" \
-H "Content-Type: application/json" \

https://${LOCATION}-aiplatform.googleapis.com/v1/projects/${PROJECT_ID}/locations/${LOCATION}/publishers/google/models/${MODEL_ID}:predict \
-d '{
"instances": [\
  ...\
],
}'
```

```
from vertexai.vision_models import MultiModalEmbeddingModel

model = MultiModalEmbeddingModel.from_pretrained("multimodalembedding")
model.get_embeddings(...)
```

## Parameter list

See [examples](https://cloud.google.com/vertex-ai/generative-ai/docs/model-reference/multimodal-embeddings-api#examples) for implementation details.

### Request Body

```
{
  "instances": [\
    {\
      "text": string,\
      "image": {\
        // Union field can be only one of the following:\
        "bytesBase64Encoded": string,\
        "gcsUri": string,\
        // End of list of possible types for union field.\
        "mimeType": string\
      },\
      "video": {\
        // Union field can be only one of the following:\
        "bytesBase64Encoded": string,\
        "gcsUri": string,\
        // End of list of possible types for union field.\
        "videoSegmentConfig": {\
          "startOffsetSec": integer,\
          "endOffsetSec": integer,\
          "intervalSec": integer\
        }\
      },\
      "parameters": {\
        "dimension": integer\
      }\
    }\
  ]
}

```

| Parameters |
| --- |
| `image` | Optional: `Image`<br>The image to generate embeddings<br>for. |
| `text` | Optional: `String`<br>The text to generate embeddings<br>for. |
| `video` | Optional: `Video`<br>The video segment to generate<br>embeddings for. |
| `dimension` | Optional: `Int`<br>The dimension of the embedding,<br>included in the response. Only applies to text and image input. Accepted<br>values: `128`, `256`, `512`, or<br>`1408`. |

#### Image

| Parameters |
| --- |
| `bytesBase64Encoded` | Optional: `String`<br>Image bytes encoded in a base64 string. Must be one of `bytesBase64Encoded` or `gcsUri`. |
| `gcsUri` | Optional. `String`<br>The Cloud Storage location of the image to perform the embedding. One of `bytesBase64Encoded` or `gcsUri`. |
| `mimeType` | Optional. `String`<br>The MIME type of the content of the image. Supported values: `image/jpeg` and `image/png`. |

#### Video

| Parameters |
| --- |
| `bytesBase64Encoded` | Optional: `String`<br>Video bytes encoded in base64 string. One of `bytesBase64Encoded` or `gcsUri`. |
| `gcsUri` | Optional: `String`<br>The Cloud Storage location of the video on which to perform the embedding. One of `bytesBase64Encoded` or `gcsUri`. |
| `videoSegmentConfig` | Optional: `VideoSegmentConfig`<br>The video segment config. |

##### VideoSegmentConfig

| Parameters |
| --- |
| `startOffsetSec` | Optional: `Int`<br>The start offset of the video segment in seconds. If not specified, it's calculated with `max(0, endOffsetSec - 120)`. |
| `endOffsetSec` | Optional: `Int`<br>The end offset of the video segment in seconds. If not specified, it's calculated with `min(video length, startOffSec + 120)`. If both `startOffSec` and `endOffsetSec` are specified, `endOffsetSec` is adjusted to `min(startOffsetSec+120, endOffsetSec)`. |
| `intervalSec` | Optional. `Int`<br>The interval of the video the embedding will be generated. The minimum value for `interval_sec` is 4. If the interval is less than `4`, an `InvalidArgumentError` is returned. There are no limitations on the maximum value of the interval. However, if the interval is larger than `min(video length, 120s)`, it impacts the quality of the generated embeddings. Default value: `16`. |

### Response body

```
{
  "predictions": [\
    {\
      "textEmbedding": [\
        float,\
        // array of 128, 256, 512, or 1408 float values\
        float\
      ],\
      "imageEmbedding": [\
        float,\
        // array of 128, 256, 512, or 1408 float values\
        float\
      ],\
      "videoEmbeddings": [\
        {\
          "startOffsetSec": integer,\
          "endOffsetSec": integer,\
          "embedding": [\
            float,\
            // array of 1408 float values\
            float\
          ]\
        }\
      ]\
    }\
  ],
  "deployedModelId": string
}

```

| Response element | Description |
| --- | --- |
| `imageEmbedding` | 128, 256, 512, or 1408 dimension list of floats. |
| `textEmbedding` | 128, 256, 512, or 1408 dimension list of floats. |
| `videoEmbeddings` | 1408 dimension list of floats with the start and end time (in seconds) of the video segment that the embeddings are generated for. |

## Examples

### Basic use case

#### Generate embeddings from image

Use the following sample to generate embeddings for an image.

Before using any of the request data, make the following replacements:

- LOCATION: Your project's region. For example, `us-central1`, `europe-west2`, or `asia-northeast3`. For a list of available regions, see [Generative AI on Vertex AI locations](https://cloud.google.com/vertex-ai/generative-ai/docs/learn/locations-genai).
- PROJECT_ID: Your Google Cloud [project ID](https://cloud.google.com/resource-manager/docs/creating-managing-projects#identifiers).
- TEXT: The target text to get embeddings for. For example, `a cat`.
- B64_ENCODED_IMG: The target image to get embeddings for. The image must be specified as a [base64-encoded](https://cloud.google.com/vertex-ai/generative-ai/docs/image/base64-encode) byte string.

HTTP method and URL:

```
POST https://LOCATION-aiplatform.googleapis.com/v1/projects/PROJECT_ID/locations/LOCATION/publishers/google/models/multimodalembedding@001:predict
```

Request JSON body:

```
{
  "instances": [\
    {\
      "text": "TEXT",\
      "image": {\
        "bytesBase64Encoded": "B64_ENCODED_IMG"\
      }\
    }\
  ]
}

```

To send your request, choose one of these options:

Save the request body in a file named `request.json`, and execute the following command:

```
curl -X POST \
     -H "Authorization: Bearer $(gcloud auth print-access-token)" \
     -H "Content-Type: application/json; charset=utf-8" \
     -d @request.json \
     "https://LOCATION-aiplatform.googleapis.com/v1/projects/PROJECT_ID/locations/LOCATION/publishers/google/models/multimodalembedding@001:predict"
```

The embedding the model returns is a 1408 float vector. The following sample response is shortened for space.

```
{
  "predictions": [\
    {\
      "textEmbedding": [\
        0.010477379,\
        -0.00399621,\
        0.00576670747,\
        [...]\
        -0.00823613815,\
        -0.0169572588,\
        -0.00472954148\
      ],\
      "imageEmbedding": [\
        0.00262696808,\
        -0.00198890246,\
        0.0152047109,\
        -0.0103145819,\
        [...]\
        0.0324628279,\
        0.0284924973,\
        0.011650892,\
        -0.00452344026\
      ]\
    }\
  ],
  "deployedModelId": "DEPLOYED_MODEL_ID"
}
```

To learn how to install or update the Vertex AI SDK for Python, see [Install the Vertex AI SDK for Python](https://cloud.google.com/vertex-ai/docs/start/use-vertex-ai-python-sdk).

For more information, see the [Python API reference documentation](https://cloud.google.com/python/docs/reference/aiplatform/latest).

```python
import vertexai
from vertexai.vision_models import Image, MultiModalEmbeddingModel

# TODO(developer): Update & uncomment line below
# PROJECT_ID = "your-project-id"
vertexai.init(project=PROJECT_ID, location="us-central1")

model = MultiModalEmbeddingModel.from_pretrained("multimodalembedding@001")
image = Image.load_from_file(
    "gs://cloud-samples-data/vertex-ai/llm/prompts/landmark1.png"
)

embeddings = model.get_embeddings(
    image=image,
    contextual_text="Colosseum",
    dimension=1408,
)
print(f"Image Embedding: {embeddings.image_embedding}")
print(f"Text Embedding: {embeddings.text_embedding}")
# Example response:
# Image Embedding: [-0.0123147098, 0.0727171078, ...]
# Text Embedding: [0.00230263756, 0.0278981831, ...]
```

To authenticate to Vertex AI, set up Application Default Credentials. For more information, see [Set up authentication for a local development environment](https://cloud.google.com/docs/authentication/set-up-adc-local-dev-environment).

```javascript
/**
 * TODO(developer): Uncomment these variables before running the sample.\
 * (Not necessary if passing values as arguments)
 */
// const project = 'YOUR_PROJECT_ID';
// const location = 'YOUR_PROJECT_LOCATION';
// const baseImagePath = 'YOUR_BASE_IMAGE_PATH';
// const textPrompt = 'YOUR_TEXT_PROMPT';
const aiplatform = require('@google-cloud/aiplatform');

// Imports the Google Cloud Prediction service client
const {PredictionServiceClient} = aiplatform.v1;

// Import the helper module for converting arbitrary protobuf.Value objects.
const {helpers} = aiplatform;

// Specifies the location of the api endpoint
const clientOptions = {
  apiEndpoint: 'us-central1-aiplatform.googleapis.com',
};
const publisher = 'google';
const model = 'multimodalembedding@001';

// Instantiates a client
const predictionServiceClient = new PredictionServiceClient(clientOptions);

async function predictImageFromImageAndText() {
  // Configure the parent resource
  const endpoint = `projects/${project}/locations/${location}/publishers/${publisher}/models/${model}`;

  const fs = require('fs');
  const imageFile = fs.readFileSync(baseImagePath);

  // Convert the image data to a Buffer and base64 encode it.
  const encodedImage = Buffer.from(imageFile).toString('base64');

  const prompt = {
    text: textPrompt,
    image: {
      bytesBase64Encoded: encodedImage,
    },
  };
  const instanceValue = helpers.toValue(prompt);
  const instances = [instanceValue];

  const parameter = {
    sampleCount: 1,
  };
  const parameters = helpers.toValue(parameter);

  const request = {
    endpoint,
    instances,
    parameters,
  };

  // Predict request
  const [response] = await predictionServiceClient.predict(request);
  console.log('Get image embedding response');
  const predictions = response.predictions;
  console.log('\tPredictions :');
  for (const prediction of predictions) {
    console.log(`\t\tPrediction : ${JSON.stringify(prediction)}`);
  }
}

await predictImageFromImageAndText();
```

```java
import com.google.cloud.aiplatform.v1beta1.EndpointName;
import com.google.cloud.aiplatform.v1beta1.PredictResponse;
import com.google.cloud.aiplatform.v1beta1.PredictionServiceClient;
import com.google.cloud.aiplatform.v1beta1.PredictionServiceSettings;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.Value;
import com.google.protobuf.util.JsonFormat;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PredictImageFromImageAndTextSample {

  public static void main(String[] args) throws IOException {
    // TODO(developer): Replace this variable before running the sample.
    String project = "YOUR_PROJECT_ID";
    String textPrompt = "YOUR_TEXT_PROMPT";
    String baseImagePath = "YOUR_BASE_IMAGE_PATH";

    // Learn how to use text prompts to update an image:
    // https://cloud.google.com/vertex-ai/docs/generative-ai/image/edit-images
    Map<String, Object> parameters = new HashMap<String, Object>();
    parameters.put("sampleCount", 1);

    String location = "us-central1";
    String publisher = "google";
    String model = "multimodalembedding@001";

    predictImageFromImageAndText(
        project, location, publisher, model, textPrompt, baseImagePath, parameters);
  }

  // Update images using text prompts
  public static void predictImageFromImageAndText(
      String project,
      String location,
      String publisher,
      String model,
      String textPrompt,
      String baseImagePath,
      Map<String, Object> parameters)
      throws IOException {
    final String endpoint = String.format("%s-aiplatform.googleapis.com:443", location);
    final PredictionServiceSettings predictionServiceSettings =
        PredictionServiceSettings.newBuilder().setEndpoint(endpoint).build();

    // Initialize client that will be used to send requests. This client only needs to be created
    // once, and can be reused for multiple requests.
    try (PredictionServiceClient predictionServiceClient =
        PredictionServiceClient.create(predictionServiceSettings)) {
      final EndpointName endpointName =
          EndpointName.ofProjectLocationPublisherModelName(project, location, publisher, model);

      // Convert the image to Base64
      byte[] imageData = Base64.getEncoder().encode(Files.readAllBytes(Paths.get(baseImagePath)));
      String encodedImage = new String(imageData, StandardCharsets.UTF_8);

      JsonObject jsonInstance = new JsonObject();
      jsonInstance.addProperty("text", textPrompt);
      JsonObject jsonImage = new JsonObject();
      jsonImage.addProperty("bytesBase64Encoded", encodedImage);
      jsonInstance.add("image", jsonImage);

      Value instanceValue = stringToValue(jsonInstance.toString());
      List<Value> instances = new ArrayList<>();
      instances.add(instanceValue);

      Gson gson = new Gson();
      String gsonString = gson.toJson(parameters);
      Value parameterValue = stringToValue(gsonString);

      PredictResponse predictResponse =
          predictionServiceClient.predict(endpointName, instances, parameterValue);
      System.out.println("Predict Response");
      System.out.println(predictResponse);
      for (Value prediction : predictResponse.getPredictionsList()) {
        System.out.format("\tPrediction: %s\n", prediction);
      }
    }
  }

  // Convert a Json string to a protobuf.Value
  static Value stringToValue(String value) throws InvalidProtocolBufferException {
    Value.Builder builder = Value.newBuilder();
    JsonFormat.parser().merge(value, builder);
    return builder.build();
  }
}
```

### Generate embeddings from video

Use the following sample to generating embeddings for video content.

The following example uses a video located in Cloud Storage. You can also use the `video.bytesBase64Encoded` field to provide a base64-encoded string representation of the video.

Before using any of the request data, make the following replacements:

- LOCATION: Your project's region. For example, `us-central1`, `europe-west2`, or `asia-northeast3`. For a list of available regions, see [Generative AI on Vertex AI locations](https://cloud.google.com/vertex-ai/generative-ai/docs/learn/locations-genai).
- PROJECT_ID: Your Google Cloud [project ID](https://cloud.google.com/resource-manager/docs/creating-managing-projects#identifiers).
- VIDEO_URI: The Cloud Storage URI of the target video to get embeddings for. For example, `gs://my-bucket/embeddings/supermarket-video.mp4`.

You can also provide the video as a base64-encoded byte string:

```
[...]
"video": {
    "bytesBase64Encoded": "B64_ENCODED_VIDEO"
}
[...]
```

- `videoSegmentConfig` (START_SECOND, END_SECOND, INTERVAL_SECONDS). Optional. The specific video segments (in seconds) the embeddings are generated for.

For example:

```
[...]
"videoSegmentConfig": {
    "startOffsetSec": 10,
    "endOffsetSec": 60,
    "intervalSec": 10
}
[...]
```

Using this config specifies video data from 10 seconds to 60 seconds and generates embeddings for the following 10 second video intervals: [10, 20), [20, 30), [30, 40), [40, 50), [50, 60). This video interval (`"intervalSec": 10`) falls in the [Standard video embedding mode](https://cloud.google.com/vertex-ai/generative-ai/docs/embeddings/get-multimodal-embeddings#video-modes), and the user is charged at the [Standard mode pricing rate](https://cloud.google.com/vertex-ai/generative-ai/pricing).

If you omit `videoSegmentConfig`, the service uses the following default values: `"videoSegmentConfig": { "startOffsetSec": 0, "endOffsetSec": 120, "intervalSec": 16 }`. This video interval (`"intervalSec": 16`) falls in the [Essential video embedding mode](https://cloud.google.com/vertex-ai/generative-ai/docs/embeddings/get-multimodal-embeddings#video-modes), and the user is charged at the [Essential mode pricing rate](https://cloud.google.com/vertex-ai/generative-ai/pricing).

HTTP method and URL:

```
POST https://LOCATION-aiplatform.googleapis.com/v1/projects/PROJECT_ID/locations/LOCATION/publishers/google/models/multimodalembedding@001:predict
```

Request JSON body:

```
{
  "instances": [\
    {\
      "video": {\
        "gcsUri": "VIDEO_URI",\
        "videoSegmentConfig": {\
          "startOffsetSec": START_SECOND,\
          "endOffsetSec": END_SECOND,\
          "intervalSec": INTERVAL_SECONDS\
        }\
      }\
    }\
  ]\
}
```

Save the request body in a file named `request.json`, and execute the following command:

```
curl -X POST \
     -H "Authorization: Bearer $(gcloud auth print-access-token)" \
     -H "Content-Type: application/json; charset=utf-8" \
     -d @request.json \
     "https://LOCATION-aiplatform.googleapis.com/v1/projects/PROJECT_ID/locations/LOCATION/publishers/google/models/multimodalembedding@001:predict"
```

The embedding the model returns is a 1408 float vector. The following sample responses are shortened for space.

**Response (7 second video, no `videoSegmentConfig` specified):**

```
{
  "predictions": [\
    {\
      "videoEmbeddings": [\
        {\
          "endOffsetSec": 7,\
          "embedding": [\
            -0.0045467657,\
            0.0258095954,\
            0.0146885719,\
            0.00945400633,\
            [...]\
            -0.0023291884,\
            -0.00493789,\
            0.00975185353,\
            0.0168156829\
          ],\
          "startOffsetSec": 0\
        }\
      ]\
    }\
  ],\
  "deployedModelId": "DEPLOYED_MODEL_ID"\
}
```

**Response (59 second video, with the following video segment config: `"videoSegmentConfig": { "startOffsetSec": 0, "endOffsetSec": 60, "intervalSec": 10 }`):**

```
{
  "predictions": [\
    {\
      "videoEmbeddings": [\
        {\
          "endOffsetSec": 10,\
          "startOffsetSec": 0,\
          "embedding": [\
            -0.00683252793,\
            0.0390476175,\
            [...]\
            0.00657121744,\
            0.013023301\
          ]\
        },\
        {\
          "startOffsetSec": 10,\
          "endOffsetSec": 20,\
          "embedding": [\
            -0.0104404651,\
            0.0357737206,\
            [...]\
            0.00509833824,\
            0.0131902946\
          ]\
        },\
        {\
          "startOffsetSec": 20,\
          "embedding": [\
            -0.0113538112,\
            0.0305239167,\
            [...]\
            -0.00195809244,\
            0.00941874553\
          ],\
          "endOffsetSec": 30\
        },\
        {\
          "embedding": [\
            -0.00299320649,\
            0.0322436653,\
            [...]\
            -0.00993082579,\
            0.00968887936\
          ],\
          "startOffsetSec": 30,\
          "endOffsetSec": 40\
        },\
        {\
          "endOffsetSec": 50,\
          "startOffsetSec": 40,\
          "embedding": [\
            -0.00591270532,\
            0.0368893594,\
            [...]\
            -0.00219071587,\
            0.0042470959\
          ]\
        },\
        {\
          "embedding": [\
            -0.00458270218,\
            0.0368121453,\
            [...]\
            -0.00317760976,\
            0.00595594104\
          ],\
          "endOffsetSec": 59,\
          "startOffsetSec": 50\
        }\
      ]\
    }\
  ],\
  "deployedModelId": "DEPLOYED_MODEL_ID"\
}
```

```python
import vertexai

from vertexai.vision_models import MultiModalEmbeddingModel, Video
from vertexai.vision_models import VideoSegmentConfig

# TODO(developer): Update & uncomment line below
# PROJECT_ID = "your-project-id"
vertexai.init(project=PROJECT_ID, location="us-central1")

model = MultiModalEmbeddingModel.from_pretrained("multimodalembedding@001")

embeddings = model.get_embeddings(
    video=Video.load_from_file(
        "gs://cloud-samples-data/vertex-ai-vision/highway_vehicles.mp4"
    ),
    video_segment_config=VideoSegmentConfig(end_offset_sec=1),
)

# Video Embeddings are segmented based on the video_segment_config.
print("Video Embeddings:")
for video_embedding in embeddings.video_embeddings:
    print(
        f"Video Segment: {video_embedding.start_offset_sec} - {video_embedding.end_offset_sec}"
    )
    print(f"Embedding: {video_embedding.embedding}")

# Example response:
# Video Embeddings:
# Video Segment: 0.0 - 1.0
# Embedding: [-0.0206376351, 0.0123456789, ...]
```

### Advanced use case

Use the following sample to get embeddings for video, text, and image content.

This sample uses a video located in Cloud Storage. You can also use the `video.bytesBase64Encoded` field to provide a base64-encoded string representation of the video.

Before using any of the request data, make the following replacements:

- LOCATION: Your project's region. For example, `us-central1`, `europe-west2`, or `asia-northeast3`. For a list of available regions, see [Generative AI on Vertex AI locations](https://cloud.google.com/vertex-ai/generative-ai/docs/learn/locations-genai).
- PROJECT_ID: Your Google Cloud [project ID](https://cloud.google.com/resource-manager/docs/creating-managing-projects#identifiers).
- TEXT: The target text to get embeddings for. For example, `a cat`.
- IMAGE_URI: The Cloud Storage URI of the target image to get embeddings for. For example, `gs://my-bucket/embeddings/supermarket-img.png`.
- VIDEO_URI: The Cloud Storage URI of the target video to get embeddings for. For example, `gs://my-bucket/embeddings/supermarket-video.mp4`.

You can also provide the image or video as a base64-encoded byte string.

HTTP method and URL:

```
POST https://LOCATION-aiplatform.googleapis.com/v1/projects/PROJECT_ID/locations/LOCATION/publishers/google/models/multimodalembedding@001:predict
```

Request JSON body:

```
{
  "instances": [\
    {\
      "text": "TEXT",\
      "image": {\
        "gcsUri": "IMAGE_URI"\
      },\
      "video": {\
        "gcsUri": "VIDEO_URI",\
        "videoSegmentConfig": {\
          "startOffsetSec": START_SECOND,\
          "endOffsetSec": END_SECOND,\
          "intervalSec": INTERVAL_SECONDS\
        }\
      }\
    }\
  ]\
}
```

Save the request body in a file named `request.json`, and execute the following command:

```
curl -X POST \
     -H "Authorization: Bearer $(gcloud auth print-access-token)" \
     -H "Content-Type: application/json; charset=utf-8" \
     -d @request.json \
     "https://LOCATION-aiplatform.googleapis.com/v1/projects/PROJECT_ID/locations/LOCATION/publishers/google/models/multimodalembedding@001:predict"
```

The embedding the model returns is a 1408 float vector. The following sample response is shortened for space.

```
{
  "predictions": [\
    {\
      "textEmbedding": [\
        0.0105433334,\
        -0.00302835181,\
        0.00656806398,\
        0.00603460241,\
        [...]\
        0.00445805816,\
        0.0139605571,\
        -0.00170318608,\
        -0.00490092579\
      ],\
      "videoEmbeddings": [\
        {\
          "startOffsetSec": 0,\
          "endOffsetSec": 7,\
          "embedding": [\
            -0.00673126569,\
            0.0248149596,\
            0.0128901172,\
            0.0107588246,\
            [...]\
            -0.00180952181,\
            -0.0054573305,\
            0.0117037306,\
            0.0169312079\
          ]\
        }\
      ],\
      "imageEmbedding": [\
        -0.00728622358,\
        0.031021487,\
        -0.00206603738,\
        0.0273937676,\
        [...]\
        -0.00204976718,\
        0.00321615417,\
        0.0121978866,\
        0.0193375275\
      ]\
    }\
  ],\
  "deployedModelId": "DEPLOYED_MODEL_ID"\
}
```

```python
import vertexai

from vertexai.vision_models import Image, MultiModalEmbeddingModel, Video
from vertexai.vision_models import VideoSegmentConfig

# TODO(developer): Update & uncomment line below
# PROJECT_ID = "your-project-id"
vertexai.init(project=PROJECT_ID, location="us-central1")

model = MultiModalEmbeddingModel.from_pretrained("multimodalembedding@001")

image = Image.load_from_file(
    "gs://cloud-samples-data/vertex-ai/llm/prompts/landmark1.png"
)
video = Video.load_from_file(
    "gs://cloud-samples-data/vertex-ai-vision/highway_vehicles.mp4"
)

embeddings = model.get_embeddings(
    image=image,
    video=video,
    video_segment_config=VideoSegmentConfig(end_offset_sec=1),
    contextual_text="Cars on Highway",
)

print(f"Image Embedding: {embeddings.image_embedding}")

# Video Embeddings are segmented based on the video_segment_config.
print("Video Embeddings:")
for video_embedding in embeddings.video_embeddings:
    print(
        f"Video Segment: {video_embedding.start_offset_sec} - {video_embedding.end_offset_sec}"
    )
    print(f"Embedding: {video_embedding.embedding}")

print(f"Text Embedding: {embeddings.text_embedding}")
# Example response:
# Image Embedding: [-0.0123144267, 0.0727186054, 0.000201397663, ...]
# Video Embeddings:
# Video Segment: 0.0 - 1.0
# Embedding: [-0.0206376351, 0.0345234685, ...]
# Text Embedding: [-0.0207006838, -0.00251058186, ...]
```

To learn how to install or update the Vertex AI SDK for Python, see [Install the Vertex AI SDK for Python](https://cloud.google.com/vertex-ai/docs/start/use-vertex-ai-python-sdk).

For more information, see the [Python API reference documentation](https://cloud.google.com/python/docs/reference/aiplatform/latest).

## What's next

For detailed documentation, see the following:

- [Get multimodal embeddings](https://cloud.google.com/vertex-ai/generative-ai/docs/embeddings/get-multimodal-embeddings)

</details>

<details>
<summary>Optimizing ColPali for Retrieval at Scale, 13x Faster Results</summary>

# Optimizing ColPali for Retrieval at Scale, 13x Faster Results

Evgeniya Sukhodolskaya, Sabrina Aquino

November 27, 2024

https://qdrant.tech/blog/colpali-qdrant-optimization/preview/title.jpg

ColPali is a fascinating leap in document retrieval. Its precision in handling visually rich PDFs is phenomenal, but scaling it to handle real-world datasets comes with its share of computational challenges.

Here’s how we solved these challenges to make ColPali 13x faster without sacrificing the precision it’s known for.

## The Scaling Dilemma

ColPali generates **1,030 vectors for just one page of a PDF.** While this is manageable for small-scale tasks, in a real-world production setting where you may need to store hundreds of thousands of PDFs, the challenge of scaling becomes significant.

Consider this scenario:

- **Dataset Size:** 20,000 PDF pages.
- **Number of Vectors:** Each page generates ~1,000 vectors of 128 dimensions.

The total number of comparisons is calculated as:

1,000⋅1,000⋅20,000⋅128 = 2.56×10^12 comparisons!

That’s trillions of comparisons needed to build the index. Even advanced indexing algorithms like HNSW struggle with this scale, as computational costs grow quadratically with amount of multivectors per page.

We turned to a hybrid optimization strategy combining pooling (to reduce computational overhead) and reranking (to preserve accuracy).

For those eager to explore, the codebase is available here: https://github.com/qdrant/demo-colpali-optimized

## Two-Stage Retrieval Process

### Pooling

Pooling is well-known in machine learning as a way to compress data while keeping important information. For ColPali, we reduced 1,030 vectors per page to just 38 vectors by pooling rows in the document’s 32x32 grid.

https://qdrant.tech/blog/colpali-optimization/rows.png

Max and mean pooling are the two most popular types, so we decided to test both approaches on the rows of the grid. Likewise, we could apply pooling on columns, which we plan to explore in the future.

- **Mean Pooling:** Averages values across rows.
- **Max Pooling:** Selects the maximum value for each feature.

32 vectors represent the pooled rows, while 6 vectors encode contextual information derived from ColPali’s special tokens (e.g., for the beginning of the sequence, and task-specific instructions like “Describe the image”).

For our experiments, we chose to preserve these 6 additional vectors.

### The “ColPali as a Reranker” Experiment

Pooling drastically reduces retrieval costs, but there’s a risk of losing fine-grained precision. To address this, we implemented a two-stage retrieval system, where embeddings generated with ColPali were max/mean pooled by grid rows to create lightweight vectors for the initial retrieval stage, followed by reranking with the original high-resolution embeddings:

1. **Pooled Retrieval:** Quickly retrieves the top 200 candidates using lightweight pooled embeddings.
2. **Full Reranking:** Refines these candidates using the original, high-resolution embeddings, delivering the final top 20 results.

## Implementation

We created a custom dataset with over 20,000 unique PDF pages by merging:

- **ViDoRe Benchmark:** Designed for PDF documents retrieval evaluation.
- **UFO Dataset:** Visually rich documents paired with synthetic queries generated by Daniel van Strien.
- **DocVQA Dataset:** A large set of document-derived Q&A pairs.

Each document was processed into 32x32 grids, generating both full-resolution and pooled embeddings. **Full-resolution** embeddings consisted of 1,030 vectors per page, while **pooled embeddings** included mean and max pooling variants.

All embeddings were stored and kept in RAM to avoid caching effects during retrieval speed experiments.

## Experiment Setup

We evaluated retrieval quality with 1,000 queries. First, pooled embeddings retrieved the top 200 candidates. Then, full-resolution embeddings reranked them to produce the final top 20 results.

To measure performance, we used:

- **NDCG@20:** Measures ranking quality (how well the top results align with expectations).
- **Recall@20:** Measures the overlap between this method and the original ColPali retrieval.

## Results

The experiment showed promising improvements in speed and accuracy. Retrieval time improved **13x** compared to using full-resolution embeddings alone.

### Metrics

| Pooling Type | NDCG@20 | Recall@20 |
| --- | --- | --- |
| **Mean** | 0.952 | 0.917 |
| **Max** | 0.759 | 0.656 |

Mean pooling preserved nearly identical quality to the original ColPali, with NDCG@20 = 0.952 and Recall@20 = 0.917. Max pooling did not perform well enough to be considered viable since it sacrificed significant accuracy without delivering a meaningful speed advantage.

## What’s Next?

Future experiments could push these results even further:

- Investigating column-wise pooling for additional compression.
- Testing half-precision (float16) vectors to balance memory use and speed.
- Skipping special multivectors during prefetch to streamline retrieval.
- Combining quantization with oversampling for even faster search.

## Try It Yourself

- **Demo Notebook:** https://github.com/qdrant/demo-colpali-optimized

</details>

<details>
<summary>Scaling ColPali to billions of PDFs with Vespa</summary>

# Scaling ColPali to billions of PDFs with Vespa

https://blog.vespa.ai/assets/2024-09-14-scaling-colpali-to-billions/colpali.jpg

This blog post deep dives into scaling [“ColPali: Efficient Document Retrieval\
with Vision Language Models”](https://arxiv.org/abs/2407.01449) to large collections of documents. We demonstrate
how we can use a [phased retrieval and ranking](https://docs.vespa.ai/en/phased-ranking.html)
pipeline in Vespa to scale ColPali to billions of documents. To do this, we introduce a new similarity function,
a hamming based MaxSim that works with binary vectors produced by binary quantization (BQ). This technique
allows us to scale ColPali to large collections of documents while maintaining high accuracy, with a significant reduction in computational cost
and vector storage requirements. The suggested deployment also supports real-time indexing and CRUD operation support.

## Introduction

ColPali surpasses traditional text-based
retrieval methods by leveraging a vision-capable language model, ( [PaliGemma](https://huggingface.co/blog/paligemma)),
to “see” the text, but also the visual elements of a page, including figures, tables and infographics.

ColPali is short for _Contextualized Late Interaction over PaliGemma_ and builds on two key concepts:

- **Contextualized Vision Embeddings from a Vision Language Model (VLM):**
ColPali generates contextualized embeddings directly from images of pages,
using [PaliGemma](https://huggingface.co/blog/paligemma), a powerful VLM with strong visual text understanding capabilities.

- **Late Interaction** ColPali uses a late interaction similarity function
to compare query and document embeddings at query time, allowing for interaction between
all the image grid cell vector representations and all the query text token vector representations.

For a longer introduction to ColPali, see [Beyond Text: The Rise of Vision-Driven Document Retrieval for RAG](https://blog.vespa.ai/the-rise-of-vision-driven-document-retrieval-for-rag/)

## Do not sleep on VLMs

VLMs have gained popularity for their ability to understand and generate text based on
combined text and visual inputs.
VLMs display enhanced capabilities in Visual Question Answering (VQA),
captioning, and document understanding tasks.

The ColPali model builds on this foundation to tackle the challenge of _document retrieval_,
where the goal is to find relevant documents (pages) based on a user query.
The top-k retrieved pages from ColPali could be used for further processing, like summarization or question answering.

https://blog.vespa.ai/assets/2024-09-14-scaling-colpali-to-billions/illustration2.png
_VLM document understanding example. The input to the VLM model is a text question and an image._
_The VLM generates an answer (output) based on the question and the image._

The above illustrates how a VLM can read complex infographics or text rendered in images.
The above uses the [Qwen/Qwen2-VL-7B-Instruct](https://huggingface.co/Qwen/Qwen2-VL-7B-Instruct) VLM.

In this example, we provide the VLM with an image of a document page along with a question, and it generates an answer. However, in the context of document retrieval, the goal is to efficiently retrieve the most relevant documents based on a user query, even when working with large collections. Instead of repeating the above process for every page in the collection—which could take days or even years for a single query on a large scale—this approach aims to streamline retrieval and avoid inefficiencies.

Instead, during offline processing of the PDFs, we obtain embeddings for all the pages in the collection,
and at query time, run a similarity search over the page embeddings to find the k (e.g. 10) most relevant pages.

This is the approach taken by ColPali and the late interaction similarity mechanism.
After having retrieved relevant pages for a query, we can feed the retrieved pages to a VLM for
further processing, like summarization or question answering, as demonstrated in the example above.

## Scaling VLM retrieval with ColPali

ColPali produces [tensors](https://docs.vespa.ai/en/tensor-user-guide.html) for both the query and the page (technically,
the image of a page). The query tensor is made up of text tokens, while the page tensor is made up of image grid cell vectors.

**ColPali Page Embeddings:** ColPali generates contextualized
embeddings solely from images of PDF pages, bypassing the need
for text extraction, [OCR](https://en.wikipedia.org/wiki/Optical_character_recognition), and layout analysis.
Each image is represented as a 32x32 = 1024 image grid (patches),
where each patch is projected into a 128-dimensional _latent_ vector space.
In addition to these patch tokens, there is six instruction text tokens that are prepended to the image input:
_(“Describe the image.”)_. In total, a single screenshot of a PDF page is represented by 1030 128-d vectors.

https://blog.vespa.ai/assets/2024-09-14-scaling-colpali-to-billions/colpali-indexing.png

**ColPali Query Text Embeddings:** The query text is tokenized and each token is also represented in the same latent 128-dimensional vector space as the patch embeddings.
The number of query tokens is dynamic (not fixed length as the patch embeddings).
The query tokens also include a prefix instruction, _“Question: “_, and mask padding tokens.
This is similar to the query expansion mask tokens used in the [ColBERT](https://blog.vespa.ai/pretrained-transformer-language-models-for-search-part-3/)
architecture for the text-only domain.

https://blog.vespa.ai/assets/2024-09-14-scaling-colpali-to-billions/colpali-query.png

Using these tensor reprensentation, we can score documents for a query using the late interaction similarity mechanism.

## Scoring with MaxSim (The Late Interaction part of ColPali)

ColPali employs a so-called late interaction similarity mechanism,
where query and document embeddings are compared at query time using a similarity function,
allowing for interaction between all the page
patch vector representations and the query text token vector representations.

The late interaction similarity mechanism
allows offline embedding generation for all the pages in a collection, and at query time,
score and rank the pages based on the similarity between the query and the document embeddings.

Another name for the similarity mechanism used in ColPali is _MaxSim_,
but a more accurate description would be SumMaxSim, as it involves an outer sum operation over the query tokens.

https://blog.vespa.ai/assets/2024-09-14-scaling-colpali-to-billions/colpali-ranking.png

_MaxSim ranking of the indexed pages for a query. We want to scale this scoring process to billions of pages._

The MaxSim similarity mechanism is a dot product between all the query token embeddings and all the patch embeddings,
followed by a max reduce operation over the patch dimension, followed by a sum reduce operation over the query tokens.

We can represent the tensors and express the MaxSim similarity function using the
Vespa [schema](https://docs.vespa.ai/en/schemas.html) language.

```txt
schema pdf_page {
  document pdf_page {
    field embedding type tensor<float>(p{}, v[128]) {
      indexing: attribute
    }
  }

  model max_sim {
    inputs {
      query(qt) tensor<float>(q{}, v[128])
    }
    function max_sim(query, page) {
      expression {
        sum(
          reduce(
            sum(
              query * page , v
            ),
            max,
            p
          ),
        q
        )
      }
    }
    first-phase {
      expression: max_sim(query(qt), attribute(embedding))
    }
  }
}
```

Both the `embedding` field and the input query tensor ( `query(qt)`)
are examples of [mixed tensors](https://docs.vespa.ai/en/tensor-user-guide.html),
combining a named mapped dimension with a named indexed bound dimension ( `v`).
The `v` dimension is bound and has a fixed size of 128, representing the vector dimension.

The `q` and `p` dimensions are unbound and allows representing an unbound number of vectors.
Read more in [tensor guide](https://docs.vespa.ai/en/tensor-user-guide.html).

Let us zoom in on the MaxSim similarity function:

```txt
function max_sim(query, page) {
  expression {
    sum(
      reduce(
        sum(
          query * page , v
        ),
        max,
        p
      ),
      q
    )
  }
}
```

This function returns a single scalar value representing the MaxSim similarity between the query and the page.
The inner sum of `query*page` computes the dot product between all the query token embeddings and all the patch embeddings, which results in
a similarity matrix of size `[q, p]`. We then apply a reduce aggregation over the `p` dimension using max, and finally
sum over the `q` dimension.

This function is configured in a the schema in a Vespa [ranking](https://docs.vespa.ai/en/ranking) expression to rank documents based
on the similarity between the query and the document. See a MaxSim example in the [Vespa tensor playground](https://docs.vespa.ai/playground/#N4KABGBEBmkFxgNrgmUrWQPYAd5QGNIAaFDSPBdDTAF30gGJGwBZAQwA8BlASwFswvAHZgAagFMAzjnYAdYQoCaWAK5gC7URM44ATtKlhaACwlsufQbgl72tXllEiw7cdNlI7wgNYiA5gC6ABQmtLQ4UnAA9NEAJlgEUgB0AG4e7MnsvNESwtHefsL+AJRgOvqGjsLJYAoAcli05qb2YAAGAI6qtgCe7a7CcR2y-hID7AZgqZO87ABGADbSrgQEhhLDLqbm7fxcAgOaiwSqi-bVyQp1wgCSom6FAeW6BlJS1UIP7jJuUgRmfbEMC9NRgADuakWw1ovRwvGOi16q3W72MZikLTyUiweiMqTmHXstD0vHmqmawQk-HmmziAQA+tBeBJoSUJkMOt0+sFOrR2bUFApuBJzDp2PwcMsjC5EAQsItaXpaGApBKpeZ2DgcCEwhEorF-LxTKp5sl5fxoulfgBaPJG4QSaJqyXLG1ayLRJZYebRfZSZp6aLyxW2WjOgHU9hSeKJZJSOIlQWKYQizWLHFIZrCHF6MD+VS8OISXXhSIxWNJNIZLI5PLRbO5m2qTF6G0FosSZJhfiLJNC4QAFTML3V0rALZakK+xc4mzA9P42OqRmCqUQACZAmVoLiwAZ2HEFrxFsbeslIGRUABfK-X0gYajkXAMCQkK8QCj4J80SDCBjcnovTvjQmBvggkCNriAA80CLFg9gAHy8sA97TJu25wMAYAAAxwIgACMxBbsCBH4URJFgBu+EAMzEAALIE16XqBt4YPeV4-p+L4QW+D6-pQaAfpg-4QaMfHCZ+4FQFBeiwfBSHBDgqHAuuW4lFhuHkcRgSkdplHUYgdGMcxwlsTe-EQFxUA8YQIECd+kkyQww7mLuizweCzy8EYJhYOCxhYC8lRohwPACBOHzFD8niycFbwfE4KQsTQ5kQBxj7CdggmQBJoFflQTl-gw+ycB8-D2fl0mQAYcSqOswS1fVEjBFIqj8LyPRAWAABUYDicQqQlMCpXAjgw2qu1wKdCUKXsXellCfltmQEQi2foJ1mfvQEGuWA7mec8Uh+eCRg7F8gZLvS9jmAGEiRPte6bPVFxOOwiz9aoeg4FgmIpGAe0Hf5zzymcwy0vFGzDNGj0ef5RheaYgV6ACyQSD57UDgO7S0LiqPozm7XBIAGASdKkxA4KkNqIZ0OCAJgE01db0Y3sGM7JzTeC2cVlK15Q5hWgZ+olQPswi9AyCS0Ay+hYHVBC0FIlW-tVbUdYByJ9QNQ0c+lXOZctOV8+Qm1FcLkClQyWDpHo0tK+Q1VNQ1ovi5L0t6LL9UKyNXBjbNZl66g1nZa+dtQCbgtQGbquW9bDKdKHUkMI7LUW1btjS8CqvEDNOtgGlecoIEIDXkAA).
```

In [PyTorch](https://pytorch.org/), a popular deep learning framework, we could express the MaxSim as a function as follows
using the `torch.einsum` [function](https://pytorch.org/docs/stable/generated/torch.einsum.html):

```
def max_sim(query, page):
  """
  Computes the MaxSim similarity between query and page tensors using einsum.

  Args:
    query: Tensor of shape [querytoken, 128] representing query token vectors.
    page: Tensor of shape [patch, 128] representing page patch vectors.

  Returns:
     the MaxSim similarity score.
  """
  return torch.sum(torch.einsum('qv,pv->qp', query, page).max(dim=1).values, dim=0)
```

Explanation of the Pytorch `max_sim` function above:

1. **torch.einsum(‘qv,pv->qp’, query, page)**:
Calculates the dot product between `q` and `p` vectors, resulting in a similarity matrix of size `[q, p]`.

   - `qv` represents the query tensor with dimensions querytoken ( `q`) and vector ( `v`).
   - `pv` represents the page tensor with dimensions patch ( `p`) and vector ( `v`).
   - `->qp` specifies the output tensor with dimensions querytoken ( `q`) and patch ( `p`).
2. **.max(dim=1).values**:
Finds the maximum value along each row (each query token) of the similarity matrix.
Returns a tensor of size `[q]` containing the maximum similarity scores for each query token.
3. **.sum(dim=0)**:
Sums the maximum similarity scores across all query tokens, producing a single scalar value representing the overall MaxSim similarity between the query and the page.

Note that PyTorch does not support unbound dimensions (mapped) or dimension names like Vespa tensors,
so we have to specify the dimension sizes.

### Scaling MaxSim

MaxSim FLOPs scales with `[q * p * v]` (roughly). We can reduce the FLOPs
by reducing the number of query tokens ( `q`), the number of patch vectors ( `p`), or the vector dimensionionality ( `v`).

We are interested in scaling a pre-trained model checkpoint and architecture to larger collections of documents, changing
the dimensionality ( `v`) would require retraining the model.

We can reduce the number of patch vector embeddings by pooling or clustering.
See the excellent work from [Answer.ai](https://answer.ai/) on reducing the number of document vectors
in their blog post: [A little pooling goes a long way for multi-vector representations](https://www.answer.ai/posts/colbert-pooling.html).

Another direction is to use a cheaper similarity function than dot product,
in other words, a function that requires fewer CPU instructions than float dot products. This
can also be used in combination with pooling or clustering to reduce the number of vectors to score.

An alternative to a float dot product is the inverted [hamming distance](https://en.wikipedia.org/wiki/Hamming_distance),
which is a simple and fast distance function. The hamming distance is the number of positions at which the corresponding bits are different,
and can be computed with fewer CPU instructions than a float dot product.

To use `hamming` distance in Vespa, we need to represent the ColPali text and patch vectors as binary vectors,
using the [int8 tensor cell type](https://docs.vespa.ai/en/tensor-user-guide.html) in Vespa, where we can
“pack” the 128-dim float vectors into 16-dim `int8` tensors in Vespa. Each `int8` cell represents 8 bits.

The following demonstrates how we can use the [hamming](https://docs.vespa.ai/en/reference/ranking-expressions.html#hamming-x-y)
distance instead of float dot product as the core similarity in MaxSim.
Since [hamming](https://docs.vespa.ai/en/reference/ranking-expressions.html#hamming-x-y)
is a distance metric (closer to 0 is more similar), we invert the distance to a similarity score by inversion: `1/(1 + hamming(query, page))`.

(Note that [hamming](https://docs.vespa.ai/en/reference/ranking-expressions.html#hamming-x-y) is
a built in Vespa ranking expression function):

```txt
schema pdf_page {
  document pdf_page {
    field embedding type tensor<int8>(p{}, v[16]) {
      indexing: attribute
    }
  }

  model max_sim {
    inputs {
      query(qt) tensor<int8>(q{}, v[16])
    }
    function max_sim(query, page) {
      expression {
        sum(
          reduce(
            1/(1 + sum(
              hamming(query, page) ,v)
            ),
            max,
            p
          ),
          q
        )
      }
    }

    first-phase {
      expression: max_sim(query(qt), attribute(embedding))
    }
  }
}
```

We use binary quantization (BQ) to convert the floating point 128-dimensional vectors to 128-bit vectors, represented in the schema
as 16-d vector with cell type [int8](https://docs.vespa.ai/en/reference/tensor.html#tensor-type-spec). See our
blog post on [Matryoshka 🤝 Binary vectors: Slash vector search costs with Vespa](https://blog.vespa.ai/combining-matryoshka-with-binary-quantization-using-embedder/)
for more information about hamming distance and binary quantization.

With this approach, we can reduce the number of CPU instructions required to compute the similarity between the query and the document,
making the MaxSim ranking process more efficient.

#### Optimizing the MaxSim with hamming

In this [Vespa performance test](https://github.com/vespa-engine/system-test/tree/master/tests/performance/mixed_tensor_max_sim),
we measure and track the difference in latency between the two versions of the MaxSim function.

This test simulates ranking 1,000 pages for a query with 20 vectors and 1030 vectors per page, using a single CPU core. It’s important
to notice that we can scale latency linearly (almost) with the number of CPU cores by Vespa
[intra-query multi-threading](https://docs.vespa.ai/en/performance/sizing-search.html#reduce-latency-with-multi-threaded-per-search-execution).

In the performance test we measure the end-to-end latency of
the two MaxSim versions. With a single ranking thread, latency is a
good proxy for computional cost.

https://blog.vespa.ai/assets/2024-09-14-scaling-colpali-to-billions/latency.png

The blue line represents the hamming distance version of the MaxSim function,
while the orange line represents the float dot product version.
As we can
see the hamming version is about 3.5 times faster than the float dot product version.
This means that we can rank more pages for the same latency budget or
lower the latency for the user query.
For services that doesn’t nessessarily need high query throughput, but were we want
to lower latency for a better user experience, we can throw CPU cores at the
problem using [intra-query multithreading](https://docs.vespa.ai/en/performance/sizing-search.html#reduce-latency-with-multi-threaded-per-search-execution)
to reduce latency further, e.g by using 2 or 4 CPU cores we can reduce latency by a factor of 2 or 4, respectively.

With 1000 pages, 20 query token vectors, and 1030 patch vectors, the MaxSim involves 20M 128-dimensions dot products or 128-dimensions hamming distances (bitwise). For the hamming version, with 100ms latency, this
translates to about 200M 128-bit hamming distances per second per CPU core/thread.

As part of this work with scaling ColPali, we optimized
the evaluation of the `1/(1 + sum(hamming(query, page), v))` expression. This is done by recognizing the specific use case,
allowing for HW optimized evaluation by the Vespa tensor engine. This
type of optimization was already in place for the float dot product version after our work with [ColBERT](https://blog.vespa.ai/pretrained-transformer-language-models-for-search-part-3/).

### Scaling to Billions of Documents

So far we have discussed how to compute the MaxSim similarity function without considering the scale of the document collection.
Performing MaxSim over 1000 pages in an index is not a huge problem. We can
brute-force score and rank all of them for every query.

But at larger scale (either #documents or #queries), we need to distribute the computation across multiple nodes
and also find a way to perform candidate selection (retrieval) so that we avoid scoring all the pages (brute-force) with the MaxSim expression.
This is where Vespa’s [phased retrieval and ranking](https://docs.vespa.ai/en/phased-ranking.html) pipeline comes into play.

The standard retrieval strategy for ColBERT and ColPali
is to use approximate [nearestNeighbor](https://docs.vespa.ai/en/approximate-nn-hnsw.html)
search to retrieve candidate documents based on the query token embeddings, and then rank the retrieved documents using MaxSim.

For example, if we have 20 query token vectors, we do a candidate search for each of the 20 query token vectors and the union
of the candidate sets are ranked using MaxSim. Each nearest neighbor operation finds the closest `k` pages with the closest
patch vector to the query token vector.

Vespa supports [multi-vector HNSW indexing](https://blog.vespa.ai/semantic-search-with-multi-vector-indexing/),
so we can index multiple patch vectors per page, and perform approximate nearest neighbor search over all the patch vectors
in a single query.

```txt
field embedding type tensor<int8>(p{}, v[16]) {
  indexing: attribute | index
  attribute {
    distance-metric: hamming
  }
  index {
    hnsw {
      max-links-per-node: 32
      neighbors-to-explore-at-insert: 200
    }
  }
}
```

We use the [hamming distance metric](https://docs.vespa.ai/en/reference/schema-reference.html#hamming)
for this index. We enable [HNSW](https://docs.vespa.ai/en/approximate-nn-hnsw.html) by adding `index`
to the `embedding` field in the schema. Notice also how we configure the `distance-metric` and HNSW index hyper parameters
that are tradoffs between speed and accuracy (comparing to exact nearest neighbor search).

For a single query token vector we could do a nearest neighbor search over all the patch vectors using
the Vespa [nearestNeighbor](https://docs.vespa.ai/en/reference/query-language-reference.html#nearestneighbor) query operator
using the Vespa [query language](https://docs.vespa.ai/en/query-language.html):

```
{
  "yql": "select documentid, embedding from pdf_page where {targetHits:100}nearestNeighbor(embedding,q1)",
  "input.query(q1)": [23,-34,12,45,67,23,45,12,45,67,23,45,12,45,67,23],
  "ranking": "vector_similarity_only",
  "hits": 100
}
```

This query would return the 100 closest pages to the query token vector `q1` based on the hamming distance to the closest patch vector in the page.

However, we do not want to run one nearest neighbor query for each query token vector, but rather run a single Vespa
query that exposes the top-k pages for all the query token vectors to a Vespa ranking expression. This allows
scoring and ranking using MaxSim **without**
**transferring the page vectors to some external ranking service**.

Why? Consider the case where we have 20 query token vectors, and where
we want to retrieve the top-100 pages for each query token vector for MaxSim re-ranking,
we would have up to 2K (20x100) pages to rank using a MaxSim implementation.
Each page is made up of 1030 vectors with 16 bytes (int8 values), each
user query request would need to transfer 2K x 1030 x 16 bytes ±= 32MB of data to
the “MaxSim ranking service”. This is sequential latency added _before_ we start scoring the pages with MaxSim.

**At any meaningful query throughput**
**scale, fetching this amount of vector data per user query would quickly become a**
**scaling bottleneck even with a fast high-throughput network**.

Instead, we want to move the tensor computations (here MaxSim) to the data and
instead perform the candidate selection and ranking in a single Vespa query request using
multiple nearest neighbor operators, combined using boolean operators (which also allows combining
ColPali/ColBERT with [query filters](https://blog.vespa.ai/constrained-approximate-nearest-neighbor-search/)).

```
{
  "yql": "select documentid from pdf_page where ({targetHits:100}nearestNeighbor(embedding,q1)) or ({targetHits:100}nearestNeighbor(embedding,q2))",
  "input.query(q1)": [23,-34,12,45,67,23,45,12,45,67,23,45,12,45,67,23],
  "input.query(q2)": [12,4,87,23,45,12,45,67,23,45,12,45,67,23,45,12],
  ....
  "ranking": "max_sim",
  "hits": 10
}
```

A Vespa schema for scalable retrieval and ranking of ColPali could look like this, note that all the input query tensors are
[defined](https://docs.vespa.ai/en/tensor-user-guide.html#querying-with-tensors)
in the `model` section of the schema ( `model` is also an alias for `rank-profile`). We can define as many
input query tensors as we want or need. Defining query tensors
has no overhead, as the input tensors are only used when a query is executed.

```txt
schema pdf_page {
  document pdf_page {
    field embedding type tensor<int8>(p{}, v[16]) {
      indexing: attribute | index
      attribute {
        distance-metric: hamming
      }
      index {
        hnsw {
          max-links-per-node: 32
          neighbors-to-explore-at-insert: 200
        }
      }
    }
  }

  model max_sim {
    inputs {
      query(qt) tensor<int8>(q{}, v[16])
      query(q1) tensor<int8>(v[16])
      query(q2) tensor<int8>(v[16])
      query(q3) tensor<int8>(v[16])
      query(q4) tensor<int8>(v[16])
      ....
    }
    function max_sim(query, page) {
      expression {
        sum(
          reduce(
            1/(1 + sum(
              hamming(query, page) ,v)
            ),
            max,
            p
          ),
          q
        )
      }
    }
    first-phase {
      expression: max_sim(query(qt), attribute(embedding))
    }
  }
}
```

With this type of schema, we can perform a query request where we both retrieve candidate documents and rank them in a single request as the `nearestNeighbor` query operator in Vespa can be combined using boolean operators and combined with filters.

This type of retrieval and ranking pipeline for late-interaction models avoids the need to transfer large amounts of vector data between services
as everything is computed inside the Vespa content nodes. Inside the content node, we can transfer vector data
at the speed of memory and not the network. This is a core design principle in Vespa, allowing developers
to express complex ranking pipelines that might involve lots of vector data in a single query request.

Note that with the query tensor separation, where there are N single-vector representing each query token vector and a single mixed
tensor used for the MaxSim ranking, we can also perform query token pruning. By using a subset of the query token vectors
we can speed up the retrieval phase, and rank fewer pages with the MaxSim variants. Pruning attempts to
remove less important query token vectors from the _retrieval_ phase while they are retained for the ranking phase.
This query tensor separation also allows different levels of `targetHits` per query token vector
for the retrieval phase.

## Is hamming a good similarity function for ColPali?

In the previous sections, we discussed how to scale ColPali to billions of documents using
Vespa’s phased retrieval and ranking pipeline, using hamming
distance for the nearest neighbor search and MaxSim for ranking. How does this approach perform in practice?

We evaluated the performance of the ColPali model on the [DocVQA dataset](https://www.docvqa.org/datasets/docvqa) using the ColPali embeddings and the
proposed hamming-based MaxSim function in Vespa.

In the following we compare four different ranking strategies on the DocVQA test dataset
using nDCG@5 as the evaluation metric. The four strategies are:

- **float-float** The “normal” float dot product in MaxSim
- **binary-binary** The suggested hamming-based MaxSim
- **binary-binary-reranking** Adding a re-ranking phase on top of the _binary-binary_ version. In the re-ranking phase we are using float
resolution for the query tensor, but an unpacked float representation obtained from the binary vector. This step requires that we pass both the representations of the query tensor to Vespa.

|     |     |
| --- | --- |
| float-float | 52.4 |
| binary-binary (hamming) | 49.5 |
| binary-binary (hamming) + float-float re-ranking | 51.6 |

A notebook that demonstrates the impact of re-ranking depth [can be found here](https://pyvespa.readthedocs.io/en/latest/examples/colpali-benchmark-vqa-vlm_Vespa-cloud.html). As seen from the above table, we can save 32x on storage (memory) by
using the binary representation instead of float, make MaxSim 4x more efficient by using hamming distance, and
retain the most of the accuracy. The drop from 52.4 to 51.6 is a small price to pay for the efficiency gain.

## Summary

ColPali is a groundbreaking document retrieval model, probably one of the most significant advancements in the field of document retrieval in recent years. By leveraging the power of vision language models, ColPali can effectively retrieve documents based on both textual and visual information in them. With the increased interest in scaling ColPali to large collections of PDF documents, Vespa provides a powerful platform for implementing and deploying ColPali at scale.

ColPali or VLMs in general simplifies the ingestion pipeline by eliminating the need for text extraction, OCR, and layout analysis.
This makes it easier to implement and deploy in real-world applications with fewer preprocessing and extraction steps.

As part of this blog, we have also created a comprehensive notebook that demonstrates all the concepts discussed in this blog post,
check it out here: [Scaling ColPali with Vespa](https://pyvespa.readthedocs.io/en/latest/examples/simplified-retrieval-with-colpali-vlm_Vespa-cloud.html).

The demo notebook features:

- Obtaining ColPali embeddings for queries and PDF pages
- How to use the MaxSim similarity function in Vespa and use both versions in a phased ranking pipeline
- How to use the Vespa nearestNeighbor query operator to retrieve candidate documents for ranking

In addition, we also demonstrate how to reproduce the accuracy results on the DocVQA dataset using the ColPali embeddings and the MaxSim similarity functions described in this post: [ColPali Benchmark DocVQA](https://pyvespa.readthedocs.io/en/latest/examples/colpali-benchmark-vqa-vlm_Vespa-cloud.html).

If you want to learn more about ColPali, and how to represent ColPali in Vespa, also check our previous posts on ColPali and Vespa.

- [Beyond Text: The Rise of Vision-Driven Document Retrieval for RAG](https://blog.vespa.ai/the-rise-of-vision-driven-document-retrieval-for-rag/)
- [PDF Retrieval with Vision Language Models](https://blog.vespa.ai/retrieval-with-vision-language-models-colpali/)

Other useful resources on ColPali:

- Notebook [Scaling ColPali with Vespa](https://pyvespa.readthedocs.io/en/latest/examples/simplified-retrieval-with-colpali-vlm_Vespa-cloud.html)
- Notebook [Complex ColPali + Vespa](https://pyvespa.readthedocs.io/en/latest/examples/colpali-document-retrieval-vision-language-models-cloud.html)
- [ColPali Paper](https://arxiv.org/abs/2407.01449)
- [ColPali on GitHub](https://github.com/illuin-tech/colpali)

For those interested in learning more about Vespa or ColPali, feel free to
join the [Vespa community on Slack](https://vespatalk.slack.com/) or [Discord](https://discord.vespa.ai/) to exchange ideas,
seek assistance from the community, or stay in the loop on the latest Vespa developments. Also check out the FAQ section below for more information on how to use ColPali in Vespa.

## FAQ

**Why can’t you just use a frontier like VLM with a large context window for this?**

_Frontier VLM models like GPT-4/Gemini Flash handles visual inputs well (The PDF above is converted to
images of the PDF pages, just like ColPali), but they have a limited context window._

In this case, a 62-page PDF occupies 34,567 tokens so that we can fit about 30 of those into the LLM context window.

We argue that there are use cases where you want to retrieve over more extensive collections than 30.
In addition, as can be seen above, inference takes about 16 seconds for every query over this single PDF.

Certainly, foundational models with large context windows can be used for RAG over small collections, but with high latency.
They are not a universal solution for large collections of complex document formats.

In this case, you turn to ColPali to retrieve relevant pages, and then feed those to the foundational model to generate the best of two paradigms.

**I have many structured text fields and meta data, can I use ColPali in Vespa?**

Yes, you can combine the ColPali embeddings with other features in Vespa.

**Can I combine ColPali with query filters in Vespa?**

Yes, ColPali, is primarily a way to score documents based on a query, and can be combined with any Vespa
[query](https://docs.vespa.ai/en/reference/query-api-reference.html)
formulation, including filters, and also result
[grouping](https://docs.vespa.ai/en/grouping.html).

**Our custom ranking uses many business-oriented ranking signals, can I use ColPali?**

Yes, Vespa’s ranking framework allows many different signals of
[rank features](https://docs.vespa.ai/en/reference/rank-features.html)
as we call them in Vespa. Features can be combined in ranking
expressions in ranking phases.

The MaxSim expression can be used as any other feature, and in combination
with other custom features, even as a feature in a GBDT-based ranker using Vespa’s [xgboost](https://docs.vespa.ai/en/xgboost.html)
or [lightgbm](https://docs.vespa.ai/en/lightgbm.html) support.

**How does ColPali relate to Vespa’s support for nearestNeighbor search?**
If we want to use ColPali representations in **retrieval** and not just for ranking,
we can use the Vespa nearestNeighbor search operator to retrieve candidate documents based on the query token embeddings.
The candidate documents are then ranked using the MaxSim similarity function (and or custom ranking features) in a Vespa ranking expression.

**How does ColPali relate to Vespa HNSW indexing for mixed tensors or multi-vectors?**
It’s handy if we need to use ColPali representations for **retrieval**, allowing
for efficient candidate selection based on the query token embeddings. See more in [multi-vector indexing](https://blog.vespa.ai/semantic-search-with-multi-vector-indexing/).

**Any plans to integrate ColPali as a native [Vespa embedder](https://docs.vespa.ai/en/embedding.html)**

Yes, [see this issue](https://github.com/vespa-engine/vespa/issues/32389).

**Can I combine ColPali with ColBERT in Vespa?**
Yes, you can combine ColPali with ColBERT or SPLADE or other fancier text ranking method in Vespa. Those would be
two different embedding (tensor) fields in the Vespa schema, and you can use two (or multiple)
MaxSim expressions and combine the score in ranking expressions.

**How does ColPali compare to hybrid search?**

ColPali can be used in a [hybrid search\
pipeline](https://blog.vespa.ai/redefining-hybrid-search-possibilities-with-vespa/)
as just another neural scoring feature, used in any of the Vespa
ranking phases (preferably in `second-phase` for optimal performance
to avoid moving vector data up the stateless container for
`global-phase` evaluation).

Vespa allows combining the MaxSim score with other scores using, for
example, [reciprocal rank\
fusion](https://docs.vespa.ai/en/phased-ranking.html#cross-hit-normalization-including-reciprocal-rank-fusion)
or other normalization rank features. The [sample\
application](https://github.com/vespa-engine/sample-apps/tree/master/colbert)
features examples of using ColBERT MaxSim in a hybrid ranking
pipeline.

**Can I run ColPali if I’m GPU-poor?**

Yes, you can. All the notebooks were developed using PyTorch with MPS support on M1 Macs, and the Vespa
content backend is CPU-based.

Encoding the PDF pages takes about 2.5 seconds per page with batches of 4 on MPS (if you ensure to close down Chrome or other GPU-hungry applications). PaliGemma works well with batch size 4 on a 16GB T4 GPU (or similar).

**What are the tradeoffs? If it stores a vector per patch, it must be expensive!**

We can look at performance and deployment cost along three axes:
Effectiveness (ranking quality), storage, and computations. In this
context, we can recommend [Moving Beyond Downstream Task Accuracy\
for Information Retrieval\
Benchmarking](https://aclanthology.org/2023.findings-acl.738.pdf),
which provides a framework to compare different methods.

A natural comparision is recent large decoder-based text embedding models (e.g. [NV-Embed-v2](https://huggingface.co/nvidia/NV-Embed-v2))
that produces 4096-dimensional float embeddings for short texts, their storage footprint is 16KB per chunk (and you will need more
than one chunk to accurately represent a page). ColPali with binarized patch vectors has a similar storage footprint (16KB).

In practise, this means that ColPali is more storage efficient than large decoder-based text embedding models, but requires more computations to score and rank the documents (as we have to compute the MaxSim similarity function).

**Why didn’t you expose the ColBERT 2 [PLAID](https://arxiv.org/abs/2205.09707) retrieval optimization**
**in Vespa? Could this be an alternative for scaling ColPali?**

Primarily because Vespa is designed for low-latency real-time indexing with CRUD support.
The [PLAID indexing optimization](https://arxiv.org/abs/2205.09707) requires batch processing the document token vectors to find
centroids. This centroid selection would not scale in a real-time setting where
users expect outstanding performance from document number one to billions of
documents. As demonstrated in this post, we can replace
the float dot product with a hamming distance, which is a much faster operation than a float dot product and then we can use the Vespa nearestNeighbor query operator to retrieve candidate documents for ranking. This makes the approach more scalable and efficient for real-time document retrieval.

**That is a lot of hamming distances - do you use any acceleration to speed it up?**

Yes, Vespa’s core backend is written in C++, and the dot products and hamming are accelerated
using `SIMD` instructions.

**Is ColPali good or not?** ColPali is a more of a direction than a model checkpoint to rule them all. We believe
in the power of vision language models for complex document retrieval, and we are excited to see how the field evolves.
We envision a future where we can have models trained on different VLM backbones like [Qwen/Qwen2-VL-7B-Instruct](https://huggingface.co/Qwen/Qwen2-VL-7B-Instruct).

**Can I use ColPali for other tasks than document retrieval?**
The ColPali model is actually a Low-Rank Adapter (LoRA) model on top of PaliGemma, so you can use it for any task that PaliGemma is good at
if you remove the adapter layer.

## References

1. [ColPali: Efficient Document Retrieval with Vision Language Models](https://arxiv.org/abs/2407.01449v2)

2. [MMLongBench-Doc: Benchmarking Long-context Document Understanding with Visualizations](https://arxiv.org/abs/2407.01523)

3. [Query Embedding Pruning for Dense Retrieval](https://arxiv.org/abs/2108.10341) , Nicola Tonellotto, Craig Macdonald

4. [An Analysis on Matching Mechanisms and Token Pruning for Late-interaction Models](https://arxiv.org/abs/2403.13291v1)

</details>

<details>
<summary>OCR-free Document Understanding Transformer</summary>

# OCR-free Document Understanding Transformer

Geewook Kim $^ { - 1 }$ ∗, Teakgyu Hong $^ { 4 \\dagger }$ , Moonbin Yim $^ { 2 \\dagger }$ , JeongYeon Nam1, Jinyoung Park $5 \\dagger$ †, Jinyeong Yim $^ { 6 \\dagger }$ , Wonseok Hwang $^ { 7 \\dagger }$ , Sangdoo Yun $^ 3$ , Dongyoon Han $^ 3$ , and Seunghyun Park1

$^ { 1 }$ NAVER CLOVA $^ 2$ NAVER Search $^ 3$ NAVER AI Lab 4Upstage 5Tmax $^ 6$ Google 7LBox

Abstract. Understanding document images (e.g., invoices) is a core but challenging task since it requires complex functions such as reading text and a holistic understanding of the document. Current Visual Document Understanding (VDU) methods outsource the task of reading text to offthe-shelf Optical Character Recognition (OCR) engines and focus on the understanding task with the OCR outputs. Although such OCR-based approaches have shown promising performance, they suffer from 1) high computational costs for using OCR; 2) inflexibility of OCR models on languages or types of documents; 3) OCR error propagation to the subsequent process. To address these issues, in this paper, we introduce a novel OCR-free VDU model named Donut, which stands for Document understanding transformer. As the first step in OCR-free VDU research, we propose a simple architecture (i.e., Transformer) with a pre-training objective (i.e., cross-entropy loss). Donut is conceptually simple yet effective. Through extensive experiments and analyses, we show a simple OCR-free VDU model, Donut, achieves state-of-the-art performances on various VDU tasks in terms of both speed and accuracy. In addition, we offer a synthetic data generator that helps the model pre-training to be flexible in various languages and domains. The code, trained model, and synthetic data are available at [https://github.com/clovaai/donut](https://github.com/clovaai/donut).

Keywords: Visual Document Understanding, Document Information Extraction, Optical Character Recognition, End-to-End Transformer

# 1 Introduction

Document images, such as commercial invoices, receipts, and business cards, are easy to find in modern working environments. To extract useful information from such document images, Visual Document Understanding (VDU) has not been only an essential task for industry, but also a challenging topic for researchers, with applications including document classification \[27,1\], information extraction \[22,42\], and visual question answering \[44,57\].

https://www.ecva.net/papers/eccv_2022/papers_ECCV/papers/images/1780db6c5a77541633d17b805e8c4379756a642c9bbc4a09f089fbea2be6a0ba.jpg

Fig. 1. The schema of the conventional document information extraction (IE) pipeline. (a) The goal is to extract the structured information from a given semistructured document image. In the pipeline, (b) text detection is conducted to obtain text locations and (c) each box is passed to the recognizer to comprehend characters. (d) Finally, the recognized texts and its locations are passed to the following module to be processed for the desired structured form of the information

https://www.ecva.net/papers/eccv_2022/papers_ECCV/papers/images/f048855209e23d13647c78a71e73456ea16bd014899a462a5047afd20fd805e7.jpg

Fig. 2. The pipeline overview and benchmarks. The proposed end-to-end model, Donut, outperforms the recent OCR-dependent VDU models in memory, time cost and accuracy. Performances on visual document IE \[45\] are shown in (b). More results on various VDU tasks are available at Section 3 showing the same trend

Current VDU methods \[22,24,63,62,18\] solve the task in a two-stage manner: 1) reading the texts in the document image; 2) holistic understanding of the document. They usually rely on deep-learning-based Optical Character Recognition (OCR) \[4,3\] for the text reading task and focus on modeling the understanding part. For example, as shown in Figure 1, a conventional pipeline for extracting structured information from documents (a.k.a. document parsing) consists of three separate modules for text detection, text recognition, and parsing \[22,24\].

However, the OCR-dependent approach has critical problems. First of all, using OCR as a pre-processing method is expensive. We can utilize pre-trained offthe-shelf OCR engines; however, the computational cost for inference would be expensive for high-quality OCR results. Moreover, the off-the-shelf OCR methods rarely have flexibility dealing with different languages or domain changes, which may lead to poor generalization ability. If we train an OCR model, it also requires extensive training costs and large-scale datasets \[4,3,39,46\]. Another problem is, OCR errors would propagate to the VDU system and negatively influence subsequent processes \[54,23\]. This problem becomes more severe in languages with complex character sets, such as Korean or Chinese, where the quality of OCR is relatively low \[50\]. To deal with this, post-OCR correction module \[51,50,10\] is usually adopted. However, it is not a practical solution for real application environments since it increases the entire system size and maintenance cost.

We go beyond the traditional framework by modeling a direct mapping from a raw input image to the desired output without OCR. We introduce a new OCR-free VDU model to address the problems induced by the OCR-dependency. Our model is based on Transformer-only architecture, referred to as Document understanding transformer (Donut), following the huge success in vision and language \[8,9,29\]. We present a minimal baseline including a simple architecture and pre-training method. Despite its simplicity, Donut shows comparable or better overall performance than previous methods as shown in Figure 2.

We take pre-train-and-fine-tune scheme \[8,63\] on Donut training. In the pre-training phase, Donut learns how to read the texts by predicting the next words by conditioning jointly on the image and previous text contexts. Donut is pre-trained with document images and their text annotations. Since our pretraining objective is simple (i.e., reading the texts), we can realize domain and language flexibility straightforwardly pre-training with synthetic data. During fine-tuning stage, Donut learns how to understand the whole document according to the downstream task. We demonstrate Donut has a strong understanding ability through extensive evaluation on various VDU tasks and datasets. The experiments show a simple OCR-free VDU model can achieve state-of-the-art performance in terms of both speed and accuracy.

The contributions are summarized as follows:

1. We propose a novel OCR-free approach for VDU. To the best of our knowledge, this is the first method based on an OCR-free Transformer trained in end-to-end manner.
2. We introduce a simple pre-training scheme that enables the utilization of synthetic data. By using our generator SynthDoG, we show Donut can easily be extended to a multi-lingual setting, which is not applicable for the conventional approaches that need to retrain an off-the-shelf OCR engine.
3. We conduct extensive experiments and analyses on both public benchmarks and private industrial datasets, showing that the proposed method achieves not only state-of-the-art performances on benchmarks but also has many practical advantages (e.g., cost-effective) in real-world applications.
4. The codebase, pre-trained model, and synthetic data are available at GitHub.1

# 2 Method

# 2.1 Preliminary: background

There have been various visual document understanding (VDU) methods to understand and extract essential information from the semi-structured documents such as receipts \[20,25,18\], invoices \[49\], and form documents \[14,6,43\].

https://www.ecva.net/papers/eccv_2022/papers_ECCV/papers/images/e75fd79771adc1628a194b37aecd1c510891b8a964d922a7eb3fdacc02442984.jpg

Fig. 3. The pipeline of Donut. The encoder maps a given document image into embeddings. With the encoded embeddings, the decoder generates a sequence of tokens that can be converted into a target type of information in a structured form

Earlier VDU attempts have been done with OCR-independent visual backbones \[27,1,15,12,31\], but the performances are limited. Later, with the remarkable advances of OCR \[4,3\] and BERT \[8\], various OCR-dependent VDU models have been proposed by combining them \[22,24,23\]. More recently, in order to get a more general VDU, most state-of-the-arts \[62,18\] use both powerful OCR engines and large-scale real document image data (e.g., IIT-CDIP \[32\]) for a model pre-training. Although they showed remarkable advances in recent years, extra effort is required to ensure the performance of an entire VDU model by using the off-the-shelf OCR engine.

# 2.2 Document Understanding Transformer

Donut is an end-to-end (i.e., self-contained) VDU model for general understanding of document images. The architecture of Donut is quite simple, which consists of a Transformer \[58,9\]-based visual encoder and textual decoder modules. Note that Donut does not rely on any modules related to OCR functionality but uses a visual encoder for extracting features from a given document image. The following textual decoder maps the derived features into a sequence of subword tokens to construct a desired structured format (e.g., JSON). Each model component is Transformer-based, and thus the model is trained easily in an end-to-end manner. The overall process of Donut is illustrated in Figure 3.

Encoder. The visual encoder converts the input document image $\\mathbf { x } { \\in } \\mathbb { R } ^ { H \\times W \\times C }$ into a set of embeddings ${ \\mathbf { z } \_ { i } \| \\mathbf { z } \_ { i } \\in \\mathbb { R } ^ { d } , 1 { \\leq } i { \\leq } n }$ , where $n$ is feature map size or the number of image patches and $d$ is the dimension of the latent vectors of the encoder. Note that CNN-based models \[17\] or Transformer-based models \[9,40\] can be used as the encoder network. In this study, we use Swin Transformer \[40\] because it shows the best performance in our preliminary study in document parsing. Swin Transformer first splits the input image $\\mathbf { x }$ into non-overlapping patches. Swin Transformer blocks, consist of a shifted window-based multi-head self-attention module and a two-layer MLP, are applied to the patches. Then, patch merging layers are applied to the patch tokens at each stage. The output of the final Swin Transformer block ${ \\mathbf { z } }$ is fed into the following textual decoder.

Decoder. Given the ${ \\mathbf { z } }$ , the textual decoder generates a token sequence $( { \\bf y } \_ { i } ) \_ { i = 1 } ^ { m }$ , where $\\mathbf { y } \_ { i } \\in \\mathbb { R } ^ { v }$ is an one-hot vector for the $\_ i$ -th token, $\\boldsymbol { v }$ is the size of token vocabulary, and $m$ is a hyperparameter, respectively. We use BART \[33\] as the decoder architecture. Specifically, we initialize the decoder model weights with those from the publicly available2 pre-trained multi-lingual BART model\[38\].

Model Input. Following the original Transformer \[58\], we use a teacher-forcing scheme \[61\], which is a model training strategy that uses the ground truth as input instead of model output from a previous time step. In the test phase, inspired by GPT-3 \[5\], the model generates a token sequence given a prompt. We add new special tokens for the prompt for each downstream task in our experiments. The prompts that we use for our applications are shown with the desired output sequences in Figure 3. Illustrative explanations for the teacherforcing strategy and the decoder output format are available in Appendix A.4.

Output Conversion. The output token sequence is converted to a desired structured format. We adopt a JSON format due to its high representation capacity. As shown in Figure 3, a token sequence is one-to-one invertible to a JSON data. We simply add two special tokens \[START ∗\] and $\[ \\mathbb { E } \\mathbb { N } \\mathbb { D } \_ { - } \* \]$ , where $^ \*$ indicates each field to extract. If the output token sequence is wrongly structured, we simply treat the field is lost. For example, if there is only \[START name\] exists but no \[END name\], we assume the model fails to extract “name” field. This algorithm can easily be implemented with simple regular expressions \[11\].

# 2.3 Pre-training

Task. The model is trained to read all texts in the image in reading order (from top-left to bottom-right, basically). The objective is to minimize cross-entropy loss of next token prediction by jointly conditioning on the image and previous contexts. This task can be interpreted as a pseudo-OCR task. The model is trained as a visual language model over the visual corpora, i.e., document images.

Visual Corpora. We use IIT-CDIP \[32\], which is a set of 11M scanned english document images. A commercial CLOVA OCR API is applied to get the pseudo text labels. As aforementioned, however, this kind of dataset is not always available, especially for languages other than English. To alleviate the dependencies, we build a scalable Synthetic Document Generator, referred to as SynthDoG. Using the SynthDog and Chinese, Japanese, Korean and English Wikipedia, we generated 0.5M samples per language.

Synthetic Document Generator. The pipeline of image rendering basically follows Yim et al. \[65\]. As shown in Figure 4, the generated sample consists of several components; background, document, text, and layout. Background image is sampled from ImageNet \[7\], and a texture of document is sampled from the collected paper photos. Words and phrases are sampled from Wikipedia. Layout is generated by a simple rule-based algorithm that randomly stacks grids. In addition, several image rendering techniques \[13,41,65\] are applied to mimic real documents. The generated examples are shown in Figure 4. More details of SynthDoG are available in the code $\\cdot$ and Appendix A.2.

https://www.ecva.net/papers/eccv_2022/papers_ECCV/papers/images/814a7453e814478aac2004d0a904c2130c8e34556f0238474164ceb3b749a667.jpg

Fig. 4. Generated English, Chinese, Japanese, and Korean samples with SynthDoG. Heuristic random patterns are applied to mimic the real documents

# 2.4 Fine-tuning

After the model learns how to read, in the application stage (i.e., fine-tuning), we teach the model how to understand the document image. As shown in Figure 3, we interpret all downstream tasks as a JSON prediction problem.

The decoder is trained to generate a token sequence that can be converted into a JSON that represents the desired output information. For example, in the document classification task, the decoder is trained to generate a token sequence \[START class\]\[memo\]\[END class\] which is 1-to-1 invertible to a JSON ${$ {“class”: “memo”}. We introduce some special tokens (e.g., \[memo\] is used for representing the class “memo”), if such replacement is available in the target task.

# 3 Experiments and Analyses

In this section, we present Donut fine-tuning results on three VDU applications on six different datasets including both public benchmarks and private industrial service datasets. The samples are shown in Figure 5.

# 3.1 Downstream Tasks and Datasets

Document Classification. To see whether the model can distinguish across different types of documents, we test a classification task. Unlike other models that predict the class label via a softmax on the encoded embedding, Donut generate a JSON that contains class information to maintain the uniformity of the task-solving method. We report overall classification accuracy on a test set.

RVL-CDIP. The RVL-CDIP dataset \[16\] consists of 400K images in 16 classes, with 25K images per class. The classes include letter, memo, email, and so on. There are 320K training, 40K validation, and 40K test images.

https://www.ecva.net/papers/eccv_2022/papers_ECCV/papers/images/719731287ff03756912c734ecbce90120a9563edb4ce6aaa0bec0b54ef8b2a71.jpg

Fig. 5. Samples of the downstream datasets. (a) Document Classification. (b) Document Information Extraction. (c) Document Visual Question Answering

Document Information Extraction. To see the model fully understands the complex layouts and contexts in documents, we test document information extraction (IE) tasks on various real document images including both public benchmarks and real industrial datasets. In this task, the model aims to map each document to a structured form of information that is consistent with the target ontology or database schema. See Figure 1 for an illustrative example. The model should not only read the characters well, but also understand the layouts and semantics to infer the groups and nested hierarchies among the texts.

We evaluate the models with two metrics; field-level F1 score \[22,63,18\] and Tree Edit Distance (TED) based accuracy \[66,68,23\]. The F1 checks whether the extracted field information is in the ground truth. Even a single character is missed, the score assume the field extraction is failed. Although F1 is simple and easy to understand, there are some limitations. First, it does not take into account partial overlaps. Second, it can not measure the predicted structure (e.g., groups and nested hierarchy). To assess overall accuracy, we also use another metric based on TED \[66\], that can be used for any documents represented as trees. It is calculated as, $\\operatorname\* { m a x } ( 0 , 1 - \\mathrm { T E D } ( \\mathrm { p r } , \\mathrm { g t } ) / \\mathrm { T E D } ( \\phi , \\mathrm { g t } ) )$ , where gt, pr, and $\\phi$ stands for ground truth, predicted, and empty trees respectively. Similar metrics are used in recent works on document IE \[68,23\]

We use two public benchmark datasets as well as two private industrial datasets which are from our active real-world service products. Each dataset is explained in the followings.

CORD. The Consolidated Receipt Dataset (CORD) $^ 3$ \[45\] is a public benchmark that consists of 0.8K train, 0.1K valid, 0.1K test receipt images. The letters of receipts is in Latin alphabet. The number of unique fields is 30 containing menu name, count, total price, and so on. There are complex structures (i.e., nested groups and hierarchies such as items>item>{name, count, price}) in the information. See Figure 1 for more details.

Ticket. This is a public benchmark dataset \[12\] that consists of 1.5K train and 0.4K test Chinese train ticket images. We split $1 0 %$ of the train set as a validation set. There are 8 fields which are ticket number, starting station, train number, and so on. The structure of information is simple and all keys are guaranteed to appear only once and the location of each field is fixed.

Business Card (In-Service Data). This dataset is from our active products that are currently deployed. The dataset consists of 20K train, 0.3K valid, 0.3K test Japanese business cards. The number of fields is 11, including name, company, address, and so on. The structure of information is similar to the Ticket dataset.

Receipt (In-Service Data). This dataset is also from one of our real products. The dataset consists of 40K train, 1K valid, 1K test Korean receipt images. The number of unique field is 81, which includes store information, payment information, price information, and so on. Each sample has complex structures compared to the aforementioned datasets. Due to industrial policies, not all samples can publicly be available. Some real-like high-quality samples are shown in Figure 5 and in the supplementary material.

Document Visual Question Answering. To validate the further capacity of the model, we conduct a document visual question answering task (DocVQA). In this task, a document image and question pair is given and the model predicts the answer for the question by capturing both visual and textual information within the image. We make the decoder generate the answer by setting the question as a starting prompt to keep the uniformity of the method (See Figure 3).

DocVQA. The dataset is from Document Visual Question Answering competition $^ 4$ and consists of 50K questions defined on more than 12K documents \[44\]. There are 40K train, 5K valid, and 5K test questions. The evaluation metric is ANLS (Average Normalized Levenshtein Similarity) which is an edit-distancebased metric. The score on the test set is measured via the evaluation site.

# 3.2 Setups

We use Swin-B \[40\] as a visual encoder of Donut with slight modification. We set the layer numbers and window size as ${ 2 , 2 , 1 4 , 2 }$ and 10. In further consideration of the speed-accuracy trade-off, we use the first four layers of BART as a decoder. As explained in Section 2.3, we train the multi-lingual Donut using the 2M synthetic and 11M IIT-CDIP scanned document images. We pre-train the model for 200K steps with 64 A100 GPUs and a mini-batch size of 196. We use Adam \[30\] optimizer, the learning rate is scheduled and the initial rate is selected from 1e-5 to 1e-4. The input resolution is set to $2 5 6 0 \\times 1 9 2 0$ and a max length in the decoder is set to 1536. All fine-tuning results are achieved by starting from the pre-trained multi-lingual model. Some hyperparameters are adjusted at fine-tuning and in ablation studies. We use $9 6 0 \\times 1 2 8 0$ for Train Tickets and Business Card parsing tasks. We fine-tune the model while monitoring the edit distance over token sequences. The speed of Donut is measured on a P40 GPU, which is much slower than A100. For the OCR based baselines, states-of-the-art OCR engines are used, including MS OCR API used in \[62\] and CLOVA OCR API $^ { 5 }$ used in \[24,23\]. An analysis on OCR engines is available in Section 3.4. More details of OCR and training setups are available in Appendix A.1 and A.5.

Table 1. Classification results on the RVL-CDIP dataset. Donut achieves state-of-the-are performance with reasonable speed and model size efficiency. Donut is a general purpose backbone but does not rely on OCR while other recent backbones (e.g., LayoutLM) do. $^ { \\dag } #$ parameters for OCR should be considered for non-E2E models

|     |     |     |     |
| --- | --- | --- | --- |
| OCR | #Params |  | Time (ms) Accuracy (%) |
| BERT | 110M + a | 1392 | 89.81 |
| RoBERTa | 125M + a | 1392 | 90.06 |
| LayoutLM | 113M + a | 1396 | 91.78 |
| LayoutLM (w/ image) | 160M + a | 1426 | 94.42 |
| LayoutLMv2 | 200M + | 1489 | 95.25 |
| Donut (Proposed) | 143M | 752 | 95.30 |

# 3.3 Experimental Results

Document Classification. The results are shown in Table 1. Without relying on any other resource (e.g., off-the-shelf OCR engine), Donut shows a state-of-the-art performance among the general-purpose VDU models such as LayoutLM \[63\] and LayoutLMv2 \[62\]. In particular, Donut surpasses the LayoutLMv2 accuracy reported in \[62\], while using fewer parameters with the 2x faster speed. Note that the OCR-based models must consider additional model parameters and speed for the entire OCR framework, which is not small in general. For example, a recent advanced OCR-based model \[4,3\] requires more than 80M parameters. Also, training and maintaining the OCR-based systems are costly \[23\], leading to needs for the Donut-like end-to-end approach.

Document Information Extraction. Table 2 shows the results on the four different document IE tasks. The first group uses a conventional BIO-taggingbased IE approach \[22\]. We follows the conventions in IE \[63,18\]. OCR extracts texts and bounding boxes from the image, and then the serialization module sorts all texts with geometry information within the bounding box. The BIO-taggingbased named entity recognition task performs token-level tag classification upon the ordered texts to generate a structured form. We test three general-purpose VDU backbones, BERT \[8\], BROS \[18\], and LayoutLMv2 \[62,64\].

Table 2. Performances on various document IE tasks. The field-level F1 scores and tree-edit-distance-based accuracies are reported. Donut shows the best accuracies for all domains with significantly faster inference speed. $^ \\dagger$ Parameters for vocabulary are omitted for fair comparisons among multi-lingual models. $^ { \\ddagger } #$ parameters for OCR should be considered. $^ \*$ Official multi-lingual extension models are used

|     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |     |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  |  |  |  | CORD \[45\] | Ticket \[12\] | Business Card | Receipt |
|  |  | OCR #Params Time (s) |  | F1 |  | Acc. Time (s) |  | F1 | Acc. Time (s) |  | F1 |  | Acc. Time (s) | F1 | Acc. |
| BERT\* \[22\] |  | 861 + a |  | 1.6 | 82.2 78.2 |  | 1.7 |  | 86.7 91.7 | 1.5 |  | 55.6 86.9 | 2.5 |  | 80.2 77.3 |
| BROS \[18\] |  | 86 + a | 1.7 |  | 83.7 80.3 |  |  |  |  |  |  |  |  |  |  |
| LayoutLMv2\* \[62,64\] |  | 179M + a |  | 1.7 | 88.9 87.0 |  | 1.8 | 96.3 90.1 |  | 1.6 |  | 68.8 92.0 | 2.6 |  | 86.0 89.0 |
| Donut |  | 143 |  | 1.2 | 91.6 93.5 |  | 0.6 | 97.0 98.8 |  | 1.4 |  | 74.2 95.1 | 1.9 |  | 88.2 94.4 |
| SPADE\* \[25\] |  | 9314 + a |  | 4.0 | 83.1 | 84.5 | 4.5 | 13.9 59.8 |  | 4.3 | 48.1 | 83.5 | 7.3 |  | 74.8 79.8 |
| WYVERN\* \[21\] |  | 106M + a\* |  | 1.2 | 62.8 70.5 |  | 1.5 | 63.5 76.2 |  | 1.7 |  | 46.5 88.8 | 3.4 |  | 85.0 92.0 |

We also test two recently proposed IE models, SPADE \[24\] and WYVERN \[23\] SPADE is a graph-based IE method that predicts relations between bounding boxes. WYVERN is an Transformer encoder-decoder model that directly generates entities with structure given OCR outputs. WYVERN is different from Donut in that it takes the OCR output as its inputs.

For all domains, including public and private in-service datasets, Donut shows the best scores among the comparing models. By measuring both F1 and TEDbased accuracy, we observe not only Donut can extract key information but also predict complex structures among the field information. We observe that a large input resolution gives robust accuracies but makes the model slower. For example, the performance on the CORD with 1280×960 was 0.7 sec./image and 93.6 accuracy. But, the large resolution showed better performances on the low-resource situation. The detailed analyses are in Section 3.4. Unlike other baselines, Donut shows stable performance regardless of the size of datasets and complexity of the tasks (See Figure 5). This is a significant impact as the target tasks are already actively used in industries.

Document Visual Question Answering. Table 3 shows the results on the DocVQA dataset. The first group is the general-purposed VDU backbones whose scores are from the LayoutLMv2 paper \[62\]. We measure the running time with MS OCR API used in \[62\]. The model in the third group is a DocVQA-specificpurposed fine-tuning model of LayoutLMv2, whose inference results are available in the official leader-board.6

As can be seen, Donut achieves competitive scores with the baselines that are dependent on external OCR engines. Especially, Donut shows that it is robust to the handwritten documents, which is known to be challenging to process. In the conventional approach, adding a post-processing module that corrects OCR errors is an option to strengthen the pipeline \[51,50,10\] or adopting an encoderdecoder architecture on the OCR outputs can mitigate the problems of OCR errors \[23\]. However, this kind of approaches tend to increase the entire system size and maintenance cost. Donut shows a completely different direction. Some inference results are shown in Figure 6. The samples show the current strengths of Donut as well as the left challenges in the Donut-like end-to-end approach. Further analysis and ablation is available in Section 3.4.

Table 3. Average Normalized Levenshtein Similarity (ANLS) scores on DocVQA. Donut shows a promising result without OCR. $^ \*$ Donut shows a high ANLS score on the handwritten documents which are known to be challenging due to the difficulty of handwriting OCR (See Figure 6). $^ \\dagger$ Token embeddings for English is counted for a fair comparison. $^ { \\ddag } #$ parameters for OCR should be considered

|     |     |     |     |     |     |
| --- | --- | --- | --- | --- | --- |
|  | Fine-tuning set | OCR #Params' Time (ms) |  |  | ANt set ANdwritten |
| BERT \[62\] | train set | 110M + a\* | 1517 | 63.5 | n/a |
| LayoutLM\[63\] | train set | 113M + a\* | 1519 | 69.8 | n/a |
| LayoutLMv2\[62\] | train set | 200M + a\* | 1610 | 78.1 | n/a |
| Donut | train set | 176M | 782 | 67.5 | 72.1 |
| LayoutLMv2-Large-QG\[62\] train + dev + QG |  | 390M + a\* | 1698 | 86.7 | 67.3 |

https://www.ecva.net/papers/eccv_2022/papers_ECCV/papers/images/158f6a6ff00b5ea473f2dcb2442eafd7de8a35105908877d4a722a62ec0094bf.jpg

Fig. 6. Examples of Donut and LayoutLMv2 outputs on DocVQA. The OCRerrors make a performance upper-bound of the OCR-dependent baselines, e.g., LayoutLMv2 (left and middle examples). Due to the input resolution constraint of the end-to-end pipeline, Donut miss some tiny texts in large-scale images (right example) but this could be mitigated by scaling the input image size (See Section 3.4)

# 3.4 Further Studies

In this section, we study several elements of understanding Donut. We show some striking characteristics of Donut through the experiments and visualization.

On Pre-training Strategy. We test several pre-training tasks for VDUs. Figure 7(a) shows that the Donut pre-training task (i.e., text reading) is the most simple yet effective approach. Other tasks that impose a general knowledge of images and texts on models, e.g., image captioning, show little gains in the fine-tuning tasks. For the text reading tasks, we verify three options, SynthDoG only, IIT-CDIP only, and both. Note that synthetic images were enough for the document IE task in our analysis. However, in the DocVQA task, it was important to see the real images. This is probably because the image distributions of IIT-CDIP and DocVQA are similar \[44\].

https://www.ecva.net/papers/eccv_2022/papers_ECCV/papers/images/6f5ddd48464ec301c43ff22315abaab5de5acd59c56d64c97efdddc552608562.jpg

Fig. 7. Analysis on (a) pre-training strategies, (b) image backbones, and (c) input resolutions. Performances on CORD \[45\] and DocVQA \[44\] are shown

On Encoder Backbone. Here, we study popular image classification backbones that show superior performance in traditional vision tasks to measure their performance in VDU tasks. The Figure 7(b) shows the comparison results. We use all the backbones pre-trained on ImageNet \[7\]. EfficientNetV2 \[55\] and Swin Transformer \[40\] outperform others on both datasets. We argue that this is due to the high expressiveness of the backbones, which were shown by the striking scores on several downstream tasks as well. We choose Swin Transformer due to the high scalability of the Transformer-based architecture and higher performance over the EfficientNetV2’s.

On Input Resolution. The Figure 7(c) shows the performance of Donut grows rapidly as we set a larger input size. This gets clearer in the DocVQA where the images are larger with many tiny texts. But, increasing the size for a precise result incurs bigger computational costs. Using an efficient attention mechanism \[60\] may avoid the matter in architectural design, but we use the original Transformer \[58\] as we aim to present a simpler architecture in this work.

On Text Localization. To see how the model behaves, we visualize the corss attention maps of the decoder given an unseen document image. As can be seen in Figure 8, the model shows meaningful results that can be used as an auxiliary indicator. The model attends to a desired location in the given image.

On OCR System. We test four widely-used public OCR engines (See Figure 9). The results show that the performances (i.e., speed and accuracy) of the conventional OCR-based methods heavily rely on the off-the-shelf OCR engine. More details of the OCR engines are available in Appendix A.1.

https://www.ecva.net/papers/eccv_2022/papers_ECCV/papers/images/d7f29c3a320619f18dbfcf0ecc5acda5217fed28a6037ca48bd5027298ea1f4c.jpg

Fig. 8. Visualization of cross-attention maps in the decoder and its application to text localization. Donut is trained without any supervision for the localization. The Donut decoder attends proper text regions to process the image

https://www.ecva.net/papers/eccv_2022/papers_ECCV/papers/images/9f8adddcb93d9268f470bf01f116acb127aefadb54c23c7c9ec7206bcd83c017.jpg

Fig. 9. Comparison of BERT, LayoutLMv2 and Donut on CORD. The performances (i.e., speed and accuracy) of the OCR-based models extremely varies depending on what OCR engine is used (left and center). Donut shows robust performances even in a low resourced situation showing the higher score only with 80 samples (right)

On Low Resourced Situation. We evaluate the models by limiting the size of training set of CORD \[45\]. The performance curves are shown in the right Figure 9. Donut shows a robust performances. We also observe that a larger input resolution, 2560 $\\times$ 1920, shows more robust scores on the extremely lowresourced situation, e.g., 80 samples. As can be seen, Donut outperformed the LayoutLMv2 accuracy only with $1 0 %$ of the data, which is only 80 samples.

# 4 Related Work

# 4.1 Optical Character Recognition

Recent trends of OCR study are to utilize deep learning models in its two substeps: 1) text areas are predicted by a detector; 2) a text recognizer then recognizes all characters in the cropped image instances. Both are trained with a large-scale datasets including the synthetic images \[26,13\] and real images \[28,47\].

Early detection methods used CNNs to predict local segments and apply heuristics to merge them \[19,67\]. Later, region proposal and bounding box regression based methods were proposed \[36\]. Recently, focusing on the homogeneity and locality of texts, component-level approaches were proposed \[56,4\].

Many modern text recognizer share a similar approach \[37,53,52,59\] that can be interpreted into a combination of several common deep modules \[3\]. Given the cropped text instance image, most recent text recognition models apply CNNs to encode the image into a feature space. A decoder is then applied to extract characters from the features.

# 4.2 Visual Document Understanding

Classification of the document type is a core step towards automated document processing. Early methods treated the problem as a general image classification, so various CNNs were tested \[27,1,15\]. Recently, with BERT \[8\], the methods based on a combination of CV and NLP were widely proposed \[63,34\]. As a common approach, most methods rely on an OCR engine to extract texts; then the OCR-ed texts are serialized into a token sequence; finally they are fed into a language model (e.g., BERT) with some visual features if available. Although the idea is simple, the methods showed remarkable performance improvements and became a main trend in recent years \[62,35,2\].

Document IE covers a wide range of real applications \[22,42\], for example, given a bunch of raw receipt images, a document parser can automate a major part of receipt digitization, which has been required numerous human-labors in the traditional pipeline. Most recent models \[25,23\] take the output of OCR as their input. The OCR results are then converted to the final parse through several processes, which are often complex. Despite the needs in the industry, only a few works have been attempted on end-to-end parsing. Recently, some works are proposed to simplify the complex parsing processes \[25,23\]. But they still rely on a separate OCR to extract text information.

Visual QA on documents seeks to answer questions asked on document images. This task requires reasoning over visual elements of the image and general knowledge to infer the correct answer \[44\]. Currently, most state-of-the-arts follow a simple pipeline consisting of applying OCR followed by BERT-like transformers \[63,62\]. However, the methods work in an extractive manner by their nature. Hence, there are some concerns for the question whose answer does not appear in the given image \[57\]. To tackle the concerns, generation-based methods have also been proposed \[48\].

# 5 Conclusions

In this work, we propose a novel end-to-end framework for visual document understanding. The proposed method, Donut, directly maps an input document image into a desired structured output. Unlike conventional methods, Donut does not depend on OCR and can easily be trained in an end-to-end fashion. We also propose a synthetic document image generator, SynthDoG, to alleviate the dependency on large-scale real document images and we show that Donut can be easily extended to a multi-lingual setting. We gradually trained the model from how to read to how to understand through the proposed training pipeline. Our extensive experiments and analysis on both external public benchmarks and private internal service datasets show higher performance and better costeffectiveness of the proposed method. This is a significant impact as the target tasks are already practically used in industries. Enhancing the pre-training objective could be a future work direction. We believe our work can easily be extended to other domains/tasks regarding document understanding.

# References

01. Afzal, M.Z., Capobianco, S., Malik, M.I., Marinai, S., Breuel, T.M., Dengel, A., Liwicki, M.: Deepdocclassifier: Document classification with deep convolutional neural network. In: 2015 13th International Conference on Document Analysis and Recognition (ICDAR). pp. 1111–1115 (2015). [https://doi.org/10.1109/ICDAR.2015.7333933](https://doi.org/10.1109/ICDAR.2015.7333933) 1, 4, 14

02. Appalaraju, S., Jasani, B., Kota, B.U., Xie, Y., Manmatha, R.: Docformer: End-toend transformer for document understanding. In: Proceedings of the IEEE/CVF International Conference on Computer Vision (ICCV). pp. 993–1003 (October 2021) 14

03. Baek, J., Kim, G., Lee, J., Park, S., Han, D., Yun, S., Oh, S.J., Lee, H.: What is wrong with scene text recognition model comparisons? dataset and model analysis. In: Proceedings of the IEEE/CVF International Conference on Computer Vision (ICCV) (October 2019) 2, 4, 9, 13

04. Baek, Y., Lee, B., Han, D., Yun, S., Lee, H.: Character region awareness for text detection. In: 2019 IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR). pp. 9357–9366 (2019). [https://doi.org/10.1109/CVPR.2019.00959](https://doi.org/10.1109/CVPR.2019.00959) 2, 4, 9, 13

05. Brown, T., Mann, B., Ryder, N., Subbiah, M., Kaplan, J.D., Dhariwal, P., Neelakantan, A., Shyam, P., Sastry, G., Askell, A., Agarwal, S., Herbert-Voss, A., Krueger, G., Henighan, T., Child, R., Ramesh, A., Ziegler, D., Wu, J., Winter, C., Hesse, C., Chen, M., Sigler, E., Litwin, M., Gray, S., Chess, B., Clark, J., Berner, C., McCandlish, S., Radford, A., Sutskever, I., Amodei, D.: Language models are few-shot learners. In: Larochelle, H., Ranzato, M., Hadsell, R., Balcan, M.F., Lin, H. (eds.) Advances in Neural Information Processing Systems. vol. 33, pp. 1877– 1901. Curran Associates, Inc. (2020), [https://proceedings.neurips.cc/paper/](https://proceedings.neurips.cc/paper/) 2020/file/1457c0d6bfcb4967418bfb8ac142f64a-Paper.pdf 5

06. Davis, B., Morse, B., Cohen, S., Price, B., Tensmeyer, C.: Deep visual template-free form parsing. In: 2019 International Conference on Document Analysis and Recognition (ICDAR). pp. 134–141 (2019). [https://doi.org/10.1109/ICDAR.2019.00030](https://doi.org/10.1109/ICDAR.2019.00030) 3

07. Deng, J., Dong, W., Socher, R., Li, L.J., Li, K., Fei-Fei, L.: Imagenet: A largescale hierarchical image database. In: 2009 IEEE conference on computer vision and pattern recognition. pp. 248–255. Ieee (2009) 6, 12

08. Devlin, J., Chang, M.W., Lee, K., Toutanova, K.: BERT: Pre-training of deep bidirectional transformers for language understanding. In: Proceedings of the 2019 Conference of the North American Chapter of the Association for Computational Linguistics: Human Language Technologies, Volume 1 (Long and Short Papers). pp. 4171–4186. Association for Computational Linguistics, Minneapolis, Minnesota (Jun 2019). [https://doi.org/10.18653/v1/N19-1423](https://doi.org/10.18653/v1/N19-1423), [https://aclanthology.org/](https://aclanthology.org/) N19-1423 3, 4, 10, 14

09. Dosovitskiy, A., Beyer, L., Kolesnikov, A., Weissenborn, D., Zhai, X., Unterthiner, T., Dehghani, M., Minderer, M., Heigold, G., Gelly, S., Uszkoreit, J., Houlsby, N.: An image is worth 16x16 words: Transformers for image recognition at scale. In: 9th International Conference on Learning Representations, ICLR 2021, Virtual Event, Austria, May 3-7, 2021. OpenReview.net (2021), [https://openreview.net/](https://openreview.net/) forum?id=YicbFdNTTy 3, 4

10. Duong, Q., H¨am¨al¨ainen, M., Hengchen, S.: An unsupervised method for OCR post-correction and spelling normalisation for Finnish. In: Proceedings of the 23rd Nordic Conference on Computational Linguistics (NoDaLiDa). pp. 240–248. Link¨oping University Electronic Press, Sweden, Reykjavik, Iceland (Online) (May 31–2 Jun 2021), [https://aclanthology.org/2021.nodalida-main.24](https://aclanthology.org/2021.nodalida-main.24) 3, 11

11. Friedl, J.E.F.: Mastering Regular Expressions. O’Reilly, Beijing, 3 edn. (2006), [https://www.safaribooksonline.com/library/view/](https://www.safaribooksonline.com/library/view/) mastering-regular-expressions/0596528124/ 5

12. Guo, H., Qin, X., Liu, J., Han, J., Liu, J., Ding, E.: Eaten: Entity-aware attention for single shot visual text extraction. In: 2019 International Conference on Document Analysis and Recognition (ICDAR). pp. 254–259 (2019). [https://doi.org/10.1109/ICDAR.2019.00049](https://doi.org/10.1109/ICDAR.2019.00049) 4, 8, 10

13. Gupta, A., Vedaldi, A., Zisserman, A.: Synthetic data for text localisation in natural images. In: Proceedings of the IEEE Conference on Computer Vision and Pattern Recognition (CVPR) (June 2016) 6, 13

14. Hammami, M., H´eroux, P., Adam, S., d’Andecy, V.P.: One-shot field spotting on colored forms using subgraph isomorphism. In: 2015 13th International Conference on Document Analysis and Recognition (ICDAR). pp. 586–590 (2015). [https://doi.org/10.1109/ICDAR.2015.7333829](https://doi.org/10.1109/ICDAR.2015.7333829) 3

15. Harley, A.W., Ufkes, A., Derpanis, K.G.: Evaluation of deep convolutional nets for document image classification and retrieval. In: 2015 13th International Conference on Document Analysis and Recognition (ICDAR). pp. 991–995 (2015). [https://doi.org/10.1109/ICDAR.2015.7333910](https://doi.org/10.1109/ICDAR.2015.7333910) 4, 14

16. Harley, A.W., Ufkes, A., Derpanis, K.G.: Evaluation of deep convolutional nets for document image classification and retrieval. In: 2015 13th International Conference on Document Analysis and Recognition (ICDAR). pp. 991–995 (2015). [https://doi.org/10.1109/ICDAR.2015.7333910](https://doi.org/10.1109/ICDAR.2015.7333910) 6

17. He, K., Zhang, X., Ren, S., Sun, J.: Deep residual learning for image recognition. In: 2016 IEEE Conference on Computer Vision and Pattern Recognition (CVPR). pp. 770–778 (2016). [https://doi.org/10.1109/CVPR.2016.90](https://doi.org/10.1109/CVPR.2016.90) 4

18. Hong, T., Kim, D., Ji, M., Hwang, W., Nam, D., Park, S.: Bros: A pre-trained language model focusing on text and layout for better key information extraction from documents. Proceedings of the AAAI Conference on Artificial Intelligence 36(10), 10767–10775 (Jun 2022). [https://doi.org/10.1609/aaai.v36i10.21322](https://doi.org/10.1609/aaai.v36i10.21322), [https://ojs.aaai.org/index.php/AAAI/article/view/21322](https://ojs.aaai.org/index.php/AAAI/article/view/21322) 2, 3, 4, 7, 9, 10

19. Huang, W., Qiao, Y., Tang, X.: Robust scene text detection with convolution neural network induced mser trees. In: Fleet, D., Pajdla, T., Schiele, B., Tuytelaars, T. (eds.) Computer Vision – ECCV 2014. pp. 497–511. Springer International Publishing, Cham (2014) 13

20. Huang, Z., Chen, K., He, J., Bai, X., Karatzas, D., Lu, S., Jawahar, C.V.: Icdar2019 competition on scanned receipt ocr and information extraction. In: 2019 International Conference on Document Analysis and Recognition (ICDAR). pp. 1516–1520 (2019). [https://doi.org/10.1109/ICDAR.2019.00244](https://doi.org/10.1109/ICDAR.2019.00244) 3

21. Hwang, A., Frey, W.R., McKeown, K.: Towards augmenting lexical resources for slang and African American English. In: Proceedings of the 7th Workshop on NLP for Similar Languages, Varieties and Dialects. pp. 160–172. International Committee on Computational Linguistics (ICCL), Barcelona, Spain (Online) (Dec 2020), [https://aclanthology.org/2020.vardial-1.15](https://aclanthology.org/2020.vardial-1.15) 10

22. Hwang, W., Kim, S., Yim, J., Seo, M., Park, S., Park, S., Lee, J., Lee, B., Lee, H.: Post-ocr parsing: building simple and robust parser via bio tagging. In: Workshop on Document Intelligence at NeurIPS 2019 (2019) 1, 2, 4, 7, 9, 10, 14

23. Hwang, W., Lee, H., Yim, J., Kim, G., Seo, M.: Cost-effective end-to-end information extraction for semi-structured document images. In: Proceedings of the 2021 Conference on Empirical Methods in Natural Language Processing. pp. 3375– 3383. Association for Computational Linguistics, Online and Punta Cana, Dominican Republic (Nov 2021). [https://doi.org/10.18653/v1/2021.emnlp-main.271](https://doi.org/10.18653/v1/2021.emnlp-main.271), [https://aclanthology.org/2021.emnlp-main.271](https://aclanthology.org/2021.emnlp-main.271) 2, 4, 7, 9, 10, 11, 14

24. Hwang, W., Yim, J., Park, S., Yang, S., Seo, M.: Spatial dependency parsing for semi-structured document information extraction. In: Findings of the Association for Computational Linguistics: ACL-IJCNLP 2021. pp. 330–343. Association for Computational Linguistics, Online (Aug 2021). [https://doi.org/10.18653/v1/2021.findings-acl.28](https://doi.org/10.18653/v1/2021.findings-acl.28), [https://aclanthology](https://aclanthology/). org/2021.findings-acl.28 2, 4, 9, 10

25. Hwang, W., Yim, J., Park, S., Yang, S., Seo, M.: Spatial dependency parsing for semi-structured document information extraction. In: Findings of the Association for Computational Linguistics: ACL-IJCNLP 2021. pp. 330–343. Association for Computational Linguistics, Online (Aug 2021). [https://doi.org/10.18653/v1/2021.findings-acl.28](https://doi.org/10.18653/v1/2021.findings-acl.28), [https://aclanthology](https://aclanthology/). org/2021.findings-acl.28 3, 10, 14

26. Jaderberg, M., Simonyan, K., Vedaldi, A., Zisserman, A.: Synthetic data and artificial neural networks for natural scene text recognition. In: Workshop on Deep Learning, NIPS (2014) 13

27. Kang, L., Kumar, J., Ye, P., Li, Y., Doermann, D.S.: Convolutional neural networks for document image classification. 2014 22nd International Conference on Pattern Recognition pp. 3168–3172 (2014) 1, 4, 14

28. Karatzas, D., Gomez-Bigorda, L., Nicolaou, A., Ghosh, S., Bagdanov, A., Iwamura, M., Matas, J., Neumann, L., Chandrasekhar, V.R., Lu, S., Shafait, F., Uchida, S., Valveny, E.: Icdar 2015 competition on robust reading. In: 2015 13th International Conference on Document Analysis and Recognition (ICDAR). pp. 1156–1160 (2015). [https://doi.org/10.1109/ICDAR.2015.7333942](https://doi.org/10.1109/ICDAR.2015.7333942) 13

29. Kim, W., Son, B., Kim, I.: Vilt: Vision-and-language transformer without convolution or region supervision. In: Meila, M., Zhang, T. (eds.) Proceedings of the 38th International Conference on Machine Learning. Proceedings of Machine Learning Research, vol. 139, pp. 5583–5594. PMLR (18–24 Jul 2021), [http://proceedings.mlr.press/v139/kim21k.html](http://proceedings.mlr.press/v139/kim21k.html) 3

30. Kingma, D.P., Ba, J.: Adam: A method for stochastic optimization. In: Bengio, Y., LeCun, Y. (eds.) 3rd International Conference on Learning Representations, ICLR 2015, San Diego, CA, USA, May 7-9, 2015, Conference Track Proceedings (2015), [http://arxiv.org/abs/1412.6980](http://arxiv.org/abs/1412.6980) 8

31. Klaiman, S., Lehne, M.: Docreader: Bounding-box free training of a document information extraction model. In: Document Analysis and Recognition – ICDAR 2021: 16th International Conference, Lausanne, Switzerland, September 5–10, 2021, Proceedings, Part I. p. 451–465. Springer-Verlag, Berlin, Heidelberg (2021). [https://doi.org/10.1007/978-3-030-86549-8](https://doi.org/10.1007/978-3-030-86549-8) 29, [https://doi.org/10](https://doi.org/10). 1007/978-3-030-86549-8\_29 4

32. Lewis, D., Agam, G., Argamon, S., Frieder, O., Grossman, D., Heard, J.: Building a test collection for complex document information processing. In: Proceedings of the 29th Annual International ACM SIGIR Conference on Research and Development in Information Retrieval. p. 665–666. SIGIR ’06, Association for Computing Machinery, New York, NY, USA (2006). [https://doi.org/10.1145/1148170.1148307](https://doi.org/10.1145/1148170.1148307), [https://doi.org/10.1145/1148170.1148307](https://doi.org/10.1145/1148170.1148307) 4, 5

33. Lewis, M., Liu, Y., Goyal, N., Ghazvininejad, M., Mohamed, A., Levy, O., Stoyanov, V., Zettlemoyer, L.: BART: Denoising sequence-to-sequence pre-training for natural language generation, translation, and comprehension. In: Proceedings of the 58th Annual Meeting of the Association for Computational Linguistics. pp. 7871–7880. Association for Computational Linguistics, Online (Jul 2020). [https://doi.org/10.18653/v1/2020.acl-main.703](https://doi.org/10.18653/v1/2020.acl-main.703), [https://aclanthology](https://aclanthology/). org/2020.acl-main.703 5

34. Li, C., Bi, B., Yan, M., Wang, W., Huang, S., Huang, F., Si, L.: StructuralLM: Structural pre-training for form understanding. In: Proceedings of the 59th Annual Meeting of the Association for Computational Linguistics and the 11th International Joint Conference on Natural Language Processing (Volume 1: Long Papers). pp. 6309–6318. Association for Computational Linguistics, Online (Aug 2021). [https://doi.org/10.18653/v1/2021.acl-long.493](https://doi.org/10.18653/v1/2021.acl-long.493), https: //aclanthology.org/2021.acl-long.493 14

35. Li, P., Gu, J., Kuen, J., Morariu, V.I., Zhao, H., Jain, R., Manjunatha, V., Liu, H.: Selfdoc: Self-supervised document representation learning. In: 2021 IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR). pp. 5648–5656 (2021). [https://doi.org/10.1109/CVPR46437.2021.00560](https://doi.org/10.1109/CVPR46437.2021.00560) 14

36. Liao, M., Shi, B., Bai, X., Wang, X., Liu, W.: Textboxes: A fast text detector with a single deep neural network. Proceedings of the AAAI Conference on Artificial Intelligence 31(1) (Feb 2017). [https://doi.org/10.1609/aaai.v31i1.11196](https://doi.org/10.1609/aaai.v31i1.11196), https: //ojs.aaai.org/index.php/AAAI/article/view/11196 13

37. Liu, W., Chen, C., Wong, K.Y.K., Su, Z., Han, J.: Star-net: A spatial attention residue network for scene text recognition. In: Richard C. Wilson, E.R.H., Smith, W.A.P. (eds.) Proceedings of the British Machine Vision Conference (BMVC). pp. 43.1–43.13. BMVA Press (September 2016). [https://doi.org/10.5244/C.30.43](https://doi.org/10.5244/C.30.43), [https://dx.doi.org/10.5244/C.30.43](https://dx.doi.org/10.5244/C.30.43) 13

38. Liu, Y., Gu, J., Goyal, N., Li, X., Edunov, S., Ghazvininejad, M., Lewis, M., Zettlemoyer, L.: Multilingual denoising pre-training for neural machine translation. Transactions of the Association for Computational Linguistics 8, 726–742 (2020), [https://aclanthology.org/2020.tacl-1.47](https://aclanthology.org/2020.tacl-1.47) 5

39. Liu, Y., Chen, H., Shen, C., He, T., Jin, L., Wang, L.: Abcnet: Real-time scene text spotting with adaptive bezier-curve network. In: Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR) (June 2020) 2

40. Liu, Z., Lin, Y., Cao, Y., Hu, H., Wei, Y., Zhang, Z., Lin, S., Guo, B.: Swin transformer: Hierarchical vision transformer using shifted windows. In: Proceedings of the IEEE/CVF International Conference on Computer Vision (ICCV). pp. 10012– 10022 (October 2021) 4, 8, 12

41. Long, S., Yao, C.: Unrealtext: Synthesizing realistic scene text images from the unreal world. arXiv preprint arXiv:2003.10608 (2020) 6

42. Majumder, B.P., Potti, N., Tata, S., Wendt, J.B., Zhao, Q., Najork, M.: Representation learning for information extraction from form-like documents. In: Proceedings of the 58th Annual Meeting of the Association for Computational Linguistics. pp. 6495–6504. Association for Computational Linguistics, Online (Jul 2020). [https://doi.org/10.18653/v1/2020.acl-main.580](https://doi.org/10.18653/v1/2020.acl-main.580), [https://www.aclweb](https://www.aclweb/). org/anthology/2020.acl-main.580 1, 14

43. Majumder, B.P., Potti, N., Tata, S., Wendt, J.B., Zhao, Q., Najork, M.: Representation learning for information extraction from form-like documents. In: Proceedings of the 58th Annual Meeting of the Association for Computational Linguistics. pp. 6495–6504. Association for Computational Linguistics, Online (Jul 2020). [https://doi.org/10.18653/v1/2020.acl-main.580](https://doi.org/10.18653/v1/2020.acl-main.580), [https://aclanthology](https://aclanthology/). org/2020.acl-main.580 3

44. Mathew, M., Karatzas, D., Jawahar, C.: Docvqa: A dataset for vqa on document images. In: Proceedings of the IEEE/CVF Winter Conference on Applications of Computer Vision. pp. 2200–2209 (2021) 1, 8, 12, 14

45. Park, S., Shin, S., Lee, B., Lee, J., Surh, J., Seo, M., Lee, H.: Cord: A consolidated receipt dataset for post-ocr parsing. In: Workshop on Document Intelligence at NeurIPS 2019 (2019) 2, 7, 10, 12, 13

46. Peng, D., Wang, X., Liu, Y., Zhang, J., Huang, M., Lai, S., Zhu, S., Li, J., Lin, D., Shen, C., Jin, L.: SPTS: Single-Point Text Spotting. CoRR abs/2112.07917 (2021), [https://arxiv.org/abs/2112.07917](https://arxiv.org/abs/2112.07917) 2

47. Phan, T.Q., Shivakumara, P., Tian, S., Tan, C.L.: Recognizing text with perspective distortion in natural scenes. In: Proceedings of the IEEE International Conference on Computer Vision (ICCV) (December 2013) 13

48. Powalski, R., Borchmann, L., Jurkiewicz, D., Dwojak, T., Pietruszka, M., Pa lka, G.: Going full-tilt boogie on document understanding with text-image-layout transformer. In: Llad´os, J., Lopresti, D., Uchida, S. (eds.) Document Analysis and Recognition – ICDAR 2021. pp. 732–747. Springer International Publishing, Cham (2021) 14

49. Riba, P., Dutta, A., Goldmann, L., Forn´es, A., Ramos, O., Llad´os, J.: Table detection in invoice documents by graph neural networks. In: 2019 International Conference on Document Analysis and Recognition (ICDAR). pp. 122–127 (2019). [https://doi.org/10.1109/ICDAR.2019.00028](https://doi.org/10.1109/ICDAR.2019.00028) 3

50. Rijhwani, S., Anastasopoulos, A., Neubig, G.: OCR Post Correction for Endangered Language Texts. In: Proceedings of the 2020 Conference on Empirical Methods in Natural Language Processing (EMNLP). pp. 5931–5942. Association for Computational Linguistics, Online (Nov 2020). [https://doi.org/10.18653/v1/2020.emnlp-main.478](https://doi.org/10.18653/v1/2020.emnlp-main.478), [https://aclanthology.org/](https://aclanthology.org/) 2020.emnlp-main.478 3, 11

51. Schaefer, R., Neudecker, C.: A two-step approach for automatic OCR postcorrection. In: Proceedings of the The 4th Joint SIGHUM Workshop on Computational Linguistics for Cultural Heritage, Social Sciences, Humanities and Literature. pp. 52–57. International Committee on Computational Linguistics, Online (Dec 2020), [https://aclanthology.org/2020.latechclfl-1.6](https://aclanthology.org/2020.latechclfl-1.6) 3, 11

52. Shi, B., Bai, X., Yao, C.: An end-to-end trainable neural network for image-based sequence recognition and its application to scene text recognition. IEEE Transactions on Pattern Analysis and Machine Intelligence 39, 2298–2304 (2017) 13

53. Shi, B., Wang, X., Lyu, P., Yao, C., Bai, X.: Robust scene text recognition with automatic rectification. In: 2016 IEEE Conference on Computer Vision and Pattern Recognition (CVPR). pp. 4168–4176 (2016). [https://doi.org/10.1109/CVPR.2016.452](https://doi.org/10.1109/CVPR.2016.452) 13

54. Taghva, K., Beckley, R., Coombs, J.: The effects of ocr error on the extraction of private information. In: Bunke, H., Spitz, A.L. (eds.) Document Analysis Systems VII. pp. 348–357. Springer Berlin Heidelberg, Berlin, Heidelberg (2006) 2

55. Tan, M., Le, Q.: Efficientnetv2: Smaller models and faster training. In: Meila, M., Zhang, T. (eds.) Proceedings of the 38th International Conference on Machine Learning. Proceedings of Machine Learning Research, vol. 139, pp. 10096–10106. PMLR (18–24 Jul 2021), [https://proceedings.mlr.press/v139/tan21a.html](https://proceedings.mlr.press/v139/tan21a.html) 12

56. Tian, Z., Huang, W., He, T., He, P., Qiao, Y.: Detecting text in natural image with connectionist text proposal network. In: Leibe, B., Matas, J., Sebe, N., Welling, M. (eds.) Computer Vision – ECCV 2016. pp. 56–72. Springer International Publishing, Cham (2016) 13

57. Tito, R., Mathew, M., Jawahar, C.V., Valveny, E., Karatzas, D.: Icdar 2021 competition on document visual question answering. In: Llad´os, J., Lopresti, D., Uchida, S. (eds.) Document Analysis and Recognition – ICDAR 2021. pp. 635–649. Springer International Publishing, Cham (2021) 1, 14

58. Vaswani, A., Shazeer, N., Parmar, N., Uszkoreit, N., Jones, L., Gomez, A.N., Kaiser, L.u., Polosukhin, I.: Attention is all you need. In: Guyon, I., Luxburg, U.V., Bengio, S., Wallach, H., Fergus, R., Vishwanathan, S., Garnett, R. (eds.) Advances in Neural Information Processing Systems. vol. 30. Curran Associates, Inc. (2017), [https://proceedings.neurips.cc/paper/2017/file/](https://proceedings.neurips.cc/paper/2017/file/) 3f5ee243547dee91fbd053c1c4a845aa-Paper.pdf 4, 5, 12

59. Wang, J., Hu, X.: Gated recurrent convolution neural network for ocr. In: Guyon, I., Luxburg, U.V., Bengio, S., Wallach, H., Fergus, R., Vishwanathan, S., Garnett, R. (eds.) Advances in Neural Information Processing Systems. vol. 30. Curran Associates, Inc. (2017), [https://proceedings.neurips.cc/paper/2017/](https://proceedings.neurips.cc/paper/2017/) file/c24cd76e1ce41366a4bbe8a49b02a028-Paper.pdf 13

60. Wang, S., Li, B., Khabsa, M., Fang, H., Ma, H.: Linformer: Self-attention with linear complexity. arXiv preprint arXiv:2006.04768 (2020) 12

61. Williams, R.J., Zipser, D.: A learning algorithm for continually running fully recurrent neural networks. Neural computation 1(2), 270–280 (1989) 5

62. Xu, Y., Xu, Y., Lv, T., Cui, L., Wei, F., Wang, G., Lu, Y., Florencio, D., Zhang, C., Che, W., Zhang, M., Zhou, L.: LayoutLMv2: Multi-modal pre-training for visually-rich document understanding. In: Proceedings of the 59th Annual Meeting of the Association for Computational Linguistics and the 11th International Joint Conference on Natural Language Processing (Volume 1: Long Papers). pp. 2579–2591. Association for Computational Linguistics, Online (Aug 2021). [https://doi.org/10.18653/v1/2021.acl-long.201](https://doi.org/10.18653/v1/2021.acl-long.201), https: //aclanthology.org/2021.acl-long.201 2, 4, 9, 10, 11, 14

63. Xu, Y., Li, M., Cui, L., Huang, S., Wei, F., Zhou, M.: Layoutlm: Pre-training of text and layout for document image understanding. In: Proceedings of the 26th ACM SIGKDD International Conference on Knowledge Discovery & Data Mining. p. 1192–1200. KDD ’20, Association for Computing Machinery, New York, NY, USA (2020). [https://doi.org/10.1145/3394486.3403172](https://doi.org/10.1145/3394486.3403172), [https://doi.org/](https://doi.org/) 10.1145/3394486.3403172 2, 3, 7, 9, 11, 14

64. Xu, Y., Lv, T., Cui, L., Wang, G., Lu, Y., Florencio, D., Zhang, C., Wei, F.: Layoutxlm: Multimodal pre-training for multilingual visually-rich document understanding. arXiv preprint arXiv:2104.08836 (2021) 10

65. Yim, M., Kim, Y., Cho, H.C., Park, S.: Synthtiger: Synthetic text image generator towards better text recognition models. In: Llad´os, J., Lopresti, D., Uchida, S. (eds.) Document Analysis and Recognition – ICDAR 2021. pp. 109–124. Springer International Publishing, Cham (2021) 5, 6

66. Zhang, K., Shasha, D.: Simple fast algorithms for the editing distance between trees and related problems. SIAM J. Comput. 18, 1245–1262 (12 1989). [https://doi.org/10.1137/0218082](https://doi.org/10.1137/0218082) 7

67. Zhang, Z., Zhang, C., Shen, W., Yao, C., Liu, W., Bai, X.: Multi-oriented text detection with fully convolutional networks. In: 2016 IEEE Conference on Computer Vision and Pattern Recognition (CVPR). pp. 4159–4167 (2016). [https://doi.org/10.1109/CVPR.2016.451](https://doi.org/10.1109/CVPR.2016.451) 13

68. Zhong, X., ShafieiBavani, E., Jimeno Yepes, A.: Image-based table recognition: Data, model, and evaluation. In: Vedaldi, A., Bischof, H., Brox, T., Frahm, J.M. (eds.) Computer Vision – ECCV 2020. pp. 564–580. Springer International Publishing, Cham (2020) 7

</details>


## Code Sources

<details>
<summary>Repository analysis for https://github.com/towardsai/course-ai-agents/blob/dev/lessons/11_multimodal/notebook.ipynb</summary>

# Repository analysis for https://github.com/towardsai/course-ai-agents/blob/dev/lessons/11_multimodal/notebook.ipynb

## Summary
Repository: towardsai/course-ai-agents
Branch: dev
File: notebook.ipynb
Lines: 1,414

Estimated tokens: 11.9k

## File tree
```Directory structure:
└── notebook.ipynb

```

## Extracted content
================================================
FILE: lessons/11_multimodal/notebook.ipynb
================================================
# Jupyter notebook converted to Python script.

"""
# Lesson 11: Multimodal

This notebook demonstrates how to build multimodal AI systems that can process and understand multimodal data such text, images and documents using Google's Gemini models.

We will use the `google-genai` library to interact with Google's Gemini models.

**Learning Objectives:**

1. **Process multimodal content**: Learn to handle images and PDFs in different formats (bytes, base64, URLs) with Gemini models
2. **Implement object detection**: Use multimodal LLMs for visual analysis and structured output generation
3. **Build multimodal RAG systems**: Create and index embeddings for images, documents and text to enable semantic search across multimodal content
4. **Develop multimodal AI agents**: Construct ReAct agents that can search through and reason about multimodal information
"""

"""
## 1. Setup

First, we define some standard Magic Python commands to autoreload Python packages whenever they change:
"""

%load_ext autoreload
%autoreload 2

"""
### Set Up Python Environment

To set up your Python virtual environment using `uv` and load it into the Notebook, follow the step-by-step instructions from the `Course Admin` lesson from the beginning of the course.

**TL/DR:** Be sure the correct kernel pointing to your `uv` virtual environment is selected.
"""

"""
### Configure Gemini API

To configure the Gemini API, follow the step-by-step instructions from the `Course Admin` lesson.

But here is a quick check on what you need to run this Notebook:

1.  Get your key from [Google AI Studio](https://aistudio.google.com/app/apikey).
2.  From the root of your project, run: `cp .env.example .env` 
3.  Within the `.env` file, fill in the `GOOGLE_API_KEY` variable:

Now, the code below will load the key from the `.env` file:
"""

from lessons.utils import env

env.load(required_env_vars=["GOOGLE_API_KEY"])
# Output:
#   Trying to load environment variables from `/Users/pauliusztin/Documents/01_projects/TAI/course-ai-agents/.env`

#   Environment variables loaded successfully.


"""
### Import Key Packages
"""

import base64
import io
from pathlib import Path
from typing import Literal

from google import genai
from google.genai import types
from IPython.display import Image as IPythonImage
from PIL import Image as PILImage

from lessons.utils import pretty_print

"""
### Initialize the Gemini Client
"""

client = genai.Client()

"""
### Define Constants

We will use the `gemini-2.5-flash` model, which is fast and cost-effective:
"""

MODEL_ID = "gemini-2.5-flash"

"""
## 2. Applying multimodal LLMs to images and PDFs

There are three core ways we can process images and PDFs with multimodal LLMs:
1. As raw bytes
2. As base64 encoded strings
3. As URLs

We will first look into how we can process images and then PDFs.

Now, let's look at our test image:

"""

def display_image(image_path: Path) -> None:
    """
    Display an image from a file path in the notebook.

    Args:
        image_path: Path to the image file to display

    Returns:
        None
    """

    image = IPythonImage(filename=image_path, width=400)
    display(image)


display_image(Path("images") / "image_1.jpeg")
# Output:
#   <IPython.core.display.Image object>

"""
### 2.1 As raw bytes
"""

def load_image_as_bytes(
    image_path: Path, format: Literal["WEBP", "JPEG", "PNG"] = "WEBP", max_width: int = 600, return_size: bool = False
) -> bytes | tuple[bytes, tuple[int, int]]:
    """
    Load an image from file path and convert it to bytes with optional resizing.

    Args:
        image_path: Path to the image file to load
        format: Output image format (WEBP, JPEG, or PNG). Defaults to "WEBP"
        max_width: Maximum width for resizing. If image width exceeds this, it will be resized proportionally. Defaults to 600
        return_size: If True, returns both bytes and image size tuple. Defaults to False

    Returns:
        bytes: Image data as bytes, or tuple of (bytes, (width, height)) if return_size is True
    """

    image = PILImage.open(image_path)
    if image.width > max_width:
        ratio = max_width / image.width
        new_size = (max_width, int(image.height * ratio))
        image = image.resize(new_size)

    byte_stream = io.BytesIO()
    image.save(byte_stream, format=format)

    if return_size:
        return byte_stream.getvalue(), image.size

    return byte_stream.getvalue()

"""
Load image:
"""

image_bytes = load_image_as_bytes(image_path=Path("images") / "image_1.jpeg", format="WEBP")
pretty_print.wrapped([f"Bytes `{image_bytes[:30]}...`", f"Size: {len(image_bytes)} bytes"], title="Image as Bytes")
# Output:
#   [93m------------------------------------------ Image as Bytes ------------------------------------------[0m

#     Bytes `b'RIFF`\xad\x00\x00WEBPVP8 T\xad\x00\x00P\xec\x02\x9d\x01*X\x02X\x02'...`

#   [93m----------------------------------------------------------------------------------------------------[0m

#     Size: 44392 bytes

#   [93m----------------------------------------------------------------------------------------------------[0m


"""
Compute captions:
"""

response = client.models.generate_content(
    model=MODEL_ID,
    contents=[
        types.Part.from_bytes(
            data=image_bytes,
            mime_type="image/webp",
        ),
        "Tell me what is in this image in one paragraph.",
    ],
)
pretty_print.wrapped(response.text, title="Image 1 Caption")

# Output:
#   [93m----------------------------------------- Image 1 Caption -----------------------------------------[0m

#     This image presents a striking contrast between a large, imposing humanoid robot and a small, delicate kitten within an industrial setting. The robot is crafted from dark, intricate metallic plates, featuring a head adorned with circuit-like patterns and intensely glowing red eyes that convey a powerful, almost menacing presence. Perched playfully on the robot's heavily armored right arm, with its front paws resting gently on the shoulder, is a fluffy grey tabby kitten, looking out with an expression of curious innocence. The background reveals a sparse workshop or factory environment with metallic structures and a soft, diffused light source from the upper left, creating a scene that beautifully juxtaposes advanced technology with the simple charm of nature.

#   [93m----------------------------------------------------------------------------------------------------[0m


"""
Using the same approach, we can easily pass multiple images simultaneously. For example, the previous one plus the one below, and compare them:
"""

display_image(Path("images") / "image_2.jpeg")
# Output:
#   <IPython.core.display.Image object>

response = client.models.generate_content(
    model=MODEL_ID,
    contents=[
        types.Part.from_bytes(
            data=load_image_as_bytes(image_path=Path("images") / "image_1.jpeg", format="WEBP"),
            mime_type="image/webp",
        ),
        types.Part.from_bytes(
            data=load_image_as_bytes(image_path=Path("images") / "image_2.jpeg", format="WEBP"),
            mime_type="image/webp",
        ),
        "What's the difference between these two images? Describe it in one paragraph.",
    ],
)
pretty_print.wrapped(response.text, title="Differences between images")

# Output:
#   [93m------------------------------------ Differences between images ------------------------------------[0m

#     The primary difference between the two images is the nature of the interaction and the overall mood. The first image depicts a small, grey kitten playfully climbing on the arm of a large, imposing robot in what appears to be an industrial setting, suggesting curiosity, gentle engagement, or even budding companionship. In stark contrast, the second image portrays a large, fluffy white dog and a sleek, black robot locked in aggressive, confrontational stances in a dilapidated urban alleyway, conveying a clear sense of hostility, imminent conflict, and tension rather than interaction.

#   [93m----------------------------------------------------------------------------------------------------[0m


"""
### 2.2 As base64 encoded strings

Now, let's load the same image as base64:
"""

from typing import cast


def load_image_as_base64(
    image_path: Path, format: Literal["WEBP", "JPEG", "PNG"] = "WEBP", max_width: int = 600, return_size: bool = False
) -> str:
    """
    Load an image and convert it to base64 encoded string.

    Args:
        image_path: Path to the image file to load
        format: Output image format (WEBP, JPEG, or PNG). Defaults to "WEBP"
        max_width: Maximum width for resizing. If image width exceeds this, it will be resized proportionally. Defaults to 600
        return_size: Parameter passed to load_image_as_bytes function. Defaults to False

    Returns:
        str: Base64 encoded string representation of the image
    """

    image_bytes = load_image_as_bytes(image_path=image_path, format=format, max_width=max_width, return_size=False)

    return base64.b64encode(cast(bytes, image_bytes)).decode("utf-8")

image_base64 = load_image_as_base64(image_path=Path("images") / "image_1.jpeg", format="WEBP")
pretty_print.wrapped(
    [f"Base64: {image_base64[:100]}...`", f"Size: {len(image_base64)} characters"], title="Image as Base64"
)
# Output:
#   [93m----------------------------------------- Image as Base64 -----------------------------------------[0m

#     Base64: UklGRmCtAABXRUJQVlA4IFStAABQ7AKdASpYAlgCPm0ylEekIqInJnQ7gOANiWdtk7FnEo2gDknjPixW9SNSb5P7IbBNhLn87Vtp...`

#   [93m----------------------------------------------------------------------------------------------------[0m

#     Size: 59192 characters

#   [93m----------------------------------------------------------------------------------------------------[0m


"""
On average base64 format is 33% larger than raw bytes. As we can see in this use case as well:
"""

print(f"Image as Base64 is {(len(image_base64) - len(image_bytes)) / len(image_bytes) * 100:.2f}% larger than as bytes")
# Output:
#   Image as Base64 is 33.34% larger than as bytes


"""
Now, let's recompute the image caption using this method:
"""

response = client.models.generate_content(
    model=MODEL_ID,
    contents=[
        types.Part.from_bytes(data=image_base64, mime_type="image/webp"),
        "Tell me what is in this image in one paragraph.",
    ],
)
response.text
# Output:
#   'The image presents a striking juxtaposition of a powerful, metallic robot and a small, curious kitten. The robot, dominating the right side of the frame, features a dark, intricately detailed head resembling circuit board patterns, with intense, glowing red eyes that pierce forward. Its massive, articulated arm is extended, and a fluffy grey tabby kitten is playfully perched on its forearm and shoulder, looking towards the robot with a raised paw as if exploring or batting it. The background suggests an industrial or workshop environment, with metallic structures and diffuse light from a window on the left, highlighting the unexpected encounter between advanced technology and innocent nature.'

"""
### 2.3 As public URLs

Using Gemini `url_context` out-of-the-box tool, we can automatically visit and parse webpages, PDFs, and images from the open internet. You only have to provide the direct URL in the prompt and configure the `url_context` tool. This makes it a no-brainer to parse multiple data formats when available online:
"""

response = client.models.generate_content(
    model=MODEL_ID,
    contents="Based on the provided paper as a PDF, tell me how ReAct works: https://arxiv.org/pdf/2210.03629",
    config=types.GenerateContentConfig(tools=[{"url_context": {}}]),
)
pretty_print.wrapped(response.text, title="How ReAct works")
# Output:
#   [93m----------------------------------------- How ReAct works -----------------------------------------[0m

#     

#   The ReAct (Reasoning and Acting) paradigm is a method that combines verbal reasoning traces with task-specific actions in an interleaved manner within large language models (LLMs). This approach allows for greater synergy between reasoning and acting, enabling LLMs to perform more dynamic reasoning and interact with external environments.

#   

#   Here's a breakdown of how ReAct works:

#   *   **Interleaved Reasoning and Acting:** ReAct prompts LLMs to generate both "thoughts" (verbal reasoning traces) and "actions" related to a task. These are produced in an alternating sequence, mimicking human cognition where inner speech (reasoning) guides actions, and actions provide new information for further reasoning.

#   *   **Reasoning to Act:** The reasoning traces help the model to induce, track, and update action plans, as well as handle exceptions. For example, a thought might involve decomposing a task goal into smaller subgoals, injecting commonsense knowledge, or extracting important information from observations.

#   *   **Acting to Reason:** Actions allow the LLM to interface with and gather additional information from external sources, such as knowledge bases (like a Wikipedia API) or interactive environments. The observations received after an action then inform subsequent reasoning steps.

#   *   **Augmented Action Space:** ReAct augments the agent's action space to include a language space (`L`) for "thoughts" in addition to the traditional action space (`A`) for external interactions. Thoughts do not directly affect the external environment but update the agent's internal context to support future reasoning or acting.

#   *   **Few-shot Prompting:** ReAct primarily utilizes few-shot in-context examples to prompt frozen large language models to generate both domain-specific actions and free-form language thoughts. These examples are human-created trajectories of actions, thoughts, and environment observations.

#   

#   **Benefits of ReAct:**

#   *   **Improved Performance:** ReAct has shown to outperform state-of-the-art baselines that only perform reasoning (Chain-of-Thought) or acting alone in various tasks, including question answering, fact verification, and interactive decision-making benchmarks.

#   *   **Reduced Hallucination and Error Propagation:** By interacting with external sources, ReAct can overcome issues of hallucination and error propagation that can occur in reasoning-only methods.

#   *   **Human Interpretability and Trustworthiness:** The interleaved reasoning traces make the model's task-solving process more interpretable and trustworthy for humans, as they can inspect the reasoning and factual correctness.

#   *   **Flexibility and Generalizability:** The flexible thought space and thought-action occurrence format allow ReAct to be applied to diverse tasks with different action spaces and reasoning needs.

#   

#   In essence, ReAct allows LLMs to think and act in a more integrated and adaptive way, leading to more robust and explainable performance across a range of complex tasks.The ReAct (Reasoning and Acting) paradigm enhances large language models (LLMs) by synergizing verbal reasoning traces with task-specific actions in an interleaved manner. This approach fosters a dynamic interaction where internal reasoning guides external actions, and observations from those actions inform subsequent reasoning steps.

#   

#   Key aspects of how ReAct works include:

#   *   **Interleaved Thoughts and Actions** The core of ReAct involves LLMs generating both "thoughts" (verbal reasoning) and "actions" in an alternating sequence. This mimics human problem-solving, where internal deliberation (e.g., planning, self-correction) is intertwined with physical or communicative actions.

#   *   **Reasoning to Guide Actions** Reasoning traces help the model to formulate, monitor, and adjust action plans, as well as manage unexpected situations. These thoughts can involve breaking down complex goals, incorporating commonsense knowledge, or extracting relevant information from observations.

#   *   **Actions to Inform Reasoning** Actions enable the LLM to interact with external environments, such as a Wikipedia API for knowledge retrieval or simulated environments for decision-making. The observations generated by these actions then provide new information that can be integrated into the reasoning process.

#   *   **Augmented Action Space** ReAct expands the agent's available actions to include a language space for "thoughts," in addition to domain-specific actions that affect the external environment. Thoughts do not alter the environment but update the agent's internal context to support future reasoning or actions.

#   *   **Few-Shot Prompting** The ReAct framework primarily relies on few-shot in-context examples to prompt LLMs. These examples demonstrate a human-like trajectory of thoughts, actions, and environmental observations to guide the model in solving tasks.

#   

#   This integrated approach offers several advantages:

#   *   **Enhanced Performance** ReAct has demonstrated superior performance compared to methods that only employ reasoning (Chain-of-Thought) or acting in isolation, across various tasks like question answering, fact verification, and interactive decision-making.

#   *   **Reduced Errors and Hallucinations** By interacting with external information sources, ReAct helps mitigate issues such as factual hallucinations and error propagation often seen in reasoning-only methods.

#   *   **Improved Interpretability and Trustworthiness** The explicit reasoning traces make the model's decision-making process more transparent and understandable to humans, increasing interpretability and trustworthiness.

#   *   **Flexibility and Generalizability** ReAct's flexible design, accommodating diverse reasoning types and action spaces, allows it to be applied effectively to a wide range of complex tasks.

#   

#   In essence, ReAct empowers LLMs to engage in a more integrated and adaptive problem-solving process by continuously leveraging reasoning to guide actions and using observations from those actions to refine its reasoning.

#   [93m----------------------------------------------------------------------------------------------------[0m


"""
### 2.4 As URLs from private data lakes

At the time of writing this notebook, Gemini works well primarily with GCP Cloud Storage links and not with other buckets such as S3. Buckets are excellent for production use cases, but they complicate our simple demonstration. Therefore, we will show you a mocked example.

The code would look like this, where you have to change the `uri` and ensure the LLM has the right permissions to your GCS bucket:
```python
response = client.models.generate_content(
    model=MODEL_ID,
    contents=[
        types.Part.from_uri(uri="gs://gemini-images/image_1.jpeg", mime_type="image/webp"),
        "Tell me what is in this image in one paragraph.",
    ],
)
```
"""

"""
### 2.5 Object detection with LLMs

As a more exciting example, let's do object detection with multimodal LLMs.

First, let's define the output Pydantic models:
"""

from pydantic import BaseModel, Field


class BoundingBox(BaseModel):
    ymin: float
    xmin: float
    ymax: float
    xmax: float
    label: str = Field(
        default="The category of the object found within the bounding box. For example: cat, dog, diagram, robot."
    )


class Detections(BaseModel):
    bounding_boxes: list[BoundingBox]

"""
Then the prompt and image:
"""

prompt = """
Detect all of the prominent items in the image. 
The box_2d should be [ymin, xmin, ymax, xmax] normalized to 0-1000.
Also, output the label of the object found within the bounding box.
"""

image_bytes, image_size = load_image_as_bytes(
    image_path=Path("images") / "image_1.jpeg", format="WEBP", return_size=True
)

"""
Now, let's call the LLM:
"""

config = types.GenerateContentConfig(
    response_mime_type="application/json",
    response_schema=Detections,
)

response = client.models.generate_content(
    model=MODEL_ID,
    contents=[
        types.Part.from_bytes(
            data=image_bytes,
            mime_type="image/webp",
        ),
        prompt,
    ],
    config=config,
)

detections = cast(Detections, response.parsed)
pretty_print.wrapped([f"Image size: {image_size}", *detections.bounding_boxes], title="Detections")
# Output:
#   [93m-------------------------------------------- Detections --------------------------------------------[0m

#     Image size: (600, 600)

#   [93m----------------------------------------------------------------------------------------------------[0m

#     ymin=2.0 xmin=517.0 ymax=997.0 xmax=1000.0 label='robot'

#   [93m----------------------------------------------------------------------------------------------------[0m

#     ymin=272.0 xmin=28.0 ymax=801.0 xmax=535.0 label='kitten'

#   [93m----------------------------------------------------------------------------------------------------[0m


"""
Let's also visualize the bounding boxes: 
"""

import matplotlib.pyplot as plt
import matplotlib.patches as patches
import numpy as np


def visualize_detections(detections: Detections, image_path: Path) -> None:
    """
    Visualize detected bounding boxes on an image with red rectangles and labels.

    Args:
        detections: Detections object containing bounding boxes in [ymin, xmin, ymax, xmax] format normalized to 0-1000
        image_path: Path to the image file to visualize

    Returns:
        None: Displays the image with bounding boxes in the notebook
    """

    # Clear any existing plots to prevent overlapping
    plt.clf()

    image = PILImage.open(image_path)
    image_array = np.array(image)
    img_height, img_width = image_array.shape[:2]

    fig, ax = plt.subplots(1, 1, figsize=(8, 6))
    ax.imshow(image_array)

    for bbox in detections.bounding_boxes:
        # Convert normalized coordinates (0-1000) to pixel coordinates
        xmin = (bbox.xmin / 1000) * img_width
        ymin = (bbox.ymin / 1000) * img_height
        xmax = (bbox.xmax / 1000) * img_width
        ymax = (bbox.ymax / 1000) * img_height

        # Calculate box dimensions (matplotlib uses bottom-left corner + width/height)
        width = xmax - xmin
        height = ymax - ymin

        # Create rectangle patch (x, y is bottom-left corner)
        rect = patches.Rectangle((xmin, ymin), width, height, linewidth=3, edgecolor="red", facecolor="none")

        # Add rectangle to the plot
        ax.add_patch(rect)

        # Add label text (positioned at top-left of bounding box)
        ax.text(
            xmin,
            ymin + 5,  # Slightly above the box
            bbox.label[:15],
            fontsize=12,
            color="red",
            fontweight="bold",
            bbox=dict(boxstyle="round,pad=0.3", facecolor="white", alpha=0.8),
        )

    # Remove axis ticks and labels for cleaner display
    ax.set_xticks([])
    ax.set_yticks([])
    ax.set_title(f"Object Detection Results: {image_path.name}", fontsize=14, fontweight="bold")

    plt.tight_layout()
    plt.show()

visualize_detections(detections, Path("images") / "image_1.jpeg")
# Output:
#   <Figure size 640x480 with 0 Axes>
#   <Figure size 800x600 with 1 Axes>

"""
### 2.6 Working with PDFs

Ultimately, let's see how we can work with PDFs. We will use the legendary `Attention Is All You Need` Paper as an example. 

To display it, we extracted the first 3 pages of the PDF as images. For example, this is how the page looks:

"""

display_image(Path("images") / "attention_is_all_you_need_0.jpeg")
# Output:
#   <IPython.core.display.Image object>

"""
We can treat PDFs similarly to images. Therefore, we can pass PDFs as bytes:
"""

pdf_bytes = (Path("pdfs") / "attention_is_all_you_need_paper.pdf").read_bytes()
pretty_print.wrapped(f"Bytes: {pdf_bytes[:40]}...", title="PDF bytes")
# Output:
#   [93m-------------------------------------------- PDF bytes --------------------------------------------[0m

#     Bytes: b'%PDF-1.7\n%\xe2\xe3\xcf\xd3\n24 0 obj\n<<\n/Filter /Flat'...

#   [93m----------------------------------------------------------------------------------------------------[0m


"""
Call the LLM:
"""

response = client.models.generate_content(
    model=MODEL_ID,
    contents=[
        types.Part.from_bytes(data=pdf_bytes, mime_type="application/pdf"),
        "What is this document about? Provide a brief summary of the main topics.",
    ],
)
pretty_print.wrapped(response.text, title="PDF Summary (as bytes)")
# Output:
#   [93m-------------------------------------- PDF Summary (as bytes) --------------------------------------[0m

#     This document introduces the **Transformer**, a novel neural network architecture for **sequence transduction** (e.g., machine translation) that relies **solely on attention mechanisms**, entirely **dispensing with recurrent and convolutional layers**.

#   

#   The main topics covered include:

#   

#   1.  **The Transformer Architecture:** A detailed description of its encoder-decoder structure, utilizing stacked multi-head self-attention and position-wise fully connected layers.

#   2.  **Attention Mechanisms:** Explanation of scaled dot-product attention, multi-head attention, and their application within the encoder and decoder.

#   3.  **Positional Encoding:** How sequence order information is integrated into the model, given the absence of recurrence or convolution.

#   4.  **Advantages of Self-Attention:** A comparison highlighting self-attention's benefits in computational complexity, parallelization, and handling long-range dependencies.

#   5.  **Performance and Results:** Experimental findings demonstrating the Transformer's superior quality (achieving state-of-the-art BLEU scores) and significantly faster training times on WMT 2014 English-to-German and English-to-French machine translation tasks.

#   6.  **Generalization:** Successful application of the Transformer to English constituency parsing, showcasing its versatility.

#   [93m----------------------------------------------------------------------------------------------------[0m


"""
Alternatively, as base64 encoded strings:
"""

def load_pdf_as_base64(pdf_path: Path) -> str:
    """
    Load a PDF file and convert it to base64 encoded string.

    Args:
        pdf_path: Path to the PDF file to load

    Returns:
        str: Base64 encoded string representation of the PDF
    """

    with open(pdf_path, "rb") as f:
        return base64.b64encode(f.read()).decode("utf-8")

"""
Load the PDF:
"""

pdf_base64 = load_pdf_as_base64(pdf_path=Path("pdfs") / "attention_is_all_you_need_paper.pdf")
pretty_print.wrapped(f"Base64: {pdf_base64[:40]}...", title="PDF as Base64")
# Output:
#   [93m------------------------------------------ PDF as Base64 ------------------------------------------[0m

#     Base64: JVBERi0xLjcKJeLjz9MKMjQgMCBvYmoKPDwKL0Zp...

#   [93m----------------------------------------------------------------------------------------------------[0m


"""
Call the LLM:
"""

response = client.models.generate_content(
    model=MODEL_ID,
    contents=[
        "What is this document about? Provide a brief summary of the main topics.",
        types.Part.from_bytes(data=pdf_base64, mime_type="application/pdf"),
    ],
)

pretty_print.wrapped(response.text, title="PDF Summary (as base64)")
# Output:
#   [93m------------------------------------- PDF Summary (as base64) -------------------------------------[0m

#     This document introduces **The Transformer**, a novel neural network architecture designed for sequence transduction tasks, such as machine translation.

#   

#   Here's a brief summary of the main topics:

#   

#   1.  **Introduction of the Transformer Architecture:** The paper proposes a new model that completely dispenses with recurrent neural networks (RNNs) and convolutional neural networks (CNNs), relying entirely on **attention mechanisms**.

#   2.  **Self-Attention and Multi-Head Attention:** The core of the Transformer is its self-attention mechanism, specifically a "Scaled Dot-Product Attention" which is further enhanced by "Multi-Head Attention" to allow the model to jointly attend to information from different representation subspaces.

#   3.  **Encoder-Decoder Structure with Positional Encodings:** The Transformer maintains an encoder-decoder structure, with each stack composed of multiple identical layers. Since it lacks recurrence or convolutions, "positional encodings" are added to the input embeddings to inject information about the sequence order.

#   4.  **Performance and Efficiency:** The model is shown to be superior in quality, more parallelizable, and requires significantly less training time compared to existing dominant models based on RNNs or CNNs.

#   5.  **State-of-the-Art Results:** It achieves new state-of-the-art BLEU scores on WMT 2014 English-to-German and English-to-French machine translation tasks.

#   6.  **Generalization to Other Tasks:** The Transformer's effectiveness is also demonstrated on English constituency parsing, indicating its potential for broader applicability.

#   [93m----------------------------------------------------------------------------------------------------[0m


"""
Now, let's do a more interesting example and detect the diagrams from a page of the transformers paper, such as the one below:
"""

display_image(Path("images") / "attention_is_all_you_need_1.jpeg")
# Output:
#   <IPython.core.display.Image object>

"""
Define the object detection prompt to detect diagrams (similar to how we did for images):
"""

prompt = """
Detect all the diagrams from the provided image as 2d bounding boxes. 
The box_2d should be [ymin, xmin, ymax, xmax] normalized to 0-1000.
Also, output the label of the object found within the bounding box.
"""

image_bytes, image_size = load_image_as_bytes(
    image_path=Path("images") / "attention_is_all_you_need_1.jpeg", format="WEBP", return_size=True
)

"""
Call the LLM:
"""

config = types.GenerateContentConfig(
    response_mime_type="application/json",
    response_schema=Detections,
)
response = client.models.generate_content(
    model=MODEL_ID,
    contents=[
        types.Part.from_bytes(
            data=image_bytes,
            mime_type="image/webp",
        ),
        prompt,
    ],
    config=config,
)
detections = cast(Detections, response.parsed)
pretty_print.wrapped([f"Image size: {image_size}", *detections.bounding_boxes], title="Detections")
# Output:
#   [93m-------------------------------------------- Detections --------------------------------------------[0m

#     Image size: (600, 776)

#   [93m----------------------------------------------------------------------------------------------------[0m

#     ymin=80.0 xmin=280.0 ymax=470.0 xmax=720.0 label='diagram'

#   [93m----------------------------------------------------------------------------------------------------[0m


"""
Visualize the detections:
"""

visualize_detections(detections, Path("images") / "attention_is_all_you_need_1.jpeg")
# Output:
#   <Figure size 640x480 with 0 Axes>
#   <Figure size 800x600 with 1 Axes>

"""
## 3. Implementing multimodal RAG for images, PDFs and text

To bring everything we did in this course together, let's implement a multimodal RAG system that works with text, images, and PDFs.

These are the images and PDF pages (as images) we will index for semantic search:
"""

def display_image_grid(image_paths: list[Path], rows: int = 2, cols: int = 2, figsize: tuple = (8, 6)) -> None:
    """
    Display a grid of images.

    Args:
        image_paths: List of paths to images to display
        rows: Number of rows in the grid
        cols: Number of columns in the grid
        figsize: Figure size as (width, height)
    """

    fig, axes = plt.subplots(rows, cols, figsize=figsize)
    axes = axes.ravel()

    for idx, img_path in enumerate(image_paths[: rows * cols]):
        img = PILImage.open(img_path)
        axes[idx].imshow(img)
        axes[idx].axis("off")

    plt.tight_layout()
    plt.show()


display_image_grid(
    image_paths=[
        Path("images") / "image_1.jpeg",
        Path("images") / "image_2.jpeg",
        Path("images") / "image_3.jpeg",
        Path("images") / "image_4.jpeg",
        Path("images") / "attention_is_all_you_need_1.jpeg",
        Path("images") / "attention_is_all_you_need_2.jpeg",
    ],
    rows=2,
    cols=3,
)
# Output:
#   <Figure size 800x600 with 6 Axes>

"""
Now, let's define the core functions.

First, one that creates image descriptions:
"""

from io import BytesIO
from typing import Any

import numpy as np


def generate_image_description(image_bytes: bytes) -> str:
    """
    Generate a detailed description of an image using Gemini Vision model.

    Args:
        image_bytes: Image data as bytes

    Returns:
        str: Generated description of the image
    """

    try:
        # Convert bytes back to PIL Image for vision model
        img = PILImage.open(BytesIO(image_bytes))

        # Use Gemini Vision model to describe the image
        prompt = """
        Describe this image in detail for semantic search purposes. 
        Include objects, scenery, colors, composition, text, and any other visual elements that would help someone find 
        this image through text queries.
        """

        response = client.models.generate_content(
            model=MODEL_ID,
            contents=[prompt, img],
        )

        if response and response.text:
            description = response.text.strip()

            return description
        else:
            print("❌ No description generated from vision model")

            return ""

    except Exception as e:
        print(f"❌ Failed to generate image description: {e}")

        return ""


"""
Another one that creates embedding using `gemini_embedding-001`, based on the given input:
"""

def embed_text_with_gemini(content: str) -> np.ndarray | None:
    """
    Embed text content using Gemini's text embedding model.

    Args:
        content: Text string to embed

    Returns:
        np.ndarray | None: Embedding vector as numpy array or None if failed
    """

    try:
        result = client.models.embed_content(
            model="gemini-embedding-001",  # Gemini's text embedding model
            contents=[content],
        )
        if not result or not result.embeddings:
            print("❌ No embedding data found in response")
            return None

        return np.array(result.embeddings[0].values)

    except Exception as e:
        print(f"❌ Failed to embed text: {e}")
        return None

"""
Let's see how this works:
"""

embedding = embed_text_with_gemini("This is a test")
embedding
# Output:
#   array([-0.02252334, -0.00076438,  0.00240217, ..., -0.00574729,

#          -0.00052345, -0.00213343], shape=(3072,))

"""
As we can see below, it creates a 3072 embedding from the input text:
"""

embedding.shape
# Output:
#   (3072,)

"""
Let's glue these functions and create the vector index out of our test images and PDF pages:
"""

from typing import cast


def create_vector_index(image_paths: list[Path]) -> list[dict]:
    """
    Create embeddings for images by generating descriptions and embedding them.

    This function processes a list of image paths by:
    1. Loading each image as bytes
    2. Generating a text description using Gemini Vision
    3. Creating an embedding of that description using Gemini Embeddings

    Args:
        image_paths (list[Path]): List of paths to image files to process

    Returns:
        list[dict]: List of dictionaries with the following keys:
            - content (bytes): Raw image bytes
            - type (str): Always "image"
            - filename (Path): Original image path
            - description (str): Generated image description
            - embedding (np.ndarray): Vector embedding of the description
    """

    vector_index = []
    for image_path in image_paths:
        image_bytes = cast(bytes, load_image_as_bytes(image_path, format="WEBP", return_size=False))

        image_description = generate_image_description(image_bytes)
        pretty_print.wrapped(f"`{image_description[:500]}...`", title="Generated image description:")

        # IMPORTANT NOTE: When working with multimodal embedding models, we can directly embed the
        # `image_bytes` instead of generating and embedding the description. Otherwise, everything
        # else remains the same within the whole RAG system.
        image_embedding = embed_text_with_gemini(image_description)

        vector_index.append(
            {
                "content": image_bytes,
                "type": "image",
                "filename": image_path,
                "description": image_description,
                "embedding": image_embedding,
            }
        )

    return vector_index

"""
We call the `create_vector_index` function on all the images from the `images` dir:
"""

image_paths = list(Path("images").glob("*.jpeg"))
vector_index = create_vector_index(image_paths)
# Output:
#   [93m----------------------------------- Generated image description: -----------------------------------[0m

#     `This image is a page from a technical document, likely a research paper or textbook, focusing on the "Attention" mechanism in machine learning, particularly for Transformer models.

#   

#   **Composition and Layout:**

#   The page has a clean, professional layout with black text on a white background. The top half is dominated by two distinct block diagrams side-by-side, visually explaining complex concepts. The bottom half is dense with technical text, including headings, paragraphs, a mathematical equatio...`

#   [93m----------------------------------------------------------------------------------------------------[0m

#   [93m----------------------------------- Generated image description: -----------------------------------[0m

#     `This image features a striking juxtaposition of a futuristic, menacing robot and an adorable, curious kitten in an industrial setting.

#   

#   **Objects:**

#   

#   1.  **Robot:** Occupying the right and center-right of the frame, a large, powerful, humanoid robot is depicted from the chest up.

#       *   **Head/Helmet:** The robot's head is designed like a sleek, dark metallic helmet, featuring intricate circuit board patterns or etched lines across its surface, giving it a high-tech, integrated look.

#       *   **...`

#   [93m----------------------------------------------------------------------------------------------------[0m

#   [93m----------------------------------- Generated image description: -----------------------------------[0m

#     `This image depicts a dramatic and unusual confrontation between a fluffy white dog and a sleek, dark humanoid robot in a gritty urban alleyway.

#   

#   **Objects:**

#   *   **Dog:** A large, white, long-haired dog, strongly resembling a Samoyed or a white husky mix, is positioned on the left side of the frame. It stands on its hind legs, with its front paws raised and mouth open in a snarl or aggressive bark, revealing sharp teeth. Its fluffy tail is curled over its back. A dark collar is visible around it...`

#   [93m----------------------------------------------------------------------------------------------------[0m

#   [93m----------------------------------- Generated image description: -----------------------------------[0m

#     `This image captures a close-up, highly detailed view of a focused African American man engaged in building or repairing a desktop computer, illuminated by internal LED lights.

#   

#   **Objects:**

#   *   **Person:** A mature African American man with a well-groomed, greying beard and mustache, wearing black-framed glasses. He is dressed in a dark, possibly teal or greyish-blue, crew-neck t-shirt. His brow is furrowed in concentration, and his gaze is directed downwards into the computer case.

#   *   **Comput...`

#   [93m----------------------------------------------------------------------------------------------------[0m

#   [93m----------------------------------- Generated image description: -----------------------------------[0m

#     `This image displays a detailed technical diagram of the **Transformer model architecture**, a fundamental neural network structure in deep learning, particularly for natural language processing (NLP) tasks. The diagram, labeled "Figure 1: The Transformer - model architecture," is centrally placed on a white page, with descriptive text below it.

#   

#   **Diagram Details:**

#   

#   The architecture is presented as an **encoder-decoder stack**, depicted in two main vertical columns.

#   

#   1.  **Input and Embedding L...`

#   [93m----------------------------------------------------------------------------------------------------[0m

#   [93m----------------------------------- Generated image description: -----------------------------------[0m

#     `This image depicts a highly dynamic and intense futuristic robot battle in a sleek, dimly lit arena. Two humanoid robots are engaged in a powerful fistfight, with one delivering a devastating blow to the other.

#   

#   **Objects:**

#   *   **Left Robot:** This robot is sleek and agile, predominantly metallic silver or chrome with bright blue glowing accents. Blue light emanates from its head (acting as a visor or eyes) and a strip across its chest. Its armor appears streamlined and polished. It is shown in...`

#   [93m----------------------------------------------------------------------------------------------------[0m

#   [93m----------------------------------- Generated image description: -----------------------------------[0m

#     `This image is a detailed depiction of the first page of a seminal academic paper titled "Attention Is All You Need." It features a clean, professional layout on a white background with black text, and a distinct reddish-brown disclaimer at the top.

#   

#   **Overall Composition & Layout:**

#   The page is organized in a single-column format, characteristic of research papers or preprints. Text is the dominant visual element, structured into distinct sections: a copyright notice, the main title, author and ...`

#   [93m----------------------------------------------------------------------------------------------------[0m


if len(vector_index) == 0:
    pretty_print.wrapped("Could not create the vector index.", title="❌")
else:
    pretty_print.wrapped(
        f"Successfully created {len(vector_index)} embeddings under the `vector_index` variable", title="✅"
    )
# Output:
#   [93m------------------------------------------------ ✅ ------------------------------------------------[0m

#     Successfully created 7 embeddings under the `vector_index` variable

#   [93m----------------------------------------------------------------------------------------------------[0m


"""
This is how an element from the `vector_index` looks like:
"""

vector_index[0].keys()
# Output:
#   dict_keys(['content', 'type', 'filename', 'description', 'embedding'])

vector_index[0]["embedding"].shape
# Output:
#   (3072,)

print(f"{vector_index[0]['description'][:150]}...")
# Output:
#   This image is a page from a technical document, likely a research paper or textbook, focusing on the "Attention" mechanism in machine learning, partic...


"""
Now let's define a function that finds `top_k` most similar items from the vector_index based on a user query:
"""

from sklearn.metrics.pairwise import cosine_similarity


def search_multimodal(query_text: str, vector_index: list[dict], top_k: int = 3) -> list[Any]:
    """
    Search for most similar documents to query using direct Gemini client.

    This function embeds the query text and compares it against pre-computed embeddings
    of document descriptions to find the most semantically similar matches.

    Args:
        query_text: Text query to search for
        docs: List of document dictionaries containing embeddings and metadata
        top_k: Number of top results to return. Defaults to 3

    Returns:
        list[Any]: List of document dictionaries with similarity scores, sorted by relevance
    """

    print(f"\n🔍 Embedding query: '{query_text}'")

    query_embedding = embed_text_with_gemini(query_text)

    if query_embedding is None:
        print("❌ Failed to embed query")
        return []
    else:
        print("✅ Query embedded successfully")

    # Calculate similarities using our custom function
    embeddings = [doc["embedding"] for doc in vector_index]
    similarities = cosine_similarity([query_embedding], embeddings).flatten()

    # Get top results
    top_indices = np.argsort(similarities)[::-1][:top_k]  # type: ignore

    results = []
    for idx in top_indices.tolist():
        results.append({**vector_index[idx], "similarity": similarities[idx]})

    return results

"""
Let's test this with an example:
"""

query = "what is the architecture of the transformer neural network?"
results = search_multimodal(query, vector_index, top_k=1)

if not results:
    pretty_print.wrapped("❌ No results found", title="❌")
else:
    result = results[0]

    pretty_print.wrapped(
        [
            f"Similarity {result['similarity']:.3f}",
            f"Filename {result['filename']}",
            f"Description `{result['description'][:1000]}...`",
        ],
        title=f"Results for query = {query}",
    )
    display_image(Path(result["filename"]))
# Output:
#   

#   🔍 Embedding query: 'what is the architecture of the transformer neural network?'

#   ✅ Query embedded successfully

#   [93m--------- Results for query = what is the architecture of the transformer neural network? ---------[0m

#     Similarity 0.786

#   [93m----------------------------------------------------------------------------------------------------[0m

#     Filename images/attention_is_all_you_need_1.jpeg

#   [93m----------------------------------------------------------------------------------------------------[0m

#     Description `This image displays a detailed technical diagram of the **Transformer model architecture**, a fundamental neural network structure in deep learning, particularly for natural language processing (NLP) tasks. The diagram, labeled "Figure 1: The Transformer - model architecture," is centrally placed on a white page, with descriptive text below it.

#   

#   **Diagram Details:**

#   

#   The architecture is presented as an **encoder-decoder stack**, depicted in two main vertical columns.

#   

#   1.  **Input and Embedding Layers (Bottom):**

#       *   At the very bottom left, a black arrow points to a label "Inputs."

#       *   Directly above it is a light pink rectangular block labeled "Input Embedding."

#       *   A circular light gray block labeled "Positional Encoding" is connected via a black arrow and a "+" sign to the "Input Embedding" block's output.

#       *   Similarly, on the bottom right, a label "Outputs (shifted right)" has an arrow pointing to a light pink rectangular block labeled "Output Embedding."

#       *   A...`

#   [93m----------------------------------------------------------------------------------------------------[0m

#   <IPython.core.display.Image object>

"""
...and another example:
"""

query = "a kitten with a robot"
results = search_multimodal(query, vector_index, top_k=1)

if not results:
    pretty_print.wrapped("❌ No results found", title="❌")
else:
    result = results[0]

    pretty_print.wrapped(
        [
            f"Similarity {result['similarity']:.3f}",
            f"Filename {result['filename']}",
            f"Description `{result['description'][:1000]}...`",
        ],
        title=f"Results for query = {query}",
    )
    display_image(Path(result["filename"]))
# Output:
#   

#   🔍 Embedding query: 'a kitten with a robot'

#   ✅ Query embedded successfully

#   [93m---------------------------- Results for query = a kitten with a robot ----------------------------[0m

#     Similarity 0.814

#   [93m----------------------------------------------------------------------------------------------------[0m

#     Filename images/image_1.jpeg

#   [93m----------------------------------------------------------------------------------------------------[0m

#     Description `This image features a striking juxtaposition of a futuristic, menacing robot and an adorable, curious kitten in an industrial setting.

#   

#   **Objects:**

#   

#   1.  **Robot:** Occupying the right and center-right of the frame, a large, powerful, humanoid robot is depicted from the chest up.

#       *   **Head/Helmet:** The robot's head is designed like a sleek, dark metallic helmet, featuring intricate circuit board patterns or etched lines across its surface, giving it a high-tech, integrated look.

#       *   **Eyes:** The most prominent feature of the robot's face are its intensely glowing, bright red eyes, which emit a subtle light flare, creating a sense of power or surveillance. These eyes are set within dark, shadowed sockets.

#       *   **Body/Armor:** The robot's body is clad in heavy, articulated dark gray and silver metallic armor with visible rivets, bolts, and panel lines. Exposed mechanical elements, wires, and pistons can be seen in the joints, particularly around the neck and shoulder area.

#   ...`

#   [93m----------------------------------------------------------------------------------------------------[0m

#   <IPython.core.display.Image object>

"""
## 4. Building multimodal AI agents
"""

"""
The last step is to hook our RAG `search_multimodal` function to a ReAct agent to create an agentic RAG system.

First, we define the `multimodal_search_tool` using LangGraph:
"""

from langchain_core.tools import tool
from langchain_google_genai import ChatGoogleGenerativeAI
from langgraph.prebuilt import create_react_agent


@tool
def multimodal_search_tool(query: str) -> dict[str, Any]:
    """
    Search through a collection of images and their text descriptions to find relevant content.

    This tool searches through a pre-indexed collection of image-text pairs using the query
    and returns the most relevant match. The search uses multimodal embeddings to find
    semantic matches between the query and the content.

    Args:
        query: Text query describing what to search for (e.g., "cat", "kitten with robot")

    Returns:
        A formatted string containing the search result with description and similarity score
    """

    pretty_print.wrapped(query, title="🔍 Tool executing search for:")

    results = search_multimodal(query, vector_index, top_k=1)

    if not results:
        return {"role": "tool_result", "content": "No relevant content found for your query."}
    else:
        pretty_print.wrapped(str(results[0]["filename"]), title="🔍 Found results:")
    result = results[0]

    content = [
        {
            "type": "text",
            "text": f"Image description: {result['description']}",
        },
        types.Part.from_bytes(
            data=result["content"],
            mime_type="image/jpeg",
        ),
    ]

    return {
        "role": "tool_result",
        "content": content,
    }

"""
Next, we create a ReAct agent using LangGraph's `create_react_agent` function and the RAG tool defined above:
"""

def build_react_agent() -> Any:
    """
    Build a ReAct agent with multimodal search capabilities.

    This function creates a LangGraph ReAct agent that can search through images
    and text using the multimodal_search_tool. The agent uses Gemini 2.5 Pro
    for reasoning and tool execution.

    Returns:
        Any: A LangGraph ReAct agent instance configured with multimodal search tools
    """

    tools = [multimodal_search_tool]

    system_prompt = """You are a helpful AI assistant that can search through images and text to answer questions.
    
    When asked about visual content like animals, objects, or scenes:
    1. Use the multimodal_search_tool to find relevant images and descriptions
    2. Carefully analyze the image or image descriptions from the search results
    3. Look for specific details like colors, features, objects, or characteristics
    4. Provide a clear, direct answer based on the search results
    5. If you can't find the specific information requested, be honest about limitations
    
    Pay special attention to:
    - Colors and visual characteristics
    - Animal features and breeds
    - Objects and their properties
    - Scene descriptions and context
    
    Always search first using your tools before attempting to answer questions about specific images or visual content.
    """

    agent = create_react_agent(
        model=ChatGoogleGenerativeAI(model="gemini-2.5-pro", temperature=0.1),
        tools=tools,
        prompt=system_prompt,
    )

    return agent


react_agent = build_react_agent()
react_agent
# Output:
#   <langgraph.graph.state.CompiledStateGraph object at 0x31147b8c0>

"""
Now, let's test it and make the ReAct agent find the color of our kitten from the indexed dataset:
"""

try:
    test_question = "what color is my kitten?"
    pretty_print.wrapped(test_question, title="🧪 Asking question:")

    response = react_agent.invoke(input={"messages": test_question})
    messages = response.get("messages", [])
    if messages:
        final_message = messages[-1].content
    else:
        final_message = "No response from the agent"
    pretty_print.wrapped(final_message, title="🤖 Agent response")
except Exception as e:
    print(f"❌ Error in ReAct agent: {e}")
# Output:
#   [93m---------------------------------------- 🧪 Asking question: ----------------------------------------[0m

#     what color is my kitten?

#   [93m----------------------------------------------------------------------------------------------------[0m

#   [93m----------------------------------- 🔍 Tool executing search for: -----------------------------------[0m

#     my kitten

#   [93m----------------------------------------------------------------------------------------------------[0m

#   

#   🔍 Embedding query: 'my kitten'

#   ✅ Query embedded successfully

#   [93m----------------------------------------- 🔍 Found results: -----------------------------------------[0m

#     images/image_1.jpeg

#   [93m----------------------------------------------------------------------------------------------------[0m

#   [93m----------------------------------------- 🤖 Agent response -----------------------------------------[0m

#     Based on the image, your kitten is a gray tabby. It has soft, short gray fur with darker tabby stripe patterns.

#   [93m----------------------------------------------------------------------------------------------------[0m


"""
Based on the image from the previous section (the one with the kitten and robot), the answer is correct.
"""

</details>


## YouTube Video Transcripts

<details>
<summary>[ 00:00 ] Although AI research is traditionally split into distinct fields like NLP and computer vision, countless real-world problems require solutions that integrate information across these modalities.</summary>

[ 00:00 ] Although AI research is traditionally split into distinct fields like NLP and computer vision, countless real-world problems require solutions that integrate information across these modalities.
[ 00:00 ] (A man wearing a white t-shirt and a black baseball cap is speaking directly to the camera. The cap reads "THE DATA ENTREPRENEURS". He is holding a small black microphone. In the background, there is a modern kitchen with white cabinets, a black tile backsplash, and stainless steel appliances. Text on screen reads "AI Research").
[ 00:04 ] (The text on screen changes to "NLP" next to a robot icon with a speech bubble saying "Hello." Then "CV" appears next to a laptop with big eyes.)
[ 00:07 ] (A banana image appears with a speech bubble saying "Where can I find this?" Then the laptop with eyes replies in a speech bubble "Aisle 2".)
[ 00:14 ] In this video, I'll discuss how we can solve such problems using multimodal embeddings.
[ 00:19 ] (Text on screen changes to "Multimodal Embeddings").
[ 00:21 ] Then show how to use them to do things like zero-shot image classification and image search.
[ 00:23 ] (A list of fruits with a banana image is shown next to the man. The list reads "Apple, Banana, Papaya". A green checkmark appears next to "Banana". Then the text "Image search" appears next to a search bar with "Papaya" typed in it, showing images of an apple, banana, and papaya below. The papaya image is highlighted with a green box).
[ 00:29 ] And if you're new here, welcome, I'm Shaw, I make videos about the things I'm learning about and building in AI.
[ 00:30 ] (Text on screen reads "Shaw Talebi, Data Scientist, Bread Enthusiast").
[ 00:37 ] And if you enjoyed this content, please consider clicking the subscribe button.
[ 00:39 ] (A red "SUBSCRIBE" button with a play icon appears on screen).
[ 00:40 ] That's a great no-cost way you can support me in all the videos that I make.
[ 00:45 ] (The video transitions to a title slide that reads "Multimodal Embeddings, An introduction with example code (ft. CLIP)". Below the title, there's a diagram showing a book and a picture going into a "CLIP" model, which then outputs "x_txt" and "x_img". The author's name "Shaw Talebi" is at the bottom left).
[ 00:45 ] Here we're going to talk about multimodal embeddings.
[ 00:50 ] Although the discussion here will focus around Clip, which works with text and image data, this is a much more general idea that can be extended to many other modalities.
[ 01:01 ] (The video transitions to a new slide with the title "What are Embeddings?". Below the title, it says "Useful numerical representations of data learned via model training").
[ 01:01 ] Before talking about multimodal embeddings, it's worth answering the question, what are embeddings?
[ 01:07 ] The way I'll define embeddings here are useful numerical representations of data learned through model training.
[ 01:16 ] A classic example of this is Bert.
[ 01:17 ] (A brown square with "BERT" written inside appears in the center of the slide).
[ 01:27 ] Which is a popular language model, before the era of GPT-3 and all the modern large language models.
[ 01:31 ] Bert used to be state of the art, and one of the things that it does is masked language modeling.
[ 01:32 ] (An arrow points from the left towards the BERT box, with text "Listen to your [MASK]." next to it).
[ 01:33 ] In other words, you can give it a sequence of text, where one of the tokens in that sequence is masked, meaning that it's not visible.
[ 01:42 ] And Bert will predict the most likely token that goes in the place of that mask.
[ 01:42 ] (An arrow points from the BERT box to the right, with text "Listen to your instincts." next to it).
[ 01:49 ] So if you pass in the sequence listen to your, the most likely token that goes in the sequence is instincts.
[ 01:56 ] So it turns out that through learning how to do this prediction, Bert learns useful representations of text, which can be extended to other NLP tasks.
[ 02:08 ] The basic idea here is that you'll take Bert and you'll drop its head, so the classification head, which is doing this masked language modeling.
[ 02:11 ] (A downward arrow with "Drop head" appears below the BERT box).
[ 02:18 ] And you'll have this mutilated version of Bert, which instead of doing this token prediction, it'll take an input sequence of text and return a numerical representation of it.
[ 02:19 ] (A trapezoidal shape labeled "BERT (mutilated)" appears below the "Drop head" arrow. An arrow points from this shape to the left, with text "Listen to your instincts." next to it).
[ 02:26 ] Where each row in this matrix corresponds to each token in this text sequence.
[ 02:26 ] (A matrix of numbers with the dimensions n x d appears next to the BERT (mutilated) shape, with an arrow pointing from the shape to the matrix).
[ 02:37 ] And then each of these columns corresponds to the embedding dimension.
[ 02:40 ] The dimension of this internal representation of text that Bert uses in order to do masked language modeling.
[ 02:51 ] We can go one step further and go from token level representations to sequence level representations.
[ 02:55 ] (An arrow points from the matrix to a single row of numbers with the dimensions 1 x d).
[ 02:56 ] So we could do something like take the average across all these tokens in the sequence and we're left with a 1 by D matrix, which represents the entire sequence.
[ 03:08 ] And of course, to get these embeddings to be a bit more practical, people will often do additional fine tuning on top of these embeddings.
[ 03:16 ] But this is the basic idea of where they are coming from.
[ 03:20 ] A key point about embeddings is that these aren't just arbitrary numerical representations.
[ 03:26 ] They are typically semantically meaningful such that if we were to look at how text were organized in this embedding space, similar concepts would tend to be located close together, while dissimilar concepts will tend to be far apart.
[ 03:28 ] (The video transitions to a new slide with the title "What are Embeddings?". Below the title, it says "Useful numerical representations of data learned via model training". A 2D coordinate system labeled "Text Embeddings" is shown. Several text phrases are plotted on this graph: "A cute puppy", "A good boy", "Best pet in the world", "A cute cat", and "Funny cat meme". "A cute puppy" and "A good boy" are close together. "A cute cat" is also somewhat close to them. "Best pet in the world" is further from the others. "Funny cat meme" is far away).
[ 03:40 ] For example, the sequence a cute puppy might be relatively close to the sequence a good boy, while that same sequence a cute puppy might be relatively far from a sequence like funny cat meme.
[ 03:52 ] However, this isn't limited to just text, we can generate embeddings for any type of data.
[ 03:55 ] (Another 2D coordinate system labeled "Image Embeddings" appears to the right. Several images are plotted on this graph: a fluffy white cat, a serious-looking white cat sitting at a table with a plate of greens, a cute puppy, a baby goat, a silhouette of a cat, and a silhouette of a tiger. The fluffy white cat and serious cat are close. The puppy and dog silhouette are close. The goat is far).
[ 04:00 ] Another popular type of data we might work with are images.
[ 04:02 ] So if we had some image embeddings, the space might be structured like this, where we tend to have cats in the top left part, the dogs tend to be in the bottom right part, and then we have a goat further away from these.
[ 04:14 ] Although text embeddings and image embeddings are super helpful in that they can be adapted and repurposed to solve other either NLP tasks or computer vision tasks.
[ 04:26 ] One major limitation here is that any random text embedding space we might be working with and any random image embedding space we might be working in, don't have any relationship to one another.
[ 04:36 ] There's no way out of the box to directly map this text embedding space to this image embedding space and vice versa.
[ 04:44 ] Even if they are semantically meaningful in of themselves.
[ 04:48 ] And that's something we can plainly see here in that the text and image embedding spaces are not aligned, because for this text embedding space, the puppies tend to be in the top right, the cats tend to be at the bottom, while in our image embedding space, the cats tend to be up here and the dogs tend to be down here.
[ 05:04 ] But what if there was a way we could merge these two embedding spaces together.
[ 05:08 ] (The video transitions to a new slide with the title "Multimodal Embeddings". Below the title, it says "Embeddings which align representations of different data modalities". A 2D coordinate system similar to the previous ones appears, but this time all the text phrases and images are plotted on the same graph. Similar concepts (e.g., "A cute puppy" and the puppy image) are located close together).
[ 05:09 ] That's exactly the key idea behind multimodal embeddings, which are embeddings which align representations of different data modalities.
[ 05:18 ] And the basic intuition here is that if we had a multimodal embedding space, we could represent text and images in the same vector space.
[ 05:25 ] So now, indeed, texts like a cute puppy will be close to images of cute puppies, the text a cute cat will be close to images of a cute cat, and the same thing will hold for other concepts.
[ 05:40 ] However, this idea is not limited to just images and text.
[ 05:43 ] We could just as easily embed audio and images together.
[ 05:43 ] (Next to the images and text, small speaker icons appear next to the fluffy white cat, puppy, and serious cat. These indicate audio files related to the images).
[ 05:48 ] Maybe this is a audio file that is a cat meowing, this is a goat making goat noises, we have a puppy with like a cute bark, and then maybe we have like a funny shrieking sound associated with this cat meme.
[ 05:59 ] (The image of the tiger and cat silhouette disappear, replaced by two brain wave maps. Text changes to "A picture of a cute cat", "A picture of a cute puppy", and "Funny cat meme").
[ 06:00 ] Another application of this is aligning representations of brain signals with images and text.
[ 06:08 ] What this means is if we were to record someone's brain activity and then represent it in this embedding space, we could in principle decode the brain information to generate images and text.
[ 06:17 ] So in essence, reading people's thoughts.
[ 06:22 ] Actually, in reference number four, they are aiming to do exactly this with large language models.
[ 06:29 ] Intuitively, this idea of multimodal embeddings is pretty simple to understand.
[ 06:33 ] We have this embedding space, which is agnostic to modality.
[ 06:38 ] So it doesn't matter if it's a image of a cat, a text description of a cat, or the brain signals of someone looking at a picture of a cat, these numerical representations will be relatively similar.
[ 06:50 ] But how do we create these aligned numerical representations?
[ 06:55 ] In other words, how does this work under the hood.
[ 06:57 ] (The video transitions to a new slide titled "Contrastive Learning". Below the title, it says "Learning approach that seeks to represent different views of the same information similarly").
[ 06:57 ] So the key technique behind creating these types of embeddings is contrastive learning, which is an approach that seeks to represent different views of the same underlying information similarly.
[ 07:08 ] And the way this works is that we'll train a model on two things.
[ 07:11 ] One, positive pairs of data, and two, negative pairs.
[ 07:12 ] (Text on screen reads "Positive Pairs" in green. Then text "Negative Pairs" appears in red).
[ 07:18 ] So in the case of aligning image and text representations, positive pairs might be a picture of a cute cat and a textual caption for this image.
[ 07:21 ] (Images of a cat, puppy, and baby goat appear under "Positive Pairs". Each image has a corresponding text caption and a green checkmark).
[ 07:27 ] And then we might have the text and an image of a cute puppy, and then we might have the same thing for a baby goat.
[ 07:34 ] On the other hand, negative captions might look something like this, where you have the image of a cat, but the caption is a cute puppy.
[ 07:35 ] (Images of a cat, puppy, and baby goat appear under "Negative Pairs". Each image has a corresponding *incorrect* text caption and a red X).
[ 07:40 ] Image of a puppy and the caption is a goat, and you have a goat and the caption is a cat.
[ 07:46 ] So the intuition here is that we train a model to maximize the similarity between these positive pairs and minimize the similarity between these negative pairs.
[ 08:00 ] That's the key intuition.
[ 08:02 ] In the following slides, we're going to go one level deeper and look at the loss function and the math behind how this is accomplished.
[ 08:11 ] If you don't care about the math and how this is working under the hood, feel free to skip ahead to the example code.
[ 08:15 ] But if you're interested in the math, we're about to jump right into it.
[ 08:17 ] (The video transitions to a new slide with the title "Contrastive Learning". Below the title, it says "Learning approach that seeks to represent different views of the same information similarly". Images of a cat, puppy, and baby goat appear on the left).
[ 08:18 ] The way we can use contrastive learning to align image and text representations is we can take images, generate image embeddings using an image encoder.
[ 08:24 ] (Arrows point from the images to matrices of numbers, labeled with "Generate image embeddings using any image encoder").
[ 08:34 ] So basically we take our images and generate a single numerical representation for them.
[ 08:35 ] And then we can take all these image embeddings and we can concatenate them into a matrix that I'll call I sub E.
[ 08:36 ] (An arrow points from the individual matrices to a single concatenated matrix labeled "I_e (n x d)". Two images of a cat, a puppy, and a baby goat appear under "Negative Pairs". Each image has a corresponding *incorrect* text caption and a red X).
[ 08:44 ] So this will be an N by D matrix, where N is the number of images, so if you have three images here, it'll be one, two, three.
[ 08:50 ] And then D, so the number of columns, will be the embedding dimension.
[ 08:53 ] Then we can do a similar thing for text, so we can get a text encoder from off the shelf.
[ 08:54 ] (Text captions "A cute cat", "A cute puppy", and "Cute baby goat" appear to the right, with arrows pointing to matrices labeled "Generate text embeddings using any text encoder". These matrices are then concatenated into a single matrix labeled "T_e (n x d)").
[ 09:00 ] We can generate these text embeddings and we can concatenate them into a matrix that I'll call T sub E, and that will have the same shape.
[ 09:06 ] So we'll have N captions and then they'll have some embedding dimension.
[ 09:12 ] Just to point out here that the representations that we would put into these matrices won't directly come from an image encoder and text encoder.
[ 09:22 ] Instead, these will be multiplied by some learnable weight matrix and then normalized before being organized in this matrix.
[ 09:23 ] (Equations appear above the matrices, showing the normalization and weight matrix multiplication for "I_e" and "T_e").
[ 09:37 ] So that weight matrix that we multiply the original embeddings by are the learnable parameters.
[ 09:40 ] (The video transitions to a new slide with the title "Contrastive Learning". Below the title, it says "Learning approach that seeks to represent different views of the same information similarly". An equation is displayed: logit_i,j = sim(I_e[i], T_e[j]) / tau).
[ 09:40 ] Once we have these matrices I and T, we can construct this logit's matrix.
[ 09:44 ] Basically, what that means is we're going to take each image in our image embedding matrix and then each text sequence in our text embedding matrix, and we're going to compute their similarity.
[ 09:54 ] Typically, this is just a cosine similarity, so you do the dot product between these two matrices, and then you'll divide by a temperature parameter.
[ 10:00 ] That's what this towel parameter is representing.
[ 10:05 ] And the reason we call them logits is because at some point, it's going to be the argument in an exponential function.
[ 10:12 ] And we'll see that in a little bit here.
[ 10:12 ] (Below the equation, a matrix appears with rows for the cat, puppy, and baby goat images, and columns for the text captions "A cute cat", "A cute puppy", and "Cute baby goat". Each cell contains a "logit" value, with diagonal elements in green and off-diagonal elements in red).
[ 10:14 ] So taking just those three examples from the previous slide, the similarity between the first image and the first text sequence will be in this one, one position of the matrix.
[ 10:24 ] And then the similarity between this cat image and the sequence a cute puppy will be represented by this value here.
[ 10:32 ] Then the similarity between this cat image and the text sequence a cute baby goat will be represented by this value here and so on and so forth.
[ 10:40 ] Just looking at this, we can see that what we want is to make the logits on the diagonal of this matrix as big as possible.
[ 10:50 ] So in other words, we want to maximize the similarity between the positive pairs, and then we want to minimize the off-diagonal elements, which correspond to negative pairs.
[ 11:02 ] (A new equation "Contrastive Loss (Images)" appears to the right of the matrix).
[ 11:03 ] One way we can do this is via the contrastive loss.
[ 11:07 ] So this might take slightly different forms depending on the context or the paper that you're reading.
[ 11:12 ] But here I'm going to follow what was done in developing Clip, which is reference number three here.
[ 11:17 ] And so basically, one way we can achieve this goal of maximizing the similarity of these on-diagonal elements and minimizing the similarity between these off-diagonal elements is via this equation here.
[ 11:30 ] Which is basically saying for the Ith image, so let's say this cat image here, we want the numerator to be as big as possible.
[ 11:40 ] So the numerator will be the I I element, so this will be either one, one or two, two or three, three.
[ 11:45 ] And then we want the denominator to be as small as possible.
[ 11:51 ] So if the numerator is big, the denominator is small, that means this fraction becomes big, and then if we take the log of that, we'll still have a big number.
[ 12:00 ] And then we want this number to be as big as possible, because the goal of training is to minimize the loss, and then if this number is big and we have a minus sign next to it, then this will be as minimal as possible.
[ 12:12 ] That was probably a bit abstract, so let's walk through this step by step.
[ 12:16 ] Let's look at just the first image first.
[ 12:17 ] (The first row of the logit matrix is highlighted, corresponding to the cat image).
[ 12:18 ] With this notation, I call the loss associated with the first image L1.
[ 12:23 ] This will consist of taking this one, one logit and then summing over all the logits in this first row.
[ 12:31 ] So we're basically taking this image and comparing it to every single caption.
[ 12:35 ] Then we do the same thing for the second image.
[ 12:36 ] (The second row of the logit matrix is highlighted, corresponding to the puppy image).
[ 12:37 ] We have the positive pair similarity here, and then we sum over all the logits in this row.
[ 12:43 ] And then we do a similar thing for image number three.
[ 12:44 ] (The third row of the logit matrix is highlighted, corresponding to the baby goat image).
[ 12:45 ] So we look at the positive pair similarity, and then we sum over all the logits or similarities in this row.
[ 12:53 ] We can do this for every single image in our batch, or even in our whole training data set, and then we can aggregate them to get the final contrastive loss.
[ 13:01 ] What that will look like is we'll take the loss according to the first image, the loss according to the second image, and the loss corresponding to the third image, and then we can just take their average.
[ 13:10 ] And that'll give us the contrastive loss for the images.
[ 13:16 ] But we can do the exact same thing for text.
[ 13:17 ] This is how I'm noting contrastive loss for the text.
[ 13:21 ] I've switched the index here from J to I, and then I've changed the summation here to I.
[ 13:27 ] I feel this notation might be a bit too subtle, but hopefully explaining it step by step it makes sense what I mean here.
[ 13:34 ] So let's see what this looks like for the first text sequence.
[ 13:36 ] We're going to be evaluating a cute cat.
[ 13:37 ] (The first column of the logit matrix is highlighted, corresponding to the "A cute cat" caption).
[ 13:39 ] So we'll look at logits one, one here, and then we'll sum over the logits in this first column.
[ 13:45 ] We'll do the same thing for this second text sequence, a cute puppy.
[ 13:47 ] (The second column of the logit matrix is highlighted, corresponding to the "A cute puppy" caption).
[ 13:49 ] We'll sum over all the logits in this column.
[ 13:52 ] And then finally, we do it for the final text sequence.
[ 13:53 ] (The third column of the logit matrix is highlighted, corresponding to the "Cute baby goat" caption).
[ 13:55 ] It's important to note here that generally, this logits matrix is asymmetric, because the similarity between the text a cute puppy and this image of a cat is in general, different than the similarity between this image of a puppy and the text sequence a cute cat.
[ 14:14 ] That's an important thing to note here and that's the reason why we go through this whole procedure for the images and the text sequences separately.
[ 14:21 ] And then we can aggregate the loss over all the text examples, just like we did for the images, like this.
[ 14:29 ] And then we'll get a total text loss by taking the average of all the examples in our mini batch.
[ 14:35 ] (The video transitions to a new slide with the title "Contrastive Learning". Below the title, it says "Learning approach that seeks to represent different views of the same information similarly". An equation is displayed: Final Loss: L = (L_I + L_T) / 2).
[ 14:36 ] We can then combine the image loss and text loss together by taking their average.
[ 14:41 ] And then we can write it all out to have this big monstrosity all on one page, but basically this first term here corresponds to the image loss.
[ 14:41 ] (The equation expands to show the full formula for L. The first large term is boxed and labeled "Image term". The second large term is boxed and labeled "Text term").
[ 14:50 ] The second term here corresponds to the text loss, and this is how we train the weights, which translate the raw image and text encodings into our multimodal embedding space.
[ 15:02 ] This will give us a training signal, which we can use to update the weights of these projection matrices.
[ 15:09 ] We can just keep doing that until we're satisfied with the loss.
[ 15:13 ] (The video transitions to a new slide with the title "Example 1: Using CLIP for 0-shot Image Classification". A smiling emoji with hugging hands and a Python logo are displayed in the top right corner).
[ 15:13 ] So if that was much more math than you were hoping to get out of this video, I apologize for that, but let's jump to practical applications of multimodal embeddings.
[ 15:23 ] Here I'm going to use Clip for two different use cases.
[ 15:26 ] This first use case is zero-shot image classification.
[ 15:30 ] The meaning of that is we're going to do image classification without explicitly training Clip to distinguish between the different image classes that we're considering.
[ 15:40 ] (Python code is displayed: `from transformers import CLIPProcessor, CLIPModel`, `from PIL import Image`).
[ 15:41 ] The first step is to import transformers.
[ 15:43 ] I'm going to bring in these two things.
[ 15:44 ] And then I'm importing this PIL library, which will allow us to work with images in Python.
[ 15:49 ] (More Python code is displayed: `model = CLIPModel.from_pretrained("openai/clip-vit-base-patch16")`, `processor = CLIPProcessor.from_pretrained("openai/clip-vit-base-patch16")`).
[ 15:50 ] Next, we'll load in the model and the data processor.
[ 15:55 ] The image preprocessing is important because images could be any type of size and shape and all that.
[ 16:00 ] The Clip processor is an abstraction that ensures the data are in a suitable format to be passed through the model.
[ 16:07 ] (More Python code is displayed: `image = Image.open("images/cat_cute.png")`, `text_classes = ["a photo of a cat", "a photo of a dog"]`).
[ 16:08 ] Next, we're going to load in our image.
[ 16:09 ] So I'm going to load in this image of a cute cat.
[ 16:10 ] (An image of a cat with a tilted head appears to the right).
[ 16:10 ] So it's the same one we've seen so far.
[ 16:13 ] Then I'm going to define the text classes.
[ 16:17 ] So this is a really interesting aspect of using Clip for zero-shot image classification, because before, if you wanted to do image classification, traditionally that was something that was set at model training.
[ 16:29 ] It was explicitly coded into the architecture of the model in that you had this classification head, and each value in the output layer corresponded to the probability of class one versus class two versus class three and so on and so forth.
[ 16:47 ] But now, we're using Clip, which is trained via contrastive learning, we actually pass these classes as text inputs.
[ 16:54 ] (More Python code is displayed: `inputs = processor(text=text_classes, images=image, return_tensors="pt", padding=True)`, `outputs = model(**inputs)`).
[ 16:55 ] So with our text and image inputs defined, we can pass these through our processor to put them in a suitable format as Clip, and then we can just pass it to the model.
[ 17:03 ] (More Python code is displayed: `logits_per_image = outputs.logits_per_image`, `probs = logits_per_image.softmax(dim=1)`).
[ 17:04 ] Then with this one line of code, we'll generate these outputs.
[ 17:06 ] Then we can extract the logits per image.
[ 17:09 ] Recall the logits matrix that we saw a few slides ago, where we had an image and then we had logit values or similarity values between that image and every single piece of text that we passed into the model.
[ 17:23 ] That's exactly what we're extracting here.
[ 17:25 ] We're extracting the similarity score of the input image to both the text inputs.
[ 17:31 ] Then we can convert these logits to probabilities via the softmax.
[ 17:36 ] (More Python code is displayed: `predicted_class = text_classes[probs.argmax()]`, `print(predicted_class, "| Probability = ", round(float(probs[0][probs.argmax()]),4))`).
[ 17:37 ] And then this will give us a prediction.
[ 17:40 ] What I'm doing here is I'm just doing argmax of the probabilities tensor and using that to pick out the predicted class from this original list that I created.
[ 17:51 ] And then I'm just going to print everything like this.
[ 17:53 ] So I'll print the predicted class as well as a rounded probability corresponding to that class.
[ 17:58 ] (Output: `>> a photo of a cat | Probability = 0.9979`).
[ 17:58 ] With that, the most probable class is a photo of a cat with a associated probability of 99.79%.
[ 18:07 ] So it basically nails the classification of this image.
[ 18:11 ] But let's see what happens when we use different text classes.
[ 18:13 ] (New text "Classes: "ugly cat" vs "cute cat"" is displayed, and the predicted class with probability: `>> cute cat | Probability = 0.9703`).
[ 18:14 ] Instead of passing in a photo of a cat and a photo of a dog, which are pretty easy classes to distinguish between, let's try something a bit more nuanced, like a ugly cat versus cute cat.
[ 18:22 ] And again, here the model basically nails it with a 97% probability of this cute cat class.
[ 18:31 ] (New text "Classes: "cat meme" vs "not cat meme"" is displayed, and the predicted class with probability: `>> not cat meme | Probability = 0.5464`).
[ 18:32 ] And then we can try something even more challenging, like trying to distinguish if this is a cat meme or not a cat meme, and it indeed gets that it's not a cat meme, but we can see that the probability dropped significantly.
[ 18:45 ] (The image of the cat with a tilted head is replaced by an image of the serious-looking cat at the table, a popular cat meme. The class predictions for "cat meme" vs "not cat meme" are displayed).
[ 18:45 ] Then as a final test of this model, let's see what happens when we pass in an actual cat meme and give it the class choices of cat meme versus not cat meme.
[ 18:54 ] And so here the model again nails it.
[ 18:57 ] It correctly classifies this as a cat meme with a probability of 83%.
[ 19:02 ] And so again, what we're doing here, using Clip is we're taking these three entities.
[ 19:07 ] We're taking the text sequence of cat meme, the text sequence of not cat meme, and this image of a cat encoding them in a shared embedding space, and we're evaluating the similarity between this image of a cat and the text sequence cat meme, and the similarity between this image of a cat and the text sequence not a cat meme.
[ 19:28 ] And then we can convert that similarity into a probability as well as a class prediction.
[ 19:35 ] The key unlock here is that you are not restricted or limited in the different class labels you can use for image classification.
[ 19:43 ] You can be as detailed or vague as you like.
[ 19:45 ] You can adapt this to endless different use cases, which is pretty amazing.
[ 19:50 ] (The video transitions to a new slide with the title "Example 2: Using CLIP for Image Search". A smiling emoji with hugging hands and a Python logo are displayed in the top right corner).
[ 19:50 ] This second example is basically the inverse of zero-shot image classification.
[ 19:56 ] There, we had an input image and we wanted to match it with one of the input text sequences.
[ 20:04 ] Here in example two, we're going to do the exact opposite.
[ 20:07 ] So instead of starting with an image, we're going to start with a piece of text.
[ 20:10 ] In other words, a search query, and then we're going to match it to a set of images.
[ 20:16 ] So essentially, what we're doing is we're doing a search over a set of images.
[ 20:20 ] (More Python code is displayed to create a list of image names and load the images: `image_name_list = ["images/cat_cute.png", "images/dog.png", "images/goat.png"]`, `image_list = []`, `for image_name in image_name_list:`, `image_list.append(Image.open(image_name))`).
[ 20:21 ] The way this looks is we'll first load in our images.
[ 20:24 ] (Images of a cat, dog, and baby goat appear below the code).
[ 20:25 ] Here we have a picture of a cute cat, picture of a dog, and a picture of a goat.
[ 20:28 ] We'll store them in this image list.
[ 20:32 ] We're using the PIL library to open the images and just store them in this list.
[ 20:36 ] (More Python code is displayed to define a query and process inputs: `query = "a cute dog"`, `inputs = processor(text=query, images=image_list, return_tensors="pt", padding=True)`).
[ 20:37 ] Then we're going to define a query and process the inputs.
[ 20:40 ] Here our query will be a cute dog.
[ 20:42 ] And then we'll pass this query along with our image list through the processor, so it's in the appropriate format for Clip.
[ 20:49 ] (More Python code is displayed to compute image probabilities: `outputs = model(**inputs)`, `logits_per_text = outputs.logits_per_text`, `probs = logits_per_text.softmax(dim=1)`).
[ 20:50 ] Then we'll run these inputs through our model.
[ 20:52 ] Get these outputs, extract the logits per text now.
[ 20:57 ] Before we did logits per image, now we're doing logits per text.
[ 21:01 ] So these are going to be the similarity scores between the input text and all the images that we inputted, and then we'll convert these logits into probabilities.
[ 21:10 ] (More Python code is displayed to evaluate the best match: `best_match = image_list[probs.argmax()]`, `prob_match = round(float(probs[0][probs.argmax()]),4)`, `print("Match probability: ",prob_match)`, `display(best_match)`).
[ 21:11 ] So with that, we can evaluate the best match.
[ 21:14 ] So I'm doing that again in a similar way.
[ 21:15 ] So we have these probabilities, doing argmax, which will give us an integer zero, one or two.
[ 21:22 ] We can use that to pick out the best matched image, and then we can take the probability associated with that image, and then we can just print everything.
[ 21:31 ] (Output: `>> Match probability: 0.9817`).
[ 21:32 ] Again, the query here was a cute dog, and this is the best matched image with a probability of about 98%.
[ 21:40 ] (New text query: `query = "something cute but metal 🤘"`, is displayed).
[ 21:40 ] But again, that was a super easy example.
[ 21:42 ] So let's try a trickier query like something cute but metal.
[ 21:46 ] (Output: `>> Match probability: 0.7715`, followed by the image of the baby goat).
[ 21:46 ] In this case, the model returns the goat, which is indeed cute, but also goats are associated with heavy metal music, and they got a 77% match probability.
[ 21:56 ] (New text query: `query = "a good boy"`, is displayed).
[ 21:56 ] Reading this, a good boy, the text itself doesn't have anything to do with animals.
[ 22:01 ] You know, maybe it's a human boy and he's well-behaved.
[ 22:04 ] But a good boy is a colloquialism for dogs that we use often.
[ 22:08 ] (Output: `>> Match probability: 0.8248`, followed by the image of the dog).
[ 22:09 ] And the model can pick that up quite easily, so it matches it with a dog with 82% probability.
[ 22:15 ] It would be interesting to see if we threw in a picture of a human boy to see how the model would handle that case.
[ 22:21 ] This could be something that you do with the example code from the GitHub.
[ 22:25 ] (New text query: `query = "the best pet in the world"`, is displayed).
[ 22:25 ] And then we can try an extremely controversial query like the best pet in the world.
[ 22:30 ] (Output: `>> Match probability: 0.5664`, followed by the image of the cat).
[ 22:30 ] For this, the model returns a cat with a 56% match probability.
[ 22:35 ] This is likely indicating that on average, people on the internet love cats more than they love dogs.
[ 22:42 ] Nevertheless, it's super interesting how we can use this model in order to do search like this.
[ 22:47 ] (The video transitions to a new slide with the title "What's Next?").
[ 22:47 ] So those were the two examples.
[ 22:49 ] Code is on the GitHub, link in the description below.
[ 22:51 ] Let's look ahead to the next video of this series.
[ 22:55 ] (New text "Part 1 (i.e. last video)" is displayed).
[ 22:55 ] In the previous video, so part one, we talked about multimodal large language models.
[ 22:58 ] (A green square labeled "Multimodal LLM" is displayed, with arrows pointing from books, pictures, and audio to the square, and an arrow pointing from the square to books).
[ 23:00 ] So basically, large language models that can process or generate multiple data modalities.
[ 23:05 ] (A vertical line appears, separating "Part 1" from a new section "Part 2 (i.e. this video)". In "Part 2", a trapezoidal shape labeled "Multimodal Embedding" is displayed, with arrows pointing from books to it, and arrows pointing from it to pictures).
[ 23:06 ] In this video, we talked about multimodal embeddings, like those generated by Clip, which can be used to do things like image search.
[ 23:13 ] So we pass in a query and a set of potential images, and then it'll spit out the best-matched image.
[ 23:22 ] In the next video of this series, we're going to bring these two ideas together.
[ 23:25 ] (The video transitions to a new slide with the title "What's Next?". Below the title, it says "Multimodal RAG").
[ 23:26 ] To create a multimodal Rag system.
[ 23:29 ] The basic flow here will be to take a user query, like what's there to do in Bali.
[ 23:31 ] (Text "What's there to do in Bali?" appears, followed by "User Query").
[ 23:35 ] We'll pass the query into a multimodal retrieval system, which involves using a multimodal embedding model to pick out the documents and images that are most relevant to this query.
[ 23:49 ] We'll take the user query and relevant documents and images to generate a prompt.
[ 23:57 ] And then we'll pass that prompt into a multimodal large language model, which can process the user query, relevant text documents and relevant images to generate a helpful response.
[ 24:10 ] (The video transitions to a new slide titled "Multimodal Embeddings: An introduction". It includes an article excerpt and an image of building blocks spelling "WORDS". The article mentions a previous post about augmenting LLMs).
[ 24:10 ] And as a final note, if you enjoyed this video and you want to learn more, check out the blog published in Towards Data Science.
[ 24:18 ] There, I went into some details that I probably missed here.
[ 24:21 ] And as always, even though this is going to be a member-only story, you can access it completely for free using the friend link in the description below.
[ 24:29 ] And with that, thank you so much for your time and thanks for watching.
[ 24:32 ] (The video transitions to a black screen with a light blue diagram of three connected circles, forming a triangle. Text below reads "Thanks for watching.").

</details>


## Additional Sources Scraped

<details>
<summary>complex-document-recognition-ocr-doesn-t-work-and-here-s-how</summary>

# Complex Document Recognition: OCR Doesn’t Work and Here’s How You Fix It

by **Oleg Kokorin**

October 12th, 2023

In this article, I will dive into a complex world of complex document recognition using AI and OCR.

Document recognition nowadays is not a complex task.

Modern OCR solutions are able to detect both typed and written text in many languages. One can find dedicated solutions for the detection of specific documents like passports and driver’s licenses.

But where out-of-the-box AI tends to struggle is when a document includes special symbols or tilted text.

Technical drawings are among the ‘trouble children’ that cause ready-made OCR solutions to struggle: they are nothing but a collection of weird symbols and weirdly placed text.

Having worked on an AI solution for technical drawing recognition, I have insights into the world of modern OCR that I will share in this article.

## Why OCR is bad for OCR

The ‘digital first’ approach, at the forefront of many businesses, has motivated many to convert physical documents into a digital format. This process usually involves the implementation of OCR — optical character recognition — which converts physical documents into PDF files.

Morel OCR tools are capable of recognizing more than just text. In many cases, OCR tools can detect special symbols, written text, signatures, images, and more.

Many of these tools come ready to use: all you need to do is install the tool (or, if you are working on a custom solution, use an API) to scan the documents in question.

Despite all this, OCR tools have certain limitations. They don’t work well for irregular text, also called wild text, like low-quality scanned documents with no predefined structure, car license plates, text on advertisement billboards, etc.

### Low-quality scans

The quality of text recognition depends highly on the quality of the document itself. Warping, scratches, faded ink, and more have a detrimental effect on the recognition quality.

### Symbol mixups

Even the best OCR tools have trouble distinguishing between certain similar-looking letters and numbers, like ‘3’ and ‘8’ or ‘O’ and ‘D.’ The very challenges OCR is supposed to solve often become the stumbling block of document digitization.

### Special symbols

Documents that feature any special symbols, from letters specific to a certain language to symbols denominating certain objects, like symbols used in technical drawings, e.g., diameter ‘Ø,’ square ‘□.’

## AI to the rescue

Using artificial intelligence, OCR tools can be improved and augmented to better handle complex documents, and often even replaced by a custom AI neural network.

Model-based OCR, or intelligent OCR, is the result of using deep learning for text document recognition.

Neural networks can be trained to recognize text regular OCR tools have trouble with. Intelligent OCR provides superior text recognition results in document recognition applications by improving recognition speed and reducing errors.

## Recognition of complex documents

Despite the widespread digitization, some paperwork remains offline. This usually applies to complex documents that are impossible to digitize due to their complex layouts, the use of special symbols, and unconventional formatting.

Technical drawings are the perfect example of a complex document: their layouts change from one document to another; they include a bunch of symbols specific to technical drawings only, and the text is often formatted in odd ways. All of the above makes technical drawings the perfect candidate for model-based OCR.

While working on a similar project, I’ve developed an understanding of the best strategies to apply when working on digitizing technical drawings. I have had experience with working on an AI for floor plan detection, so that’s what I’ll be using as an example.

I’ve broken the process down into sections, as this is exactly how one should approach the development of AI-based OCR solutions for complex document recognition.

## Stage 1: Detection of text

Recognition of plain text is the most simple part of this entire ordeal. When it comes to technical drawings, plain text is used to specify the drawing type, dimensions, floor plan type, building type, etc. While the detection of plain text is a simple task, detecting text on a technical drawing is far more complex.

The text can come in a variety of fonts, sizes, and colors, can be rotated or upside down, and contains special symbols. Ready-made OCR software like iText and OCRSpace can detect simple text with high accuracy, but they fail spectacularly when it comes to technical drawings (or any other complex document, for that matter). For example, these tools struggle to detect rotated text.

https://hackernoon.imgix.net/images/2DFAaGGO5cfymtBKn4bFFAoT6sg2-v993xj8.jpeg?w=1200

Most OCR tools can be fine-tuned to handle problematic text better. The best approach to recognizing complex text is to use multiple fine-tuned OCR tools along with a balancer that compares the results of each tool and chooses the one that produces the most accurate results.

Another benefit of using fine-tuned OCR software is the increase in recognition speed.

https://hackernoon.imgix.net/images/2DFAaGGO5cfymtBKn4bFFAoT6sg2-v9a3xhv.jpeg?w=1200

By fine-tuning these tools alone, we’ve seen a 200 times decrease in document processing speed.If you add an OCR engine into the equation, like Tesseract, the text recognition quality can be increased up to 99.9%.

## Stage 2: Recognition of special symbols

Each technical drawing includes special symbols of some sort. In the case of floor plan technical drawings, the documents include symbols designating doors, windows, electrical outlets, etc.

These symbols, or labels, look like geometric figures with text inside. They can be difficult to distinguish from their surroundings due to their shape, which blends in perfectly with the rest of the drawing.

In addition, there can be multiple labels representing the same object due to inconsistencies in document design.

https://hackernoon.imgix.net/images/2DFAaGGO5cfymtBKn4bFFAoT6sg2-efb3xu6.jpeg?w=1200

Pre-trained computer vision solutions, like OpenCV libraries for symbol detection, work best with photographs of real-life objects. Technical drawings are quite a bit different: they are almost always in black and white and mostly consist of geometric shapes.

We’ve tested multiple OpenCV libraries, each of which resulted in albeit different, yet insufficiently low recognition quality. Unless you develop your own neural network from scratch, any pre-trained computer vision model needs to be built upon to achieve decent recognition quality.

One of the main problems with using pre-trained CV models is the amount of false positive results they produce. Technical drawings consist of simple geometric shapes, but so do special symbols and labels, which results in CV models detecting random parts of the drawings as labels.

The best way of mitigating this issue is to implement deep learning to detect false positive results and remove them from the final detection results.

https://hackernoon.imgix.net/images/2DFAaGGO5cfymtBKn4bFFAoT6sg2-mjc3x1z.jpeg?w=1200

## Stage 3: Spreadsheets

Technical drawings often include large spreadsheets with merged cells and complex structures stretching across multiple pages. While spreadsheets are generally easy to detect, the complex nature of these spreadsheets makes them difficult to crack.

Going a custom software route is the best way to achieve satisfactory results. Here’s how we’ve done it:

### Recognition of text in a spreadsheet

Solutions like Amazon Textract work very well and can extract text with very high accuracy as long as the document scan is of high quality. Documents with 300 DPI result in 100% recognition accuracy and 100 DPI results in ~90% accuracy.

### Recognition of spreadsheet structure

First, you need to detect the spreadsheet structure by detecting vertical and horizontal lines.

Using OpenCV, create a binary matrix by converting the document into black and white, defining its threshold in a way that results in all horizontal and vertical lines being one and the rest — a zero. The binary matrix will then contain the spreadsheet structure.

Using the extracted text and spreadsheet structure, the spreadsheet itself can be extracted in an editable format like Excel.

## Summing Up

Digitizing any complex document comes with its own set of problems. The best approach to solving them is to approach them one by one, researching the best tools for the job, testing them, and comparing results.

The approaches I’ve described work on any document type despite its type, as individual challenges can be similar despite the document type being completely different.

For example, I have experience in working on a passport detection solution where the text recognition challenges were very similar, and we’ve used some of the same techniques.

Knowing your OCR tools, being well-versed in coding neural networks and having decent experience in the field of custom AI development will help overcome any document digitization challenges.

</details>

<details>
<summary>google-generative-ai-embeddings-ai-studio-gemini-api-langcha</summary>

Connect to Google's generative AI embeddings service using the `GoogleGenerativeAIEmbeddings` class, found in the [langchain-google-genai](https://pypi.org/project/langchain-google-genai/) package.

This will help you get started with Google's Generative AI embedding models (like Gemini) using LangChain. For detailed documentation on `GoogleGenerativeAIEmbeddings` features and configuration options, please refer to the [API reference](https://python.langchain.com/v0.2/api_reference/google_genai/embeddings/langchain_google_genai.embeddings.GoogleGenerativeAIEmbeddings.html).

## Overview

### Integration details

| Provider | Package |
| --- | --- |
| [Google Gemini](https://python.langchain.com/docs/integrations/text_embedding/google_generative_ai) | [langchain-google-genai](https://python.langchain.com/api_reference/google_genai/embeddings/langchain_google_genai.embeddings.GoogleGenerativeAIEmbeddings.html) |

## Setup

To access Google Generative AI embedding models you'll need to create a Google Cloud project, enable the Generative Language API, get an API key, and install the `langchain-google-genai` integration package.

### Credentials

To use Google Generative AI models, you must have an API key. You can create one in Google AI Studio. See the [Google documentation](https://ai.google.dev/gemini-api/docs/api-key) for instructions.

Once you have a key, set it as an environment variable `GOOGLE_API_KEY`:

```codeBlockLines_e6Vv
import getpass
import os

if not os.getenv("GOOGLE_API_KEY"):
    os.environ["GOOGLE_API_KEY"] = getpass.getpass("Enter your Google API key: ")

```

To enable automated tracing of your model calls, set your [LangSmith](https://docs.smith.langchain.com/) API key:

```codeBlockLines_e6Vv
# os.environ["LANGSMITH_TRACING"] = "true"
# os.environ["LANGSMITH_API_KEY"] = getpass.getpass("Enter your LangSmith API key: ")

```

## Installation

```codeBlockLines_e6Vv
%pip install --upgrade --quiet  langchain-google-genai

```

## Usage

```codeBlockLines_e6Vv
from langchain_google_genai import GoogleGenerativeAIEmbeddings

embeddings = GoogleGenerativeAIEmbeddings(model="models/gemini-embedding-001")
vector = embeddings.embed_query("hello, world!")
vector[:5]

```

```codeBlockLines_e6Vv
[-0.024917153641581535,\
 0.012005362659692764,\
 -0.003886754624545574,\
 -0.05774897709488869,\
 0.0020742062479257584]

```

## Batch

You can also embed multiple strings at once for a processing speedup:

```codeBlockLines_e6Vv
vectors = embeddings.embed_documents(
    [\
        "Today is Monday",\
        "Today is Tuesday",\
        "Today is April Fools day",\
    ]
)
len(vectors), len(vectors[0])

```

```codeBlockLines_e6Vv
(3, 3072)

```

## Indexing and Retrieval

Embedding models are often used in retrieval-augmented generation (RAG) flows, both as part of indexing data as well as later retrieving it. For more detailed instructions, please see our [RAG tutorials](https://python.langchain.com/docs/tutorials/rag/).

Below, see how to index and retrieve data using the `embeddings` object we initialized above. In this example, we will index and retrieve a sample document in the `InMemoryVectorStore`.

```codeBlockLines_e6Vv
# Create a vector store with a sample text
from langchain_core.vectorstores import InMemoryVectorStore

text = "LangChain is the framework for building context-aware reasoning applications"

vectorstore = InMemoryVectorStore.from_texts(
    [text],
    embedding=embeddings,
)

# Use the vectorstore as a retriever
retriever = vectorstore.as_retriever()

# Retrieve the most similar text
retrieved_documents = retriever.invoke("What is LangChain?")

# show the retrieved document's content
retrieved_documents[0].page_content

```

**API Reference:** [InMemoryVectorStore](https://python.langchain.com/api_reference/core/vectorstores/langchain_core.vectorstores.in_memory.InMemoryVectorStore.html)

```codeBlockLines_e6Vv
'LangChain is the framework for building context-aware reasoning applications'

```

## Task type

`GoogleGenerativeAIEmbeddings` optionally support a `task_type`, which currently must be one of:

- `SEMANTIC_SIMILARITY`: Used to generate embeddings that are optimized to assess text similarity.
- `CLASSIFICATION`: Used to generate embeddings that are optimized to classify texts according to preset labels.
- `CLUSTERING`: Used to generate embeddings that are optimized to cluster texts based on their similarities.
- `RETRIEVAL_DOCUMENT`, `RETRIEVAL_QUERY`, `QUESTION_ANSWERING`, and `FACT_VERIFICATION`: Used to generate embeddings that are optimized for document search or information retrieval.
- `CODE_RETRIEVAL_QUERY`: Used to retrieve a code block based on a natural language query, such as sort an array or reverse a linked list. Embeddings of the code blocks are computed using `RETRIEVAL_DOCUMENT`.

By default, we use `RETRIEVAL_DOCUMENT` in the `embed_documents` method and `RETRIEVAL_QUERY` in the `embed_query` method. If you provide a task type, we will use that for all methods.

```codeBlockLines_e6Vv
%pip install --upgrade --quiet  matplotlib scikit-learn

```

```codeBlockLines_e6Vv
from langchain_google_genai import GoogleGenerativeAIEmbeddings
from sklearn.metrics.pairwise import cosine_similarity

query_embeddings = GoogleGenerativeAIEmbeddings(
    model="models/gemini-embedding-001", task_type="RETRIEVAL_QUERY"
)
doc_embeddings = GoogleGenerativeAIEmbeddings(
    model="models/gemini-embedding-001", task_type="RETRIEVAL_DOCUMENT"
)

q_embed = query_embeddings.embed_query("What is the capital of France?")
d_embed = doc_embeddings.embed_documents(
    ["The capital of France is Paris.", "Philipp is likes to eat pizza."]
)

for i, d in enumerate(d_embed):
    print(f"Document {i + 1}:")
    print(f"Cosine similarity with query: {cosine_similarity([q_embed], [d])[0][0]}")
    print("---")

```

```codeBlockLines_e6Vv
Document 1
Cosine similarity with query: 0.7892893360164779
---
Document 2
Cosine similarity with query: 0.5438283285204146
---

```

## API Reference

For detailed documentation on `GoogleGenerativeAIEmbeddings` features and configuration options, please refer to the [API reference](https://python.langchain.com/api_reference/google_genai/embeddings/langchain_google_genai.embeddings.GoogleGenerativeAIEmbeddings.html).

## Additional Configuration

You can pass the following parameters to ChatGoogleGenerativeAI in order to customize the SDK's behavior:

- `client_options`: [Client Options](https://googleapis.dev/python/google-api-core/latest/client_options.html#module-google.api_core.client_options) to pass to the Google API Client, such as a custom `client_options["api_endpoint"]`
- `transport`: The transport method to use, such as `rest`, `grpc`, or `grpc_asyncio`.

## Related

- Embedding model [conceptual guide](https://python.langchain.com/docs/concepts/embedding_models/)
- Embedding model [how-to guides](https://python.langchain.com/docs/how_to/#embedding-models)

</details>

<details>
<summary>i-m-a-g-e</summary>

# ColPali: EFFICIENT DOCUMENT RETRIEVAL WITH VISION LANGUAGE MODELS

Manuel Faysse∗1,3 Hugues Sibille∗1,4 Tony $\mathbf { W \_ { u } } ^ { \* 1 }$ Bilel Omrani1

Gautier Viaud1 C´eline Hudelot3 Pierre Colombo2,3

1Illuin Technology 2Equall.ai 3CentraleSupe´lec, Paris-Saclay 4ETH Zu¨rich

[manuel.faysse@centralesupelec.fr](mailto:manuel.faysse@centralesupelec.fr)

# ABSTRACT

Documents are visually rich structures that convey information through text, but also figures, page layouts, tables, or even fonts. Since modern retrieval systems mainly rely on the textual information they extract from document pages to index documents -often through lengthy and brittle processes-, they struggle to exploit key visual cues efficiently. This limits their capabilities in many practical document retrieval applications such as Retrieval Augmented Generation (RAG). To benchmark current systems on visually rich document retrieval, we introduce the Visual Document Retrieval Benchmark ViDoRe, composed of various page-level retrieval tasks spanning multiple domains, languages, and practical settings. The inherent complexity and performance shortcomings of modern systems motivate a new concept; doing document retrieval by directly embedding the images of the document pages. We release ColPali, a Vision Language Model trained to produce high-quality multi-vector embeddings from images of document pages. Combined with a late interaction matching mechanism, ColPali largely outperforms modern document retrieval pipelines while being drastically simpler, faster and end-to-end trainable. We release models, data, code and benchmarks under open licenses at [https://hf.co/vidore](https://hf.co/vidore).

# 1 INTRODUCTION

Document Retrieval consists of matching a user query to relevant documents in a given corpus. It is central to many widespread industrial applications, either as a standalone ranking system (search engines) or as part of more complex information extraction or Retrieval Augmented Generation (RAG) pipelines.

Over recent years, pretrained language models have enabled large improvements in text embedding models. In practical industrial settings, however, the primary performance bottleneck for efficient document retrieval stems not from embedding model performance but from the prior data ingestion pipeline. Indexing a standard PDF document involves several steps. First, PDF parsers or Optical Character Recognition (OCR) systems are used to extract words from the pages. Document layout detection models can then be run to segment paragraphs, titles, and other page objects such as tables, figures, and headers. A chunking strategy is then defined to group text passages with some semantical coherence, and modern retrieval setups may even integrate a captioning step to describe visually rich elements in a natural language form, more suitable for embedding models. In our experiments (Table 2), we typically find that optimizing the ingestion pipeline yields much better performance on visually rich document retrieval than optimizing the text embedding model.

Contribution 1: ViDoRe. In this work, we argue that document retrieval systems should not be evaluated solely on the capabilities of text embedding models (Bajaj et al., 2016; Thakur et al., 2021; Muennighoff et al., 2022), but should also consider the context and visual elements of the documents to be retrieved. To this end, we create and openly release ViDoRe, a comprehensive benchmark to evaluate systems on page-level document retrieval with a wide coverage of domains, visual elements, and languages. ViDoRe addresses practical document retrieval scenarios, where queries often necessitate both textual and visual understanding for accurate document matching. We highlight the shortcomings of current text-centric systems in these settings.1

https://arxiv.org/pdf/images/391f32efa12ee5d8c95be1f641c318cd9e821711f7d2f28610e9c54a25d13db6.jpg

Figure 1: ColPali simplifies document retrieval w.r.t. standard retrieval methods while achieving stronger performances with better latencies. Latencies and results are detailed in section 5 and subsection B.4.

Contribution 2: ColPali. We propose a novel concept and model architecture based on Vision Language Models (VLMs) to efficiently index documents purely from their visual features, allowing for subsequent fast query matching with late interaction mechanisms (Khattab & Zaharia, 2020). Our method, ColPali, significantly outperforms all other retrieval systems on $V i D o R e$ while being fast and end-to-end trainable. These results demonstrate the potential and the many benefits of this novel Retrieval in Vision Space concept, which could significantly alter the way document retrieval is approached in the industry moving forward. We release all resources at [https://hf.co/vidore](https://hf.co/vidore).

# 2 PROBLEM FORMULATION & RELATED WORK

Problem Setting. In our setting, a retrieval system scores how relevant a document $d$ from corpus $\mathcal { D }$ is with respect to a query $q$ . Computing the similarity score $s ( q , d ) \in \mathbb { R }$ for each of the $\| \mathcal { D } \|$ documents in the corpus creates a ranking we can use to extract the most relevant documents. In this work, we focus on page-level retrieval: given a query, is the correct document page retrieved by the system? For coherence with existing literature, we further use the term document to refer to individual pages, i.e. the atomic retrieved elements in our setting. As we focus on practical industrial retrieval applications (RAG, search engines) with potentially large corpora sizes, latency constraints are imposed on scoring systems. Most current retrieval systems can be decomposed into (1) an offline indexation phase in which a document index is built and (2) an online querying phase in which a query is matched to documents from the index and where low latency is vital to the user experience.

Under these industrial constraints, we identify three main properties an efficient document retrieval systems should exhibit: (R1) strong retrieval performance, as measured by standard retrieval metrics; $( R 2 )$ fast online querying, measured through average latencies; (R3) high throughput corpus indexation, ie. the number of pages that can be embedded in a given timeframe.

2.1 TEXTUAL RETRIEVAL METHODS

# Document Retrieval in Text Space.

Statistical methods based on word frequency like TF-IDF (Sparck Jones, 1972) and BM25 (Robertson et al., 1994) are still widely used due to their simplicity and efficiency. More recently, neural embedding models based on fine-tuned large language models display state-of-the-art performance on a variety of text embedding tasks and top the retrieval leaderboards (Muennighoff et al., 2022).

Neural Retrievers. In bi-encoder models (Reimers & Gurevych, 2019; Karpukhin et al., 2020; Wang et al., 2022), documents are independently mapped offline to a dense vector space. Queries are embedded online and matched to documents through a fast cosine distance computation. A slower, but slightly more performant alternative, cross-encoder systems (Wang et al., 2020; Cohere, 2024) concatenate query and document as a single input sequence and iteratively attribute matching scores to each possible combination. This enables full attention computation between query and document terms but comes at the cost of computational efficiency, as $\| \mathcal D \|$ encoding passes must be done online.

Multi-Vector retrieval via late interaction. In the late interaction paradigm introduced by ColBERT (Khattab & Zaharia, 2020), an embedding is pre-computed and indexed per document token. At runtime, similarity can be computed with individual query token embeddings. The idea is to benefit from the rich interaction between individual query and document terms while taking advantage of the offline computation and fast query matching enabled by bi-encoders. See section E for more details.

Retrieval Evaluation. Although benchmarks and leaderboards have been developed to evaluate text embedding models (Thakur et al., 2021; Muennighoff et al., 2022), much of the performance improvements in industrial use cases of embedding models stem from the prior data ingestion pipeline. While documents often rely on visual elements to more efficiently convey information to human readers, text-only systems barely tap into these visual cues. Other work has also independently studied table or chart retrieval systems through repurposed Question Answering datasets (Zhang et al., 2019; Nowak et al., 2024) but only assessing specialized methods for each task.

To our knowledge, no benchmark evaluates document retrieval systems in practical settings; in an end-to-end manner, across several document types and topics, and by evaluating the use of both textual and visual document features.

# 2.2 INTEGRATING VISUAL FEATURES

Contrastive Vision Language Models. Mapping latent representations of textual content to corresponding representations of visual content has been done by aligning disjoint visual and text encoders through contrastive losses (Radford et al., 2021; Zhai et al., 2023). While some OCR capabilities exist in these models, the visual component is often not optimized for text understanding.

The Fine-grained Interactive Language-Image Pre-training (Yao et al., 2021) framework extends the late interaction mechanism to cross-modal Vision Language Models, relying on max similarity operations between text tokens and image patches.

Visually Rich Document Understanding. To go beyond text, some document-focused models jointly encode text tokens alongside visual or document layout features (Appalaraju et al., 2021; Kim et al., 2021; Huang et al., 2022; Tang et al., 2022). Large Language transformer Models (LLMs) with strong reasoning capabilities have recently been combined with Vision Transformers (ViTs) (Dosovitskiy et al., 2020) to create VLMs (Alayrac et al., 2022; Liu et al., 2023; Bai et al., 2023; Lauren¸con et al., 2024b) where image patch vectors from contrastively trained ViT models (Zhai et al., 2023) are fed as input embeddings to the LLM and concatenated with the text-token embeddings.

PaliGemma. The PaliGemma-3B model (Beyer et al., 2024) extends concepts from Pali3 (Chen et al., 2023), and projects SigLIP-So400m/14 (Alabdulmohsin et al., 2023) patch embeddings into Gemma-2B’s text vector space (Gemma Team et al., 2024). Along with its reasonable size w.r.t. other performant VLMs, an interesting property of PaliGemma’s text model is that it is fine-tuned with full-block attention on the prefix (instruction text and image tokens). See Appendix E for more details.

VLMs display enhanced capabilities in Visual Question Answering, captioning, and document understanding (Yue et al., 2023), but are not optimized for retrieval tasks.

# 3 THE ViDoRe BENCHMARK

Existing benchmarks for contrastive vision-language models primarily evaluate retrieval for natural images (Lin et al., 2014; Borchmann et al., 2021; Thapliyal et al., 2022). On the other hand, textual retrieval benchmarks (Muennighoff et al., 2022) are evaluated at at textual passage level and are not tailored for document retrieval tasks. We fill the gap with ViDoRe, a comprehensive benchmark for document retrieval using visual features.

# 3.1 BENCHMARK DESIGN

ViDoRe is designed to comprehensively evaluate retrieval systems on their capacity to match queries to relevant documents at the page level. This benchmark encompasses multiple orthogonal subtasks, with focuses on various modalities - text, figures, infographics, tables; thematic domains - medical, business, scientific, administrative; or languages - English, French. Tasks also span varying levels of complexity, in order to capture signals from both weaker and stronger systems. As many systems require large amounts of time to index pages (captioning-based approaches can take dozens of seconds per page for instance), we limit the number of candidate documents for each retrieval task in order to evaluate even complex systems in a reasonable timeframe without sacrificing quality. For trainable retrieval systems, we provide a reference training set that can be used to facilitate comparisons.

Table 1: ViDoRe comprehensively evaluates multimodal retrieval methods.

|     |     |     |     |     |
| --- | --- | --- | --- | --- |
| Dataset | Language | \# Queries | \# Documents | Description |
| Academic Tasks |
| DocVQA | English | 500 | 500 | Scanned documents from UCSF Industry |
| InfoVQA | English | 500 | 500 | Infographics scrapped from the web |
| TAT-DQA | English | 1600 | 1600 | High-quality financial reports |
| arXiVQA | English | 500 | 500 | Scientific Figures from arXiv |
| TabFQuAD | French | 210 | 210 | Tables scrapped from the web |
| Practical Tasks |
| Energy | English | 100 | 1000 | Documents about energy |
| Government | English | 100 | 1000 | Administrative documents |
| Healthcare | English | 100 | 1000 | Medical documents |
| AI | English | 100 | 1000 | Scientific documents related to AI |
| Shift Project | French | 100 | 1000 | Environmental reports |

Academic Tasks. We repurpose widely used visual question-answering benchmarks for retrieval tasks: for each page-question-answer triplet, we use the question as the query, and the associated page as the gold document (Table 1). These academic datasets either focus on single specific modalities (Mathew et al., 2020; 2021; Li et al., 2024) or target more varied visually rich documents (Zhu et al., 2022). Moreover, we consider TabFQuAD, a human-labeled dataset on tables extracted from French industrial PDF documents released with this work. Details can be found in subsection A.1.

Practical tasks. We construct topic-specific retrieval benchmarks spanning multiple domains to go beyond repurposed QA datasets and evaluate retrieval in more realistic industrial situations (e.g. RAG). To achieve this, we collect publicly accessible PDF documents and generate queries pertaining to document pages using Claude-3 Sonnet, a high-quality proprietary vision-language model (Anthropic, 2024). In total, we collect 1,000 document pages per topic, which we associate with 100 queries extensively filtered for quality and relevance by human annotators. The corpus topics are intentionally specific to maximize syntactic proximity between documents, creating more challenging retrieval tasks and covering an array of orthogonal domains (Table 1). 2

Evaluation Metrics. We evaluate performance on our benchmark (Requirement R1) using standard metrics from the retrieval literature (nDCG, Recall@K, MRR). We report $\mathrm { n D C G } @ 5$ values as the main performance metric in this work and release the complete sets of results along with the models3.

To validate compliance with practical industrial requirements (section 2), we also consider query latencies (R2) and indexing throughputs (R3).

# 3.2 ASSESSING CURRENT SYSTEMS

Unstructured. We evaluate retrieval systems representative of those found in standard industrial RAG pipelines. As is common practice, we rely on the Unstructured4 off-the-shelf tool in the highest resolution settings to construct high-quality text chunks from PDF documents. Unstructured orchestrates the document parsing pipeline, relying on deep learning vision models to detect titles and document layouts (Ge et al., 2021), OCR engines (Smith, 2007) to extract text in non-native PDFs, specialized methods or models to detect and reconstruct tables, and implements a chunking strategy (by-title) that leverages the detected document structure to preserve section boundaries when concatenating texts. As is common practice, in our simplest Unstructured configuration (text-only), only textual elements are kept and figures, images, and tables are considered noisy information and are filtered out.

Unstructured $+ \textbf { X }$ . While Unstructured is a strong baseline by itself, we further augment Unstructured’s output by integrating the visual elements. In $( + \ O C R )$ , tables, charts, and images are run through an OCR engine, processed by Unstructured, and chunked independently. In ( $+$ Captioning), we set up a fully-fledged captioning strategy (Zhao et al., 2023), in which we feed visual elements to a strong proprietary Vision Language Model (Claude-3 Sonnet (Anthropic, 2024)) to obtain highly detailed textual descriptions of the elements. Both strategies aim to integrate visual elements in the retrieval pipeline but incur significant latency and resource costs (subsection 5.2).

Embedding Model. To embed textual chunks, we evaluate Okapi BM25, the de facto standard sparse statistical retrieval method, and the dense encoder of BGE-M3 (Chen et al., 2024), a multilingual neural method with SOTA performance in its size category. Chunks are embedded and scored independently, and page-level scores are obtained by max-pooling over the page’s chunk scores.5

Contrastive VLMs. We also evaluate the strongest available vision-language embedding models; Jina CLIP (Koukounas et al., 2024), Nomic Embed Vision (Nomic, 2024), and SigLIP-So400m/14 (Alabdulmohsin et al., 2023).

Results. From a performance perspective, best results are obtained by combining the Unstructured parser with visual information, either from captioning strategies or by running OCR on the visual elements (Table 2). Little difference is seen between BM25 and BGE-M3 embeddings highlighting the visual information bottleneck. Contrastive VLMs lag behind. Beyond retrieval performance (R1), the indexing latencies (R2) reported in Figure 2 illustrate that PDF parsing pipelines can be very lengthy, especially when incorporating OCR or captioning strategies. Querying latencies at runtime (R3) are very good for all evaluated systems $\leq 2 2 \mathrm { m s }$ on a NVIDIA L4) due to fast query encoding and cosine similarity matching.

https://arxiv.org/pdf/images/9b42e697ca163d7e29300ce3893bfbb565058abb5496f1a4433ddbc0420c9cb1.jpg

Figure 2: Offline document indexing with ColPali is much simpler and faster compared to standard retrieval methods. The PDF Parser results are obtained following the Unstructured settings with BGE-M3 detailed in subsection 3.2. All indexing speeds are averaged per-page latencies. More details in subsection B.4

# 4 LATE INTERACTION BASED VISION RETRIEVAL

# 4.1 ARCHITECTURE

Vision-Language Models. Encouraged by their strong document understanding capabilities, we propose adapting recent VLMs for retrieval. The key concept is to leverage the alignment between output embeddings of text and image tokens acquired during multi-modal fine-tuning. To this extent, we introduce ColPali, a Paligemma-3B extension that is capable of generating ColBERT-style multivector representations of text and images (Figure 1). PaliGemma-3B is a strong candidate due to its small size, the many released checkpoints fine-tuned for different image resolutions and tasks, and the promising performances on various document understanding benchmarks. We add a projection layer to map each of the language model’s output token embeddings (whether from text or image tokens) to a vector space of reduced dimension $D = 1 2 8$ as used in the ColBERT paper (Khattab & Zaharia, 2020) to keep lightweight bag-of-embedding representations.

Late Interaction. Given query $q$ and document $d$ , we denote as $\mathbf { E \_ { q } } \in \mathbb { R } ^ { N \_ { q } \times D }$ and $\mathbf { E \_ { d } } \in \mathbb { R } ^ { N \_ { d } \times D }$ their respective multi-vector representation in the common embedding space $\mathbb { R } ^ { D }$ , where $N \_ { q }$ and $N \_ { d }$ are respectively the number of vectors in the query and in the document page embeddings. The late interaction operator, $\operatorname { L I } \left( q , d \right)$ , is the sum over all query vectors $\mathbf { E \_ { q } } ^ { ( j ) }$ , of its maximum dot product $\langle \cdot \| \cdot \rangle$ with each of the $N \_ { d }$ document embedding vectors $\mathbf { E \_ { d \left( 1 : N \_ { d } \right) } }$ .

$$
\mathbf { L } \left( q , d \right) = \sum \_ { i \in \left[ \left\| 1 , N \_ { q } \right\| \right] } \operatorname\* { m a x } \_ { j \in \left[ \left\| 1 , N \_ { d } \right\| \right] } \langle \mathbf { E \_ { q } } ^ { ( i ) } \| \mathbf { E \_ { d } } ^ { ( j ) } \rangle
$$

Contrastive Loss. The Late Interaction operation is fully differentiable, enabling backpropagation. Let a batch ${ q \_ { k } , d \_ { k } } \_ { k \in \[ \| 1 , b \| \] }$ composed of $b$ query-page pairs, where for all $k \in \[ \| \bar { 1 , \upsilon } \| \]$ , the document page $d \_ { k }$ is the document corresponding to query $q \_ { k }$ . Following Khattab & Zaharia (2020), we define our in-batch contrastive loss $\mathcal { L }$ as the softmaxed cross-entropy of the positive scores $s \_ { k } ^ { + } = \mathrm { L I } \left( q \_ { k } , d \_ { k } \right)$ w.r.t. to the maximal in-batch negative scores $s \_ { k } ^ { - } = \operatorname\* { m a x } \_ { l , l \neq k } \quad \mathrm { L I } ( q \_ { k } , d \_ { l } ) ^ { 6 }$ :

$$
\mathcal { L } = - \frac { 1 } { b } \sum \_ { k = 1 } ^ { b } \log \left[ \frac { \exp \left( s \_ { k } ^ { + } \right) } { \exp \left( s \_ { k } ^ { + } \right) + \exp \left( s \_ { k } ^ { - } \right) } \right] = \frac { 1 } { b } \sum \_ { k = 1 } ^ { b } \log \left( 1 + \exp \left( s \_ { k } ^ { - } - s \_ { k } ^ { + } \right) \right)
$$

# 4.2 MODEL TRAINING

Dataset. Our training dataset of 118,695 query-page pairs is comprised of train sets of openly available academic datasets $( 6 3 % )$ and a synthetic dataset made up of pages from web-crawled PDF documents and augmented with VLM-generated (Claude-3 Sonnet) pseudo-questions $( 3 7 % )$ . Dataset split details are given in subsection A.3. Our training set is fully English by design, enabling us to study zero-shot generalization to non-English languages7. We explicitly verify no multi-page PDF document is used both ViDoRe and in the train set to prevent evaluation contamination. A validation set is created with $2 %$ of the samples to tune hyperparameters. We openly release the training dataset8 for reproducibility and to encourage further research.

Parameters. All models are trained for 1 epoch on the train set. Unless specified otherwise, we train models in bfloat16 format, use low-rank adapters (LoRA, Hu et al. (2021)) with $\alpha = 3 2$ and $r = 3 2$ on the transformer layers from the language model, as well as the final randomly initialized projection layer, and use a paged adamw 8bit optimizer. We train on an 8 GPU setup with data parallelism, a learning rate of $5 e - 5$ with linear decay with $2 . 5 %$ warmup steps, and a batch size of 32.

Query Augmentation. As in Khattab & Zaharia (2020), we append 5  tokens to the query tokens to serve as a soft, differentiable query expansion or re-weighting mechanism.

# 5 RESULTS

Table 2: Comprehensive evaluation of baseline models and our proposed method on ViDoRe. Results are presented using $\mathrm { n D C G } @ 5$ metrics, and illustrate the impact of different components. Text-only metrics are not computed for benchmarks with only visual elements.

|     |     |     |     |     |     |     |     |     |     |     |     |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | ArxivQ DocQ |  | InfoQ | TabF | TATQ | Shift | AI | Energy | Gov. | Health. | Avg. |
| Unstructured text-only |  |  |  |  |  |  |  |  |  |  |  |
| \- BM25 |  | 34.1 |  |  | 44.0 | 59.6 | 90.4 | 78.3 | 78.8 | 82.6 |  |
| \- BGE-M3 |  | 28.4↓5.7 |  |  | 36.1↓7.9 | 68.5†8.9 | 88.4↓2.0 | 76.8↓1.5 | 77.7↓1.1 | 84.6↑2.0 |  |
| Unstructured +oCR |  |  |  |  |  |  |  |  |  |  |  |
| \- BM25 | 31.6 | 36.8 | 62.9 | 46.5 | 62.7 | 64.3 | 92.8 | 85.9 | 83.9 | 87.2 | 65.5 |
| \- BGE-M3 | 31.4↓0.2 | 25.7↓11.1 60.1↓2.8 |  | 70.8↑24.3 50.5↓12.2 73.2↑8.9 |  |  | 90.2↓2.6 | 83.6↓2.3 | 84.9↑1.0 | 91.1↑3.9 | 66.1↑0.6 |
| Unstructured + Captioning |  |  |  |  |  |  |  |  |  |  |  |
| \- BM25 | 40.1 | 38.4 | 70.0 | 35.4 | 61.5 | 60.9 | 88.0 | 84.7 | 82.7 | 89.2 | 65.1 |
| \- BGE-M3 | 35.7↓4.4 | 32.9↓5.4 | 71.9†1.9 |  |  |  | 69.1†↑33.7 43.8↓17.7 73.1↑12.2 88.810.8 | 83.3↓1.4 | 80.4↓2.3 | 91.3↑2.1 | 67.0个1.9 |
| ContrastiveVLMs |  |  |  |  |  |  |  |  |  |  |  |
| Jina-CLIP | 25.4 | 11.9 | 35.5 | 20.2 | 3.3 | 3.8 | 15.2 | 19.7 | 21.4 | 20.8 | 17.7 |
| Nomic-vision | 17.1 | 10.7 | 30.1 | 16.3 | 2.7 | 1.1 | 12.9 | 10.9 | 11.4 | 15.7 | 12.9 |
| SigLIP (Vanilla) | 43.2 | 30.3 | 64.1 | 58.1 | 26.2 | 18.7 | 62.5 | 65.7 | 66.1 | 79.1 | 51.4 |
| Ours |  |  |  |  |  |  |  |  |  |  |  |
| SigLIP (vanilla) | 43.2 | 30.3 | 64.1 | 58.1 | 26.2 | 18.7 | 62.5 | 65.7 | 66.1 | 79.1 | 51.4 |
| BiSigLIP (+fine-tuning) |  | 58.5↑15.3 32.9↑2.6 | 70.5↑6.4 | 62.7↑4.6 | 30.5↑4.3 | 26.5↑7.8 | 74.3†11.8 73.7†8.0 |  | 74.2†8.1 | 82.3↑3.2 | 58.6↑7.2 |
| BiPali (+LLM) |  | 56.5↓-2.0 30.0↓-2.9 67.4↓-3.1 |  | 76.9↑14.2 | 33.4↑2.9 |  |  | 43.7↑17.2 71.2↓-3.1 61.9↓-11.7 | 73.8↓-0.4 | 73.6↓-8.8 | 58.8↑0.2 |
| ColPali (+Late Iter.) |  | 79.1↑22.6 54.424.5 81.8个14.4 83.9†7.0 |  |  |  |  | 65.8†32.4 73.2↑29.5 96.2↑25.0 91.0个29.1 |  |  | 92.7†18.9 94.4个20.8 | 81.3†22.5 |

# 5.1 PERFORMANCE (R1)

We show performance is achieved iteratively through the combination of three factors; (1) a carefully crafted task-specific dataset, (2) pairing a pretrained LLM to a vision model to better leverage text semantics from the image, and (3) using multi-vector embeddings rather than a single vector representation to better capture the vast amount of visual information present in a document.

Fine-tuning a Vision Model on a document retrieval oriented dataset: BiSigLIP. SigLIP9 is a strong vision-language bi-encoder producing single vector embeddings, and pretrained on billions of image-text pairs from the English split of WebLI (Chen et al., 2023). Further fine-tuning the textual component of this model on our document-oriented dataset (BiSigLIP) yields clear improvements across the board, particularly on figure retrieval (ArxivQA) and table retrieval tasks (TabFQuAD).

Feeding image patches to a LLM: BiPali. In the PaliGemma model architecture, SigLIP-generated patch embeddings are fed to a text language model and we can obtain LLM contextualized output patch embeddings.10 This technique aligns the image token representations with the text token embeddings in the LLM’s embeddings space, and augments the vision model embeddings with the language model’s text understanding capabilities. We average pool these representations to obtain a single dense vector, effectively creating a PaliGemma bi-encoder model (BiPali). After fine-tuning on the training dataset, we obtain a model that performs slightly worse in English than the tuned BiSigLIP variant.11 However, we see notable improvements in French tasks, indicating that BiPali’s LLM (Gemma 2B) helps multilingual text understanding. This is particularly notable as our training dataset does not contain non-English samples.

Leveraging Multi-Vector Embeddings through Late Interaction: ColPali. One benefit of inputting image patch embeddings through a language model is that they are natively mapped to a latent space similar to the textual input (query). This enables leveraging the ColBERT strategy to construct one embedding per image patch token, and at inference compute all interactions between text tokens and image patches, resulting in a step-change improvement in performance compared to BiPali. Results in Table 2 show that our ColPali model also largely outperforms the strong baselines based on Unstructured and captioning, as well as all evaluated text-image embedding models. The difference is particularly stark on the more visually complex benchmark tasks, such as InfographicVQA, ArxivQA, and TabFQuAD, respectively representing infographics, figures, and tables. However, text-centric documents are also better retrieved by the ColPali models across all evaluated domains and languages, making our approach the overall best-performing document-retrieval model.

Negative Results. For extensiveness, we also train ColSigLIP, a late interaction variant of the BiSigLIP model but obtain abysmal performances. We attribute this to the large gaps w.r.t. SigLIP’s pre-training, in which only a pooled latent representation is used in the contrastive loss, which does not optimize the representations of individual patch and token embeddings. Similarly, we train a $\mathrm { B i S i g L I P } \_ { P a l i G e m m a }$ variant, in which we retrieve the image representations from the SigLIP model that has been further updated by PaliGemma fine-tuning, and use the text representations from PaliGemma’s text model. After fine-tuning on our dataset, performance is severely inferior to $\mathrm { S i g L I P } \_ { V a n i l l a }$ which simply encodes with SigLIP’s original text and vision components. This indicates a logical misalignment between SigLIP embeddings, and Gemma embeddings after PaliGemma training. We detail these results in subsection C.1.

# 5.2 LATENCIES & MEMORY FOOTPRINT

Online Querying. (R2) Logically, querying latencies differ between ColPali and a BGE-M3 embedding model. For BGE, encoding takes about $2 2 ~ \mathrm { m s }$ for 15 tokens, while encoding a query with ColPali’s language model takes about $\mathrm { 3 0 ~ m s ^ { 1 2 } }$ . For smaller corpus sizes, computing the late interaction operation induces marginally small overheads $\approx 1$ ms per 1000 pages in the corpus), and the cosine similarity computation between bi-encoder vectors is even faster. Optimized late interaction engines (Santhanam et al., 2022; Lee et al., 2023) enable to easily scale corpus sizes to millions of documents with reduced latency degradations.

Offline Indexing. (R3) Standard retrieval methods using bi-encoders represent each chunk as a single vector embedding, which is easy to store and fast to compute. However, processing a PDF to get the different chunks is the most time-consuming part (layout detection, OCR, chunking), and using captioning to handle multimodal data will only exacerbate this already lengthy process. On the other hand, ColPali directly encodes pages from their image representation. Although the model is larger than standard retrieval encoders, skipping the preprocessing allows large speedups at indexing13 (Figure 2). As pages are embedded end-to-end in single forward pass, the VRAM usage depends exclusively on the sequence length (number of patches per image) which is fixed as well, enabling efficient batching strategies to fully leverage hardware acceleration. ColPali also benefits from most LLM efficiency improvements introduced in the ecosystem such as Flash Attention (Dao, 2023).

Storage Footprint. Our method requires storing a vector per image patch, along with 6 extra text tokens “Describe the image” concatenated to image patches. We project each PaliGemma vector to a lower dimensional space $D = 1 2 8 ,$ ) to maximize efficiency, leading to a memory footprint of 257.5 KB per page (subsection B.3). Importantly, the memory footprint of the naive ColBERT indexing strategy can be drastically improved through compression and clustering mechanisms (Santhanam et al., 2022; Clavie´ et al., 2024).

Token pooling. Token pooling (Clavi´e et al., 2024) is a CRUDE-compliant method (document addition/deletion-friendly) that aims amountto reduce the amount of multi-vector embeddings. For ColPali, many image patches share redundant information, e.g. white background patches. By pooling these patches together, we can reduce the amount of embeddings while retaining most information. Retrieval performance with hierarchical mean token pooling on image embeddings is shown in Figure 3 (left). With a pool factor of 3, the total number of vectors is reduced by $6 6 . 7 %$ while $9 7 . 8 %$ of the original performance is maintained. We note that the Shift dataset—composed of the most text-dense documents—is a clear outlier, showcasing more information dense documents contain less redundant patches and may be prone to worse performance degradation with such pooling techniques.

https://arxiv.org/pdf/images/8293b990ecdbbef3709cfbff1889d6bbaef5395f6aee03741bd76b28b993209f.jpg

Figure 3: (Left: Token Pooling) Relative performance degradation when reducing the number of stored embeddings per document. (Right: Interpretability) For each term in a user query, ColPali identifies the most relevant document image patches (highlighted zones) and computes a query-topage matching score.

# 5.3 INTERPRETABILITY

By superimposing the late interaction heatmap on top of the original image, we can visualize the most salient image patches with respect to each term of the query, yielding interpretable insights into model focus zones. As epitomized in Figure 3 (right), we observe ColPali exhibits strong OCR capabilities as both the words “hourly” and “hours” present a high similarity score with the query token < hour>. We also note particular focus on other non-trivial image features such as the x-axis representing hours being salient. Other visualization examples are shown in Appendix D.

# 6 ABLATION STUDY

We run various ablations to better understand the mechanisms at play. By default, result deltas reported below refer to $\mathrm { n D C G } @ 5$ values averaged over all ViDoRe tasks. Detailed results in C.2.

Tradeoffs between model size and the number of image patches. We train a variant of PaliGemma with half the number of image patches (512). While we observe a clear performance degradation with respects to to the 1024-patch ColPali model $( - 2 4 . 8 \mathrm { n D C G } @ 5 )$ , memory usage is much lower. As an alternative to PaliGemma, we train Idefics2-8B (Lauren¸con et al., 2024b), a VLM with a similar architecture and based on a Mistral-7B (Jiang et al., 2023) language backbone and a SigLIP vision encoder paired with a perceiver resampler. The most notable differences with PaliGemma lie in the size of the language model (2B and 7B resp.) and the number of image patches (between 512 and 2048 for PaliGemma, and 64 post-resampling for Idefic $ \cdot 2 ^ { 1 4 }$ ). Our results suggest better language models enable more efficient representations of image embeddings - ColIdefics2 with 64 patches largely outperforms out ColPali with 512 patches $( + 2 0 . 1 \ \mathrm { n D C G } @ 5 )$ . However ColIdefics2 (64) remains less accurate than ColPali (1024) $( - 4 . 7 \mathrm { n D C G } @ 5 )$ while being about twice as slow in terms of training and inference latency. These results suggest there are tradeoffs between performance (R1), latencies during online querying (R2) and offline indexation phases (R3), and index memory size.

Unfreezing the vision component. We train a ColPali variant by also backpropagating through and updating the vision encoder and the projection layer. This leads to a slight performance degradation $( \bar { - } 0 . 7 \mathrm { n D C G } @ 5 )$ . These conclusions may change with larger scales of training data.

Impact of “query augmentation” tokens. In ColBERT, special tokens are concatenated to the input query to serve as soft query augmentation buffers. Training without these tokens, we observe no significant performance difference in the English benchmarks. However, performance on the French tasks seems to improve $\left( + 9 . 8 \mathrm { n D C G } @ \mathrm { G } \right.$ on Shift, $+ 6 . 3 \mathrm { n D C G } @ 5 $ on TabFQuAD, Table 7).

Impact of the Pairwise CE loss. Training with an in-batch negative contrastive loss, instead of the pairwise CE loss that only considers the hardest negative sample, leads to a slight performance degradation $( - 1 . 6 \mathrm { n D C G } @ 5 ) ,$ ) on the aggregated benchmark.

Adapting models to new tasks. Contrary to more complex multi-step retrieval pipelines, ColPali can be trained end-to-end, directly optimizing the downstream retrieval task which greatly facilitates fine-tuning to boost performance on specialized domains, multilingual retrieval, or specific visual elements the model struggles with. To demonstrate, we add 1552 samples representing French tables and associated queries to the training set. This represents the only French data in the training set, with all other examples being kept unchanged. We see clear $\mathrm { n D C G } @ 5$ improvements $\left( + 2 . 6 \right)$ and even starker Recall $@ 1$ gains $( + 5 )$ on the TabFQuAD benchmark, with no performance degradation on the rest of the benchmark tasks $( + 0 . 4 \mathrm { n D C G } @ 5 $ overall).

Better VLMs lead to better visual retrievers. As improved VLMs are released, it is interesting to observe if improved performances on generative tasks translate once these models are adapted for image retrieval tasks through ColPali training strategies. We train the recently released Qwen2-VL 2B (Wang et al., 2024b), a SOTA 2 billion parameter generative VLM, with the same data and training strategy, obtaining ColQwen2-VL. To approximately match ColPali’s memory requirements, we limit the number of image patches to 768, slightly less than ColPali’s 1024 patches. We observe clear performance improvements of $+ 5 . 3 \mathrm { n D C G } @ 5 $ values over ColPali showcasing clear performance correlations between generative benchmarks performance and retrieving metrics.

Out-of-domain generalization. Some of the datasets in the ViDoRe benchmark have train sets, which we have integrated within the ColPali train set (eg. academic tasks). This is standard in embedding models (Wang et al., 2024a; Lee et al., 2024), and while ColPali also exhibits strong performance on tasks in which this is not the case (French data is never seen by the model during training for instance), it remains interesting to evaluate model performance when training is done on a fully disjoint data distribution. We train a ColPali variant solely using the recent DocMatix dataset (Lauren¸con et al., 2024a), a large scale, synthetically annotated visual document question answering dataset, which we subsample to obtain a comparably-sized train set. Results on ViDoRe show the performance drop is minor $( - 2 . 2 \operatorname { n D C G } \ @ 5 )$ , still outperforming the closest baseline method by over 12 points. These results showcase ColPali generalizes well outside of its training distribution, and demonstrate that our results are not unreasonably boosted with respect to baselines (BGE-M3) that cannot be fine-tuned on the same data15

# 7 CONCLUSIONS

In this work, we introduced the Visual Document Retrieval Benchmark (ViDoRe), which evaluates document retrieval systems in realistic settings involving visually complex documents. We demonstrated that current retrieval pipelines and contrastive vision-language models struggle to efficiently exploit visual information embedded in documents, leading to suboptimal performance. To address this, we presented ColPali, a novel retrieval method that leverages Vision-Language Models to create high-quality, multi-vector embeddings purely from visual document features. ColPali largely outperforms the best existing document retrieval methods while enabling faster corpus indexing times and maintaining low querying latencies, thus circumventing many pain points of modern document retrieval applications. We hope to drive industrial adoption, and to encourage future work by publicly releasing the ViDoRe benchmark, the data, the codebase, and all models and baselines from our work.

Future Work. Beyond performance improvements that could be obtained through better data, backbone models or training strategies, our vision at term is to combine visual retrieval systems and visually grounded query answering to create end-to-end RAG systems that purely function from image features. This idea is supported by concurrent work (Ma et al., 2024) showcasing the strong promises of VLMs for visual QA, and may eventually become a new industrial standard for document processing. In this line of work, reliability is key, and confidence estimation techniques for Information Retrieval methods could become central to implement abstention mechanisms (GisserotBoukhlef et al., 2024), and are particularly interesting given the information rich multi-vector scoring mechanisms of late interaction systems. Expanding benchmarking efforts to cover more languages, modalities, and tasks is also a crucial future research direction (Jiang et al., 2024).

# REPRODUCIBILITY STATEMENT

For transparency, reproducibility and to foster future work, we release our training data, model checkpoints (adapters), entire codebase, and complete evaluation benchmark under MIT licenses as detailed in the main paper. We also host a public ViDoRe leaderboard16 to foster concurrent work in the space. The supplementary material further details training configurations for our models (also specified in HuggingFace model repositories), and dives into the process we used to generate synthetic data, how latency computations are performed, as well as provides further detailed evaluation results.

# ACKNOWLEDGEMENTS

This work is partially supported by Illuin Technology, and by a grant from ANRT France. This work was performed using HPC resources from the CINES ADASTRA through Grant 2024-AD011015443 and from IDRIS with grant 2024-AD011015724R1. We extend our warm thanks to Jonathan Dong, Caio Corro, Victor Pellegrain and Ender Konukoglu for their valuable feedback on the paper.

# REFERENCES

Ibrahim Alabdulmohsin, Xiaohua Zhai, Alexander Kolesnikov, and Lucas Beyer. Getting ViT in Shape: Scaling Laws for Compute-Optimal Model Design. 2023. doi: 10.48550/ARXIV.2305. 13035. URL [https://arxiv.org/abs/2305.13035](https://arxiv.org/abs/2305.13035). Publisher: arXiv Version Number: 5.

Jean-Baptiste Alayrac, Jeff Donahue, Pauline Luc, Antoine Miech, Iain Barr, Yana Hasson, Karel Lenc, Arthur Mensch, Katie Millican, Malcolm Reynolds, Roman Ring, Eliza Rutherford, Serkan Cabi, Tengda Han, Zhitao Gong, Sina Samangooei, Marianne Monteiro, Jacob Menick, Sebastian Borgeaud, Andrew Brock, Aida Nematzadeh, Sahand Sharifzadeh, Mikolaj Binkowski, Ricardo Barreira, Oriol Vinyals, Andrew Zisserman, and Karen Simonyan. Flamingo: a Visual Language Model for Few-Shot Learning. 2022. doi: 10.48550/ARXIV.2204.14198. URL [https://arxiv](https://arxiv/). org/abs/2204.14198. Publisher: arXiv Version Number: 2.

Anthropic. The Claude 3 Model Family: Opus, Sonnet, Haiku, 2024. URL [https://www-cdn.anthropic.com/de8ba9b01c9ab7cbabf5c33b80b7bbc618857627/](https://www-cdn.anthropic.com/de8ba9b01c9ab7cbabf5c33b80b7bbc618857627/) Model Card Claude 3.pdf.

Srikar Appalaraju, Bhavan Jasani, Bhargava Urala Kota, Yusheng Xie, and R. Manmatha. DocFormer: End-to-End Transformer for Document Understanding, 2021. URL [https://arxiv.org/abs/](https://arxiv.org/abs/) 2106.11539. Version Number: 2.

Jinze Bai, Shuai Bai, Shusheng Yang, Shijie Wang, Sinan Tan, Peng Wang, Junyang Lin, Chang Zhou, and Jingren Zhou. Qwen-VL: A Versatile Vision-Language Model for Understanding, Localization, Text Reading, and Beyond. 2023. doi: 10.48550/ARXIV.2308.12966. URL [https://arxiv.org/abs/2308.12966](https://arxiv.org/abs/2308.12966). Publisher: arXiv Version Number: 3.

Payal Bajaj, Daniel Campos, Nick Craswell, Li Deng, Jianfeng Gao, Xiaodong Liu, Rangan Majumder, Andrew McNamara, Bhaskar Mitra, Tri Nguyen, Mir Rosenberg, Xia Song, Alina Stoica, Saurabh Tiwary, and Tong Wang. MS MARCO: A Human Generated MAchine Reading COmprehension Dataset, 2016. URL [https://arxiv.org/abs/1611.09268](https://arxiv.org/abs/1611.09268). Version Number: 3.

Lucas Beyer, Andreas Steiner, Andre´ Susano Pinto, Alexander Kolesnikov, Xiao Wang, Daniel Salz, Maxim Neumann, Ibrahim Alabdulmohsin, Michael Tschannen, Emanuele Bugliarello, Thomas Unterthiner, Daniel Keysers, Skanda Koppula, Fangyu Liu, Adam Grycner, Alexey Gritsenko, Neil Houlsby, Matthias Bauer, Matko Bosˇnjak, Xi Chen, Matthias Minderer, Paul Voigtlaender, Ioana Bica, Ivana Balazevic, Joan Puigcerver, Julian Eisenschlos, Manoj Kumar, Matko Bosˇnjak, Matthias Bauer, Fangyu Liu, Adam Grycner, Alexey Gritsenko, Paul Voigtlaender, Pinelopi Papalampidi, Olivier Henaff, Xi Xiong, Radu Soricut, Jeremiah Harmsen, and Xiaohua Zhai. Paligemma: A versatile 3b vlm for transfer, 2024. URL [https://arxiv.org/](https://arxiv.org/) abs/2407.07726.

Burton H. Bloom. Space/time trade-offs in hash coding with allowable errors. Commun. ACM, 13(7): 422–426, July 1970. ISSN 0001-0782. doi: 10.1145/362686.362692. URL [https://doi.org/](https://doi.org/) 10.1145/362686.362692. Place: New York, NY, USA Publisher: Association for Computing Machinery.

Łukasz Borchmann, Michał Pietruszka, Tomasz Stanislawek, Dawid Jurkiewicz, Michał Turski, Karolina Szyndler, and Filip Grali´nski. DUE: End-to-End Document Understanding Benchmark. In Thirty-fifth Conference on Neural Information Processing Systems Datasets and Benchmarks Track (Round 2), 2021. URL [https://openreview.net/forum?id=rNs2FvJGDK](https://openreview.net/forum?id=rNs2FvJGDK).

Jianlv Chen, Shitao Xiao, Peitian Zhang, Kun Luo, Defu Lian, and Zheng Liu. BGE M3-Embedding: Multi-Lingual, Multi-Functionality, Multi-Granularity Text Embeddings Through Self-Knowledge Distillation, 2024. URL [https://arxiv.org/abs/2402.03216](https://arxiv.org/abs/2402.03216). Version Number: 3.

Xi Chen, Xiao Wang, Lucas Beyer, Alexander Kolesnikov, Jialin Wu, Paul Voigtlaender, Basil Mustafa, Sebastian Goodman, Ibrahim Alabdulmohsin, Piotr Padlewski, Daniel Salz, Xi Xiong, Daniel Vlasic, Filip Pavetic, Keran Rong, Tianli Yu, Daniel Keysers, Xiaohua Zhai, and Radu Soricut. PaLI-3 Vision Language Models: Smaller, Faster, Stronger, 2023. URL [https://arxiv](https://arxiv/). org/abs/2310.09199. Version Number: 2.

Benjamin Clavi´e, Antoine Chaffin, and Griffin Adams. Reducing the Footprint of Multi-Vector Retrieval with Minimal Performance Impact via Token Pooling, 2024. URL [https://arxiv.org/](https://arxiv.org/) abs/2409.14683. Version Number: 1.

Cohere. Introducing Rerank 3: A New Foundation Model for Efficient Enterprise Search & Retrieval, April 2024. URL [https://cohere.com/blog/rerank-3](https://cohere.com/blog/rerank-3).

Tri Dao. Flashattention-2: Faster attention with better parallelism and work partitioning, 2023. URL [https://arxiv.org/abs/2307.08691](https://arxiv.org/abs/2307.08691).

Timoth´ee Darcet, Maxime Oquab, Julien Mairal, and Piotr Bojanowski. Vision Transformers Need Registers. 2023. doi: 10.48550/ARXIV.2309.16588. URL [https://arxiv.org/abs/2309](https://arxiv.org/abs/2309). 16588\. Publisher: \[object Object\] Version Number: 2.

Jacob Devlin, Ming-Wei Chang, Kenton Lee, and Kristina Toutanova. BERT: Pre-training of Deep Bidirectional Transformers for Language Understanding, 2018. URL [https://arxiv.org/abs/](https://arxiv.org/abs/) 1810.04805. Version Number: 2.

Alexey Dosovitskiy, Lucas Beyer, Alexander Kolesnikov, Dirk Weissenborn, Xiaohua Zhai, Thomas Unterthiner, Mostafa Dehghani, Matthias Minderer, Georg Heigold, Sylvain Gelly, Jakob Uszkoreit, and Neil Houlsby. An Image is Worth 16x16 Words: Transformers for Image Recognition at Scale. 2020. doi: 10.48550/ARXIV.2010.11929. URL [https://arxiv.org/abs/2010.11929](https://arxiv.org/abs/2010.11929). Publisher: arXiv Version Number: 2.

Zheng Ge, Songtao Liu, Feng Wang, Zeming Li, and Jian Sun. YOLOX: Exceeding YOLO Series in 2021, 2021. URL [https://arxiv.org/abs/2107.08430](https://arxiv.org/abs/2107.08430). Version Number: 2.

Gemma Team, Thomas Mesnard, Cassidy Hardin, Robert Dadashi, Surya Bhupatiraju, Shreya Pathak, Laurent Sifre, Morgane Rivie\`re, Mihir Sanjay Kale, Juliette Love, Pouya Tafti, Le´onard Hussenot, Pier Giuseppe Sessa, Aakanksha Chowdhery, Adam Roberts, Aditya Barua, Alex Botev, Alex Castro-Ros, Ambrose Slone, Ame´lie He´liou, Andrea Tacchetti, Anna Bulanova, Antonia Paterson, Beth Tsai, Bobak Shahriari, Charline Le Lan, Christopher A. Choquette-Choo, Cl´ement Crepy, Daniel Cer, Daphne Ippolito, David Reid, Elena Bu hatskaya, Eric Ni, Eric Noland, Geng Yan, George Tucker, George-Christian o des venskiy, Henryk Michalewski, Ian Tenney, Ivan Grishchenko, Jacob Au banowski, Jean-Baptiste Lespiau, Jeff Stanway, Jenny Brennan, J Justin Mao-Jones, Katherine Lee, Kathy Yu, Katie Mi ixon, Machel Reid, Maciej Mikuła, Mateo Wirth, Michael , Olivier Bachem, Oscar Chang, Oscar Wahltinez, ahma Chaabouni, Ramona Comanescu, Reena Jana, Rohan ullins, Samuel L Smith, Sebastian Borgeaud, Sertan Girg ndya, Siamak Shakeri, Soham De, Ted Klimenko, Tom Hennigan, Vlad Feinberg, Wojciech Stokowiec, Yu-hui Chen, Zafarali Ahmed, Zhitao Gong, Tris Warkentin, Ludovic Peran, Minh Giang, Cl´ement Farabet, Oriol Vinyals, Jeff Dean, Koray Kavukcuoglu, Demis Hassabis, Zoubin Ghahramani, Douglas Eck, Joelle Barral, Fernando Pereira, Eli Collins, Armand Joulin, Noah Fiedel, Evan Senter, Alek Andreev, and Kathleen Kenealy. Gemma: Open Models Based on Gemini Research and Technology, 2024. URL [https://arxiv.org/abs/2403.08295](https://arxiv.org/abs/2403.08295). Version Number: 4.

Hippolyte Gisserot-Boukhlef, Manuel Faysse, Emmanuel Malherbe, C´eline Hudelot, and Pierre Colombo. Towards trustworthy reranking: A simple yet effective abstention mechanism, 2024. URL [https://arxiv.org/abs/2402.12997](https://arxiv.org/abs/2402.12997).

Edward J. Hu, Yelong Shen, Phillip Wallis, Zeyuan Allen-Zhu, Yuanzhi Li, Shean Wang, Lu Wang, and Weizhu Chen. LoRA: Low-Rank Adaptation of Large Language Models. 2021. doi: 10.48550/ ARXIV.2106.09685. URL [https://arxiv.org/abs/2106.09685](https://arxiv.org/abs/2106.09685). Publisher: arXiv Version Number: 2.

Yupan Huang, Tengchao Lv, Lei Cui, Yutong Lu, and Furu Wei. LayoutLMv3: Pre-training for Document AI with Unified Text and Image Masking. 2022. doi: 10.48550/ARXIV.2204.08387. URL [https://arxiv.org/abs/2204.08387](https://arxiv.org/abs/2204.08387). Publisher: arXiv Version Number: 3.

Albert Q. Jiang, Alexandre Sablayrolles, Arthur Mensch, Chris Bamford, Devendra Singh Chaplot, Diego de las Casas, Florian Bressand, Gianna Lengyel, Guillaume Lample, Lucile Saulnier, Le´lio Renard Lavaud, Marie-Anne Lachaux, Pierre Stock, Teven Le Scao, Thibaut Lavril, Thomas Wang, Timoth´ee Lacroix, and William El Sayed. Mistral 7B. 2023. doi: 10.48550/ARXIV.2310. 06825. URL [https://arxiv.org/abs/2310.06825](https://arxiv.org/abs/2310.06825). Publisher: arXiv Version Number: 1.

Ziyan Jiang, Rui Meng, Xinyi Yang, Semih Yavuz, Yingbo Zhou, and Wenhu Chen. Vlm2vec: Training vision-language models for massive multimodal embedding tasks, 2024. URL https: //arxiv.org/abs/2410.05160.

Vladimir Karpukhin, Barlas O˘guz, Sewon Min, Patrick Lewis, Ledell Wu, Sergey Edunov, Danqi Chen, and Wen-tau Yih. Dense Passage Retrieval for Open-Domain Question Answering, 2020. URL [https://arxiv.org/abs/2004.04906](https://arxiv.org/abs/2004.04906). Version Number: 3.

Omar Khattab and Matei Zaharia. ColBERT: Efficient and Effective Passage Search via Contextualized Late Interaction over BERT. 2020. doi: 10.48550/ARXIV.2004.12832. URL [https://arxiv.org/abs/2004.12832](https://arxiv.org/abs/2004.12832).

Geewook Kim, Teakgyu Hong, Moonbin Yim, Jeongyeon Nam, Jinyoung Park, Jinyeong Yim, Wonseok Hwang, Sangdoo Yun, Dongyoon Han, and Seunghyun Park. OCR-free Document Understanding Transformer, 2021. URL [https://arxiv.org/abs/2111.15664](https://arxiv.org/abs/2111.15664). Version Number: 5.

Andreas Koukounas, Georgios Mastrapas, Michael Gu¨nther, Bo Wang, Scott Martens, Isabelle Mohr, Saba Sturua, Mohammad Kalim Akram, Joan Fontanals Mart´ınez, Saahil Ognawala, Susana Guzman, Maximilian Werk, Nan Wang, and Han Xiao. Jina CLIP: Your CLIP Model Is Also Your Text Retriever, 2024. URL [https://arxiv.org/abs/2405.20204](https://arxiv.org/abs/2405.20204). Version Number: 1.

Hugo Lauren¸con, Andre´s Marafioti, Victor Sanh, and Le´o Tronchon. Building and better understanding vision-language models: insights and future directions., 2024a.

Hugo Laurenc¸on, Le´o Tronchon, Matthieu Cord, and Victor Sanh. What matters when building visionlanguage models?, May 2024b. URL [http://arxiv.org/abs/2405.02246](http://arxiv.org/abs/2405.02246). arXiv:2405.02246 \[cs\].

Chankyu Lee, Rajarshi Roy, Mengyao Xu, Jonathan Raiman, Mohammad Shoeybi, Bryan Catanzaro, and Wei Ping. Nv-embed: Improved techniques for training llms as generalist embedding models, 2024. URL [https://arxiv.org/abs/2405.17428](https://arxiv.org/abs/2405.17428).

Jinhyuk Lee, Zhuyun Dai, Sai Meher Karthik Duddu, Tao Lei, Iftekhar Naim, Ming-Wei Chang, and Vincent Y. Zhao. Rethinking the Role of Token Retrieval in Multi-Vector Retrieval, 2023. URL [https://arxiv.org/abs/2304.01982](https://arxiv.org/abs/2304.01982). Version Number: 3.

Lei Li, Yuqi Wang, Runxin Xu, Peiyi Wang, Xiachong Feng, Lingpeng Kong, and Qi Liu. Multimodal arxiv: A dataset for improving scientific comprehension of large vision-language models, 2024.

Tsung-Yi Lin, Michael Maire, Serge Belongie, Lubomir Bourdev, Ross Girshick, James Hays, Pietro Perona, Deva Ramanan, C. Lawrence Zitnick, and Piotr Doll´ar. Microsoft COCO: Common Objects in Context, 2014. URL [https://arxiv.org/abs/1405.0312](https://arxiv.org/abs/1405.0312). Version Number: 3.

Haotian Liu, Chunyuan Li, Qingyang Wu, and Yong Jae Lee. Visual Instruction Tuning. 2023. doi: 10.48550/ARXIV.2304.08485. URL [https://arxiv.org/abs/2304.08485](https://arxiv.org/abs/2304.08485). Publisher: arXiv Version Number: 1.

Lucas Beyer\*, Andreas Steiner\*, Andr´e Susano Pinto\*, Alexander Kolesnikov\*, Xiao Wang\*, Xiaohua Zhai\*, Daniel Salz, Maxim Neumann, Ibrahim Alabdulmohsin, Michael Tschannen, Jeremiah Harmsen, Daniel Keysers, Neil Houlsby, Xi Chen, Emanuele Bugliarello, Thomas Unterthiner, Keran Rong, Matthias Minderer, Ioana Bica, Ivana Balazevic, Joan Puigcerver, Julian Eisenschlos, Manoj Kumar, Matko Bosˇnjak, Matthias Bauer, Fangyu Liu, Adam Grycner, Alexey Gritsenko, Paul Voigtlaender, Pinelopi Papalampidi, Olivier Henaff, Skanda Koppula, Xi Xiong, Radu Soricut, Model release contributors and general support, Tris Warkentin, Kat Black, Luiz Gustavo Martins, Glenn Cameron, Raj Gundluru, Manvinder Singh, Meg Risdal, Nilay Chauhan, Nate Keating, Nesh Devanathan, Elisa Bandy, Joe Fernandez, Antonia Paterson, Jenny Brennan, Tom Eccles, Pankil Botadra, Ben Bariach, Lav Rai, Minwoo Park, Dustin Luong, Daniel Vlasic, Bo Wu, Wenming Ye, Divyashree Sreepathihalli, Kiranbir Sodhia, Alek Andreev, Armand Joulin, Surya Bhupatiraju, Minh Giang, Joelle Barral, and Zoubin Ghahramani. PaliGemma, 2024. URL [https://www.kaggle.com/m/23393](https://www.kaggle.com/m/23393).

Yubo Ma, Yuhang Zang, Liangyu Chen, Meiqi Chen, Yizhu Jiao, Xinze Li, Xinyuan Lu, Ziyu Liu, Yan Ma, Xiaoyi Dong, Pan Zhang, Liangming Pan, Yu-Gang Jiang, Jiaqi Wang, Yixin Cao, and Aixin Sun. Mmlongbench-doc: Benchmarking long-context document understanding with visualizations, 2024. URL [https://arxiv.org/abs/2407.01523](https://arxiv.org/abs/2407.01523).

Minesh Mathew, Dimosthenis Karatzas, and C. V. Jawahar. DocVQA: A Dataset for VQA on Document Images. 2020. doi: 10.48550/ARXIV.2007.00398. URL [https://arxiv.org/abs/](https://arxiv.org/abs/) 2007.00398.

Minesh Mathew, Viraj Bagal, Rub\`en P´erez Tito, Dimosthenis Karatzas, Ernest Valveny, and C. V Jawahar. InfographicVQA, 2021. URL [https://arxiv.org/abs/2104.12756](https://arxiv.org/abs/2104.12756). Version Number: 2.

Niklas Muennighoff, Nouamane Tazi, Loı¨c Magne, and Nils Reimers. MTEB: Massive Text Embedding Benchmark, 2022. URL [https://arxiv.org/abs/2210.07316](https://arxiv.org/abs/2210.07316). Version Number: 3.

Nomic. Nomic Embed Vision: Expanding The Nomic Latent Space, June 2024. URL https: //blog.nomic.ai/posts/nomic-embed-vision.

Averi Nowak, Francesco Piccinno, and Yasemin Altun. Multimodal chart retrieval: A comparison of text, table and image based approaches. In Kevin Duh, Helena Gomez, and Steven Bethard (eds.), Proceedings of the 2024 Conference of the North American Chapter of the Association for Computational Linguistics: Human Language Technologies (Volume 1: Long Papers), pp. 5488–5505, Mexico City, Mexico, June 2024. Association for Computational Linguistics. doi: 10.18653/v1/2024.naacl-long.307. URL [https://aclanthology.org/2024.naacl-long.307](https://aclanthology.org/2024.naacl-long.307).

Alec Radford, Jong Wook Kim, Chris Hallacy, Aditya Ramesh, Gabriel Goh, Sandhini Agarwal, Girish Sastry, Amanda Askell, Pamela Mishkin, Jack Clark, Gretchen Krueger, and Ilya Sutskever. Learning Transferable Visual Models From Natural Language Supervision. 2021. doi: 10.48550/ ARXIV.2103.00020. URL [https://arxiv.org/abs/2103.00020](https://arxiv.org/abs/2103.00020). Publisher: arXiv Version Number: 1.

Nils Reimers and Iryna Gurevych. Sentence-BERT: Sentence Embeddings using Siamese BERTNetworks, 2019. URL [https://arxiv.org/abs/1908.10084](https://arxiv.org/abs/1908.10084). Version Number: 1.

Stephen E. Robertson, Steve Walker, Susan Jones, Micheline Hancock-Beaulieu, and Mike Gatford. Okapi at TREC-3. In Donna K. Harman (ed.), Proceedings of The Third Text REtrieval Conference, TREC 1994, Gaithersburg, Maryland, USA, November 2-4, 1994, volume 500-225 of NIST Special Publication, pp. 109–126. National Institute of Standards and Technology (NIST), 1994. URL [http://trec.nist.gov/pubs/trec3/papers/city.ps.gz](http://trec.nist.gov/pubs/trec3/papers/city.ps.gz).

Keshav Santhanam, Omar Khattab, Christopher Potts, and Matei Zaharia. PLAID: An Efficient Engine for Late Interaction Retrieval, 2022. URL [https://arxiv.org/abs/2205.09707](https://arxiv.org/abs/2205.09707). Version Number: 1.

R. Smith. An Overview of the Tesseract OCR Engine. In Ninth International Conference on Document Analysis and Recognition (ICDAR 2007) Vol 2, pp. 629–633, Curitiba, Parana, Brazil, September 2007. IEEE. ISBN 978-0-7695-2822-9. doi: 10.1109/ICDAR.2007.4376991. URL [http://ieeexplore.ieee.org/document/4376991/](http://ieeexplore.ieee.org/document/4376991/). ISSN: 1520-5363.

Karen Sparck Jones. A STATISTICAL INTERPRETATION OF TERM SPECIFICITY AND ITS APPLICATION IN RETRIEVAL. Journal of Documentation, 28(1):11–21, January 1972. ISSN 0022-0418. doi: 10.1108/eb026526. URL [https://www.emerald.com/insight/content/doi/](https://www.emerald.com/insight/content/doi/) 10.1108/eb026526/full/html.

Zineng Tang, Ziyi Yang, Guoxin Wang, Yuwei Fang, Yang Liu, Chenguang Zhu, Michael Zeng, Cha Zhang, and Mohit Bansal. Unifying Vision, Text, and Layout for Universal Document Processing, 2022. URL [https://arxiv.org/abs/2212.02623](https://arxiv.org/abs/2212.02623). Version Number: 3.

Nandan Thakur, Nils Reimers, Andreas Ru¨ckle´, Abhishek Srivastava, and Iryna Gurevych. BEIR: A Heterogenous Benchmark for Zero-shot Evaluation of Information Retrieval Models, 2021. URL [https://arxiv.org/abs/2104.08663](https://arxiv.org/abs/2104.08663). Version Number: 4.

Ashish V. Thapliyal, Jordi Pont-Tuset, Xi Chen, and Radu Soricut. Crossmodal-3600: A Massively Multilingual Multimodal Evaluation Dataset, 2022. URL [https://arxiv.org/abs/2205.12522](https://arxiv.org/abs/2205.12522). Version Number: 2.

Liang Wang, Nan Yang, Xiaolong Huang, Binxing Jiao, Linjun Yang, Daxin Jiang, Rangan Majumder, and Furu Wei. Text Embeddings by Weakly-Supervised Contrastive Pre-training, 2022. URL [https://arxiv.org/abs/2212.03533](https://arxiv.org/abs/2212.03533). Version Number: 2.

Liang Wang, Nan Yang, Xiaolong Huang, Linjun Yang, Rangan Majumder, and Furu Wei. Improving text embeddings with large language models, 2024a. URL [https://arxiv.org/abs/2401](https://arxiv.org/abs/2401). 00368.

Peng Wang, Shuai Bai, Sinan Tan, Shijie Wang, Zhihao Fan, Jinze Bai, Keqin Chen, Xuejing Liu, Jialin Wang, Wenbin Ge, Yang Fan, Kai Dang, Mengfei Du, Xuancheng Ren, Rui Men, Dayiheng Liu, Chang Zhou, Jingren Zhou, and Junyang Lin. Qwen2-vl: Enhancing vision-language model’s perception of the world at any resolution, 2024b. URL [https://arxiv.org/abs/2409.12191](https://arxiv.org/abs/2409.12191).

Wenhui Wang, Furu Wei, Li Dong, Hangbo Bao, Nan Yang, and Ming Zhou. MiniLM: Deep Self-Attention Distillation for Task-Agnostic Compression of Pre-Trained Transformers, April 2020. URL [http://arxiv.org/abs/2002.10957](http://arxiv.org/abs/2002.10957). arXiv:2002.10957 \[cs\].

Lewei Yao, Runhui Huang, Lu Hou, Guansong Lu, Minzhe Niu, Hang Xu, Xiaodan Liang, Zhenguo Li, Xin Jiang, and Chunjing Xu. FILIP: Fine-grained Interactive Language-Image Pre-Training, 2021. URL [https://arxiv.org/abs/2111.07783](https://arxiv.org/abs/2111.07783). Version Number: 1.

Xiang Yue, Yuansheng Ni, Kai Zhang, Tianyu Zheng, Ruoqi Liu, Ge Zhang, Samuel Stevens, Dongfu Jiang, Weiming Ren, Yuxuan Sun, Cong Wei, Botao Yu, Ruibin Yuan, Renliang Sun, Ming Yin, Boyuan Zheng, Zhenzhu Yang, Yibo Liu, Wenhao Huang, Huan Sun, Yu Su, and Wenhu Chen. MMMU: A Massive Multi-discipline Multimodal Understanding and Reasoning Benchmark for Expert AGI, 2023. URL [https://arxiv.org/abs/2311.16502](https://arxiv.org/abs/2311.16502). Version Number: 3.

Xiaohua Zhai, Basil Mustafa, Alexander Kolesnikov, and Lucas Beyer. Sigmoid Loss for Language Image Pre-Training. 2023. doi: 10.48550/ARXIV.2303.15343. URL [https://arxiv.org/abs/](https://arxiv.org/abs/) 2303.15343. Publisher: \[object Object\] Version Number: 4.

Li Zhang, Shuo Zhang, and Krisztian Balog. Table2vec: Neural word and entity embeddings for table population and retrieval. In Proceedings of the 42nd International ACM SIGIR Conference on Research and Development in Information Retrieval, SIGIR ’19. ACM, July 2019. doi: 10.1145/3331184.3331333. URL [http://dx.doi.org/10.1145/3331184.3331333](http://dx.doi.org/10.1145/3331184.3331333).

Ruochen Zhao, Hailin Chen, Weishi Wang, Fangkai Jiao, Xuan Long Do, Chengwei Qin, Bosheng Ding, Xiaobao Guo, Minzhi Li, Xingxuan Li, and Shafiq Joty. Retrieving Multimodal Information for Augmented Generation: A Survey, 2023. URL [https://arxiv.org/abs/2303.10868](https://arxiv.org/abs/2303.10868). Version Number: 3.

Fengbin Zhu, Wenqiang Lei, Fuli Feng, Chao Wang, Haozhou Zhang, and Tat-Seng Chua. Towards Complex Document Understanding By Discrete Reasoning. 2022. doi: 10.48550/ARXIV.2207. 11871. URL [https://arxiv.org/abs/2207.11871](https://arxiv.org/abs/2207.11871). Publisher: arXiv Version Number: 3.

# A BENCHMARK DATASETS

A.1 ACADEMIC DATASETS

DocVQA (Mathew et al., 2020) includes collected images from the UCSF Industry Documents Library. Questions and answers were manually annotated.

InfoVQA (Mathew et al., 2021) includes infographics collected from the Internet using the search query “infographics”. Questions and answers were manually annotated.

TAT-DQA (Zhu et al., 2022) is a large-scale Document VQA dataset that was constructed from publicly available real-world financial reports. It focuses on rich tabular and textual content requiring numerical reasoning. Questions and answers were manually annotated by human experts in finance.

arXivQA (Li et al., 2024) is a VQA dataset based on figures extracted from arXiv publications. The questions were generated synthetically using GPT-4 Vision.

TabFQuAD (Table French Question Answering Dataset) is designed to evaluate TableQA models in realistic industry settings. We create additional queries to augment the existing human-annotated ones using the same method described in subsection A.2.

# A.2 PRACTICAL DATASETS

Methodology. Creating a relevant retrieval dataset close to real use cases is a major challenge as the dataset needs to be both sufficiently large for effective fine-tuning and sufficiently diverse to cover a broad range of modalities (full text, tables, charts, ...), domains (industry, healthcare, ...), and query-document interactions (extractive questions, open-ended questions, ...). Our approach to building this dataset involves several steps: (1) we use a web crawler to collect publicly available documents on various themes and sources, (2) we convert these PDFs into a series of images, one per page, and (3) we generate queries related to each image using a VLM.

Web-Crawler. We implemented a web crawler to efficiently collect large volumes of documents related to a given topic. The crawler is seeded with a user-defined query (e.g. “artificial intelligence”) and then uses GPT-3.5 Turbo to brainstorm related topics and subtopics. This query augmentation strategy aims at both broadening and deepening the search. GPT-3.5 Turbo is further used to generate diverse search queries from each subtopic. This query set is then consumed by a pool of parallel workers whose job is to fetch the associated most relevant documents. We use SerpAPI17 along with a filetype filter (PDF documents only) to programmatically scrape Google Search rankings. Each file is hashed and stored in a Bloom filter (Bloom, 1970) shared among workers to avoid duplicate documents in the final corpus. Unique scraped files are downloaded, and inserted into a SQLite database along with additional metadata.

Datamix. Using the web crawler, we collected approximately 100 documents for each of the following four seeds: “energy”, “government reports”, “healthcare industry”, and “artificial intelligence”. These seeds were meticulously hand-picked to align with real-use cases for retrieval models and visually rich pages. We also removed all documents containing any private information.

Query Generation. To increase the efficiency of our query generation scheme and to limit API calls, we generate at most 3 questions per image. From all the documents collected, we randomly sample 10,000 images per theme and call Claude-3 Sonnet with the following prompt:

You are an assistant specialized in Multimodal RAG tasks.

The task is the following: given an image from a pdf page, you will have to generate questions that can be asked by a user to retrieve information from a large documentary corpus.

The question should be relevant to the page, and should not be too specific or too general. The question should be about the subject of the page, and the answer needs to be found in the page.

Remember that the question is asked by a user to get some information from a

large documentary corpus that contains multimodal data. Generate a question

that could be asked by a user without knowing the existence and the content

of the corpus.

Generate as well the answer to the question, which should be found in the

page. And the format of the answer should be a list of words answering the

question.

Generate at most THREE pairs of questions and answers per page in a dictionary

with the following format, answer ONLY this dictionary NOTHING ELSE:

{ "questions": \[ { "question": "XXXXXX", "answer": \["YYYYYY"\] }, { "question": "XXXXXX", "answer": \["YYYYYY"\] }, { "question": "XXXXXX", "answer": \["YYYYYY"\] }, \]

}

where XXXXXX is the question and \['YYYYYY'\] is the corresponding list of answers

that could be as long as needed. Note: If there are no questions to ask about the page, return an empty list. Focus on making relevant questions concerning the page.

Here is the page:

Human Validation. We manually validate every single synthetically created query in ViDoRe to ensure quality, query relevance, and consistency with the benchmark objective of evaluating retrieval in practical industrial settings. During this step, we randomly assign document-pair queries to 4 volunteer annotators and instruct them to filter out queries that do not fit the above-listed criteria. We also instruct annotators to flag any documents they deem to contain PII information or content not suited for an academic benchmark. No flag was raised during the entirety of the process, validating our prior PDF collection strategy. 100 queries per topic are collected in this manner. Annotators are colleagues and collaborators of the authors who volunteered to help. Each annotator spent approximately 3 hours filtering the larger query set down to 100 high-quality queries per topic.

# A.3 TRAINING DATASET

The statistics of the train set are given in the following table. The creation of the train set follows the same methodology as in subsection A.2. We made sure that a PDF document cannot have pages in both the training set and the test set to prevent data leakage and that there are no duplicate documents in each split.

Table 3: Details on the different splits in the dataset used to train ColPali.

|     |     |     |     |
| --- | --- | --- | --- |
| Dataset Split | Split Size | Language | Domain |
| DocVQA | 39,463 | English | Scanned documents from UCSF Industry |
| InfoVQA | 10,074 | English | Infographics scrapped from the web |
| TATDQA | 13,251 | English | High-quality financial reports |
| arXivQA | 10,000 | English | Scientific Scientific Figures from arXiv |
| Scrapped PDFs | 45,940 | English | Varied PDFs from 3885 distinct URL domains |
| TOTAL | 118,695 | English-only | Mixed |

# B IMPLEMENTATION DETAILS

# B.1 CODEBASE

The codebase is written in PyTorch18 and leverages HuggingFace tooling for model implementations and trainers19.

# B.2 HYPERPARAMETERS

Hyperparameters are tuned on a validation split composed of $2 %$ of the training dataset. We find bi-encoder methods to be more sensible to learning rate variations than late interaction-based models and achieve the best performance for all models with a learning rate of $5 e \mathrm { ~ - ~ } 5$ . We experiment with LoRA rank and $\alpha$ values and do not notice particular improvements past $r = \alpha = 3 2$ . Per-device batch sizes are kept small due to long sequence lengths that complicate scaling past $b = 4$ . We simulate larger batch sizes with multi-GPU training and train with a total batch size $b = 3 2$ with no accumulation, for 1 epoch on our training set.

# B.3 EMBEDDING SIZE

Minimizing storage footprint can be essential to industrial retrieval systems if databases contain millions of documents. With this criterion in view, we have compared the embedding sizes of the models in our study. As shown in Table 4, ColPali’s embedding size is an order of magnitude larger than BM25 and two orders of magnitude larger than BGE-M3. However, in practical scenarios, pooling multi-vector embeddings by centroid cluster, or quantizing embeddings to binary representations 20 can reduce storage costs by two orders of magnitude (Santhanam et al., 2022) with minimal performance hits, and make storage costs competitive with other systems.

|     |     |
| --- | --- |
| Model | Embeddingsize (KB) |
| BGE-M3 | 8.60 |
| BM25 (dense emb.) | 3.00 |
| BM25 (sparse emb.) | 1.56 ± 0.51 |
| ColPali (float16) | 257.5 |

Table 4: Comparison of the embedding sizes for the DocVQA test set from ViDoRe w.r.t. different retrieval models. The mean $\\pm$ std size is given for the sparse embeddings. In general multiple vectors (2-5) per page are used for BGE-M3 and BM25.

# B.4 LATENCY COMPUTATIONS

To ensure comparison fairness, the latencies of the different retrieval systems shown in Figure 2 are measured on the same g2-standard-8 GCP VM with a NVIDIA L4 GPU. Document pages are embedded using the highest settings of Unstructured with captioning (see subsection 3.2). SigLIP and ColPali are both loaded with bfloat16 parameter dtypes. The reported times in Table 5 are the average per-page latencies for each indexing operation on 1000 randomly chosen documents across all splits of the ViDoRe benchmark test set. A batch size of 8 was used for the BGE-M3 model used with Unstructured, and a batch size of 4 was used for SigLIP and ColPali.

|     |     |     |     |
| --- | --- | --- | --- |
| Indexing operation | Latency (s) |
| Unstructured | SigLIP | ColPali |
| Layout detection | 0.81 | NA | NA |
| OCR | 2.67 | NA | NA |
| Captioning | 3.71 | NA | NA |
| Page encoding | 0.03 | 0.12 | 0.39 |
| Total | 7.22 | 0.12 | 0.39 |

Table 5: Page-level latencies for document indexing using various retrieval systems. SigLIP and ColPali are much faster than Unstructured because they don’t require the layout detection, OCR, and captioning operations.

# B.5 CAPTIONING

Examples of captions generated for visually rich document chunks with Claude-3 Sonnet are shown in Figure 5 and Figure 4. The prompt used for generating the description is the following:

You are an assistant specialized in document analysis. Given a table or a figure, you have to provide a detailed summary of the content in maximum 3000 characters. Your summary should be qualitative and not quantitative. Here is the table/figure to analyze: {image}. Answer ONLY with the caption of the table/figure.

https://arxiv.org/pdf/images/b578972a7404cd92e3c49325f2b39546dbecd19e0ac452bc06ace2578cb6a1ba.jpg

Figure 4: Example from the “Energy” test set.

Caption: The image depicts the hourly energy generation profile, illustrating the contributions of various energy sources over 24 hours. The data is presented as a stacked bar chart, with the $x$ -axis representing the hours of the day from 1 to 2, and the y-axis showing the average hourly generation in MW. The bars are segmented into different colors, each representing a distinct energy source: nuclear, bio, geothermal, solar, wind, hydro, natural gas, and other imports. The chart provides insights into the temporal variations in energy generation across different sources, highlighting the interplay between baseload and intermittent sources throughout the day.

https://arxiv.org/pdf/images/5e9e3c0f9ff527eae81290a8397593ca7163bf60bed81795640a8ebdc03d7a3c.jpg

Figure 5: Example from the “Government Reports” test set.

Caption: The image shows a table titled “System of Record” which outlines the different types of documents or records maintained across various systems or departments within an organization related to project management and construction. The rows list documents like project plans, budgets, schedules, contracts, purchase orders, invoices, change requests, bid submissions, drawings, manuals, meeting minutes, and reports. The columns indicate the system or department responsible for maintaining each record, such as County Servers, Project View, OnBase, CGI Advantage Financial System, and Purchasing Department. The table uses ”W” and ”T” markers to denote which system or department serves as the primary source (writer) or storage location (trailer) for each type of document.

# C ADDITIONAL RESULTS

C.1 OTHER METRICS

|     |     |     |     |     |     |     |     |     |     |     |     |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | ArxivQ DocQ |  | InfoQ | TabF | TATQ | Shift | AI | Energy | Gov. | Health. | Avg. |
| Unstructured text-only |  |  |  |  |  |  |  |  |  |  |  |
| BM25 |  | 26.6 |  |  | 34.6 | 45.0 | 86.0 | 70.0 | 68.0 | 74.0 |  |
| BGE-M3 |  | 22.8↓3.8 |  |  | 26.1↓8.5 | 51.0†6.0 | 81.0↓5.0 | 72.0↑2.0 | 67.0↓1.0 | 77.0↑3.0 |  |
| Unstructured + ocR |  |  |  |  |  |  |  |  |  |  |  |
| BM25 | 26.7 | 28.9 | 54.0 | 30.4 | 50.0 | 52.0 | 86.0 | 77.0 | 74.0 | 80.0 | 55.9 |
| BGE-M3 | 28.1†1.4 | 22.9↓6.0 | 53.8↓0.2 |  |  | 55.7†25.3 38.6↓11.4 56.0↑4.0 | 82.0↓4.0 | 79.0↑2.0 | 76.0↑2.0 | 83.0↑3.0 | 57.5↑1.6 |
| Unstructured + Captioning |  |  |  |  |  |  |  |  |  |  |  |
| BM25 | 35.5 | 30.2 | 61.5 | 24.3 | 49.0 | 47.0 | 79.0 | 76.0 | 75.0 | 81.0 | 55.9 |
| BGE-M3 | 29.3↓6.2 | 26.0↓4.2 | 62.1 t0.6 |  |  | 58.6†34.3 30.618.4 55.0个8.0 | 80.0†1.0 | 78.0+2.0 | 69.0↓6.0 | 83.0+2.0 | 57.2↑1.3 |
| Contrastive VLMs |  |  |  |  |  |  |  |  |  |  |  |
| Jina-CLIP | 19.4 | 7.3 | 26.7 | 12.5 | 1.6 | 2.0 | 11.0 | 13.0 | 15.0 | 17.0 | 12.6 |
| Nomic-vision | 10.4 | 6.7 | 22.1 | 9.6 | 1.6 | 0.0 | 9.0 | 9.0 | 7.0 | 13.0 | 8.8 |
| SigLIP (vanilla) | 34.2 | 21.3 | 51.8 | 46.1 | 17.9 | 13.0 | 50.0 | 51.0 | 47.0 | 65.0 | 39.7 |
| Ours |  |  |  |  |  |  |  |  |  |  |  |
| SigLIP (vanilla) | 34.2 | 21.3 | 51.8 | 46.1 | 17.9 | 13.0 | 50.0 | 51.0 | 47.0 | 65.0 | 39.7 |
| BiSigLIP (+fine-tuning) |  | 49.2↑15.0 23.8↑2.5 | 59.0↑7.2 | 52.1↑6.0 | 20.7†2.8 | 16.0↑3.0 |  | 62.0↑12.0 61.0↑10.0 55.0↑8.0 |  | 72.0†7.0 | 47.1↑7.4 |
| BiPali (+LLM) |  |  |  |  |  |  |  |  | 46.4↓-2.820.0↓-3.854.6↓-4.4 63.2↑1120.4-0.434.0↑18.059.0-3.0 45.0-16.057.02.0 | 56.0↓-16.0 | 45.6↓-1.5 |
| ColPali (+Late Inter.) |  | 72.4个26.045.6↑25.6 74.6↑20.0 75.4个12.1 |  |  |  |  |  | 53.1↑32.7 55.0个21.0 93.0↑34.0 85.0个40.0 | 85.0↑28.0 | 88.0↑32.0 | 72.7↑27.1 |

Table 6: Comprehensive evaluation of baseline models and our proposed method on ViDoRe. Results are presented using Recall $@$ 1 metrics. Text-only metrics are not computed for benchmarks with only visual elements.

C.2 MODEL VARIANTS

Table 7: Benchmark scores for the “negative results” and various ablations on ViDoRe; ColPali for reference. Results are presented using nDCG $\textcircled { a } 5$ metrics. Text-only metrics are not computed for benchmarks with only visual elements.

|     |     |     |     |     |     |     |     |     |     |     |     |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | ArxivQ DocQ InfoQ TabF TATQ |  |  |  |  | Shift AI |  | Energy |  | Gov. Health. | Avg. |
| ColSigLIP (PaliGemma) | 3.1 | 3.0 | 5.1 | 6.2 | 2.5 | 1.0 | 3.4 | 3.4 | 2.3 | 2.2 | 3.2 |
| BiSigLIP (PaliGemma) | 18.5 | 14.6 | 33.4 | 39.5 | 16.1 | 5.2 |  | 27.6 32.6 | 36.6 | 35.7 | 26.0 |
| ColSigLIP (Original) | 2.6 | 2.2 | 2.3 | 5.7 | 1.8 | 1.0 | 2.6 | 4.1 | 1.4 | 1.5 | 2.5 |
| ColPali (No Q.A. Tokens) | 80.4 | 53.2 | 82.4 | 77.4 | 65.7 | 63.4 |  | 97.0 89.9 | 93.6 | 92.4 | 79.6 |
| ColPali (Docmatix) | 71.3 | 48.0 | 80.0 | 83.9 | 59.1 | 73.8 |  | 95.7 93.8 | 92.5 | 93.1 | 79.1 |
| ColPali (224) | 71.0 | 37.4 | 62.3 | 65.7 | 28.6 | 20.4 |  | 65.7 66.8 | 73.9 | 73.0 | 56.5 |
| ColPali (Vision Trained) | 78.8 | 53.9 | 81.3 | 81.7 | 64.4 | 70.6 |  | 95.3 91.7 | 93.5 | 94.7 | 80.6 |
| ColPali (No Pairwise) | 79.0 | 53.0 | 82.1 | 85.3 | 63.2 | 66.2 |  | 94.9 88.9 | 92.7 | 92.1 | 79.7 |
| ColPali (+TabFQuAD training) | 77.6 | 54.7 | 82.6 | 86.5 | 65.4 | 73.9 |  | 94.8 92.4 | 94.2 | 94.8 | 81.7 |
| ColIdefics2 (64) | 73.6 | 48.0 | 82.4 | 81.6 | 63.0 | 57.2 |  | 95.5 86.9 | 86.6 | 91.2 | 76.6 |
| ColQwen2 (768) | 86.4 | 56.2 | 89.8 | 88.7 | 75.2 | 85.7 |  | 98.8 94.8 | 93.6 | 97.3 | 86.6 |
| ColPali (Reference: 448) | 79.1 | 54.4 | 81.8 | 83.9 | 65.8 | 73.2 |  | 96.2 91.0 | 92.7 | 94.4 | 81.3 |

https://arxiv.org/pdf/images/0217658dc526953c07436f5e23c0b69a3a6f330c58603950c07fdda9a8a2836d.jpg

Query: "Quelle partie de la production pétroliere du Kazakhstan provient de champs en mer ?"

Figure 6: Similarity of the image patches w.r.t. the underlined token in the user query. This example is from the Shift test set.

# D MORE SIMILARITY MAPS

In Figure 6, ColPali assigns a high similarity to all patches with the word “Kazakhstan” when given the token < Kazakhstan>. Moreover, our model seems to exhibit world knowledge capabilities as the patch around the word ”Kashagan”—an offshore oil field in Kazakhstan—also shows a high similarity score.

It is also interesting to highlight that both this similarity map and the one displayed in Figure 3 (right) showcase a few white patches with high similarity scores. This behavior might first seem surprising as the white patches should not carry a meaningful signal from the original images. We believe the vectors associated with these patches share a similar role with the ViT registers (Darcet et al., 2023), i.e. these patches were repurposed for internal computations and stored the global information from the whole image.

# E MODEL GLOSSARY

SIGLIP

SigLIP (Sigmoid Loss for Language Image Pre-Training) builds upon CLIP (Contrastive LanguageImage Pretraining)—a foundational model that aligns images and text by maximizing the similarity between correct image-text pairs while minimizing it for incorrect ones, leveraging a contrastive loss (Zhai et al., 2023). Unlike CLIP (Radford et al., 2021), which applies the softmax function to the logits, SigLIP uses the sigmoid activation function. This innovation eliminates the need for a global view of all pairwise similarities between images and texts within a batch, enabling more flexible batch size scaling (up to 1M items per batch, with an effective optimal batch size of 32k). This approach allows SigLIP to achieve state-of-the-art performance in zero-shot image classification tasks.

# PALIGEMMA

PaliGemma is a 3B-parameter vision-language model. It integrates the SigLIP vision encoder with a Gemma-2B language decoder, connected via a multimodal linear projection layer (Lucas Beyer\* et al.,

2024). The model processes images by segmenting them into a fixed number of Vision Transformer (Dosovitskiy et al., 2020) tokens, which are prepended to an optional text prompt.

A distinguishing feature of PaliGemma is its operation as a Prefix-Language Model (Prefix-LM). This design ensures full attention between image tokens and the user-provided input (prefix) while generating outputs auto-regressively (suffix). This architecture allows image tokens to access the task-specific query during processing, facilitating more effective task-dependent reasoning.

PaliGemma was trained in four stages: unimodal pretraining with existing components, extended multimodal pretraining, short high-resolution pretraining, and task-specific fine-tuning.

# COLBERT

ColBERT (Contextualized Late Interaction over BERT) is a retrieval model designed to balance speed and effectiveness in information retrieval tasks (Khattab & Zaharia, 2020). Traditional retrieval models are typically categorized based on their type of interaction: either processing queries and documents independently for efficiency (bi-encoders) or jointly to capture rich contextual relationships (crossencoders). ColBERT combines the advantages of both approaches through a novel late interaction mechanism.

Queries and documents are encoded separately using BERT, enabling offline pre-computation of document representations for scalability. Instead of pooling embeddings into a single vector, ColBERT retains token-level embeddings and employs a MaxSim operator to compute fine-grained similarity scores. For each query token, the model determines the maximum similarity with document tokens, summing these scores to compute relevance.

This architecture preserves the contextual richness of deep language models while significantly improving computational efficiency. By delaying the interaction step, ColBERT supports vector similarity indexing, facilitating end-to-end retrieval from large collections without prohibitive costs. Empirical evaluations on passage search datasets demonstrate that ColBERT achieves competitive effectiveness compared to existing BERT-based models (Devlin et al., 2018), while executing queries orders of magnitude faster and with drastically reduced computational requirements.

# F EXAMPLES FROM THE ViDoRe BENCHMARK

# Energy

Query: What types of accounts or products allow investors to defer paying taxes?

Query: What is the estimated to-Query: What is the projected

tal savings for a PV system in peak electricity demand in Cali

Durham under the net metering fornia for the year 2030?

(flat rate) billing option over the stem’s useful life of 25 years?

https://arxiv.org/pdf/images/1f9bb209c65efe578ba50868a9c38ce8cb6f246966ae148e4620d11a0e607212.jpg

https://arxiv.org/pdf/images/3960e4108709e4059f26cfe162eb3d936c3067e514cb08ca74f06162a8133d67.jpg

https://arxiv.org/pdf/images/e42b7fab5707392bc051a93970281ac113009ce37c322c63a68c4abebcd55ef7.jpg

# Artificial Intelligence

Query: What are some common outcome areas targeted by TAII for different age groups?

Query: What did the robot moni- Query: What is the key approach

tor to determine when to activate used in the PDP architecture?

or deactivate the blower motor

and blinker?

https://arxiv.org/pdf/images/9016549ff01b9fbab36065594cd1ee58efc6b7d6f0e48d20e3de677225676ae7.jpg

https://arxiv.org/pdf/images/bd0530bcbb330f02782de1f5c1297af8b783f13733b31cc36cd41350f36dfa27.jpg

# Healthcare Industry

Query: What is the chemical formula for the ferroelectric material Lead Zirconium Titanate (PZT)?

Query: What government entities are involved in public financing for healthcare in the US?

Query: What does the AVPU scale stand for in assessing the level of consciousness of a seriously ill child?

https://arxiv.org/pdf/images/1444da993a6ee3b1f59c12ed057e76987d6d04ec703b309af1f57ca2a86b3e76.jpg

https://arxiv.org/pdf/images/38372b0dbe77a01b8b69787f56cb4099efbb3dcb110561bbe169fd3229ace1cb.jpg

https://arxiv.org/pdf/images/91878a732ed3319672984664297e6dc86f53c974a9af005b68884f221dcec18c.jpg

# Government Reports

# Query: What are some mandates for the EPA under the Pollution Prevention Act?

Query: What is the strategy of KPMG Hazem Hassan?

https://arxiv.org/pdf/images/adbe49c71bb05e93ba1043d1c60f64fa6debd89e45f60c536c414803465d5c0f.jpg

Query: What is the trust signal score for the consumer industry best-in-class archetype?

https://arxiv.org/pdf/images/346df2ccef49c90eab7668c90dbca02d5f207f8c91880b4b9767e25c61c384aa.jpg

https://arxiv.org/pdf/images/d05ca9155dc858c869d56a125f9ebfcf2b158cb761d7e7acddc5f4f01f51b550.jpg

https://arxiv.org/pdf/images/73685f10f6769ee7ce32ed6752357e4d12e341abf7bd8c352f5decc74797d729.jpg

# Shift

Query: Selon le graphique, Query: Quelle partie de la proquelle est la capacit´e d’import et duction pe´trolie\`re du Kazakhstan la consommation r´eelle de carbu- provient de champs en mer ?

rants SAF (biocarburants durables pour l’aviation) pr´evues en 2050 ?

Query: Quels sont les pays ayant la plus grande part des d´ecouvertes cumul´ees de p´etrole brut en 2020 (en milliers de barils, hors d´ecouvertes cumule´es) ?

https://arxiv.org/pdf/images/58ff928d61e2c6526f0ab107700f7119a4d1e1524fab70beb3e26f175712cb60.jpg

https://arxiv.org/pdf/images/32a1b7a13ef9773e94478799bd2ca046af67fa42f07bd30746fe0e962ef4e9dd.jpg

https://arxiv.org/pdf/images/2289f86f67ae91ed3003029d330ee9e6b6ec529bfa838ea82ced746417f7b1f1.jpg

</details>

<details>
<summary>image-understanding-gemini-api-google-ai-for-developers</summary>

# Image understanding

Gemini models are built to be multimodal from the ground up, unlocking a wide range of image processing and computer vision tasks including but not limited to image captioning, classification, and visual question answering without having to train specialized ML models.

## Passing images to Gemini

You can provide images as input to Gemini using two methods:

- Passing inline image data: Ideal for smaller files (total request size less than 20MB, including prompts).
- Uploading images using the File API: Recommended for larger files or for reusing images across multiple requests.

### Passing inline image data

You can pass inline image data in the request to `generateContent`. You can provide image data as Base64 encoded strings or by reading local files directly (depending on the language).

The following example shows how to read an image from a local file and pass it to `generateContent` API for processing.

```python
from google.genai import types

with open('path/to/small-sample.jpg', 'rb') as f:
    image_bytes = f.read()

response = client.models.generate_content(
  model='gemini-2.5-flash',
  contents=[\
    types.Part.from_bytes(\
      data=image_bytes,\
      mime_type='image/jpeg',\
    ),\
    'Caption this image.'\
  ]
)

print(response.text)
```

```javascript
import { GoogleGenAI } from "@google/genai";
import * as fs from "node:fs";

const ai = new GoogleGenAI({});
const base64ImageFile = fs.readFileSync("path/to/small-sample.jpg", {
  encoding: "base64",
});

const contents = [\
  {\
    inlineData: {\
      mimeType: "image/jpeg",\
      data: base64ImageFile,\
    },\
  },\
  { text: "Caption this image." },\
];

const response = await ai.models.generateContent({
  model: "gemini-2.5-flash",
  contents: contents,
});
console.log(response.text);
```

```go
bytes, _ := os.ReadFile("path/to/small-sample.jpg")

parts := []*genai.Part{
  genai.NewPartFromBytes(bytes, "image/jpeg"),
  genai.NewPartFromText("Caption this image."),
}

contents := []*genai.Content{
  genai.NewContentFromParts(parts, genai.RoleUser),
}

result, _ := client.Models.GenerateContent(
  ctx,
  "gemini-2.5-flash",
  contents,
  nil,
)

fmt.Println(result.Text())
```

You can also fetch an image from a URL, convert it to bytes, and pass it to `generateContent` as shown in the following examples.

```python
from google import genai
from google.genai import types

import requests

image_path = "https://goo.gle/instrument-img"
image_bytes = requests.get(image_path).content
image = types.Part.from_bytes(
  data=image_bytes, mime_type="image/jpeg"
)

client = genai.Client()

response = client.models.generate_content(
    model="gemini-2.5-flash",
    contents=["What is this image?", image],
)

print(response.text)
```

```javascript
import { GoogleGenAI } from "@google/genai";

async function main() {
  const ai = new GoogleGenAI({});

  const imageUrl = "https://goo.gle/instrument-img";

  const response = await fetch(imageUrl);
  const imageArrayBuffer = await response.arrayBuffer();
  const base64ImageData = Buffer.from(imageArrayBuffer).toString('base64');

  const result = await ai.models.generateContent({
    model: "gemini-2.5-flash",
    contents: [\
    {\
      inlineData: {\
        mimeType: 'image/jpeg',\
        data: base64ImageData,\
      },\
    },\
    { text: "Caption this image." }\
  ],
  });
  console.log(result.text);
}

main();
```

```go
package main

import (
  "context"
  "fmt"
  "os"
  "io"
  "net/http"
  "google.golang.org/genai"
)

func main() {
  ctx := context.Background()
  client, err := genai.NewClient(ctx, nil)
  if err != nil {
      log.Fatal(err)
  }

  // Download the image.
  imageResp, _ := http.Get("https://goo.gle/instrument-img")

  imageBytes, _ := io.ReadAll(imageResp.Body)

  parts := []*genai.Part{
    genai.NewPartFromBytes(imageBytes, "image/jpeg"),
    genai.NewPartFromText("Caption this image."),
  }

  contents := []*genai.Content{
    genai.NewContentFromParts(parts, genai.RoleUser),
  }

  result, _ := client.Models.GenerateContent(
    ctx,
    "gemini-2.5-flash",
    contents,
    nil,
  )

  fmt.Println(result.Text())
}
```

### Uploading images using the File API

For large files or to be able to use the same image file repeatedly, use the Files API. The following code uploads an image file and then uses the file in a call to `generateContent`. See the Files API guide for more information and examples.

```python
from google import genai

client = genai.Client()

my_file = client.files.upload(file="path/to/sample.jpg")

response = client.models.generate_content(
    model="gemini-2.5-flash",
    contents=[my_file, "Caption this image."],
)

print(response.text)
```

```javascript
import {
  GoogleGenAI,
  createUserContent,
  createPartFromUri,
} from "@google/genai";

const ai = new GoogleGenAI({});

async function main() {
  const myfile = await ai.files.upload({
    file: "path/to/sample.jpg",
    config: { mimeType: "image/jpeg" },
  });

  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash",
    contents: createUserContent([\
      createPartFromUri(myfile.uri, myfile.mimeType),\
      "Caption this image.",\
    ]),
  });
  console.log(response.text);
}

await main();
```

```go
package main

import (
  "context"
  "fmt"
  "os"
  "google.golang.org/genai"
)

func main() {
  ctx := context.Background()
  client, err := genai.NewClient(ctx, nil)
  if err != nil {
      log.Fatal(err)
  }

  uploadedFile, _ := client.Files.UploadFromPath(ctx, "path/to/sample.jpg", nil)

  parts := []*genai.Part{
      genai.NewPartFromText("Caption this image."),
      genai.NewPartFromURI(uploadedFile.URI, uploadedFile.MIMEType),
  }

  contents := []*genai.Content{
      genai.NewContentFromParts(parts, genai.RoleUser),
  }

  result, _ := client.Models.GenerateContent(
      ctx,
      "gemini-2.5-flash",
      contents,
      nil,
  )

  fmt.Println(result.Text())
}
```

```bash
IMAGE_PATH="path/to/sample.jpg"
MIME_TYPE=$(file -b --mime-type "${IMAGE_PATH}")
NUM_BYTES=$(wc -c < "${IMAGE_PATH}")
DISPLAY_NAME=IMAGE

tmp_header_file=upload-header.tmp

# Initial resumable request defining metadata.
# The upload url is in the response headers dump them to a file.
curl "https://generativelanguage.googleapis.com/upload/v1beta/files" \
  -H "x-goog-api-key: $GEMINI_API_KEY" \
  -D upload-header.tmp \
  -H "X-Goog-Upload-Protocol: resumable" \
  -H "X-Goog-Upload-Command: start" \
  -H "X-Goog-Upload-Header-Content-Length: ${NUM_BYTES}" \
  -H "X-Goog-Upload-Header-Content-Type: ${MIME_TYPE}" \
  -H "Content-Type: application/json" \
  -d "{'file': {'display_name': '${DISPLAY_NAME}'}}" 2> /dev/null

upload_url=$(grep -i "x-goog-upload-url: " "${tmp_header_file}" | cut -d" " -f2 | tr -d "\r")
rm "${tmp_header_file}"

# Upload the actual bytes.
curl "${upload_url}" \
  -H "x-goog-api-key: $GEMINI_API_KEY" \
  -H "Content-Length: ${NUM_BYTES}" \
  -H "X-Goog-Upload-Offset: 0" \
  -H "X-Goog-Upload-Command: upload, finalize" \
  --data-binary "@${IMAGE_PATH}" 2> /dev/null > file_info.json

file_uri=$(jq -r ".file.uri" file_info.json)
echo file_uri=$file_uri

# Now generate content using that file
curl "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent" \
    -H "x-goog-api-key: $GEMINI_API_KEY" \
    -H 'Content-Type: application/json' \
    -X POST \
    -d '{
      "contents": [{\
        "parts":[\
          {"file_data":{"mime_type": "'"${MIME_TYPE}"'", "file_uri": "'"${file_uri}"'"}},\
          {"text": "Caption this image."}]\
        }]
      }' 2> /dev/null > response.json

cat response.json
echo

jq ".candidates[].content.parts[].text" response.json
```

## Prompting with multiple images

You can provide multiple images in a single prompt by including multiple image `Part` objects in the `contents` array. These can be a mix of inline data (local files or URLs) and File API references.

```python
from google import genai
from google.genai import types

client = genai.Client()

# Upload the first image
image1_path = "path/to/image1.jpg"
uploaded_file = client.files.upload(file=image1_path)

# Prepare the second image as inline data
image2_path = "path/to/image2.png"
with open(image2_path, 'rb') as f:
    img2_bytes = f.read()

# Create the prompt with text and multiple images
response = client.models.generate_content(

    model="gemini-2.5-flash",
    contents=[\
        "What is different between these two images?",\
        uploaded_file,  # Use the uploaded file reference\
        types.Part.from_bytes(\
            data=img2_bytes,\
            mime_type='image/png'\
        )\
    ]
)

print(response.text)
```

```javascript
import {
  GoogleGenAI,
  createUserContent,
  createPartFromUri,
} from "@google/genai";
import * as fs from "node:fs";

const ai = new GoogleGenAI({});

async function main() {
  // Upload the first image
  const image1_path = "path/to/image1.jpg";
  const uploadedFile = await ai.files.upload({
    file: image1_path,
    config: { mimeType: "image/jpeg" },
  });

  // Prepare the second image as inline data
  const image2_path = "path/to/image2.png";
  const base64Image2File = fs.readFileSync(image2_path, {
    encoding: "base64",
  });

  // Create the prompt with text and multiple images

  const response = await ai.models.generateContent({

    model: "gemini-2.5-flash",
    contents: createUserContent([\
      "What is different between these two images?",\
      createPartFromUri(uploadedFile.uri, uploadedFile.mimeType),\
      {\
        inlineData: {\
          mimeType: "image/png",\
          data: base64Image2File,\
        },\
      },\
    ]),
  });
  console.log(response.text);
}

await main();
```

```go
// Upload the first image
image1Path := "path/to/image1.jpg"
uploadedFile, _ := client.Files.UploadFromPath(ctx, image1Path, nil)

// Prepare the second image as inline data
image2Path := "path/to/image2.jpeg"
imgBytes, _ := os.ReadFile(image2Path)

parts := []*genai.Part{
  genai.NewPartFromText("What is different between these two images?"),
  genai.NewPartFromBytes(imgBytes, "image/jpeg"),
  genai.NewPartFromURI(uploadedFile.URI, uploadedFile.MIMEType),
}

contents := []*genai.Content{
  genai.NewContentFromParts(parts, genai.RoleUser),
}

result, _ := client.Models.GenerateContent(
  ctx,
  "gemini-2.5-flash",
  contents,
  nil,
)

fmt.Println(result.Text())
```

```bash
# Upload the first image
IMAGE1_PATH="path/to/image1.jpg"
MIME1_TYPE=$(file -b --mime-type "${IMAGE1_PATH}")
NUM1_BYTES=$(wc -c < "${IMAGE1_PATH}")
DISPLAY_NAME1=IMAGE1

tmp_header_file1=upload-header1.tmp

curl "https://generativelanguage.googleapis.com/upload/v1beta/files" \
  -H "x-goog-api-key: $GEMINI_API_KEY" \
  -D upload-header1.tmp \
  -H "X-Goog-Upload-Protocol: resumable" \
  -H "X-Goog-Upload-Command: start" \
  -H "X-Goog-Upload-Header-Content-Length: ${NUM1_BYTES}" \
  -H "X-Goog-Upload-Header-Content-Type: ${MIME1_TYPE}" \
  -H "Content-Type: application/json" \
  -d "{'file': {'display_name': '${DISPLAY_NAME1}'}}" 2> /dev/null

upload_url1=$(grep -i "x-goog-upload-url: " "${tmp_header_file1}" | cut -d" " -f2 | tr -d "\r")
rm "${tmp_header_file1}"

curl "${upload_url1}" \
  -H "Content-Length: ${NUM1_BYTES}" \
  -H "X-Goog-Upload-Offset: 0" \
  -H "X-Goog-Upload-Command: upload, finalize" \
  --data-binary "@${IMAGE1_PATH}" 2> /dev/null > file_info1.json

file1_uri=$(jq ".file.uri" file_info1.json)
echo file1_uri=$file1_uri

# Prepare the second image (inline)
IMAGE2_PATH="path/to/image2.png"
MIME2_TYPE=$(file -b --mime-type "${IMAGE2_PATH}")

if [[ "$(base64 --version 2>&1)" = *"FreeBSD"* ]]; then
  B64FLAGS="--input"
else
  B64FLAGS="-w0"
fi
IMAGE2_BASE64=$(base64 $B64FLAGS $IMAGE2_PATH)

# Now generate content using both images
curl "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent" \
    -H "x-goog-api-key: $GEMINI_API_KEY" \
    -H 'Content-Type: application/json' \
    -X POST \
    -d '{
      "contents": [{\
        "parts":[\
          {"text": "What is different between these two images?"},\
          {"file_data":{"mime_type": "'"${MIME1_TYPE}"'", "file_uri": '$file1_uri'}},\
          {\
            "inline_data": {\
              "mime_type":"'"${MIME2_TYPE}"'",\
              "data": "'"$IMAGE2_BASE64"'"\
            }\
          }\
        ]\
      }]
    }' 2> /dev/null > response.json

cat response.json
echo

jq ".candidates[].content.parts[].text" response.json
```

## Object detection

From Gemini 2.0 onwards, models are further trained to detect objects in an image and get their bounding box coordinates. The coordinates, relative to image dimensions, scale to [0, 1000]. You need to descale these coordinates based on your original image size.

```python
from google import genai
from google.genai import types
from PIL import Image
import json

client = genai.Client()
prompt = "Detect the all of the prominent items in the image. The box_2d should be [ymin, xmin, ymax, xmax] normalized to 0-1000."

image = Image.open("/path/to/image.png")

config = types.GenerateContentConfig(
  response_mime_type="application/json"
  )

response = client.models.generate_content(model="gemini-2.5-flash",
                                          contents=[image, prompt],
                                          config=config
                                          )

width, height = image.size
bounding_boxes = json.loads(response.text)

converted_bounding_boxes = []
for bounding_box in bounding_boxes:
    abs_y1 = int(bounding_box["box_2d"][0]/1000 * height)
    abs_x1 = int(bounding_box["box_2d"][1]/1000 * width)
    abs_y2 = int(bounding_box["box_2d"][2]/1000 * height)
    abs_x2 = int(bounding_box["box_2d"][3]/1000 * width)
    converted_bounding_boxes.append([abs_x1, abs_y1, abs_x2, abs_y2])

print("Image size: ", width, height)
print("Bounding boxes:", converted_bounding_boxes)
```

For more examples, check following notebooks in the Gemini Cookbook:

- 2D spatial understanding notebook
- Experimental 3D pointing notebook

## Segmentation

Starting with Gemini 2.5, models not only detect items but also segment them and provide their contour masks.

The model predicts a JSON list, where each item represents a segmentation mask. Each item has a bounding box (" `box_2d`") in the format `[y0, x0, y1, x1]` with normalized coordinates between 0 and 1000, a label (" `label`") that identifies the object, and finally the segmentation mask inside the bounding box, as base64 encoded png that is a probability map with values between 0 and 255. The mask needs to be resized to match the bounding box dimensions, then binarized at your confidence threshold (127 for the midpoint).

```python
from google import genai
from google.genai import types
from PIL import Image, ImageDraw
import io
import base64
import json
import numpy as np
import os

client = genai.Client()

def parse_json(json_output: str):
  # Parsing out the markdown fencing
  lines = json_output.splitlines()
  for i, line in enumerate(lines):
    if line == "```json":
      json_output = "\n".join(lines[i+1:])  # Remove everything before "```json"
      output = json_output.split("```")[0]  # Remove everything after the closing "```"
      break  # Exit the loop once "```json" is found
  return json_output

def extract_segmentation_masks(image_path: str, output_dir: str = "segmentation_outputs"):
  # Load and resize image
  im = Image.open(image_path)
  im.thumbnail([1024, 1024], Image.Resampling.LANCZOS)

  prompt = """
  Give the segmentation masks for the wooden and glass items.
  Output a JSON list of segmentation masks where each entry contains the 2D
  bounding box in the key "box_2d", the segmentation mask in key "mask", and
  the text label in the key "label". Use descriptive labels.
  """

  config = types.GenerateContentConfig(
    thinking_config=types.ThinkingConfig(thinking_budget=0) # set thinking_budget to 0 for better results in object detection
  )

  response = client.models.generate_content(
    model="gemini-2.5-flash",
    contents=[prompt, im], # Pillow images can be directly passed as inputs (which will be converted by the SDK)
    config=config
  )

  # Parse JSON response
  items = json.loads(parse_json(response.text))

  # Create output directory
  os.makedirs(output_dir, exist_ok=True)

  # Process each mask
  for i, item in enumerate(items):
      # Get bounding box coordinates
      box = item["box_2d"]
      y0 = int(box[0] / 1000 * im.size[1])
      x0 = int(box[1] / 1000 * im.size[0])
      y1 = int(box[2] / 1000 * im.size[1])
      x1 = int(box[3] / 1000 * im.size[0])

      # Skip invalid boxes
      if y0 >= y1 or x0 >= x1:
          continue

      # Process mask
      png_str = item["mask"]
      if not png_str.startswith("data:image/png;base64,"):
          continue

      # Remove prefix
      png_str = png_str.removeprefix("data:image/png;base64,")
      mask_data = base64.b64decode(png_str)
      mask = Image.open(io.BytesIO(mask_data))

      # Resize mask to match bounding box
      mask = mask.resize((x1 - x0, y1 - y0), Image.Resampling.BILINEAR)

      # Convert mask to numpy array for processing
      mask_array = np.array(mask)

      # Create overlay for this mask
      overlay = Image.new('RGBA', im.size, (0, 0, 0, 0))
      overlay_draw = ImageDraw.Draw(overlay)

      # Create overlay for the mask
      color = (255, 255, 255, 200)
      for y in range(y0, y1):
          for x in range(x0, x1):
              if mask_array[y - y0, x - x0] > 128:  # Threshold for mask
                  overlay_draw.point((x, y), fill=color)

      # Save individual mask and its overlay
      mask_filename = f"{item['label']}_{i}_mask.png"
      overlay_filename = f"{item['label']}_{i}_overlay.png"

      mask.save(os.path.join(output_dir, mask_filename))

      # Create and save overlay
      composite = Image.alpha_composite(im.convert('RGBA'), overlay)
      composite.save(os.path.join(output_dir, overlay_filename))
      print(f"Saved mask and overlay for {item['label']} to {output_dir}")

# Example usage
if __name__ == "__main__":
  extract_segmentation_masks("path/to/image.png")
```

https://ai.google.dev/static/gemini-api/docs/images/segmentation.jpg
An example segmentation output with objects and segmentation masks

## Supported image formats

Gemini supports the following image format MIME types:

- PNG - `image/png`
- JPEG - `image/jpeg`
- WEBP - `image/webp`
- HEIC - `image/heic`
- HEIF - `image/heif`

## Capabilities

All Gemini model versions are multimodal and can be utilized in a wide range of image processing and computer vision tasks including but not limited to image captioning, visual question and answering, image classification, object detection and segmentation.

Gemini can reduce the need to use specialized ML models depending on your quality and performance requirements.

Some later model versions are specifically trained improve accuracy of specialized tasks in addition to generic capabilities:

- **Gemini 2.0 models** are further trained to support enhanced object detection.
- **Gemini 2.5 models** are further trained to support enhanced segmentation in addition to object detection.

## Limitations and key technical information

### File limit

Gemini 2.5 Pro/Flash, 2.0 Flash, 1.5 Pro, and 1.5 Flash support a maximum of 3,600 image files per request.

### Token calculation

- **Gemini 1.5 Flash and Gemini 1.5 Pro**: 258 tokens if both dimensions <= 384 pixels. Larger images are tiled (min tile 256px, max 768px, resized to 768x768), with each tile costing 258 tokens.
- **Gemini 2.0 Flash and Gemini 2.5 Flash/Pro**: 258 tokens if both dimensions <= 384 pixels. Larger images are tiled into 768x768 pixel tiles, each costing 258 tokens.

## Tips and best practices

- Verify that images are correctly rotated.
- Use clear, non-blurry images.
- When using a single image with text, place the text prompt after the image part in the `contents` array.

## What's next

This guide shows you how to upload image files and generate text outputs from image inputs. To learn more, see the following resources:

- Files API: Learn more about uploading and managing files for use with Gemini.
- System instructions: System instructions let you steer the behavior of the model based on your specific needs and use cases.
- File prompting strategies: The Gemini API supports prompting with text, image, audio, and video data, also known as multimodal prompting.
- Safety guidance: Sometimes generative AI models produce unexpected outputs, such as outputs that are inaccurate, biased, or offensive. Post-processing and human evaluation are essential to limit the risk of harm from such outputs.

</details>

<details>
<summary>multi-modal-ml-with-openai-s-clip-pinecone</summary>

# Multi-modal ML with OpenAI's CLIP

* * *

Language models (LMs) can not rely on language alone. That is the idea behind the “Experience Grounds Language” paper, that proposes a framework to measure LMs' current and future progress. A key idea is that, beyond a certain threshold LMs need other forms of data, such as visual input \[1\] \[2\].

https://www.pinecone.io/_next/image/?url=https%3A%2F%2Fcdn.sanity.io%2Fimages%2Fvr8gru94%2Fproduction%2F25e7f2f54b543af8c34c143448a4b0c55f77c6b5-2360x854.png&w=3840&q=75

World Scopes (WS), as datasets become larger in scope and span multiple modalities, the capabilities of models trained with them increase.

The next step beyond well-known language models; BERT, GPT-3, and T5 is _”World Scope 3”_. In World Scope 3, we move from large text-only datasets to large multi-modal datasets. That is, datasets containing information from multiple forms of media, like _both_ images and text.

The world, both digital and real, is multi-modal. We perceive the world as an orchestra of language, imagery, video, smell, touch, and more. This chaotic ensemble produces an inner state, our “model” of the outside world.

AI must move in the same direction. Even specialist models that focus on language or vision must, at some point, have input from the other modalities. How can a model fully understand the concept of the word “person” without _seeing_ a person?

OpenAI **C** ontrastive **L** earning **I** n **P** retraining (CLIP) is a world scope three model. It can comprehend concepts in both text and image and even connect concepts between the two modalities. In this chapter we will learn about multi-modality, how CLIP works, and how to use CLIP for different use cases like encoding, classification, and object detection.

* * *

## Multi-modality

The multi-modal nature of CLIP is powered by two encoder models trained to “speak the same language”. Text inputs are passed to a text encoder, and image inputs to an image encoder \[3\]. These models then create a _vector representation_ of the respective input.

Both models “speak the same language” by encoding similar concepts in text and images into similar vectors. That means that the text “two dogs running across a frosty field” would output a vector similar to an _image_ of two dogs running across a frosty field.

https://www.pinecone.io/_next/image/?url=https%3A%2F%2Fcdn.sanity.io%2Fimages%2Fvr8gru94%2Fproduction%2Fa54a2f1fa0aeac03748c09df0fdfbb42aadc96b7-2430x1278.png&w=3840&q=75

Similar text and images will be encoded into a similar vector space. Dissimilar text and images do not share a similar vector space.

We can think of the language these models speak as the vector space in which they encode vectors. These two models can express nuanced information about text and images through this vector space. However, this “vector language” is far too abstract for us to directly understand.

Rather than directly reading this “language”, we can train other simple neural networks to understand it and make predictions that we can understand. Or we use vector search to identify similar concepts and patterns across text and image domains.

Let’s take a look at an example of CLIP in action.

### Text-to-Image Search

Entering a prompt in the search bar above allows us to search through images based on their _content_ rather than any attached textual metadata. We call this **C** ontent **B** ased **I** mage **R** etrieval (CBIR).

With CBIR, we can search for specific phrases such as “two dogs running across a frosty field”. We can even drop the word “dogs” and replace it with everyday slang for dogs like “good boy” or “mans best friend”, and we return the same images showing dogs running across fields.

CLIP can accurately understand language. It understands that _in the context_ of running across a field, we are likely referring to dogs and do not literally mean good children or someone’s “human” best friend.

Amusingly, the dataset contains no images of the food hot dogs (other than one). So, suppose we search for “hot dogs”. In that case, we first get an image containing a hot dog (and a dog), a dog looking toasty in a warm room, another dog looking warm with wooly clothing, and another dog posing for the camera. All of these portray a hot dog in one sense or another.

* * *

_After being processed by CLIP’s text or image encoder, we are left with vectors. That means we can search across_ **_any_** _modality with_ **_any_** _modality; we can search in either direction. We can also stick to a single modality, like text-to-text or image-to-image._

* * *

Now that we’ve seen what CLIP can do, let’s take a look at _how_ it can do this.

## CLIP

CLIP actually consists of two models trained in parallel. A 12-layer text transformer for building text embeddings and a ResNet or vision transformer (ViT) for building image embeddings \[3\].

https://www.pinecone.io/_next/image/?url=https%3A%2F%2Fcdn.sanity.io%2Fimages%2Fvr8gru94%2Fproduction%2F539716ea1571e459908c1fdc5a898fea239d8243-2803x1672.png&w=3840&q=75

Architecture diagram of CLIP with the text encoder and ViT or ResNet as the image encoder.

The text encoder and image encoder (ResNet _or_ ViT) output single vector embeddings for each text/image record fed into the encoders. All vectors are 512 dimensional and can be represented in the same vector space, meaning similar images and text produce vectors that appear near each other.

### Contrastive Pretraining

Across both [**N** atural](https://www.pinecone.io/learn/series/nlp/) [**L** anguage](https://www.pinecone.io/learn/series/nlp/) [**P** rocessing (NLP)](https://www.pinecone.io/learn/series/nlp/) and computer vision (CV), large pretrained models dominate the SotA. The idea is that by giving a big model a lot of data, they can learn general patterns from the dataset.

For language models, that may be the general rules and patterns in the English language. For vision models, that may be the characteristics of different scenes or objects.

The problem with multi-modality is that these models are trained separately and, by default, have no understanding of one another. CLIP solves this thanks to image-text _contrastive pretraining_. With CLIP, text and image encoders are trained while considering the other modality and context. Meaning that the text and image encoders share an “indirect understanding” of patterns in both modalities; language and vision.

Contrastive pretraining works by taking a _(text, image)_ pair – where the text describes the image – and learning to encode the pairs as closely as possible in vector space.

For this to work well, we also need negative pairs to provide a contrastive comparison. We need positive pairs that should output similar vectors and negative pairs that should output dissimilar vectors.

This is the general idea behind contrastive learning, which can be found in the training functions of many models, particularly those that produce embedding vectors.

The negative pairs can be extracted directly from positive pairs. If we have positive pairs  and , we simply swap the components, giving us the negative pairs  and .

With this, we can apply a loss function that maximizes the similarity between  and , and minimizes the similarity between  and . Altogether, this looks like this:

https://www.pinecone.io/_next/image/?url=https%3A%2F%2Fcdn.sanity.io%2Fimages%2Fvr8gru94%2Fproduction%2Fd6868e6dae721512fed8f1287fc9ffe6b6a2cddd-2332x1342.png&w=3840&q=75

Contrastive pretraining with CLIP.

In this image, we can see a single pretraining step on a single batch. The loss function assumes pairs in the diagonal should have a maximized dot product score, and all other pairs should have a minimized dot product score. Both text and image encoder models are optimized for this.

A fundamental assumption is that there are no other positive pairs within a single batch. For example, we assume that “two dogs running across a frosty field” is only relevant to the image it is paired with. We assume there are no other texts or images with similar meanings.

This assumption is possible because the datasets used for pretraining are diverse and large enough that the likelihood of two similar pairs appearing in a single batch is negligible. Therefore, rare enough to have a little-to-no negative impact on pretraining performance.

## Using CLIP

We have a good idea of what CLIP can be used for and how it is trained. With that, how can we get started with it?

OpenAI released a few implementations of CLIP via the Hugging Face library; this is the fastest way to get started. First, we need to install the necessary libraries.

`pip install transformers torch datasets`

Before we can do anything with CLIP, we need some text and images. The `jamescalam/image-text-demo` dataset contains a small number of image-text pairs we can use in our examples.

```python
from datasets import load_dataset

data = load_dataset(
    "jamescalam/image-text-demo",
    split="train"
)
```

https://www.pinecone.io/_next/image/?url=https%3A%2F%2Fcdn.sanity.io%2Fimages%2Fvr8gru94%2Fproduction%2Fa40f673ed52e07f497c7a39b032c27b33ce9f565-1128x761.png&w=3840&q=75

Example of text-image pair found in the dataset. Text is stored in the "text" feature and images in the "image" feature.

With these sample records ready, we can move on to initializing CLIP and an image/text preprocessor like so:

```python
from transformers import CLIPProcessor, CLIPModel
import torch

model_id = "openai/clip-vit-base-patch32"

processor = CLIPProcessor.from_pretrained(model_id)
model = CLIPModel.from_pretrained(model_id)

# move model to device if possible
device = 'cuda' if torch.cuda.is_available() else 'cpu'

model.to(device)
```

The `model` is CLIP itself. Note that we use the ViT image encoder (the model is `clip-vit`). Text and image data cannot be fed directly into CLIP. The text must be preprocessed to create “tokens IDs”, and images must be resized and normalized. The `processor` handles both of these functions.

### Encoding Text

We will start with encoding text using the CLIP text transformer. Before feeding text into CLIP, it must be preprocessed and converted into token IDs. Let’s take a batch of sentences from the `unsplash` data and encode them.

In\[5\]:

```python
text = data['text']  # 21

tokens = processor(
    text=text,
    padding=True,
    images=None,
    return_tensors='pt'
).to(device)
tokens.keys()
```

Out\[5\]:

```
dict_keys(['input_ids', 'attention_mask'])
```

This returns the typical text transformer inputs of `input_ids` and `attention_mask`.

The `input_ids` are token ID values where each token ID is an integer value ID that maps to a specific word or sub-word. For example the phrase _“multi-modality”_ may be split into tokens _\[“multi”, “-”, “modal”, “ity”\]_, which are then mapped to IDs _\[1021, 110, 2427, 425\]_.

A text transformer maps these token IDs to semantic vector embeddings that the model learned during pretraining.

The `attention_mask` is a tensor of 1s and 0s used by the model’s internal mechanisms to “pay attention” to real token IDs and ignore padding tokens.

* * *

_Padding tokens are a special type of token used by text transformers to create input sequences of a fixed length from sentences of varying length. They are appended to the end of shorter sentences, so “hello world” may become “hello world \[PAD\] \[PAD\] \[PAD\]”._

* * *

We then use CLIP to encode all of these text descriptions with `get_text_features` like so:

```python
text_emb = model.get_text_features(
    **tokens
)
```

One important thing to note here is that these embeddings are _not_ normalized. If we plan on using a similarity metric like the dot product, we must normalize the embeddings:

In\[9\]:

```python
print(text_emb.shape)
print(text_emb.min(), text_emb.max())
```

Out\[9\]:

```
torch.Size([21, 512])
tensor(-1.1893, grad_fn=<MinBackward1>) tensor(4.8015, grad_fn=<MaxBackward1>)
```

In\[40\]:

```python
# IF using dot product similarity, must normalize vectors like so...
import numpy as np

# detach text emb from graph, move to CPU, and convert to numpy array
text_emb = text_emb.detach().cpu().numpy()

# calculate value to normalize each vector by
norm_factor = np.linalg.norm(text_emb, axis=1)
norm_factor.shape
```

Out\[40\]:

```
(21,)
```

In\[41\]:

```python
text_emb = text_emb.T / norm_factor
# transpose back to (21, 512)
text_emb = text_emb.T
print(text_emb.shape)
print(text_emb.min(), text_emb.max())
```

Out\[41\]:

```
(21, 512)
-0.1526844 0.53449875
```

Alternatively, we can use cosine similarity as our metric as this only considers angular similarity and not vector magnitude (like dot product). For our examples, we will normalize and use dot product similarity.

We now have our text embeddings; let’s see how to do the same for images.

### Encoding Images

Images will be encoded using the ViT portion of CLIP. Similar to text encoding, we need to preprocess these images using the `preprocessor` like so:

In\[42\]:

```python
data['image'][0].size
```

Out\[42\]:

```
(6000, 3376)
```

In\[43\]:

```python
image_batch = data['image']

images = processor(
    text=None,
    images=image_batch,
    return_tensors='pt'
)['pixel_values'].to(device)
images.shape
```

Out\[43\]:

```
torch.Size([21, 3, 224, 224])
```

Preprocessing images does _not_ produce token IDs like those we saw from preprocessing our text. Instead, preprocessing images consists of resizing the image to a 244x244 array with three color channels (red, green, and blue) and normalizing pixel values into a \[0,1\]\[0,1\] range.

After preprocessing our images, we get the image features with `get_image_features` and normalize them as before:

In\[44\]:

```python
img_emb = model.get_image_features(images)
print(img_emb.shape)
print(img_emb.min(), img_emb.max())
```

Out\[44\]:

```
torch.Size([21, 512])
tensor(-8.6533, grad_fn=<MinBackward1>) tensor(2.6551, grad_fn=<MaxBackward1>)
```

In\[45\]:

```python
# NORMALIZE
# detach text emb from graph, move to CPU, and convert to numpy array
img_emb = img_emb.detach().cpu().numpy()

img_emb = img_emb.T / np.linalg.norm(img_emb, axis=1)
# transpose back to (21, 512)
img_emb = img_emb.T
print(img_emb.shape)
print(img_emb.min(), img_emb.max())
```

Out\[45\]:

```
(21, 512)
-0.7275361 0.23383287
```

With this, we have created CLIP embeddings for both text and images. We can move on to comparing items across the two modalities.

### Calculating Similarity

CLIP embedding similarities are represented by their angular similarity. Meaning we can identify similar pairs using cosine similarity:

Or, if we have normalized the embeddings, we can use dot product similarity:

Let’s try both. First, for cosine similarity, we do:

In\[46\]:

```python
from numpy.linalg import norm

cos_sim = np.dot(text_emb, img_emb.T) / (
    norm(text_emb, axis=1) * norm(img_emb, axis=1)
)
cos_sim.shape
```

Out\[46\]:

```
(21, 21)
```

In\[47\]:

```python
import matplotlib.pyplot as plt

plt.imshow(cos_sim)
plt.show()
```

Out\[47\]:

```
<Figure size 432x288 with 1 Axes>
```

And if we perform the same operation for dot product similarity, we should return the same results:

In\[48\]:

```python
dot_sim = np.dot(text_emb, img_emb.T)

plt.imshow(cos_sim)
plt.show()
```

Out\[48\]:

```
<Figure size 432x288 with 1 Axes>
```

Both of these similarity score arrays look the same, and if we check for the difference between the two arrays, we will see that the scores are the same. We see some slight differences due to floating point errors.

In\[51\]:

```python
diff = cos_sim - dot_sim
diff.min(), diff.max()
```

Out\[51\]:

```
(0.0, 2.9802322e-08)
```

Using the embedding functions of CLIP in this way, we can perform a semantic search across the modalities of text and image in any direction. We can search for images with text, text with images, text with text, and images with images.

These use cases are great, but we can make slight modifications to this for many other tasks.

### Classification

One of the most impressive demonstrations of CLIP is its unparalleled zero-shot performance on various tasks. For example, given the `fragment/imagenette` dataset from Hugging Face _Datasets_, we can write a list of brief sentences that align with the ten class labels.

https://www.pinecone.io/_next/image/?url=https%3A%2F%2Fcdn.sanity.io%2Fimages%2Fvr8gru94%2Fproduction%2Ff841984e7617686f5041ca95797498e2b0b085b5-1348x542.png&w=3840&q=75

We take the original imagenette labels and preappend "a photo of a ..." to each to create a set of CLIP-friendly sentence representations.

From this, we can calculate the cosine similarity between the text embeddings of these ten labels against an image we’d like to classify. The text that returns the highest similarity is our predicted class.

### Object Detection

Another compelling use case of zero-shot CLIP is object detection. We can do this by splitting our images into smaller patches and running each patch through the image encoder of CLIP. We then compare these patch embeddings to a text encoding describing what we are looking for. After calculating the similarity scores for all patches, we can collate them into a map of relevance.

For example, given an image of a butterfly and a cat, we could break it into many small patches. Given the prompt `"a fluffy cat"`, we will return an outline of the cat, whereas the prompt `"a butterfly"` will produce an outline of the butterfly.

https://www.pinecone.io/_next/image/?url=https%3A%2F%2Fcdn.sanity.io%2Fimages%2Fvr8gru94%2Fproduction%2Fbe4800918976efd9d974d9e5453985a5106f2558-2389x1455.png&w=3840&q=75

Zero-shot object detection with CLIP allows us to find specific objects with natural language prompts.

These are only a few of the use cases of CLIP and only scratch the surface of what is possible with this model and others in the scope of multi-modal ML.

* * *

That’s it for this introduction to multi-modal ML with OpenAI’s CLIP. The past years since the CLIP release have seen ever more fascinating applications of the model.

DALL-E 2 is a well-known example of CLIP. The incredible images generated by DALL-E 2 start by embedding the user’s text prompt with CLIP \[4\]. That text embedding is then passed to the diffusion model, which generates some mind-blowing images.

The fields of NLP and CV have mainly progressed independently of each other for the past decade. However, with the introduction of world scope three models, they’re becoming more entwined into a majestic multi-modal field of Machine Learning.

## Resources

\[1\] Y. Bisk et al., [Experience Grounds Language](https://arxiv.org/abs/2004.10151) (2020), EMNLP

\[2\] J. Alammar, [Experience Grounds Language: Improving language models beyond the world of text](https://www.youtube.com/watch?v=WQm7-X4gts4) (2022), YouTube

\[3\] A. Radford et al., [Learning Transferable Visual Models From Natural Language Supervision](https://arxiv.org/abs/2103.00020) (2021), arXiv

\[4\] A. Ramesh, P. Dhariwal, A. Nichol, C. Chu, M. Chen, [Hierarchical Text-Conditional Image Generation with CLIP Latents](https://arxiv.org/abs/2204.06125) (2022), arXiv

</details>

<details>
<summary>multimodal-embeddings-an-introduction-towards-data-science</summary>

# Multimodal Embeddings: An Introduction

Mapping text and images into a common space

Shaw Talebi

Nov 29, 2024

8 min read

This is the 2nd article in a [larger series](https://shawhin.medium.com/list/multimodal-ai-fe9521d0e77a) on multimodal AI. In the [previous post](https://towardsdatascience.com/multimodal-models-llms-that-can-see-and-hear-5c6737c981d3), we saw how to augment [large language models (LLMs)](https://shawhin.medium.com/list/large-language-models-llms-8e009ae3054c) to understand new data modalities (e.g., images, audio, video). One such approach relied on encoders that generate vector representations (i.e. embeddings) of non-text data. In this article, I will discuss _multimodal_ embeddings and share what they can do via two practical use cases.

https://towardsdatascience.com/wp-content/uploads/2024/11/1a6BF-kEeo8rd7OW2a3JYGA.pngImage from Canva.

---

AI research is traditionally split into distinct fields: NLP, computer vision (CV), robotics, human-computer interface (HCI), etc. However, countless practical tasks require the **integration of these different research areas** e.g. autonomous vehicles (CV + robotics), AI agents (NLP + CV + HCI), personalized learning (NLP + HCI), etc.

Although these fields aim to solve different problems and work with different data types, they all share a fundamental process. Namely, **generating useful numerical representations of real-world phenomena**.

Historically, this was done by hand. This means that researchers and practitioners would use their (or other people’s) expertise to explicitly transform data into a more helpful form. Today, however, _these can be derived another way_.

## **Embeddings**

**Embeddings** are **(useful) numerical representations of data learned implicitly through model training**. For example, through learning how to predict text, BERT learned representations of text, which are helpful for many NLP tasks \[1\]. Another example is the Vision Transformer (ViT), trained for image classification on Image Net, which can be repurposed for other applications \[2\].

A key point here is that these learned embedding spaces will have some underlying structure so that **similar concepts are located close together**. As shown in the toy examples below.

https://towardsdatascience.com/wp-content/uploads/2024/11/1jpmC6Kx7DxVeikEr15vooA.pngToy represetation of text and image embeddings, respectively. Image by author.

One **key limitation** of the previously mentioned models is they are restricted to a single data modality, e.g., text or images. Preventing cross-modal applications like image captioning, content moderation, image search, and more. _But what if we could merge these two representations?_

## **Multimodal Embeddings**

Although text and images may look very different to us, in a neural network, these are **represented via the same mathematical object**, i.e., a vector. Therefore, in principle, text, images, or any other data modality can processed by a single model.

This fact underlies **multimodal embeddings**, which **represent multiple data modalities in the same vector space** such that similar concepts are co-located (independent of their original representations).

https://towardsdatascience.com/wp-content/uploads/2024/11/15d3HBNjNIXLy0oMIvJjxWw.pngToy representation of multimodal embedding space. Image by author.

For example, CLIP encodes text and images into a shared embedding space \[3\]. A key insight from CLIP is that by aligning text and image representations, the **model is capable of 0-shot image classification on an arbitrary set of target classes** since any input text can be treated as a class label (we will see a concrete example of this later).

However, this idea is not limited to text and images. Virtually any data modalities can be aligned in this way e.g., text-audio, audio-image, text-EEG, image-tabular, and text-video. Unlocking use cases such as video captioning, advanced OCR, audio transcription, video search, and EEG-to-text \[4\].

## **Contrastive Learning**

The standard approach to aligning disparate embedding spaces is **contrastive learning (CL)**. A key intuition of CL is to **represent different views of the same _information_ similarly** \[5\].

This consists of learning representations that **maximize the similarity between positive pairs** and **minimize the similarity of negative pairs**. In the case of an image-text model, a positive pair might be an image with an appropriate caption, while a negative pair would be an image with an irrelevant caption (as shown below).

https://towardsdatascience.com/wp-content/uploads/2024/11/1AGHBVjzwjXapJSe4aUPrjg.pngExample positive and negative pairs used in contrastive training. Image by author.

**Two key aspects** **of CL** contribute to its effectiveness

1. Since positive and negative pairs can be curated from the data’s inherent structure (e.g., metadata from web images), CL training data **do not require manual labeling**, which unlocks larger-scale training and more powerful representations \[3\].
2. It simultaneously maximizes positive and minimizes negative pair similarity via a special loss function, as demonstrated by CLIP \[3\].

![CLIP's contrastive loss for text-image representation alignment [3]. Image by author.](https://towardsdatascience.com/wp-content/uploads/2024/11/12X1aT8fzFsgbqn23zXmmAA.png)CLIP’s contrastive loss for text-image representation alignment \[3\]. Image by author.

## **Example Code:** Using CLIP for 0-shot classification and image search

With a high-level understanding of how multimodal embeddings work, let’s see two concrete examples of what they can do. Here, I will use the open-source [CLIP model](https://huggingface.co/openai/clip-vit-base-patch16) to perform two tasks: 0-shot image classification and image search.

The **code for these examples** is freely available on the [GitHub repository](https://github.com/ShawhinT/YouTube-Blog/tree/main/multimodal-ai/2-mm-embeddings).

---

### Use case 1: 0-shot Image Classification

The basic idea behind using CLIP for 0-shot image classification is to pass an image into the model along with a set of possible class labels. Then, a classification can be made by **evaluating which text input is most similar to the input image**.

We’ll start by importing the [Hugging Face Transformers library](https://huggingface.co/docs/transformers/en/installation) so that the CLIP model can be downloaded locally. Additionally, the PIL library is used to load images in Python.

```python
from transformers import CLIPProcessor, CLIPModel
from PIL import Image
```

Next, we can import a version of the clip model and its associated data processor. _Note: the processor handles tokenizing input text and image preparation._

```ini
# import model
model = CLIPModel.from_pretrained("openai/clip-vit-base-patch16")

# import processor (handles text tokenization and image preprocessing)
processor = CLIPProcessor.from_pretrained("openai/clip-vit-base-patch16")
```

We load in the below image of a cat and create a list of two possible class labels: " _a photo of a cat_" or " _a photo of a dog_".

```ini
# load image
image = Image.open("images/cat_cute.png")

# define text classes
text_classes = ["a photo of a cat", "a photo of a dog"]
```

https://towardsdatascience.com/wp-content/uploads/2024/11/1Nzo536sqahqm1Q24Ms2vmA.pngInput cat photo. Image from Canva.

Next, we’ll preprocess the image/text inputs and pass them into the model.

```ini
# pass image and text classes to processor
inputs = processor(text=text_classes, images=image, return_tensors="pt",
                                                    padding=True)

# pass inputs to CLIP
outputs = model(**inputs) # note: "**" unpacks dictionary items
```

To make a class prediction, we must extract the image logits and evaluate which class corresponds to the maximum.

```makefile
# image-text similarity score
logits_per_image = outputs.logits_per_image
# convert scores to probs via softmax
probs = logits_per_image.softmax(dim=1)

# print prediction
predicted_class = text_classes[probs.argmax()]
print(predicted_class, "| Probability = ",
                       round(float(probs[0][probs.argmax()]),4))
```

``` language-none
>> a photo of a cat | Probability =  0.9979
```

The model nailed it with a 99.79% probability that it’s a cat photo. However, this was a super easy one. Let’s see what happens when we change the class labels to: " _ugly cat_" and " _cute cat_" for the same image.

``` language-none
>> cute cat | Probability =  0.9703
```

The model easily identified that the image was indeed a cute cat. Let’s do something more challenging like the labels: " _cat meme_" or " _not cat meme_".

``` language-none
>> not cat meme | Probability =  0.5464
```

While the model is less confident about this prediction with a 54.64% probability, it correctly implies that the image is not a meme.

### Use case 2: Image Search

Another application of CLIP is essentially the inverse of Use Case 1. Rather than identifying which text label matches an input image, we can evaluate **which image (in a set) best matches a text input (i.e. query)**—in other words, performing a search over images.

We start by storing a set of images in a list. Here, I have three images of a cat, dog, and goat, respectively.

```python
# create list of images to search over
image_name_list = ["images/cat_cute.png", "images/dog.png", "images/goat.png"]

image_list = []
for image_name in image_name_list:
    image_list.append(Image.open(image_name))
```

Next, we can define a query like " _a cute dog_" and pass it and the images into CLIP.

```python
# define a query
query = "a cute dog"

# pass images and query to CLIP
inputs = processor(text=query, images=image_list, return_tensors="pt",
                                                  padding=True)
```

We can then match the best image to the input text by extracting the text logits and evaluating the image corresponding to the maximum.

```python
# compute logits and probabilities
outputs = model(**inputs)
logits_per_text = outputs.logits_per_text
probs = logits_per_text.softmax(dim=1)

# print best match
best_match = image_list[probs.argmax()]
prob_match = round(float(probs[0][probs.argmax()]),4)

print("Match probability: ",prob_match)
display(best_match)
```

``` language-none
>> Match probability:  0.9817
```

https://towardsdatascience.com/wp-content/uploads/2024/11/14wnqr5p_7N3QD5EkXIQeew.pngBest match for query "a cute dog". Image from Canva.

We see that (again) the model nailed this simple example. But let’s try some trickier examples.

```python
query = "something cute but metal 🤘"
```

``` language-none
>> Match probability:  0.7715
```

https://towardsdatascience.com/wp-content/uploads/2024/11/1tIY3_ONQQT_cracAPWm8NQ.pngBest match for query "something cute but metal 🤘". Image from Canva.

```python
query = "a good boy"
```

``` language-none
>> Match probability:  0.8248
```

https://towardsdatascience.com/wp-content/uploads/2024/11/14wnqr5p_7N3QD5EkXIQeew.pngBest match for query "a good boy". Image from Canva.

```python
query = "the best pet in the world"
```

``` language-none
>> Match probability:  0.5664
```

https://towardsdatascience.com/wp-content/uploads/2024/11/1Nzo536sqahqm1Q24Ms2vmA.pngBest match for query "the best pet in the world". Image from Canva.

Although this last prediction is quite controversial, all the other matches were spot on! This is likely since images like these are ubiquitous on the internet and thus were seen many times in CLIP’s pre-training.

> [**YouTube-Blog/multimodal-ai/2-mm-embeddings at main · ShawhinT/YouTube-Blog**](https://github.com/ShawhinT/YouTube-Blog/tree/main/multimodal-ai/2-mm-embeddings)

## What’s Next?

Multimodal embeddings unlock countless AI use cases that involve multiple data modalities. Here, we saw two such use cases, i.e., 0-shot image classification and image search using CLIP.

Another practical application of models like CLIP is multimodal RAG, which consists of the automated retrieval of multimodal context to an LLM. In the [next article](https://medium.com/towards-data-science/multimodal-rag-process-any-file-type-with-ai-e6921342c903) of this [series](https://shawhin.medium.com/list/multimodal-ai-fe9521d0e77a), we will see how this works under the hood and review a concrete example.

---

**My website**: https://www.shawhintalebi.com/

- [BERT](https://arxiv.org/abs/1810.04805)
- [ViT](https://arxiv.org/abs/2010.11929)
- [CLIP](https://arxiv.org/abs/2103.00020)
- [Thought2Text: Text Generation from EEG Signal using Large Language Models (LLMs)](https://arxiv.org/abs/2410.07507)
- [A Simple Framework for Contrastive Learning of Visual Representations](https://arxiv.org/abs/2002.05709)

Written By

Shaw Talebi

</details>

<details>
<summary>multimodal-rag-with-colpali-milvus-and-vlms</summary>

# Multimodal RAG with Colpali, Milvus and VLMs

Community Article Published  
December 10, 2024

In this post, we will see how to doIn this post, we will see how to do multimodal RAG with [colpali](https://arxiv.org/abs/2407.01449), [milvus](https://milvus.io/) and a visual language model (gemini/gpt-4o).

We will build an application to upload a PDF and then do Q&A queries on it. Q&A can be done on both text and visual elements of the PDF. We will not extract text from the PDF; instead, we will treat it as an image and use colpali to get embeddings for the PDF pages. These embeddings will be indexed to Milvus, and then we will use a VLM to do Q&A queries on the PDF pages.

> If you just want to see the code in action, there is a demo at [https://huggingface.co/spaces/saumitras/colpali-milvus](https://huggingface.co/spaces/saumitras/colpali-milvus/). Code for the same is [here](https://github.com/saumitras/colpali-milvus-multimodal-rag/).

**TOC**:

1. [Problem](#problem)  
2. [Why colpali?](#why-colpali)  
3. [Understanding how colpali works](#understanding-how-colpali-works)  
4. [Code to upload a PDF, get embedding using colpali, index it to Milvus, then do Q&A queries using a vision language model (gemini/openai)](#code)

## Problem

Let's say a company wants to build a Q&A/search interface for its internal documents, which include PDFs, word files, wikis, images, and text files. The traditional approach involves extracting text and media, detecting layout for structure, and indexing the information in a vector store for semantic search. However, this method often falls short for complex documents containing images, tables, and graphs. Let's look at an example below:

We have a [PDF with stats on covid](https://saumitra.me/2024/covid-slides.pdf) in the form of charts and tables. We want to answer the queries below:

```markdown
1. What is the correlation between the samples tested and the positivity rate?
2. When and what was the highest number of cases and TPR?
3. Which country had the highest omicron cases?

```

These queries can be answered by using data from following 3 pages:

**Page 4: A chart showing stats on samples and positivity rate**

[https://saumitra.me/2024/covid-page-4.png](https://saumitra.me/2024/covid-page-4.png)

**Page 8: A table showing cases and TPR**

[https://saumitra.me/2024/covid-page-8.png](https://saumitra.me/2024/covid-page-8.png)

**Page 9: A table showing cases by country**

[https://saumitra.me/2024/covid-page-9.png](https://saumitra.me/2024/covid-page-9.png)

It would be difficult to extract data from these pages as text in a manner which can be used for querying.
We want to show user the answer and source page(s) from the PDF which contains the answer, like below:

[https://saumitra.me/2024/rag-demo-screenshot.png](https://saumitra.me/2024/rag-demo-screenshot.png)

Let's understand how colpali can help us here.

## Why colpali?

Document retrieval has always been a key component of systems like search engines and information retrieval. Traditional document retrieval methods rely heavily on text-based methods (like OCR and text segmentation), often missing crucial visual cues like layouts, images, and tables.

Colpali addresses this by using Vision-Language Models (VLMs) to understand and retrieve visually rich documents, capturing both textual and visual information. Colpali's architecture allows direct encoding of document images into a common embedding space, eliminating the need for time-consuming text extraction and segmentation.

## Understanding how colpali works

Colpali works in the following steps:

### Step 1: Treating the Document as an Image

Imagine we have a PDF document. Normally, we would extract text from the document using OCR (Optical Character Recognition), segment it into different sections, and then use these segments for searching. colpali simplifies this process by treating the entire document page as an image, bypassing the need for complex text extraction, layout detection, or OCR.

### Step 2: Splitting the Image into Patches

Once colpali has this "image" of the document, it divides the page into small, uniform pieces called patches. Each patch captures a tiny portion of the page. It might contain a few words, a piece of a graph, or part of an image. This division helps the model focus on the document's small, detailed parts rather than trying to understand the whole page at once.

At first glance, it might seem like dividing an image into patches is similar to breaking text into chunks. However, these two methods have several key differences, especially in how they handle and preserve context. Let’s dive deeper into these differences to understand why patch-based processing in colpali is more effective for document retrieval compared to traditional text chunking.

#### Understanding Context Loss in Text Chunking

In traditional text chunking, text is split into smaller chunks based on certain tokens since many models limit the number of tokens they can process at once.

Problem with Context Loss:

- Chunking can split sentences or paragraphs midway, causing crucial context to be lost. It can also result in incomplete information in one chunk and missing context in another.
Chunking doesn't preserve visual or structural information, such as the relationship between headings and their corresponding content or the placement of text in tables or figures.

For example, If you have a document with a heading followed by a table, text chunking might separate the heading and the table, losing the context that the table belongs to that heading.

#### Patch-Based Image Processing in colpali

Colpali divides the document image into patches, much like dividing a photo into small squares. Each patch is a fixed-size portion of the image, like a mini-snapshot of that part of the page.

Patches are more effective due to the following reasons:

- **No Loss of Structure:** The patches retain the document's visual structure, preserving its spatial layout. For instance, if a page has two columns of text or a table with rows and columns, each patch maintains its relative position, ensuring that the model understands the overall arrangement of the elements.
- **Multi-Modal Context:** Patches capture both textual and visual information. This includes both visual features (e.g., font styles, colors, boldness) and non-text elements (e.g., figures and graphs).
- **Positional Awareness:** Each patch has a positional embedding that tells the model where it is located on the page, helping the model understand the overall layout.

### Step 3: Embedding Creation and **Aligning Visual and Textual Information**

Each patch is then passed through a Vision Transformer (ViT), which converts them into unique embeddings. Next, colpali aligns these visual embeddings with the text of the query by transforming the query into its own set of embeddings. colpali uses a process called `alignment` that aligns image path embeddings and text embeddings in the same vector space. Only then can we compare the similarity between query and document embeddings.

### Step 4: Scoring the Relevance - Late Interaction Mechanism

At this point, colpali has embeddings for both the query and the document. The next challenge is to identify the relevant parts of the document. colpali uses a process called the `Late Interaction Mechanism`, where each piece of the query is finely matched against every part of the document, scoring and ranking their relevance.

Colpali highlights the most relevant pieces of the document, focusing on the patches that best match the query. This approach enables colpali to efficiently retrieve relevant information from visually rich documents, capturing both visual and textual data without losing context.

* * *

## Code

Full code at [https://github.com/saumitras/colpali-milvus-rag/](https://github.com/saumitras/colpali-milvus-rag/)

### 1. Add colpali processor

```python
model_name = "vidore/colpali-v1.2"
device = get_torch_device("cuda")

model = colpali.from_pretrained(
    model_name,
    torch_dtype=torch.bfloat16,
    device_map=device,
).eval()

processor = cast(colpaliProcessor, colpaliProcessor.from_pretrained(model_name))

```

### 2. Use colpali to get embeddings for image (pdf pages)

```python
def process_images(self, image_paths:list[str], batch_size=5):

    print(f"Processing {len(image_paths)} image_paths")

    images = self.get_images(image_paths)

    dataloader = DataLoader(
        dataset=ListDataset[str](images),
        batch_size=batch_size,
        shuffle=False,
        collate_fn=lambda x: processor.process_images(x),
    )

    ds: List[torch.Tensor] = []
    for batch_doc in tqdm(dataloader):
        with torch.no_grad():
            batch_doc = {k: v.to(model.device) for k, v in batch_doc.items()}
            embeddings_doc = model(**batch_doc)
        ds.extend(list(torch.unbind(embeddings_doc.to(device))))

    ds_np = [d.float().cpu().numpy() for d in ds]

    return ds_np

```

### 3. Use colpali to get embeddings for text (user query)

```python
def process_text(self, texts: list[str]):
    print(f"Processing {len(texts)} texts")

    dataloader = DataLoader(
        dataset=ListDataset[str](texts),
        batch_size=1,
        shuffle=False,
        collate_fn=lambda x: processor.process_queries(x),
    )

    qs: List[torch.Tensor] = []
    for batch_query in dataloader:
        with torch.no_grad():
            batch_query = {k: v.to(model.device) for k, v in batch_query.items()}
            embeddings_query = model(**batch_query)

        qs.extend(list(torch.unbind(embeddings_query.to(device))))

    qs_np = [q.float().cpu().numpy() for q in qs]

    return qs_np

```

### 4. Code to create collection, index and query in milvus

```python
class MilvusManager:
    def __init__(self, milvus_uri, collection_name, create_collection, dim=128):
        self.client = MilvusClient(uri=milvus_uri)
        self.collection_name = collection_name
        if self.client.has_collection(collection_name=self.collection_name):
            self.client.load_collection(collection_name)
        self.dim = dim

        if create_collection:
            self.create_collection()
            self.create_index()

    def create_collection(self):
        if self.client.has_collection(collection_name=self.collection_name):
            self.client.drop_collection(collection_name=self.collection_name)
        schema = self.client.create_schema(
            auto_id=True,
            enable_dynamic_fields=True,
        )
        schema.add_field(field_name="pk", datatype=DataType.INT64, is_primary=True)
        schema.add_field(
            field_name="vector", datatype=DataType.FLOAT_VECTOR, dim=self.dim
        )
        schema.add_field(field_name="seq_id", datatype=DataType.INT16)
        schema.add_field(field_name="doc_id", datatype=DataType.INT64)
        schema.add_field(field_name="doc", datatype=DataType.VARCHAR, max_length=65535)

        self.client.create_collection(
            collection_name=self.collection_name, schema=schema
        )

    def create_index(self):
        self.client.release_collection(collection_name=self.collection_name)
        self.client.drop_index(
            collection_name=self.collection_name, index_name="vector"
        )
        index_params = self.client.prepare_index_params()
        index_params.add_index(
            field_name="vector",
            index_name="vector_index",
            index_type="HNSW",
            metric_type="IP",
            params={
                "M": 16,
                "efConstruction": 500,
            },
        )

        self.client.create_index(
            collection_name=self.collection_name, index_params=index_params, sync=True
        )

    def create_scalar_index(self):
        self.client.release_collection(collection_name=self.collection_name)

        index_params = self.client.prepare_index_params()
        index_params.add_index(
            field_name="doc_id",
            index_name="int32_index",
            index_type="INVERTED",
        )

        self.client.create_index(
            collection_name=self.collection_name, index_params=index_params, sync=True
        )

    def search(self, data, topk):
        search_params = {"metric_type": "IP", "params": {}}
        results = self.client.search(
            self.collection_name,
            data,
            limit=int(50),
            output_fields=["vector", "seq_id", "doc_id"],
            search_params=search_params,
        )
        doc_ids = set()
        for r_id in range(len(results)):
            for r in range(len(results[r_id])):
                doc_ids.add(results[r_id][r]["entity"]["doc_id"])

        scores = []

        def rerank_single_doc(doc_id, data, client, collection_name):
            doc_colbert_vecs = client.query(
                collection_name=collection_name,
                filter=f"doc_id in [{doc_id}, {doc_id + 1}]",
                output_fields=["seq_id", "vector", "doc"],
                limit=1000,
            )
            doc_vecs = np.vstack(
                [doc_colbert_vecs[i]["vector"] for i in range(len(doc_colbert_vecs))]
            )
            score = np.dot(data, doc_vecs.T).max(1).sum()
            return (score, doc_id)

        with concurrent.futures.ThreadPoolExecutor(max_workers=300) as executor:
            futures = {
                executor.submit(
                    rerank_single_doc, doc_id, data, self.client, self.collection_name
                ): doc_id
                for doc_id in doc_ids
            }
            for future in concurrent.futures.as_completed(futures):
                score, doc_id = future.result()
                scores.append((score, doc_id))

        scores.sort(key=lambda x: x[0], reverse=True)
        if len(scores) >= topk:
            return scores[:topk]
        else:
            return scores

    def insert(self, data):
        colbert_vecs = [vec for vec in data["colbert_vecs"]]
        seq_length = len(colbert_vecs)
        doc_ids = [data["doc_id"] for i in range(seq_length)]
        seq_ids = list(range(seq_length))
        docs = [""] * seq_length
        docs[0] = data["filepath"]

        self.client.insert(
            self.collection_name,
            [\
                {\
                    "vector": colbert_vecs[i],\
                    "seq_id": seq_ids[i],\
                    "doc_id": doc_ids[i],\
                    "doc": docs[i],\
                }\
                for i in range(seq_length)\
            ],
        )

    def get_images_as_doc(self, images_with_vectors:list):

        images_data = []

        for i in range(len(images_with_vectors)):
            data = {
                "colbert_vecs": images_with_vectors[i]["colbert_vecs"],
                "doc_id": i,
                "filepath": images_with_vectors[i]["filepath"],
            }
            images_data.append(data)

        return images_data

    def insert_images_data(self, image_data):
        data = self.get_images_as_doc(image_data)

        for i in range(len(data)):
            self.insert(data[i])

```

### 5. Save pdf as individual images

```python
class PdfManager:
    def __init__(self):
        pass

    def clear_and_recreate_dir(self, output_folder):
        print(f"Clearing output folder {output_folder}")

        if os.path.exists(output_folder):
            shutil.rmtree(output_folder)

        os.makedirs(output_folder)

    def save_images(self, id, pdf_path, max_pages, pages: list[int] = None) -> list[str]:
        output_folder = f"pages/{id}/"
        images = convert_from_path(pdf_path)

        print(f"Saving images from {pdf_path} to {output_folder}. Max pages: {max_pages}")

        self.clear_and_recreate_dir(output_folder)

        num_page_processed = 0

        for i, image in enumerate(images):
            if max_pages and num_page_processed >= max_pages:
                break

            if pages and i not in pages:
                continue

            full_save_path = f"{output_folder}/page_{i + 1}.png"

            image.save(full_save_path, "PNG")

            num_page_processed += 1

        return [f"{output_folder}/page_{i + 1}.png" for i in range(num_page_processed)]

```

### 6. Middleware to index and search Milvus for embeddings generated from colpali

```python
class Middleware:
    def __init__(self, id:str, create_collection=True):
        hashed_id = hashlib.md5(id.encode()).hexdigest()[:8]
        milvus_db_name = f"milvus_{hashed_id}.db"
        self.milvus_manager = MilvusManager(milvus_db_name, "colpali", create_collection)

    def index(self, pdf_path: str, id:str, max_pages: int, pages: list[int] = None):

        print(f"Indexing {pdf_path}, id: {id}, max_pages: {max_pages}")

        image_paths = pdf_manager.save_images(id, pdf_path, max_pages)

        print(f"Saved {len(image_paths)} images")

        colbert_vecs = colpali_manager.process_images(image_paths)

        images_data = [{\
            "colbert_vecs": colbert_vecs[i],\
            "filepath": image_paths[i]\
        } for i in range(len(image_paths))]

        print(f"Inserting {len(images_data)} images data to Milvus")

        self.milvus_manager.insert_images_data(images_data)

        print("Indexing completed")

        return image_paths


    def search(self, search_queries: list[str]):
        print(f"Searching for {len(search_queries)} queries")

        final_res = []

        for query in search_queries:
            print(f"Searching for query: {query}")
            query_vec = colpali_manager.process_text([query])[0]
            search_res = self.milvus_manager.search(query_vec, topk=1)
            print(f"Search result: {search_res} for query: {query}")
            final_res.append(search_res)

        return final_res

```

### 7. Use Gemini or gpt-4o to do Q&A on pdf page(s) matching user query

```python
class Rag:

    def get_answer_from_gemini(self, query, imagePaths):

        print(f"Querying Gemini for query={query}, imagePaths={imagePaths}")

        try:
            genai.configure(api_key=os.environ['GEMINI_API_KEY'])
            model = genai.GenerativeModel('gemini-1.5-flash')

            images = [Image.open(path) for path in imagePaths]

            chat = model.start_chat()

            response = chat.send_message([*images, query])

            answer = response.text

            print(answer)

            return answer

        except Exception as e:
            print(f"An error occurred while querying Gemini: {e}")
            return f"Error: {str(e)}"


    def get_answer_from_openai(self, query, imagesPaths):
        print(f"Querying OpenAI for query={query}, imagesPaths={imagesPaths}")

        try:
            payload = self.__get_openai_api_payload(query, imagesPaths)

            headers = {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {os.environ['OPENAI_API_KEY']}"
            }

            response = requests.post(
                url="https://api.openai.com/v1/chat/completions",
                headers=headers,
                json=payload
            )
            response.raise_for_status()  # Raise an HTTPError for bad responses

            answer = response.json()["choices"][0]["message"]["content"]

            print(answer)

            return answer

        except Exception as e:
            print(f"An error occurred while querying OpenAI: {e}")
            return None

    def __get_openai_api_payload(self, query:str, imagesPaths:List[str]):
        image_payload = []

        for imagePath in imagesPaths:
            base64_image = encode_image(imagePath)
            image_payload.append({
                "type": "image_url",
                "image_url": {
                    "url": f"data:image/jpeg;base64,{base64_image}"
                }
            })

        payload = {
            "model": "gpt-4o",
            "messages": [\
                {\
                    "role": "user",\
                    "content": [\
                        {\
                            "type": "text",\
                            "text": query\
                        },\
                        *image_payload\
                    ]\
                }\
            ],
            "max_tokens": 1024
        }

        return payload


```

In the next post, we will understand the limitations of colpali and a workaround for them.

## References

1. [https://milvus.io/docs/use_colpali_with_milvus.md](https://milvus.io/docs/use_colpali_with_milvus.md)  
2. [https://arxiv.org/abs/2407.01449](https://arxiv.org/abs/2407.01449)

</details>

<details>
<summary>start-with-a-prebuilt-agent</summary>

# LangGraph quickstart

This guide shows you how to set up and use LangGraph's **prebuilt**, **reusable** components, which are designed to help you construct agentic systems quickly and reliably.

## Prerequisites

Before you start this tutorial, ensure you have the following:

- An [Anthropic](https://console.anthropic.com/settings/keys) API key

## 1. Install dependencies

If you haven't already, install LangGraph and LangChain:

```bash
pip install -U langgraph "langchain[anthropic]"
```

`langchain[anthropic]` is installed so the agent can call the model.

## 2. Create an agent

To create an agent, use `create_react_agent`:

_API Reference: [create_react_agent](https://langchain-ai.github.io/langgraph/reference/prebuilt/#langgraph.prebuilt.chat_agent_executor.create_react_agent)_

```python
from langgraph.prebuilt import create_react_agent

def get_weather(city: str) -> str:
    """Get weather for a given city."""
    return f"It's always sunny in {city}!"

agent = create_react_agent(
    model="anthropic:claude-3-7-sonnet-latest",
    tools=[get_weather],
    prompt="You are a helpful assistant"
)

# Run the agent
agent.invoke(
    {"messages": [{"role": "user", "content": "what is the weather in sf"}]}
)
```

## 3. Configure an LLM

To configure an LLM with specific parameters, such as temperature, use `init_chat_model`:

_API Reference: [init_chat_model](https://python.langchain.com/api_reference/langchain/chat_models/langchain.chat_models.base.init_chat_model.html) | [create_react_agent](https://langchain-ai.github.io/langgraph/reference/prebuilt/#langgraph.prebuilt.chat_agent_executor.create_react_agent)_

```python
from langchain.chat_models import init_chat_model
from langgraph.prebuilt import create_react_agent

model = init_chat_model(
    "anthropic:claude-3-7-sonnet-latest",
    temperature=0
)

agent = create_react_agent(
    model=model,
    tools=[get_weather],
)
```

For more information on how to configure LLMs, see Models.

## 4. Add a custom prompt

Prompts instruct the LLM how to behave. Add one of the following types of prompts:

- **Static**: A string is interpreted as a **system message**.
- **Dynamic**: A list of messages generated at **runtime**, based on input or configuration.

Define a fixed prompt string or list of messages:

```python
from langgraph.prebuilt import create_react_agent

agent = create_react_agent(
    model="anthropic:claude-3-7-sonnet-latest",
    tools=[get_weather],
    # A static prompt that never changes
    prompt="Never answer questions about the weather."
)

agent.invoke(
    {"messages": [{"role": "user", "content": "what is the weather in sf"}]}
)
```

Define a function that returns a message list based on the agent's state and configuration:

```python
from langchain_core.messages import AnyMessage
from langchain_core.runnables import RunnableConfig
from langgraph.prebuilt.chat_agent_executor import AgentState
from langgraph.prebuilt import create_react_agent

def prompt(state: AgentState, config: RunnableConfig) -> list[AnyMessage]:
    user_name = config["configurable"].get("user_name")
    system_msg = f"You are a helpful assistant. Address the user as {user_name}."
    return [{"role": "system", "content": system_msg}] + state["messages"]

agent = create_react_agent(
    model="anthropic:claude-3-7-sonnet-latest",
    tools=[get_weather],
    prompt=prompt
)

agent.invoke(
    {"messages": [{"role": "user", "content": "what is the weather in sf"}]},
    config={"configurable": {"user_name": "John Smith"}}
)
```

For more information, see Context.

## 5. Add memory

To allow multi-turn conversations with an agent, you need to enable persistence by providing a checkpointer when creating an agent. At runtime, you need to provide a config containing `thread_id` — a unique identifier for the conversation (session):

_API Reference: [create_react_agent](https://langchain-ai.github.io/langgraph/reference/prebuilt/#langgraph.prebuilt.chat_agent_executor.create_react_agent) | [InMemorySaver](https://langchain-ai.github.io/langgraph/reference/checkpoints/#langgraph.checkpoint.memory.InMemorySaver)_

```python
from langgraph.prebuilt import create_react_agent
from langgraph.checkpoint.memory import InMemorySaver

checkpointer = InMemorySaver()

agent = create_react_agent(
    model="anthropic:claude-3-7-sonnet-latest",
    tools=[get_weather],
    checkpointer=checkpointer
)

# Run the agent
config = {"configurable": {"thread_id": "1"}}
sf_response = agent.invoke(
    {"messages": [{"role": "user", "content": "what is the weather in sf"}]},
    config
)
ny_response = agent.invoke(
    {"messages": [{"role": "user", "content": "what about new york?"}]},
    config
)
```

When you enable the checkpointer, it stores agent state at every step in the provided checkpointer database (or in memory, if using `InMemorySaver`).

Note that in the above example, when the agent is invoked the second time with the same `thread_id`, the original message history from the first conversation is automatically included, together with the new user input.

For more information, see Memory.

## 6. Configure structured output

To produce structured responses conforming to a schema, use the `response_format` parameter. The schema can be defined with a `Pydantic` model or `TypedDict`. The result will be accessible via the `structured_response` field.

_API Reference: [create_react_agent](https://langchain-ai.github.io/langgraph/reference/prebuilt/#langgraph.prebuilt.chat_agent_executor.create_react_agent)_

```python
from pydantic import BaseModel
from langgraph.prebuilt import create_react_agent

class WeatherResponse(BaseModel):
    conditions: str

agent = create_react_agent(
    model="anthropic:claude-3-7-sonnet-latest",
    tools=[get_weather],
    response_format=WeatherResponse
)

response = agent.invoke(
    {"messages": [{"role": "user", "content": "what is the weather in sf"}]}
)

response["structured_response"]
```

LLM post-processing

Structured output requires an additional call to the LLM to format the response according to the schema.

</details>

<details>
<summary>the-8-best-ai-image-generators-in-2025-zapier</summary>

# The 8 best AI image generators in 2025

## Get the best AI-generated images using text-to-image AI.

By Harry Guinness · May 23, 2025

https://images.ctfassets.net/lzny33ho1g45/2olcy4TVSWAjqy5dsxLNZd/09b4a18346af97076615d5f1d1407c39/best-ai-image-generator-hero.jpg?fm=jpg&q=31&fit=thumb&w=1520&h=760

AI image generators have been brewing (generating?) up a storm for the last couple of years. If you've been on social media, watched prime time news shows, or read a magazine, AI-generated images have been impossible to miss. These kinds of AI-generated images are everywhere, and sometimes you won't even realize. If you want to join in the fun, or [add some AI-powered features to your business workflows](https://zapier.com/blog/ai-image-examples-for-business/), the apps on this list will give you what you're looking for.

I've been writing about AI image generators [since Google Deep Dream in 2015](https://photography.tutsplus.com/articles/brave-new-camera-computational-photography--cms-23438). That's about as long as anyone outside of a computer science lab has realistically been thinking about these tools, and I'm really excited by how far they've come.

I'm going to try to avoid the thorny discussions around artistic merit, whether or not these tools are replacing or augmenting artists, and copyright infringement in training data, at least where I can. Instead, I'll focus on the fact that these AI image generators can now produce excellent results from a wide range of text and image prompts.

It's worth taking a few hours to play around with one of these text-to-image AI apps—even just so you can appreciate them from a technical perspective. Whether you like it or not, we're all seeing a lot of their output at the moment. And there will only be more to come.

## The best AI image generators

- [ChatGPT (GPT-4o)](https://zapier.com/blog/best-ai-image-generator/#gpt-4o) for the best AI image generator overall

- [Midjourney](https://zapier.com/blog/best-ai-image-generator/#midjourney) for artistic results

- [Reve](https://zapier.com/blog/best-ai-image-generator/#reve) for overall prompt adherence

- [Ideogram](https://zapier.com/blog/best-ai-image-generator/#ideogram) for accurate text

- [Stable Diffusion](https://zapier.com/blog/best-ai-image-generator/#stable-diffusion) for customization and control of your AI images

- [FLUX.1](https://zapier.com/blog/best-ai-image-generator/#flux) for a Stable Diffusion alternative

- [Adobe Firefly](https://zapier.com/blog/best-ai-image-generator/#firefly) for integrating AI-generated images into photos

- [Recraft](https://zapier.com/blog/best-ai-image-generator/#recraft) for graphic design


## How do AI image generators work?

All these AI image generators take a text prompt and then turn it—as best they can—into a matching image. This opens up some wild possibilities, since your prompt can be anything from "an impressionist oil painting of a Canadian man riding a moose through a forest of maple trees" to "a painting in the style of Vermeer of a large fluffy Irish wolfhound enjoying a pint of beer in a traditional pub" or "a photograph of a donkey on the moon."

https://images.ctfassets.net/lzny33ho1g45/2udOp4paDgOh5HpqG5JRAQ/18abc9476c4705aacf3609edcec4f945/image8.jpeg?

I made this with Midjourney using the prompt "an impressionist oil painting of a Canadian man riding a moose through a forest of maple trees"

Seriously, the only real limits are your imagination, the AI image generator's ability to [comprehend your prompt](https://zapier.com/blog/natural-language-processing/), and any content filters put in place to stop plagiarism, copyright infringement, and bad actors flooding the internet with AI-generated violence or other NSFW content. (That Vermeer prompt used to work reliably, but some more restrictive image generators now block it because it uses a named artist.)

Most AI image generators work in a pretty similar way. [Millions or billions](https://laion.ai/blog/laion-5b/) of image-text pairs are used to train a neural network (basically, a very fancy computer algorithm [modeled loosely on the human brain](https://news.mit.edu/2017/explained-neural-networks-deep-learning-0414)) on _what things are_. By allowing it to process near-countless images, it learns what dogs, the color red, Vermeers, and everything else are. Once this is done, you have an AI that can interpret almost any prompt—though [there is a skill in setting things up](https://zapier.com/blog/ai-art-prompts/) so it can do so accurately.

The next step is to actually render the AI-generated image. The latest generation of AI image generators typically uses a [process called diffusion](https://www.assemblyai.com/blog/diffusion-models-for-machine-learning-introduction/)—though OpenAI's latest foray into image generation uses a slightly different [process called autoregression](https://arxiv.org/abs/2404.02905). In essence, the image generators start with a random field of noise and then edit it in a series of steps to match their interpretation of the prompt. It's kind of like looking up at a cloudy sky, finding a cloud that looks kind of like a dog, and then being able to snap your fingers to keep making it more and more dog-like.

https://images.ctfassets.net/lzny33ho1g45/1LHdvgxMxOKcgWqC2yzoKh/ff7194426828d81a2d8437f4f9c38132/ai-image-generator-dogs.png?

A dog-shaped cloud floating in a clear blue sky—from top-left, going clockwise, at 10 steps, 20 steps, 40 steps, and 120 steps.

Before we dive in: I don't want to oversell things. What these text-to-image generators can do is very impressive, but they aren't likely to save you from ever having to do a product photoshoot again. If you just need some weird or unique images, they can really help. But if you're looking for something super specific, you're better off hiring a photographer—or licensing the exact image you want. Similarly, trying to use one to [make a header image for a blog post](https://zapier.com/blog/generate-blog-images-with-dall-e-and-zapier/) can take a lot more time than just finding a header image for your blog through a stock photo site.

## What makes the best AI image generator?

##### How we evaluate and test apps

Our best apps roundups are written by humans who've spent much of their careers using, testing, and writing about software. Unless explicitly stated, we spend dozens of hours researching and testing apps, using each app as it's intended to be used and evaluating it against the criteria we set for the category. We're never paid for placement in our articles from any app or for links to any site—we value the trust readers put in us to offer authentic evaluations of the categories and apps we review. For more details on our process, read the full rundown of [how we select apps to feature on the Zapier blog](https://zapier.com/blog/selecting-apps/).

There's a reason that AI image generators have become incredibly popular over the past few years: before that, they were pretty bad. The technology underlying them was incredibly cool and impressive, at least to research scientists, but [the images they could output](https://www.theguardian.com/artanddesign/2016/mar/28/google-deep-dream-art) were underwhelming. Even the original DALL·E was more of a fun novelty than a world-shaking revelation [when it launched in 2021](https://openai.com/research/dall-e).

Now that these text-to-image generators have been around for a while, there's some real competition between the different models. They've really increased in quality and can now even generate text somewhat accurately. If all you care about is the current "best" model, check out [Artificial Analysis's Image Arena](https://artificialanalysis.ai/text-to-image/arena?tab=Leaderboard). But we've reached the stage where the top dozen or more models are all excellent, so other features and usability matter more than they used to.

So, to find the best AI art generators, I set some pretty strict criteria:

- I was looking for apps that allowed you to generate AI images from a text prompt (and to a lesser degree, an image prompt). Tools that have you upload a dozen of your photos and then [spit out AI-generated portraits](https://land.prisma-ai.com/magic-avatars/) are fun (and normally built using Stable Diffusion), but they aren't the kind of general-purpose image generators I was considering.

- I was looking at the AI image generators themselves, not [tools built on top of them](https://zapier.com/blog/ai-art-generator/). For example, [NightCafe](https://nightcafe.studio/) is an AI picture generator that has a great community and app, but it just enables you to use [open source models](https://zapier.com/blog/open-source-ai/) like FLUX and Stable Diffusion, fine-tuned models based on various versions of them, the DALL·E 3 and Google Imagen APIs, as well as a handful of older generative models. It's worth checking out, but it doesn't meet my criteria for its own entry on this list.


Aside from all that, I also considered how easy each AI image creator is to use, what kinds of controls and customization options it provides (for things like AI image upscale), what pricing model it has, and most important of all: how good were the results? The best AI image generators are now far less likely to create weird or impossible-looking things.

I've been using and writing about text-to image generators since the original DALL·E launched, and about photography and art for more than a decade, so I'm pretty familiar with how all these tools work—and their various pros, cons, and bonkers behaviors. But writing this article was actually the first time I've put so many AI image generators head-to-head with the _same prompts_. The results were fascinating, and I'm delighted to say all the apps on the list offer genuine reasons to use them.

**How to use AI image generation at work**

Interested in AI, but not quite sure how you'd use it at work? Here are a few of the ways people are turning to AI image generation in their roles:

- Generating hero images for blog posts

- Creating social media posts

- Generating slide decks and storyboards

- Creating personalized images for customers


Learn more about [how to use AI image generation at work](https://zapier.com/blog/ai-image-examples-for-business/).

## The best AI image generators at a glance

|  | **Best for** | **Access options** | **Price** | **Parent company** |
| --- | --- | --- | --- | --- |
| [ChatGPT (GPT-4o)](https://zapier.com/blog/best-ai-image-generator/#gpt-4o) | Ease of use and overall quality | ChatGPT; API | Free with ChatGPT; fewer restrictions with ChatGPT Plus at $20/month | OpenAI |
| [Midjourney](https://zapier.com/blog/best-ai-image-generator/#midjourney) | Artistic results | Web app; Discord | From $10/month for ~200 images/month and commercial usage rights | Midjourney |
| [Reve](https://zapier.com/blog/best-ai-image-generator/#reve) | Adhering to prompts | Web app | 20 free credits/day; $5 for 500 credits | Reve |
| [Ideogram](https://zapier.com/blog/best-ai-image-generator/#ideogram) | Accurate text | Web app | Limited free plan; from $8/month for full-resolution download and 400 monthly priority credits | Ideogram AI |
| [Stable Diffusion](https://zapier.com/blog/best-ai-image-generator/#stable-diffusion) | Customization and control | NightCafe, Tensor.Art, Civitai, and lots of other apps; API; downloading it to a local server | Depends on the platform | Stability AI |
| [FLUX.1](https://zapier.com/blog/best-ai-image-generator/#flux) | Stable Diffusion alternative | NightCafe, Tensor.Art, Civitai, and lots of other apps; API; downloading it to a local server | Depends on the platform | Black Forest Labs |
| [Adobe Firefly](https://zapier.com/blog/best-ai-image-generator/#firefly) | Using AI-generated images in photos | firefly.adobe.com, Photoshop, Express, and other Adobe tools | Limited free credits; from $9.99 for 2,000 credits/month | Adobe |
| [Recraft](https://zapier.com/blog/best-ai-image-generator/#recraft) | Graphic design | Web app | Free for 50 credits/day; from $12/month for full features | Recraft |

## The best AI image generator overall

### [GPT-4o](https://chat.com/)(ChatGPT)

https://images.ctfassets.net/lzny33ho1g45/75DSS8gsgXORvalbs3MCyE/e5c337007c370f28ba0e27584234c762/image13.jpg?

**GPT-4o pros:**

- Incredibly easy to use and a best-in-class model

- Included with ChatGPT Plus, so you get a lot of AI for your money

- Integrates with Zapier


**GPT-4o cons:**

- Very slow

- Controls can be hit and miss

- $20/month is pricey if you don't want the rest of ChatGPT with it


After OpenAI's [DALL·E](https://zapier.com/blog/dall-e-3/) model kickstarted the text-to-image boom, it seemed to take a backseat to the company's language models. DALL·E 2 and DALL·E 3 were good when they debuted, but were both quickly overtaken by other models. But now OpenAI is back with a bang. GPT-4o, the [multimodal](https://zapier.com/blog/multimodal-ai/) model that powers [ChatGPT](https://zapier.com/blog/how-to-use-chatgpt/), can now [natively generate images](https://zapier.com/blog/chatgpt-image-generation/).

GPT-4o is one of the best image generators available. It's also ridiculously easy to use: tell ChatGPT what you want to see, and it'll create the image. Unfortunately, because GPT-4o uses an autoregression model instead of diffusion, it's much slower than the other image generators on this list—and it only generates a single image. If you're only occasionally generating a few images, this isn't a big deal, but it's worth noting.

It's really solid across the board: accurate text rendering, easy editing, understanding of numbers and position, the list goes on. GPT-4o's best feature, though, is what's caused it to go viral. It's great adhering to image prompts (and it's pretty good at adhering to regular prompts, too). If you upload a photo and direct it to create the image in the style of Picasso, Vermeer, or, yes, Studio Ghibli, it will do an exceptional job. It's also pretty good at incorporating feedback—ask it to change just one element of your image and it generally will. Compared to DALL·E 3 (which you can still use as a [GPT](https://chatgpt.com/g/g-2fkFE8rbu-dall-e)), it's a huge improvement.

In addition to GPT-4o image generation through ChatGPT, [OpenAI offers an API](https://zapier.com/blog/openai-api/), which means you can [connect ChatGPT to Zapier](https://zapier.com/apps/chatgpt/integrations) to do things like automatically create images from Google Forms or HubSpot responses—or any other apps you use. Learn more about [how to automate ChatGPT](https://zapier.com/blog/automate-chatgpt/), or get started with one of these pre-made templates.

**GPT-4o pricing:** Free users can access it, but if you don't want to run into limits, GPT-4o image generation is included as part of ChatGPT Plus at $20/month.

## The best AI image generator for artistic results

### [**Midjourney**](https://www.midjourney.com/explore?tab=top)

https://images.ctfassets.net/lzny33ho1g45/5c2lxK4vhLWzfata4t1eul/5037e39582914b8b1f4be36d945085e3/image12.jpg?

**Midjourney pros:**

- Consistently produces some of the best looking AI-generated images

- The community is a great way to get inspiration


**Midjourney cons:**

- Images you generate are public by default

- [Free trials are currently suspended](https://help.midjourney.com/en/articles/8150088-is-there-a-free-trial)


For a long time, [Midjourney](https://zapier.com/blog/how-to-use-midjourney/) produced my favorite results of all of the image generators on this list. Other apps have finally caught up with its quality, but it still produces some of the most coherent, visually appealing, and interesting results with great textures and colors. It's telling that it was [the first AI image generator to win an art competition](https://www.nytimes.com/2022/09/02/technology/ai-artificial-intelligence-artists.html).

Best of all, Midjourney now has an actual web app. You no longer have to access it through Discord—though you can if you want.

Still, as you can probably guess, Midjourney isn't totally free of quirks: by default, every image you generate is posted publicly on Midjourney's Explore page and can be viewed on your profile. It gives everything a cool community aspect, but it means that anyone who cares to look can see what you're creating. While not necessarily a problem for artists, this might be a dealbreaker if you're looking to use Midjourney for business purposes.

If things still sound a bit confusing, don't worry. [Midjourney's help docs](https://docs.midjourney.com/docs/quick-start) are really good and walk you through getting started with both the web app and Discord, and they show you how to control all its various features, from selecting model versions and upscaling to using character references and its personalization tools. Once you understand the different options, the results you can get are genuinely amazing.

Midjourney's free trials are currently suspended because of [the overwhelming number of people trying to use it](https://www.theverge.com/2023/3/30/23662940/deepfake-viral-ai-misinformation-midjourney-stops-free-trials), but they're occasionally reinstated for a few days. If you miss a free trial window, the Basic Plan starts at $10/month and comes with 3.3 hours of GPU time per month, or around 200 images. You also get the option to buy additional GPU time, and you can use your images commercially.

**Midjourney pricing:** From $10/month for the Basic Plan that allows you to generate ~200 images/month and provides commercial usage rights.

**Read more:** [Midjourney vs. DALL·E 3](https://zapier.com/blog/midjourney-vs-dalle/)

## The best AI image generator for adhering to prompts

### [**Reve**](https://preview.reve.art/)

https://images.ctfassets.net/lzny33ho1g45/1rErUICKuzBtIoT0x1EmHf/4e9492bc64da35bec554e2eb16f4ca02/image7.jpg?

**Reve Image 1.0 pros:**

- Great prompt adherence

- Free plan plus affordable credit system


**Reve Image 1.0 cons:**

- Images you generate are public by default


Reve Image 1.0 is a new image model that essentially came out of nowhere in March 2025. It instantly jumped to the top of Artificial Analysis's leaderboard—until it was replaced by GPT-4o a few days later. Still, Image 1.0 is an incredibly powerful image generator with best-in-class prompt adherence.

In plain English, that means Reve Image 1.0 is able to stick closely to the prompt you give it. If you ask for, say, an image with a warrior holding a sword and a wizard holding a staff, that's what you'll get—not a warrior with a staff and a wizard with a sword. This kind of adherence has been a struggle for image generators, especially as prompts get longer and more complicated. I was pretty blown away by just how many details Image 1.0 could manage.

On top of that, Image 1.0 is great with text, different styles, and photorealism. Really, the only area it falls short is with editing. While you can edit a prompt or instruct the model to do something differently, it isn't as effective as GPT-4o or Midjourney at incorporating these changes.

Reve Image 1.0 also represents a return to credit-based pricing, which had fallen out of vogue. You get 100 free credits to start and 20 credits per day. Packs of 500 credits cost $5. Each credit is good for one image, though be warned: on the default settings, you generate four images for every prompt.

**Reve Image 1.0 pricing:** Free for 20 credits per day; additional credits are $5/500

## Best AI image generator for accurate text

### [Ideogram](https://ideogram.ai/)

https://images.ctfassets.net/lzny33ho1g45/7xaiByWYInfO3qQnxkpn9O/05f734289aa1b0f517b3f43eb74f9680/image15-ideogram.jpg?

**Ideogram pros:**

- Great looking AI-generated images—and among the most accurate text of any app

- There's a free plan


**Ideogram cons:**

- Images you generate are public by default


Although they're getting better, most AI image generators still struggle to generate text correctly—the diffusion process just doesn't lend itself to precisely rendering letters. Ideogram, though, has cracked it. Its latest 3.0 algorithm is able to accurately and reliably include text along with any generated image.

What makes this more impressive is Ideogram is also one of the best image generators overall. It has an intuitive web app and some nice features like an [image editor](https://docs.ideogram.ai/using-ideogram/ideogram-features/ideogram-editor) and the ability to [use any image as the basis for a new one](https://docs.ideogram.ai/using-ideogram/ideogram-features/remix). There's a new Batch Generator that allows you to upload a spreadsheet with a list of prompts, and it's beta testing a canvas feature that allows for more complex designs. In my testing, it was up there with Midjourney in terms of quality.

Ideogram even has a free plan. With it, you're limited to 10 credits a week, you have to wait a few minutes for a generation to start, and you only get Ideogram's basic features, but it's still a great way to get a feel for one of the best AI image generators available.

**Ideogram pricing:** Limited free plan; from $8/month for full-resolution download and 400 monthly priority credits.

## Best AI image generator for customization and control

### [Stable Diffusion](https://stability.ai/)

https://images.ctfassets.net/lzny33ho1g45/4Az7EJ5gtpVyQYpyk3J7AX/5077102edb0e3f841c0d3160aeae1bd0/image3.jpeg?

**Stable Diffusion pros:**

- Widely available across AI art generator platforms

- Affordable, customizable, and super powerful with generally great results


**Stable Diffusion cons:**

- The company behind it is maybe collapsing

- There's no one easy option for using it


Unlike Midjourney and Ideogram, [Stable Diffusion](https://zapier.com/blog/how-to-use-stable-diffusion) [has an open license](https://zapier.com/blog/open-source-ai/). This means anyone with the requisite technical skills can [download some versions of it](https://github.com/CompVis/stable-diffusion) and run them locally on their own computer. It also means that you can train and fine-tune the model for specific purposes. For the past couple of years, almost all the services that use AI to generate [artistic portraits](https://land.prisma-ai.com/magic-avatars/), [historical portraits](https://www.myheritage.com/ai-time-machine), [architectural renders](https://interiorai.com/), and everything else use Stable Diffusion this way.

But this kind of open setup can also mean chaos. And that's exactly what's happened with Stability.ai, the company that was formed by some of the researchers who developed Stable Diffusion. In 2024, it was [on the verge of collapse](https://futurism.com/the-byte/stability-ai-collapsing-considering-sale), its latest model and licensing terms [had been heavily criticized](https://www.zeniteq.com/blog/stability-ais-july-2024-license-update), and most of the research team had left to form a new company (which I'll talk about next).

While Stability AI seems to have weathered the crisis for now, all this puts Stable Diffusion in a weird place. The existing versions are still some of the best models available, there are countless fine-tuned versions that make it even better for specific uses, and it's wildly popular—but I'm not sure for how much longer any of this will remain true. The latest version, Stable Diffusion 3.5, is a great model, but it's not as popular or widely available as the earlier models.

The best (or at least most stable) way to use the most popular versions of Stable Diffusion is through an image generation tool like [NightCafe](https://creator.nightcafe.studio/), [Tensor.Art](https://tensor.art/), or [Civitai](https://civitai.com/)—though you can find [lots of other apps](https://zapier.com/blog/ai-art-generator/) that will give you access to it. A lot of these platforms even give you a few free credits so you can try it out before paying. One word of warning, though: some of these platforms don't have the kind of content moderation that's typical on larger social sites. You might see some weird and NSFW things.

If you want to avoid all that or have total control, you can always download Stable Diffusion and run it locally.

**Stable Diffusion pricing:** Depends on the platform, but many offer free credits so you can try them out.

**Read more:** [Stable Diffusion vs. DALL·E](https://zapier.com/blog/stable-diffusion-vs-dalle) and [Midjourney vs. Stable Diffusion](https://zapier.com/blog/midjourney-vs-stable-diffusion).

## Best Stable Diffusion alternative

### [**FLUX.1**](https://blackforestlabs.ai/)

https://images.ctfassets.net/lzny33ho1g45/5xAzjYy11xVmiruodsWtSo/d7a171fd60b1ffd639829b40a87e8cc7/image5.jpg?

**FLUX.1 pros:**

- From the team behind Stable Diffusion—but without the drama

- Powerful and open


**FLUX.1 cons:**

- New and not as widely available as Stable Diffusion


As Stability.ai started collapsing, a significant portion of the team left the company to found [Black Forest Labs](https://blackforestlabs.ai/). Now, they've released their first series of text-to-image models: [FLUX.1](https://zapier.com/blog/flux-ai-image/).

In my testing, FLUX.1 is better than any version of Stable Diffusion that's widely available. It's also increasing in popularity and being embraced by the AI art community.

Right now, if you're looking to get into open AI image generation rather than just using one of the simpler text-to-image tools, I'd suggest experimenting with FLUX.1 over Stable Diffusion. FLUX.1 Schnell is released under an open Apache 2.0 license, while the larger FLUX.1 is open for non-commercial use.

Like Stable Diffusion, the simplest way to use FLUX.1 is through online AI art generators like NightCafe, Tensor.Art, and Civitai. Sign up for a free account, give it a go, and compare it side by side with some of the other models. But again, be warned that the content on these sites may not be entirely SFW.

**FLUX.1 pricing:** Depends on the platform, but many offer free credits so you can try them out.

## Best AI image generator for integrating AI-generated images into photos

### [Adobe Firefly](https://www.adobe.com/products/firefly/features/text-to-image.html)

https://images.ctfassets.net/lzny33ho1g45/4awQwjmU6tXZ9zR8TvLFCm/3835c17c8b44c9a9396d57e77701fdd5/best-ai-image-generator-image2.jpeg?

**Adobe Firefly pros:**

- Integrates well with Adobe's apps, especially Photoshop

- Powerful when it's matching an image


**Adobe Firefly cons:**

- Not the best as a pure text-to-image model


Adobe has been building AI tools into its apps for more than 15 years, so it should be no surprise that it has one of the most powerful text-to-image generators—at least in terms of how it integrates with other tools. You can try its AI model, [Firefly](https://zapier.com/blog/adobe-firefly/), out on the web for free or through [Adobe Express](https://zapier.com/blog/adobe-express-ai), but it's at its best in the latest version of Photoshop.

Firefly has a few tricks up its sleeve. In addition to being capable of generating new images from a detailed text description, it can create text effects from a written prompt (think, the word "TOAST" written with letters that look like they're made from toast), recolor vector artwork, or add AI-generated elements to your images. You can test all these out through the web app, but it's that last feature where Firefly stands out.

Taken purely as a text-to-image generator, Firefly's results can be pretty hit and miss. It can match the best image generators like Midjourney for some prompts, but for others, I question what it was aiming to do. On the other hand, its integration with Photoshop, the industry standard image editor, is next level.

The two best features are Generative Fill and Generative Expand. With Generative Fill, you use Photoshop's regular tools to select an area of your image, and then, just by clicking a button and typing a prompt, you can replace it with something else. With Generative Expand, you can add to the outside of your image. Crucially, both tools understand the context of your image. In the screenshot above, you can see that Photoshop has matched the depth-of-field blur for the forest I added using Generative Fill. It looks cohesive.

As much as DALL·E and Stable Diffusion have started the conversation about image-generating AIs, Adobe's Firefly is the first implementation of an AI photo generator that really hints at what's to come. It isn't a party trick but a tool that's available to the millions of professionals who use Adobe apps every day.

**Firefly pricing:** Limited free credits; from $9.99 for Firefly Standard with 2,000 credits/month; Photoshop is available from $19.99/month as part of the Creative Cloud Photography Plan, which comes with 500 generative credits.

## The best AI image generator for graphic design

### [**Recraft**](https://www.recraft.ai/)

https://images.ctfassets.net/lzny33ho1g45/3ZU5phnoABT9vgevnLFlcG/6eb9b110464e7ed161fe54816ef0f78c/image2.png?

**Recraft pros:**

- One of the most powerful and usable AI image generators

- Graphic design features are second to none


**Recraft cons:**

- More complicated to use than some of the other apps


Recraft is probably the most impressive app on this list. Its model is excellent and able to generate whatever you want, from photorealistic images to interesting logo designs. But it's the tools that Recraft has built around its model that really make it stand out.

Here's one example. Recraft allows you to create image sets that all fit the same style and color panel from a single set of prompts. You have all the style, color, and controls you need to dial things in, and it does an exceptional job right off the bat. Once you're happy with your images, you can export them as JPGs (fine), PNGs (better), or SVGs (amazing). Instead of being limited to small individual images, right from Recraft, you can create matching scalable design elements.

On top of that, you can use Recraft to create product mockups that combine multiple AI elements, in-paint and out-paint to add elements and combine images, adjust images and AI-generated work, remove backgrounds, and so much more. It's got collaboration tools, a great workspace, and you can export your work to other apps like Photoshop or Illustrator. It's a real continuation of what Adobe has done integrating Firefly into Photoshop.

**Recraft Pricing:** Free for 50 credits/day and limited features. From $12/month for Basic with 1,000 credits/month, commercial rights, and more artistic controls.

## Other AI image generators worth trying out

Over the past year, the overall standard of image generators has really improved. There are now a dozen different models that are almost equivalent in quality. I feel the seven above are the best choices for most people, but there are a handful of other apps that warrant mentioning:

- [Google Imagen 3](https://imagen.research.google/). Google's Imagen model is really great, and [if you already pay for Google Gemini](https://zapier.com/blog/gemini-for-workspace/), it's the first model you should look at.

- [Generative AI by Getty](https://www.gettyimages.ie/ai). Designed to generate commercially safe images, Generative AI by Getty is...fine. If you need images with zero commercial risk, it's worth a look—but the legal system doesn't seem to care about companies using images from Midjourney, Ideogram, or DALL·E.

- [Leonardo.Ai](http://leonardo.ai/). In addition to offering FLUX, image creation tool Leonardo.Ai has developed its own Phoenix model. It's a solid platform that just lacks a few features.

- [DALL·E 3](https://openai.com/index/dall-e-3/). DALL·E 3 is still available as a [GPT](https://zapier.com/blog/custom-chatgpt/). If you've got a soft spot for it, you can keep using it, but it's actually considered a legacy model now.

- [Luma Photon](https://lumalabs.ai/photon). Luma Photon is another great model, though I found the [Dream Machine](https://lumalabs.ai/dream-machine) app that uses it a bit too offbeat.

- [Playground](https://playground.com/design). Playground is great for creating designs, but its reliance on a template system meant I felt it was a little out of scope for the list.

- [MiniMax Image-01](https://www.minimax.io/news/image-01). Image-01 is doing really well in Artificial Analysis's leaderboards, though it's only available as an API. If you're a developer, it's worth a look.


If you want a laundry list of every AI image generator out there, including those that are built on top of all the models I've talked about, I made that too. It includes more than two dozen image generators: some are built into other tools, like [AI writing apps](https://zapier.com/blog/best-ai-writing-generator/), [photo editing apps](https://zapier.com/blog/best-ai-photo-editor/), or [stock photo sites](https://zapier.com/blog/best-free-stock-photos/); some let you [select from multiple models](https://zapier.com/blog/hugging-face/); and each one differs on how it approaches AI image generation. So if none of the apps on this list feel natural to you, check out my list of the [top AI art generators](https://zapier.com/blog/ai-art-generator/), and see if anything stands out.

## How to use an AI image generator

Ok, so you know what the best options are, but...now what? The team at Zapier has put together a bunch of resources to help you understand how to use these tools—and put them to work.

First, tutorials and walkthroughs for some of the best AI image generators:

- [How to use the ChatGPT image generator](https://zapier.com/blog/chatgpt-image-generation/)

- [How to use Midjourney](https://zapier.com/blog/how-to-use-midjourney/)

- [How to use Stable Diffusion](https://zapier.com/blog/how-to-use-stable-diffusion/)

- [How to use FLUX.1](https://zapier.com/blog/flux-ai-image/)

- [How to use Adobe Firefly](https://zapier.com/blog/adobe-firefly/)


Plus, a guide for [how to write effective AI art prompts](https://zapier.com/blog/ai-art-prompts/), so you can get what you're looking for faster (and better) when generating images.

Once you've got the basics down, it's time to use these tools for more than just creating wacky pictures. Here are some [tips for how to use AI image generators at work](https://zapier.com/blog/ai-image-examples-for-business/).

And finally, you can [automate your AI image generators](https://zapier.com/blog/automate-ai-images/), so they do their magic behind the scenes and connect to all the other apps you use.

## The legal and ethical implications of AI-generated images

AI-generated images are everywhere now, but that doesn't mean we shouldn't be asking questions about [how they should (or shouldn't) be used](https://zapier.com/blog/how-to-use-ai-badly/).

There aren't clear laws in place surrounding AI-generated images. And that goes for both sides of the coin: the U.S. Copyright Office [suggests that](https://fortune.com/2023/02/23/no-copyright-images-made-ai-artificial-intelligence/) AI-generated content isn't copyright-protected [without some kind of significant human input to the process](https://petapixel.com/2025/01/30/us-copyright-office-softens-its-stance-toward-registering-ai-generated-artworks/), and there aren't rules to protect artists whose work was scraped for AI training. (That's why Firefly was trained on licensed images and public domain content only.) They've [reaffirmed this stance](https://www.reuters.com/legal/litigation/us-copyright-office-denies-protection-another-ai-created-image-2023-09-06/), and the courts [have sided with their interpretation](https://www.reuters.com/world/us/us-appeals-court-rejects-copyrights-ai-generated-art-lacking-human-creator-2025-03-18/).

You're not likely to get into trouble for using AI-generated images for a few social media posts or blog hero images, but because there's no line drawn in the sand yet, it can be risky to develop an entire strategy around AI-generated art. (For what it's worth, [Hollywood seems to be quietly using it](https://nofilmschool.com/the-brutalist-ai).)

Then there's the [issue of bias](https://zapier.com/blog/ai-ethics/). As of now, AI has a lot of the same biases as humans, and that can lead to everything from the portrayal of stereotypes to harmful content. I experienced this myself with the outputs I got from some of the apps while testing them, though other tools take deliberate steps to add diversity to the images they generate. It's up to us as humans to avoid it by reviewing AI-generated content for bias and refining our prompts to eliminate that bias as much as possible.

## What's next for AI image generators?

AI image generating is a rapidly evolving space—and more powerful models are available each time I update this article. (I literally updated the article six weeks ago, and three new or upgraded image models dropped, so I had to update it again.) It's wild how good text-to-image models like GPT-4o, Reve, Midjourney, Ideogram, and FLUX.1 are getting at rendering tricky concepts repeatedly. While they're still a somewhat niche tool now, if they continue getting better at this pace, they could really shake things up.

**Related reading:**

- [The best AI productivity tools](https://zapier.com/blog/best-ai-productivity-tools/)

- [The best AI-powered social media management platforms](https://zapier.com/blog/best-ai-social-media-management/)

- [The best AI photo editors](https://zapier.com/blog/best-ai-photo-editor)

- [The best photo editors for iPhone and Android](https://zapier.com/blog/best-photo-editing-apps-iphone-android/)

- [The best free AI tools](https://zapier.com/blog/free-ai-tools/)

- [What is nano banana? Google's AI image generation model](https://zapier.com/blog/gemini-nano-banana)


_This article was originally published in March 2023. The most recent update was in May 2025._

[https://www.gravatar.com/avatar/68034d9772a3b2d120e7e7b08b251ea3?d=https://res.cloudinary.com/zapier-media/image/upload/f_auto/q_auto/Zapier%20logos/120px_2x_dt6fwm.png\\
\\
Harry Guinness\\
\\
Harry Guinness is a writer and photographer from Dublin, Ireland. His writing has appeared in the New York Times, Lifehacker, the Irish Examiner, and How-To Geek. His photos have been published on hundreds of sites—mostly without his permission.](https://zapier.com/blog/author/harry-guinness)

</details>

<details>
<summary>understanding-multimodal-llms-by-sebastian-raschka-phd</summary>

# Understanding Multimodal LLMs

### An introduction to the main techniques and latest models

Sebastian Raschka, PhD  
Nov 03, 2024

It was a wild two months. There have once again been many developments in AI research, with two Nobel Prizes awarded to AI and several interesting research papers published.

Among others, Meta AI released their latest Llama 3.2 models, which include open-weight versions for the 1B and 3B large language models and two multimodal models.

In this article, I aim to explain how multimodal LLMs function. Additionally, I will review and summarize roughly a dozen other recent multimodal papers and models published in recent weeks (including Llama 3.2) to compare their approaches.

_An illustration of a multimodal LLM that can accept different input modalities (audio, text, images, and videos) and returns text as the output modality._

---

# 1. Use cases of multimodal LLMs

What are multimodal LLMs? As hinted at in the introduction, multimodal LLMs are large language models capable of processing multiple types of inputs, where each "modality" refers to a specific type of data—such as text (like in traditional LLMs), sound, images, videos, and more. For simplicity, we will primarily focus on the image modality alongside text inputs.

A classic and intuitive application of multimodal LLMs is image captioning: you provide an input image, and the model generates a description of the image, as shown in the figure below.

_Example use of a multimodal LLM explaining [a meme](https://x.com/PainSci/status/1309570607458086914)._

Of course, there are many other use cases. For example, one of my favorites is extracting information from a PDF table and converting it into LaTeX or Markdown.

# 2. Common approaches to building multimodal LLMs

There are two main approaches to building multimodal LLMs:

- Method A: Unified Embedding Decoder Architecture approach;
- Method B: Cross-modality Attention Architecture approach.

(By the way, I don’t believe official terms for these techniques exist yet, but let me know if you’ve come across any. For instance, briefer descriptions may be "decoder-only" and "cross-attention-based" approaches.)

_The two main approaches to developing multimodal LLM architectures._

As shown in the figure above, the _Unified Embedding-Decoder Architecture_ utilizes a single decoder model, much like an unmodified LLM architecture such as GPT-2 or Llama 3.2. In this approach, images are converted into tokens with the same embedding size as the original text tokens, allowing the LLM to process both text and image input tokens together after concatenation.

The _Cross-Modality Attention Architecture_ employs a cross-attention mechanism to integrate image and text embeddings directly within the attention layer.

In the following sections, we will explore how these methods work on a conceptual level. Then, we will look at recent research papers on multimodal LLMs to see how they are applied in practice.

## 2.1 Method A: Unified Embedding Decoder Architecture

Let’s begin with the unified embedding decoder architecture, illustrated again in the figure below.

_Illustration of the unified embedding decoder architecture, which is an unmodified decoder-style LLM (like GPT-2, Phi-3, Gemma, or Llama 3.2) that receives inputs consisting of image token and text token embeddings._

In the unified embedding-decoder architecture, an image is converted into embedding vectors, similar to how input text is converted into embeddings in a standard text-only LLM.

For a typical text-only LLM that processes text, the text input is usually tokenized (e.g., using Byte-Pair Encoding) and then passed through an embedding layer, as shown in the figure below.

_Illustration of the standard process for tokenizing text and converting it into token embedding vectors, which are subsequently passed to an LLM during training and inference._

### 2.1.1 Understanding Image encoders

Analogous to the tokenization and embedding of text, image embeddings are generated using an image encoder module (instead of a tokenizer), as shown in the figure below.

_Illustration of the process for encoding an image into image patch embeddings._

What happens inside the image encoder shown above? To process an image, we first divide it into smaller patches, much like breaking words into subwords during tokenization. These patches are then encoded by a pretrained vision transformer (ViT), as shown in the figure below.

_Illustration of a classic vision transformer (ViT) setup, similar to the model proposed in [An Image is Worth 16x16 Words: Transformers for Image Recognition at Scale](https://arxiv.org/abs/2010.11929) (2020)._

Note that ViTs are often used for classification tasks, so I included the classification head in the figure above. However, in this case, we only need the image encoder part.

### 2.1.2 The role of the linear projection module

The "linear projection" shown in the previous figure consists of a single linear layer (i.e., a fully connected layer). The purpose of this layer is to project the image patches, which are flattened into a vector, into an embedding size compatible with the transformer encoder. This linear projection is illustrated in the figure below. An image patch, flattened into a 256-dimensional vector, is up-projected to a 768-dimensional vector.

_Illustration of a linear projection layer that projects flattened image patches from a 256-dimensional into a 768-dimensional embedding space._

For those who prefer seeing a code example, In PyTorch code, we could implement the linear projection for the image patches as follows:

```
import torch

class PatchProjectionLayer(torch.nn.Module):

    def __init__(self, patch_size, num_channels, embedding_dim):
        super().__init__()
        self.patch_size = patch_size
        self.num_channels = num_channels
        self.embedding_dim = embedding_dim
        self.projection = torch.nn.Linear(
            patch_size * patch_size * num_channels, embedding_dim
        )

    def forward(self, x):

        batch_size, num_patches, channels, height, width = x.size()
        x = x.view(batch_size, num_patches, -1)  # Flatten each patch
        x = self.projection(x)  # Project each flattened patch
        return x

# Example Usage:
batch_size = 1
num_patches = 9  # Total patches per image
patch_size = 16  # 16x16 pixels per patch
num_channels = 3  # RGB image
embedding_dim = 768  # Size of the embedding vector

projection_layer = PatchProjectionLayer(patch_size, num_channels, embedding_dim)

patches = torch.rand(
    batch_size, num_patches, num_channels, patch_size, patch_size
)

projected_embeddings = projection_layer(patches)
print(projected_embeddings.shape)

# This prints
# torch.Size([1, 9, 768])
```

If you have read my [Machine Learning Q and AI](https://www.amazon.com/Machine-Learning-AI-Essential-Questions/dp/1718503768/) book by chance, you may know there are ways to replace linear layers with convolution operations that can be implemented to be mathematically equivalent. Here, this can be especially handy as we can combine the creation of patches and projection into two lines of code:

```
layer = torch.nn.Conv2d(3, 768, kernel_size=(16, 16), stride=(16, 16))

image = torch.rand(batch_size, 3, 48, 48)
projected_patches = layer(image)

print(projected_patches.flatten(-2).transpose(-1, -2).shape)
# This prints
# torch.Size([1, 9, 768])
```

### 2.1.3 Image vs text tokenization

Now that we briefly discussed the purpose of the image encoder (and the linear projection that is part of the encoder), let's return to the text tokenization analogy from earlier and look at text and image tokenization and embedding side by side, as depicted in the figure below.

_Image tokenization and embedding (left) and text tokenization and embedding (right) side by side._

As you can see in the figure above, I included an additional _projector_ module that follows the image encoder. This _projector_ is usually just another _linear projection_ layer that is similar to the one explained earlier. The purpose is to project the image encoder outputs into a dimension that matches the dimensions of the embedded text tokens, as illustrated in the figure below. (As we will see later, the projector is sometimes also called adapter, adaptor, or connector.)

_Another side-by-side comparison between image tokenization and text tokenization, where the role of the projector is to match the text token embedding dimensions._

Now that the image patch embeddings have the same embedding dimension as the text token embeddings, we can simply concatenate them as input to the LLM, as shown in the figure at the beginning of this section. Below is the same figure again for easier reference.

_After projecting the image patch tokens into the same dimension as the text token embeddings, we can simply concatenate them as input to a standard LLM._

By the way, the image encoder we discussed in this section is usually a pretrained vision transformer. A popular choice is [CLIP](https://github.com/openai/CLIP) or [OpenCLIP](https://github.com/mlfoundations/open_clip).

However, there are also versions of Method A that operate directly on patches, such as [Fuyu](https://www.adept.ai/blog/fuyu-8b), which is shown in the figure below.

_Annotated figure of the Fuyu multimodal LLM that operates directly on the image patches without image encoder. (Annotated figure from https://www.adept.ai/blog/fuyu-8b.)_

As illustrated in the figure above, Fuyu passes the input patches directly into a linear projection (or embedding layer) to learn its own image patch embeddings rather than relying on an additional pretrained image encoder like other models and methods do. This greatly simplifies the architecture and training setup.

## 2.2 Method B: Cross-Modality Attention Architecture

Now that we have discussed the unified embedding decoder architecture approach to building multimodal LLMs and understand the basic concept behind image encoding, let's talk about an alternative way of implementing multimodal LLMs via cross-attention, as summarized in the figure below.

_An illustration of the Cross-Modality Attention Architecture approach to building multimodal LLMs._

In the Cross-Modality Attention Architecture method depicted in the figure above, we still use the same image encoder setup we discussed previously. However, instead of encoding the patches as input to the LLM, we connect the input patches in the multi-head attention layer via a cross-attention mechanism.

The idea is related and goes back to the original transformer architecture from the 2017 [Attention Is All You Need](https://arxiv.org/abs/1706.03762) paper, highlighted in the figure below.

_High-level illustration of the cross-attention mechanism used in the original transformer architecture. (Annotated figure from the "Attention Is All You Need" paper: https://arxiv.org/abs/1706.03762.)_

Note that the original "Attention Is All You Need" transformer depicted in the figure above was originally developed for language translation. So, it consists of a text encoder (left part of the figure) that takes the sentence to be translated and generates the translation via a text decoder (right part of the figure). In the context of multimodal LLM, the encoder is an image encoder instead of a text encoder, but the same idea applies.

How does cross-attention work? Let's have a look at a conceptual drawing of what happens inside the regular self-attention mechanism.

_Outline of the regular self-attention mechanism. (This flow depicts one of the heads in a regular multi-head attention module.)_

In the figure above, x is the input, and Wq is a weight matrix used to generate the queries (Q). Similarly, K stands for keys, and V stands for values. A represents the attention scores matrix, and Z are the inputs (x) transformed into the output context vectors.

In cross-attention, in contrast to self-attention, we have two different input sources, as illustrated in the following figure.

_Illustration of cross attention, where there can be two different inputs x1 and x2_

As illustrated, in self-attention, we work with the same input sequence. In cross-attention, we mix or combine two different input sequences.

In the case of the original transformer architecture in the _Attention Is All You Need_ paper, the two inputs x1 and x2 correspond to the sequence returned by the encoder module on the left (x2) and the input sequence being processed by the decoder part on the right (x1). In the context of a multimodal LLM, x2 is the output of an image encoder. (Note that the queries usually come from the decoder, and the keys and values typically come from the encoder.)

Note that in cross-attention, the two input sequences x1 and x2 can have different numbers of elements. However, their embedding dimensions must match. If we set x1 = x2, this is equivalent to self-attention.

# 3. Unified decoder and cross-attention model training

Now that we have talked a bit about the two major multimodal design choices, let's briefly talk about how we deal with the three major components during model training, which are summarized in the figure below.

_An overview of the different components in a multimodal LLM. The components numbered 1-3 can be frozen or unfrozen during the multimodal training process._

Similar to the development of traditional text-only LLMs, the training of multimodal LLMs also involves two phases: pretraining and instruction finetuning. However, unlike starting from scratch, multimodal LLM training typically begins with a pretrained, instruction-finetuned text-only LLM as the base model.

For the image encoder, CLIP is commonly used and often remains unchanged during the entire training process, though there are exceptions, as we will explore later. Keeping the LLM part frozen during the pretraining phase is also usual, focusing only on training the projector—a linear layer or a small multi-layer perceptron. Given the projector's limited learning capacity, usually comprising just one or two layers, the LLM is often unfrozen during multimodal instruction finetuning (stage 2) to allow for more comprehensive updates. However, note that in the cross-attention-based models (Method B), the cross-attention layers are unfrozen throughout the entire training process.

After introducing the two primary approaches (Method A: Unified Embedding Decoder Architecture and Method B: Cross-modality Attention Architecture), you might be wondering which is more effective. The answer depends on specific trade-offs.

The Unified Embedding Decoder Architecture (Method A) is typically easier to implement since it doesn't require any modifications to the LLM architecture itself.

The Cross-modality Attention Architecture (Method B) is often considered more computationally efficient because it doesn't overload the input context with additional image tokens, introducing them later in the cross-attention layers instead. Additionally, this approach maintains the text-only performance of the original LLM if the LLM parameters are kept frozen during training.

We will revisit the discussion on modeling performance and response quality in a later section, where we will discuss NVIDIA's NVLM paper.

This marks the end of what turned out to be a rather extensive introduction to multimodal LLMs. As I write this, I realize that the discussion has become lengthier than initially planned, which probably makes this a good place to conclude the article.

However, to provide a practical perspective, it would be nice to examine a few recent research papers that implement these approaches. So, we will explore these papers in the remaining sections of this article.

# 4. Recent multimodal models and methods

For the remainder of this article, I will review recent literature concerning multimodal LLMs, focusing specifically on works published in the last few weeks to maintain a reasonable scope.

Thus, this is not a historical overview or comprehensive review of multimodal LLMs but rather a brief look at the latest developments. I will also try to keep these summaries short and without too much fluff as there are 10 of them.

The conclusion section at the end of this has an overview that compares the methods used in these papers.

## 4.1 The Llama 3 Herd of Models

_[The Llama 3 Herd of Models](https://arxiv.org/abs/2407.21783)_ paper (July 31, 2024) by Meta AI came out earlier this summer, which feels like ages ago in LLM terms. However, given that they only described but did not release their multimodal models until much later, I think it's fair to include Llama 3 in this list. (Llama 3.2 models were officially announced and made available on September 25.)

The multimodal Llama 3.2 models, which come in an 11-billion and 90-billion parameter version, are image-text models that use the previously described cross-attention-based approach, which is illustrated in the figure below.

_Illustration of the multimodal LLM approach used by Llama 3.2. (Annotated figure from the Llama 3 paper: https://arxiv.org/abs/2407.21783. The video and speech parts are visually occluded to focus the attention on the image part.)_

Note that while the figure also depicts video and speech as possible modalities, the models that were released as of this writing focus only on image and text.

Llama 3.2 uses the cross-attention-based approach. However, it differs a bit from what I wrote about earlier, namely that in multimodal LLM development, we usually freeze the image encoder and only update the LLM parameters during pretraining.

Here, the researchers almost take the opposite approach: they update the image encoder but do not update the language model's parameters. They write that this is intentional and done to preserve the text-only capabilities so that the 11B and 90B multimodal models can be used as drop-in replacements for the Llama 3.1 8B and 70B text-only model on text tasks.

The training itself is done in multiple iterations, starting with the Llama 3.1 text models. After adding the image encoder and projection (here called "adapter") layers, they pretrain the model on image-text data. Then, similar to the Llama 3 model text-only training, they follow up with instruction and preference finetuning.

Instead of adopting a pretrained model such as CLIP as an image encoder, the researchers used a vision transformer that they pretrained from scratch. Specifically, they adopted the ViT-H/14 variant (630 million parameters) of the classic vision transformer architecture. They then pretrained the ViT on a dataset of 2.5 billion image-text pairs over five epochs; this was done before connecting the image encoder to the LLM. (The image encoder takes 224×224 resolution images and divides them into a 14×14 grid of patches, with each patch sized at 16×16 pixels.)

As the cross-attention layers add a substantial amount of parameters, they are only added in every fourth transformer block. (For the 8B model, this adds 3B parameters, and for the 70B model, this adds 20 billion parameters.)

## 4.2 Molmo and PixMo: Open Weights and Open Data for State-of-the-Art Multimodal Models

_[Molmo and PixMo: Open Weights and Open Data for State-of-the-Art Multimodal Models](https://www.arxiv.org/abs/2409.17146)_ paper (September 25, 2024) is notable because it promises to open source not only the model weights but also the dataset and source code similar to the language-only OLMo LLM. This is great for LLM research as it allows us to take a look at the exact training procedure and code and also lets us run ablation studies and reproduce results on the same dataset.

_Illustration of the Molmo decoder-only approach (Method A). Annotated figure adapted from the Molmo and PixMo paper: https://www.arxiv.org/abs/2409.17146._

As illustrated in the figure above, the image encoder employs an off-the-shelf vision transformer, specifically CLIP. The term "connector" here refers to a "projector" that aligns image features with the language model.

Molmo streamlines the training process by avoiding multiple pretraining stages, choosing instead a simple pipeline that updates all parameters in a unified approach—including those of the base LLM, the connector, and the image encoder.

The Molmo team offers several options for the base LLM:

- OLMo-7B-1024 (a fully open model backbone),
- OLMoE-1B-7B (a mixture-of-experts architecture; the most efficient model),
- Qwen2 7B (an open-weight model that performs better than OLMo-7B-1024),
- Qwen2 72B (an open-weight model and the best-performing model)

## 4.3 NVLM: Open Frontier-Class Multimodal LLMs

NVIDIA's _[NVLM: Open Frontier-Class Multimodal LLMs](https://arxiv.org/abs/2409.11402)_ paper (September 17, 2024) is particularly interesting because, rather than focusing on a single approach, it explores both methods:

- Method A, the Unified Embedding Decoder Architecture ("decoder-only architecture," NVLM-D), and
- Method B, the Cross-Modality Attention Architecture ("cross-attention-based architecture," NVLM-X).

Additionally, they develop a hybrid approach (NVLM-H) and provide an apples-to-apples comparison of all three methods.

_Overview of the three multimodal approaches. (Annotated figure from the NVLM paper: https://arxiv.org/abs/2409.11402)_

As summarized in the figure below, NVLM-D corresponds to Method A, and NVLM-X corresponds to Method B, as discussed earlier. The concept behind the hybrid model (NVLM-H) is to combine the strengths of both methods: an image thumbnail is provided as input, followed by a dynamic number of patches passed through cross-attention to capture finer high-resolution details.

In short, the research team find that:

- NVLM-X demonstrates superior computational efficiency for high-resolution images.
- NVLM-D achieves higher accuracy in OCR-related tasks.
- NVLM-H combines the advantages of both methods.

Similar to Molmo and other approaches, they begin with a text-only LLM rather than pretraining a multimodal model from scratch (as this generally performs better). Additionally, they use an instruction-tuned LLM instead of a base LLM. Specifically, the backbone LLM is Qwen2-72B-Instruct.

While training all LLM parameters in the NVLM-D approach, they found that for NVLM-X, it works well to freeze the original LLM parameters and train only the cross-attention layers during both pretraining and instruction finetuning.

For the image encoder, instead of using a typical CLIP model, they use InternViT-6B, which remains frozen throughout all stages.

The projector is a multilayer perceptron rather than a single linear layer.

## 4.4 Qwen2-VL: Enhancing Vision-Language Model’s Perception of the World at Any Resolution

_Qwen2-VL: Enhancing Vision-Language Model's Perception of the World at Any Resolution_ (October 3rd, 2024) introduces a "Naive Dynamic Resolution" mechanism that allows the model to handle images of varying resolutions without simple downsampling, enabling the input of images in their original resolution.

_An overview of the multimodal Qwen model, which can process input images with various different resolutions natively. (Annotated figure from the Qwen2-VL paper: https://arxiv.org/abs/2409.12191)_

The native resolution input is implemented via a modified ViT by removing the original absolute position embeddings and introducing 2D-RoPE.

They used a classic vision encoder with 675M parameters and LLM backbones of varying sizes.

The training itself consists of 3 stages: (1) pretraining only the image encoder, (2) unfreezing all parameters (including LLM), and (3) freezing the image encoder and instruction-finetuning only the LLM.

## 4.5 Pixtral 12B

_Pixtral 12B_ (September 17, 2024), which uses the Method A: Unified Embedding Decoder Architecture approach, is the first multimodal model from Mistral AI. The Mistral team shared that they trained an image encoder with 400 million parameters from scratch. For the LLM backbone, they used the 12-billion-parameter Mistral NeMo model.

Pixtral also supports variable image sizes natively.

## 4.6 MM1.5: Methods, Analysis & Insights from Multimodal LLM Fine-tuning

_MM1.5: Methods, Analysis & Insights from Multimodal LLM Fine-tuning_ (September 30, 2024) provides practical tips and introduces a mixture-of-experts multimodal model alongside a dense model similar to Molmo. The models span a wide size range, from 1 billion to 30 billion parameters.

The models described in this paper focus on Method A, a Unified Embedding Transformer Architecture, which structures inputs effectively for multimodal learning.

The paper includes ablation studies looking into data mixtures and the effects of using coordinate tokens.

_Illustration of the MM1.5 approach, which includes additional coordinate tokens to denote bounding boxes. (Annotated figure from the MM1.5 paper: https://arxiv.org/abs/2409.20566.)_

## 4.7 Aria: An Open Multimodal Native Mixture-of-Experts Model

_Aria: An Open Multimodal Native Mixture-of-Experts Model_ (October 8, 2024) introduces another mixture-of-experts model approach, similar to one of the variants in the Molmo and MM1.5 lineups.

The Aria model has 24.9 billion parameters, with 3.5 billion parameters allocated per text token. The image encoder (SigLIP) has 438M parameters.

This model is based on a cross-attention approach with the following overall training procedure:

1. Training the LLM backbone entirely from scratch.
2. Pretraining both the LLM backbone and the vision encoder.

## 4.8 Baichuan-Omni

_The Baichuan-Omni Technical Report_ (October 11, 2024) introduces Baichuan-Omni, a 7-billion-parameter multimodal LLM based on Method A: the Unified Embedding Decoder Architecture approach.

_An overview of the Baichuan-Omni model, which can handle various input modalities. (Annotated figure from the Baichuan-Omni paper: https://arxiv.org/abs/2410.08565)_

The training process for Baichuan-Omni involves a three-stage approach:

1. Projector training: Initially, only the projector is trained, while both the vision encoder and the language model (LLM) remain frozen.
2. Vision encoder training: Next, the vision encoder is unfrozen and trained, with the LLM still frozen.
3. Full model training: Finally, the LLM is unfrozen, allowing the entire model to be trained end-to-end.

The model utilizes the SigLIP vision encoder and incorporates the AnyRes module to handle high-resolution images through down-sampling techniques.

## 4.9 Emu3: Next-Token Prediction is All You Need

The _Emu3: Next-Token Prediction is All You Need_ paper (September 27, 2024) presents a compelling alternative to diffusion models for image generation, which is solely based on a transformer-based decoder architecture. Although it's not a multimodal LLM in the classic sense (i.e., models focused on image understanding rather than generation), Emu3 is interesting as it demonstrates that it's possible to use transformer decoders for image generation, a task typically dominated by diffusion methods.

_Emu3 is primarily an LLM for image generation as an alternative to diffusion models. (Annotated figure from the Emu3 paper: https://arxiv.org/abs/2409.18869)_

The researchers trained Emu3 from scratch and then used Direct Preference Optimization (DPO) to align the model with human preferences.

The architecture includes a vision tokenizer inspired by SBER-MoVQGAN. The core LLM architecture is based on Llama 2, yet it is trained entirely from scratch.

## 4.10 Janus: Decoupling Visual Encoding for Unified Multimodal Understanding and Generation

_Janus: Decoupling Visual Encoding for Unified Multimodal Understanding and Generation_ (October 17, 2024) introduces a framework that unifies multimodal understanding and generation tasks within a single LLM backbone.

A key feature of Janus is the decoupling of visual encoding pathways to address the distinct requirements of understanding and generation tasks. The researchers argue that image understanding tasks require high-dimensional semantic representations, while generation tasks require detailed local information and global consistency in images. By separating these pathways, Janus effectively manages these differing needs.

The model employs the SigLIP vision encoder for processing visual inputs. For image generation, it utilizes a Vector Quantized (VQ) tokenizer to handle the generation process. The base LLM in Janus is the DeepSeek-LLM with 1.3 billion parameters.

_An overview of the unified decoder-only framework used in Janus. (Annotated figure from the Janus paper: https://arxiv.org/abs/2410.13848.)_

The training process for the model follows three stages:

- Stage I: Only the projector layers and image output layer are trained while the LLM, understanding, and generation encoders remain frozen.
- Stage II: The LLM backbone and text output layer are unfrozen, allowing for unified pretraining across understanding and generation tasks.
- Stage III: The entire model, including the SigLIP image encoder, is unfrozen for supervised fine-tuning, enabling the model to fully integrate and refine its multimodal capabilities.

# Conclusion

As you may have noticed, I almost entirely skipped both the modeling and the computational performance comparisons. First, comparing the performance of LLMs and multimodal LLMs on public benchmarks is challenging due to prevalent data contamination, meaning that the test data may have been included in the training data.

Additionally, the architectural components vary so much that making an apples-to-apples comparison is difficult. So, big kudos to the NVIDIA team for developing NVLM in different flavors, which allowed for a comparison between the decoder-only and cross-attention approaches at least.

In any case, the main takeaway from this article is that multimodal LLMs can be built successfully in many different ways. Below is a figure that summarizes the different components of the models covered in this article.

_An overview of the different models covered in this article along with their subcomponents and training approaches._

I hope you found reading this article educational and now have a better understanding of how multimodal LLMs work!

</details>

<details>
<summary>what-are-some-real-world-applications-of-multimodal-ai</summary>

# What are some real-world applications of multimodal AI?

Multimodal AI, which processes and combines different data types like text, images, audio, and sensor inputs, has practical applications across industries. By integrating multiple data sources, these systems improve accuracy and functionality in tasks that require contextual understanding. Below are three key areas where multimodal AI is being applied effectively today.

In healthcare, multimodal AI enhances diagnostics and patient care by merging medical imaging, electronic health records (EHRs), and sensor data. For example, a system might analyze a chest X-ray (image), a patient’s symptom descriptions (text), and vital signs from wearables (sensor data) to detect pneumonia. Models like Google’s Med-PaLM 2 combine vision and language processing to interpret radiology images alongside clinical notes, reducing misdiagnosis risks. Another use case is monitoring postoperative recovery: wearable devices track movement and heart rate, while speech analysis detects pain or fatigue in a patient’s voice, enabling proactive interventions.

Autonomous vehicles rely heavily on multimodal AI to fuse data from cameras, LiDAR, radar, and GPS. A self-driving car processes road signs (visual data), pedestrian movements (video), and proximity sensor readings to navigate safely. Tesla’s Autopilot, for instance, uses neural networks to combine camera feeds with ultrasonic sensors, improving object detection in varied lighting or weather. Similarly, companies like Waymo train models to correlate map data with real-time sensor inputs, ensuring precise localization and path planning. This redundancy across modalities helps address limitations of single-sensor systems, such as camera failures in low light.

Customer service and content moderation also benefit from multimodal approaches. Virtual assistants like Amazon’s Alexa process voice commands while analyzing user history (text) to personalize responses. In moderation, platforms like YouTube use AI to flag harmful content by scanning video frames (images), audio for hate speech, and user comments (text) simultaneously. For example, a post containing violent imagery and threatening text would be detected faster than if each modality were analyzed separately. Tools like OpenAI’s CLIP enable cross-modal matching, such as linking inappropriate images to their descriptive captions, improving accuracy in filtering violations. These systems reduce reliance on manual review while scaling to handle large data volumes.

</details>

<details>
<summary>what-are-vision-language-models-nvidia-glossary</summary>

# Vision Language Models

Vision language models (VLMs) are multimodal, generative AI models capable of understanding and processing video, image, and text.

## What Are Vision Language Models?

Vision language models are multimodal AI systems built by combining a large language model (LLM) with a vision encoder, giving the LLM the ability to “see.”

With this ability, VLMs can process and provide advanced understanding of video, image, and text inputs supplied in the prompt to generate text responses.

https://www.nvidia.com/content/nvidiaGDC/us/en_US/glossary/vision-language-models/_jcr_content/root/responsivegrid/nv_container_copy/nv_image.coreimg.100.1290.png/1736201901571/metropolis-iva-diagram-vlm-glossary-ces25-3576177-r1--1-.png

Figure 1: Use cases for vision language models

Unlike traditional [computer vision](https://www.nvidia.com/en-us/glossary/computer-vision/) models, VLMs are not bound by a fixed set of classes or a specific task like classification or detection. Retrained on a vast corpus of text and image/video-caption pairs, VLMs can be instructed in natural language and used to handle many classic vision tasks plus new generative AI-powered tasks such as summarization and visual Q&A.

## Why Are Vision Language Models Important?

To understand the importance of VLMs, it’s helpful to know how past computer vision (CV) models work. Traditional convolutional neural network ( [CNN](https://www.nvidia.com/en-us/glossary/convolutional-neural-network/))-based CV models are trained for a specific task on a bounded set of classes. For example:

- A classification model that identifies whether an image contains a cat or a dog
- An optical character detection and recognition CV model that reads text in an image but doesn’t interpret the format or any visual data within a document

Previous CV models were trained for a specific purpose and did not have the ability to go beyond the task or set of classes they were developed for and trained on. If the use case changed at all or required a new class to be added to the model, a developer would have to collect and label a large number of images and retrain the model. This is an expensive, time-consuming process. Additionally, CV models don't have any natural language understanding.

VLMs bring a new class of capabilities by combining the power of foundation models, like [CLIP](https://github.com/openai/CLIP), and LLMs to have both vision and language capabilities. Out of the box, VLMs have strong zero-shot performance on a variety of vision tasks, like visual question-answering, classification, and optical character recognition. They are also extremely flexible and can be used not just on a fixed set of classes but for nearly any use case by simply changing a text prompt.

Using a VLM is very similar to interacting with an LLM. The user supplies text prompts that can be interleaved with images. The inputs are then used to generate text output. The input prompts are open-ended, allowing the user to instruct the VLM to answer questions, summarize, explain the content, or reason with the image. Users can chat back and forth with the VLM, with the ability to add images into the context of the conversation. VLMs can also be integrated into visual agents to autonomously perform vision tasks.

## How Do Vision Language Models Work?

Most VLMs follow an architecture with three parts:

- A vision encoder
- A projector
- An LLM

The vision encoder is typically a CLIP-based model with a transformer architecture that has been trained on millions of image-text pairs, giving it the ability to associate images and text. The projector is a set of layers that translates the output of the vision encoder into a form the LLM can understand, often interpreted as image tokens. This projector can be a simple line layer like LLaVA and VILA, or something more complex like the cross-attention layers used in Llama 3.2 Vision.

Any off-the-shelf LLM can be used to build a VLM. There are hundreds of VLM variants that combine various LLMs with vision encoders.

https://www.nvidia.com/content/nvidiaGDC/us/en_US/glossary/vision-language-models/_jcr_content/root/responsivegrid/nv_container_copy_co_300503066/nv_image.coreimg.svg/1736168815674/vlm-architecture-diagram.svg

Figure 2: A common three-part architecture for vision language models

## How Are Vision Language Models Trained?

VLMs are trained in several stages that include pretraining, followed by supervised fine-tuning. Optionally, parameter efficient fine-tuning (PEFT) can be applied as a final stage to create a domain-specific VLM on custom data.

The pretraining stage aligns the vision encoder, projector, and LLM to essentially speak the same language when interpreting the text and image input. This is done using large corpora of text and images with image-caption pairs and interleaved image-text data. Once the three components have been aligned through pretraining, the VLM goes through a supervised fine-tuning stage to help it understand how to respond to user prompts.

The data used in this stage are a blend of example prompts with text and/or image input and the expected response of the model. For example, this data could be prompts telling the model to describe the image or to count all the objects in the frame with the expected correct response. After this round of training, the VLM will understand how to best interpret images and respond to user prompts.

https://www.nvidia.com/content/nvidiaGDC/us/en_US/glossary/vision-language-models/_jcr_content/root/responsivegrid/nv_container_copy_co_1755415045/nv_image.coreimg.svg/1736168816034/vlm-training-process-diagram.svg

Figure 3: Training for VLMs is often done in several stages to target certain parts of the model

Once the VLM is trained, it can be used in the same way as an LLM by providing prompts that can also include images interleaved in text. The VLM will then generate a text response based on the inputs. VLMs are typically deployed with an OpenAI style REST API interface to make it easy to interact with the model.

More advanced techniques are currently being researched to enhance vision capabilities:

- Ensembling vision encoders to process image inputs
- Breaking apart high-resolution image inputs into smaller tiles for processing
- Increasing context length to improve long video understanding

All of these advancements are progressing the capabilities of VLMs from only understanding single-image input to being highly capable models that can compare and contrast images, accurately read text, understand long videos, and have strong spatial understanding.

## How Are Vision Language Models Benchmarked?

Several common benchmarks, such [MMMU](https://mmmu-benchmark.github.io/), [Video-MME](https://video-mme.github.io/home_page.html), [MathVista](https://mathvista.github.io/), [ChartQA](https://github.com/vis-nlp/ChartQA) , and [DocVQA](https://www.docvqa.org/), exist to determine how well vision-language models perform on a variety of tasks, such as:

- Visual question-answering
- Logic and reasoning
- Document understanding
- Multi-image comparisons
- Video understanding

Most benchmarks consist of a set of images with several associated questions, often posed as multiple-choice questions. The multiple-choice format is the easiest way to consistently benchmark and compare VLMs. These questions test the VLMs perception, knowledge, and reasoning capabilities. When running these benchmarks, the VLM is provided with the image, question, and several multiple-choice answers it must choose from.

https://www.nvidia.com/content/nvidiaGDC/us/en_US/glossary/vision-language-models/_jcr_content/root/responsivegrid/nv_container_copy_co_42410027/nv_image.coreimg.100.1290.jpeg/1736168816436/vlm-mmmu-ari.jpeg

Figure 4: Example multiple-choice questions for VLMs used in the MMMU benchmark

Source ( [MMMU](https://mmmu-benchmark.github.io/))

The accuracy of the VLM is the number of correct choices over the set of multiple-choice questions. Some benchmarks also include numerical questions where the VLM must perform a specific calculation and be within a certain percentage of the answer to be considered correct. Often these questions and images come from academic sources, such as college-level textbooks.

## How Are Vision Language Models Used?

VLMs are quickly becoming the go-to tool for all types of vision-related tasks due to their flexibility and natural language understanding. VLMs can be easily instructed to perform a wide variety of tasks through natural language:

1. Visual questions-answering
2. Image and video summarization
3. Parsing text and handwritten documents

Previous applications that would have required a large ensemble of specially trained models can now be accomplished with just a single VLM.

VLMs are especially good at summarizing the contents of images and can be prompted to perform specific tasks based on the contents. Take for example, an education use case—a VLM could be given an image of a handwritten math problem, and it could use its optical character recognition and reasoning capabilities to interpret the problem and produce a step-by-step guide on how to solve it. VLMs can not only understand the content of the image but also reason and perform specific tasks.

https://www.nvidia.com/content/nvidiaGDC/us/en_US/glossary/vision-language-models/_jcr_content/root/responsivegrid/nv_container_copy_co_531349501/nv_image.coreimg.svg/1736168816834/vlm-real-world-diagram.svg

Figure 5: video analytics AI agents transform video and image data into real-world insights

With vast amounts of video being produced every day, it's infeasible to review and extract insights from this volume of video that is produced by all industries. VLMs can be integrated into a larger system to build video analytics AI agents capable of detecting specific events when prompted. These systems could be used to detect malfunctioning robots in a warehouse or generate out-of-stock alerts when shelves are empty. Their general understanding goes beyond simple detection and could be used to generate automated reports. For example, an intelligent traffic system could detect, analyze, and produce reports of traffic hazards, such as fallen trees, stalled vehicles, or collisions.

VLMs can be used with technologies like graph databases to understand long videos. This helps them capture the complexity of objects and events in a video. Such systems could be used to summarize operations in a warehouse to find bottlenecks and inefficiencies or produce sports commentary for football, basketball, or soccer games.

## What Are the Challenges of Vision Language Models?

Vision language models are maturing quickly, but they still have some limitations, particularly around spatial understanding and long-context video understanding.

Most VLMs use CLIP-based models as the vision encoder, which are limited to 224x224 or 336x336 image input size. This relatively small input image makes it difficult for small objects and details to be detected. For example, an HD 1080x1920 frame from a video must be downsized or cropped to a much smaller input resolution, making it difficult to retain details for small objects or fine details. To fix this, VLMs are starting to use tiling methods that allow a big image to be broken into smaller pieces and then fed into the model. There's also ongoing research to explore the use of higher-resolution image encoders.

VLMs also have difficulty providing precise locations for objects. The training data for CLIP-based vision encoders consists mostly of short text descriptions of images, like captions. These descriptions don't include detailed, fine-grained object locations, and this limitation impacts CLIP’s spatial understanding. This is inherited by VLMs that use it as a vision encoder. New approaches are exploring the use of ensembling several vision encoders to address these limitations [2408.15998 (arxiv.org)](https://arxiv.org/pdf/2408.15998).

Long video understanding is a challenge due to the need to take into account visual information across potential hours of video to properly analyze or answer questions. Like LLMs, VLMs have limited context length meaning—only a certain number of frames from a video can be included to answer questions. Approaches to increase context length and train VLMs on more video-based data are being researched, such as LongVILA [2408.10188 (arxiv.org)](https://www.arxiv.org/pdf/2408.10188).

VLMs may not have seen enough data for very specific use cases, such as finding manufacturing defects in a specific product line. This limitation can be overcome by fine-tuning the VLM on domain-specific data or using multi-image VLMs with in-context learning to provide examples that can teach the model new information without explicitly training the model. Training the model on domain-specific data with PEFT is another technique that can be used to improve a VLM’s accuracy on custom data.

</details>

<details>
<summary>what-is-optical-character-recognition-ocr-explained</summary>

# What Is Optical Character Recognition (OCR)?

https://blog.roboflow.com/content/images/size/w1200/2024/04/image-730.webp

[Petru P.](https://blog.roboflow.com/author/potrimba/)

Published
Nov 21, 2023
•
7 min read


Have you ever wondered how a computer can understand the words on a photo, just like you do?  That's where Optical Character Recognition, or [OCR](https://roboflow.com/ocr?ref=blog.roboflow.com), steps in. OCR takes the text you see in images – be it from a book, a receipt, or an old letter – and turns it into something your computer can read, edit, and search.

OCR finds widespread applications in tasks such as automated data entry, document digitization, text extraction from images, invoice processing, form recognition, and enhancing accessibility for visually impaired individuals.

Let's explore the fundamentals of OCR, understanding its workings, the challenges it addresses, and why it remains a crucial component of present and future technology.

## What Is Optical Character Recognition?

Optical Character Recognition (OCR) involves converting both handwritten and typed text from various sources, including images, videos, and scanned documents like PDFs, into a digitally editable format.

The output from OCR can be used by a computer to make decisions. Common use cases of OCR include:

Using OCR to read product identifiers on an assembly line. When each identifier is read, a piece of software can update an inventory tracking system to note the package with the given identifier has arrived.

Using OCR for scanned document recognition. This involves scanning printed documents, after which OCR software converts them into searchable and editable text. This method is widely employed to automate the handling of legal documents, extract data from bank statements and invoices, and streamline tasks like invoice processing and financial record-keeping.

Using OCR for “scene text recognition”, wherein an OCR system recognizes text from natural scenes, such as street signs, storefronts, or license plates.

Using OCR for alphanumeric, printed text, such as text that was written on a typewriter, or text that was printed out. But, you can also use OCR on handwriting. This usually involves using a separate system due to the differences in handwriting compared to printed text.

https://blog.roboflow.com/content/images/2024/04/image-733.webp_Application of OCR on the text of a book._ [_Source_](https://www.edenai.co/post/optical-character-recognition-ocr-which-solution-to-choose?ref=blog.roboflow.com).

## How Optical Character Recognition Works

Let's discuss the typical steps modern OCR software uses to read text:

1. **Image pre-processing**: After an image has been collected, the image undergoes pre-processing to enhance image quality, improving recognition. Pre-processing may involve resizing, contrast enhancement, binarization, noise reduction, and other techniques.
2. **Text Detection**: Using a specialized deep-learning model trained on large datasets of images and text, the computer vision model detects regions in the input image that likely contain text. This process is usually a crucial step.
3. **Layout Analysis**: After detecting text regions, the computer vision model conducts layout analysis to determine the structure and order of the text in the image. This step ensures the preservation of context and organizes the output for readability, but is not run by all OCR systems.
4. **Text Recognition**: Detected text regions pass through a deep learning-based text recognition model, utilizing a combination of convolutional neural networks (CNNs) and recurrent neural networks (RNNs). This model recognizes individual characters and words in the input image, converting them into machine-readable text.
5. **Language Model**: The final output undergoes post-processing to remove noise, correct spelling mistakes, and enhance overall accuracy. The predicted sequence of characters may contain errors, especially for long or uncommon words. Language models, acting as word processors, refine the output by predicting the probability of a sequence of words based on the input image. Statistical models and advanced methods, including deep learning, may be employed for this purpose.


https://blog.roboflow.com/content/images/2024/04/image-738.webp_An example OCR system pipeline._

Having acquired an understanding of how OCR operates, let's examine its algorithms and investigate their operational mechanisms, covering the old and the new.

## Traditional Approaches to OCR

The first OCR algorithms rooted in image processing were typically rule-based systems. One well-known OCR that uses this approach is [Tesseract](https://github.com/tesseract-ocr/tesseract?ref=blog.roboflow.com). These systems relied on manually crafted features and heuristic rules to identify characters within images. The approach involved segmenting characters into individual units and applying a set of rules for character classification.

However, the accuracy and performance of these algorithms were often constrained due to the intricate process of developing and fine-tuning the necessary handcrafted features and rules for effective recognition.

### Tesseract

Tesseract, an open-source optical character recognition engine, originated at Hewlett-Packard Laboratories in the 1980s and subsequently became open-source in 2005.

Initially designed to recognize English text exclusively, Tesseract has evolved into a versatile OCR engine. Working from traditional image processing principles, which involves manual logic unlike the deep learning processes in modern systems, Tesseract analyzes images to identify patterns for character recognition.

First, Tesseract preprocesses the image to enhance input quality, a step which encompasses tasks like contrast improvement and noise removal. Following this, Tesseract employs feature extraction techniques, including edge detection and pattern recognition, to identify and recognize characters.

https://blog.roboflow.com/content/images/2024/04/image-741.webp_Tesseract OCR engine pipeline._ [_Source_](https://www.researchgate.net/figure/Tesseract-OCR-engine-architecture_fig4_265087843?ref=blog.roboflow.com).

## Deep Learning Approaches to Optical Character Recognition

With the rise of deep learning, the integration of neural networks into OCR systems has gained substantial popularity. In particular, deep learning methodologies like [Convolutional Neural Networks](https://blog.roboflow.com/what-is-a-convolutional-neural-network/) and Long Short-Term Memory networks are leveraged, for precise text recognition. Neural networks regularly achieve better performance than traditional OCR techniques.

In recent years, there has also been a surge in novel approaches that leverage pre-trained image and text [Transformers](https://blog.roboflow.com/what-is-a-transformer/), a deep learning architecture. Transformers are ushering in a new era of end-to-end optical word recognition.

### PaddleOCR

[Paddle OCR](https://arxiv.org/abs/2009.09941?ref=blog.roboflow.com) is an open-source engine developed by Baidu's PaddlePaddle team. Leveraging deep learning techniques, including CNNs and recurrent neural networks, Paddle OCR excels in accurate text recognition. It comprises two key components: the detector and the extractor. The detector is tasked with pinpointing text within an image or document. It employs various algorithms, such as [EAST (Efficient and Accurate Scene Text)](https://paperswithcode.com/paper/east-an-efficient-and-accurate-scene-text?ref=blog.roboflow.com) or [DB (Differentiable Binarization)](https://arxiv.org/abs/1911.08947?ref=blog.roboflow.com) detectors, to identify text regions.

https://blog.roboflow.com/content/images/2024/04/image-745.webp_DB (Differentiable Binarization) architecture._ [_Source_](https://arxiv.org/pdf/2009.09941.pdf?ref=blog.roboflow.com).

After the detector locates the text, the extractor comes into play, retrieving the text from the image. It employs a blend of Convolutional Neural Networks and Recurrent Neural Networks for precise text recognition. CNNs are utilized to extract features from the text, while RNNs play a crucial role in recognizing the sequence of characters.

https://blog.roboflow.com/content/images/2024/04/image-748.webp_CRNN Extractor architecture._ [_Source_](https://arxiv.org/pdf/1507.05717.pdf?ref=blog.roboflow.com).

Paddle OCR stands out for its remarkable speed, making it among the swiftest OCR engines. Its efficiency is attributed to the utilization of parallel computing and GPU acceleration. This feature renders it particularly suitable for extensive OCR tasks, including document scanning and image recognition. Moreover, its adaptability shines through as it can be tailored and fine-tuned for specific tasks and datasets, enhancing its versatility and robustness in various OCR applications.

### TrOCR

[Transformer-based Optical Character Recognition (TrOCR)](https://arxiv.org/abs/2109.10282?ref=blog.roboflow.com) is one of many transformer-based [OCR models](https://blog.roboflow.com/best-ocr-models-text-recognition/). In contrast to traditional OCR systems, TrOCR adopts a methodology where both input image processing and the generation of corresponding text output occur within a single model.

The encoder segment of TrOCR employs a transformer-based architecture to handle the input image, segmenting it into a grid of patches and extracting visual features from each patch. Simultaneously, the decoder component utilizes a transformer-based model to produce the relevant text output, incorporating the visual features extracted from the image.

https://blog.roboflow.com/content/images/2024/04/image-752.webp_TrOCR Architecture._ [_Source_](https://arxiv.org/pdf/2109.10282.pdf?ref=blog.roboflow.com).

This comprehensive and transformer-based methodology empowers TrOCR to attain strong performance across diverse OCR benchmarks, establishing the model as a highly dependable and effective tool for text recognition tasks.

## Advantages of Modern OCR Techniques

One of the primary advantages of OCR is its ability to automate the data entry process. Traditional manual data entry is not only time-consuming but also prone to errors. OCR technology streamlines this process by automatically extracting text from images or scanned documents, eliminating the need for human input. This automation significantly reduces the time required for tasks such as transcribing printed or handwritten text into digital formats.

In addition, OCR facilitates the digitization of documents, leading to improved efficiency in document management. By converting physical documents into digital formats, OCR enables easy storage, retrieval, and organization of information.

Digital documents are more accessible and can be quickly searched, eliminating the need for manual sorting through paper files. This advantage is particularly crucial in business settings where quick access to relevant information is essential.

## Limitations of Modern OCR Techniques

OCR systems, while proficient in recognizing printed text, often face challenges when it comes to accurately interpreting handwritten text. Handwriting is inherently diverse, varying in styles, shapes, and legibility. Unlike printed text, which follows standardized fonts and structures, handwritten text can exhibit significant variability, making it difficult for OCR algorithms to consistently and accurately recognize every nuance.

This limitation is particularly pronounced in scenarios where the handwriting is cursive, unconventional, or poorly formed. Overcoming this challenge requires more advanced techniques, such as integrating machine learning [models](https://blog.roboflow.com/best-ocr-models-text-recognition/) specifically trained on diverse handwritten datasets.

Furthermore,OCR systems can be sensitive to the quality of the input image and may struggle with images that have poor resolution, low contrast, or significant noise. Additionally, documents with complex layouts, multiple columns, or irregular text arrangements pose challenges for traditional OCR methods.

The image preprocessing steps performed by OCR engines, such as Tesseract, are crucial for improving recognition accuracy, but they may not always suffice for images with inherent complexities. Complex layouts can disrupt the OCR's ability to accurately segment text regions and extract meaningful content, leading to errors in character recognition.

To mitigate these issues, additional preprocessing techniques or more advanced OCR methods may be necessary, adding complexity to the implementation process.

## Optical Character Recognition

Optical Character Recognition (OCR) is the extraction of text from scanned documents or images, converting it into machine-readable data to enhance information accessibility.

OCR can reduce the time and resources needed for managing non-searchable or elusive data, eliminating manual data input, reducing errors, and boosting productivity. However, challenges such as handwritten text recognition and sensitivity to image quality persist in OCR systems.

Despite these challenges, OCR remains pivotal in present and future technology, automating data entry, improving document management, and enhancing accessibility. Its adaptability and multilingual support position OCR as a fundamental component in shaping technological advancements.

</details>
