class CsvReadError(Exception):
    """Fehler beim Lesen einer CSV-Datei."""

    pass


class ExcelReadError(Exception):
    """Fehler beim Lesen einer Excel-Datei."""

    pass
