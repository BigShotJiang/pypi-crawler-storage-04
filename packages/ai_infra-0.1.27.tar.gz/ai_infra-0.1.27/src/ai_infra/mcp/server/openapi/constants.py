ALLOWED_METHODS = {"get", "post", "put", "patch", "delete", "head", "options"}

__all__ = ["ALLOWED_METHODS"]