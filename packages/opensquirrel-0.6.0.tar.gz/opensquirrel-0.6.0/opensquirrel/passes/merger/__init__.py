from opensquirrel.passes.merger.single_qubit_gates_merger import SingleQubitGatesMerger

__all__ = [
    "SingleQubitGatesMerger",
]
