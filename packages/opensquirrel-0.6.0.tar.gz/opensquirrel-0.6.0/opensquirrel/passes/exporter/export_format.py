from enum import Enum


class ExportFormat(Enum):
    QUANTIFY_SCHEDULER = 0
    CQASM_V1 = 1
