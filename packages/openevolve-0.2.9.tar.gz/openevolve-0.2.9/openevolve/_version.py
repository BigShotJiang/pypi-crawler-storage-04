"""Version information for openevolve package."""

__version__ = "0.2.9"
