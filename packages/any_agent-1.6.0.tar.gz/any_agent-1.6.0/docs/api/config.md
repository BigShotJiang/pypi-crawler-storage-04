# Config

::: any_agent.config.AgentConfig

::: any_agent.config.MCPStdio

::: any_agent.config.MCPStreamableHttp

::: any_agent.config.MCPSse

::: any_agent.serving.A2AServingConfig

::: any_agent.serving.MCPServingConfig

::: any_agent.config.AgentFramework
