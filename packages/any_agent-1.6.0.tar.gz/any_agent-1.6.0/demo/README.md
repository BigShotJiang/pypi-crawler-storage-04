---
title: Surf Spot Finder
emoji: 🏄🏼‍♂️
colorFrom: blue
colorTo: indigo
sdk: docker
app_port: 8501
tags:
- streamlit
pinned: false
short_description: Find a surf spot near you
license: apache-2.0
---
