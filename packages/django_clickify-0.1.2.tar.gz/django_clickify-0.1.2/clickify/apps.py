from django.apps import AppConfig


class ClickifyConfig(AppConfig):
    """App Config For Clickify"""

    default_auto_field = "django.db.models.BigAutoField"
    name = "clickify"
