"""Code to access NIH's iCite API"""

__copyright__ = 'Copyright (C) 2019-present, DV Klopfenstein, PhD. All rights reserved'
__author__ = 'DV Klopfenstein, PhD'
__version__ = '0.2.0'

# Copyright (C) 2019-present, DV Klopfenstein, PhD. All rights reserved
