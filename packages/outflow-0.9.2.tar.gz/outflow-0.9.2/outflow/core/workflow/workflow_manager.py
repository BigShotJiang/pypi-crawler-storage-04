# -*- coding: utf-8 -*-
from outflow.core.generic.context_manager import ContextManager


class WorkflowManager(ContextManager):
    pass
