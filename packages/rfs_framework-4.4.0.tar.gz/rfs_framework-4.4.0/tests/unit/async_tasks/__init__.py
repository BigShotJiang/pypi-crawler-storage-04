"""Unit tests for async_tasks module"""
