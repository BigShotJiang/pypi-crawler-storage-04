# noqa: D104

# Wheel names will be generated according to this value. Do not manually modify this value; instead
# update it according to committed changes by running this command from the root of the repository:
#
#   uv run python -m AutoGitSemVer.scripts.UpdatePythonVersion ./src/dbrownell_Email/__init__.py ./src
#
__version__ = "0.2.4"

from .SmtpMailer import SmtpMailer

__all__ = [
    "SmtpMailer",
]
