# smd/__main__.py
# this runs when you run `python -m smd`

from smd.downloader import cli

if __name__ == "__main__":
    cli()
