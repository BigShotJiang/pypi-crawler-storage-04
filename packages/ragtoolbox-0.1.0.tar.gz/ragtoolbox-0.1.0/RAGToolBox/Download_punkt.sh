#!/bin/bash

python -c "import nltk; nltk.download('punkt_tab'); nltk.download('punkt_tab')"
