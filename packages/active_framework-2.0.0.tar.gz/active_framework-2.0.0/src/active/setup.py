# from setuptools import setup
# setup(
#     name='active',
#     version='0.0.1',
#     entry_points={
#         'console_scripts': [
#             'active=active:run'
#         ]
#     }
# )