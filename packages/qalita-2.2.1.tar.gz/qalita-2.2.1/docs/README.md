# QALITA Command Line Interface (CLI)

<div style="text-align:center;">
<img width="250px" height="auto" src="https://cloud.platform.qalita.io/logo.svg" style="max-width:250px;"/>
</div>

QALITA Command Line Interface (CLI) is a tool intended to be used by Data Engineers who setup's QALITA Platform's agents, sources and assets.

It gives easy to use command to help them make an up & running qalita platform's environment in no time.

Find the full documentation [in the online documentation](https://doc.qalita.io/docs/cli)