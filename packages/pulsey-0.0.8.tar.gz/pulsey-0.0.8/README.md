# PULSEY

A python package for modeling stellar pulsation. Now updated with JAX and JAXoplanet implementation.