# xhs-mcp-cli

[![PyPI - Version](https://img.shields.io/pypi/v/xhs-mcp-cli.svg)](https://pypi.org/project/xhs-mcp-cli)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/xhs-mcp-cli.svg)](https://pypi.org/project/xhs-mcp-cli)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install xhs-mcp-cli
```

## License

`xhs-mcp-cli` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
