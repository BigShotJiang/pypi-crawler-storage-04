## hvPlot.density

`hvPlot.density` is an alias for {meth}`hvPlot.kde <hvplot.hvPlot.kde>`.
