# Maintainers

For member policy, see the description at the top of [HoloViz/HoloViz - MEMBERS.md](https://github.com/holoviz/holoviz/blob/hvplot-gov/doc/governance/project-docs/MEMBERS.md).


The hvPlot Project’s equivalently named documents take precedence over any external materials referenced within this linked document above.


| **NAME** | **Role** | **GitHub Handle** |
| --- | --- | --- |
| Philipp Rudiger | Project Director | [philippjfr](https://github.com/philippjfr) |
| Maxime Liquet | Lead Maintainer | [maximlt](https://github.com/maximlt) |
| Simon Høxbro Hansen | Maintainer | [hoxbro](https://github.com/hoxbro) |
| Andrew Huang | Maintainer | [ahuang11](https://github.com/ahuang11) |
