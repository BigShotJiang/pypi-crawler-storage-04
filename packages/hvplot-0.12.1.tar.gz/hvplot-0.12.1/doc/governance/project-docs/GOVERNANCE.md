# Governance Policy


The "Project" is herein defined as the activities related to this specific GitHub repository [`hvPlot`](https://github.com/holoviz/hvplot), within the `HoloViz` GitHub Organization.


This Project adopts the governance specified by all of the numbered sections of [HoloViz/HoloViz - GOVERNANCE.md](https://github.com/holoviz/holoviz/blob/hvplot-gov/doc/governance/project-docs/GOVERNANCE.md).


The hvPlot Project’s equivalently named documents take precedence over any external materials referenced within this linked document above.
