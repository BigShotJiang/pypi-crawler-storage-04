import sqlite3
import psycopg2
import pymysql

def connect(db_type, **kw):
    if db_type == "sqlite":
        return sqlite3.connect(kw.get("database", ":memory:"))

    if db_type == "postgres":
        if "url" in kw:
            return psycopg2.connect(kw["url"])
        return psycopg2.connect(
            host=kw.get("host", "localhost"),
            user=kw["user"],
            password=kw["password"],
            dbname=kw["database"],
            port=kw.get("port", 5432)
        )

    if db_type == "mysql":
        return pymysql.connect(
            host=kw.get("host", "localhost"),
            user=kw["user"],
            password=kw["password"],
            database=kw["database"],
            port=kw.get("port", 3306)
        )

    # if db_type == "mongodb":
    #     client = pymongo.MongoClient(
    #         kw.get("url") or kw.get("host", "localhost"),
    #         port=kw.get("port", 27017),
    #         username=kw.get("user"),
    #         password=kw.get("password"),
    #         authSource=kw.get("authSource", "admin")
    #     )
    #     return client[kw["database"]]

    # raise ValueError(f"Unsupported DB type: {db_type}")