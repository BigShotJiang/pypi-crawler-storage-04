# multidb

A minimal universal database connection library for **SQLite, PostgreSQL, MySQL**.  
One simple function to connect to multiple databases without worrying about different drivers.


First, install the library (after building or from PyPI once published):

```bash
pip install multidb
