import os
from pathlib import Path

__version__ = "0.7.2"

project_dir = Path(os.path.abspath(__file__)).parents[1]
