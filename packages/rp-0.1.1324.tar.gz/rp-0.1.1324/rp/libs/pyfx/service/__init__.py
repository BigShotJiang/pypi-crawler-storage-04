"""
This is the service framework
"""
