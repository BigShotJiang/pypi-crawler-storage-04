# bpnet-lite
# Author: Jacob Schreiber
# Code adapted from Avanti Shrikumar and Ziga Avsec and Alex Tseng and many others

from .bpnet import BPNet
from .chrombpnet import ChromBPNet

__version__ = '0.9.4'
