from .core import MainyDB, MongoClient
from .core import Collection, Database
from .core import ObjectId

__version__ = '1.0.1'
__author__ = 'devid'

# Easter egg: Hidden message
__easter_egg__ = "You've found the secret message! MainyDB is watching you... always."