from .flink_mcp_server import main as run_mcp


def main():
	run_mcp()


if __name__ == "__main__":
	main()



