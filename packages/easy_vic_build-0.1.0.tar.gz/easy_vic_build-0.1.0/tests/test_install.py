# code: utf-8
# author: Xudong Zheng
# email: z786909151@163.com
import easy_vic_build
print(easy_vic_build.__version__)