# Gemini MCP

A Model Context Protocol (MCP) server for generating images using Gemini 2.5 Flash.

## Features

- 🎨 Generate images using Gemini 2.5 Flash model
- 🚀 Easy installation with `uvx gemini-mcp`
- 🔧 Compatible with Claude, Cursor, and other MCP clients
- 🛡️ Secure API key handling via environment variables
- ⚡ Fast streaming responses

## Installation

### Using uvx (recommended)

```bash
uvx gemini-mcp
```

### Using pip

```bash
pip install gemini-mcp
```

## Usage

### As MCP Server

Add to your MCP client configuration (e.g., Claude Desktop):

```json
{
  "mcpServers": {
    "gemini": {
      "command": "uvx",
      "args": ["gemini-mcp"],
      "env": {
        "GEMINI_API_KEY": "your-api-key-here"
      }
    }
  }
}
```

### Command Line

```bash
# Set your API key
export GEMINI_API_KEY="your-api-key-here"

# Run the MCP server
gemini-mcp
```

## Configuration

### Environment Variables

- `GEMINI_API_KEY`: Your API key for the tu-zi.com service (required)

### API Key

You can obtain an API key from [tu-zi.com](https://api.tu-zi.com). The key should have access to the `gemini-2.5-flash-image` model.

## Tools

### generate_image

Generate an image from a text prompt using Gemini 2.5 Flash.

**Parameters:**
- `prompt` (string, required): Detailed description of the image to generate
- `api_key` (string, optional): API key override (uses environment variable if not provided)

**Example:**
```json
{
  "name": "generate_image",
  "arguments": {
    "prompt": "A cute orange cat sitting under a cherry blossom tree, anime style, soft lighting"
  }
}
```

## Examples

### Using with Claude

```
Please use the generate_image tool to create a picture of a futuristic city at night with neon lights and flying cars.
```

### Using with Cursor

```
Generate an image: minimalist office design with natural lighting and plants
```

## Development

### Local Development

```bash
git clone https://github.com/yourusername/gemini-mcp
cd gemini-mcp
pip install -e .
```

### Testing

```bash
# Test the server
python -m gemini_mcp.server

# Or use the command directly
gemini-mcp
```

## License

MIT License

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.