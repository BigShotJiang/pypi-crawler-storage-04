To see the button you need to:

1.  Go to your user.
2.  Set debug mode.
3.  On Preferences tab, select a Home action.
4.  Refresh the screeen.

The button will be able on systray buttons.
