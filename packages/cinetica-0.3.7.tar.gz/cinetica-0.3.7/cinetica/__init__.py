from .movimiento_rectilineo import MovimientoRectilineo
from .movimiento_parabolico import MovimientoParabolico
from .movimiento_circular import MovimientoCircular

__version__ = "0.3.6"
