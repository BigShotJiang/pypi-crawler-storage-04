from collections.abc import Sequence

from rosy.types import Data

Args = Sequence[Data]
KWArgs = dict[str, Data]
