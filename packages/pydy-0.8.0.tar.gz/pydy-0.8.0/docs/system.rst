======
system
======

.. automodule:: pydy.system
   :members:
   :special-members: __init__
