API
---

All the module specific docs have some test cases, which will prove helpful in
understanding the usage of the particular module.

.. toctree::
   :maxdepth: 2

   python_api.rst
   javascript_api.rst
