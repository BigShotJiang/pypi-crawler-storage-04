Shapes
======

Shape
^^^^^

.. autoclass:: pydy.viz.shapes.Shape
   :members:

Cube
^^^^

.. autoclass:: pydy.viz.shapes.Cube
   :members:

Cylinder
^^^^^^^^

.. autoclass:: pydy.viz.shapes.Cylinder
   :members:

Cone
^^^^

.. autoclass:: pydy.viz.shapes.Cone
   :members:

Sphere
^^^^^^

.. autoclass:: pydy.viz.shapes.Sphere
   :members:

Circle
^^^^^^

.. autoclass:: pydy.viz.shapes.Circle
   :members:

Plane
^^^^^

.. autoclass:: pydy.viz.shapes.Plane
   :members:

Tetrahedron
^^^^^^^^^^^

.. autoclass:: pydy.viz.shapes.Tetrahedron
   :members:

Octahedron
^^^^^^^^^^

.. autoclass:: pydy.viz.shapes.Tetrahedron
   :members:

Icosahedron
^^^^^^^^^^^

.. autoclass:: pydy.viz.shapes.Icosahedron
   :members:

Torus
^^^^^

.. autoclass:: pydy.viz.shapes.Torus
   :members:

TorusKnot
^^^^^^^^^

.. autoclass:: pydy.viz.shapes.TorusKnot
   :members:

Tube
^^^^

.. autoclass:: pydy.viz.shapes.Tube
   :members:

