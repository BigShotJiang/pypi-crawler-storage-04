Cameras
=======

Perspective Camera
^^^^^^^^^^^^^^^^^^

.. autoclass:: pydy.viz.camera.PerspectiveCamera
   :members:

Orthographic Camera
^^^^^^^^^^^^^^^^^^^

.. autoclass:: pydy.viz.camera.OrthoGraphicCamera
   :members:
