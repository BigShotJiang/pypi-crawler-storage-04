BEIR is a heterogeneous benchmark containing diverse IR tasks. It also provides
a common and easy framework for evaluation of your NLP-based retrieval models
within the benchmark.
