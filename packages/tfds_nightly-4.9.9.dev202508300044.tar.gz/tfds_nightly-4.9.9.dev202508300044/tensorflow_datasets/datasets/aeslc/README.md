A collection of email messages of employees in the Enron Corporation.

There are two features:

  - email_body: email body text.
  - subject_line: email subject text.
