AccentDB is a multi-pairwise parallel corpus of structured and labelled accented
speech. It contains speech samples from speakers of 4 non-native accents of
English (8 speakers, 4 Indian languages); and also has a compilation of 4 native
accents of English (4 countries, 13 speakers) and a metropolitan Indian accent
(2 speakers). The dataset available here corresponds to release titled
accentdb_extended on https://accentdb.github.io/#dataset.
