Read the documentation here: <http://alisw.github.io/alibuild/>
