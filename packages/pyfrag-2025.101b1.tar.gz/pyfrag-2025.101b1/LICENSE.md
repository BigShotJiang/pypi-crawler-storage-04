Copyright (c) 2019 X. Sun, T. M. Soini, J. Poater, T. A. Hamlin and F. M. Bickelhaupt

PyFrag 2019 is an Open Source project supported by the Vrije Universiteit Amsterdam and Software for Chemistry & Materials BV (SCM). The terms of the [LGPL-3.0 license]* apply. As an exception to the LGPL-3.0 license, you agree to grant SCM a [BSD 3-Clause license]** to the contributions you commit on this Github or provide to SCM in another manner.

\* https://opensource.org/licenses/LGPL-3.0

** https://opensource.org/licenses/BSD-3-Clause

[LGPL-3.0 license]:  https://opensource.org/licenses/LGPL-3.0 "LGPL-3.0 license"
[BSD 3-Clause license]: https://opensource.org/licenses/BSD-3-Clause  "BSD 3-Clause license"
