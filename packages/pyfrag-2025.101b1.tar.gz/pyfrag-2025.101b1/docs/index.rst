.. qmworks documentation master file, created by
   sphinx-quickstart on Wed Dec 16 14:33:52 2015.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to PyFrag' documentation!
===================================

Contents:

.. toctree::
   :maxdepth: 2

   includeme
   install
   interactive_tutorial
   pyfragparameter
   standalone
   specialcalculation
   Further_reading
   documentation
   app

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

