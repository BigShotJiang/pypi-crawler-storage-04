Code Structure
=======================

For the advanced users who are interested and want to contribute to the code,

please check `Code Structure`_


.. _Code Structure: https://pyfragdocument.readthedocs.io/en/latest/annotated.html
