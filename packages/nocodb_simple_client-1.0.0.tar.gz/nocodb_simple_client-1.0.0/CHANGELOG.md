# CHANGELOG

<!-- version list -->

## v1.0.0 (2025-09-01)

### Bug Fixes

- Aktualisiere CI/CD-Konfiguration und füge Semantic Release hinzu
  ([`391515e`](https://github.com/bauer-group/LIB-NocoDB_SimpleClient/commit/391515ec2ee1420ed5bb7d3f39fbc822da8a01b6))

- Aktualisiere die Version der Dokumentations-Workflow-Vorlage auf v1.6.0
  ([`a171907`](https://github.com/bauer-group/LIB-NocoDB_SimpleClient/commit/a171907605c24f562922e1bd0faca80dbf701b43))

- Aktualisiere die Workflow-Vorlage auf den Hauptbranch
  ([`2f7855f`](https://github.com/bauer-group/LIB-NocoDB_SimpleClient/commit/2f7855f7a894cfe49fe966287f45c99a314d93fb))

- Entferne überflüssige Kommentarzeile aus validate.cmd
  ([`b863a80`](https://github.com/bauer-group/LIB-NocoDB_SimpleClient/commit/b863a809d3d31dcbffd016f8858a8d5108631f79))

- Entferne überflüssige Kommentarzeile aus validate.cmd
  ([`0d0f841`](https://github.com/bauer-group/LIB-NocoDB_SimpleClient/commit/0d0f841a4f9ee675929c3a9e43aa72817b52d68e))

- Entferne überflüssige Leerzeilen aus dem Skript validate.sh
  ([`7cd2222`](https://github.com/bauer-group/LIB-NocoDB_SimpleClient/commit/7cd2222026be4eafc378ce72a8a9f259b8a78df6))

- Füge fehlende Leerzeile am Ende der Datei validate.cmd hinzu
  ([`f277d2a`](https://github.com/bauer-group/LIB-NocoDB_SimpleClient/commit/f277d2aead2895a1eb95a3f231e929f9b9088e8d))

- Füge Leerzeilen zum Skript validate.sh hinzu
  ([`b32af02`](https://github.com/bauer-group/LIB-NocoDB_SimpleClient/commit/b32af02c0d6b55ddfa523c8e0ddf883ee5a06990))

- Füge Leerzeilen zum Skript validate.sh hinzu
  ([`b8f9903`](https://github.com/bauer-group/LIB-NocoDB_SimpleClient/commit/b8f9903c286556120b43ea439a90f6e27140f562))

- Füge Trennzeichen am Ende der Datei validate.cmd hinzu
  ([`9b8e942`](https://github.com/bauer-group/LIB-NocoDB_SimpleClient/commit/9b8e9425d65e01496ac24acf4259fba5138e27d9))

- Korrigiere den Namen der CI/CD-Pipeline für Konsistenz
  ([`e0efe91`](https://github.com/bauer-group/LIB-NocoDB_SimpleClient/commit/e0efe916f4a1f02d4b0366b8614e88cba506c803))

- Korrigiere die Schreibweise der PyPI-Version und aktualisiere das CI/CD-Badge
  ([`289bd1c`](https://github.com/bauer-group/LIB-NocoDB_SimpleClient/commit/289bd1c02f2456c1ee61b5d5cf1bec0a2362d1fd))

- Korrigiere Trennzeichen in der Hilfeausgabe des Makefiles
  ([`31472ec`](https://github.com/bauer-group/LIB-NocoDB_SimpleClient/commit/31472ecf255eb2adac0179ff8fb685c07da4b3b2))

- Verhindere automatische Übergänge von 0.x.x auf 1.0.0 in der Semantic Release-Konfiguration
  ([`4eee661`](https://github.com/bauer-group/LIB-NocoDB_SimpleClient/commit/4eee661b7fa53299888dc8a50e6c616155aa2ef5))

### Chores

- Aktualisiere Workflow-Dateien für bessere Organisation und Lesbarkeit
  ([`67c3211`](https://github.com/bauer-group/LIB-NocoDB_SimpleClient/commit/67c32111ce6769bba4f10dd7abfaf1a95ea2229a))

- Entferne die Sicherheitsrichtlinie aus dem Repository
  ([`4b6e2a4`](https://github.com/bauer-group/LIB-NocoDB_SimpleClient/commit/4b6e2a47e34dc2649277aa277b24753d6a2fca6e))

- Entferne die Sicherheitsrichtlinie aus dem Repository
  ([`8bf955b`](https://github.com/bauer-group/LIB-NocoDB_SimpleClient/commit/8bf955bd678ed01828d134c734d38bedfa4ab530))

### Documentation

- Aktualisiere README-Vorlage mit Unternehmensnamen und Repository-Informationen
  ([`b128ad8`](https://github.com/bauer-group/LIB-NocoDB_SimpleClient/commit/b128ad8bfc7cc81ebbe9f100d69988f0bbee15de))

- Aktualisiere Sicherheitsrichtlinie mit Emojis und verbesserten Formatierungen
  ([`6bf88ca`](https://github.com/bauer-group/LIB-NocoDB_SimpleClient/commit/6bf88ca06496f68b1b78dbecd10dd8537d1a4449))

- Aktualisiere Sicherheitsrichtlinie mit neuen Abschnitten und Emojis
  ([`d67b852`](https://github.com/bauer-group/LIB-NocoDB_SimpleClient/commit/d67b852be0efff82f0a6fb6660741ba1d28b5cb6))

- Ergänze Kommentar zur Standardzielbeschreibung im Makefile
  ([`55c7e81`](https://github.com/bauer-group/LIB-NocoDB_SimpleClient/commit/55c7e81ea06c23d8b8ba8109ec380dafeeb4dc36))

- Kommentiere nicht verwendete Paket-Ökosysteme in dependabot.yml aus
  ([`b04ca59`](https://github.com/bauer-group/LIB-NocoDB_SimpleClient/commit/b04ca598c3069c6f0a8b4ecaae3d7f0fe4f08e43))

- Update README.MD [automated]
  ([`f261815`](https://github.com/bauer-group/LIB-NocoDB_SimpleClient/commit/f26181503b8410929fd35fdefd96bc19062516d9))

- Update README.MD [automated]
  ([`8a9531b`](https://github.com/bauer-group/LIB-NocoDB_SimpleClient/commit/8a9531bff95ed53a69ded1539aa22c2bf29bfa69))

- Update SECURITY.MD (policy v1.0.0) [automated]
  ([`f2f0eef`](https://github.com/bauer-group/LIB-NocoDB_SimpleClient/commit/f2f0eef7e1a5cbfc7c83d469fdb44f9993390cdc))

- Update SECURITY.MD (policy v1.0.0) [automated]
  ([`3255297`](https://github.com/bauer-group/LIB-NocoDB_SimpleClient/commit/3255297f587f25257d3f846d73ec65cf5cd3549f))

- Update SECURITY.MD [automated]
  ([`99829a3`](https://github.com/bauer-group/LIB-NocoDB_SimpleClient/commit/99829a32afddc3ea317be20658056fec8f4bd27d))

- Update SECURITY.MD [automated]
  ([`527a0d2`](https://github.com/bauer-group/LIB-NocoDB_SimpleClient/commit/527a0d26681329a340f2ca1e86255b3761a7105a))

### Features

- Füge CI/CD-Pipeline für automatische Releases hinzu
  ([`7687329`](https://github.com/bauer-group/LIB-NocoDB_SimpleClient/commit/768732956d0ae1d44de9efd45ca9f82d38ca1b62))

- Füge Gitleaks-Ignore-Datei hinzu, um spezifische Pfade von der Sicherheitsprüfung auszuschließen
  ([`fd4a5c6`](https://github.com/bauer-group/LIB-NocoDB_SimpleClient/commit/fd4a5c67050de14cdbf12b2c01516bc319d6753b))

- Füge Gitleaks-Konfigurationsdatei hinzu und entferne die Gitleaks-Ignore-Datei
  ([`dc37243`](https://github.com/bauer-group/LIB-NocoDB_SimpleClient/commit/dc372436ab5c3476f76e464cd5bc14b7708df9d7))


## v0.0.0 (2025-08-25)

- Initial Release
