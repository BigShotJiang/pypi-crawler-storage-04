ticklabel_fontsize = 6
axis_label_fontsize = 8
title_fontsize = 10
panel_letter_fontstyle = {'fontsize': 10,
                          'weight': 'bold'}
