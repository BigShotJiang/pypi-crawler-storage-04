"""Configuration package for LocalPort."""
