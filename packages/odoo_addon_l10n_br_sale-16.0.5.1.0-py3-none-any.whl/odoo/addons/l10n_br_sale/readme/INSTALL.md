Este módulo depende dos seguintes módulos:

- sale_management
- l10n_br_account
- l10n_br_fiscal
