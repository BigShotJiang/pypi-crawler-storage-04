# License AGPL-3 - See http://www.gnu.org/licenses/agpl-3.0.html

from . import test_l10n_br_sale
from . import test_l10n_br_sale_discount
from . import test_l10n_br_sale_sn
from . import test_l10n_br_sale_pricelist
from . import test_sale_order_report
