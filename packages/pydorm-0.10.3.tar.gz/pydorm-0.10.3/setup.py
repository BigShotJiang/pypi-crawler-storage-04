import setuptools

setuptools.setup(
    name="pydorm",
    version="0.10.3",
    description="A dynamic and lightweight Python orm framework",
    author="melon",
    packages=setuptools.find_packages(),
)
