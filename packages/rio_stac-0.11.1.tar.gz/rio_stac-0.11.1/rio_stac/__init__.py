"""rio-stac: Create STAC items from raster file."""

__version__ = "0.11.1"

from rio_stac.stac import create_stac_item  # noqa
