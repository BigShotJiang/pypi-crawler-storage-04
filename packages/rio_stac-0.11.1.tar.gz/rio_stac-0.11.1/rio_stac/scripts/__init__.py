"""rio-stac.scripts.cli."""
