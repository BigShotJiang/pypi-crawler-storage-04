"""
Main package for aiverify digital corruptions plugin.
"""
