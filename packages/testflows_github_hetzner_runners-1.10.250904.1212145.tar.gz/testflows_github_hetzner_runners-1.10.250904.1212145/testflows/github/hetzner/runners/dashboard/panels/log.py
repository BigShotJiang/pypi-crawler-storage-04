# Copyright 2025 Katteli Inc.
# TestFlows.com Open-Source Software Testing Framework (http://testflows.com)
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import streamlit as st
import os
from ...config import Config
from ...logger import decode_message
from .. import renderers
from ..colors import COLORS


def format_log(lines, columns, delimiter):
    """Format log lines for dashboard display.

    Args:
        lines: List of log lines to format
        columns: Dictionary mapping column names to (index, width) tuples
        delimiter: Column delimiter in the log line

    Returns:
        List of dictionaries containing formatted log entries
    """
    formatted_lines = []

    # Reverse lines to show most recent first
    for line in reversed(lines):
        # Split the line by delimiter and decode each part
        parts = line.strip().split(delimiter)
        if len(parts) < len(columns):  # Skip invalid lines
            continue

        # Decode all parts
        decoded_parts = [decode_message(part) for part in parts]

        # Format each column
        formatted_parts = {}
        for name, (index, _) in columns.items():
            value = decoded_parts[index]
            formatted_parts[name] = value

        formatted_lines.append(formatted_parts)

    return formatted_lines


def get_level_color(level):
    """Get color for log level.

    Args:
        level: Log level string

    Returns:
        str: Color code for the level
    """
    level_colors = {
        "DEBUG": COLORS["accent"],
        "INFO": COLORS["success"],
        "WARNING": COLORS["warning"],
        "ERROR": COLORS["error"],
        "CRITICAL": COLORS["error"],
    }
    return level_colors.get(level, COLORS["accent"])


def create_log_dataframe(formatted_lines):
    """Create a pandas DataFrame from formatted log lines.

    Args:
        formatted_lines: List of dictionaries containing formatted log entries

    Returns:
        pandas.DataFrame: DataFrame with log data
    """
    import pandas as pd

    # Convert to DataFrame
    df = pd.DataFrame(formatted_lines)

    # Combine date and time into one column
    if "date" in df.columns and "time" in df.columns:
        df["datetime"] = df["date"] + " " + df["time"]
        df = df.drop(["date", "time"], axis=1)

    # Reorder columns to put important ones first
    column_order = [
        "datetime",
        "level",
        "message",
        "run_id",
        "job_id",
        "server_name",
        "threadName",
        "funcName",
        "interval",
    ]
    existing_columns = [col for col in column_order if col in df.columns]
    other_columns = [col for col in df.columns if col not in column_order]

    # Reorder DataFrame
    df = df[existing_columns + other_columns]

    return df


def render(config: Config, num_lines: int = 200):
    """Render the log messages panel.

    Args:
        config: Configuration object containing logger settings
    """

    with renderers.errors("rendering log panel"):
        with st.container(border=True):
            # Add CSS styling for dataframe
            st.header(f"Log Messages")
            st.caption(f"Last {num_lines} lines")

            if config is None:
                st.warning("Configuration not available")
                return

            logger_format = config.logger_format
            rotating_logfile = config.logger_config["handlers"]["rotating_logfile"][
                "filename"
            ]

            columns = logger_format["columns"]
            delimiter = logger_format["delimiter"]

            # Read last 100 lines from log file
            if os.path.exists(rotating_logfile):

                # Add download button at the top for better visibility
                st.link_button(
                    "📥 Log File",
                    help="Download full log file",
                    url="/download/log",
                    type="secondary",
                )

                with open(rotating_logfile, "r") as f:
                    lines = f.readlines()[-num_lines:]

                # Format log lines
                formatted_lines = format_log(lines, columns, delimiter)

                # Create log dataframe
                if formatted_lines:
                    df = create_log_dataframe(formatted_lines)

                    # Display dataframe with sorting and filtering capabilities
                    st.dataframe(
                        df,
                        use_container_width=True,
                        height=800,
                        hide_index=True,
                        column_config={
                            "message": st.column_config.TextColumn(
                                "Message", width="large", help="Log message content"
                            ),
                            "level": st.column_config.TextColumn(
                                "Level", width="small", help="Log level"
                            ),
                            "datetime": st.column_config.DatetimeColumn(
                                "DateTime", width="medium", help="Log date and time"
                            ),
                        },
                    )
                else:
                    st.info("No log messages available")
            else:
                st.warning("Log file not found")
