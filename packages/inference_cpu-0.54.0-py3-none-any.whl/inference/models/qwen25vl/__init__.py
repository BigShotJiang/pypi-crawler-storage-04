from inference.models.qwen25vl.qwen25vl import LoRAQwen25VL, Qwen25VL
