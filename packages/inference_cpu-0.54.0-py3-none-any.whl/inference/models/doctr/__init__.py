from inference.models.doctr.doctr_model import DocTR
