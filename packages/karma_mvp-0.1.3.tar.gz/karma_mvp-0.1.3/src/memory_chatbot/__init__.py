"""Memory Chatbot - Three-layer memory architecture chatbot."""

__version__ = "0.1.3"
__author__ = "Memory Chatbot Team"
__description__ = "Three-layer memory chatbot with Global-Workspace-Session architecture"
