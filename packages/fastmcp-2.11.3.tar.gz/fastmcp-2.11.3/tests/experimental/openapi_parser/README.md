# OpenAPI Parser Experiment

Performance-optimized OpenAPI parser with better transitive reference resolution.

Enabled via `experimental.enable_new_openapi_parser = True`