# STADLE v0.8.0

Our STADLE platform is a paradigm-shifting technology for collaborative and continuous learning combining privacy-preserving frameworks.
STADLE platform stands for Scalable, Traceable, Adaptive, Distributed Learning platform for versatile ML applications.

The purpose of stadle-client (this package) is to allow agents to interface with the [STADLE Ops](https://stadle.ai/) platform in order to perform federated learning.

Please refer to the [documentation](https://stadle-documentation.readthedocs.io/en/latest/index.html) for information on using STADLE for FL.

## Contributing

Reach out with your issues or proposals to improve STADLE.

## Tech Support

Please reach out to our technical support team via [support@tie-set.com](support@tie-set.com).

## License

Any use and distribution of this code must be under the NDA with [TieSet Inc.](https://tie-set.com/)