class RouteNotFound(Exception):
    pass


class InvalidMessage(Exception):
    pass