from .. import __version__


def main(**kwargs):
    print('Aloha! version: %s' % __version__)
