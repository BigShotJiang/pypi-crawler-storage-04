\# mtcli-atr

&nbsp; 

Plugin mtcli que adiciona o comando atr do indicador ATR (Average True Range).

&nbsp; 

---

&nbsp; 

\## Instalação

&nbsp; 

```cmd

pip install mtcli-atr

```



