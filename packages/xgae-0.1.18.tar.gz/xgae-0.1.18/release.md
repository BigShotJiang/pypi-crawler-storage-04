# Release Changelog
## [0.1.18] - 2025-9-3
### Added
- Support Agent tools


## [0.1.17] - 2025-9-1
### Target
- Saved for XGATaskEngine base version
### Changed
- Delete StreamTaskResponser tool_exec_on_stream model code


## [0.1.15] - 2025-9-1
### Target
- Saved for StreamResponser tool_exec_on_stream mode, next release will be abolished
### Changed
- Refact TaskResponseProcessor, XGATaskEngine
### Fixed
- Fix finish_reason judge logic


## [0.1.14] - 2025-8-31
### Target
- First complete version is merged 
### Changed
- StreamTaskResponser first version

## [0.1.10] - 2025-8-28
### Target
- NonStream mode release is completed
### Changed
- StreamTaskResponser is original
- NonStreamTaskResponser first version is completed 
- Langfuse use 2.x, match for LiteLLM package

## [0.1.7] - 2025-8-25
### Target
- Langfuse use 3.x package