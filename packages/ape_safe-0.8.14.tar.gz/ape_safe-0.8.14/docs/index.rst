.. dynamic-toc-tree::
    :userguides:
        - quickstart
        - transactions
        - safe_management
        - multisend
        - modules
    :commands:
        - mgmt
        - pending
        - delegates
        - modules
