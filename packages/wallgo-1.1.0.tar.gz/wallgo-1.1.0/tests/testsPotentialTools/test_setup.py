"""Basic test of imports and setup"""


def test_importPotentialTools() -> None:
    """Testing import of PotentialTools from WallGo"""
    from WallGo import PotentialTools
