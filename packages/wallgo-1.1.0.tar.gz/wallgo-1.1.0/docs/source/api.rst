.. DO NOT DELETE THIS FILE. It is neccessary to build the _autosummary.

.. autosummary::
   :toctree: _autosummary
   :template: custom-module-template.rst
   :recursive:

    WallGo
