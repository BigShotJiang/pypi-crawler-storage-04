======================================
License
======================================

.. highlight:: none

.. include:: ../../LICENSE
    :literal:
