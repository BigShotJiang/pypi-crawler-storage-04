======================================
Two Higgs Doublet Model
======================================

.. literalinclude:: ../../../Models/InertDoubletModel/inertDoubletModel.py
   :language: py