================================================
Singlet Scalar Extension: Collisions Definitions
================================================

.. literalinclude:: ../../../Models/SingletStandardModel_Z2/exampleCollisionDefs.py
    :language: py
