===============================================
Singlet Scalar Extension: Thermodynamics Output
===============================================

.. literalinclude:: ../../../Models/SingletStandardModel_Z2/exampleOutputThermodynamics.py
   :language: py