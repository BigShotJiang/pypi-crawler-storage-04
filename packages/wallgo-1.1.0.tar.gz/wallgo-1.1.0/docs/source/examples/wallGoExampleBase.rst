======================================
Example base
======================================

.. literalinclude:: ../../../Models/wallGoExampleBase.py
   :language: py