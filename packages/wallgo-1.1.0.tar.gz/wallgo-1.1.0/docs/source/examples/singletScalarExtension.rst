======================================
Singlet Scalar Extension
======================================

.. literalinclude:: ../../../Models/SingletStandardModel_Z2/singletStandardModelZ2.py
   :language: py