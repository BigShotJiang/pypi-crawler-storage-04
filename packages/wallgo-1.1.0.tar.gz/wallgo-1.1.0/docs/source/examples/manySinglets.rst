======================================
Many Singlet Scalars Extension
======================================

.. literalinclude:: ../../../Models/ManySinglets/manySinglets.py
   :language: py