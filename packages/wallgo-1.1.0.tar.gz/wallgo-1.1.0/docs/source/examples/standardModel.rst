======================================
Standard Model
======================================

.. literalinclude:: ../../../Models/StandardModel/standardModel.py
   :language: py