======================================
Contact
======================================

If you find any bugs, or have any suggestions for features, please raise an
issue on the `WallGo git repo <https://github.com/Wall-Go/WallGo>`_.

Or, if you prefer to get into contact directly, feel free to send us an email:

    | andreas.ekstedt@physics.uu.se
    | oliver.gould@nottingham.ac.uk
    | joonas.hirvonen@nottingham.ac.uk
    | benoit.laurent@mail.mcgill.ca
    | lauri.b.niemi@helsinki.fi
    | philipp.schicho@unige.ch
    | jorinde.van.de.vis@cern.ch

|