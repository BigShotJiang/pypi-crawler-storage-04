from .initFuncGen import *
from .initFuncGen import get_for_all_tabs
