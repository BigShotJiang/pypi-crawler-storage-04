class ConfException(AttributeError):
    pass
