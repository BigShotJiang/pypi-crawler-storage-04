from fastmcp.utilities.logging import get_logger

BASE_LOGGER = get_logger("fso")
