from magika import Magika


def init_magika() -> Magika:
    return Magika()
