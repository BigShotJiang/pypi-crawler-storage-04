app_name = "djangocms_blog"
urlpatterns = []