
.. _related_posts:

#############
Related posts
#############

To each post a number of (sortable) related posts can be attached.

The default template implementation shows them a the bottom of the post detail,
but it can be customized.
