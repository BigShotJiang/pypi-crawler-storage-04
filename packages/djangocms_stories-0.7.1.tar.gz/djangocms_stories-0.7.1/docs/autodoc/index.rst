.. _autodoc:

#################
API Documentation
#################


.. toctree::
   :maxdepth: 3

   admin
   menu
   models
   plugins
   views
