.. _settings:

#############
Configuration
#############

Django settings
###############

.. automodule:: djangocms_stories.settings
    :members:
    :private-members:

Per-apphook settings
####################

.. autoclass:: djangocms_stories.cms_appconfig.StoriesConfig
    :members:
    :private-members:
