from ya_market_api.campaign.dataclass.campaign_list import (
	Request as CampaignListRequest, Response as CampaignListResponse,
)


__all__ = ["CampaignListRequest", "CampaignListResponse"]
