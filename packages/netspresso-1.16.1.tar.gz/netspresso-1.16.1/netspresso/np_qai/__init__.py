from qai_hub import Device

__all__ = ["Device"]
