from .model import ModelInterface
from .task import TaskInterface

__all__ = [TaskInterface, ModelInterface]
