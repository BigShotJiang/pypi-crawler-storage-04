from netspresso.profiler.profiler import Profiler

__all__ = ["Profiler"]
