from __future__ import annotations

import setuptools

setuptools.setup()
