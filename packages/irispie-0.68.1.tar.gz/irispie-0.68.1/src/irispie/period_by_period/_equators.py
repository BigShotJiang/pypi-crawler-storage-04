"""
Equators for dynamic period-by-period systems
"""


#[
from __future__ import annotations

from ..equators import plain as _plain
#]


class Equator(_plain.PlainEquator, ):
    pass

