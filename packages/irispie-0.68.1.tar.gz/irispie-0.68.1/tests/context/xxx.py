
import numpy as np

def cdf(a, b):
    return np.log(a) + np.log(b)

