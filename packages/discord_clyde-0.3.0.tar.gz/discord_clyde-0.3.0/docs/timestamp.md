::: clyde.timestamp
