class SimpleClass:
    def __init__(self, value=42):
        self.value = value
    
    def get_value(self):
        return self.value

def simple_function(x):
    return x * 2