# nested package for testing deep imports
# simulates packages like binaryninja.mediumlevelil.instruction

def top_level_func():
    return "top level"

TOP_LEVEL_VAR = "nested package root"