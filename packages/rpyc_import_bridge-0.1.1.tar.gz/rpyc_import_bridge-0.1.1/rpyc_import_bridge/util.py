def log(msg: str) -> None:
    print(f"[rpyc_import_bridge] {msg}")
