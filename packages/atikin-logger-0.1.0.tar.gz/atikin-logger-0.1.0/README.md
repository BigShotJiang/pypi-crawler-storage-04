# 🚀 Atikin Logger

A lightweight and beginner-friendly Python logging library with colored output.  
Easily track your application's flow with clean, timestamped log messages. Created by: Atikin Verse.

![Python Version](https://img.shields.io/badge/python-3.6%2B-blue)
![License](https://img.shields.io/badge/license-MIT-green)
![PyPI](https://img.shields.io/badge/pypi-v0.1.0-orange)
![Contributions welcome](https://img.shields.io/badge/contributions-welcome-brightgreen)

---

## ✨ Features

- 🎨 **Colored console output** – Different colors for each log level  
- ⏰ **Automatic timestamps** – Every log includes precise timing  
- 📁 **File logging** – Optional log saving to files  
- 🪶 **Lightweight** – Zero external dependencies  
- 🚀 **Simple setup** – One-line import and ready to use  
- 🔧 **Customizable** – Configure colors, files, and formats  

---

## 📦 Installation

```bash
pip install atikin-logger
````

---

## 🎯 Quick Start

```python
from atikin_logger import log

log.info("Application started successfully")
log.success("User authentication completed")
log.warning("Disk space is running low")
log.error("Failed to connect to database")
log.debug("Variable x = 42")
```

**Console Output (with colors ✨):**

```
[2025-08-28 14:20:11] [INFO] Application started successfully
[2025-08-28 14:20:11] [SUCCESS] User authentication completed
[2025-08-28 14:20:11] [WARNING] Disk space is running low
[2025-08-28 14:20:11] [ERROR] Failed to connect to database
[2025-08-28 14:20:11] [DEBUG] Variable x = 42
```

---

## 🛠 Advanced Usage

### Custom Logger Instance (File Logging)

```python
from atikin_logger import Logger

log = Logger(log_file="logs/app.log")
log.info("This message appears in console and saves to file")
log.error("Error details are also saved for debugging")
```

### Disable Colors

```python
from atikin_logger import Logger

log = Logger(use_colors=False)
log.info("This message has no colors")
```

### Multiple Logger Instances

```python
from atikin_logger import Logger

db_logger = Logger(log_file="logs/database.log")
api_logger = Logger(log_file="logs/api.log")

db_logger.info("Database connection established")
api_logger.debug("API request received: /users")
```

---

## 📚 API Reference

### Logger Class

```python
Logger(log_file=None, use_colors=True)
```

**Parameters:**

* `log_file (str, optional)` – Save logs to a file if provided.
* `use_colors (bool)` – Enable/disable colored output (default: True).

### Log Methods

| Method          | Description            | Color     |
| --------------- | ---------------------- | --------- |
| `log.info()`    | Informational messages | 🔵 Blue   |
| `log.success()` | Success notifications  | 🟢 Green  |
| `log.warning()` | Warning messages       | 🟡 Yellow |
| `log.error()`   | Error reports          | 🔴 Red    |
| `log.debug()`   | Debug information      | 🟣 Purple |

---

## 🧪 Examples

### Example 1 – Basic Application Logging

```python
from atikin_logger import log

def main():
    log.info("Starting application...")
    try:
        log.success("Application started successfully")
    except Exception as e:
        log.error(f"Application failed: {str(e)}")
    log.info("Application shutdown")

if __name__ == "__main__":
    main()
```

### Example 2 – Web Server Logging

```python
from atikin_logger import Logger

server_log = Logger(log_file="logs/server.log")

def handle_request(request):
    server_log.info(f"Request received: {request.path}")
    if request.method == "POST":
        server_log.debug(f"POST data: {request.data}")
    server_log.success("Request processed successfully")
```

### Example 3 – Error Tracking

```python
from atikin_logger import log

def process_data(data):
    try:
        result = complex_operation(data)
        log.success("Data processed successfully")
        return result
    except ValueError as e:
        log.warning(f"Data validation issue: {e}")
        return None
    except Exception as e:
        log.error(f"Unexpected error in process_data: {e}")
        raise
```

---

## ❓ FAQ

**Q: Works on all OS?**
A: ✅ Yes, Windows, macOS, Linux. Colors auto-disable if not supported.

**Q: Custom log format?**
A: 🚧 Currently `[timestamp] [LEVEL] message`. Customization planned.

**Q: Disable all logging?**
A: Wrap log calls in a condition.

**Q: Compatible with Python’s built-in logging?**
A: ✅ Yes, it’s standalone and non-conflicting.

---

## 🤝 Contributing

1. Fork repo
2. Create branch: `git checkout -b feature/awesome`
3. Commit changes: `git commit -m 'Add awesome feature'`
4. Push branch: `git push origin feature/awesome`
5. Open Pull Request

---

## 📄 License

Licensed under the **MIT License** – see [LICENSE](LICENSE).

---

## 🐛 Bug Reports

Please open an issue with:

* Description of bug
* Steps to reproduce
* Expected behavior
* Python version & OS

---

## 🌟 Star History

If you find this project useful, please give it a ⭐ on GitHub!

---

## 📞 Support

* Open an issue on GitHub
* Or contact: **[atikinverse@gmail.com](mailto:atikinverse@gmail.com)**

---

## 🌐 Follow Us

| Platform  | Username    |
| --------- | ----------- |
| Facebook  | atikinverse |
| Instagram | atikinverse |
| LinkedIn  | atikinverse |
| Twitter/X | atikinverse |
| Threads   | atikinverse |
| Pinterest | atikinverse |
| Quora     | atikinverse |
| Reddit    | atikinverse |
| Tumblr    | atikinverse |
| Snapchat  | atikinverse |
| Skype     | atikinverse |
| GitHub    | atikinverse |

---

<div align="center">  
Made with ❤️ by the **Atikin Logger Team** 🚀  
</div>
```

