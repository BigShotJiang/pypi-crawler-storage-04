from agrigee_lite.sat.dem import ANADEM
from agrigee_lite.sat.embeddings import SatelliteEmbedding
from agrigee_lite.sat.landsat import Landsat5, Landsat7, Landsat8, Landsat9
from agrigee_lite.sat.mapbiomas import MapBiomas
from agrigee_lite.sat.modis import Modis, Modis8Days
from agrigee_lite.sat.palsar import PALSAR2ScanSAR
from agrigee_lite.sat.sentinel1 import Sentinel1
from agrigee_lite.sat.sentinel2 import Sentinel2
from agrigee_lite.sat.soil import WRBSoilClasses
from agrigee_lite.sat.unified_satellite import UnifiedSatellite
