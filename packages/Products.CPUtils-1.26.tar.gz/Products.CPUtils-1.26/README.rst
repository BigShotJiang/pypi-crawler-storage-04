====================
Products.CPUtils
====================

This products contains useful external methods and some monkey patches.

Installation
============

Go in ZMI

1) Add an External Method with :

  - id = cputils_install
  - title = cputils_install
  - Module Name = Products.CPUtils.utils
  - Function Name = install

2) click on test to execute added method. This adds all main external methods of utils.py, prefixed by "cputils\_".
