This product contains utilities like :

* some scripts in Extensions. They can be called as external method in the zmi

* 


Installation

 a) get the product and place it in the Products folder

 b) in your plone instance, go to the Plone configuration area

 c) click on "Add/Remove Products"

 d) select the "CPUtils" product and click on "Install" button

