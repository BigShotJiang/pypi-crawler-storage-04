#!/bin/sh
/opt/ArchGenXML/ArchGenXML.py --cfg generate.conf CPUtils.zargo -o ..
