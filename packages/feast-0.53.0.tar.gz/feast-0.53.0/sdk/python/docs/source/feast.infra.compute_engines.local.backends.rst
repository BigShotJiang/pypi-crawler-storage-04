feast.infra.compute\_engines.local.backends package
===================================================

Submodules
----------

feast.infra.compute\_engines.local.backends.base module
-------------------------------------------------------

.. automodule:: feast.infra.compute_engines.local.backends.base
   :members:
   :undoc-members:
   :show-inheritance:

feast.infra.compute\_engines.local.backends.factory module
----------------------------------------------------------

.. automodule:: feast.infra.compute_engines.local.backends.factory
   :members:
   :undoc-members:
   :show-inheritance:

feast.infra.compute\_engines.local.backends.pandas\_backend module
------------------------------------------------------------------

.. automodule:: feast.infra.compute_engines.local.backends.pandas_backend
   :members:
   :undoc-members:
   :show-inheritance:

feast.infra.compute\_engines.local.backends.polars\_backend module
------------------------------------------------------------------

.. automodule:: feast.infra.compute_engines.local.backends.polars_backend
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: feast.infra.compute_engines.local.backends
   :members:
   :undoc-members:
   :show-inheritance:
