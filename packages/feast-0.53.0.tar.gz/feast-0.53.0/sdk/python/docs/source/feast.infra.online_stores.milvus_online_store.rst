feast.infra.online\_stores.milvus\_online\_store package
========================================================

Submodules
----------

feast.infra.online\_stores.milvus\_online\_store.milvus module
--------------------------------------------------------------

.. automodule:: feast.infra.online_stores.milvus_online_store.milvus
   :members:
   :undoc-members:
   :show-inheritance:

feast.infra.online\_stores.milvus\_online\_store.milvus\_repo\_configuration module
-----------------------------------------------------------------------------------

.. automodule:: feast.infra.online_stores.milvus_online_store.milvus_repo_configuration
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: feast.infra.online_stores.milvus_online_store
   :members:
   :undoc-members:
   :show-inheritance:
