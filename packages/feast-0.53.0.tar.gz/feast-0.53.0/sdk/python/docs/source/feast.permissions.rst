feast.permissions package
=========================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   feast.permissions.auth
   feast.permissions.client
   feast.permissions.server

Submodules
----------

feast.permissions.action module
-------------------------------

.. automodule:: feast.permissions.action
   :members:
   :undoc-members:
   :show-inheritance:

feast.permissions.auth\_model module
------------------------------------

.. automodule:: feast.permissions.auth_model
   :members:
   :undoc-members:
   :show-inheritance:

feast.permissions.decision module
---------------------------------

.. automodule:: feast.permissions.decision
   :members:
   :undoc-members:
   :show-inheritance:

feast.permissions.decorator module
----------------------------------

.. automodule:: feast.permissions.decorator
   :members:
   :undoc-members:
   :show-inheritance:

feast.permissions.enforcer module
---------------------------------

.. automodule:: feast.permissions.enforcer
   :members:
   :undoc-members:
   :show-inheritance:

feast.permissions.matcher module
--------------------------------

.. automodule:: feast.permissions.matcher
   :members:
   :undoc-members:
   :show-inheritance:

feast.permissions.oidc\_service module
--------------------------------------

.. automodule:: feast.permissions.oidc_service
   :members:
   :undoc-members:
   :show-inheritance:

feast.permissions.permission module
-----------------------------------

.. automodule:: feast.permissions.permission
   :members:
   :undoc-members:
   :show-inheritance:

feast.permissions.policy module
-------------------------------

.. automodule:: feast.permissions.policy
   :members:
   :undoc-members:
   :show-inheritance:

feast.permissions.security\_manager module
------------------------------------------

.. automodule:: feast.permissions.security_manager
   :members:
   :undoc-members:
   :show-inheritance:

feast.permissions.user module
-----------------------------

.. automodule:: feast.permissions.user
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: feast.permissions
   :members:
   :undoc-members:
   :show-inheritance:
