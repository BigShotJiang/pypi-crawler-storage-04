feast.api package
=================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   feast.api.registry

Module contents
---------------

.. automodule:: feast.api
   :members:
   :undoc-members:
   :show-inheritance:
