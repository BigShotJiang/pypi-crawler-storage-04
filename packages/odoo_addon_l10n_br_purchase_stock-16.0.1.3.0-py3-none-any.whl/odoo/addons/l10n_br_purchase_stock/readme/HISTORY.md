## 16.0.1.0.0 (2025-01-22)

- \[MIG\] Migração para a v16

## 14.0.1.0.0 (2022-09-16)

- \[MIG\] Migração para a v14

## 12.0.1.0.0 (2020-04-27)

- \[REF\] Separado o módulo l10n_br_purchase em dois l10n_br_purchase e
  l10n_br_purchase_stock.
