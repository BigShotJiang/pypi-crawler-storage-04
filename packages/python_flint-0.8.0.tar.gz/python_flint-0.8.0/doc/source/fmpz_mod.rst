**fmpz_mod** -- integers mod n
===============================================================================

.. autoclass :: flint.fmpz_mod_ctx
  :members:
  :inherited-members:
  :undoc-members:

.. autoclass :: flint.fmpz_mod
  :members:
  :inherited-members:
  :undoc-members:

