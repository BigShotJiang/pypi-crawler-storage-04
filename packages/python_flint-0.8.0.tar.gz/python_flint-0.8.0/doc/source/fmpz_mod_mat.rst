**fmpz_mod_mat** -- matrices over integers mod n for arbitrary n
===============================================================================

.. autoclass :: flint.fmpz_mod_mat
  :members:
  :inherited-members:
  :undoc-members:

