**fmpz_mod_poly** -- polynomials over integers mod n
===============================================================================

.. autoclass :: flint.fmpz_mod_poly_ctx
  :members:
  :inherited-members:
  :undoc-members:

.. autoclass :: flint.fmpz_mod_poly
  :members:
  :inherited-members:
  :undoc-members:

