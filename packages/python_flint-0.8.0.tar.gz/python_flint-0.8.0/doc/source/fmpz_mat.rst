**fmpz_mat** -- matrices over integers
===============================================================================

.. autoclass :: flint.fmpz_mat
  :members:
  :inherited-members:
  :undoc-members:

