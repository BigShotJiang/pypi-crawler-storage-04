**dirichlet_char** -- Dirichlet characters
===============================================================================

.. autoclass :: flint.dirichlet_group
  :members:
  :inherited-members:
  :undoc-members:

.. autoclass :: flint.dirichlet_char
  :members:
  :inherited-members:
  :undoc-members:

