**acb_poly** -- polynomials over complex numbers
===============================================================================

.. autoclass :: flint.acb_poly
  :members:
  :inherited-members:
  :undoc-members:

