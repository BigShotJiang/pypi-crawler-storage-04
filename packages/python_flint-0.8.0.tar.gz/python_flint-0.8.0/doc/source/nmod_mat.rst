**nmod_mat** -- matrices over integers mod n
===============================================================================

.. autoclass :: flint.nmod_mat
  :members:
  :inherited-members:
  :undoc-members:

