**arb_mat** -- matrices over real numbers
===============================================================================

.. autoclass :: flint.arb_mat
  :members:
  :inherited-members:
  :undoc-members:

