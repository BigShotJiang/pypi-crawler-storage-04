**nmod** -- integers mod wordsize n
===============================================================================

.. autoclass :: flint.nmod
  :members:
  :inherited-members:
  :undoc-members:

