**arb_poly** -- polynomials over real numbers
===============================================================================

.. autoclass :: flint.arb_poly
  :members:
  :inherited-members:
  :undoc-members:

