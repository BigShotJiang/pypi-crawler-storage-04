**acb_mat** -- matrices over complex numbers
===============================================================================

.. autoclass :: flint.acb_mat
  :members:
  :inherited-members:
  :undoc-members:

