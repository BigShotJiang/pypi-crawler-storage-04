**fmpq** -- rational numbers
===============================================================================

.. autoclass :: flint.fmpq
  :members:
  :inherited-members:
  :undoc-members:

