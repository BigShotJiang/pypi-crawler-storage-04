**fq_default_poly** -- polynomials over finite fields
===============================================================================

.. autoclass :: flint.fq_default_poly_ctx
  :members:
  :inherited-members:
  :undoc-members:

.. autoclass :: flint.fq_default_poly
  :members:
  :inherited-members:
  :undoc-members:

