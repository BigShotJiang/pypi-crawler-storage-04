**nmod_mpoly** -- multivariate polynomials over the integers mod n (word-size n)
================================================================================

.. autoclass :: flint.nmod_mpoly_ctx
  :members:
  :inherited-members:
  :undoc-members:

.. autoclass :: flint.nmod_mpoly
  :members:
  :inherited-members:
  :undoc-members:

.. autoclass :: flint.nmod_mpoly_vec
  :members:
  :inherited-members:
  :undoc-members:

