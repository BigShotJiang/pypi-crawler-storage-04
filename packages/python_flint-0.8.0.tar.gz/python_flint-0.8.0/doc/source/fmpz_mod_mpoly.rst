**fmpz_mod_mpoly** -- multivariate polynomials over the integers mod n
===============================================================================

.. autoclass :: flint.fmpz_mod_mpoly_ctx
  :members:
  :inherited-members:
  :undoc-members:

.. autoclass :: flint.fmpz_mod_mpoly
  :members:
  :inherited-members:
  :undoc-members:

.. autoclass :: flint.fmpz_mod_mpoly_vec
  :members:
  :inherited-members:
  :undoc-members:

