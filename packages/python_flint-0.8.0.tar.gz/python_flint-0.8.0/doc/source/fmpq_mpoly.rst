**fmpq_mpoly** -- multivariate polynomials over the rational numbers
===============================================================================

.. autoclass :: flint.fmpq_mpoly_ctx
  :members:
  :inherited-members:
  :undoc-members:

.. autoclass :: flint.fmpq_mpoly
  :members:
  :inherited-members:
  :undoc-members:

.. autoclass :: flint.fmpq_mpoly_vec
  :members:
  :inherited-members:
  :undoc-members:

