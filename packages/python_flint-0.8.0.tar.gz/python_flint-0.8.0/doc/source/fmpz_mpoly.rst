**fmpz_mpoly** -- multivariate polynomials over the integers
===============================================================================

.. autoclass :: flint.fmpz_mpoly_ctx
  :members:
  :inherited-members:
  :undoc-members:

.. autoclass :: flint.fmpz_mpoly
  :members:
  :inherited-members:
  :undoc-members:

.. autoclass :: flint.fmpz_mpoly_vec
  :members:
  :inherited-members:
  :undoc-members:

