# AnimePics

A fun Python package that fetches random anime pictures using a free public API.

## Installation
```bash
pip install animepics
