from .core import get_random_anime_pic
