# Django imports
from django.apps import AppConfig

__all__ = ["wagtail_parlerTestsConfig"]


class wagtail_parlerTestsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "wagtail_parler_tests"
