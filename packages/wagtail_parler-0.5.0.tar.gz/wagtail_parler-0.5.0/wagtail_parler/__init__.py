__version__ = "0.5.0"
default_app_config = "wagtail_parler.apps.WagtailParlerConfig"
