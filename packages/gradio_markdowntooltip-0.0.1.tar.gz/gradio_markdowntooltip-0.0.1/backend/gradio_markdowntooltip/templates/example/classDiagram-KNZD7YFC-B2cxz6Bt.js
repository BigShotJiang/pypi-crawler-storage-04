import { s as r, c as s, a as e, C as t } from "./chunk-K7UQS3LO-tyN4dn2E.js";
import { _ as l } from "./mermaid.core-KthD0Gaq.js";
var d = {
  parser: e,
  get db() {
    return new t();
  },
  renderer: s,
  styles: r,
  init: /* @__PURE__ */ l((a) => {
    a.class || (a.class = {}), a.class.arrowMarkerAbsolute = a.arrowMarkerAbsolute;
  }, "init")
};
export {
  d as diagram
};
