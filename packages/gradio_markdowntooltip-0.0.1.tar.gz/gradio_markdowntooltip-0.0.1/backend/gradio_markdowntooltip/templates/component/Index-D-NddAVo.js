var Ia = Object.defineProperty;
var $n = (i) => {
  throw TypeError(i);
};
var Ra = (i, e, t) => e in i ? Ia(i, e, { enumerable: !0, configurable: !0, writable: !0, value: t }) : i[e] = t;
var M = (i, e, t) => Ra(i, typeof e != "symbol" ? e + "" : e, t), Ma = (i, e, t) => e.has(i) || $n("Cannot " + t);
var Cn = (i, e, t) => e.has(i) ? $n("Cannot add the same private member more than once") : e instanceof WeakSet ? e.add(i) : e.set(i, t);
var nt = (i, e, t) => (Ma(i, e, "access private method"), t);
const Oa = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], En = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
Oa.reduce(
  (i, { color: e, primary: t, secondary: n }) => ({
    ...i,
    [e]: {
      primary: En[e][t],
      secondary: En[e][n]
    }
  }),
  {}
);
function Pa(i) {
  i.addEventListener("click", e);
  async function e(t) {
    const n = t.composedPath(), [a] = n.filter(
      (r) => (r == null ? void 0 : r.tagName) === "BUTTON" && r.classList.contains("copy_code_button")
    );
    if (a) {
      let r = function(u) {
        u.style.opacity = "1", setTimeout(() => {
          u.style.opacity = "0";
        }, 2e3);
      };
      t.stopImmediatePropagation();
      const l = a.parentElement.innerText.trim(), o = Array.from(
        a.children
      )[1];
      await Na(l) && r(o);
    }
  }
  return {
    destroy() {
      i.removeEventListener("click", e);
    }
  };
}
async function Na(i) {
  let e = !1;
  if ("clipboard" in navigator)
    await navigator.clipboard.writeText(i), e = !0;
  else {
    const t = document.createElement("textarea");
    t.value = i, t.style.position = "absolute", t.style.left = "-999999px", document.body.prepend(t), t.select();
    try {
      document.execCommand("copy"), e = !0;
    } catch (n) {
      console.error(n), e = !1;
    } finally {
      t.remove();
    }
  }
  return e;
}
const it = (i) => typeof i == "number" ? i + "px" : i, {
  SvelteComponent: gu,
  append_hydration: vu,
  attr: Du,
  children: bu,
  claim_svg_element: wu,
  detach: yu,
  init: Fu,
  insert_hydration: ku,
  noop: $u,
  safe_not_equal: Cu,
  svg_element: Eu
} = window.__gradio__svelte__internal, {
  SvelteComponent: Au,
  append_hydration: Su,
  attr: xu,
  children: Bu,
  claim_svg_element: Tu,
  detach: qu,
  init: Lu,
  insert_hydration: zu,
  noop: Iu,
  safe_not_equal: Ru,
  svg_element: Mu
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ou,
  append_hydration: Pu,
  attr: Nu,
  children: Hu,
  claim_svg_element: ju,
  detach: Gu,
  init: Uu,
  insert_hydration: Vu,
  noop: Zu,
  safe_not_equal: Xu,
  svg_element: Wu
} = window.__gradio__svelte__internal, {
  SvelteComponent: Yu,
  append_hydration: Ku,
  attr: Qu,
  children: Ju,
  claim_svg_element: ec,
  detach: tc,
  init: nc,
  insert_hydration: ic,
  noop: ac,
  safe_not_equal: lc,
  svg_element: rc
} = window.__gradio__svelte__internal, {
  SvelteComponent: oc,
  append_hydration: sc,
  attr: uc,
  children: cc,
  claim_svg_element: _c,
  detach: dc,
  init: hc,
  insert_hydration: fc,
  noop: pc,
  safe_not_equal: mc,
  svg_element: gc
} = window.__gradio__svelte__internal, {
  SvelteComponent: vc,
  append_hydration: Dc,
  attr: bc,
  children: wc,
  claim_svg_element: yc,
  detach: Fc,
  init: kc,
  insert_hydration: $c,
  noop: Cc,
  safe_not_equal: Ec,
  svg_element: Ac
} = window.__gradio__svelte__internal, {
  SvelteComponent: Sc,
  append_hydration: xc,
  attr: Bc,
  children: Tc,
  claim_svg_element: qc,
  detach: Lc,
  init: zc,
  insert_hydration: Ic,
  noop: Rc,
  safe_not_equal: Mc,
  svg_element: Oc
} = window.__gradio__svelte__internal, {
  SvelteComponent: Pc,
  append_hydration: Nc,
  attr: Hc,
  children: jc,
  claim_svg_element: Gc,
  detach: Uc,
  init: Vc,
  insert_hydration: Zc,
  noop: Xc,
  safe_not_equal: Wc,
  svg_element: Yc
} = window.__gradio__svelte__internal, {
  SvelteComponent: Kc,
  append_hydration: Qc,
  attr: Jc,
  children: e_,
  claim_svg_element: t_,
  detach: n_,
  init: i_,
  insert_hydration: a_,
  noop: l_,
  safe_not_equal: r_,
  svg_element: o_
} = window.__gradio__svelte__internal, {
  SvelteComponent: s_,
  append_hydration: u_,
  attr: c_,
  children: __,
  claim_svg_element: d_,
  detach: h_,
  init: f_,
  insert_hydration: p_,
  noop: m_,
  safe_not_equal: g_,
  svg_element: v_
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ha,
  append_hydration: ja,
  attr: ee,
  children: An,
  claim_svg_element: Sn,
  detach: St,
  init: Ga,
  insert_hydration: Ua,
  noop: xt,
  safe_not_equal: Va,
  svg_element: xn
} = window.__gradio__svelte__internal;
function Za(i) {
  let e, t;
  return {
    c() {
      e = xn("svg"), t = xn("path"), this.h();
    },
    l(n) {
      e = Sn(n, "svg", {
        width: !0,
        height: !0,
        "stroke-width": !0,
        viewBox: !0,
        fill: !0,
        xmlns: !0,
        color: !0
      });
      var a = An(e);
      t = Sn(a, "path", {
        d: !0,
        stroke: !0,
        "stroke-width": !0,
        "stroke-linecap": !0,
        "stroke-linejoin": !0
      }), An(t).forEach(St), a.forEach(St), this.h();
    },
    h() {
      ee(t, "d", "M5 13L9 17L19 7"), ee(t, "stroke", "currentColor"), ee(t, "stroke-width", "1.5"), ee(t, "stroke-linecap", "round"), ee(t, "stroke-linejoin", "round"), ee(e, "width", "100%"), ee(e, "height", "100%"), ee(e, "stroke-width", "1.5"), ee(e, "viewBox", "0 0 24 24"), ee(e, "fill", "none"), ee(e, "xmlns", "http://www.w3.org/2000/svg"), ee(e, "color", "currentColor");
    },
    m(n, a) {
      Ua(n, e, a), ja(e, t);
    },
    p: xt,
    i: xt,
    o: xt,
    d(n) {
      n && St(e);
    }
  };
}
class Bn extends Ha {
  constructor(e) {
    super(), Ga(this, e, null, Za, Va, {});
  }
}
const {
  SvelteComponent: D_,
  append_hydration: b_,
  attr: w_,
  children: y_,
  claim_svg_element: F_,
  detach: k_,
  init: $_,
  insert_hydration: C_,
  noop: E_,
  safe_not_equal: A_,
  svg_element: S_
} = window.__gradio__svelte__internal, {
  SvelteComponent: Xa,
  append_hydration: Bt,
  attr: se,
  children: at,
  claim_svg_element: lt,
  detach: He,
  init: Wa,
  insert_hydration: Ya,
  noop: Tt,
  safe_not_equal: Ka,
  set_style: me,
  svg_element: rt
} = window.__gradio__svelte__internal;
function Qa(i) {
  let e, t, n, a;
  return {
    c() {
      e = rt("svg"), t = rt("g"), n = rt("path"), a = rt("path"), this.h();
    },
    l(r) {
      e = lt(r, "svg", {
        width: !0,
        height: !0,
        viewBox: !0,
        version: !0,
        xmlns: !0,
        "xmlns:xlink": !0,
        "xml:space": !0,
        stroke: !0,
        style: !0
      });
      var l = at(e);
      t = lt(l, "g", { transform: !0 });
      var o = at(t);
      n = lt(o, "path", { d: !0, style: !0 }), at(n).forEach(He), o.forEach(He), a = lt(l, "path", { d: !0, style: !0 }), at(a).forEach(He), l.forEach(He), this.h();
    },
    h() {
      se(n, "d", "M18,6L6.087,17.913"), me(n, "fill", "none"), me(n, "fill-rule", "nonzero"), me(n, "stroke-width", "2px"), se(t, "transform", "matrix(1.14096,-0.140958,-0.140958,1.14096,-0.0559523,0.0559523)"), se(a, "d", "M4.364,4.364L19.636,19.636"), me(a, "fill", "none"), me(a, "fill-rule", "nonzero"), me(a, "stroke-width", "2px"), se(e, "width", "100%"), se(e, "height", "100%"), se(e, "viewBox", "0 0 24 24"), se(e, "version", "1.1"), se(e, "xmlns", "http://www.w3.org/2000/svg"), se(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), se(e, "xml:space", "preserve"), se(e, "stroke", "currentColor"), me(e, "fill-rule", "evenodd"), me(e, "clip-rule", "evenodd"), me(e, "stroke-linecap", "round"), me(e, "stroke-linejoin", "round");
    },
    m(r, l) {
      Ya(r, e, l), Bt(e, t), Bt(t, n), Bt(e, a);
    },
    p: Tt,
    i: Tt,
    o: Tt,
    d(r) {
      r && He(e);
    }
  };
}
class Ja extends Xa {
  constructor(e) {
    super(), Wa(this, e, null, Qa, Ka, {});
  }
}
const {
  SvelteComponent: x_,
  append_hydration: B_,
  attr: T_,
  children: q_,
  claim_svg_element: L_,
  detach: z_,
  init: I_,
  insert_hydration: R_,
  noop: M_,
  safe_not_equal: O_,
  svg_element: P_
} = window.__gradio__svelte__internal, {
  SvelteComponent: N_,
  append_hydration: H_,
  attr: j_,
  children: G_,
  claim_svg_element: U_,
  detach: V_,
  init: Z_,
  insert_hydration: X_,
  noop: W_,
  safe_not_equal: Y_,
  svg_element: K_
} = window.__gradio__svelte__internal, {
  SvelteComponent: Q_,
  append_hydration: J_,
  attr: ed,
  children: td,
  claim_svg_element: nd,
  detach: id,
  init: ad,
  insert_hydration: ld,
  noop: rd,
  safe_not_equal: od,
  svg_element: sd
} = window.__gradio__svelte__internal, {
  SvelteComponent: ud,
  append_hydration: cd,
  attr: _d,
  children: dd,
  claim_svg_element: hd,
  detach: fd,
  init: pd,
  insert_hydration: md,
  noop: gd,
  safe_not_equal: vd,
  svg_element: Dd
} = window.__gradio__svelte__internal, {
  SvelteComponent: el,
  append_hydration: Tn,
  attr: ge,
  children: qt,
  claim_svg_element: Lt,
  detach: ot,
  init: tl,
  insert_hydration: nl,
  noop: zt,
  safe_not_equal: il,
  svg_element: It
} = window.__gradio__svelte__internal;
function al(i) {
  let e, t, n;
  return {
    c() {
      e = It("svg"), t = It("path"), n = It("path"), this.h();
    },
    l(a) {
      e = Lt(a, "svg", {
        xmlns: !0,
        viewBox: !0,
        color: !0,
        "aria-hidden": !0,
        width: !0,
        height: !0
      });
      var r = qt(e);
      t = Lt(r, "path", { fill: !0, d: !0 }), qt(t).forEach(ot), n = Lt(r, "path", { fill: !0, d: !0 }), qt(n).forEach(ot), r.forEach(ot), this.h();
    },
    h() {
      ge(t, "fill", "currentColor"), ge(t, "d", "M28 10v18H10V10h18m0-2H10a2 2 0 0 0-2 2v18a2 2 0 0 0 2 2h18a2 2 0 0 0 2-2V10a2 2 0 0 0-2-2Z"), ge(n, "fill", "currentColor"), ge(n, "d", "M4 18H2V4a2 2 0 0 1 2-2h14v2H4Z"), ge(e, "xmlns", "http://www.w3.org/2000/svg"), ge(e, "viewBox", "0 0 33 33"), ge(e, "color", "currentColor"), ge(e, "aria-hidden", "true"), ge(e, "width", "100%"), ge(e, "height", "100%");
    },
    m(a, r) {
      nl(a, e, r), Tn(e, t), Tn(e, n);
    },
    p: zt,
    i: zt,
    o: zt,
    d(a) {
      a && ot(e);
    }
  };
}
class qn extends el {
  constructor(e) {
    super(), tl(this, e, null, al, il, {});
  }
}
const {
  SvelteComponent: bd,
  append_hydration: wd,
  attr: yd,
  children: Fd,
  claim_svg_element: kd,
  detach: $d,
  init: Cd,
  insert_hydration: Ed,
  noop: Ad,
  safe_not_equal: Sd,
  svg_element: xd
} = window.__gradio__svelte__internal, {
  SvelteComponent: Bd,
  append_hydration: Td,
  attr: qd,
  children: Ld,
  claim_svg_element: zd,
  detach: Id,
  init: Rd,
  insert_hydration: Md,
  noop: Od,
  safe_not_equal: Pd,
  svg_element: Nd
} = window.__gradio__svelte__internal, {
  SvelteComponent: Hd,
  append_hydration: jd,
  attr: Gd,
  children: Ud,
  claim_svg_element: Vd,
  detach: Zd,
  init: Xd,
  insert_hydration: Wd,
  noop: Yd,
  safe_not_equal: Kd,
  svg_element: Qd
} = window.__gradio__svelte__internal, {
  SvelteComponent: Jd,
  append_hydration: eh,
  attr: th,
  children: nh,
  claim_svg_element: ih,
  detach: ah,
  init: lh,
  insert_hydration: rh,
  noop: oh,
  safe_not_equal: sh,
  svg_element: uh
} = window.__gradio__svelte__internal, {
  SvelteComponent: ch,
  append_hydration: _h,
  attr: dh,
  children: hh,
  claim_svg_element: fh,
  detach: ph,
  init: mh,
  insert_hydration: gh,
  noop: vh,
  safe_not_equal: Dh,
  svg_element: bh
} = window.__gradio__svelte__internal, {
  SvelteComponent: wh,
  append_hydration: yh,
  attr: Fh,
  children: kh,
  claim_svg_element: $h,
  detach: Ch,
  init: Eh,
  insert_hydration: Ah,
  noop: Sh,
  safe_not_equal: xh,
  svg_element: Bh
} = window.__gradio__svelte__internal, {
  SvelteComponent: Th,
  append_hydration: qh,
  attr: Lh,
  children: zh,
  claim_svg_element: Ih,
  detach: Rh,
  init: Mh,
  insert_hydration: Oh,
  noop: Ph,
  safe_not_equal: Nh,
  svg_element: Hh
} = window.__gradio__svelte__internal, {
  SvelteComponent: jh,
  append_hydration: Gh,
  attr: Uh,
  children: Vh,
  claim_svg_element: Zh,
  detach: Xh,
  init: Wh,
  insert_hydration: Yh,
  noop: Kh,
  safe_not_equal: Qh,
  svg_element: Jh
} = window.__gradio__svelte__internal, {
  SvelteComponent: ef,
  append_hydration: tf,
  attr: nf,
  children: af,
  claim_svg_element: lf,
  detach: rf,
  init: of,
  insert_hydration: sf,
  noop: uf,
  safe_not_equal: cf,
  svg_element: _f
} = window.__gradio__svelte__internal, {
  SvelteComponent: df,
  append_hydration: hf,
  attr: ff,
  children: pf,
  claim_svg_element: mf,
  detach: gf,
  init: vf,
  insert_hydration: Df,
  noop: bf,
  safe_not_equal: wf,
  svg_element: yf
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ff,
  append_hydration: kf,
  attr: $f,
  children: Cf,
  claim_svg_element: Ef,
  detach: Af,
  init: Sf,
  insert_hydration: xf,
  noop: Bf,
  safe_not_equal: Tf,
  svg_element: qf
} = window.__gradio__svelte__internal, {
  SvelteComponent: Lf,
  append_hydration: zf,
  attr: If,
  children: Rf,
  claim_svg_element: Mf,
  detach: Of,
  init: Pf,
  insert_hydration: Nf,
  noop: Hf,
  safe_not_equal: jf,
  svg_element: Gf
} = window.__gradio__svelte__internal, {
  SvelteComponent: Uf,
  append_hydration: Vf,
  attr: Zf,
  children: Xf,
  claim_svg_element: Wf,
  detach: Yf,
  init: Kf,
  insert_hydration: Qf,
  noop: Jf,
  safe_not_equal: ep,
  svg_element: tp
} = window.__gradio__svelte__internal, {
  SvelteComponent: np,
  append_hydration: ip,
  attr: ap,
  children: lp,
  claim_svg_element: rp,
  detach: op,
  init: sp,
  insert_hydration: up,
  noop: cp,
  safe_not_equal: _p,
  svg_element: dp
} = window.__gradio__svelte__internal, {
  SvelteComponent: hp,
  append_hydration: fp,
  attr: pp,
  children: mp,
  claim_svg_element: gp,
  detach: vp,
  init: Dp,
  insert_hydration: bp,
  noop: wp,
  safe_not_equal: yp,
  svg_element: Fp
} = window.__gradio__svelte__internal, {
  SvelteComponent: kp,
  append_hydration: $p,
  attr: Cp,
  children: Ep,
  claim_svg_element: Ap,
  detach: Sp,
  init: xp,
  insert_hydration: Bp,
  noop: Tp,
  safe_not_equal: qp,
  svg_element: Lp
} = window.__gradio__svelte__internal, {
  SvelteComponent: zp,
  append_hydration: Ip,
  attr: Rp,
  children: Mp,
  claim_svg_element: Op,
  detach: Pp,
  init: Np,
  insert_hydration: Hp,
  noop: jp,
  safe_not_equal: Gp,
  svg_element: Up
} = window.__gradio__svelte__internal, {
  SvelteComponent: Vp,
  append_hydration: Zp,
  attr: Xp,
  children: Wp,
  claim_svg_element: Yp,
  detach: Kp,
  init: Qp,
  insert_hydration: Jp,
  noop: em,
  safe_not_equal: tm,
  svg_element: nm
} = window.__gradio__svelte__internal, {
  SvelteComponent: im,
  append_hydration: am,
  attr: lm,
  children: rm,
  claim_svg_element: om,
  detach: sm,
  init: um,
  insert_hydration: cm,
  noop: _m,
  safe_not_equal: dm,
  svg_element: hm
} = window.__gradio__svelte__internal, {
  SvelteComponent: fm,
  append_hydration: pm,
  attr: mm,
  children: gm,
  claim_svg_element: vm,
  detach: Dm,
  init: bm,
  insert_hydration: wm,
  noop: ym,
  safe_not_equal: Fm,
  svg_element: km
} = window.__gradio__svelte__internal, {
  SvelteComponent: $m,
  append_hydration: Cm,
  attr: Em,
  children: Am,
  claim_svg_element: Sm,
  detach: xm,
  init: Bm,
  insert_hydration: Tm,
  noop: qm,
  safe_not_equal: Lm,
  svg_element: zm
} = window.__gradio__svelte__internal, {
  SvelteComponent: Im,
  append_hydration: Rm,
  attr: Mm,
  children: Om,
  claim_svg_element: Pm,
  detach: Nm,
  init: Hm,
  insert_hydration: jm,
  noop: Gm,
  safe_not_equal: Um,
  svg_element: Vm
} = window.__gradio__svelte__internal, {
  SvelteComponent: Zm,
  append_hydration: Xm,
  attr: Wm,
  children: Ym,
  claim_svg_element: Km,
  detach: Qm,
  init: Jm,
  insert_hydration: eg,
  noop: tg,
  safe_not_equal: ng,
  svg_element: ig
} = window.__gradio__svelte__internal, {
  SvelteComponent: ag,
  append_hydration: lg,
  attr: rg,
  children: og,
  claim_svg_element: sg,
  detach: ug,
  init: cg,
  insert_hydration: _g,
  noop: dg,
  safe_not_equal: hg,
  svg_element: fg
} = window.__gradio__svelte__internal, {
  SvelteComponent: pg,
  append_hydration: mg,
  attr: gg,
  children: vg,
  claim_svg_element: Dg,
  detach: bg,
  init: wg,
  insert_hydration: yg,
  noop: Fg,
  safe_not_equal: kg,
  svg_element: $g
} = window.__gradio__svelte__internal, {
  SvelteComponent: Cg,
  append_hydration: Eg,
  attr: Ag,
  children: Sg,
  claim_svg_element: xg,
  detach: Bg,
  init: Tg,
  insert_hydration: qg,
  noop: Lg,
  safe_not_equal: zg,
  svg_element: Ig
} = window.__gradio__svelte__internal, {
  SvelteComponent: Rg,
  append_hydration: Mg,
  attr: Og,
  children: Pg,
  claim_svg_element: Ng,
  detach: Hg,
  init: jg,
  insert_hydration: Gg,
  noop: Ug,
  safe_not_equal: Vg,
  svg_element: Zg
} = window.__gradio__svelte__internal, {
  SvelteComponent: Xg,
  append_hydration: Wg,
  attr: Yg,
  children: Kg,
  claim_svg_element: Qg,
  detach: Jg,
  init: e0,
  insert_hydration: t0,
  noop: n0,
  safe_not_equal: i0,
  svg_element: a0
} = window.__gradio__svelte__internal, {
  SvelteComponent: l0,
  append_hydration: r0,
  attr: o0,
  children: s0,
  claim_svg_element: u0,
  detach: c0,
  init: _0,
  insert_hydration: d0,
  noop: h0,
  safe_not_equal: f0,
  set_style: p0,
  svg_element: m0
} = window.__gradio__svelte__internal, {
  SvelteComponent: g0,
  append_hydration: v0,
  attr: D0,
  children: b0,
  claim_svg_element: w0,
  detach: y0,
  init: F0,
  insert_hydration: k0,
  noop: $0,
  safe_not_equal: C0,
  svg_element: E0
} = window.__gradio__svelte__internal, {
  SvelteComponent: A0,
  append_hydration: S0,
  attr: x0,
  children: B0,
  claim_svg_element: T0,
  detach: q0,
  init: L0,
  insert_hydration: z0,
  noop: I0,
  safe_not_equal: R0,
  svg_element: M0
} = window.__gradio__svelte__internal, {
  SvelteComponent: O0,
  append_hydration: P0,
  attr: N0,
  children: H0,
  claim_svg_element: j0,
  detach: G0,
  init: U0,
  insert_hydration: V0,
  noop: Z0,
  safe_not_equal: X0,
  svg_element: W0
} = window.__gradio__svelte__internal, {
  SvelteComponent: Y0,
  append_hydration: K0,
  attr: Q0,
  children: J0,
  claim_svg_element: e1,
  detach: t1,
  init: n1,
  insert_hydration: i1,
  noop: a1,
  safe_not_equal: l1,
  svg_element: r1
} = window.__gradio__svelte__internal, {
  SvelteComponent: o1,
  append_hydration: s1,
  attr: u1,
  children: c1,
  claim_svg_element: _1,
  detach: d1,
  init: h1,
  insert_hydration: f1,
  noop: p1,
  safe_not_equal: m1,
  svg_element: g1
} = window.__gradio__svelte__internal, {
  SvelteComponent: v1,
  append_hydration: D1,
  attr: b1,
  children: w1,
  claim_svg_element: y1,
  detach: F1,
  init: k1,
  insert_hydration: $1,
  noop: C1,
  safe_not_equal: E1,
  svg_element: A1
} = window.__gradio__svelte__internal, {
  SvelteComponent: S1,
  append_hydration: x1,
  attr: B1,
  children: T1,
  claim_svg_element: q1,
  detach: L1,
  init: z1,
  insert_hydration: I1,
  noop: R1,
  safe_not_equal: M1,
  svg_element: O1
} = window.__gradio__svelte__internal, {
  SvelteComponent: P1,
  append_hydration: N1,
  attr: H1,
  children: j1,
  claim_svg_element: G1,
  detach: U1,
  init: V1,
  insert_hydration: Z1,
  noop: X1,
  safe_not_equal: W1,
  svg_element: Y1
} = window.__gradio__svelte__internal, {
  SvelteComponent: K1,
  append_hydration: Q1,
  attr: J1,
  children: ev,
  claim_svg_element: tv,
  claim_text: nv,
  detach: iv,
  init: av,
  insert_hydration: lv,
  noop: rv,
  safe_not_equal: ov,
  svg_element: sv,
  text: uv
} = window.__gradio__svelte__internal, {
  SvelteComponent: cv,
  append_hydration: _v,
  attr: dv,
  children: hv,
  claim_svg_element: fv,
  detach: pv,
  init: mv,
  insert_hydration: gv,
  noop: vv,
  safe_not_equal: Dv,
  svg_element: bv
} = window.__gradio__svelte__internal, {
  SvelteComponent: wv,
  append_hydration: yv,
  attr: Fv,
  children: kv,
  claim_svg_element: $v,
  detach: Cv,
  init: Ev,
  insert_hydration: Av,
  noop: Sv,
  safe_not_equal: xv,
  svg_element: Bv
} = window.__gradio__svelte__internal, {
  SvelteComponent: Tv,
  append_hydration: qv,
  attr: Lv,
  children: zv,
  claim_svg_element: Iv,
  detach: Rv,
  init: Mv,
  insert_hydration: Ov,
  noop: Pv,
  safe_not_equal: Nv,
  svg_element: Hv
} = window.__gradio__svelte__internal, {
  SvelteComponent: jv,
  append_hydration: Gv,
  attr: Uv,
  children: Vv,
  claim_svg_element: Zv,
  detach: Xv,
  init: Wv,
  insert_hydration: Yv,
  noop: Kv,
  safe_not_equal: Qv,
  svg_element: Jv
} = window.__gradio__svelte__internal, {
  SvelteComponent: eD,
  append_hydration: tD,
  attr: nD,
  children: iD,
  claim_svg_element: aD,
  detach: lD,
  init: rD,
  insert_hydration: oD,
  noop: sD,
  safe_not_equal: uD,
  svg_element: cD
} = window.__gradio__svelte__internal, {
  SvelteComponent: _D,
  append_hydration: dD,
  attr: hD,
  children: fD,
  claim_svg_element: pD,
  detach: mD,
  init: gD,
  insert_hydration: vD,
  noop: DD,
  safe_not_equal: bD,
  svg_element: wD
} = window.__gradio__svelte__internal, {
  SvelteComponent: yD,
  append_hydration: FD,
  attr: kD,
  children: $D,
  claim_svg_element: CD,
  detach: ED,
  init: AD,
  insert_hydration: SD,
  noop: xD,
  safe_not_equal: BD,
  svg_element: TD
} = window.__gradio__svelte__internal, {
  SvelteComponent: qD,
  append_hydration: LD,
  attr: zD,
  children: ID,
  claim_svg_element: RD,
  claim_text: MD,
  detach: OD,
  init: PD,
  insert_hydration: ND,
  noop: HD,
  safe_not_equal: jD,
  svg_element: GD,
  text: UD
} = window.__gradio__svelte__internal, {
  SvelteComponent: VD,
  append_hydration: ZD,
  attr: XD,
  children: WD,
  claim_svg_element: YD,
  claim_text: KD,
  detach: QD,
  init: JD,
  insert_hydration: eb,
  noop: tb,
  safe_not_equal: nb,
  svg_element: ib,
  text: ab
} = window.__gradio__svelte__internal, {
  SvelteComponent: lb,
  append_hydration: rb,
  attr: ob,
  children: sb,
  claim_svg_element: ub,
  claim_text: cb,
  detach: _b,
  init: db,
  insert_hydration: hb,
  noop: fb,
  safe_not_equal: pb,
  svg_element: mb,
  text: gb
} = window.__gradio__svelte__internal, {
  SvelteComponent: vb,
  append_hydration: Db,
  attr: bb,
  children: wb,
  claim_svg_element: yb,
  detach: Fb,
  init: kb,
  insert_hydration: $b,
  noop: Cb,
  safe_not_equal: Eb,
  svg_element: Ab
} = window.__gradio__svelte__internal, {
  SvelteComponent: Sb,
  append_hydration: xb,
  attr: Bb,
  children: Tb,
  claim_svg_element: qb,
  detach: Lb,
  init: zb,
  insert_hydration: Ib,
  noop: Rb,
  safe_not_equal: Mb,
  svg_element: Ob
} = window.__gradio__svelte__internal, {
  SvelteComponent: Pb,
  append_hydration: Nb,
  attr: Hb,
  children: jb,
  claim_svg_element: Gb,
  detach: Ub,
  init: Vb,
  insert_hydration: Zb,
  noop: Xb,
  safe_not_equal: Wb,
  svg_element: Yb
} = window.__gradio__svelte__internal, {
  SvelteComponent: Kb,
  append_hydration: Qb,
  attr: Jb,
  children: ew,
  claim_svg_element: tw,
  detach: nw,
  init: iw,
  insert_hydration: aw,
  noop: lw,
  safe_not_equal: rw,
  svg_element: ow
} = window.__gradio__svelte__internal, {
  SvelteComponent: sw,
  append_hydration: uw,
  attr: cw,
  children: _w,
  claim_svg_element: dw,
  detach: hw,
  init: fw,
  insert_hydration: pw,
  noop: mw,
  safe_not_equal: gw,
  svg_element: vw
} = window.__gradio__svelte__internal, {
  SvelteComponent: Dw,
  append_hydration: bw,
  attr: ww,
  children: yw,
  claim_svg_element: Fw,
  detach: kw,
  init: $w,
  insert_hydration: Cw,
  noop: Ew,
  safe_not_equal: Aw,
  svg_element: Sw
} = window.__gradio__svelte__internal, {
  SvelteComponent: xw,
  append_hydration: Bw,
  attr: Tw,
  children: qw,
  claim_svg_element: Lw,
  detach: zw,
  init: Iw,
  insert_hydration: Rw,
  noop: Mw,
  safe_not_equal: Ow,
  svg_element: Pw
} = window.__gradio__svelte__internal, {
  SvelteComponent: Nw,
  append_hydration: Hw,
  attr: jw,
  children: Gw,
  claim_svg_element: Uw,
  detach: Vw,
  init: Zw,
  insert_hydration: Xw,
  noop: Ww,
  safe_not_equal: Yw,
  svg_element: Kw
} = window.__gradio__svelte__internal, {
  SvelteComponent: Qw,
  append_hydration: Jw,
  attr: ey,
  children: ty,
  claim_svg_element: ny,
  detach: iy,
  init: ay,
  insert_hydration: ly,
  noop: ry,
  safe_not_equal: oy,
  svg_element: sy
} = window.__gradio__svelte__internal, {
  SvelteComponent: uy,
  append_hydration: cy,
  attr: _y,
  children: dy,
  claim_svg_element: hy,
  detach: fy,
  init: py,
  insert_hydration: my,
  noop: gy,
  safe_not_equal: vy,
  svg_element: Dy
} = window.__gradio__svelte__internal, {
  SvelteComponent: by,
  append_hydration: wy,
  attr: yy,
  children: Fy,
  claim_svg_element: ky,
  detach: $y,
  init: Cy,
  insert_hydration: Ey,
  noop: Ay,
  safe_not_equal: Sy,
  svg_element: xy
} = window.__gradio__svelte__internal, {
  SvelteComponent: ll,
  append_hydration: Vt,
  assign: rl,
  attr: W,
  binding_callbacks: ol,
  children: Ge,
  claim_element: Pi,
  claim_space: Ni,
  claim_svg_element: Rt,
  create_slot: sl,
  detach: ve,
  element: Hi,
  empty: Ln,
  get_all_dirty_from_scope: ul,
  get_slot_changes: cl,
  get_spread_update: _l,
  init: dl,
  insert_hydration: Ke,
  listen: hl,
  noop: fl,
  safe_not_equal: pl,
  set_dynamic_element_data: zn,
  set_style: L,
  space: ji,
  svg_element: Mt,
  toggle_class: G,
  transition_in: Gi,
  transition_out: Ui,
  update_slot_base: ml
} = window.__gradio__svelte__internal;
function In(i) {
  let e, t, n, a, r;
  return {
    c() {
      e = Mt("svg"), t = Mt("line"), n = Mt("line"), this.h();
    },
    l(l) {
      e = Rt(l, "svg", { class: !0, xmlns: !0, viewBox: !0 });
      var o = Ge(e);
      t = Rt(o, "line", {
        x1: !0,
        y1: !0,
        x2: !0,
        y2: !0,
        stroke: !0,
        "stroke-width": !0
      }), Ge(t).forEach(ve), n = Rt(o, "line", {
        x1: !0,
        y1: !0,
        x2: !0,
        y2: !0,
        stroke: !0,
        "stroke-width": !0
      }), Ge(n).forEach(ve), o.forEach(ve), this.h();
    },
    h() {
      W(t, "x1", "1"), W(t, "y1", "9"), W(t, "x2", "9"), W(t, "y2", "1"), W(t, "stroke", "gray"), W(t, "stroke-width", "0.5"), W(n, "x1", "5"), W(n, "y1", "9"), W(n, "x2", "9"), W(n, "y2", "5"), W(n, "stroke", "gray"), W(n, "stroke-width", "0.5"), W(e, "class", "resize-handle svelte-239wnu"), W(e, "xmlns", "http://www.w3.org/2000/svg"), W(e, "viewBox", "0 0 10 10");
    },
    m(l, o) {
      Ke(l, e, o), Vt(e, t), Vt(e, n), a || (r = hl(
        e,
        "mousedown",
        /*resize*/
        i[27]
      ), a = !0);
    },
    p: fl,
    d(l) {
      l && ve(e), a = !1, r();
    }
  };
}
function gl(i) {
  var f;
  let e, t, n, a, r;
  const l = (
    /*#slots*/
    i[31].default
  ), o = sl(
    l,
    i,
    /*$$scope*/
    i[30],
    null
  );
  let s = (
    /*resizable*/
    i[19] && In(i)
  ), u = [
    { "data-testid": (
      /*test_id*/
      i[11]
    ) },
    { id: (
      /*elem_id*/
      i[6]
    ) },
    {
      class: n = "block " + /*elem_classes*/
      (((f = i[7]) == null ? void 0 : f.join(" ")) || "") + " svelte-239wnu"
    },
    {
      dir: a = /*rtl*/
      i[20] ? "rtl" : "ltr"
    }
  ], _ = {};
  for (let d = 0; d < u.length; d += 1)
    _ = rl(_, u[d]);
  return {
    c() {
      e = Hi(
        /*tag*/
        i[25]
      ), o && o.c(), t = ji(), s && s.c(), this.h();
    },
    l(d) {
      e = Pi(
        d,
        /*tag*/
        (i[25] || "null").toUpperCase(),
        {
          "data-testid": !0,
          id: !0,
          class: !0,
          dir: !0
        }
      );
      var h = Ge(e);
      o && o.l(h), t = Ni(h), s && s.l(h), h.forEach(ve), this.h();
    },
    h() {
      zn(
        /*tag*/
        i[25]
      )(e, _), G(
        e,
        "hidden",
        /*visible*/
        i[14] === !1
      ), G(
        e,
        "padded",
        /*padding*/
        i[10]
      ), G(
        e,
        "flex",
        /*flex*/
        i[1]
      ), G(
        e,
        "border_focus",
        /*border_mode*/
        i[9] === "focus"
      ), G(
        e,
        "border_contrast",
        /*border_mode*/
        i[9] === "contrast"
      ), G(e, "hide-container", !/*explicit_call*/
      i[12] && !/*container*/
      i[13]), G(
        e,
        "fullscreen",
        /*fullscreen*/
        i[0]
      ), G(
        e,
        "animating",
        /*fullscreen*/
        i[0] && /*preexpansionBoundingRect*/
        i[24] !== null
      ), G(
        e,
        "auto-margin",
        /*scale*/
        i[17] === null
      ), L(
        e,
        "height",
        /*fullscreen*/
        i[0] ? void 0 : (
          /*get_dimension*/
          i[26](
            /*height*/
            i[2]
          )
        )
      ), L(
        e,
        "min-height",
        /*fullscreen*/
        i[0] ? void 0 : (
          /*get_dimension*/
          i[26](
            /*min_height*/
            i[3]
          )
        )
      ), L(
        e,
        "max-height",
        /*fullscreen*/
        i[0] ? void 0 : (
          /*get_dimension*/
          i[26](
            /*max_height*/
            i[4]
          )
        )
      ), L(
        e,
        "--start-top",
        /*preexpansionBoundingRect*/
        i[24] ? `${/*preexpansionBoundingRect*/
        i[24].top}px` : "0px"
      ), L(
        e,
        "--start-left",
        /*preexpansionBoundingRect*/
        i[24] ? `${/*preexpansionBoundingRect*/
        i[24].left}px` : "0px"
      ), L(
        e,
        "--start-width",
        /*preexpansionBoundingRect*/
        i[24] ? `${/*preexpansionBoundingRect*/
        i[24].width}px` : "0px"
      ), L(
        e,
        "--start-height",
        /*preexpansionBoundingRect*/
        i[24] ? `${/*preexpansionBoundingRect*/
        i[24].height}px` : "0px"
      ), L(
        e,
        "width",
        /*fullscreen*/
        i[0] ? void 0 : typeof /*width*/
        i[5] == "number" ? `calc(min(${/*width*/
        i[5]}px, 100%))` : (
          /*get_dimension*/
          i[26](
            /*width*/
            i[5]
          )
        )
      ), L(
        e,
        "border-style",
        /*variant*/
        i[8]
      ), L(
        e,
        "overflow",
        /*allow_overflow*/
        i[15] ? (
          /*overflow_behavior*/
          i[16]
        ) : "hidden"
      ), L(
        e,
        "flex-grow",
        /*scale*/
        i[17]
      ), L(e, "min-width", `calc(min(${/*min_width*/
      i[18]}px, 100%))`), L(e, "border-width", "var(--block-border-width)");
    },
    m(d, h) {
      Ke(d, e, h), o && o.m(e, null), Vt(e, t), s && s.m(e, null), i[32](e), r = !0;
    },
    p(d, h) {
      var m;
      o && o.p && (!r || h[0] & /*$$scope*/
      1073741824) && ml(
        o,
        l,
        d,
        /*$$scope*/
        d[30],
        r ? cl(
          l,
          /*$$scope*/
          d[30],
          h,
          null
        ) : ul(
          /*$$scope*/
          d[30]
        ),
        null
      ), /*resizable*/
      d[19] ? s ? s.p(d, h) : (s = In(d), s.c(), s.m(e, null)) : s && (s.d(1), s = null), zn(
        /*tag*/
        d[25]
      )(e, _ = _l(u, [
        (!r || h[0] & /*test_id*/
        2048) && { "data-testid": (
          /*test_id*/
          d[11]
        ) },
        (!r || h[0] & /*elem_id*/
        64) && { id: (
          /*elem_id*/
          d[6]
        ) },
        (!r || h[0] & /*elem_classes*/
        128 && n !== (n = "block " + /*elem_classes*/
        (((m = d[7]) == null ? void 0 : m.join(" ")) || "") + " svelte-239wnu")) && { class: n },
        (!r || h[0] & /*rtl*/
        1048576 && a !== (a = /*rtl*/
        d[20] ? "rtl" : "ltr")) && { dir: a }
      ])), G(
        e,
        "hidden",
        /*visible*/
        d[14] === !1
      ), G(
        e,
        "padded",
        /*padding*/
        d[10]
      ), G(
        e,
        "flex",
        /*flex*/
        d[1]
      ), G(
        e,
        "border_focus",
        /*border_mode*/
        d[9] === "focus"
      ), G(
        e,
        "border_contrast",
        /*border_mode*/
        d[9] === "contrast"
      ), G(e, "hide-container", !/*explicit_call*/
      d[12] && !/*container*/
      d[13]), G(
        e,
        "fullscreen",
        /*fullscreen*/
        d[0]
      ), G(
        e,
        "animating",
        /*fullscreen*/
        d[0] && /*preexpansionBoundingRect*/
        d[24] !== null
      ), G(
        e,
        "auto-margin",
        /*scale*/
        d[17] === null
      ), h[0] & /*fullscreen, height*/
      5 && L(
        e,
        "height",
        /*fullscreen*/
        d[0] ? void 0 : (
          /*get_dimension*/
          d[26](
            /*height*/
            d[2]
          )
        )
      ), h[0] & /*fullscreen, min_height*/
      9 && L(
        e,
        "min-height",
        /*fullscreen*/
        d[0] ? void 0 : (
          /*get_dimension*/
          d[26](
            /*min_height*/
            d[3]
          )
        )
      ), h[0] & /*fullscreen, max_height*/
      17 && L(
        e,
        "max-height",
        /*fullscreen*/
        d[0] ? void 0 : (
          /*get_dimension*/
          d[26](
            /*max_height*/
            d[4]
          )
        )
      ), h[0] & /*preexpansionBoundingRect*/
      16777216 && L(
        e,
        "--start-top",
        /*preexpansionBoundingRect*/
        d[24] ? `${/*preexpansionBoundingRect*/
        d[24].top}px` : "0px"
      ), h[0] & /*preexpansionBoundingRect*/
      16777216 && L(
        e,
        "--start-left",
        /*preexpansionBoundingRect*/
        d[24] ? `${/*preexpansionBoundingRect*/
        d[24].left}px` : "0px"
      ), h[0] & /*preexpansionBoundingRect*/
      16777216 && L(
        e,
        "--start-width",
        /*preexpansionBoundingRect*/
        d[24] ? `${/*preexpansionBoundingRect*/
        d[24].width}px` : "0px"
      ), h[0] & /*preexpansionBoundingRect*/
      16777216 && L(
        e,
        "--start-height",
        /*preexpansionBoundingRect*/
        d[24] ? `${/*preexpansionBoundingRect*/
        d[24].height}px` : "0px"
      ), h[0] & /*fullscreen, width*/
      33 && L(
        e,
        "width",
        /*fullscreen*/
        d[0] ? void 0 : typeof /*width*/
        d[5] == "number" ? `calc(min(${/*width*/
        d[5]}px, 100%))` : (
          /*get_dimension*/
          d[26](
            /*width*/
            d[5]
          )
        )
      ), h[0] & /*variant*/
      256 && L(
        e,
        "border-style",
        /*variant*/
        d[8]
      ), h[0] & /*allow_overflow, overflow_behavior*/
      98304 && L(
        e,
        "overflow",
        /*allow_overflow*/
        d[15] ? (
          /*overflow_behavior*/
          d[16]
        ) : "hidden"
      ), h[0] & /*scale*/
      131072 && L(
        e,
        "flex-grow",
        /*scale*/
        d[17]
      ), h[0] & /*min_width*/
      262144 && L(e, "min-width", `calc(min(${/*min_width*/
      d[18]}px, 100%))`);
    },
    i(d) {
      r || (Gi(o, d), r = !0);
    },
    o(d) {
      Ui(o, d), r = !1;
    },
    d(d) {
      d && ve(e), o && o.d(d), s && s.d(), i[32](null);
    }
  };
}
function Rn(i) {
  let e;
  return {
    c() {
      e = Hi("div"), this.h();
    },
    l(t) {
      e = Pi(t, "DIV", { class: !0 }), Ge(e).forEach(ve), this.h();
    },
    h() {
      W(e, "class", "placeholder svelte-239wnu"), L(
        e,
        "height",
        /*placeholder_height*/
        i[22] + "px"
      ), L(
        e,
        "width",
        /*placeholder_width*/
        i[23] + "px"
      );
    },
    m(t, n) {
      Ke(t, e, n);
    },
    p(t, n) {
      n[0] & /*placeholder_height*/
      4194304 && L(
        e,
        "height",
        /*placeholder_height*/
        t[22] + "px"
      ), n[0] & /*placeholder_width*/
      8388608 && L(
        e,
        "width",
        /*placeholder_width*/
        t[23] + "px"
      );
    },
    d(t) {
      t && ve(e);
    }
  };
}
function vl(i) {
  let e, t, n, a = (
    /*tag*/
    i[25] && gl(i)
  ), r = (
    /*fullscreen*/
    i[0] && Rn(i)
  );
  return {
    c() {
      a && a.c(), e = ji(), r && r.c(), t = Ln();
    },
    l(l) {
      a && a.l(l), e = Ni(l), r && r.l(l), t = Ln();
    },
    m(l, o) {
      a && a.m(l, o), Ke(l, e, o), r && r.m(l, o), Ke(l, t, o), n = !0;
    },
    p(l, o) {
      /*tag*/
      l[25] && a.p(l, o), /*fullscreen*/
      l[0] ? r ? r.p(l, o) : (r = Rn(l), r.c(), r.m(t.parentNode, t)) : r && (r.d(1), r = null);
    },
    i(l) {
      n || (Gi(a, l), n = !0);
    },
    o(l) {
      Ui(a, l), n = !1;
    },
    d(l) {
      l && (ve(e), ve(t)), a && a.d(l), r && r.d(l);
    }
  };
}
function Dl(i, e, t) {
  let { $$slots: n = {}, $$scope: a } = e, { height: r = void 0 } = e, { min_height: l = void 0 } = e, { max_height: o = void 0 } = e, { width: s = void 0 } = e, { elem_id: u = "" } = e, { elem_classes: _ = [] } = e, { variant: f = "solid" } = e, { border_mode: d = "base" } = e, { padding: h = !0 } = e, { type: m = "normal" } = e, { test_id: w = void 0 } = e, { explicit_call: y = !1 } = e, { container: E = !0 } = e, { visible: p = !0 } = e, { allow_overflow: c = !0 } = e, { overflow_behavior: v = "auto" } = e, { scale: F = null } = e, { min_width: b = 0 } = e, { flex: g = !1 } = e, { resizable: k = !1 } = e, { rtl: D = !1 } = e, { fullscreen: C = !1 } = e, x = C, T, V = m === "fieldset" ? "fieldset" : "div", j = 0, U = 0, R = null;
  function H($) {
    C && $.key === "Escape" && t(0, C = !1);
  }
  const O = ($) => {
    if ($ !== void 0) {
      if (typeof $ == "number")
        return $ + "px";
      if (typeof $ == "string")
        return $;
    }
  }, Y = ($) => {
    let Z = $.clientY;
    const Le = (A) => {
      const ze = A.clientY - Z;
      Z = A.clientY, t(21, T.style.height = `${T.offsetHeight + ze}px`, T);
    }, K = () => {
      window.removeEventListener("mousemove", Le), window.removeEventListener("mouseup", K);
    };
    window.addEventListener("mousemove", Le), window.addEventListener("mouseup", K);
  };
  function oe($) {
    ol[$ ? "unshift" : "push"](() => {
      T = $, t(21, T);
    });
  }
  return i.$$set = ($) => {
    "height" in $ && t(2, r = $.height), "min_height" in $ && t(3, l = $.min_height), "max_height" in $ && t(4, o = $.max_height), "width" in $ && t(5, s = $.width), "elem_id" in $ && t(6, u = $.elem_id), "elem_classes" in $ && t(7, _ = $.elem_classes), "variant" in $ && t(8, f = $.variant), "border_mode" in $ && t(9, d = $.border_mode), "padding" in $ && t(10, h = $.padding), "type" in $ && t(28, m = $.type), "test_id" in $ && t(11, w = $.test_id), "explicit_call" in $ && t(12, y = $.explicit_call), "container" in $ && t(13, E = $.container), "visible" in $ && t(14, p = $.visible), "allow_overflow" in $ && t(15, c = $.allow_overflow), "overflow_behavior" in $ && t(16, v = $.overflow_behavior), "scale" in $ && t(17, F = $.scale), "min_width" in $ && t(18, b = $.min_width), "flex" in $ && t(1, g = $.flex), "resizable" in $ && t(19, k = $.resizable), "rtl" in $ && t(20, D = $.rtl), "fullscreen" in $ && t(0, C = $.fullscreen), "$$scope" in $ && t(30, a = $.$$scope);
  }, i.$$.update = () => {
    i.$$.dirty[0] & /*fullscreen, old_fullscreen, element*/
    538968065 && C !== x && (t(29, x = C), C ? (t(24, R = T.getBoundingClientRect()), t(22, j = T.offsetHeight), t(23, U = T.offsetWidth), window.addEventListener("keydown", H)) : (t(24, R = null), window.removeEventListener("keydown", H))), i.$$.dirty[0] & /*visible*/
    16384 && (p || t(1, g = !1));
  }, [
    C,
    g,
    r,
    l,
    o,
    s,
    u,
    _,
    f,
    d,
    h,
    w,
    y,
    E,
    p,
    c,
    v,
    F,
    b,
    k,
    D,
    T,
    j,
    U,
    R,
    V,
    O,
    Y,
    m,
    x,
    a,
    n,
    oe
  ];
}
class bl extends ll {
  constructor(e) {
    super(), dl(
      this,
      e,
      Dl,
      vl,
      pl,
      {
        height: 2,
        min_height: 3,
        max_height: 4,
        width: 5,
        elem_id: 6,
        elem_classes: 7,
        variant: 8,
        border_mode: 9,
        padding: 10,
        type: 28,
        test_id: 11,
        explicit_call: 12,
        container: 13,
        visible: 14,
        allow_overflow: 15,
        overflow_behavior: 16,
        scale: 17,
        min_width: 18,
        flex: 1,
        resizable: 19,
        rtl: 20,
        fullscreen: 0
      },
      null,
      [-1, -1]
    );
  }
}
function dn() {
  return {
    async: !1,
    breaks: !1,
    extensions: null,
    gfm: !0,
    hooks: null,
    pedantic: !1,
    renderer: null,
    silent: !1,
    tokenizer: null,
    walkTokens: null
  };
}
let qe = dn();
function Vi(i) {
  qe = i;
}
const Zi = /[&<>"']/, wl = new RegExp(Zi.source, "g"), Xi = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, yl = new RegExp(Xi.source, "g"), Fl = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, Mn = (i) => Fl[i];
function J(i, e) {
  if (e) {
    if (Zi.test(i))
      return i.replace(wl, Mn);
  } else if (Xi.test(i))
    return i.replace(yl, Mn);
  return i;
}
const kl = /&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/ig;
function $l(i) {
  return i.replace(kl, (e, t) => (t = t.toLowerCase(), t === "colon" ? ":" : t.charAt(0) === "#" ? t.charAt(1) === "x" ? String.fromCharCode(parseInt(t.substring(2), 16)) : String.fromCharCode(+t.substring(1)) : ""));
}
const Cl = /(^|[^\[])\^/g;
function I(i, e) {
  let t = typeof i == "string" ? i : i.source;
  e = e || "";
  const n = {
    replace: (a, r) => {
      let l = typeof r == "string" ? r : r.source;
      return l = l.replace(Cl, "$1"), t = t.replace(a, l), n;
    },
    getRegex: () => new RegExp(t, e)
  };
  return n;
}
function On(i) {
  try {
    i = encodeURI(i).replace(/%25/g, "%");
  } catch {
    return null;
  }
  return i;
}
const Ue = { exec: () => null };
function Pn(i, e) {
  const t = i.replace(/\|/g, (r, l, o) => {
    let s = !1, u = l;
    for (; --u >= 0 && o[u] === "\\"; )
      s = !s;
    return s ? "|" : " |";
  }), n = t.split(/ \|/);
  let a = 0;
  if (n[0].trim() || n.shift(), n.length > 0 && !n[n.length - 1].trim() && n.pop(), e)
    if (n.length > e)
      n.splice(e);
    else
      for (; n.length < e; )
        n.push("");
  for (; a < n.length; a++)
    n[a] = n[a].trim().replace(/\\\|/g, "|");
  return n;
}
function st(i, e, t) {
  const n = i.length;
  if (n === 0)
    return "";
  let a = 0;
  for (; a < n && i.charAt(n - a - 1) === e; )
    a++;
  return i.slice(0, n - a);
}
function El(i, e) {
  if (i.indexOf(e[1]) === -1)
    return -1;
  let t = 0;
  for (let n = 0; n < i.length; n++)
    if (i[n] === "\\")
      n++;
    else if (i[n] === e[0])
      t++;
    else if (i[n] === e[1] && (t--, t < 0))
      return n;
  return -1;
}
function Nn(i, e, t, n) {
  const a = e.href, r = e.title ? J(e.title) : null, l = i[1].replace(/\\([\[\]])/g, "$1");
  if (i[0].charAt(0) !== "!") {
    n.state.inLink = !0;
    const o = {
      type: "link",
      raw: t,
      href: a,
      title: r,
      text: l,
      tokens: n.inlineTokens(l)
    };
    return n.state.inLink = !1, o;
  }
  return {
    type: "image",
    raw: t,
    href: a,
    title: r,
    text: J(l)
  };
}
function Al(i, e) {
  const t = i.match(/^(\s+)(?:```)/);
  if (t === null)
    return e;
  const n = t[1];
  return e.split(`
`).map((a) => {
    const r = a.match(/^\s+/);
    if (r === null)
      return a;
    const [l] = r;
    return l.length >= n.length ? a.slice(n.length) : a;
  }).join(`
`);
}
class bt {
  // set by the lexer
  constructor(e) {
    M(this, "options");
    M(this, "rules");
    // set by the lexer
    M(this, "lexer");
    this.options = e || qe;
  }
  space(e) {
    const t = this.rules.block.newline.exec(e);
    if (t && t[0].length > 0)
      return {
        type: "space",
        raw: t[0]
      };
  }
  code(e) {
    const t = this.rules.block.code.exec(e);
    if (t) {
      const n = t[0].replace(/^ {1,4}/gm, "");
      return {
        type: "code",
        raw: t[0],
        codeBlockStyle: "indented",
        text: this.options.pedantic ? n : st(n, `
`)
      };
    }
  }
  fences(e) {
    const t = this.rules.block.fences.exec(e);
    if (t) {
      const n = t[0], a = Al(n, t[3] || "");
      return {
        type: "code",
        raw: n,
        lang: t[2] ? t[2].trim().replace(this.rules.inline.anyPunctuation, "$1") : t[2],
        text: a
      };
    }
  }
  heading(e) {
    const t = this.rules.block.heading.exec(e);
    if (t) {
      let n = t[2].trim();
      if (/#$/.test(n)) {
        const a = st(n, "#");
        (this.options.pedantic || !a || / $/.test(a)) && (n = a.trim());
      }
      return {
        type: "heading",
        raw: t[0],
        depth: t[1].length,
        text: n,
        tokens: this.lexer.inline(n)
      };
    }
  }
  hr(e) {
    const t = this.rules.block.hr.exec(e);
    if (t)
      return {
        type: "hr",
        raw: t[0]
      };
  }
  blockquote(e) {
    const t = this.rules.block.blockquote.exec(e);
    if (t) {
      let n = t[0].replace(/\n {0,3}((?:=+|-+) *)(?=\n|$)/g, `
    $1`);
      n = st(n.replace(/^ *>[ \t]?/gm, ""), `
`);
      const a = this.lexer.state.top;
      this.lexer.state.top = !0;
      const r = this.lexer.blockTokens(n);
      return this.lexer.state.top = a, {
        type: "blockquote",
        raw: t[0],
        tokens: r,
        text: n
      };
    }
  }
  list(e) {
    let t = this.rules.block.list.exec(e);
    if (t) {
      let n = t[1].trim();
      const a = n.length > 1, r = {
        type: "list",
        raw: "",
        ordered: a,
        start: a ? +n.slice(0, -1) : "",
        loose: !1,
        items: []
      };
      n = a ? `\\d{1,9}\\${n.slice(-1)}` : `\\${n}`, this.options.pedantic && (n = a ? n : "[*+-]");
      const l = new RegExp(`^( {0,3}${n})((?:[	 ][^\\n]*)?(?:\\n|$))`);
      let o = "", s = "", u = !1;
      for (; e; ) {
        let _ = !1;
        if (!(t = l.exec(e)) || this.rules.block.hr.test(e))
          break;
        o = t[0], e = e.substring(o.length);
        let f = t[2].split(`
`, 1)[0].replace(/^\t+/, (E) => " ".repeat(3 * E.length)), d = e.split(`
`, 1)[0], h = 0;
        this.options.pedantic ? (h = 2, s = f.trimStart()) : (h = t[2].search(/[^ ]/), h = h > 4 ? 1 : h, s = f.slice(h), h += t[1].length);
        let m = !1;
        if (!f && /^ *$/.test(d) && (o += d + `
`, e = e.substring(d.length + 1), _ = !0), !_) {
          const E = new RegExp(`^ {0,${Math.min(3, h - 1)}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`), p = new RegExp(`^ {0,${Math.min(3, h - 1)}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)`), c = new RegExp(`^ {0,${Math.min(3, h - 1)}}(?:\`\`\`|~~~)`), v = new RegExp(`^ {0,${Math.min(3, h - 1)}}#`);
          for (; e; ) {
            const F = e.split(`
`, 1)[0];
            if (d = F, this.options.pedantic && (d = d.replace(/^ {1,4}(?=( {4})*[^ ])/g, "  ")), c.test(d) || v.test(d) || E.test(d) || p.test(e))
              break;
            if (d.search(/[^ ]/) >= h || !d.trim())
              s += `
` + d.slice(h);
            else {
              if (m || f.search(/[^ ]/) >= 4 || c.test(f) || v.test(f) || p.test(f))
                break;
              s += `
` + d;
            }
            !m && !d.trim() && (m = !0), o += F + `
`, e = e.substring(F.length + 1), f = d.slice(h);
          }
        }
        r.loose || (u ? r.loose = !0 : /\n *\n *$/.test(o) && (u = !0));
        let w = null, y;
        this.options.gfm && (w = /^\[[ xX]\] /.exec(s), w && (y = w[0] !== "[ ] ", s = s.replace(/^\[[ xX]\] +/, ""))), r.items.push({
          type: "list_item",
          raw: o,
          task: !!w,
          checked: y,
          loose: !1,
          text: s,
          tokens: []
        }), r.raw += o;
      }
      r.items[r.items.length - 1].raw = o.trimEnd(), r.items[r.items.length - 1].text = s.trimEnd(), r.raw = r.raw.trimEnd();
      for (let _ = 0; _ < r.items.length; _++)
        if (this.lexer.state.top = !1, r.items[_].tokens = this.lexer.blockTokens(r.items[_].text, []), !r.loose) {
          const f = r.items[_].tokens.filter((h) => h.type === "space"), d = f.length > 0 && f.some((h) => /\n.*\n/.test(h.raw));
          r.loose = d;
        }
      if (r.loose)
        for (let _ = 0; _ < r.items.length; _++)
          r.items[_].loose = !0;
      return r;
    }
  }
  html(e) {
    const t = this.rules.block.html.exec(e);
    if (t)
      return {
        type: "html",
        block: !0,
        raw: t[0],
        pre: t[1] === "pre" || t[1] === "script" || t[1] === "style",
        text: t[0]
      };
  }
  def(e) {
    const t = this.rules.block.def.exec(e);
    if (t) {
      const n = t[1].toLowerCase().replace(/\s+/g, " "), a = t[2] ? t[2].replace(/^<(.*)>$/, "$1").replace(this.rules.inline.anyPunctuation, "$1") : "", r = t[3] ? t[3].substring(1, t[3].length - 1).replace(this.rules.inline.anyPunctuation, "$1") : t[3];
      return {
        type: "def",
        tag: n,
        raw: t[0],
        href: a,
        title: r
      };
    }
  }
  table(e) {
    const t = this.rules.block.table.exec(e);
    if (!t || !/[:|]/.test(t[2]))
      return;
    const n = Pn(t[1]), a = t[2].replace(/^\||\| *$/g, "").split("|"), r = t[3] && t[3].trim() ? t[3].replace(/\n[ \t]*$/, "").split(`
`) : [], l = {
      type: "table",
      raw: t[0],
      header: [],
      align: [],
      rows: []
    };
    if (n.length === a.length) {
      for (const o of a)
        /^ *-+: *$/.test(o) ? l.align.push("right") : /^ *:-+: *$/.test(o) ? l.align.push("center") : /^ *:-+ *$/.test(o) ? l.align.push("left") : l.align.push(null);
      for (const o of n)
        l.header.push({
          text: o,
          tokens: this.lexer.inline(o)
        });
      for (const o of r)
        l.rows.push(Pn(o, l.header.length).map((s) => ({
          text: s,
          tokens: this.lexer.inline(s)
        })));
      return l;
    }
  }
  lheading(e) {
    const t = this.rules.block.lheading.exec(e);
    if (t)
      return {
        type: "heading",
        raw: t[0],
        depth: t[2].charAt(0) === "=" ? 1 : 2,
        text: t[1],
        tokens: this.lexer.inline(t[1])
      };
  }
  paragraph(e) {
    const t = this.rules.block.paragraph.exec(e);
    if (t) {
      const n = t[1].charAt(t[1].length - 1) === `
` ? t[1].slice(0, -1) : t[1];
      return {
        type: "paragraph",
        raw: t[0],
        text: n,
        tokens: this.lexer.inline(n)
      };
    }
  }
  text(e) {
    const t = this.rules.block.text.exec(e);
    if (t)
      return {
        type: "text",
        raw: t[0],
        text: t[0],
        tokens: this.lexer.inline(t[0])
      };
  }
  escape(e) {
    const t = this.rules.inline.escape.exec(e);
    if (t)
      return {
        type: "escape",
        raw: t[0],
        text: J(t[1])
      };
  }
  tag(e) {
    const t = this.rules.inline.tag.exec(e);
    if (t)
      return !this.lexer.state.inLink && /^<a /i.test(t[0]) ? this.lexer.state.inLink = !0 : this.lexer.state.inLink && /^<\/a>/i.test(t[0]) && (this.lexer.state.inLink = !1), !this.lexer.state.inRawBlock && /^<(pre|code|kbd|script)(\s|>)/i.test(t[0]) ? this.lexer.state.inRawBlock = !0 : this.lexer.state.inRawBlock && /^<\/(pre|code|kbd|script)(\s|>)/i.test(t[0]) && (this.lexer.state.inRawBlock = !1), {
        type: "html",
        raw: t[0],
        inLink: this.lexer.state.inLink,
        inRawBlock: this.lexer.state.inRawBlock,
        block: !1,
        text: t[0]
      };
  }
  link(e) {
    const t = this.rules.inline.link.exec(e);
    if (t) {
      const n = t[2].trim();
      if (!this.options.pedantic && /^</.test(n)) {
        if (!/>$/.test(n))
          return;
        const l = st(n.slice(0, -1), "\\");
        if ((n.length - l.length) % 2 === 0)
          return;
      } else {
        const l = El(t[2], "()");
        if (l > -1) {
          const s = (t[0].indexOf("!") === 0 ? 5 : 4) + t[1].length + l;
          t[2] = t[2].substring(0, l), t[0] = t[0].substring(0, s).trim(), t[3] = "";
        }
      }
      let a = t[2], r = "";
      if (this.options.pedantic) {
        const l = /^([^'"]*[^\s])\s+(['"])(.*)\2/.exec(a);
        l && (a = l[1], r = l[3]);
      } else
        r = t[3] ? t[3].slice(1, -1) : "";
      return a = a.trim(), /^</.test(a) && (this.options.pedantic && !/>$/.test(n) ? a = a.slice(1) : a = a.slice(1, -1)), Nn(t, {
        href: a && a.replace(this.rules.inline.anyPunctuation, "$1"),
        title: r && r.replace(this.rules.inline.anyPunctuation, "$1")
      }, t[0], this.lexer);
    }
  }
  reflink(e, t) {
    let n;
    if ((n = this.rules.inline.reflink.exec(e)) || (n = this.rules.inline.nolink.exec(e))) {
      const a = (n[2] || n[1]).replace(/\s+/g, " "), r = t[a.toLowerCase()];
      if (!r) {
        const l = n[0].charAt(0);
        return {
          type: "text",
          raw: l,
          text: l
        };
      }
      return Nn(n, r, n[0], this.lexer);
    }
  }
  emStrong(e, t, n = "") {
    let a = this.rules.inline.emStrongLDelim.exec(e);
    if (!a || a[3] && n.match(/[\p{L}\p{N}]/u))
      return;
    if (!(a[1] || a[2] || "") || !n || this.rules.inline.punctuation.exec(n)) {
      const l = [...a[0]].length - 1;
      let o, s, u = l, _ = 0;
      const f = a[0][0] === "*" ? this.rules.inline.emStrongRDelimAst : this.rules.inline.emStrongRDelimUnd;
      for (f.lastIndex = 0, t = t.slice(-1 * e.length + l); (a = f.exec(t)) != null; ) {
        if (o = a[1] || a[2] || a[3] || a[4] || a[5] || a[6], !o)
          continue;
        if (s = [...o].length, a[3] || a[4]) {
          u += s;
          continue;
        } else if ((a[5] || a[6]) && l % 3 && !((l + s) % 3)) {
          _ += s;
          continue;
        }
        if (u -= s, u > 0)
          continue;
        s = Math.min(s, s + u + _);
        const d = [...a[0]][0].length, h = e.slice(0, l + a.index + d + s);
        if (Math.min(l, s) % 2) {
          const w = h.slice(1, -1);
          return {
            type: "em",
            raw: h,
            text: w,
            tokens: this.lexer.inlineTokens(w)
          };
        }
        const m = h.slice(2, -2);
        return {
          type: "strong",
          raw: h,
          text: m,
          tokens: this.lexer.inlineTokens(m)
        };
      }
    }
  }
  codespan(e) {
    const t = this.rules.inline.code.exec(e);
    if (t) {
      let n = t[2].replace(/\n/g, " ");
      const a = /[^ ]/.test(n), r = /^ /.test(n) && / $/.test(n);
      return a && r && (n = n.substring(1, n.length - 1)), n = J(n, !0), {
        type: "codespan",
        raw: t[0],
        text: n
      };
    }
  }
  br(e) {
    const t = this.rules.inline.br.exec(e);
    if (t)
      return {
        type: "br",
        raw: t[0]
      };
  }
  del(e) {
    const t = this.rules.inline.del.exec(e);
    if (t)
      return {
        type: "del",
        raw: t[0],
        text: t[2],
        tokens: this.lexer.inlineTokens(t[2])
      };
  }
  autolink(e) {
    const t = this.rules.inline.autolink.exec(e);
    if (t) {
      let n, a;
      return t[2] === "@" ? (n = J(t[1]), a = "mailto:" + n) : (n = J(t[1]), a = n), {
        type: "link",
        raw: t[0],
        text: n,
        href: a,
        tokens: [
          {
            type: "text",
            raw: n,
            text: n
          }
        ]
      };
    }
  }
  url(e) {
    var n;
    let t;
    if (t = this.rules.inline.url.exec(e)) {
      let a, r;
      if (t[2] === "@")
        a = J(t[0]), r = "mailto:" + a;
      else {
        let l;
        do
          l = t[0], t[0] = ((n = this.rules.inline._backpedal.exec(t[0])) == null ? void 0 : n[0]) ?? "";
        while (l !== t[0]);
        a = J(t[0]), t[1] === "www." ? r = "http://" + t[0] : r = t[0];
      }
      return {
        type: "link",
        raw: t[0],
        text: a,
        href: r,
        tokens: [
          {
            type: "text",
            raw: a,
            text: a
          }
        ]
      };
    }
  }
  inlineText(e) {
    const t = this.rules.inline.text.exec(e);
    if (t) {
      let n;
      return this.lexer.state.inRawBlock ? n = t[0] : n = J(t[0]), {
        type: "text",
        raw: t[0],
        text: n
      };
    }
  }
}
const Sl = /^(?: *(?:\n|$))+/, xl = /^( {4}[^\n]+(?:\n(?: *(?:\n|$))*)?)+/, Bl = /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/, Qe = /^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/, Tl = /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/, Wi = /(?:[*+-]|\d{1,9}[.)])/, Yi = I(/^(?!bull |blockCode|fences|blockquote|heading|html)((?:.|\n(?!\s*?\n|bull |blockCode|fences|blockquote|heading|html))+?)\n {0,3}(=+|-+) *(?:\n+|$)/).replace(/bull/g, Wi).replace(/blockCode/g, / {4}/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).getRegex(), hn = /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/, ql = /^[^\n]+/, fn = /(?!\s*\])(?:\\.|[^\[\]\\])+/, Ll = I(/^ {0,3}\[(label)\]: *(?:\n *)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n *)?| *\n *)(title))? *(?:\n+|$)/).replace("label", fn).replace("title", /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/).getRegex(), zl = I(/^( {0,3}bull)([ \t][^\n]+?)?(?:\n|$)/).replace(/bull/g, Wi).getRegex(), $t = "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul", pn = /<!--(?:-?>|[\s\S]*?(?:-->|$))/, Il = I("^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>\\n*|$)|<![A-Z][\\s\\S]*?(?:>\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n *)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$))", "i").replace("comment", pn).replace("tag", $t).replace("attribute", / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex(), Ki = I(hn).replace("hr", Qe).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("|table", "").replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", $t).getRegex(), Rl = I(/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/).replace("paragraph", Ki).getRegex(), mn = {
  blockquote: Rl,
  code: xl,
  def: Ll,
  fences: Bl,
  heading: Tl,
  hr: Qe,
  html: Il,
  lheading: Yi,
  list: zl,
  newline: Sl,
  paragraph: Ki,
  table: Ue,
  text: ql
}, Hn = I("^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)").replace("hr", Qe).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("blockquote", " {0,3}>").replace("code", " {4}[^\\n]").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", $t).getRegex(), Ml = {
  ...mn,
  table: Hn,
  paragraph: I(hn).replace("hr", Qe).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("table", Hn).replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", $t).getRegex()
}, Ol = {
  ...mn,
  html: I(`^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`).replace("comment", pn).replace(/tag/g, "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(),
  def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/,
  heading: /^(#{1,6})(.*)(?:\n+|$)/,
  fences: Ue,
  // fences not supported
  lheading: /^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/,
  paragraph: I(hn).replace("hr", Qe).replace("heading", ` *#{1,6} *[^
]`).replace("lheading", Yi).replace("|table", "").replace("blockquote", " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html", "").replace("|tag", "").getRegex()
}, Qi = /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/, Pl = /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/, Ji = /^( {2,}|\\)\n(?!\s*$)/, Nl = /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/, Je = "\\p{P}\\p{S}", Hl = I(/^((?![*_])[\spunctuation])/, "u").replace(/punctuation/g, Je).getRegex(), jl = /\[[^[\]]*?\]\([^\(\)]*?\)|`[^`]*?`|<[^<>]*?>/g, Gl = I(/^(?:\*+(?:((?!\*)[punct])|[^\s*]))|^_+(?:((?!_)[punct])|([^\s_]))/, "u").replace(/punct/g, Je).getRegex(), Ul = I("^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)[punct](\\*+)(?=[\\s]|$)|[^punct\\s](\\*+)(?!\\*)(?=[punct\\s]|$)|(?!\\*)[punct\\s](\\*+)(?=[^punct\\s])|[\\s](\\*+)(?!\\*)(?=[punct])|(?!\\*)[punct](\\*+)(?!\\*)(?=[punct])|[^punct\\s](\\*+)(?=[^punct\\s])", "gu").replace(/punct/g, Je).getRegex(), Vl = I("^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)[punct](_+)(?=[\\s]|$)|[^punct\\s](_+)(?!_)(?=[punct\\s]|$)|(?!_)[punct\\s](_+)(?=[^punct\\s])|[\\s](_+)(?!_)(?=[punct])|(?!_)[punct](_+)(?!_)(?=[punct])", "gu").replace(/punct/g, Je).getRegex(), Zl = I(/\\([punct])/, "gu").replace(/punct/g, Je).getRegex(), Xl = I(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/).replace("scheme", /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/).replace("email", /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/).getRegex(), Wl = I(pn).replace("(?:-->|$)", "-->").getRegex(), Yl = I("^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>").replace("comment", Wl).replace("attribute", /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/).getRegex(), wt = /(?:\[(?:\\.|[^\[\]\\])*\]|\\.|`[^`]*`|[^\[\]\\`])*?/, Kl = I(/^!?\[(label)\]\(\s*(href)(?:\s+(title))?\s*\)/).replace("label", wt).replace("href", /<(?:\\.|[^\n<>\\])+>|[^\s\x00-\x1f]*/).replace("title", /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/).getRegex(), ea = I(/^!?\[(label)\]\[(ref)\]/).replace("label", wt).replace("ref", fn).getRegex(), ta = I(/^!?\[(ref)\](?:\[\])?/).replace("ref", fn).getRegex(), Ql = I("reflink|nolink(?!\\()", "g").replace("reflink", ea).replace("nolink", ta).getRegex(), gn = {
  _backpedal: Ue,
  // only used for GFM url
  anyPunctuation: Zl,
  autolink: Xl,
  blockSkip: jl,
  br: Ji,
  code: Pl,
  del: Ue,
  emStrongLDelim: Gl,
  emStrongRDelimAst: Ul,
  emStrongRDelimUnd: Vl,
  escape: Qi,
  link: Kl,
  nolink: ta,
  punctuation: Hl,
  reflink: ea,
  reflinkSearch: Ql,
  tag: Yl,
  text: Nl,
  url: Ue
}, Jl = {
  ...gn,
  link: I(/^!?\[(label)\]\((.*?)\)/).replace("label", wt).getRegex(),
  reflink: I(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", wt).getRegex()
}, Zt = {
  ...gn,
  escape: I(Qi).replace("])", "~|])").getRegex(),
  url: I(/^((?:ftp|https?):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/, "i").replace("email", /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/).getRegex(),
  _backpedal: /(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/,
  del: /^(~~?)(?=[^\s~])([\s\S]*?[^\s~])\1(?=[^~]|$)/,
  text: /^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|https?:\/\/|ftp:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/
}, er = {
  ...Zt,
  br: I(Ji).replace("{2,}", "*").getRegex(),
  text: I(Zt.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex()
}, ut = {
  normal: mn,
  gfm: Ml,
  pedantic: Ol
}, je = {
  normal: gn,
  gfm: Zt,
  breaks: er,
  pedantic: Jl
};
class De {
  constructor(e) {
    M(this, "tokens");
    M(this, "options");
    M(this, "state");
    M(this, "tokenizer");
    M(this, "inlineQueue");
    this.tokens = [], this.tokens.links = /* @__PURE__ */ Object.create(null), this.options = e || qe, this.options.tokenizer = this.options.tokenizer || new bt(), this.tokenizer = this.options.tokenizer, this.tokenizer.options = this.options, this.tokenizer.lexer = this, this.inlineQueue = [], this.state = {
      inLink: !1,
      inRawBlock: !1,
      top: !0
    };
    const t = {
      block: ut.normal,
      inline: je.normal
    };
    this.options.pedantic ? (t.block = ut.pedantic, t.inline = je.pedantic) : this.options.gfm && (t.block = ut.gfm, this.options.breaks ? t.inline = je.breaks : t.inline = je.gfm), this.tokenizer.rules = t;
  }
  /**
   * Expose Rules
   */
  static get rules() {
    return {
      block: ut,
      inline: je
    };
  }
  /**
   * Static Lex Method
   */
  static lex(e, t) {
    return new De(t).lex(e);
  }
  /**
   * Static Lex Inline Method
   */
  static lexInline(e, t) {
    return new De(t).inlineTokens(e);
  }
  /**
   * Preprocessing
   */
  lex(e) {
    e = e.replace(/\r\n|\r/g, `
`), this.blockTokens(e, this.tokens);
    for (let t = 0; t < this.inlineQueue.length; t++) {
      const n = this.inlineQueue[t];
      this.inlineTokens(n.src, n.tokens);
    }
    return this.inlineQueue = [], this.tokens;
  }
  blockTokens(e, t = []) {
    this.options.pedantic ? e = e.replace(/\t/g, "    ").replace(/^ +$/gm, "") : e = e.replace(/^( *)(\t+)/gm, (o, s, u) => s + "    ".repeat(u.length));
    let n, a, r, l;
    for (; e; )
      if (!(this.options.extensions && this.options.extensions.block && this.options.extensions.block.some((o) => (n = o.call({ lexer: this }, e, t)) ? (e = e.substring(n.raw.length), t.push(n), !0) : !1))) {
        if (n = this.tokenizer.space(e)) {
          e = e.substring(n.raw.length), n.raw.length === 1 && t.length > 0 ? t[t.length - 1].raw += `
` : t.push(n);
          continue;
        }
        if (n = this.tokenizer.code(e)) {
          e = e.substring(n.raw.length), a = t[t.length - 1], a && (a.type === "paragraph" || a.type === "text") ? (a.raw += `
` + n.raw, a.text += `
` + n.text, this.inlineQueue[this.inlineQueue.length - 1].src = a.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.fences(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.heading(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.hr(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.blockquote(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.list(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.html(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.def(e)) {
          e = e.substring(n.raw.length), a = t[t.length - 1], a && (a.type === "paragraph" || a.type === "text") ? (a.raw += `
` + n.raw, a.text += `
` + n.raw, this.inlineQueue[this.inlineQueue.length - 1].src = a.text) : this.tokens.links[n.tag] || (this.tokens.links[n.tag] = {
            href: n.href,
            title: n.title
          });
          continue;
        }
        if (n = this.tokenizer.table(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.lheading(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (r = e, this.options.extensions && this.options.extensions.startBlock) {
          let o = 1 / 0;
          const s = e.slice(1);
          let u;
          this.options.extensions.startBlock.forEach((_) => {
            u = _.call({ lexer: this }, s), typeof u == "number" && u >= 0 && (o = Math.min(o, u));
          }), o < 1 / 0 && o >= 0 && (r = e.substring(0, o + 1));
        }
        if (this.state.top && (n = this.tokenizer.paragraph(r))) {
          a = t[t.length - 1], l && a.type === "paragraph" ? (a.raw += `
` + n.raw, a.text += `
` + n.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = a.text) : t.push(n), l = r.length !== e.length, e = e.substring(n.raw.length);
          continue;
        }
        if (n = this.tokenizer.text(e)) {
          e = e.substring(n.raw.length), a = t[t.length - 1], a && a.type === "text" ? (a.raw += `
` + n.raw, a.text += `
` + n.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = a.text) : t.push(n);
          continue;
        }
        if (e) {
          const o = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(o);
            break;
          } else
            throw new Error(o);
        }
      }
    return this.state.top = !0, t;
  }
  inline(e, t = []) {
    return this.inlineQueue.push({ src: e, tokens: t }), t;
  }
  /**
   * Lexing/Compiling
   */
  inlineTokens(e, t = []) {
    let n, a, r, l = e, o, s, u;
    if (this.tokens.links) {
      const _ = Object.keys(this.tokens.links);
      if (_.length > 0)
        for (; (o = this.tokenizer.rules.inline.reflinkSearch.exec(l)) != null; )
          _.includes(o[0].slice(o[0].lastIndexOf("[") + 1, -1)) && (l = l.slice(0, o.index) + "[" + "a".repeat(o[0].length - 2) + "]" + l.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex));
    }
    for (; (o = this.tokenizer.rules.inline.blockSkip.exec(l)) != null; )
      l = l.slice(0, o.index) + "[" + "a".repeat(o[0].length - 2) + "]" + l.slice(this.tokenizer.rules.inline.blockSkip.lastIndex);
    for (; (o = this.tokenizer.rules.inline.anyPunctuation.exec(l)) != null; )
      l = l.slice(0, o.index) + "++" + l.slice(this.tokenizer.rules.inline.anyPunctuation.lastIndex);
    for (; e; )
      if (s || (u = ""), s = !1, !(this.options.extensions && this.options.extensions.inline && this.options.extensions.inline.some((_) => (n = _.call({ lexer: this }, e, t)) ? (e = e.substring(n.raw.length), t.push(n), !0) : !1))) {
        if (n = this.tokenizer.escape(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.tag(e)) {
          e = e.substring(n.raw.length), a = t[t.length - 1], a && n.type === "text" && a.type === "text" ? (a.raw += n.raw, a.text += n.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.link(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.reflink(e, this.tokens.links)) {
          e = e.substring(n.raw.length), a = t[t.length - 1], a && n.type === "text" && a.type === "text" ? (a.raw += n.raw, a.text += n.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.emStrong(e, l, u)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.codespan(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.br(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.del(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.autolink(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (!this.state.inLink && (n = this.tokenizer.url(e))) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (r = e, this.options.extensions && this.options.extensions.startInline) {
          let _ = 1 / 0;
          const f = e.slice(1);
          let d;
          this.options.extensions.startInline.forEach((h) => {
            d = h.call({ lexer: this }, f), typeof d == "number" && d >= 0 && (_ = Math.min(_, d));
          }), _ < 1 / 0 && _ >= 0 && (r = e.substring(0, _ + 1));
        }
        if (n = this.tokenizer.inlineText(r)) {
          e = e.substring(n.raw.length), n.raw.slice(-1) !== "_" && (u = n.raw.slice(-1)), s = !0, a = t[t.length - 1], a && a.type === "text" ? (a.raw += n.raw, a.text += n.text) : t.push(n);
          continue;
        }
        if (e) {
          const _ = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(_);
            break;
          } else
            throw new Error(_);
        }
      }
    return t;
  }
}
class yt {
  constructor(e) {
    M(this, "options");
    this.options = e || qe;
  }
  code(e, t, n) {
    var r;
    const a = (r = (t || "").match(/^\S*/)) == null ? void 0 : r[0];
    return e = e.replace(/\n$/, "") + `
`, a ? '<pre><code class="language-' + J(a) + '">' + (n ? e : J(e, !0)) + `</code></pre>
` : "<pre><code>" + (n ? e : J(e, !0)) + `</code></pre>
`;
  }
  blockquote(e) {
    return `<blockquote>
${e}</blockquote>
`;
  }
  html(e, t) {
    return e;
  }
  heading(e, t, n) {
    return `<h${t}>${e}</h${t}>
`;
  }
  hr() {
    return `<hr>
`;
  }
  list(e, t, n) {
    const a = t ? "ol" : "ul", r = t && n !== 1 ? ' start="' + n + '"' : "";
    return "<" + a + r + `>
` + e + "</" + a + `>
`;
  }
  listitem(e, t, n) {
    return `<li>${e}</li>
`;
  }
  checkbox(e) {
    return "<input " + (e ? 'checked="" ' : "") + 'disabled="" type="checkbox">';
  }
  paragraph(e) {
    return `<p>${e}</p>
`;
  }
  table(e, t) {
    return t && (t = `<tbody>${t}</tbody>`), `<table>
<thead>
` + e + `</thead>
` + t + `</table>
`;
  }
  tablerow(e) {
    return `<tr>
${e}</tr>
`;
  }
  tablecell(e, t) {
    const n = t.header ? "th" : "td";
    return (t.align ? `<${n} align="${t.align}">` : `<${n}>`) + e + `</${n}>
`;
  }
  /**
   * span level renderer
   */
  strong(e) {
    return `<strong>${e}</strong>`;
  }
  em(e) {
    return `<em>${e}</em>`;
  }
  codespan(e) {
    return `<code>${e}</code>`;
  }
  br() {
    return "<br>";
  }
  del(e) {
    return `<del>${e}</del>`;
  }
  link(e, t, n) {
    const a = On(e);
    if (a === null)
      return n;
    e = a;
    let r = '<a href="' + e + '"';
    return t && (r += ' title="' + t + '"'), r += ">" + n + "</a>", r;
  }
  image(e, t, n) {
    const a = On(e);
    if (a === null)
      return n;
    e = a;
    let r = `<img src="${e}" alt="${n}"`;
    return t && (r += ` title="${t}"`), r += ">", r;
  }
  text(e) {
    return e;
  }
}
class vn {
  // no need for block level renderers
  strong(e) {
    return e;
  }
  em(e) {
    return e;
  }
  codespan(e) {
    return e;
  }
  del(e) {
    return e;
  }
  html(e) {
    return e;
  }
  text(e) {
    return e;
  }
  link(e, t, n) {
    return "" + n;
  }
  image(e, t, n) {
    return "" + n;
  }
  br() {
    return "";
  }
}
class be {
  constructor(e) {
    M(this, "options");
    M(this, "renderer");
    M(this, "textRenderer");
    this.options = e || qe, this.options.renderer = this.options.renderer || new yt(), this.renderer = this.options.renderer, this.renderer.options = this.options, this.textRenderer = new vn();
  }
  /**
   * Static Parse Method
   */
  static parse(e, t) {
    return new be(t).parse(e);
  }
  /**
   * Static Parse Inline Method
   */
  static parseInline(e, t) {
    return new be(t).parseInline(e);
  }
  /**
   * Parse Loop
   */
  parse(e, t = !0) {
    let n = "";
    for (let a = 0; a < e.length; a++) {
      const r = e[a];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[r.type]) {
        const l = r, o = this.options.extensions.renderers[l.type].call({ parser: this }, l);
        if (o !== !1 || !["space", "hr", "heading", "code", "table", "blockquote", "list", "html", "paragraph", "text"].includes(l.type)) {
          n += o || "";
          continue;
        }
      }
      switch (r.type) {
        case "space":
          continue;
        case "hr": {
          n += this.renderer.hr();
          continue;
        }
        case "heading": {
          const l = r;
          n += this.renderer.heading(this.parseInline(l.tokens), l.depth, $l(this.parseInline(l.tokens, this.textRenderer)));
          continue;
        }
        case "code": {
          const l = r;
          n += this.renderer.code(l.text, l.lang, !!l.escaped);
          continue;
        }
        case "table": {
          const l = r;
          let o = "", s = "";
          for (let _ = 0; _ < l.header.length; _++)
            s += this.renderer.tablecell(this.parseInline(l.header[_].tokens), { header: !0, align: l.align[_] });
          o += this.renderer.tablerow(s);
          let u = "";
          for (let _ = 0; _ < l.rows.length; _++) {
            const f = l.rows[_];
            s = "";
            for (let d = 0; d < f.length; d++)
              s += this.renderer.tablecell(this.parseInline(f[d].tokens), { header: !1, align: l.align[d] });
            u += this.renderer.tablerow(s);
          }
          n += this.renderer.table(o, u);
          continue;
        }
        case "blockquote": {
          const l = r, o = this.parse(l.tokens);
          n += this.renderer.blockquote(o);
          continue;
        }
        case "list": {
          const l = r, o = l.ordered, s = l.start, u = l.loose;
          let _ = "";
          for (let f = 0; f < l.items.length; f++) {
            const d = l.items[f], h = d.checked, m = d.task;
            let w = "";
            if (d.task) {
              const y = this.renderer.checkbox(!!h);
              u ? d.tokens.length > 0 && d.tokens[0].type === "paragraph" ? (d.tokens[0].text = y + " " + d.tokens[0].text, d.tokens[0].tokens && d.tokens[0].tokens.length > 0 && d.tokens[0].tokens[0].type === "text" && (d.tokens[0].tokens[0].text = y + " " + d.tokens[0].tokens[0].text)) : d.tokens.unshift({
                type: "text",
                text: y + " "
              }) : w += y + " ";
            }
            w += this.parse(d.tokens, u), _ += this.renderer.listitem(w, m, !!h);
          }
          n += this.renderer.list(_, o, s);
          continue;
        }
        case "html": {
          const l = r;
          n += this.renderer.html(l.text, l.block);
          continue;
        }
        case "paragraph": {
          const l = r;
          n += this.renderer.paragraph(this.parseInline(l.tokens));
          continue;
        }
        case "text": {
          let l = r, o = l.tokens ? this.parseInline(l.tokens) : l.text;
          for (; a + 1 < e.length && e[a + 1].type === "text"; )
            l = e[++a], o += `
` + (l.tokens ? this.parseInline(l.tokens) : l.text);
          n += t ? this.renderer.paragraph(o) : o;
          continue;
        }
        default: {
          const l = 'Token with "' + r.type + '" type was not found.';
          if (this.options.silent)
            return console.error(l), "";
          throw new Error(l);
        }
      }
    }
    return n;
  }
  /**
   * Parse Inline Tokens
   */
  parseInline(e, t) {
    t = t || this.renderer;
    let n = "";
    for (let a = 0; a < e.length; a++) {
      const r = e[a];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[r.type]) {
        const l = this.options.extensions.renderers[r.type].call({ parser: this }, r);
        if (l !== !1 || !["escape", "html", "link", "image", "strong", "em", "codespan", "br", "del", "text"].includes(r.type)) {
          n += l || "";
          continue;
        }
      }
      switch (r.type) {
        case "escape": {
          const l = r;
          n += t.text(l.text);
          break;
        }
        case "html": {
          const l = r;
          n += t.html(l.text);
          break;
        }
        case "link": {
          const l = r;
          n += t.link(l.href, l.title, this.parseInline(l.tokens, t));
          break;
        }
        case "image": {
          const l = r;
          n += t.image(l.href, l.title, l.text);
          break;
        }
        case "strong": {
          const l = r;
          n += t.strong(this.parseInline(l.tokens, t));
          break;
        }
        case "em": {
          const l = r;
          n += t.em(this.parseInline(l.tokens, t));
          break;
        }
        case "codespan": {
          const l = r;
          n += t.codespan(l.text);
          break;
        }
        case "br": {
          n += t.br();
          break;
        }
        case "del": {
          const l = r;
          n += t.del(this.parseInline(l.tokens, t));
          break;
        }
        case "text": {
          const l = r;
          n += t.text(l.text);
          break;
        }
        default: {
          const l = 'Token with "' + r.type + '" type was not found.';
          if (this.options.silent)
            return console.error(l), "";
          throw new Error(l);
        }
      }
    }
    return n;
  }
}
class Ve {
  constructor(e) {
    M(this, "options");
    this.options = e || qe;
  }
  /**
   * Process markdown before marked
   */
  preprocess(e) {
    return e;
  }
  /**
   * Process HTML after marked is finished
   */
  postprocess(e) {
    return e;
  }
  /**
   * Process all tokens before walk tokens
   */
  processAllTokens(e) {
    return e;
  }
}
M(Ve, "passThroughHooks", /* @__PURE__ */ new Set([
  "preprocess",
  "postprocess",
  "processAllTokens"
]));
var Te, Xt, ia;
class na {
  constructor(...e) {
    Cn(this, Te);
    M(this, "defaults", dn());
    M(this, "options", this.setOptions);
    M(this, "parse", nt(this, Te, Xt).call(this, De.lex, be.parse));
    M(this, "parseInline", nt(this, Te, Xt).call(this, De.lexInline, be.parseInline));
    M(this, "Parser", be);
    M(this, "Renderer", yt);
    M(this, "TextRenderer", vn);
    M(this, "Lexer", De);
    M(this, "Tokenizer", bt);
    M(this, "Hooks", Ve);
    this.use(...e);
  }
  /**
   * Run callback for every token
   */
  walkTokens(e, t) {
    var a, r;
    let n = [];
    for (const l of e)
      switch (n = n.concat(t.call(this, l)), l.type) {
        case "table": {
          const o = l;
          for (const s of o.header)
            n = n.concat(this.walkTokens(s.tokens, t));
          for (const s of o.rows)
            for (const u of s)
              n = n.concat(this.walkTokens(u.tokens, t));
          break;
        }
        case "list": {
          const o = l;
          n = n.concat(this.walkTokens(o.items, t));
          break;
        }
        default: {
          const o = l;
          (r = (a = this.defaults.extensions) == null ? void 0 : a.childTokens) != null && r[o.type] ? this.defaults.extensions.childTokens[o.type].forEach((s) => {
            const u = o[s].flat(1 / 0);
            n = n.concat(this.walkTokens(u, t));
          }) : o.tokens && (n = n.concat(this.walkTokens(o.tokens, t)));
        }
      }
    return n;
  }
  use(...e) {
    const t = this.defaults.extensions || { renderers: {}, childTokens: {} };
    return e.forEach((n) => {
      const a = { ...n };
      if (a.async = this.defaults.async || a.async || !1, n.extensions && (n.extensions.forEach((r) => {
        if (!r.name)
          throw new Error("extension name required");
        if ("renderer" in r) {
          const l = t.renderers[r.name];
          l ? t.renderers[r.name] = function(...o) {
            let s = r.renderer.apply(this, o);
            return s === !1 && (s = l.apply(this, o)), s;
          } : t.renderers[r.name] = r.renderer;
        }
        if ("tokenizer" in r) {
          if (!r.level || r.level !== "block" && r.level !== "inline")
            throw new Error("extension level must be 'block' or 'inline'");
          const l = t[r.level];
          l ? l.unshift(r.tokenizer) : t[r.level] = [r.tokenizer], r.start && (r.level === "block" ? t.startBlock ? t.startBlock.push(r.start) : t.startBlock = [r.start] : r.level === "inline" && (t.startInline ? t.startInline.push(r.start) : t.startInline = [r.start]));
        }
        "childTokens" in r && r.childTokens && (t.childTokens[r.name] = r.childTokens);
      }), a.extensions = t), n.renderer) {
        const r = this.defaults.renderer || new yt(this.defaults);
        for (const l in n.renderer) {
          if (!(l in r))
            throw new Error(`renderer '${l}' does not exist`);
          if (l === "options")
            continue;
          const o = l, s = n.renderer[o], u = r[o];
          r[o] = (..._) => {
            let f = s.apply(r, _);
            return f === !1 && (f = u.apply(r, _)), f || "";
          };
        }
        a.renderer = r;
      }
      if (n.tokenizer) {
        const r = this.defaults.tokenizer || new bt(this.defaults);
        for (const l in n.tokenizer) {
          if (!(l in r))
            throw new Error(`tokenizer '${l}' does not exist`);
          if (["options", "rules", "lexer"].includes(l))
            continue;
          const o = l, s = n.tokenizer[o], u = r[o];
          r[o] = (..._) => {
            let f = s.apply(r, _);
            return f === !1 && (f = u.apply(r, _)), f;
          };
        }
        a.tokenizer = r;
      }
      if (n.hooks) {
        const r = this.defaults.hooks || new Ve();
        for (const l in n.hooks) {
          if (!(l in r))
            throw new Error(`hook '${l}' does not exist`);
          if (l === "options")
            continue;
          const o = l, s = n.hooks[o], u = r[o];
          Ve.passThroughHooks.has(l) ? r[o] = (_) => {
            if (this.defaults.async)
              return Promise.resolve(s.call(r, _)).then((d) => u.call(r, d));
            const f = s.call(r, _);
            return u.call(r, f);
          } : r[o] = (..._) => {
            let f = s.apply(r, _);
            return f === !1 && (f = u.apply(r, _)), f;
          };
        }
        a.hooks = r;
      }
      if (n.walkTokens) {
        const r = this.defaults.walkTokens, l = n.walkTokens;
        a.walkTokens = function(o) {
          let s = [];
          return s.push(l.call(this, o)), r && (s = s.concat(r.call(this, o))), s;
        };
      }
      this.defaults = { ...this.defaults, ...a };
    }), this;
  }
  setOptions(e) {
    return this.defaults = { ...this.defaults, ...e }, this;
  }
  lexer(e, t) {
    return De.lex(e, t ?? this.defaults);
  }
  parser(e, t) {
    return be.parse(e, t ?? this.defaults);
  }
}
Te = new WeakSet(), Xt = function(e, t) {
  return (n, a) => {
    const r = { ...a }, l = { ...this.defaults, ...r };
    this.defaults.async === !0 && r.async === !1 && (l.silent || console.warn("marked(): The async option was set to true by an extension. The async: false option sent to parse will be ignored."), l.async = !0);
    const o = nt(this, Te, ia).call(this, !!l.silent, !!l.async);
    if (typeof n > "u" || n === null)
      return o(new Error("marked(): input parameter is undefined or null"));
    if (typeof n != "string")
      return o(new Error("marked(): input parameter is of type " + Object.prototype.toString.call(n) + ", string expected"));
    if (l.hooks && (l.hooks.options = l), l.async)
      return Promise.resolve(l.hooks ? l.hooks.preprocess(n) : n).then((s) => e(s, l)).then((s) => l.hooks ? l.hooks.processAllTokens(s) : s).then((s) => l.walkTokens ? Promise.all(this.walkTokens(s, l.walkTokens)).then(() => s) : s).then((s) => t(s, l)).then((s) => l.hooks ? l.hooks.postprocess(s) : s).catch(o);
    try {
      l.hooks && (n = l.hooks.preprocess(n));
      let s = e(n, l);
      l.hooks && (s = l.hooks.processAllTokens(s)), l.walkTokens && this.walkTokens(s, l.walkTokens);
      let u = t(s, l);
      return l.hooks && (u = l.hooks.postprocess(u)), u;
    } catch (s) {
      return o(s);
    }
  };
}, ia = function(e, t) {
  return (n) => {
    if (n.message += `
Please report this to https://github.com/markedjs/marked.`, e) {
      const a = "<p>An error occurred:</p><pre>" + J(n.message + "", !0) + "</pre>";
      return t ? Promise.resolve(a) : a;
    }
    if (t)
      return Promise.reject(n);
    throw n;
  };
};
const Be = new na();
function z(i, e) {
  return Be.parse(i, e);
}
z.options = z.setOptions = function(i) {
  return Be.setOptions(i), z.defaults = Be.defaults, Vi(z.defaults), z;
};
z.getDefaults = dn;
z.defaults = qe;
z.use = function(...i) {
  return Be.use(...i), z.defaults = Be.defaults, Vi(z.defaults), z;
};
z.walkTokens = function(i, e) {
  return Be.walkTokens(i, e);
};
z.parseInline = Be.parseInline;
z.Parser = be;
z.parser = be.parse;
z.Renderer = yt;
z.TextRenderer = vn;
z.Lexer = De;
z.lexer = De.lex;
z.Tokenizer = bt;
z.Hooks = Ve;
z.parse = z;
z.options;
z.setOptions;
z.use;
z.walkTokens;
z.parseInline;
be.parse;
De.lex;
function tr(i) {
  if (typeof i == "function" && (i = {
    highlight: i
  }), !i || typeof i.highlight != "function")
    throw new Error("Must provide highlight function");
  return typeof i.langPrefix != "string" && (i.langPrefix = "language-"), typeof i.emptyLangClass != "string" && (i.emptyLangClass = ""), {
    async: !!i.async,
    walkTokens(e) {
      if (e.type !== "code")
        return;
      const t = jn(e.lang);
      if (i.async)
        return Promise.resolve(i.highlight(e.text, t, e.lang || "")).then(Gn(e));
      const n = i.highlight(e.text, t, e.lang || "");
      if (n instanceof Promise)
        throw new Error("markedHighlight is not set to async but the highlight function is async. Set the async option to true on markedHighlight to await the async highlight function.");
      Gn(e)(n);
    },
    useNewRenderer: !0,
    renderer: {
      code(e, t, n) {
        typeof e == "object" && (n = e.escaped, t = e.lang, e = e.text);
        const a = jn(t), r = a ? i.langPrefix + Vn(a) : i.emptyLangClass, l = r ? ` class="${r}"` : "";
        return e = e.replace(/\n$/, ""), `<pre><code${l}>${n ? e : Vn(e, !0)}
</code></pre>`;
      }
    }
  };
}
function jn(i) {
  return (i || "").match(/\S*/)[0];
}
function Gn(i) {
  return (e) => {
    typeof e == "string" && e !== i.text && (i.escaped = !0, i.text = e);
  };
}
const aa = /[&<>"']/, nr = new RegExp(aa.source, "g"), la = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, ir = new RegExp(la.source, "g"), ar = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, Un = (i) => ar[i];
function Vn(i, e) {
  if (e) {
    if (aa.test(i))
      return i.replace(nr, Un);
  } else if (la.test(i))
    return i.replace(ir, Un);
  return i;
}
const lr = /[\0-\x1F!-,\.\/:-@\[-\^`\{-\xA9\xAB-\xB4\xB6-\xB9\xBB-\xBF\xD7\xF7\u02C2-\u02C5\u02D2-\u02DF\u02E5-\u02EB\u02ED\u02EF-\u02FF\u0375\u0378\u0379\u037E\u0380-\u0385\u0387\u038B\u038D\u03A2\u03F6\u0482\u0530\u0557\u0558\u055A-\u055F\u0589-\u0590\u05BE\u05C0\u05C3\u05C6\u05C8-\u05CF\u05EB-\u05EE\u05F3-\u060F\u061B-\u061F\u066A-\u066D\u06D4\u06DD\u06DE\u06E9\u06FD\u06FE\u0700-\u070F\u074B\u074C\u07B2-\u07BF\u07F6-\u07F9\u07FB\u07FC\u07FE\u07FF\u082E-\u083F\u085C-\u085F\u086B-\u089F\u08B5\u08C8-\u08D2\u08E2\u0964\u0965\u0970\u0984\u098D\u098E\u0991\u0992\u09A9\u09B1\u09B3-\u09B5\u09BA\u09BB\u09C5\u09C6\u09C9\u09CA\u09CF-\u09D6\u09D8-\u09DB\u09DE\u09E4\u09E5\u09F2-\u09FB\u09FD\u09FF\u0A00\u0A04\u0A0B-\u0A0E\u0A11\u0A12\u0A29\u0A31\u0A34\u0A37\u0A3A\u0A3B\u0A3D\u0A43-\u0A46\u0A49\u0A4A\u0A4E-\u0A50\u0A52-\u0A58\u0A5D\u0A5F-\u0A65\u0A76-\u0A80\u0A84\u0A8E\u0A92\u0AA9\u0AB1\u0AB4\u0ABA\u0ABB\u0AC6\u0ACA\u0ACE\u0ACF\u0AD1-\u0ADF\u0AE4\u0AE5\u0AF0-\u0AF8\u0B00\u0B04\u0B0D\u0B0E\u0B11\u0B12\u0B29\u0B31\u0B34\u0B3A\u0B3B\u0B45\u0B46\u0B49\u0B4A\u0B4E-\u0B54\u0B58-\u0B5B\u0B5E\u0B64\u0B65\u0B70\u0B72-\u0B81\u0B84\u0B8B-\u0B8D\u0B91\u0B96-\u0B98\u0B9B\u0B9D\u0BA0-\u0BA2\u0BA5-\u0BA7\u0BAB-\u0BAD\u0BBA-\u0BBD\u0BC3-\u0BC5\u0BC9\u0BCE\u0BCF\u0BD1-\u0BD6\u0BD8-\u0BE5\u0BF0-\u0BFF\u0C0D\u0C11\u0C29\u0C3A-\u0C3C\u0C45\u0C49\u0C4E-\u0C54\u0C57\u0C5B-\u0C5F\u0C64\u0C65\u0C70-\u0C7F\u0C84\u0C8D\u0C91\u0CA9\u0CB4\u0CBA\u0CBB\u0CC5\u0CC9\u0CCE-\u0CD4\u0CD7-\u0CDD\u0CDF\u0CE4\u0CE5\u0CF0\u0CF3-\u0CFF\u0D0D\u0D11\u0D45\u0D49\u0D4F-\u0D53\u0D58-\u0D5E\u0D64\u0D65\u0D70-\u0D79\u0D80\u0D84\u0D97-\u0D99\u0DB2\u0DBC\u0DBE\u0DBF\u0DC7-\u0DC9\u0DCB-\u0DCE\u0DD5\u0DD7\u0DE0-\u0DE5\u0DF0\u0DF1\u0DF4-\u0E00\u0E3B-\u0E3F\u0E4F\u0E5A-\u0E80\u0E83\u0E85\u0E8B\u0EA4\u0EA6\u0EBE\u0EBF\u0EC5\u0EC7\u0ECE\u0ECF\u0EDA\u0EDB\u0EE0-\u0EFF\u0F01-\u0F17\u0F1A-\u0F1F\u0F2A-\u0F34\u0F36\u0F38\u0F3A-\u0F3D\u0F48\u0F6D-\u0F70\u0F85\u0F98\u0FBD-\u0FC5\u0FC7-\u0FFF\u104A-\u104F\u109E\u109F\u10C6\u10C8-\u10CC\u10CE\u10CF\u10FB\u1249\u124E\u124F\u1257\u1259\u125E\u125F\u1289\u128E\u128F\u12B1\u12B6\u12B7\u12BF\u12C1\u12C6\u12C7\u12D7\u1311\u1316\u1317\u135B\u135C\u1360-\u137F\u1390-\u139F\u13F6\u13F7\u13FE-\u1400\u166D\u166E\u1680\u169B-\u169F\u16EB-\u16ED\u16F9-\u16FF\u170D\u1715-\u171F\u1735-\u173F\u1754-\u175F\u176D\u1771\u1774-\u177F\u17D4-\u17D6\u17D8-\u17DB\u17DE\u17DF\u17EA-\u180A\u180E\u180F\u181A-\u181F\u1879-\u187F\u18AB-\u18AF\u18F6-\u18FF\u191F\u192C-\u192F\u193C-\u1945\u196E\u196F\u1975-\u197F\u19AC-\u19AF\u19CA-\u19CF\u19DA-\u19FF\u1A1C-\u1A1F\u1A5F\u1A7D\u1A7E\u1A8A-\u1A8F\u1A9A-\u1AA6\u1AA8-\u1AAF\u1AC1-\u1AFF\u1B4C-\u1B4F\u1B5A-\u1B6A\u1B74-\u1B7F\u1BF4-\u1BFF\u1C38-\u1C3F\u1C4A-\u1C4C\u1C7E\u1C7F\u1C89-\u1C8F\u1CBB\u1CBC\u1CC0-\u1CCF\u1CD3\u1CFB-\u1CFF\u1DFA\u1F16\u1F17\u1F1E\u1F1F\u1F46\u1F47\u1F4E\u1F4F\u1F58\u1F5A\u1F5C\u1F5E\u1F7E\u1F7F\u1FB5\u1FBD\u1FBF-\u1FC1\u1FC5\u1FCD-\u1FCF\u1FD4\u1FD5\u1FDC-\u1FDF\u1FED-\u1FF1\u1FF5\u1FFD-\u203E\u2041-\u2053\u2055-\u2070\u2072-\u207E\u2080-\u208F\u209D-\u20CF\u20F1-\u2101\u2103-\u2106\u2108\u2109\u2114\u2116-\u2118\u211E-\u2123\u2125\u2127\u2129\u212E\u213A\u213B\u2140-\u2144\u214A-\u214D\u214F-\u215F\u2189-\u24B5\u24EA-\u2BFF\u2C2F\u2C5F\u2CE5-\u2CEA\u2CF4-\u2CFF\u2D26\u2D28-\u2D2C\u2D2E\u2D2F\u2D68-\u2D6E\u2D70-\u2D7E\u2D97-\u2D9F\u2DA7\u2DAF\u2DB7\u2DBF\u2DC7\u2DCF\u2DD7\u2DDF\u2E00-\u2E2E\u2E30-\u3004\u3008-\u3020\u3030\u3036\u3037\u303D-\u3040\u3097\u3098\u309B\u309C\u30A0\u30FB\u3100-\u3104\u3130\u318F-\u319F\u31C0-\u31EF\u3200-\u33FF\u4DC0-\u4DFF\u9FFD-\u9FFF\uA48D-\uA4CF\uA4FE\uA4FF\uA60D-\uA60F\uA62C-\uA63F\uA673\uA67E\uA6F2-\uA716\uA720\uA721\uA789\uA78A\uA7C0\uA7C1\uA7CB-\uA7F4\uA828-\uA82B\uA82D-\uA83F\uA874-\uA87F\uA8C6-\uA8CF\uA8DA-\uA8DF\uA8F8-\uA8FA\uA8FC\uA92E\uA92F\uA954-\uA95F\uA97D-\uA97F\uA9C1-\uA9CE\uA9DA-\uA9DF\uA9FF\uAA37-\uAA3F\uAA4E\uAA4F\uAA5A-\uAA5F\uAA77-\uAA79\uAAC3-\uAADA\uAADE\uAADF\uAAF0\uAAF1\uAAF7-\uAB00\uAB07\uAB08\uAB0F\uAB10\uAB17-\uAB1F\uAB27\uAB2F\uAB5B\uAB6A-\uAB6F\uABEB\uABEE\uABEF\uABFA-\uABFF\uD7A4-\uD7AF\uD7C7-\uD7CA\uD7FC-\uD7FF\uE000-\uF8FF\uFA6E\uFA6F\uFADA-\uFAFF\uFB07-\uFB12\uFB18-\uFB1C\uFB29\uFB37\uFB3D\uFB3F\uFB42\uFB45\uFBB2-\uFBD2\uFD3E-\uFD4F\uFD90\uFD91\uFDC8-\uFDEF\uFDFC-\uFDFF\uFE10-\uFE1F\uFE30-\uFE32\uFE35-\uFE4C\uFE50-\uFE6F\uFE75\uFEFD-\uFF0F\uFF1A-\uFF20\uFF3B-\uFF3E\uFF40\uFF5B-\uFF65\uFFBF-\uFFC1\uFFC8\uFFC9\uFFD0\uFFD1\uFFD8\uFFD9\uFFDD-\uFFFF]|\uD800[\uDC0C\uDC27\uDC3B\uDC3E\uDC4E\uDC4F\uDC5E-\uDC7F\uDCFB-\uDD3F\uDD75-\uDDFC\uDDFE-\uDE7F\uDE9D-\uDE9F\uDED1-\uDEDF\uDEE1-\uDEFF\uDF20-\uDF2C\uDF4B-\uDF4F\uDF7B-\uDF7F\uDF9E\uDF9F\uDFC4-\uDFC7\uDFD0\uDFD6-\uDFFF]|\uD801[\uDC9E\uDC9F\uDCAA-\uDCAF\uDCD4-\uDCD7\uDCFC-\uDCFF\uDD28-\uDD2F\uDD64-\uDDFF\uDF37-\uDF3F\uDF56-\uDF5F\uDF68-\uDFFF]|\uD802[\uDC06\uDC07\uDC09\uDC36\uDC39-\uDC3B\uDC3D\uDC3E\uDC56-\uDC5F\uDC77-\uDC7F\uDC9F-\uDCDF\uDCF3\uDCF6-\uDCFF\uDD16-\uDD1F\uDD3A-\uDD7F\uDDB8-\uDDBD\uDDC0-\uDDFF\uDE04\uDE07-\uDE0B\uDE14\uDE18\uDE36\uDE37\uDE3B-\uDE3E\uDE40-\uDE5F\uDE7D-\uDE7F\uDE9D-\uDEBF\uDEC8\uDEE7-\uDEFF\uDF36-\uDF3F\uDF56-\uDF5F\uDF73-\uDF7F\uDF92-\uDFFF]|\uD803[\uDC49-\uDC7F\uDCB3-\uDCBF\uDCF3-\uDCFF\uDD28-\uDD2F\uDD3A-\uDE7F\uDEAA\uDEAD-\uDEAF\uDEB2-\uDEFF\uDF1D-\uDF26\uDF28-\uDF2F\uDF51-\uDFAF\uDFC5-\uDFDF\uDFF7-\uDFFF]|\uD804[\uDC47-\uDC65\uDC70-\uDC7E\uDCBB-\uDCCF\uDCE9-\uDCEF\uDCFA-\uDCFF\uDD35\uDD40-\uDD43\uDD48-\uDD4F\uDD74\uDD75\uDD77-\uDD7F\uDDC5-\uDDC8\uDDCD\uDDDB\uDDDD-\uDDFF\uDE12\uDE38-\uDE3D\uDE3F-\uDE7F\uDE87\uDE89\uDE8E\uDE9E\uDEA9-\uDEAF\uDEEB-\uDEEF\uDEFA-\uDEFF\uDF04\uDF0D\uDF0E\uDF11\uDF12\uDF29\uDF31\uDF34\uDF3A\uDF45\uDF46\uDF49\uDF4A\uDF4E\uDF4F\uDF51-\uDF56\uDF58-\uDF5C\uDF64\uDF65\uDF6D-\uDF6F\uDF75-\uDFFF]|\uD805[\uDC4B-\uDC4F\uDC5A-\uDC5D\uDC62-\uDC7F\uDCC6\uDCC8-\uDCCF\uDCDA-\uDD7F\uDDB6\uDDB7\uDDC1-\uDDD7\uDDDE-\uDDFF\uDE41-\uDE43\uDE45-\uDE4F\uDE5A-\uDE7F\uDEB9-\uDEBF\uDECA-\uDEFF\uDF1B\uDF1C\uDF2C-\uDF2F\uDF3A-\uDFFF]|\uD806[\uDC3B-\uDC9F\uDCEA-\uDCFE\uDD07\uDD08\uDD0A\uDD0B\uDD14\uDD17\uDD36\uDD39\uDD3A\uDD44-\uDD4F\uDD5A-\uDD9F\uDDA8\uDDA9\uDDD8\uDDD9\uDDE2\uDDE5-\uDDFF\uDE3F-\uDE46\uDE48-\uDE4F\uDE9A-\uDE9C\uDE9E-\uDEBF\uDEF9-\uDFFF]|\uD807[\uDC09\uDC37\uDC41-\uDC4F\uDC5A-\uDC71\uDC90\uDC91\uDCA8\uDCB7-\uDCFF\uDD07\uDD0A\uDD37-\uDD39\uDD3B\uDD3E\uDD48-\uDD4F\uDD5A-\uDD5F\uDD66\uDD69\uDD8F\uDD92\uDD99-\uDD9F\uDDAA-\uDEDF\uDEF7-\uDFAF\uDFB1-\uDFFF]|\uD808[\uDF9A-\uDFFF]|\uD809[\uDC6F-\uDC7F\uDD44-\uDFFF]|[\uD80A\uD80B\uD80E-\uD810\uD812-\uD819\uD824-\uD82B\uD82D\uD82E\uD830-\uD833\uD837\uD839\uD83D\uD83F\uD87B-\uD87D\uD87F\uD885-\uDB3F\uDB41-\uDBFF][\uDC00-\uDFFF]|\uD80D[\uDC2F-\uDFFF]|\uD811[\uDE47-\uDFFF]|\uD81A[\uDE39-\uDE3F\uDE5F\uDE6A-\uDECF\uDEEE\uDEEF\uDEF5-\uDEFF\uDF37-\uDF3F\uDF44-\uDF4F\uDF5A-\uDF62\uDF78-\uDF7C\uDF90-\uDFFF]|\uD81B[\uDC00-\uDE3F\uDE80-\uDEFF\uDF4B-\uDF4E\uDF88-\uDF8E\uDFA0-\uDFDF\uDFE2\uDFE5-\uDFEF\uDFF2-\uDFFF]|\uD821[\uDFF8-\uDFFF]|\uD823[\uDCD6-\uDCFF\uDD09-\uDFFF]|\uD82C[\uDD1F-\uDD4F\uDD53-\uDD63\uDD68-\uDD6F\uDEFC-\uDFFF]|\uD82F[\uDC6B-\uDC6F\uDC7D-\uDC7F\uDC89-\uDC8F\uDC9A-\uDC9C\uDC9F-\uDFFF]|\uD834[\uDC00-\uDD64\uDD6A-\uDD6C\uDD73-\uDD7A\uDD83\uDD84\uDD8C-\uDDA9\uDDAE-\uDE41\uDE45-\uDFFF]|\uD835[\uDC55\uDC9D\uDCA0\uDCA1\uDCA3\uDCA4\uDCA7\uDCA8\uDCAD\uDCBA\uDCBC\uDCC4\uDD06\uDD0B\uDD0C\uDD15\uDD1D\uDD3A\uDD3F\uDD45\uDD47-\uDD49\uDD51\uDEA6\uDEA7\uDEC1\uDEDB\uDEFB\uDF15\uDF35\uDF4F\uDF6F\uDF89\uDFA9\uDFC3\uDFCC\uDFCD]|\uD836[\uDC00-\uDDFF\uDE37-\uDE3A\uDE6D-\uDE74\uDE76-\uDE83\uDE85-\uDE9A\uDEA0\uDEB0-\uDFFF]|\uD838[\uDC07\uDC19\uDC1A\uDC22\uDC25\uDC2B-\uDCFF\uDD2D-\uDD2F\uDD3E\uDD3F\uDD4A-\uDD4D\uDD4F-\uDEBF\uDEFA-\uDFFF]|\uD83A[\uDCC5-\uDCCF\uDCD7-\uDCFF\uDD4C-\uDD4F\uDD5A-\uDFFF]|\uD83B[\uDC00-\uDDFF\uDE04\uDE20\uDE23\uDE25\uDE26\uDE28\uDE33\uDE38\uDE3A\uDE3C-\uDE41\uDE43-\uDE46\uDE48\uDE4A\uDE4C\uDE50\uDE53\uDE55\uDE56\uDE58\uDE5A\uDE5C\uDE5E\uDE60\uDE63\uDE65\uDE66\uDE6B\uDE73\uDE78\uDE7D\uDE7F\uDE8A\uDE9C-\uDEA0\uDEA4\uDEAA\uDEBC-\uDFFF]|\uD83C[\uDC00-\uDD2F\uDD4A-\uDD4F\uDD6A-\uDD6F\uDD8A-\uDFFF]|\uD83E[\uDC00-\uDFEF\uDFFA-\uDFFF]|\uD869[\uDEDE-\uDEFF]|\uD86D[\uDF35-\uDF3F]|\uD86E[\uDC1E\uDC1F]|\uD873[\uDEA2-\uDEAF]|\uD87A[\uDFE1-\uDFFF]|\uD87E[\uDE1E-\uDFFF]|\uD884[\uDF4B-\uDFFF]|\uDB40[\uDC00-\uDCFF\uDDF0-\uDFFF]/g, rr = Object.hasOwnProperty;
class Dn {
  /**
   * Create a new slug class.
   */
  constructor() {
    this.occurrences, this.reset();
  }
  /**
   * Generate a unique slug.
  *
  * Tracks previously generated slugs: repeated calls with the same value
  * will result in different slugs.
  * Use the `slug` function to get same slugs.
   *
   * @param  {string} value
   *   String of text to slugify
   * @param  {boolean} [maintainCase=false]
   *   Keep the current case, otherwise make all lowercase
   * @return {string}
   *   A unique slug string
   */
  slug(e, t) {
    const n = this;
    let a = or(e, t === !0);
    const r = a;
    for (; rr.call(n.occurrences, a); )
      n.occurrences[r]++, a = r + "-" + n.occurrences[r];
    return n.occurrences[a] = 0, a;
  }
  /**
   * Reset - Forget all previous slugs
   *
   * @return void
   */
  reset() {
    this.occurrences = /* @__PURE__ */ Object.create(null);
  }
}
function or(i, e) {
  return typeof i != "string" ? "" : (e || (i = i.toLowerCase()), i.replace(lr, "").replace(/ /g, "-"));
}
let ra = new Dn(), oa = [];
function sr({ prefix: i = "", globalSlugs: e = !1 } = {}) {
  return {
    headerIds: !1,
    // prevent deprecation warning; remove this once headerIds option is removed
    hooks: {
      preprocess(t) {
        return e || ur(), t;
      }
    },
    renderer: {
      heading(t, n, a) {
        a = a.toLowerCase().trim().replace(/<[!\/a-z].*?>/gi, "");
        const r = `${i}${ra.slug(a)}`, l = { level: n, text: t, id: r };
        return oa.push(l), `<h${n} id="${r}">${t}</h${n}>
`;
      }
    }
  };
}
function ur() {
  oa = [], ra = new Dn();
}
var Zn = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {};
function By(i) {
  return i && i.__esModule && Object.prototype.hasOwnProperty.call(i, "default") ? i.default : i;
}
var sa = { exports: {} };
(function(i) {
  var e = typeof window < "u" ? window : typeof WorkerGlobalScope < "u" && self instanceof WorkerGlobalScope ? self : {};
  /**
   * Prism: Lightweight, robust, elegant syntax highlighting
   *
   * @license MIT <https://opensource.org/licenses/MIT>
   * @author Lea Verou <https://lea.verou.me>
   * @namespace
   * @public
   */
  var t = function(n) {
    var a = /(?:^|\s)lang(?:uage)?-([\w-]+)(?=\s|$)/i, r = 0, l = {}, o = {
      /**
       * By default, Prism will attempt to highlight all code elements (by calling {@link Prism.highlightAll}) on the
       * current page after the page finished loading. This might be a problem if e.g. you wanted to asynchronously load
       * additional languages or plugins yourself.
       *
       * By setting this value to `true`, Prism will not automatically highlight all code elements on the page.
       *
       * You obviously have to change this value before the automatic highlighting started. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.manual = true;
       * // add a new <script> to load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      manual: n.Prism && n.Prism.manual,
      /**
       * By default, if Prism is in a web worker, it assumes that it is in a worker it created itself, so it uses
       * `addEventListener` to communicate with its parent instance. However, if you're using Prism manually in your
       * own worker, you don't want it to do this.
       *
       * By setting this value to `true`, Prism will not add its own listeners to the worker.
       *
       * You obviously have to change this value before Prism executes. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.disableWorkerMessageHandler = true;
       * // Load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      disableWorkerMessageHandler: n.Prism && n.Prism.disableWorkerMessageHandler,
      /**
       * A namespace for utility methods.
       *
       * All function in this namespace that are not explicitly marked as _public_ are for __internal use only__ and may
       * change or disappear at any time.
       *
       * @namespace
       * @memberof Prism
       */
      util: {
        encode: function p(c) {
          return c instanceof s ? new s(c.type, p(c.content), c.alias) : Array.isArray(c) ? c.map(p) : c.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/\u00a0/g, " ");
        },
        /**
         * Returns the name of the type of the given value.
         *
         * @param {any} o
         * @returns {string}
         * @example
         * type(null)      === 'Null'
         * type(undefined) === 'Undefined'
         * type(123)       === 'Number'
         * type('foo')     === 'String'
         * type(true)      === 'Boolean'
         * type([1, 2])    === 'Array'
         * type({})        === 'Object'
         * type(String)    === 'Function'
         * type(/abc+/)    === 'RegExp'
         */
        type: function(p) {
          return Object.prototype.toString.call(p).slice(8, -1);
        },
        /**
         * Returns a unique number for the given object. Later calls will still return the same number.
         *
         * @param {Object} obj
         * @returns {number}
         */
        objId: function(p) {
          return p.__id || Object.defineProperty(p, "__id", { value: ++r }), p.__id;
        },
        /**
         * Creates a deep clone of the given object.
         *
         * The main intended use of this function is to clone language definitions.
         *
         * @param {T} o
         * @param {Record<number, any>} [visited]
         * @returns {T}
         * @template T
         */
        clone: function p(c, v) {
          v = v || {};
          var F, b;
          switch (o.util.type(c)) {
            case "Object":
              if (b = o.util.objId(c), v[b])
                return v[b];
              F = /** @type {Record<string, any>} */
              {}, v[b] = F;
              for (var g in c)
                c.hasOwnProperty(g) && (F[g] = p(c[g], v));
              return (
                /** @type {any} */
                F
              );
            case "Array":
              return b = o.util.objId(c), v[b] ? v[b] : (F = [], v[b] = F, /** @type {Array} */
              /** @type {any} */
              c.forEach(function(k, D) {
                F[D] = p(k, v);
              }), /** @type {any} */
              F);
            default:
              return c;
          }
        },
        /**
         * Returns the Prism language of the given element set by a `language-xxxx` or `lang-xxxx` class.
         *
         * If no language is set for the element or the element is `null` or `undefined`, `none` will be returned.
         *
         * @param {Element} element
         * @returns {string}
         */
        getLanguage: function(p) {
          for (; p; ) {
            var c = a.exec(p.className);
            if (c)
              return c[1].toLowerCase();
            p = p.parentElement;
          }
          return "none";
        },
        /**
         * Sets the Prism `language-xxxx` class of the given element.
         *
         * @param {Element} element
         * @param {string} language
         * @returns {void}
         */
        setLanguage: function(p, c) {
          p.className = p.className.replace(RegExp(a, "gi"), ""), p.classList.add("language-" + c);
        },
        /**
         * Returns the script element that is currently executing.
         *
         * This does __not__ work for line script element.
         *
         * @returns {HTMLScriptElement | null}
         */
        currentScript: function() {
          if (typeof document > "u")
            return null;
          if ("currentScript" in document)
            return (
              /** @type {any} */
              document.currentScript
            );
          try {
            throw new Error();
          } catch (F) {
            var p = (/at [^(\r\n]*\((.*):[^:]+:[^:]+\)$/i.exec(F.stack) || [])[1];
            if (p) {
              var c = document.getElementsByTagName("script");
              for (var v in c)
                if (c[v].src == p)
                  return c[v];
            }
            return null;
          }
        },
        /**
         * Returns whether a given class is active for `element`.
         *
         * The class can be activated if `element` or one of its ancestors has the given class and it can be deactivated
         * if `element` or one of its ancestors has the negated version of the given class. The _negated version_ of the
         * given class is just the given class with a `no-` prefix.
         *
         * Whether the class is active is determined by the closest ancestor of `element` (where `element` itself is
         * closest ancestor) that has the given class or the negated version of it. If neither `element` nor any of its
         * ancestors have the given class or the negated version of it, then the default activation will be returned.
         *
         * In the paradoxical situation where the closest ancestor contains __both__ the given class and the negated
         * version of it, the class is considered active.
         *
         * @param {Element} element
         * @param {string} className
         * @param {boolean} [defaultActivation=false]
         * @returns {boolean}
         */
        isActive: function(p, c, v) {
          for (var F = "no-" + c; p; ) {
            var b = p.classList;
            if (b.contains(c))
              return !0;
            if (b.contains(F))
              return !1;
            p = p.parentElement;
          }
          return !!v;
        }
      },
      /**
       * This namespace contains all currently loaded languages and the some helper functions to create and modify languages.
       *
       * @namespace
       * @memberof Prism
       * @public
       */
      languages: {
        /**
         * The grammar for plain, unformatted text.
         */
        plain: l,
        plaintext: l,
        text: l,
        txt: l,
        /**
         * Creates a deep copy of the language with the given id and appends the given tokens.
         *
         * If a token in `redef` also appears in the copied language, then the existing token in the copied language
         * will be overwritten at its original position.
         *
         * ## Best practices
         *
         * Since the position of overwriting tokens (token in `redef` that overwrite tokens in the copied language)
         * doesn't matter, they can technically be in any order. However, this can be confusing to others that trying to
         * understand the language definition because, normally, the order of tokens matters in Prism grammars.
         *
         * Therefore, it is encouraged to order overwriting tokens according to the positions of the overwritten tokens.
         * Furthermore, all non-overwriting tokens should be placed after the overwriting ones.
         *
         * @param {string} id The id of the language to extend. This has to be a key in `Prism.languages`.
         * @param {Grammar} redef The new tokens to append.
         * @returns {Grammar} The new language created.
         * @public
         * @example
         * Prism.languages['css-with-colors'] = Prism.languages.extend('css', {
         *     // Prism.languages.css already has a 'comment' token, so this token will overwrite CSS' 'comment' token
         *     // at its original position
         *     'comment': { ... },
         *     // CSS doesn't have a 'color' token, so this token will be appended
         *     'color': /\b(?:red|green|blue)\b/
         * });
         */
        extend: function(p, c) {
          var v = o.util.clone(o.languages[p]);
          for (var F in c)
            v[F] = c[F];
          return v;
        },
        /**
         * Inserts tokens _before_ another token in a language definition or any other grammar.
         *
         * ## Usage
         *
         * This helper method makes it easy to modify existing languages. For example, the CSS language definition
         * not only defines CSS highlighting for CSS documents, but also needs to define highlighting for CSS embedded
         * in HTML through `<style>` elements. To do this, it needs to modify `Prism.languages.markup` and add the
         * appropriate tokens. However, `Prism.languages.markup` is a regular JavaScript object literal, so if you do
         * this:
         *
         * ```js
         * Prism.languages.markup.style = {
         *     // token
         * };
         * ```
         *
         * then the `style` token will be added (and processed) at the end. `insertBefore` allows you to insert tokens
         * before existing tokens. For the CSS example above, you would use it like this:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'cdata', {
         *     'style': {
         *         // token
         *     }
         * });
         * ```
         *
         * ## Special cases
         *
         * If the grammars of `inside` and `insert` have tokens with the same name, the tokens in `inside`'s grammar
         * will be ignored.
         *
         * This behavior can be used to insert tokens after `before`:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'comment', {
         *     'comment': Prism.languages.markup.comment,
         *     // tokens after 'comment'
         * });
         * ```
         *
         * ## Limitations
         *
         * The main problem `insertBefore` has to solve is iteration order. Since ES2015, the iteration order for object
         * properties is guaranteed to be the insertion order (except for integer keys) but some browsers behave
         * differently when keys are deleted and re-inserted. So `insertBefore` can't be implemented by temporarily
         * deleting properties which is necessary to insert at arbitrary positions.
         *
         * To solve this problem, `insertBefore` doesn't actually insert the given tokens into the target object.
         * Instead, it will create a new object and replace all references to the target object with the new one. This
         * can be done without temporarily deleting properties, so the iteration order is well-defined.
         *
         * However, only references that can be reached from `Prism.languages` or `insert` will be replaced. I.e. if
         * you hold the target object in a variable, then the value of the variable will not change.
         *
         * ```js
         * var oldMarkup = Prism.languages.markup;
         * var newMarkup = Prism.languages.insertBefore('markup', 'comment', { ... });
         *
         * assert(oldMarkup !== Prism.languages.markup);
         * assert(newMarkup === Prism.languages.markup);
         * ```
         *
         * @param {string} inside The property of `root` (e.g. a language id in `Prism.languages`) that contains the
         * object to be modified.
         * @param {string} before The key to insert before.
         * @param {Grammar} insert An object containing the key-value pairs to be inserted.
         * @param {Object<string, any>} [root] The object containing `inside`, i.e. the object that contains the
         * object to be modified.
         *
         * Defaults to `Prism.languages`.
         * @returns {Grammar} The new grammar object.
         * @public
         */
        insertBefore: function(p, c, v, F) {
          F = F || /** @type {any} */
          o.languages;
          var b = F[p], g = {};
          for (var k in b)
            if (b.hasOwnProperty(k)) {
              if (k == c)
                for (var D in v)
                  v.hasOwnProperty(D) && (g[D] = v[D]);
              v.hasOwnProperty(k) || (g[k] = b[k]);
            }
          var C = F[p];
          return F[p] = g, o.languages.DFS(o.languages, function(x, T) {
            T === C && x != p && (this[x] = g);
          }), g;
        },
        // Traverse a language definition with Depth First Search
        DFS: function p(c, v, F, b) {
          b = b || {};
          var g = o.util.objId;
          for (var k in c)
            if (c.hasOwnProperty(k)) {
              v.call(c, k, c[k], F || k);
              var D = c[k], C = o.util.type(D);
              C === "Object" && !b[g(D)] ? (b[g(D)] = !0, p(D, v, null, b)) : C === "Array" && !b[g(D)] && (b[g(D)] = !0, p(D, v, k, b));
            }
        }
      },
      plugins: {},
      /**
       * This is the most high-level function in Prism’s API.
       * It fetches all the elements that have a `.language-xxxx` class and then calls {@link Prism.highlightElement} on
       * each one of them.
       *
       * This is equivalent to `Prism.highlightAllUnder(document, async, callback)`.
       *
       * @param {boolean} [async=false] Same as in {@link Prism.highlightAllUnder}.
       * @param {HighlightCallback} [callback] Same as in {@link Prism.highlightAllUnder}.
       * @memberof Prism
       * @public
       */
      highlightAll: function(p, c) {
        o.highlightAllUnder(document, p, c);
      },
      /**
       * Fetches all the descendants of `container` that have a `.language-xxxx` class and then calls
       * {@link Prism.highlightElement} on each one of them.
       *
       * The following hooks will be run:
       * 1. `before-highlightall`
       * 2. `before-all-elements-highlight`
       * 3. All hooks of {@link Prism.highlightElement} for each element.
       *
       * @param {ParentNode} container The root element, whose descendants that have a `.language-xxxx` class will be highlighted.
       * @param {boolean} [async=false] Whether each element is to be highlighted asynchronously using Web Workers.
       * @param {HighlightCallback} [callback] An optional callback to be invoked on each element after its highlighting is done.
       * @memberof Prism
       * @public
       */
      highlightAllUnder: function(p, c, v) {
        var F = {
          callback: v,
          container: p,
          selector: 'code[class*="language-"], [class*="language-"] code, code[class*="lang-"], [class*="lang-"] code'
        };
        o.hooks.run("before-highlightall", F), F.elements = Array.prototype.slice.apply(F.container.querySelectorAll(F.selector)), o.hooks.run("before-all-elements-highlight", F);
        for (var b = 0, g; g = F.elements[b++]; )
          o.highlightElement(g, c === !0, F.callback);
      },
      /**
       * Highlights the code inside a single element.
       *
       * The following hooks will be run:
       * 1. `before-sanity-check`
       * 2. `before-highlight`
       * 3. All hooks of {@link Prism.highlight}. These hooks will be run by an asynchronous worker if `async` is `true`.
       * 4. `before-insert`
       * 5. `after-highlight`
       * 6. `complete`
       *
       * Some the above hooks will be skipped if the element doesn't contain any text or there is no grammar loaded for
       * the element's language.
       *
       * @param {Element} element The element containing the code.
       * It must have a class of `language-xxxx` to be processed, where `xxxx` is a valid language identifier.
       * @param {boolean} [async=false] Whether the element is to be highlighted asynchronously using Web Workers
       * to improve performance and avoid blocking the UI when highlighting very large chunks of code. This option is
       * [disabled by default](https://prismjs.com/faq.html#why-is-asynchronous-highlighting-disabled-by-default).
       *
       * Note: All language definitions required to highlight the code must be included in the main `prism.js` file for
       * asynchronous highlighting to work. You can build your own bundle on the
       * [Download page](https://prismjs.com/download.html).
       * @param {HighlightCallback} [callback] An optional callback to be invoked after the highlighting is done.
       * Mostly useful when `async` is `true`, since in that case, the highlighting is done asynchronously.
       * @memberof Prism
       * @public
       */
      highlightElement: function(p, c, v) {
        var F = o.util.getLanguage(p), b = o.languages[F];
        o.util.setLanguage(p, F);
        var g = p.parentElement;
        g && g.nodeName.toLowerCase() === "pre" && o.util.setLanguage(g, F);
        var k = p.textContent, D = {
          element: p,
          language: F,
          grammar: b,
          code: k
        };
        function C(T) {
          D.highlightedCode = T, o.hooks.run("before-insert", D), D.element.innerHTML = D.highlightedCode, o.hooks.run("after-highlight", D), o.hooks.run("complete", D), v && v.call(D.element);
        }
        if (o.hooks.run("before-sanity-check", D), g = D.element.parentElement, g && g.nodeName.toLowerCase() === "pre" && !g.hasAttribute("tabindex") && g.setAttribute("tabindex", "0"), !D.code) {
          o.hooks.run("complete", D), v && v.call(D.element);
          return;
        }
        if (o.hooks.run("before-highlight", D), !D.grammar) {
          C(o.util.encode(D.code));
          return;
        }
        if (c && n.Worker) {
          var x = new Worker(o.filename);
          x.onmessage = function(T) {
            C(T.data);
          }, x.postMessage(JSON.stringify({
            language: D.language,
            code: D.code,
            immediateClose: !0
          }));
        } else
          C(o.highlight(D.code, D.grammar, D.language));
      },
      /**
       * Low-level function, only use if you know what you’re doing. It accepts a string of text as input
       * and the language definitions to use, and returns a string with the HTML produced.
       *
       * The following hooks will be run:
       * 1. `before-tokenize`
       * 2. `after-tokenize`
       * 3. `wrap`: On each {@link Token}.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @param {string} language The name of the language definition passed to `grammar`.
       * @returns {string} The highlighted HTML.
       * @memberof Prism
       * @public
       * @example
       * Prism.highlight('var foo = true;', Prism.languages.javascript, 'javascript');
       */
      highlight: function(p, c, v) {
        var F = {
          code: p,
          grammar: c,
          language: v
        };
        if (o.hooks.run("before-tokenize", F), !F.grammar)
          throw new Error('The language "' + F.language + '" has no grammar.');
        return F.tokens = o.tokenize(F.code, F.grammar), o.hooks.run("after-tokenize", F), s.stringify(o.util.encode(F.tokens), F.language);
      },
      /**
       * This is the heart of Prism, and the most low-level function you can use. It accepts a string of text as input
       * and the language definitions to use, and returns an array with the tokenized code.
       *
       * When the language definition includes nested tokens, the function is called recursively on each of these tokens.
       *
       * This method could be useful in other contexts as well, as a very crude parser.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @returns {TokenStream} An array of strings and tokens, a token stream.
       * @memberof Prism
       * @public
       * @example
       * let code = `var foo = 0;`;
       * let tokens = Prism.tokenize(code, Prism.languages.javascript);
       * tokens.forEach(token => {
       *     if (token instanceof Prism.Token && token.type === 'number') {
       *         console.log(`Found numeric literal: ${token.content}`);
       *     }
       * });
       */
      tokenize: function(p, c) {
        var v = c.rest;
        if (v) {
          for (var F in v)
            c[F] = v[F];
          delete c.rest;
        }
        var b = new f();
        return d(b, b.head, p), _(p, b, c, b.head, 0), m(b);
      },
      /**
       * @namespace
       * @memberof Prism
       * @public
       */
      hooks: {
        all: {},
        /**
         * Adds the given callback to the list of callbacks for the given hook.
         *
         * The callback will be invoked when the hook it is registered for is run.
         * Hooks are usually directly run by a highlight function but you can also run hooks yourself.
         *
         * One callback function can be registered to multiple hooks and the same hook multiple times.
         *
         * @param {string} name The name of the hook.
         * @param {HookCallback} callback The callback function which is given environment variables.
         * @public
         */
        add: function(p, c) {
          var v = o.hooks.all;
          v[p] = v[p] || [], v[p].push(c);
        },
        /**
         * Runs a hook invoking all registered callbacks with the given environment variables.
         *
         * Callbacks will be invoked synchronously and in the order in which they were registered.
         *
         * @param {string} name The name of the hook.
         * @param {Object<string, any>} env The environment variables of the hook passed to all callbacks registered.
         * @public
         */
        run: function(p, c) {
          var v = o.hooks.all[p];
          if (!(!v || !v.length))
            for (var F = 0, b; b = v[F++]; )
              b(c);
        }
      },
      Token: s
    };
    n.Prism = o;
    function s(p, c, v, F) {
      this.type = p, this.content = c, this.alias = v, this.length = (F || "").length | 0;
    }
    s.stringify = function p(c, v) {
      if (typeof c == "string")
        return c;
      if (Array.isArray(c)) {
        var F = "";
        return c.forEach(function(C) {
          F += p(C, v);
        }), F;
      }
      var b = {
        type: c.type,
        content: p(c.content, v),
        tag: "span",
        classes: ["token", c.type],
        attributes: {},
        language: v
      }, g = c.alias;
      g && (Array.isArray(g) ? Array.prototype.push.apply(b.classes, g) : b.classes.push(g)), o.hooks.run("wrap", b);
      var k = "";
      for (var D in b.attributes)
        k += " " + D + '="' + (b.attributes[D] || "").replace(/"/g, "&quot;") + '"';
      return "<" + b.tag + ' class="' + b.classes.join(" ") + '"' + k + ">" + b.content + "</" + b.tag + ">";
    };
    function u(p, c, v, F) {
      p.lastIndex = c;
      var b = p.exec(v);
      if (b && F && b[1]) {
        var g = b[1].length;
        b.index += g, b[0] = b[0].slice(g);
      }
      return b;
    }
    function _(p, c, v, F, b, g) {
      for (var k in v)
        if (!(!v.hasOwnProperty(k) || !v[k])) {
          var D = v[k];
          D = Array.isArray(D) ? D : [D];
          for (var C = 0; C < D.length; ++C) {
            if (g && g.cause == k + "," + C)
              return;
            var x = D[C], T = x.inside, V = !!x.lookbehind, j = !!x.greedy, U = x.alias;
            if (j && !x.pattern.global) {
              var R = x.pattern.toString().match(/[imsuy]*$/)[0];
              x.pattern = RegExp(x.pattern.source, R + "g");
            }
            for (var H = x.pattern || x, O = F.next, Y = b; O !== c.tail && !(g && Y >= g.reach); Y += O.value.length, O = O.next) {
              var oe = O.value;
              if (c.length > p.length)
                return;
              if (!(oe instanceof s)) {
                var $ = 1, Z;
                if (j) {
                  if (Z = u(H, Y, p, V), !Z || Z.index >= p.length)
                    break;
                  var ze = Z.index, Le = Z.index + Z[0].length, K = Y;
                  for (K += O.value.length; ze >= K; )
                    O = O.next, K += O.value.length;
                  if (K -= O.value.length, Y = K, O.value instanceof s)
                    continue;
                  for (var A = O; A !== c.tail && (K < Le || typeof A.value == "string"); A = A.next)
                    $++, K += A.value.length;
                  $--, oe = p.slice(Y, K), Z.index -= Y;
                } else if (Z = u(H, 0, oe, V), !Z)
                  continue;
                var ze = Z.index, et = Z[0], Ct = oe.slice(0, ze), kn = oe.slice(ze + et.length), Et = Y + oe.length;
                g && Et > g.reach && (g.reach = Et);
                var tt = O.prev;
                Ct && (tt = d(c, tt, Ct), Y += Ct.length), h(c, tt, $);
                var za = new s(k, T ? o.tokenize(et, T) : et, U, et);
                if (O = d(c, tt, za), kn && d(c, O, kn), $ > 1) {
                  var At = {
                    cause: k + "," + C,
                    reach: Et
                  };
                  _(p, c, v, O.prev, Y, At), g && At.reach > g.reach && (g.reach = At.reach);
                }
              }
            }
          }
        }
    }
    function f() {
      var p = { value: null, prev: null, next: null }, c = { value: null, prev: p, next: null };
      p.next = c, this.head = p, this.tail = c, this.length = 0;
    }
    function d(p, c, v) {
      var F = c.next, b = { value: v, prev: c, next: F };
      return c.next = b, F.prev = b, p.length++, b;
    }
    function h(p, c, v) {
      for (var F = c.next, b = 0; b < v && F !== p.tail; b++)
        F = F.next;
      c.next = F, F.prev = c, p.length -= b;
    }
    function m(p) {
      for (var c = [], v = p.head.next; v !== p.tail; )
        c.push(v.value), v = v.next;
      return c;
    }
    if (!n.document)
      return n.addEventListener && (o.disableWorkerMessageHandler || n.addEventListener("message", function(p) {
        var c = JSON.parse(p.data), v = c.language, F = c.code, b = c.immediateClose;
        n.postMessage(o.highlight(F, o.languages[v], v)), b && n.close();
      }, !1)), o;
    var w = o.util.currentScript();
    w && (o.filename = w.src, w.hasAttribute("data-manual") && (o.manual = !0));
    function y() {
      o.manual || o.highlightAll();
    }
    if (!o.manual) {
      var E = document.readyState;
      E === "loading" || E === "interactive" && w && w.defer ? document.addEventListener("DOMContentLoaded", y) : window.requestAnimationFrame ? window.requestAnimationFrame(y) : window.setTimeout(y, 16);
    }
    return o;
  }(e);
  i.exports && (i.exports = t), typeof Zn < "u" && (Zn.Prism = t), t.languages.markup = {
    comment: {
      pattern: /<!--(?:(?!<!--)[\s\S])*?-->/,
      greedy: !0
    },
    prolog: {
      pattern: /<\?[\s\S]+?\?>/,
      greedy: !0
    },
    doctype: {
      // https://www.w3.org/TR/xml/#NT-doctypedecl
      pattern: /<!DOCTYPE(?:[^>"'[\]]|"[^"]*"|'[^']*')+(?:\[(?:[^<"'\]]|"[^"]*"|'[^']*'|<(?!!--)|<!--(?:[^-]|-(?!->))*-->)*\]\s*)?>/i,
      greedy: !0,
      inside: {
        "internal-subset": {
          pattern: /(^[^\[]*\[)[\s\S]+(?=\]>$)/,
          lookbehind: !0,
          greedy: !0,
          inside: null
          // see below
        },
        string: {
          pattern: /"[^"]*"|'[^']*'/,
          greedy: !0
        },
        punctuation: /^<!|>$|[[\]]/,
        "doctype-tag": /^DOCTYPE/i,
        name: /[^\s<>'"]+/
      }
    },
    cdata: {
      pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
      greedy: !0
    },
    tag: {
      pattern: /<\/?(?!\d)[^\s>\/=$<%]+(?:\s(?:\s*[^\s>\/=]+(?:\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))|(?=[\s/>])))+)?\s*\/?>/,
      greedy: !0,
      inside: {
        tag: {
          pattern: /^<\/?[^\s>\/]+/,
          inside: {
            punctuation: /^<\/?/,
            namespace: /^[^\s>\/:]+:/
          }
        },
        "special-attr": [],
        "attr-value": {
          pattern: /=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+)/,
          inside: {
            punctuation: [
              {
                pattern: /^=/,
                alias: "attr-equals"
              },
              {
                pattern: /^(\s*)["']|["']$/,
                lookbehind: !0
              }
            ]
          }
        },
        punctuation: /\/?>/,
        "attr-name": {
          pattern: /[^\s>\/]+/,
          inside: {
            namespace: /^[^\s>\/:]+:/
          }
        }
      }
    },
    entity: [
      {
        pattern: /&[\da-z]{1,8};/i,
        alias: "named-entity"
      },
      /&#x?[\da-f]{1,8};/i
    ]
  }, t.languages.markup.tag.inside["attr-value"].inside.entity = t.languages.markup.entity, t.languages.markup.doctype.inside["internal-subset"].inside = t.languages.markup, t.hooks.add("wrap", function(n) {
    n.type === "entity" && (n.attributes.title = n.content.replace(/&amp;/, "&"));
  }), Object.defineProperty(t.languages.markup.tag, "addInlined", {
    /**
     * Adds an inlined language to markup.
     *
     * An example of an inlined language is CSS with `<style>` tags.
     *
     * @param {string} tagName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addInlined('style', 'css');
     */
    value: function(a, r) {
      var l = {};
      l["language-" + r] = {
        pattern: /(^<!\[CDATA\[)[\s\S]+?(?=\]\]>$)/i,
        lookbehind: !0,
        inside: t.languages[r]
      }, l.cdata = /^<!\[CDATA\[|\]\]>$/i;
      var o = {
        "included-cdata": {
          pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
          inside: l
        }
      };
      o["language-" + r] = {
        pattern: /[\s\S]+/,
        inside: t.languages[r]
      };
      var s = {};
      s[a] = {
        pattern: RegExp(/(<__[^>]*>)(?:<!\[CDATA\[(?:[^\]]|\](?!\]>))*\]\]>|(?!<!\[CDATA\[)[\s\S])*?(?=<\/__>)/.source.replace(/__/g, function() {
          return a;
        }), "i"),
        lookbehind: !0,
        greedy: !0,
        inside: o
      }, t.languages.insertBefore("markup", "cdata", s);
    }
  }), Object.defineProperty(t.languages.markup.tag, "addAttribute", {
    /**
     * Adds an pattern to highlight languages embedded in HTML attributes.
     *
     * An example of an inlined language is CSS with `style` attributes.
     *
     * @param {string} attrName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addAttribute('style', 'css');
     */
    value: function(n, a) {
      t.languages.markup.tag.inside["special-attr"].push({
        pattern: RegExp(
          /(^|["'\s])/.source + "(?:" + n + ")" + /\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))/.source,
          "i"
        ),
        lookbehind: !0,
        inside: {
          "attr-name": /^[^\s=]+/,
          "attr-value": {
            pattern: /=[\s\S]+/,
            inside: {
              value: {
                pattern: /(^=\s*(["']|(?!["'])))\S[\s\S]*(?=\2$)/,
                lookbehind: !0,
                alias: [a, "language-" + a],
                inside: t.languages[a]
              },
              punctuation: [
                {
                  pattern: /^=/,
                  alias: "attr-equals"
                },
                /"|'/
              ]
            }
          }
        }
      });
    }
  }), t.languages.html = t.languages.markup, t.languages.mathml = t.languages.markup, t.languages.svg = t.languages.markup, t.languages.xml = t.languages.extend("markup", {}), t.languages.ssml = t.languages.xml, t.languages.atom = t.languages.xml, t.languages.rss = t.languages.xml, function(n) {
    var a = /(?:"(?:\\(?:\r\n|[\s\S])|[^"\\\r\n])*"|'(?:\\(?:\r\n|[\s\S])|[^'\\\r\n])*')/;
    n.languages.css = {
      comment: /\/\*[\s\S]*?\*\//,
      atrule: {
        pattern: RegExp("@[\\w-](?:" + /[^;{\s"']|\s+(?!\s)/.source + "|" + a.source + ")*?" + /(?:;|(?=\s*\{))/.source),
        inside: {
          rule: /^@[\w-]+/,
          "selector-function-argument": {
            pattern: /(\bselector\s*\(\s*(?![\s)]))(?:[^()\s]|\s+(?![\s)])|\((?:[^()]|\([^()]*\))*\))+(?=\s*\))/,
            lookbehind: !0,
            alias: "selector"
          },
          keyword: {
            pattern: /(^|[^\w-])(?:and|not|only|or)(?![\w-])/,
            lookbehind: !0
          }
          // See rest below
        }
      },
      url: {
        // https://drafts.csswg.org/css-values-3/#urls
        pattern: RegExp("\\burl\\((?:" + a.source + "|" + /(?:[^\\\r\n()"']|\\[\s\S])*/.source + ")\\)", "i"),
        greedy: !0,
        inside: {
          function: /^url/i,
          punctuation: /^\(|\)$/,
          string: {
            pattern: RegExp("^" + a.source + "$"),
            alias: "url"
          }
        }
      },
      selector: {
        pattern: RegExp(`(^|[{}\\s])[^{}\\s](?:[^{};"'\\s]|\\s+(?![\\s{])|` + a.source + ")*(?=\\s*\\{)"),
        lookbehind: !0
      },
      string: {
        pattern: a,
        greedy: !0
      },
      property: {
        pattern: /(^|[^-\w\xA0-\uFFFF])(?!\s)[-_a-z\xA0-\uFFFF](?:(?!\s)[-\w\xA0-\uFFFF])*(?=\s*:)/i,
        lookbehind: !0
      },
      important: /!important\b/i,
      function: {
        pattern: /(^|[^-a-z0-9])[-a-z0-9]+(?=\()/i,
        lookbehind: !0
      },
      punctuation: /[(){};:,]/
    }, n.languages.css.atrule.inside.rest = n.languages.css;
    var r = n.languages.markup;
    r && (r.tag.addInlined("style", "css"), r.tag.addAttribute("style", "css"));
  }(t), t.languages.clike = {
    comment: [
      {
        pattern: /(^|[^\\])\/\*[\s\S]*?(?:\*\/|$)/,
        lookbehind: !0,
        greedy: !0
      },
      {
        pattern: /(^|[^\\:])\/\/.*/,
        lookbehind: !0,
        greedy: !0
      }
    ],
    string: {
      pattern: /(["'])(?:\\(?:\r\n|[\s\S])|(?!\1)[^\\\r\n])*\1/,
      greedy: !0
    },
    "class-name": {
      pattern: /(\b(?:class|extends|implements|instanceof|interface|new|trait)\s+|\bcatch\s+\()[\w.\\]+/i,
      lookbehind: !0,
      inside: {
        punctuation: /[.\\]/
      }
    },
    keyword: /\b(?:break|catch|continue|do|else|finally|for|function|if|in|instanceof|new|null|return|throw|try|while)\b/,
    boolean: /\b(?:false|true)\b/,
    function: /\b\w+(?=\()/,
    number: /\b0x[\da-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:e[+-]?\d+)?/i,
    operator: /[<>]=?|[!=]=?=?|--?|\+\+?|&&?|\|\|?|[?*/~^%]/,
    punctuation: /[{}[\];(),.:]/
  }, t.languages.javascript = t.languages.extend("clike", {
    "class-name": [
      t.languages.clike["class-name"],
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$A-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\.(?:constructor|prototype))/,
        lookbehind: !0
      }
    ],
    keyword: [
      {
        pattern: /((?:^|\})\s*)catch\b/,
        lookbehind: !0
      },
      {
        pattern: /(^|[^.]|\.\.\.\s*)\b(?:as|assert(?=\s*\{)|async(?=\s*(?:function\b|\(|[$\w\xA0-\uFFFF]|$))|await|break|case|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally(?=\s*(?:\{|$))|for|from(?=\s*(?:['"]|$))|function|(?:get|set)(?=\s*(?:[#\[$\w\xA0-\uFFFF]|$))|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)\b/,
        lookbehind: !0
      }
    ],
    // Allow for all non-ASCII characters (See http://stackoverflow.com/a/2008444)
    function: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*(?:\.\s*(?:apply|bind|call)\s*)?\()/,
    number: {
      pattern: RegExp(
        /(^|[^\w$])/.source + "(?:" + // constant
        (/NaN|Infinity/.source + "|" + // binary integer
        /0[bB][01]+(?:_[01]+)*n?/.source + "|" + // octal integer
        /0[oO][0-7]+(?:_[0-7]+)*n?/.source + "|" + // hexadecimal integer
        /0[xX][\dA-Fa-f]+(?:_[\dA-Fa-f]+)*n?/.source + "|" + // decimal bigint
        /\d+(?:_\d+)*n/.source + "|" + // decimal number (integer or float) but no bigint
        /(?:\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\.\d+(?:_\d+)*)(?:[Ee][+-]?\d+(?:_\d+)*)?/.source) + ")" + /(?![\w$])/.source
      ),
      lookbehind: !0
    },
    operator: /--|\+\+|\*\*=?|=>|&&=?|\|\|=?|[!=]==|<<=?|>>>?=?|[-+*/%&|^!=<>]=?|\.{3}|\?\?=?|\?\.?|[~:]/
  }), t.languages.javascript["class-name"][0].pattern = /(\b(?:class|extends|implements|instanceof|interface|new)\s+)[\w.\\]+/, t.languages.insertBefore("javascript", "keyword", {
    regex: {
      pattern: RegExp(
        // lookbehind
        // eslint-disable-next-line regexp/no-dupe-characters-character-class
        /((?:^|[^$\w\xA0-\uFFFF."'\])\s]|\b(?:return|yield))\s*)/.source + // Regex pattern:
        // There are 2 regex patterns here. The RegExp set notation proposal added support for nested character
        // classes if the `v` flag is present. Unfortunately, nested CCs are both context-free and incompatible
        // with the only syntax, so we have to define 2 different regex patterns.
        /\//.source + "(?:" + /(?:\[(?:[^\]\\\r\n]|\\.)*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}/.source + "|" + // `v` flag syntax. This supports 3 levels of nested character classes.
        /(?:\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.)*\])*\])*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}v[dgimyus]{0,7}/.source + ")" + // lookahead
        /(?=(?:\s|\/\*(?:[^*]|\*(?!\/))*\*\/)*(?:$|[\r\n,.;:})\]]|\/\/))/.source
      ),
      lookbehind: !0,
      greedy: !0,
      inside: {
        "regex-source": {
          pattern: /^(\/)[\s\S]+(?=\/[a-z]*$)/,
          lookbehind: !0,
          alias: "language-regex",
          inside: t.languages.regex
        },
        "regex-delimiter": /^\/|\/$/,
        "regex-flags": /^[a-z]+$/
      }
    },
    // This must be declared before keyword because we use "function" inside the look-forward
    "function-variable": {
      pattern: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*[=:]\s*(?:async\s*)?(?:\bfunction\b|(?:\((?:[^()]|\([^()]*\))*\)|(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)\s*=>))/,
      alias: "function"
    },
    parameter: [
      {
        pattern: /(function(?:\s+(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)?\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\))/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$a-z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*=>)/i,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*=>)/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /((?:\b|\s|^)(?!(?:as|async|await|break|case|catch|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally|for|from|function|get|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|set|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)(?![$\w\xA0-\uFFFF]))(?:(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*\s*)\(\s*|\]\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*\{)/,
        lookbehind: !0,
        inside: t.languages.javascript
      }
    ],
    constant: /\b[A-Z](?:[A-Z_]|\dx?)*\b/
  }), t.languages.insertBefore("javascript", "string", {
    hashbang: {
      pattern: /^#!.*/,
      greedy: !0,
      alias: "comment"
    },
    "template-string": {
      pattern: /`(?:\\[\s\S]|\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}|(?!\$\{)[^\\`])*`/,
      greedy: !0,
      inside: {
        "template-punctuation": {
          pattern: /^`|`$/,
          alias: "string"
        },
        interpolation: {
          pattern: /((?:^|[^\\])(?:\\{2})*)\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}/,
          lookbehind: !0,
          inside: {
            "interpolation-punctuation": {
              pattern: /^\$\{|\}$/,
              alias: "punctuation"
            },
            rest: t.languages.javascript
          }
        },
        string: /[\s\S]+/
      }
    },
    "string-property": {
      pattern: /((?:^|[,{])[ \t]*)(["'])(?:\\(?:\r\n|[\s\S])|(?!\2)[^\\\r\n])*\2(?=\s*:)/m,
      lookbehind: !0,
      greedy: !0,
      alias: "property"
    }
  }), t.languages.insertBefore("javascript", "operator", {
    "literal-property": {
      pattern: /((?:^|[,{])[ \t]*)(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*:)/m,
      lookbehind: !0,
      alias: "property"
    }
  }), t.languages.markup && (t.languages.markup.tag.addInlined("script", "javascript"), t.languages.markup.tag.addAttribute(
    /on(?:abort|blur|change|click|composition(?:end|start|update)|dblclick|error|focus(?:in|out)?|key(?:down|up)|load|mouse(?:down|enter|leave|move|out|over|up)|reset|resize|scroll|select|slotchange|submit|unload|wheel)/.source,
    "javascript"
  )), t.languages.js = t.languages.javascript, function() {
    if (typeof t > "u" || typeof document > "u")
      return;
    Element.prototype.matches || (Element.prototype.matches = Element.prototype.msMatchesSelector || Element.prototype.webkitMatchesSelector);
    var n = "Loading…", a = function(w, y) {
      return "✖ Error " + w + " while fetching file: " + y;
    }, r = "✖ Error: File does not exist or is empty", l = {
      js: "javascript",
      py: "python",
      rb: "ruby",
      ps1: "powershell",
      psm1: "powershell",
      sh: "bash",
      bat: "batch",
      h: "c",
      tex: "latex"
    }, o = "data-src-status", s = "loading", u = "loaded", _ = "failed", f = "pre[data-src]:not([" + o + '="' + u + '"]):not([' + o + '="' + s + '"])';
    function d(w, y, E) {
      var p = new XMLHttpRequest();
      p.open("GET", w, !0), p.onreadystatechange = function() {
        p.readyState == 4 && (p.status < 400 && p.responseText ? y(p.responseText) : p.status >= 400 ? E(a(p.status, p.statusText)) : E(r));
      }, p.send(null);
    }
    function h(w) {
      var y = /^\s*(\d+)\s*(?:(,)\s*(?:(\d+)\s*)?)?$/.exec(w || "");
      if (y) {
        var E = Number(y[1]), p = y[2], c = y[3];
        return p ? c ? [E, Number(c)] : [E, void 0] : [E, E];
      }
    }
    t.hooks.add("before-highlightall", function(w) {
      w.selector += ", " + f;
    }), t.hooks.add("before-sanity-check", function(w) {
      var y = (
        /** @type {HTMLPreElement} */
        w.element
      );
      if (y.matches(f)) {
        w.code = "", y.setAttribute(o, s);
        var E = y.appendChild(document.createElement("CODE"));
        E.textContent = n;
        var p = y.getAttribute("data-src"), c = w.language;
        if (c === "none") {
          var v = (/\.(\w+)$/.exec(p) || [, "none"])[1];
          c = l[v] || v;
        }
        t.util.setLanguage(E, c), t.util.setLanguage(y, c);
        var F = t.plugins.autoloader;
        F && F.loadLanguages(c), d(
          p,
          function(b) {
            y.setAttribute(o, u);
            var g = h(y.getAttribute("data-range"));
            if (g) {
              var k = b.split(/\r\n?|\n/g), D = g[0], C = g[1] == null ? k.length : g[1];
              D < 0 && (D += k.length), D = Math.max(0, Math.min(D - 1, k.length)), C < 0 && (C += k.length), C = Math.max(0, Math.min(C, k.length)), b = k.slice(D, C).join(`
`), y.hasAttribute("data-start") || y.setAttribute("data-start", String(D + 1));
            }
            E.textContent = b, t.highlightElement(E);
          },
          function(b) {
            y.setAttribute(o, _), E.textContent = b;
          }
        );
      }
    }), t.plugins.fileHighlight = {
      /**
       * Executes the File Highlight plugin for all matching `pre` elements under the given container.
       *
       * Note: Elements which are already loaded or currently loading will not be touched by this method.
       *
       * @param {ParentNode} [container=document]
       */
      highlight: function(y) {
        for (var E = (y || document).querySelectorAll(f), p = 0, c; c = E[p++]; )
          t.highlightElement(c);
      }
    };
    var m = !1;
    t.fileHighlight = function() {
      m || (console.warn("Prism.fileHighlight is deprecated. Use `Prism.plugins.fileHighlight.highlight` instead."), m = !0), t.plugins.fileHighlight.highlight.apply(this, arguments);
    };
  }();
})(sa);
var Ot = sa.exports;
Prism.languages.python = {
  comment: {
    pattern: /(^|[^\\])#.*/,
    lookbehind: !0,
    greedy: !0
  },
  "string-interpolation": {
    pattern: /(?:f|fr|rf)(?:("""|''')[\s\S]*?\1|("|')(?:\\.|(?!\2)[^\\\r\n])*\2)/i,
    greedy: !0,
    inside: {
      interpolation: {
        // "{" <expression> <optional "!s", "!r", or "!a"> <optional ":" format specifier> "}"
        pattern: /((?:^|[^{])(?:\{\{)*)\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}])+\})+\})+\}/,
        lookbehind: !0,
        inside: {
          "format-spec": {
            pattern: /(:)[^:(){}]+(?=\}$)/,
            lookbehind: !0
          },
          "conversion-option": {
            pattern: /![sra](?=[:}]$)/,
            alias: "punctuation"
          },
          rest: null
        }
      },
      string: /[\s\S]+/
    }
  },
  "triple-quoted-string": {
    pattern: /(?:[rub]|br|rb)?("""|''')[\s\S]*?\1/i,
    greedy: !0,
    alias: "string"
  },
  string: {
    pattern: /(?:[rub]|br|rb)?("|')(?:\\.|(?!\1)[^\\\r\n])*\1/i,
    greedy: !0
  },
  function: {
    pattern: /((?:^|\s)def[ \t]+)[a-zA-Z_]\w*(?=\s*\()/g,
    lookbehind: !0
  },
  "class-name": {
    pattern: /(\bclass\s+)\w+/i,
    lookbehind: !0
  },
  decorator: {
    pattern: /(^[\t ]*)@\w+(?:\.\w+)*/m,
    lookbehind: !0,
    alias: ["annotation", "punctuation"],
    inside: {
      punctuation: /\./
    }
  },
  keyword: /\b(?:_(?=\s*:)|and|as|assert|async|await|break|case|class|continue|def|del|elif|else|except|exec|finally|for|from|global|if|import|in|is|lambda|match|nonlocal|not|or|pass|print|raise|return|try|while|with|yield)\b/,
  builtin: /\b(?:__import__|abs|all|any|apply|ascii|basestring|bin|bool|buffer|bytearray|bytes|callable|chr|classmethod|cmp|coerce|compile|complex|delattr|dict|dir|divmod|enumerate|eval|execfile|file|filter|float|format|frozenset|getattr|globals|hasattr|hash|help|hex|id|input|int|intern|isinstance|issubclass|iter|len|list|locals|long|map|max|memoryview|min|next|object|oct|open|ord|pow|property|range|raw_input|reduce|reload|repr|reversed|round|set|setattr|slice|sorted|staticmethod|str|sum|super|tuple|type|unichr|unicode|vars|xrange|zip)\b/,
  boolean: /\b(?:False|None|True)\b/,
  number: /\b0(?:b(?:_?[01])+|o(?:_?[0-7])+|x(?:_?[a-f0-9])+)\b|(?:\b\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\B\.\d+(?:_\d+)*)(?:e[+-]?\d+(?:_\d+)*)?j?(?!\w)/i,
  operator: /[-+%=]=?|!=|:=|\*\*?=?|\/\/?=?|<[<=>]?|>[=>]?|[&|^~]/,
  punctuation: /[{}[\];(),.:]/
};
Prism.languages.python["string-interpolation"].inside.interpolation.inside.rest = Prism.languages.python;
Prism.languages.py = Prism.languages.python;
(function(i) {
  var e = /\\(?:[^a-z()[\]]|[a-z*]+)/i, t = {
    "equation-command": {
      pattern: e,
      alias: "regex"
    }
  };
  i.languages.latex = {
    comment: /%.*/,
    // the verbatim environment prints whitespace to the document
    cdata: {
      pattern: /(\\begin\{((?:lstlisting|verbatim)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
      lookbehind: !0
    },
    /*
     * equations can be between $$ $$ or $ $ or \( \) or \[ \]
     * (all are multiline)
     */
    equation: [
      {
        pattern: /\$\$(?:\\[\s\S]|[^\\$])+\$\$|\$(?:\\[\s\S]|[^\\$])+\$|\\\([\s\S]*?\\\)|\\\[[\s\S]*?\\\]/,
        inside: t,
        alias: "string"
      },
      {
        pattern: /(\\begin\{((?:align|eqnarray|equation|gather|math|multline)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
        lookbehind: !0,
        inside: t,
        alias: "string"
      }
    ],
    /*
     * arguments which are keywords or references are highlighted
     * as keywords
     */
    keyword: {
      pattern: /(\\(?:begin|cite|documentclass|end|label|ref|usepackage)(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    url: {
      pattern: /(\\url\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    /*
     * section or chapter headlines are highlighted as bold so that
     * they stand out more
     */
    headline: {
      pattern: /(\\(?:chapter|frametitle|paragraph|part|section|subparagraph|subsection|subsubparagraph|subsubsection|subsubsubparagraph)\*?(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0,
      alias: "class-name"
    },
    function: {
      pattern: e,
      alias: "selector"
    },
    punctuation: /[[\]{}&]/
  }, i.languages.tex = i.languages.latex, i.languages.context = i.languages.latex;
})(Prism);
(function(i) {
  var e = "\\b(?:BASH|BASHOPTS|BASH_ALIASES|BASH_ARGC|BASH_ARGV|BASH_CMDS|BASH_COMPLETION_COMPAT_DIR|BASH_LINENO|BASH_REMATCH|BASH_SOURCE|BASH_VERSINFO|BASH_VERSION|COLORTERM|COLUMNS|COMP_WORDBREAKS|DBUS_SESSION_BUS_ADDRESS|DEFAULTS_PATH|DESKTOP_SESSION|DIRSTACK|DISPLAY|EUID|GDMSESSION|GDM_LANG|GNOME_KEYRING_CONTROL|GNOME_KEYRING_PID|GPG_AGENT_INFO|GROUPS|HISTCONTROL|HISTFILE|HISTFILESIZE|HISTSIZE|HOME|HOSTNAME|HOSTTYPE|IFS|INSTANCE|JOB|LANG|LANGUAGE|LC_ADDRESS|LC_ALL|LC_IDENTIFICATION|LC_MEASUREMENT|LC_MONETARY|LC_NAME|LC_NUMERIC|LC_PAPER|LC_TELEPHONE|LC_TIME|LESSCLOSE|LESSOPEN|LINES|LOGNAME|LS_COLORS|MACHTYPE|MAILCHECK|MANDATORY_PATH|NO_AT_BRIDGE|OLDPWD|OPTERR|OPTIND|ORBIT_SOCKETDIR|OSTYPE|PAPERSIZE|PATH|PIPESTATUS|PPID|PS1|PS2|PS3|PS4|PWD|RANDOM|REPLY|SECONDS|SELINUX_INIT|SESSION|SESSIONTYPE|SESSION_MANAGER|SHELL|SHELLOPTS|SHLVL|SSH_AUTH_SOCK|TERM|UID|UPSTART_EVENTS|UPSTART_INSTANCE|UPSTART_JOB|UPSTART_SESSION|USER|WINDOWID|XAUTHORITY|XDG_CONFIG_DIRS|XDG_CURRENT_DESKTOP|XDG_DATA_DIRS|XDG_GREETER_DATA_DIR|XDG_MENU_PREFIX|XDG_RUNTIME_DIR|XDG_SEAT|XDG_SEAT_PATH|XDG_SESSION_DESKTOP|XDG_SESSION_ID|XDG_SESSION_PATH|XDG_SESSION_TYPE|XDG_VTNR|XMODIFIERS)\\b", t = {
    pattern: /(^(["']?)\w+\2)[ \t]+\S.*/,
    lookbehind: !0,
    alias: "punctuation",
    // this looks reasonably well in all themes
    inside: null
    // see below
  }, n = {
    bash: t,
    environment: {
      pattern: RegExp("\\$" + e),
      alias: "constant"
    },
    variable: [
      // [0]: Arithmetic Environment
      {
        pattern: /\$?\(\([\s\S]+?\)\)/,
        greedy: !0,
        inside: {
          // If there is a $ sign at the beginning highlight $(( and )) as variable
          variable: [
            {
              pattern: /(^\$\(\([\s\S]+)\)\)/,
              lookbehind: !0
            },
            /^\$\(\(/
          ],
          number: /\b0x[\dA-Fa-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:[Ee]-?\d+)?/,
          // Operators according to https://www.gnu.org/software/bash/manual/bashref.html#Shell-Arithmetic
          operator: /--|\+\+|\*\*=?|<<=?|>>=?|&&|\|\||[=!+\-*/%<>^&|]=?|[?~:]/,
          // If there is no $ sign at the beginning highlight (( and )) as punctuation
          punctuation: /\(\(?|\)\)?|,|;/
        }
      },
      // [1]: Command Substitution
      {
        pattern: /\$\((?:\([^)]+\)|[^()])+\)|`[^`]+`/,
        greedy: !0,
        inside: {
          variable: /^\$\(|^`|\)$|`$/
        }
      },
      // [2]: Brace expansion
      {
        pattern: /\$\{[^}]+\}/,
        greedy: !0,
        inside: {
          operator: /:[-=?+]?|[!\/]|##?|%%?|\^\^?|,,?/,
          punctuation: /[\[\]]/,
          environment: {
            pattern: RegExp("(\\{)" + e),
            lookbehind: !0,
            alias: "constant"
          }
        }
      },
      /\$(?:\w+|[#?*!@$])/
    ],
    // Escape sequences from echo and printf's manuals, and escaped quotes.
    entity: /\\(?:[abceEfnrtv\\"]|O?[0-7]{1,3}|U[0-9a-fA-F]{8}|u[0-9a-fA-F]{4}|x[0-9a-fA-F]{1,2})/
  };
  i.languages.bash = {
    shebang: {
      pattern: /^#!\s*\/.*/,
      alias: "important"
    },
    comment: {
      pattern: /(^|[^"{\\$])#.*/,
      lookbehind: !0
    },
    "function-name": [
      // a) function foo {
      // b) foo() {
      // c) function foo() {
      // but not “foo {”
      {
        // a) and c)
        pattern: /(\bfunction\s+)[\w-]+(?=(?:\s*\(?:\s*\))?\s*\{)/,
        lookbehind: !0,
        alias: "function"
      },
      {
        // b)
        pattern: /\b[\w-]+(?=\s*\(\s*\)\s*\{)/,
        alias: "function"
      }
    ],
    // Highlight variable names as variables in for and select beginnings.
    "for-or-select": {
      pattern: /(\b(?:for|select)\s+)\w+(?=\s+in\s)/,
      alias: "variable",
      lookbehind: !0
    },
    // Highlight variable names as variables in the left-hand part
    // of assignments (“=” and “+=”).
    "assign-left": {
      pattern: /(^|[\s;|&]|[<>]\()\w+(?:\.\w+)*(?=\+?=)/,
      inside: {
        environment: {
          pattern: RegExp("(^|[\\s;|&]|[<>]\\()" + e),
          lookbehind: !0,
          alias: "constant"
        }
      },
      alias: "variable",
      lookbehind: !0
    },
    // Highlight parameter names as variables
    parameter: {
      pattern: /(^|\s)-{1,2}(?:\w+:[+-]?)?\w+(?:\.\w+)*(?=[=\s]|$)/,
      alias: "variable",
      lookbehind: !0
    },
    string: [
      // Support for Here-documents https://en.wikipedia.org/wiki/Here_document
      {
        pattern: /((?:^|[^<])<<-?\s*)(\w+)\s[\s\S]*?(?:\r?\n|\r)\2/,
        lookbehind: !0,
        greedy: !0,
        inside: n
      },
      // Here-document with quotes around the tag
      // → No expansion (so no “inside”).
      {
        pattern: /((?:^|[^<])<<-?\s*)(["'])(\w+)\2\s[\s\S]*?(?:\r?\n|\r)\3/,
        lookbehind: !0,
        greedy: !0,
        inside: {
          bash: t
        }
      },
      // “Normal” string
      {
        // https://www.gnu.org/software/bash/manual/html_node/Double-Quotes.html
        pattern: /(^|[^\\](?:\\\\)*)"(?:\\[\s\S]|\$\([^)]+\)|\$(?!\()|`[^`]+`|[^"\\`$])*"/,
        lookbehind: !0,
        greedy: !0,
        inside: n
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/Single-Quotes.html
        pattern: /(^|[^$\\])'[^']*'/,
        lookbehind: !0,
        greedy: !0
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/ANSI_002dC-Quoting.html
        pattern: /\$'(?:[^'\\]|\\[\s\S])*'/,
        greedy: !0,
        inside: {
          entity: n.entity
        }
      }
    ],
    environment: {
      pattern: RegExp("\\$?" + e),
      alias: "constant"
    },
    variable: n.variable,
    function: {
      pattern: /(^|[\s;|&]|[<>]\()(?:add|apropos|apt|apt-cache|apt-get|aptitude|aspell|automysqlbackup|awk|basename|bash|bc|bconsole|bg|bzip2|cal|cargo|cat|cfdisk|chgrp|chkconfig|chmod|chown|chroot|cksum|clear|cmp|column|comm|composer|cp|cron|crontab|csplit|curl|cut|date|dc|dd|ddrescue|debootstrap|df|diff|diff3|dig|dir|dircolors|dirname|dirs|dmesg|docker|docker-compose|du|egrep|eject|env|ethtool|expand|expect|expr|fdformat|fdisk|fg|fgrep|file|find|fmt|fold|format|free|fsck|ftp|fuser|gawk|git|gparted|grep|groupadd|groupdel|groupmod|groups|grub-mkconfig|gzip|halt|head|hg|history|host|hostname|htop|iconv|id|ifconfig|ifdown|ifup|import|install|ip|java|jobs|join|kill|killall|less|link|ln|locate|logname|logrotate|look|lpc|lpr|lprint|lprintd|lprintq|lprm|ls|lsof|lynx|make|man|mc|mdadm|mkconfig|mkdir|mke2fs|mkfifo|mkfs|mkisofs|mknod|mkswap|mmv|more|most|mount|mtools|mtr|mutt|mv|nano|nc|netstat|nice|nl|node|nohup|notify-send|npm|nslookup|op|open|parted|passwd|paste|pathchk|ping|pkill|pnpm|podman|podman-compose|popd|pr|printcap|printenv|ps|pushd|pv|quota|quotacheck|quotactl|ram|rar|rcp|reboot|remsync|rename|renice|rev|rm|rmdir|rpm|rsync|scp|screen|sdiff|sed|sendmail|seq|service|sftp|sh|shellcheck|shuf|shutdown|sleep|slocate|sort|split|ssh|stat|strace|su|sudo|sum|suspend|swapon|sync|sysctl|tac|tail|tar|tee|time|timeout|top|touch|tr|traceroute|tsort|tty|umount|uname|unexpand|uniq|units|unrar|unshar|unzip|update-grub|uptime|useradd|userdel|usermod|users|uudecode|uuencode|v|vcpkg|vdir|vi|vim|virsh|vmstat|wait|watch|wc|wget|whereis|which|who|whoami|write|xargs|xdg-open|yarn|yes|zenity|zip|zsh|zypper)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    keyword: {
      pattern: /(^|[\s;|&]|[<>]\()(?:case|do|done|elif|else|esac|fi|for|function|if|in|select|then|until|while)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    // https://www.gnu.org/software/bash/manual/html_node/Shell-Builtin-Commands.html
    builtin: {
      pattern: /(^|[\s;|&]|[<>]\()(?:\.|:|alias|bind|break|builtin|caller|cd|command|continue|declare|echo|enable|eval|exec|exit|export|getopts|hash|help|let|local|logout|mapfile|printf|pwd|read|readarray|readonly|return|set|shift|shopt|source|test|times|trap|type|typeset|ulimit|umask|unalias|unset)(?=$|[)\s;|&])/,
      lookbehind: !0,
      // Alias added to make those easier to distinguish from strings.
      alias: "class-name"
    },
    boolean: {
      pattern: /(^|[\s;|&]|[<>]\()(?:false|true)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    "file-descriptor": {
      pattern: /\B&\d\b/,
      alias: "important"
    },
    operator: {
      // Lots of redirections here, but not just that.
      pattern: /\d?<>|>\||\+=|=[=~]?|!=?|<<[<-]?|[&\d]?>>|\d[<>]&?|[<>][&=]?|&[>&]?|\|[&|]?/,
      inside: {
        "file-descriptor": {
          pattern: /^\d/,
          alias: "important"
        }
      }
    },
    punctuation: /\$?\(\(?|\)\)?|\.\.|[{}[\];\\]/,
    number: {
      pattern: /(^|\s)(?:[1-9]\d*|0)(?:[.,]\d+)?\b/,
      lookbehind: !0
    }
  }, t.inside = i.languages.bash;
  for (var a = [
    "comment",
    "function-name",
    "for-or-select",
    "assign-left",
    "parameter",
    "string",
    "environment",
    "function",
    "keyword",
    "builtin",
    "boolean",
    "file-descriptor",
    "operator",
    "punctuation",
    "number"
  ], r = n.variable[1].inside, l = 0; l < a.length; l++)
    r[a[l]] = i.languages.bash[a[l]];
  i.languages.sh = i.languages.bash, i.languages.shell = i.languages.bash;
})(Prism);
const cr = '<svg class="md-link-icon" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true" fill="currentColor"><path d="m7.775 3.275 1.25-1.25a3.5 3.5 0 1 1 4.95 4.95l-2.5 2.5a3.5 3.5 0 0 1-4.95 0 .751.751 0 0 1 .018-1.042.751.751 0 0 1 1.042-.018 1.998 1.998 0 0 0 2.83 0l2.5-2.5a2.002 2.002 0 0 0-2.83-2.83l-1.25 1.25a.751.751 0 0 1-1.042-.018.751.751 0 0 1-.018-1.042Zm-4.69 9.64a1.998 1.998 0 0 0 2.83 0l1.25-1.25a.751.751 0 0 1 1.042.018.751.751 0 0 1 .018 1.042l-1.25 1.25a3.5 3.5 0 1 1-4.95-4.95l2.5-2.5a3.5 3.5 0 0 1 4.95 0 .751.751 0 0 1-.018 1.042.751.751 0 0 1-1.042.018 1.998 1.998 0 0 0-2.83 0l-2.5 2.5a1.998 1.998 0 0 0 0 2.83Z"></path></svg>', _r = `
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 15 15" color="currentColor" aria-hidden="true" aria-label="Copy" stroke-width="1.3" width="15" height="15">
  <path fill="currentColor" d="M12.728 4.545v8.182H4.545V4.545zm0 -0.909H4.545a0.909 0.909 0 0 0 -0.909 0.909v8.182a0.909 0.909 0 0 0 0.909 0.909h8.182a0.909 0.909 0 0 0 0.909 -0.909V4.545a0.909 0.909 0 0 0 -0.909 -0.909"/>
  <path fill="currentColor" d="M1.818 8.182H0.909V1.818a0.909 0.909 0 0 1 0.909 -0.909h6.364v0.909H1.818Z"/>
</svg>

`, dr = `<svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 17 17" aria-hidden="true" aria-label="Copied" fill="none" stroke="currentColor" stroke-width="1.3">
  <path d="m13.813 4.781 -7.438 7.438 -3.188 -3.188"/>
</svg>
`, Xn = `<button title="copy" class="copy_code_button">
  <span class="copy-text">${_r}</span>
  <span class="check">${dr}</span>
</button>`, ua = /[&<>"']/, hr = new RegExp(ua.source, "g"), ca = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, fr = new RegExp(ca.source, "g"), pr = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, Wn = (i) => pr[i] || "";
function Pt(i, e) {
  if (e) {
    if (ua.test(i))
      return i.replace(hr, Wn);
  } else if (ca.test(i))
    return i.replace(fr, Wn);
  return i;
}
function mr(i) {
  const e = i.map((t) => ({
    start: new RegExp(t.left.replace(/[-\/\\^$*+?.()|[\]{}]/g, "\\$&")),
    end: new RegExp(t.right.replace(/[-\/\\^$*+?.()|[\]{}]/g, "\\$&"))
  }));
  return {
    name: "latex",
    level: "block",
    start(t) {
      for (const n of e) {
        const a = t.match(n.start);
        if (a)
          return a.index;
      }
      return -1;
    },
    tokenizer(t, n) {
      for (const a of e) {
        const r = new RegExp(
          `${a.start.source}([\\s\\S]+?)${a.end.source}`
        ).exec(t);
        if (r)
          return {
            type: "latex",
            raw: r[0],
            text: r[1].trim()
          };
      }
    },
    renderer(t) {
      return `<div class="latex-block">${t.text}</div>`;
    }
  };
}
function gr() {
  return {
    name: "mermaid",
    level: "block",
    start(i) {
      var e;
      return (e = i.match(/^```mermaid\s*\n/)) == null ? void 0 : e.index;
    },
    tokenizer(i) {
      const e = /^```mermaid\s*\n([\s\S]*?)```\s*(?:\n|$)/.exec(i);
      if (e)
        return {
          type: "mermaid",
          raw: e[0],
          text: e[1].trim()
        };
    },
    renderer(i) {
      return `<div class="mermaid">${i.text}</div>
`;
    }
  };
}
const vr = {
  code(i, e, t) {
    var a;
    const n = ((a = (e ?? "").match(/\S*/)) == null ? void 0 : a[0]) ?? "";
    return i = i.replace(/\n$/, "") + `
`, !n || n === "mermaid" ? '<div class="code_wrap">' + Xn + "<pre><code>" + (t ? i : Pt(i, !0)) + `</code></pre></div>
` : '<div class="code_wrap">' + Xn + '<pre><code class="language-' + Pt(n) + '">' + (t ? i : Pt(i, !0)) + `</code></pre></div>
`;
  }
}, Dr = new Dn();
function br({
  header_links: i,
  line_breaks: e,
  latex_delimiters: t
}) {
  const n = new na();
  n.use(
    {
      gfm: !0,
      pedantic: !1,
      breaks: e
    },
    tr({
      highlight: (l, o) => {
        var s;
        return (s = Ot.languages) != null && s[o] ? Ot.highlight(l, Ot.languages[o], o) : l;
      }
    }),
    { renderer: vr }
  ), i && (n.use(sr()), n.use({
    extensions: [
      {
        name: "heading",
        level: "block",
        renderer(l) {
          const o = l.raw.toLowerCase().trim().replace(/<[!\/a-z].*?>/gi, ""), s = "h" + Dr.slug(o), u = l.depth, _ = this.parser.parseInline(l.tokens);
          return `<h${u} id="${s}"><a class="md-header-anchor" href="#${s}">${cr}</a>${_}</h${u}>
`;
        }
      }
    ]
  }));
  const a = gr(), r = mr(t);
  return n.use({
    extensions: [a, r]
  }), n;
}
const Wt = (i) => JSON.parse(JSON.stringify(i)), wr = (i) => i.nodeType === 1, yr = (i) => jr.has(i.tagName), Fr = (i) => "action" in i, kr = (i) => i.tagName === "IFRAME", $r = (i) => "formAction" in i, Cr = (i) => "protocol" in i, ct = /* @__PURE__ */ (() => {
  const i = /^(?:\w+script|data):/i;
  return (e) => i.test(e);
})(), Er = /* @__PURE__ */ (() => {
  const i = /(?:script|data):/i;
  return (e) => i.test(e);
})(), Ar = (i) => {
  const e = {};
  for (let t = 0, n = i.length; t < n; t++) {
    const a = i[t];
    for (const r in a)
      e[r] ? e[r] = e[r].concat(a[r]) : e[r] = a[r];
  }
  return e;
}, _a = (i, e) => {
  let t = i.firstChild;
  for (; t; ) {
    const n = t.nextSibling;
    wr(t) && (e(t, i), t.parentNode && _a(t, e)), t = n;
  }
}, Sr = (i, e) => {
  const t = document.createNodeIterator(i, NodeFilter.SHOW_ELEMENT);
  let n;
  for (; n = t.nextNode(); ) {
    const a = n.parentNode;
    a && e(n, a);
  }
}, xr = (i, e) => !!globalThis.document && !!globalThis.document.createNodeIterator ? Sr(i, e) : _a(i, e), da = [
  "a",
  "abbr",
  "acronym",
  "address",
  "area",
  "article",
  "aside",
  "audio",
  "b",
  "bdi",
  "bdo",
  "bgsound",
  "big",
  "blockquote",
  "body",
  "br",
  "button",
  "canvas",
  "caption",
  "center",
  "cite",
  "code",
  "col",
  "colgroup",
  "datalist",
  "dd",
  "del",
  "details",
  "dfn",
  "dialog",
  "dir",
  "div",
  "dl",
  "dt",
  "em",
  "fieldset",
  "figcaption",
  "figure",
  "font",
  "footer",
  "form",
  "h1",
  "h2",
  "h3",
  "h4",
  "h5",
  "h6",
  "head",
  "header",
  "hgroup",
  "hr",
  "html",
  "i",
  "img",
  "input",
  "ins",
  "kbd",
  "keygen",
  "label",
  "layer",
  "legend",
  "li",
  "link",
  "listing",
  "main",
  "map",
  "mark",
  "marquee",
  "menu",
  "meta",
  "meter",
  "nav",
  "nobr",
  "ol",
  "optgroup",
  "option",
  "output",
  "p",
  "picture",
  "popup",
  "pre",
  "progress",
  "q",
  "rb",
  "rp",
  "rt",
  "rtc",
  "ruby",
  "s",
  "samp",
  "section",
  "select",
  "selectmenu",
  "small",
  "source",
  "span",
  "strike",
  "strong",
  "style",
  "sub",
  "summary",
  "sup",
  "table",
  "tbody",
  "td",
  "tfoot",
  "th",
  "thead",
  "time",
  "tr",
  "track",
  "tt",
  "u",
  "ul",
  "var",
  "video",
  "wbr"
], Br = [
  "basefont",
  "command",
  "data",
  "iframe",
  "image",
  "plaintext",
  "portal",
  "slot",
  // 'template', //TODO: Not exactly correct to never allow this, too strict
  "textarea",
  "title",
  "xmp"
], Tr = /* @__PURE__ */ new Set([
  ...da,
  ...Br
]), ha = [
  "svg",
  "a",
  "altglyph",
  "altglyphdef",
  "altglyphitem",
  "animatecolor",
  "animatemotion",
  "animatetransform",
  "circle",
  "clippath",
  "defs",
  "desc",
  "ellipse",
  "filter",
  "font",
  "g",
  "glyph",
  "glyphref",
  "hkern",
  "image",
  "line",
  "lineargradient",
  "marker",
  "mask",
  "metadata",
  "mpath",
  "path",
  "pattern",
  "polygon",
  "polyline",
  "radialgradient",
  "rect",
  "stop",
  "style",
  "switch",
  "symbol",
  "text",
  "textpath",
  "title",
  "tref",
  "tspan",
  "view",
  "vkern",
  /* FILTERS */
  "feBlend",
  "feColorMatrix",
  "feComponentTransfer",
  "feComposite",
  "feConvolveMatrix",
  "feDiffuseLighting",
  "feDisplacementMap",
  "feDistantLight",
  "feFlood",
  "feFuncA",
  "feFuncB",
  "feFuncG",
  "feFuncR",
  "feGaussianBlur",
  "feImage",
  "feMerge",
  "feMergeNode",
  "feMorphology",
  "feOffset",
  "fePointLight",
  "feSpecularLighting",
  "feSpotLight",
  "feTile",
  "feTurbulence"
], qr = [
  "animate",
  "color-profile",
  "cursor",
  "discard",
  "fedropshadow",
  "font-face",
  "font-face-format",
  "font-face-name",
  "font-face-src",
  "font-face-uri",
  "foreignobject",
  "hatch",
  "hatchpath",
  "mesh",
  "meshgradient",
  "meshpatch",
  "meshrow",
  "missing-glyph",
  "script",
  "set",
  "solidcolor",
  "unknown",
  "use"
], Lr = /* @__PURE__ */ new Set([
  ...ha,
  ...qr
]), fa = [
  "math",
  "menclose",
  "merror",
  "mfenced",
  "mfrac",
  "mglyph",
  "mi",
  "mlabeledtr",
  "mmultiscripts",
  "mn",
  "mo",
  "mover",
  "mpadded",
  "mphantom",
  "mroot",
  "mrow",
  "ms",
  "mspace",
  "msqrt",
  "mstyle",
  "msub",
  "msup",
  "msubsup",
  "mtable",
  "mtd",
  "mtext",
  "mtr",
  "munder",
  "munderover"
], zr = [
  "maction",
  "maligngroup",
  "malignmark",
  "mlongdiv",
  "mscarries",
  "mscarry",
  "msgroup",
  "mstack",
  "msline",
  "msrow",
  "semantics",
  "annotation",
  "annotation-xml",
  "mprescripts",
  "none"
], Ir = /* @__PURE__ */ new Set([
  ...fa,
  ...zr
]), Rr = [
  "abbr",
  "accept",
  "accept-charset",
  "accesskey",
  "action",
  "align",
  "alink",
  "allow",
  "allowfullscreen",
  "alt",
  "anchor",
  "archive",
  "as",
  "async",
  "autocapitalize",
  "autocomplete",
  "autocorrect",
  "autofocus",
  "autopictureinpicture",
  "autoplay",
  "axis",
  "background",
  "behavior",
  "bgcolor",
  "border",
  "bordercolor",
  "capture",
  "cellpadding",
  "cellspacing",
  "challenge",
  "char",
  "charoff",
  "charset",
  "checked",
  "cite",
  "class",
  "classid",
  "clear",
  "code",
  "codebase",
  "codetype",
  "color",
  "cols",
  "colspan",
  "compact",
  "content",
  "contenteditable",
  "controls",
  "controlslist",
  "conversiondestination",
  "coords",
  "crossorigin",
  "csp",
  "data",
  "datetime",
  "declare",
  "decoding",
  "default",
  "defer",
  "dir",
  "direction",
  "dirname",
  "disabled",
  "disablepictureinpicture",
  "disableremoteplayback",
  "disallowdocumentaccess",
  "download",
  "draggable",
  "elementtiming",
  "enctype",
  "end",
  "enterkeyhint",
  "event",
  "exportparts",
  "face",
  "for",
  "form",
  "formaction",
  "formenctype",
  "formmethod",
  "formnovalidate",
  "formtarget",
  "frame",
  "frameborder",
  "headers",
  "height",
  "hidden",
  "high",
  "href",
  "hreflang",
  "hreftranslate",
  "hspace",
  "http-equiv",
  "id",
  "imagesizes",
  "imagesrcset",
  "importance",
  "impressiondata",
  "impressionexpiry",
  "incremental",
  "inert",
  "inputmode",
  "integrity",
  "invisible",
  "ismap",
  "keytype",
  "kind",
  "label",
  "lang",
  "language",
  "latencyhint",
  "leftmargin",
  "link",
  "list",
  "loading",
  "longdesc",
  "loop",
  "low",
  "lowsrc",
  "manifest",
  "marginheight",
  "marginwidth",
  "max",
  "maxlength",
  "mayscript",
  "media",
  "method",
  "min",
  "minlength",
  "multiple",
  "muted",
  "name",
  "nohref",
  "nomodule",
  "nonce",
  "noresize",
  "noshade",
  "novalidate",
  "nowrap",
  "object",
  "open",
  "optimum",
  "part",
  "pattern",
  "ping",
  "placeholder",
  "playsinline",
  "policy",
  "poster",
  "preload",
  "pseudo",
  "readonly",
  "referrerpolicy",
  "rel",
  "reportingorigin",
  "required",
  "resources",
  "rev",
  "reversed",
  "role",
  "rows",
  "rowspan",
  "rules",
  "sandbox",
  "scheme",
  "scope",
  "scopes",
  "scrollamount",
  "scrolldelay",
  "scrolling",
  "select",
  "selected",
  "shadowroot",
  "shadowrootdelegatesfocus",
  "shape",
  "size",
  "sizes",
  "slot",
  "span",
  "spellcheck",
  "src",
  "srclang",
  "srcset",
  "standby",
  "start",
  "step",
  "style",
  "summary",
  "tabindex",
  "target",
  "text",
  "title",
  "topmargin",
  "translate",
  "truespeed",
  "trusttoken",
  "type",
  "usemap",
  "valign",
  "value",
  "valuetype",
  "version",
  "virtualkeyboardpolicy",
  "vlink",
  "vspace",
  "webkitdirectory",
  "width",
  "wrap"
], Mr = [
  "accent-height",
  "accumulate",
  "additive",
  "alignment-baseline",
  "ascent",
  "attributename",
  "attributetype",
  "azimuth",
  "basefrequency",
  "baseline-shift",
  "begin",
  "bias",
  "by",
  "class",
  "clip",
  "clippathunits",
  "clip-path",
  "clip-rule",
  "color",
  "color-interpolation",
  "color-interpolation-filters",
  "color-profile",
  "color-rendering",
  "cx",
  "cy",
  "d",
  "dx",
  "dy",
  "diffuseconstant",
  "direction",
  "display",
  "divisor",
  "dominant-baseline",
  "dur",
  "edgemode",
  "elevation",
  "end",
  "fill",
  "fill-opacity",
  "fill-rule",
  "filter",
  "filterunits",
  "flood-color",
  "flood-opacity",
  "font-family",
  "font-size",
  "font-size-adjust",
  "font-stretch",
  "font-style",
  "font-variant",
  "font-weight",
  "fx",
  "fy",
  "g1",
  "g2",
  "glyph-name",
  "glyphref",
  "gradientunits",
  "gradienttransform",
  "height",
  "href",
  "id",
  "image-rendering",
  "in",
  "in2",
  "k",
  "k1",
  "k2",
  "k3",
  "k4",
  "kerning",
  "keypoints",
  "keysplines",
  "keytimes",
  "lang",
  "lengthadjust",
  "letter-spacing",
  "kernelmatrix",
  "kernelunitlength",
  "lighting-color",
  "local",
  "marker-end",
  "marker-mid",
  "marker-start",
  "markerheight",
  "markerunits",
  "markerwidth",
  "maskcontentunits",
  "maskunits",
  "max",
  "mask",
  "media",
  "method",
  "mode",
  "min",
  "name",
  "numoctaves",
  "offset",
  "operator",
  "opacity",
  "order",
  "orient",
  "orientation",
  "origin",
  "overflow",
  "paint-order",
  "path",
  "pathlength",
  "patterncontentunits",
  "patterntransform",
  "patternunits",
  "points",
  "preservealpha",
  "preserveaspectratio",
  "primitiveunits",
  "r",
  "rx",
  "ry",
  "radius",
  "refx",
  "refy",
  "repeatcount",
  "repeatdur",
  "restart",
  "result",
  "rotate",
  "scale",
  "seed",
  "shape-rendering",
  "specularconstant",
  "specularexponent",
  "spreadmethod",
  "startoffset",
  "stddeviation",
  "stitchtiles",
  "stop-color",
  "stop-opacity",
  "stroke-dasharray",
  "stroke-dashoffset",
  "stroke-linecap",
  "stroke-linejoin",
  "stroke-miterlimit",
  "stroke-opacity",
  "stroke",
  "stroke-width",
  "style",
  "surfacescale",
  "systemlanguage",
  "tabindex",
  "targetx",
  "targety",
  "transform",
  "transform-origin",
  "text-anchor",
  "text-decoration",
  "text-rendering",
  "textlength",
  "type",
  "u1",
  "u2",
  "unicode",
  "values",
  "viewbox",
  "visibility",
  "version",
  "vert-adv-y",
  "vert-origin-x",
  "vert-origin-y",
  "width",
  "word-spacing",
  "wrap",
  "writing-mode",
  "xchannelselector",
  "ychannelselector",
  "x",
  "x1",
  "x2",
  "xmlns",
  "y",
  "y1",
  "y2",
  "z",
  "zoomandpan"
], Or = [
  "accent",
  "accentunder",
  "align",
  "bevelled",
  "close",
  "columnsalign",
  "columnlines",
  "columnspan",
  "denomalign",
  "depth",
  "dir",
  "display",
  "displaystyle",
  "encoding",
  "fence",
  "frame",
  "height",
  "href",
  "id",
  "largeop",
  "length",
  "linethickness",
  "lspace",
  "lquote",
  "mathbackground",
  "mathcolor",
  "mathsize",
  "mathvariant",
  "maxsize",
  "minsize",
  "movablelimits",
  "notation",
  "numalign",
  "open",
  "rowalign",
  "rowlines",
  "rowspacing",
  "rowspan",
  "rspace",
  "rquote",
  "scriptlevel",
  "scriptminsize",
  "scriptsizemultiplier",
  "selection",
  "separator",
  "separators",
  "stretchy",
  "subscriptshift",
  "supscriptshift",
  "symmetric",
  "voffset",
  "width",
  "xmlns"
], pe = {
  HTML: "http://www.w3.org/1999/xhtml",
  SVG: "http://www.w3.org/2000/svg",
  MATH: "http://www.w3.org/1998/Math/MathML"
}, Pr = {
  [pe.HTML]: Tr,
  [pe.SVG]: Lr,
  [pe.MATH]: Ir
}, Nr = {
  [pe.HTML]: "html",
  [pe.SVG]: "svg",
  [pe.MATH]: "math"
}, Hr = {
  [pe.HTML]: "",
  [pe.SVG]: "svg:",
  [pe.MATH]: "math:"
}, jr = /* @__PURE__ */ new Set([
  "A",
  "AREA",
  "BUTTON",
  "FORM",
  "IFRAME",
  "INPUT"
]), pa = {
  allowComments: !0,
  allowCustomElements: !1,
  allowUnknownMarkup: !1,
  allowElements: [
    ...da,
    ...ha.map((i) => `svg:${i}`),
    ...fa.map((i) => `math:${i}`)
  ],
  allowAttributes: Ar([
    Object.fromEntries(Rr.map((i) => [i, ["*"]])),
    Object.fromEntries(Mr.map((i) => [i, ["svg:*"]])),
    Object.fromEntries(Or.map((i) => [i, ["math:*"]]))
  ])
};
var Nt = function(i, e, t, n, a) {
  if (n === "m") throw new TypeError("Private method is not writable");
  if (n === "a" && !a) throw new TypeError("Private accessor was defined without a setter");
  if (typeof e == "function" ? i !== e || !a : !e.has(i)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? a.call(i, t) : a ? a.value = t : e.set(i, t), t;
}, Ae = function(i, e, t, n) {
  if (t === "a" && !n) throw new TypeError("Private accessor was defined without a getter");
  if (typeof e == "function" ? i !== e || !n : !e.has(i)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return t === "m" ? n : t === "a" ? n.call(i) : n ? n.value : e.get(i);
}, Ce, mt, gt;
class ma {
  /* CONSTRUCTOR */
  constructor(e = {}) {
    Ce.set(this, void 0), mt.set(this, void 0), gt.set(this, void 0), this.getConfiguration = () => Wt(Ae(this, Ce, "f")), this.sanitize = (_) => {
      const f = Ae(this, mt, "f"), d = Ae(this, gt, "f");
      return xr(_, (h, m) => {
        const w = h.namespaceURI || pe.HTML, y = m.namespaceURI || pe.HTML, E = Pr[w], p = Nr[w], c = Hr[w], v = h.tagName.toLowerCase(), F = `${c}${v}`, g = `${c}*`;
        if (!E.has(v) || !f.has(F) || w !== y && v !== p)
          m.removeChild(h);
        else {
          const k = h.getAttributeNames(), D = k.length;
          if (D) {
            for (let C = 0; C < D; C++) {
              const x = k[C], T = d[x];
              (!T || !T.has(g) && !T.has(F)) && h.removeAttribute(x);
            }
            if (yr(h))
              if (Cr(h)) {
                const C = h.getAttribute("href");
                C && Er(C) && ct(h.protocol) && h.removeAttribute("href");
              } else Fr(h) ? ct(h.action) && h.removeAttribute("action") : $r(h) ? ct(h.formAction) && h.removeAttribute("formaction") : kr(h) && (ct(h.src) && h.removeAttribute("formaction"), h.setAttribute("sandbox", "allow-scripts"));
          }
        }
      }), _;
    }, this.sanitizeFor = (_, f) => {
      throw new Error('"sanitizeFor" is not implemented yet');
    };
    const { allowComments: t, allowCustomElements: n, allowUnknownMarkup: a, blockElements: r, dropElements: l, dropAttributes: o } = e;
    if (t === !1)
      throw new Error('A false "allowComments" is not supported yet');
    if (n)
      throw new Error('A true "allowCustomElements" is not supported yet');
    if (a)
      throw new Error('A true "allowUnknownMarkup" is not supported yet');
    if (r)
      throw new Error('"blockElements" is not supported yet, use "allowElements" instead');
    if (l)
      throw new Error('"dropElements" is not supported yet, use "allowElements" instead');
    if (o)
      throw new Error('"dropAttributes" is not supported yet, use "allowAttributes" instead');
    Nt(this, Ce, Wt(pa), "f");
    const { allowElements: s, allowAttributes: u } = e;
    s && (Ae(this, Ce, "f").allowElements = e.allowElements), u && (Ae(this, Ce, "f").allowAttributes = e.allowAttributes), Nt(this, mt, new Set(Ae(this, Ce, "f").allowElements), "f"), Nt(this, gt, Object.fromEntries(Object.entries(Ae(this, Ce, "f").allowAttributes || {}).map(([_, f]) => [_, new Set(f)])), "f");
  }
}
Ce = /* @__PURE__ */ new WeakMap(), mt = /* @__PURE__ */ new WeakMap(), gt = /* @__PURE__ */ new WeakMap();
ma.getDefaultConfiguration = () => Wt(pa);
const Gr = (i, e = location.href) => {
  try {
    return !!i && new URL(i).origin !== new URL(e).origin;
  } catch {
    return !1;
  }
};
function Yn(i) {
  const e = new ma(), t = new DOMParser().parseFromString(i, "text/html");
  return ga(t.body, "A", (n) => {
    n instanceof HTMLElement && "target" in n && Gr(n.getAttribute("href"), location.href) && (n.setAttribute("target", "_blank"), n.setAttribute("rel", "noopener noreferrer"));
  }), e.sanitize(t).body.innerHTML;
}
function ga(i, e, t) {
  i && (i.nodeName === e || typeof e == "function") && t(i);
  const n = (i == null ? void 0 : i.childNodes) || [];
  for (let a = 0; a < n.length; a++)
    ga(n[a], e, t);
}
const Kn = [
  "!--",
  "!doctype",
  "a",
  "abbr",
  "acronym",
  "address",
  "applet",
  "area",
  "article",
  "aside",
  "audio",
  "b",
  "base",
  "basefont",
  "bdi",
  "bdo",
  "big",
  "blockquote",
  "body",
  "br",
  "button",
  "canvas",
  "caption",
  "center",
  "cite",
  "code",
  "col",
  "colgroup",
  "data",
  "datalist",
  "dd",
  "del",
  "details",
  "dfn",
  "dialog",
  "dir",
  "div",
  "dl",
  "dt",
  "em",
  "embed",
  "fieldset",
  "figcaption",
  "figure",
  "font",
  "footer",
  "form",
  "frame",
  "frameset",
  "h1",
  "h2",
  "h3",
  "h4",
  "h5",
  "h6",
  "head",
  "header",
  "hgroup",
  "hr",
  "html",
  "i",
  "iframe",
  "img",
  "input",
  "ins",
  "kbd",
  "label",
  "legend",
  "li",
  "link",
  "main",
  "map",
  "mark",
  "menu",
  "meta",
  "meter",
  "nav",
  "noframes",
  "noscript",
  "object",
  "ol",
  "optgroup",
  "option",
  "output",
  "p",
  "param",
  "picture",
  "pre",
  "progress",
  "q",
  "rp",
  "rt",
  "ruby",
  "s",
  "samp",
  "script",
  "search",
  "section",
  "select",
  "small",
  "source",
  "span",
  "strike",
  "strong",
  "style",
  "sub",
  "summary",
  "sup",
  "svg",
  "table",
  "tbody",
  "td",
  "template",
  "textarea",
  "tfoot",
  "th",
  "thead",
  "time",
  "title",
  "tr",
  "track",
  "tt",
  "u",
  "ul",
  "var",
  "video",
  "wbr"
], Ur = [
  // Base structural elements
  "g",
  "defs",
  "use",
  "symbol",
  // Shape elements
  "rect",
  "circle",
  "ellipse",
  "line",
  "polyline",
  "polygon",
  "path",
  "image",
  // Text elements
  "text",
  "tspan",
  "textPath",
  // Gradient and effects
  "linearGradient",
  "radialGradient",
  "stop",
  "pattern",
  "clipPath",
  "mask",
  "filter",
  // Filter effects
  "feBlend",
  "feColorMatrix",
  "feComponentTransfer",
  "feComposite",
  "feConvolveMatrix",
  "feDiffuseLighting",
  "feDisplacementMap",
  "feGaussianBlur",
  "feMerge",
  "feMorphology",
  "feOffset",
  "feSpecularLighting",
  "feTurbulence",
  "feMergeNode",
  "feFuncR",
  "feFuncG",
  "feFuncB",
  "feFuncA",
  "feDistantLight",
  "fePointLight",
  "feSpotLight",
  "feFlood",
  "feTile",
  // Animation elements
  "animate",
  "animateTransform",
  "animateMotion",
  "mpath",
  "set",
  // Interactive and other elements
  "view",
  "cursor",
  "foreignObject",
  "desc",
  "title",
  "metadata",
  "switch"
], Vr = [
  ...Kn,
  ...Ur.filter((i) => !Kn.includes(i))
], {
  HtmlTagHydration: Zr,
  SvelteComponent: Xr,
  attr: Wr,
  binding_callbacks: Yr,
  children: Kr,
  claim_element: Qr,
  claim_html_tag: Jr,
  detach: Qn,
  element: eo,
  init: to,
  insert_hydration: no,
  noop: Jn,
  safe_not_equal: io,
  toggle_class: _t
} = window.__gradio__svelte__internal, { afterUpdate: ao, tick: lo, onMount: Ty } = window.__gradio__svelte__internal;
function ro(i) {
  let e, t;
  return {
    c() {
      e = eo("span"), t = new Zr(!1), this.h();
    },
    l(n) {
      e = Qr(n, "SPAN", { class: !0 });
      var a = Kr(e);
      t = Jr(a, !1), a.forEach(Qn), this.h();
    },
    h() {
      t.a = null, Wr(e, "class", "md svelte-1m32c2s"), _t(
        e,
        "chatbot",
        /*chatbot*/
        i[0]
      ), _t(
        e,
        "prose",
        /*render_markdown*/
        i[1]
      );
    },
    m(n, a) {
      no(n, e, a), t.m(
        /*html*/
        i[3],
        e
      ), i[11](e);
    },
    p(n, [a]) {
      a & /*html*/
      8 && t.p(
        /*html*/
        n[3]
      ), a & /*chatbot*/
      1 && _t(
        e,
        "chatbot",
        /*chatbot*/
        n[0]
      ), a & /*render_markdown*/
      2 && _t(
        e,
        "prose",
        /*render_markdown*/
        n[1]
      );
    },
    i: Jn,
    o: Jn,
    d(n) {
      n && Qn(e), i[11](null);
    }
  };
}
function ei(i) {
  return i.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function oo(i, e, t) {
  var n = this && this.__awaiter || function(b, g, k, D) {
    function C(x) {
      return x instanceof k ? x : new k(function(T) {
        T(x);
      });
    }
    return new (k || (k = Promise))(function(x, T) {
      function V(R) {
        try {
          U(D.next(R));
        } catch (H) {
          T(H);
        }
      }
      function j(R) {
        try {
          U(D.throw(R));
        } catch (H) {
          T(H);
        }
      }
      function U(R) {
        R.done ? x(R.value) : C(R.value).then(V, j);
      }
      U((D = D.apply(b, g || [])).next());
    });
  };
  let { chatbot: a = !0 } = e, { message: r } = e, { sanitize_html: l = !0 } = e, { latex_delimiters: o = [] } = e, { render_markdown: s = !0 } = e, { line_breaks: u = !0 } = e, { header_links: _ = !1 } = e, { allow_tags: f = !1 } = e, { theme_mode: d = "system" } = e, h, m, w = !1;
  const y = br({
    header_links: _,
    line_breaks: u,
    latex_delimiters: o || []
  });
  function E(b) {
    return !o || o.length === 0 ? !1 : o.some((g) => b.includes(g.left) && b.includes(g.right));
  }
  function p(b, g) {
    if (g === !0) {
      const k = /<\/?([a-zA-Z][a-zA-Z0-9-]*)([\s>])/g;
      return b.replace(k, (D, C, x) => Vr.includes(C.toLowerCase()) ? D : D.replace(/</g, "&lt;").replace(/>/g, "&gt;"));
    }
    if (Array.isArray(g)) {
      const k = g.map((C) => ({
        open: new RegExp(`<(${C})(\\s+[^>]*)?>`, "gi"),
        close: new RegExp(`</(${C})>`, "gi")
      }));
      let D = b;
      return k.forEach((C) => {
        D = D.replace(C.open, (x) => x.replace(/</g, "&lt;").replace(/>/g, "&gt;")), D = D.replace(C.close, (x) => x.replace(/</g, "&lt;").replace(/>/g, "&gt;"));
      }), D;
    }
    return b;
  }
  function c(b) {
    let g = b;
    if (s) {
      const k = [];
      o.forEach((D, C) => {
        const x = ei(D.left), T = ei(D.right), V = new RegExp(`${x}([\\s\\S]+?)${T}`, "g");
        g = g.replace(V, (j, U) => (k.push(j), `%%%LATEX_BLOCK_${k.length - 1}%%%`));
      }), g = y.parse(g), g = g.replace(/%%%LATEX_BLOCK_(\d+)%%%/g, (D, C) => k[parseInt(C, 10)]);
    }
    return f && (g = p(g, f)), l && Yn && (g = Yn(g)), g;
  }
  function v(b) {
    return n(this, void 0, void 0, function* () {
      if (o.length > 0 && b && E(b))
        if (!w)
          yield Promise.all([
            Promise.resolve({              }),
            import("./auto-render-BwaQGe8P.js")
          ]).then(([, { default: g }]) => {
            w = !0, g(h, {
              delimiters: o,
              throwOnError: !1
            });
          });
        else {
          const { default: g } = yield import("./auto-render-BwaQGe8P.js");
          g(h, {
            delimiters: o,
            throwOnError: !1
          });
        }
      if (h) {
        const g = h.querySelectorAll(".mermaid");
        if (g.length > 0) {
          yield lo();
          const { default: k } = yield import("./mermaid.core-BTngqxdm.js").then((D) => D.bC);
          k.initialize({
            startOnLoad: !1,
            theme: d === "dark" ? "dark" : "default",
            securityLevel: "antiscript"
          }), yield k.run({
            nodes: Array.from(g).map((D) => D)
          });
        }
      }
    });
  }
  ao(() => n(void 0, void 0, void 0, function* () {
    h && document.body.contains(h) ? yield v(r) : console.error("Element is not in the DOM");
  }));
  function F(b) {
    Yr[b ? "unshift" : "push"](() => {
      h = b, t(2, h);
    });
  }
  return i.$$set = (b) => {
    "chatbot" in b && t(0, a = b.chatbot), "message" in b && t(4, r = b.message), "sanitize_html" in b && t(5, l = b.sanitize_html), "latex_delimiters" in b && t(6, o = b.latex_delimiters), "render_markdown" in b && t(1, s = b.render_markdown), "line_breaks" in b && t(7, u = b.line_breaks), "header_links" in b && t(8, _ = b.header_links), "allow_tags" in b && t(9, f = b.allow_tags), "theme_mode" in b && t(10, d = b.theme_mode);
  }, i.$$.update = () => {
    i.$$.dirty & /*message*/
    16 && (r && r.trim() ? t(3, m = c(r)) : t(3, m = ""));
  }, [
    a,
    s,
    h,
    m,
    r,
    l,
    o,
    u,
    _,
    f,
    d,
    F
  ];
}
class va extends Xr {
  constructor(e) {
    super(), to(this, e, oo, ro, io, {
      chatbot: 0,
      message: 4,
      sanitize_html: 5,
      latex_delimiters: 6,
      render_markdown: 1,
      line_breaks: 7,
      header_links: 8,
      allow_tags: 9,
      theme_mode: 10
    });
  }
}
const {
  SvelteComponent: qy,
  attr: Ly,
  children: zy,
  claim_component: Iy,
  claim_element: Ry,
  create_component: My,
  destroy_component: Oy,
  detach: Py,
  element: Ny,
  init: Hy,
  insert_hydration: jy,
  mount_component: Gy,
  safe_not_equal: Uy,
  transition_in: Vy,
  transition_out: Zy
} = window.__gradio__svelte__internal, {
  SvelteComponent: Xy,
  attr: Wy,
  check_outros: Yy,
  children: Ky,
  claim_component: Qy,
  claim_element: Jy,
  claim_space: eF,
  create_component: tF,
  create_slot: nF,
  destroy_component: iF,
  detach: aF,
  element: lF,
  empty: rF,
  get_all_dirty_from_scope: oF,
  get_slot_changes: sF,
  group_outros: uF,
  init: cF,
  insert_hydration: _F,
  mount_component: dF,
  safe_not_equal: hF,
  space: fF,
  toggle_class: pF,
  transition_in: mF,
  transition_out: gF,
  update_slot_base: vF
} = window.__gradio__svelte__internal, {
  SvelteComponent: DF,
  append_hydration: bF,
  attr: wF,
  children: yF,
  claim_component: FF,
  claim_element: kF,
  claim_space: $F,
  claim_text: CF,
  create_component: EF,
  destroy_component: AF,
  detach: SF,
  element: xF,
  init: BF,
  insert_hydration: TF,
  mount_component: qF,
  safe_not_equal: LF,
  set_data: zF,
  space: IF,
  text: RF,
  toggle_class: MF,
  transition_in: OF,
  transition_out: PF
} = window.__gradio__svelte__internal, {
  SvelteComponent: so,
  append_hydration: vt,
  attr: $e,
  bubble: uo,
  check_outros: co,
  children: Yt,
  claim_component: _o,
  claim_element: Kt,
  claim_space: ti,
  claim_text: ho,
  construct_svelte_component: ni,
  create_component: ii,
  create_slot: fo,
  destroy_component: ai,
  detach: Ze,
  element: Qt,
  get_all_dirty_from_scope: po,
  get_slot_changes: mo,
  group_outros: go,
  init: vo,
  insert_hydration: Da,
  listen: Do,
  mount_component: li,
  safe_not_equal: bo,
  set_data: wo,
  set_style: dt,
  space: ri,
  text: yo,
  toggle_class: X,
  transition_in: Ht,
  transition_out: jt,
  update_slot_base: Fo
} = window.__gradio__svelte__internal;
function oi(i) {
  let e, t;
  return {
    c() {
      e = Qt("span"), t = yo(
        /*label*/
        i[1]
      ), this.h();
    },
    l(n) {
      e = Kt(n, "SPAN", { class: !0 });
      var a = Yt(e);
      t = ho(
        a,
        /*label*/
        i[1]
      ), a.forEach(Ze), this.h();
    },
    h() {
      $e(e, "class", "svelte-qgco6m");
    },
    m(n, a) {
      Da(n, e, a), vt(e, t);
    },
    p(n, a) {
      a & /*label*/
      2 && wo(
        t,
        /*label*/
        n[1]
      );
    },
    d(n) {
      n && Ze(e);
    }
  };
}
function ko(i) {
  let e, t, n, a, r, l, o, s, u = (
    /*show_label*/
    i[2] && oi(i)
  );
  var _ = (
    /*Icon*/
    i[0]
  );
  function f(m, w) {
    return {};
  }
  _ && (a = ni(_, f()));
  const d = (
    /*#slots*/
    i[14].default
  ), h = fo(
    d,
    i,
    /*$$scope*/
    i[13],
    null
  );
  return {
    c() {
      e = Qt("button"), u && u.c(), t = ri(), n = Qt("div"), a && ii(a.$$.fragment), r = ri(), h && h.c(), this.h();
    },
    l(m) {
      e = Kt(m, "BUTTON", {
        "aria-label": !0,
        "aria-haspopup": !0,
        title: !0,
        class: !0
      });
      var w = Yt(e);
      u && u.l(w), t = ti(w), n = Kt(w, "DIV", { class: !0 });
      var y = Yt(n);
      a && _o(a.$$.fragment, y), r = ti(y), h && h.l(y), y.forEach(Ze), w.forEach(Ze), this.h();
    },
    h() {
      $e(n, "class", "svelte-qgco6m"), X(
        n,
        "x-small",
        /*size*/
        i[4] === "x-small"
      ), X(
        n,
        "small",
        /*size*/
        i[4] === "small"
      ), X(
        n,
        "large",
        /*size*/
        i[4] === "large"
      ), X(
        n,
        "medium",
        /*size*/
        i[4] === "medium"
      ), e.disabled = /*disabled*/
      i[7], $e(
        e,
        "aria-label",
        /*label*/
        i[1]
      ), $e(
        e,
        "aria-haspopup",
        /*hasPopup*/
        i[8]
      ), $e(
        e,
        "title",
        /*label*/
        i[1]
      ), $e(e, "class", "svelte-qgco6m"), X(
        e,
        "pending",
        /*pending*/
        i[3]
      ), X(
        e,
        "padded",
        /*padded*/
        i[5]
      ), X(
        e,
        "highlight",
        /*highlight*/
        i[6]
      ), X(
        e,
        "transparent",
        /*transparent*/
        i[9]
      ), dt(e, "color", !/*disabled*/
      i[7] && /*_color*/
      i[11] ? (
        /*_color*/
        i[11]
      ) : "var(--block-label-text-color)"), dt(e, "--bg-color", /*disabled*/
      i[7] ? "auto" : (
        /*background*/
        i[10]
      ));
    },
    m(m, w) {
      Da(m, e, w), u && u.m(e, null), vt(e, t), vt(e, n), a && li(a, n, null), vt(n, r), h && h.m(n, null), l = !0, o || (s = Do(
        e,
        "click",
        /*click_handler*/
        i[15]
      ), o = !0);
    },
    p(m, [w]) {
      if (/*show_label*/
      m[2] ? u ? u.p(m, w) : (u = oi(m), u.c(), u.m(e, t)) : u && (u.d(1), u = null), w & /*Icon*/
      1 && _ !== (_ = /*Icon*/
      m[0])) {
        if (a) {
          go();
          const y = a;
          jt(y.$$.fragment, 1, 0, () => {
            ai(y, 1);
          }), co();
        }
        _ ? (a = ni(_, f()), ii(a.$$.fragment), Ht(a.$$.fragment, 1), li(a, n, r)) : a = null;
      }
      h && h.p && (!l || w & /*$$scope*/
      8192) && Fo(
        h,
        d,
        m,
        /*$$scope*/
        m[13],
        l ? mo(
          d,
          /*$$scope*/
          m[13],
          w,
          null
        ) : po(
          /*$$scope*/
          m[13]
        ),
        null
      ), (!l || w & /*size*/
      16) && X(
        n,
        "x-small",
        /*size*/
        m[4] === "x-small"
      ), (!l || w & /*size*/
      16) && X(
        n,
        "small",
        /*size*/
        m[4] === "small"
      ), (!l || w & /*size*/
      16) && X(
        n,
        "large",
        /*size*/
        m[4] === "large"
      ), (!l || w & /*size*/
      16) && X(
        n,
        "medium",
        /*size*/
        m[4] === "medium"
      ), (!l || w & /*disabled*/
      128) && (e.disabled = /*disabled*/
      m[7]), (!l || w & /*label*/
      2) && $e(
        e,
        "aria-label",
        /*label*/
        m[1]
      ), (!l || w & /*hasPopup*/
      256) && $e(
        e,
        "aria-haspopup",
        /*hasPopup*/
        m[8]
      ), (!l || w & /*label*/
      2) && $e(
        e,
        "title",
        /*label*/
        m[1]
      ), (!l || w & /*pending*/
      8) && X(
        e,
        "pending",
        /*pending*/
        m[3]
      ), (!l || w & /*padded*/
      32) && X(
        e,
        "padded",
        /*padded*/
        m[5]
      ), (!l || w & /*highlight*/
      64) && X(
        e,
        "highlight",
        /*highlight*/
        m[6]
      ), (!l || w & /*transparent*/
      512) && X(
        e,
        "transparent",
        /*transparent*/
        m[9]
      ), w & /*disabled, _color*/
      2176 && dt(e, "color", !/*disabled*/
      m[7] && /*_color*/
      m[11] ? (
        /*_color*/
        m[11]
      ) : "var(--block-label-text-color)"), w & /*disabled, background*/
      1152 && dt(e, "--bg-color", /*disabled*/
      m[7] ? "auto" : (
        /*background*/
        m[10]
      ));
    },
    i(m) {
      l || (a && Ht(a.$$.fragment, m), Ht(h, m), l = !0);
    },
    o(m) {
      a && jt(a.$$.fragment, m), jt(h, m), l = !1;
    },
    d(m) {
      m && Ze(e), u && u.d(), a && ai(a), h && h.d(m), o = !1, s();
    }
  };
}
function $o(i, e, t) {
  let n, { $$slots: a = {}, $$scope: r } = e, { Icon: l } = e, { label: o = "" } = e, { show_label: s = !1 } = e, { pending: u = !1 } = e, { size: _ = "small" } = e, { padded: f = !0 } = e, { highlight: d = !1 } = e, { disabled: h = !1 } = e, { hasPopup: m = !1 } = e, { color: w = "var(--block-label-text-color)" } = e, { transparent: y = !1 } = e, { background: E = "var(--block-background-fill)" } = e;
  function p(c) {
    uo.call(this, i, c);
  }
  return i.$$set = (c) => {
    "Icon" in c && t(0, l = c.Icon), "label" in c && t(1, o = c.label), "show_label" in c && t(2, s = c.show_label), "pending" in c && t(3, u = c.pending), "size" in c && t(4, _ = c.size), "padded" in c && t(5, f = c.padded), "highlight" in c && t(6, d = c.highlight), "disabled" in c && t(7, h = c.disabled), "hasPopup" in c && t(8, m = c.hasPopup), "color" in c && t(12, w = c.color), "transparent" in c && t(9, y = c.transparent), "background" in c && t(10, E = c.background), "$$scope" in c && t(13, r = c.$$scope);
  }, i.$$.update = () => {
    i.$$.dirty & /*highlight, color*/
    4160 && t(11, n = d ? "var(--color-accent)" : w);
  }, [
    l,
    o,
    s,
    u,
    _,
    f,
    d,
    h,
    m,
    y,
    E,
    n,
    w,
    r,
    a,
    p
  ];
}
class ba extends so {
  constructor(e) {
    super(), vo(this, e, $o, ko, bo, {
      Icon: 0,
      label: 1,
      show_label: 2,
      pending: 3,
      size: 4,
      padded: 5,
      highlight: 6,
      disabled: 7,
      hasPopup: 8,
      color: 12,
      transparent: 9,
      background: 10
    });
  }
}
const {
  SvelteComponent: NF,
  append_hydration: HF,
  attr: jF,
  binding_callbacks: GF,
  children: UF,
  claim_element: VF,
  create_slot: ZF,
  detach: XF,
  element: WF,
  get_all_dirty_from_scope: YF,
  get_slot_changes: KF,
  init: QF,
  insert_hydration: JF,
  safe_not_equal: e2,
  toggle_class: t2,
  transition_in: n2,
  transition_out: i2,
  update_slot_base: a2
} = window.__gradio__svelte__internal, {
  SvelteComponent: l2,
  claim_component: r2,
  create_component: o2,
  destroy_component: s2,
  init: u2,
  mount_component: c2,
  safe_not_equal: _2,
  transition_in: d2,
  transition_out: h2
} = window.__gradio__svelte__internal, { createEventDispatcher: f2 } = window.__gradio__svelte__internal, {
  SvelteComponent: p2,
  append_hydration: m2,
  attr: g2,
  check_outros: v2,
  children: D2,
  claim_component: b2,
  claim_element: w2,
  claim_space: y2,
  claim_text: F2,
  create_component: k2,
  destroy_component: $2,
  detach: C2,
  element: E2,
  empty: A2,
  group_outros: S2,
  init: x2,
  insert_hydration: B2,
  mount_component: T2,
  safe_not_equal: q2,
  set_data: L2,
  space: z2,
  text: I2,
  toggle_class: R2,
  transition_in: M2,
  transition_out: O2
} = window.__gradio__svelte__internal, {
  SvelteComponent: P2,
  attr: N2,
  children: H2,
  claim_element: j2,
  create_slot: G2,
  detach: U2,
  element: V2,
  get_all_dirty_from_scope: Z2,
  get_slot_changes: X2,
  init: W2,
  insert_hydration: Y2,
  safe_not_equal: K2,
  toggle_class: Q2,
  transition_in: J2,
  transition_out: ek,
  update_slot_base: tk
} = window.__gradio__svelte__internal, {
  SvelteComponent: nk,
  append_hydration: ik,
  attr: ak,
  check_outros: lk,
  children: rk,
  claim_component: ok,
  claim_element: sk,
  claim_space: uk,
  create_component: ck,
  destroy_component: _k,
  detach: dk,
  element: hk,
  empty: fk,
  group_outros: pk,
  init: mk,
  insert_hydration: gk,
  listen: vk,
  mount_component: Dk,
  safe_not_equal: bk,
  space: wk,
  toggle_class: yk,
  transition_in: Fk,
  transition_out: kk
} = window.__gradio__svelte__internal, {
  SvelteComponent: Co,
  attr: si,
  children: Eo,
  claim_element: Ao,
  create_slot: So,
  detach: ui,
  element: xo,
  get_all_dirty_from_scope: Bo,
  get_slot_changes: To,
  init: qo,
  insert_hydration: Lo,
  null_to_empty: ci,
  safe_not_equal: zo,
  transition_in: Io,
  transition_out: Ro,
  update_slot_base: Mo
} = window.__gradio__svelte__internal;
function Oo(i) {
  let e, t, n;
  const a = (
    /*#slots*/
    i[3].default
  ), r = So(
    a,
    i,
    /*$$scope*/
    i[2],
    null
  );
  return {
    c() {
      e = xo("div"), r && r.c(), this.h();
    },
    l(l) {
      e = Ao(l, "DIV", { class: !0 });
      var o = Eo(e);
      r && r.l(o), o.forEach(ui), this.h();
    },
    h() {
      si(e, "class", t = ci(`icon-button-wrapper ${/*top_panel*/
      i[0] ? "top-panel" : ""} ${/*display_top_corner*/
      i[1] ? "display-top-corner" : "hide-top-corner"}`) + " svelte-1h0hs6p");
    },
    m(l, o) {
      Lo(l, e, o), r && r.m(e, null), n = !0;
    },
    p(l, [o]) {
      r && r.p && (!n || o & /*$$scope*/
      4) && Mo(
        r,
        a,
        l,
        /*$$scope*/
        l[2],
        n ? To(
          a,
          /*$$scope*/
          l[2],
          o,
          null
        ) : Bo(
          /*$$scope*/
          l[2]
        ),
        null
      ), (!n || o & /*top_panel, display_top_corner*/
      3 && t !== (t = ci(`icon-button-wrapper ${/*top_panel*/
      l[0] ? "top-panel" : ""} ${/*display_top_corner*/
      l[1] ? "display-top-corner" : "hide-top-corner"}`) + " svelte-1h0hs6p")) && si(e, "class", t);
    },
    i(l) {
      n || (Io(r, l), n = !0);
    },
    o(l) {
      Ro(r, l), n = !1;
    },
    d(l) {
      l && ui(e), r && r.d(l);
    }
  };
}
function Po(i, e, t) {
  let { $$slots: n = {}, $$scope: a } = e, { top_panel: r = !0 } = e, { display_top_corner: l = !1 } = e;
  return i.$$set = (o) => {
    "top_panel" in o && t(0, r = o.top_panel), "display_top_corner" in o && t(1, l = o.display_top_corner), "$$scope" in o && t(2, a = o.$$scope);
  }, [r, l, a, n];
}
class No extends Co {
  constructor(e) {
    super(), qo(this, e, Po, Oo, zo, { top_panel: 0, display_top_corner: 1 });
  }
}
const {
  SvelteComponent: $k,
  check_outros: Ck,
  claim_component: Ek,
  create_component: Ak,
  destroy_component: Sk,
  detach: xk,
  empty: Bk,
  group_outros: Tk,
  init: qk,
  insert_hydration: Lk,
  mount_component: zk,
  noop: Ik,
  safe_not_equal: Rk,
  transition_in: Mk,
  transition_out: Ok
} = window.__gradio__svelte__internal, { createEventDispatcher: Pk } = window.__gradio__svelte__internal, {
  SvelteComponent: Ho,
  action_destroyer: jo,
  append_hydration: Se,
  attr: de,
  check_outros: Go,
  children: Ft,
  claim_component: bn,
  claim_element: Xe,
  claim_space: Jt,
  claim_text: Uo,
  create_component: wn,
  destroy_component: yn,
  detach: Pe,
  element: We,
  get_svelte_dataset: Vo,
  group_outros: Zo,
  init: Xo,
  insert_hydration: wa,
  mount_component: Fn,
  safe_not_equal: Wo,
  set_data: Yo,
  set_style: _i,
  space: en,
  text: Ko,
  toggle_class: di,
  transition_in: Me,
  transition_out: Ye
} = window.__gradio__svelte__internal, { createEventDispatcher: Qo } = window.__gradio__svelte__internal;
function hi(i) {
  let e, t;
  return e = new No({
    props: {
      $$slots: { default: [Jo] },
      $$scope: { ctx: i }
    }
  }), {
    c() {
      wn(e.$$.fragment);
    },
    l(n) {
      bn(e.$$.fragment, n);
    },
    m(n, a) {
      Fn(e, n, a), t = !0;
    },
    p(n, a) {
      const r = {};
      a & /*$$scope, copied*/
      1064960 && (r.$$scope = { dirty: a, ctx: n }), e.$set(r);
    },
    i(n) {
      t || (Me(e.$$.fragment, n), t = !0);
    },
    o(n) {
      Ye(e.$$.fragment, n), t = !1;
    },
    d(n) {
      yn(e, n);
    }
  };
}
function Jo(i) {
  let e, t;
  return e = new ba({
    props: {
      Icon: (
        /*copied*/
        i[14] ? Bn : qn
      ),
      label: (
        /*copied*/
        i[14] ? "Copied conversation" : "Copy conversation"
      )
    }
  }), e.$on(
    "click",
    /*handle_copy*/
    i[15]
  ), {
    c() {
      wn(e.$$.fragment);
    },
    l(n) {
      bn(e.$$.fragment, n);
    },
    m(n, a) {
      Fn(e, n, a), t = !0;
    },
    p(n, a) {
      const r = {};
      a & /*copied*/
      16384 && (r.Icon = /*copied*/
      n[14] ? Bn : qn), a & /*copied*/
      16384 && (r.label = /*copied*/
      n[14] ? "Copied conversation" : "Copy conversation"), e.$set(r);
    },
    i(n) {
      t || (Me(e.$$.fragment, n), t = !0);
    },
    o(n) {
      Ye(e.$$.fragment, n), t = !1;
    },
    d(n) {
      yn(e, n);
    }
  };
}
function fi(i) {
  let e, t, n = "?", a, r, l;
  return {
    c() {
      e = We("span"), t = We("span"), t.textContent = n, a = en(), r = We("span"), l = Ko(
        /*tooltip*/
        i[3]
      ), this.h();
    },
    l(o) {
      e = Xe(o, "SPAN", { class: !0 });
      var s = Ft(e);
      t = Xe(s, "SPAN", { class: !0, "data-svelte-h": !0 }), Vo(t) !== "svelte-fzek5l" && (t.textContent = n), a = Jt(s), r = Xe(s, "SPAN", { class: !0 });
      var u = Ft(r);
      l = Uo(
        u,
        /*tooltip*/
        i[3]
      ), u.forEach(Pe), s.forEach(Pe), this.h();
    },
    h() {
      de(t, "class", "tooltip-icon svelte-15dk3s5"), de(r, "class", "tooltip-text svelte-15dk3s5"), de(e, "class", "tooltip-container svelte-15dk3s5");
    },
    m(o, s) {
      wa(o, e, s), Se(e, t), Se(e, a), Se(e, r), Se(r, l);
    },
    p(o, s) {
      s & /*tooltip*/
      8 && Yo(
        l,
        /*tooltip*/
        o[3]
      );
    },
    d(o) {
      o && Pe(e);
    }
  };
}
function es(i) {
  let e, t, n, a, r, l, o, s, u, _, f, d = (
    /*show_copy_button*/
    i[11] && hi(i)
  );
  a = new va({
    props: {
      message: (
        /*value*/
        i[2]
      ),
      latex_delimiters: (
        /*latex_delimiters*/
        i[8]
      ),
      sanitize_html: (
        /*sanitize_html*/
        i[6]
      ),
      line_breaks: (
        /*line_breaks*/
        i[7]
      ),
      chatbot: !1,
      header_links: (
        /*header_links*/
        i[9]
      ),
      theme_mode: (
        /*theme_mode*/
        i[13]
      )
    }
  });
  let h = (
    /*tooltip*/
    i[3] && fi(i)
  );
  return {
    c() {
      e = We("div"), d && d.c(), t = en(), n = We("span"), wn(a.$$.fragment), r = en(), h && h.c(), this.h();
    },
    l(m) {
      e = Xe(m, "DIV", {
        class: !0,
        "data-testid": !0,
        dir: !0,
        style: !0
      });
      var w = Ft(e);
      d && d.l(w), t = Jt(w), n = Xe(w, "SPAN", { class: !0 });
      var y = Ft(n);
      bn(a.$$.fragment, y), r = Jt(y), h && h.l(y), y.forEach(Pe), w.forEach(Pe), this.h();
    },
    h() {
      var m, w;
      de(n, "class", "markdown-wrapper svelte-15dk3s5"), de(e, "class", l = "prose " + /*elem_classes*/
      (((m = i[0]) == null ? void 0 : m.join(" ")) || "") + " svelte-15dk3s5"), de(e, "data-testid", "markdown"), de(e, "dir", o = /*rtl*/
      i[5] ? "rtl" : "ltr"), de(e, "style", s = /*height*/
      i[10] ? `max-height: ${it(
        /*height*/
        i[10]
      )}; overflow-y: auto;` : ""), di(e, "hide", !/*visible*/
      i[1]), _i(
        e,
        "min-height",
        /*min_height*/
        i[4] && /*loading_status*/
        ((w = i[12]) == null ? void 0 : w.status) !== "pending" ? it(
          /*min_height*/
          i[4]
        ) : void 0
      );
    },
    m(m, w) {
      wa(m, e, w), d && d.m(e, null), Se(e, t), Se(e, n), Fn(a, n, null), Se(n, r), h && h.m(n, null), u = !0, _ || (f = jo(Pa.call(null, e)), _ = !0);
    },
    p(m, [w]) {
      var p, c;
      /*show_copy_button*/
      m[11] ? d ? (d.p(m, w), w & /*show_copy_button*/
      2048 && Me(d, 1)) : (d = hi(m), d.c(), Me(d, 1), d.m(e, t)) : d && (Zo(), Ye(d, 1, 1, () => {
        d = null;
      }), Go());
      const y = {};
      w & /*value*/
      4 && (y.message = /*value*/
      m[2]), w & /*latex_delimiters*/
      256 && (y.latex_delimiters = /*latex_delimiters*/
      m[8]), w & /*sanitize_html*/
      64 && (y.sanitize_html = /*sanitize_html*/
      m[6]), w & /*line_breaks*/
      128 && (y.line_breaks = /*line_breaks*/
      m[7]), w & /*header_links*/
      512 && (y.header_links = /*header_links*/
      m[9]), w & /*theme_mode*/
      8192 && (y.theme_mode = /*theme_mode*/
      m[13]), a.$set(y), /*tooltip*/
      m[3] ? h ? h.p(m, w) : (h = fi(m), h.c(), h.m(n, null)) : h && (h.d(1), h = null), (!u || w & /*elem_classes*/
      1 && l !== (l = "prose " + /*elem_classes*/
      (((p = m[0]) == null ? void 0 : p.join(" ")) || "") + " svelte-15dk3s5")) && de(e, "class", l), (!u || w & /*rtl*/
      32 && o !== (o = /*rtl*/
      m[5] ? "rtl" : "ltr")) && de(e, "dir", o), (!u || w & /*height*/
      1024 && s !== (s = /*height*/
      m[10] ? `max-height: ${it(
        /*height*/
        m[10]
      )}; overflow-y: auto;` : "")) && de(e, "style", s), (!u || w & /*elem_classes, visible*/
      3) && di(e, "hide", !/*visible*/
      m[1]);
      const E = w & /*height*/
      1024;
      (w & /*min_height, loading_status, height*/
      5136 || E) && _i(
        e,
        "min-height",
        /*min_height*/
        m[4] && /*loading_status*/
        ((c = m[12]) == null ? void 0 : c.status) !== "pending" ? it(
          /*min_height*/
          m[4]
        ) : void 0
      );
    },
    i(m) {
      u || (Me(d), Me(a.$$.fragment, m), u = !0);
    },
    o(m) {
      Ye(d), Ye(a.$$.fragment, m), u = !1;
    },
    d(m) {
      m && Pe(e), d && d.d(), yn(a), h && h.d(), _ = !1, f();
    }
  };
}
function ts(i, e, t) {
  var n = this && this.__awaiter || function(g, k, D, C) {
    function x(T) {
      return T instanceof D ? T : new D(function(V) {
        V(T);
      });
    }
    return new (D || (D = Promise))(function(T, V) {
      function j(H) {
        try {
          R(C.next(H));
        } catch (O) {
          V(O);
        }
      }
      function U(H) {
        try {
          R(C.throw(H));
        } catch (O) {
          V(O);
        }
      }
      function R(H) {
        H.done ? T(H.value) : x(H.value).then(j, U);
      }
      R((C = C.apply(g, k || [])).next());
    });
  };
  let { elem_classes: a = [] } = e, { visible: r = !0 } = e, { value: l } = e, { tooltip: o = null } = e, { min_height: s = void 0 } = e, { rtl: u = !1 } = e, { sanitize_html: _ = !0 } = e, { line_breaks: f = !1 } = e, { latex_delimiters: d } = e, { header_links: h = !1 } = e, { height: m = void 0 } = e, { show_copy_button: w = !1 } = e, { loading_status: y = void 0 } = e, { theme_mode: E } = e, p = !1, c;
  const v = Qo();
  function F() {
    return n(this, void 0, void 0, function* () {
      "clipboard" in navigator && (yield navigator.clipboard.writeText(l), v("copy", { value: l }), b());
    });
  }
  function b() {
    t(14, p = !0), c && clearTimeout(c), c = setTimeout(
      () => {
        t(14, p = !1);
      },
      1e3
    );
  }
  return i.$$set = (g) => {
    "elem_classes" in g && t(0, a = g.elem_classes), "visible" in g && t(1, r = g.visible), "value" in g && t(2, l = g.value), "tooltip" in g && t(3, o = g.tooltip), "min_height" in g && t(4, s = g.min_height), "rtl" in g && t(5, u = g.rtl), "sanitize_html" in g && t(6, _ = g.sanitize_html), "line_breaks" in g && t(7, f = g.line_breaks), "latex_delimiters" in g && t(8, d = g.latex_delimiters), "header_links" in g && t(9, h = g.header_links), "height" in g && t(10, m = g.height), "show_copy_button" in g && t(11, w = g.show_copy_button), "loading_status" in g && t(12, y = g.loading_status), "theme_mode" in g && t(13, E = g.theme_mode);
  }, i.$$.update = () => {
    i.$$.dirty & /*value*/
    4 && v("change");
  }, [
    a,
    r,
    l,
    o,
    s,
    u,
    _,
    f,
    d,
    h,
    m,
    w,
    y,
    E,
    p,
    F
  ];
}
class ns extends Ho {
  constructor(e) {
    super(), Xo(this, e, ts, es, Wo, {
      elem_classes: 0,
      visible: 1,
      value: 2,
      tooltip: 3,
      min_height: 4,
      rtl: 5,
      sanitize_html: 6,
      line_breaks: 7,
      latex_delimiters: 8,
      header_links: 9,
      height: 10,
      show_copy_button: 11,
      loading_status: 12,
      theme_mode: 13
    });
  }
}
function Oe(i) {
  let e = ["", "k", "M", "G", "T", "P", "E", "Z"], t = 0;
  for (; i > 1e3 && t < e.length - 1; )
    i /= 1e3, t++;
  let n = e[t];
  return (Number.isInteger(i) ? i : i.toFixed(1)) + n;
}
function Dt() {
}
const ya = typeof window < "u";
let pi = ya ? () => window.performance.now() : () => Date.now(), Fa = ya ? (i) => requestAnimationFrame(i) : Dt;
const Ne = /* @__PURE__ */ new Set();
function ka(i) {
  Ne.forEach((e) => {
    e.c(i) || (Ne.delete(e), e.f());
  }), Ne.size !== 0 && Fa(ka);
}
function is(i) {
  let e;
  return Ne.size === 0 && Fa(ka), { promise: new Promise((t) => {
    Ne.add(e = { c: i, f: t });
  }), abort() {
    Ne.delete(e);
  } };
}
const Ie = [];
function as(i, e = Dt) {
  let t;
  const n = /* @__PURE__ */ new Set();
  function a(l) {
    if (s = l, ((o = i) != o ? s == s : o !== s || o && typeof o == "object" || typeof o == "function") && (i = l, t)) {
      const u = !Ie.length;
      for (const _ of n) _[1](), Ie.push(_, i);
      if (u) {
        for (let _ = 0; _ < Ie.length; _ += 2) Ie[_][0](Ie[_ + 1]);
        Ie.length = 0;
      }
    }
    var o, s;
  }
  function r(l) {
    a(l(i));
  }
  return { set: a, update: r, subscribe: function(l, o = Dt) {
    const s = [l, o];
    return n.add(s), n.size === 1 && (t = e(a, r) || Dt), l(i), () => {
      n.delete(s), n.size === 0 && t && (t(), t = null);
    };
  } };
}
function mi(i) {
  return Object.prototype.toString.call(i) === "[object Date]";
}
function tn(i, e, t, n) {
  if (typeof t == "number" || mi(t)) {
    const a = n - t, r = (t - e) / (i.dt || 1 / 60), l = (r + (i.opts.stiffness * a - i.opts.damping * r) * i.inv_mass) * i.dt;
    return Math.abs(l) < i.opts.precision && Math.abs(a) < i.opts.precision ? n : (i.settled = !1, mi(t) ? new Date(t.getTime() + l) : t + l);
  }
  if (Array.isArray(t)) return t.map((a, r) => tn(i, e[r], t[r], n[r]));
  if (typeof t == "object") {
    const a = {};
    for (const r in t) a[r] = tn(i, e[r], t[r], n[r]);
    return a;
  }
  throw new Error(`Cannot spring ${typeof t} values`);
}
function gi(i, e = {}) {
  const t = as(i), { stiffness: n = 0.15, damping: a = 0.8, precision: r = 0.01 } = e;
  let l, o, s, u = i, _ = i, f = 1, d = 0, h = !1;
  function m(y, E = {}) {
    _ = y;
    const p = s = {};
    return i == null || E.hard || w.stiffness >= 1 && w.damping >= 1 ? (h = !0, l = pi(), u = y, t.set(i = _), Promise.resolve()) : (E.soft && (d = 1 / (60 * (E.soft === !0 ? 0.5 : +E.soft)), f = 0), o || (l = pi(), h = !1, o = is((c) => {
      if (h) return h = !1, o = null, !1;
      f = Math.min(f + d, 1);
      const v = { inv_mass: f, opts: w, settled: !0, dt: 60 * (c - l) / 1e3 }, F = tn(v, u, i, _);
      return l = c, u = i, t.set(i = F), v.settled && (o = null), !v.settled;
    })), new Promise((c) => {
      o.promise.then(() => {
        p === s && c();
      });
    }));
  }
  const w = { set: m, update: (y, E) => m(y(_, i), E), subscribe: t.subscribe, stiffness: n, damping: a, precision: r };
  return w;
}
const {
  SvelteComponent: ls,
  append_hydration: ue,
  attr: q,
  children: te,
  claim_element: rs,
  claim_svg_element: ce,
  component_subscribe: vi,
  detach: Q,
  element: os,
  init: ss,
  insert_hydration: us,
  noop: Di,
  safe_not_equal: cs,
  set_style: ht,
  svg_element: _e,
  toggle_class: bi
} = window.__gradio__svelte__internal, { onMount: _s } = window.__gradio__svelte__internal;
function ds(i) {
  let e, t, n, a, r, l, o, s, u, _, f, d;
  return {
    c() {
      e = os("div"), t = _e("svg"), n = _e("g"), a = _e("path"), r = _e("path"), l = _e("path"), o = _e("path"), s = _e("g"), u = _e("path"), _ = _e("path"), f = _e("path"), d = _e("path"), this.h();
    },
    l(h) {
      e = rs(h, "DIV", { class: !0 });
      var m = te(e);
      t = ce(m, "svg", {
        viewBox: !0,
        fill: !0,
        xmlns: !0,
        class: !0
      });
      var w = te(t);
      n = ce(w, "g", { style: !0 });
      var y = te(n);
      a = ce(y, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), te(a).forEach(Q), r = ce(y, "path", { d: !0, fill: !0, class: !0 }), te(r).forEach(Q), l = ce(y, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), te(l).forEach(Q), o = ce(y, "path", { d: !0, fill: !0, class: !0 }), te(o).forEach(Q), y.forEach(Q), s = ce(w, "g", { style: !0 });
      var E = te(s);
      u = ce(E, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), te(u).forEach(Q), _ = ce(E, "path", { d: !0, fill: !0, class: !0 }), te(_).forEach(Q), f = ce(E, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), te(f).forEach(Q), d = ce(E, "path", { d: !0, fill: !0, class: !0 }), te(d).forEach(Q), E.forEach(Q), w.forEach(Q), m.forEach(Q), this.h();
    },
    h() {
      q(a, "d", "M255.926 0.754768L509.702 139.936V221.027L255.926 81.8465V0.754768Z"), q(a, "fill", "#FF7C00"), q(a, "fill-opacity", "0.4"), q(a, "class", "svelte-43sxxs"), q(r, "d", "M509.69 139.936L254.981 279.641V361.255L509.69 221.55V139.936Z"), q(r, "fill", "#FF7C00"), q(r, "class", "svelte-43sxxs"), q(l, "d", "M0.250138 139.937L254.981 279.641V361.255L0.250138 221.55V139.937Z"), q(l, "fill", "#FF7C00"), q(l, "fill-opacity", "0.4"), q(l, "class", "svelte-43sxxs"), q(o, "d", "M255.923 0.232622L0.236328 139.936V221.55L255.923 81.8469V0.232622Z"), q(o, "fill", "#FF7C00"), q(o, "class", "svelte-43sxxs"), ht(n, "transform", "translate(" + /*$top*/
      i[1][0] + "px, " + /*$top*/
      i[1][1] + "px)"), q(u, "d", "M255.926 141.5L509.702 280.681V361.773L255.926 222.592V141.5Z"), q(u, "fill", "#FF7C00"), q(u, "fill-opacity", "0.4"), q(u, "class", "svelte-43sxxs"), q(_, "d", "M509.69 280.679L254.981 420.384V501.998L509.69 362.293V280.679Z"), q(_, "fill", "#FF7C00"), q(_, "class", "svelte-43sxxs"), q(f, "d", "M0.250138 280.681L254.981 420.386V502L0.250138 362.295V280.681Z"), q(f, "fill", "#FF7C00"), q(f, "fill-opacity", "0.4"), q(f, "class", "svelte-43sxxs"), q(d, "d", "M255.923 140.977L0.236328 280.68V362.294L255.923 222.591V140.977Z"), q(d, "fill", "#FF7C00"), q(d, "class", "svelte-43sxxs"), ht(s, "transform", "translate(" + /*$bottom*/
      i[2][0] + "px, " + /*$bottom*/
      i[2][1] + "px)"), q(t, "viewBox", "-1200 -1200 3000 3000"), q(t, "fill", "none"), q(t, "xmlns", "http://www.w3.org/2000/svg"), q(t, "class", "svelte-43sxxs"), q(e, "class", "svelte-43sxxs"), bi(
        e,
        "margin",
        /*margin*/
        i[0]
      );
    },
    m(h, m) {
      us(h, e, m), ue(e, t), ue(t, n), ue(n, a), ue(n, r), ue(n, l), ue(n, o), ue(t, s), ue(s, u), ue(s, _), ue(s, f), ue(s, d);
    },
    p(h, [m]) {
      m & /*$top*/
      2 && ht(n, "transform", "translate(" + /*$top*/
      h[1][0] + "px, " + /*$top*/
      h[1][1] + "px)"), m & /*$bottom*/
      4 && ht(s, "transform", "translate(" + /*$bottom*/
      h[2][0] + "px, " + /*$bottom*/
      h[2][1] + "px)"), m & /*margin*/
      1 && bi(
        e,
        "margin",
        /*margin*/
        h[0]
      );
    },
    i: Di,
    o: Di,
    d(h) {
      h && Q(e);
    }
  };
}
function hs(i, e, t) {
  let n, a;
  var r = this && this.__awaiter || function(h, m, w, y) {
    function E(p) {
      return p instanceof w ? p : new w(function(c) {
        c(p);
      });
    }
    return new (w || (w = Promise))(function(p, c) {
      function v(g) {
        try {
          b(y.next(g));
        } catch (k) {
          c(k);
        }
      }
      function F(g) {
        try {
          b(y.throw(g));
        } catch (k) {
          c(k);
        }
      }
      function b(g) {
        g.done ? p(g.value) : E(g.value).then(v, F);
      }
      b((y = y.apply(h, m || [])).next());
    });
  };
  let { margin: l = !0 } = e;
  const o = gi([0, 0]);
  vi(i, o, (h) => t(1, n = h));
  const s = gi([0, 0]);
  vi(i, s, (h) => t(2, a = h));
  let u;
  function _() {
    return r(this, void 0, void 0, function* () {
      yield Promise.all([o.set([125, 140]), s.set([-125, -140])]), yield Promise.all([o.set([-125, 140]), s.set([125, -140])]), yield Promise.all([o.set([-125, 0]), s.set([125, -0])]), yield Promise.all([o.set([125, 0]), s.set([-125, 0])]);
    });
  }
  function f() {
    return r(this, void 0, void 0, function* () {
      yield _(), u || f();
    });
  }
  function d() {
    return r(this, void 0, void 0, function* () {
      yield Promise.all([o.set([125, 0]), s.set([-125, 0])]), f();
    });
  }
  return _s(() => (d(), () => u = !0)), i.$$set = (h) => {
    "margin" in h && t(0, l = h.margin);
  }, [l, n, a, o, s];
}
class fs extends ls {
  constructor(e) {
    super(), ss(this, e, hs, ds, cs, { margin: 0 });
  }
}
const {
  SvelteComponent: ps,
  append_hydration: xe,
  attr: fe,
  binding_callbacks: wi,
  check_outros: nn,
  children: we,
  claim_component: $a,
  claim_element: ye,
  claim_space: ie,
  claim_text: P,
  create_component: Ca,
  create_slot: Ea,
  destroy_component: Aa,
  destroy_each: Sa,
  detach: S,
  element: Fe,
  empty: le,
  ensure_array_like: kt,
  get_all_dirty_from_scope: xa,
  get_slot_changes: Ba,
  group_outros: an,
  init: ms,
  insert_hydration: B,
  mount_component: Ta,
  noop: ln,
  safe_not_equal: gs,
  set_data: re,
  set_style: Ee,
  space: ae,
  text: N,
  toggle_class: ne,
  transition_in: he,
  transition_out: ke,
  update_slot_base: qa
} = window.__gradio__svelte__internal, { tick: vs } = window.__gradio__svelte__internal, { onDestroy: Ds } = window.__gradio__svelte__internal, { createEventDispatcher: bs } = window.__gradio__svelte__internal, ws = (i) => ({}), yi = (i) => ({}), ys = (i) => ({}), Fi = (i) => ({});
function ki(i, e, t) {
  const n = i.slice();
  return n[40] = e[t], n[42] = t, n;
}
function $i(i, e, t) {
  const n = i.slice();
  return n[40] = e[t], n;
}
function Fs(i) {
  let e, t, n, a, r = (
    /*i18n*/
    i[1]("common.error") + ""
  ), l, o, s;
  t = new ba({
    props: {
      Icon: Ja,
      label: (
        /*i18n*/
        i[1]("common.clear")
      ),
      disabled: !1
    }
  }), t.$on(
    "click",
    /*click_handler*/
    i[32]
  );
  const u = (
    /*#slots*/
    i[30].error
  ), _ = Ea(
    u,
    i,
    /*$$scope*/
    i[29],
    yi
  );
  return {
    c() {
      e = Fe("div"), Ca(t.$$.fragment), n = ae(), a = Fe("span"), l = N(r), o = ae(), _ && _.c(), this.h();
    },
    l(f) {
      e = ye(f, "DIV", { class: !0 });
      var d = we(e);
      $a(t.$$.fragment, d), d.forEach(S), n = ie(f), a = ye(f, "SPAN", { class: !0 });
      var h = we(a);
      l = P(h, r), h.forEach(S), o = ie(f), _ && _.l(f), this.h();
    },
    h() {
      fe(e, "class", "clear-status svelte-17v219f"), fe(a, "class", "error svelte-17v219f");
    },
    m(f, d) {
      B(f, e, d), Ta(t, e, null), B(f, n, d), B(f, a, d), xe(a, l), B(f, o, d), _ && _.m(f, d), s = !0;
    },
    p(f, d) {
      const h = {};
      d[0] & /*i18n*/
      2 && (h.label = /*i18n*/
      f[1]("common.clear")), t.$set(h), (!s || d[0] & /*i18n*/
      2) && r !== (r = /*i18n*/
      f[1]("common.error") + "") && re(l, r), _ && _.p && (!s || d[0] & /*$$scope*/
      536870912) && qa(
        _,
        u,
        f,
        /*$$scope*/
        f[29],
        s ? Ba(
          u,
          /*$$scope*/
          f[29],
          d,
          ws
        ) : xa(
          /*$$scope*/
          f[29]
        ),
        yi
      );
    },
    i(f) {
      s || (he(t.$$.fragment, f), he(_, f), s = !0);
    },
    o(f) {
      ke(t.$$.fragment, f), ke(_, f), s = !1;
    },
    d(f) {
      f && (S(e), S(n), S(a), S(o)), Aa(t), _ && _.d(f);
    }
  };
}
function ks(i) {
  let e, t, n, a, r, l, o, s, u, _ = (
    /*variant*/
    i[8] === "default" && /*show_eta_bar*/
    i[18] && /*show_progress*/
    i[6] === "full" && Ci(i)
  );
  function f(c, v) {
    if (
      /*progress*/
      c[7]
    ) return Es;
    if (
      /*queue_position*/
      c[2] !== null && /*queue_size*/
      c[3] !== void 0 && /*queue_position*/
      c[2] >= 0
    ) return Cs;
    if (
      /*queue_position*/
      c[2] === 0
    ) return $s;
  }
  let d = f(i), h = d && d(i), m = (
    /*timer*/
    i[5] && Si(i)
  );
  const w = [Bs, xs], y = [];
  function E(c, v) {
    return (
      /*last_progress_level*/
      c[15] != null ? 0 : (
        /*show_progress*/
        c[6] === "full" ? 1 : -1
      )
    );
  }
  ~(r = E(i)) && (l = y[r] = w[r](i));
  let p = !/*timer*/
  i[5] && Ii(i);
  return {
    c() {
      _ && _.c(), e = ae(), t = Fe("div"), h && h.c(), n = ae(), m && m.c(), a = ae(), l && l.c(), o = ae(), p && p.c(), s = le(), this.h();
    },
    l(c) {
      _ && _.l(c), e = ie(c), t = ye(c, "DIV", { class: !0 });
      var v = we(t);
      h && h.l(v), n = ie(v), m && m.l(v), v.forEach(S), a = ie(c), l && l.l(c), o = ie(c), p && p.l(c), s = le(), this.h();
    },
    h() {
      fe(t, "class", "progress-text svelte-17v219f"), ne(
        t,
        "meta-text-center",
        /*variant*/
        i[8] === "center"
      ), ne(
        t,
        "meta-text",
        /*variant*/
        i[8] === "default"
      );
    },
    m(c, v) {
      _ && _.m(c, v), B(c, e, v), B(c, t, v), h && h.m(t, null), xe(t, n), m && m.m(t, null), B(c, a, v), ~r && y[r].m(c, v), B(c, o, v), p && p.m(c, v), B(c, s, v), u = !0;
    },
    p(c, v) {
      /*variant*/
      c[8] === "default" && /*show_eta_bar*/
      c[18] && /*show_progress*/
      c[6] === "full" ? _ ? _.p(c, v) : (_ = Ci(c), _.c(), _.m(e.parentNode, e)) : _ && (_.d(1), _ = null), d === (d = f(c)) && h ? h.p(c, v) : (h && h.d(1), h = d && d(c), h && (h.c(), h.m(t, n))), /*timer*/
      c[5] ? m ? m.p(c, v) : (m = Si(c), m.c(), m.m(t, null)) : m && (m.d(1), m = null), (!u || v[0] & /*variant*/
      256) && ne(
        t,
        "meta-text-center",
        /*variant*/
        c[8] === "center"
      ), (!u || v[0] & /*variant*/
      256) && ne(
        t,
        "meta-text",
        /*variant*/
        c[8] === "default"
      );
      let F = r;
      r = E(c), r === F ? ~r && y[r].p(c, v) : (l && (an(), ke(y[F], 1, 1, () => {
        y[F] = null;
      }), nn()), ~r ? (l = y[r], l ? l.p(c, v) : (l = y[r] = w[r](c), l.c()), he(l, 1), l.m(o.parentNode, o)) : l = null), /*timer*/
      c[5] ? p && (an(), ke(p, 1, 1, () => {
        p = null;
      }), nn()) : p ? (p.p(c, v), v[0] & /*timer*/
      32 && he(p, 1)) : (p = Ii(c), p.c(), he(p, 1), p.m(s.parentNode, s));
    },
    i(c) {
      u || (he(l), he(p), u = !0);
    },
    o(c) {
      ke(l), ke(p), u = !1;
    },
    d(c) {
      c && (S(e), S(t), S(a), S(o), S(s)), _ && _.d(c), h && h.d(), m && m.d(), ~r && y[r].d(c), p && p.d(c);
    }
  };
}
function Ci(i) {
  let e, t = `translateX(${/*eta_level*/
  (i[17] || 0) * 100 - 100}%)`;
  return {
    c() {
      e = Fe("div"), this.h();
    },
    l(n) {
      e = ye(n, "DIV", { class: !0 }), we(e).forEach(S), this.h();
    },
    h() {
      fe(e, "class", "eta-bar svelte-17v219f"), Ee(e, "transform", t);
    },
    m(n, a) {
      B(n, e, a);
    },
    p(n, a) {
      a[0] & /*eta_level*/
      131072 && t !== (t = `translateX(${/*eta_level*/
      (n[17] || 0) * 100 - 100}%)`) && Ee(e, "transform", t);
    },
    d(n) {
      n && S(e);
    }
  };
}
function $s(i) {
  let e;
  return {
    c() {
      e = N("processing |");
    },
    l(t) {
      e = P(t, "processing |");
    },
    m(t, n) {
      B(t, e, n);
    },
    p: ln,
    d(t) {
      t && S(e);
    }
  };
}
function Cs(i) {
  let e, t = (
    /*queue_position*/
    i[2] + 1 + ""
  ), n, a, r, l;
  return {
    c() {
      e = N("queue: "), n = N(t), a = N("/"), r = N(
        /*queue_size*/
        i[3]
      ), l = N(" |");
    },
    l(o) {
      e = P(o, "queue: "), n = P(o, t), a = P(o, "/"), r = P(
        o,
        /*queue_size*/
        i[3]
      ), l = P(o, " |");
    },
    m(o, s) {
      B(o, e, s), B(o, n, s), B(o, a, s), B(o, r, s), B(o, l, s);
    },
    p(o, s) {
      s[0] & /*queue_position*/
      4 && t !== (t = /*queue_position*/
      o[2] + 1 + "") && re(n, t), s[0] & /*queue_size*/
      8 && re(
        r,
        /*queue_size*/
        o[3]
      );
    },
    d(o) {
      o && (S(e), S(n), S(a), S(r), S(l));
    }
  };
}
function Es(i) {
  let e, t = kt(
    /*progress*/
    i[7]
  ), n = [];
  for (let a = 0; a < t.length; a += 1)
    n[a] = Ai($i(i, t, a));
  return {
    c() {
      for (let a = 0; a < n.length; a += 1)
        n[a].c();
      e = le();
    },
    l(a) {
      for (let r = 0; r < n.length; r += 1)
        n[r].l(a);
      e = le();
    },
    m(a, r) {
      for (let l = 0; l < n.length; l += 1)
        n[l] && n[l].m(a, r);
      B(a, e, r);
    },
    p(a, r) {
      if (r[0] & /*progress*/
      128) {
        t = kt(
          /*progress*/
          a[7]
        );
        let l;
        for (l = 0; l < t.length; l += 1) {
          const o = $i(a, t, l);
          n[l] ? n[l].p(o, r) : (n[l] = Ai(o), n[l].c(), n[l].m(e.parentNode, e));
        }
        for (; l < n.length; l += 1)
          n[l].d(1);
        n.length = t.length;
      }
    },
    d(a) {
      a && S(e), Sa(n, a);
    }
  };
}
function Ei(i) {
  let e, t = (
    /*p*/
    i[40].unit + ""
  ), n, a, r = " ", l;
  function o(_, f) {
    return (
      /*p*/
      _[40].length != null ? Ss : As
    );
  }
  let s = o(i), u = s(i);
  return {
    c() {
      u.c(), e = ae(), n = N(t), a = N(" | "), l = N(r);
    },
    l(_) {
      u.l(_), e = ie(_), n = P(_, t), a = P(_, " | "), l = P(_, r);
    },
    m(_, f) {
      u.m(_, f), B(_, e, f), B(_, n, f), B(_, a, f), B(_, l, f);
    },
    p(_, f) {
      s === (s = o(_)) && u ? u.p(_, f) : (u.d(1), u = s(_), u && (u.c(), u.m(e.parentNode, e))), f[0] & /*progress*/
      128 && t !== (t = /*p*/
      _[40].unit + "") && re(n, t);
    },
    d(_) {
      _ && (S(e), S(n), S(a), S(l)), u.d(_);
    }
  };
}
function As(i) {
  let e = Oe(
    /*p*/
    i[40].index || 0
  ) + "", t;
  return {
    c() {
      t = N(e);
    },
    l(n) {
      t = P(n, e);
    },
    m(n, a) {
      B(n, t, a);
    },
    p(n, a) {
      a[0] & /*progress*/
      128 && e !== (e = Oe(
        /*p*/
        n[40].index || 0
      ) + "") && re(t, e);
    },
    d(n) {
      n && S(t);
    }
  };
}
function Ss(i) {
  let e = Oe(
    /*p*/
    i[40].index || 0
  ) + "", t, n, a = Oe(
    /*p*/
    i[40].length
  ) + "", r;
  return {
    c() {
      t = N(e), n = N("/"), r = N(a);
    },
    l(l) {
      t = P(l, e), n = P(l, "/"), r = P(l, a);
    },
    m(l, o) {
      B(l, t, o), B(l, n, o), B(l, r, o);
    },
    p(l, o) {
      o[0] & /*progress*/
      128 && e !== (e = Oe(
        /*p*/
        l[40].index || 0
      ) + "") && re(t, e), o[0] & /*progress*/
      128 && a !== (a = Oe(
        /*p*/
        l[40].length
      ) + "") && re(r, a);
    },
    d(l) {
      l && (S(t), S(n), S(r));
    }
  };
}
function Ai(i) {
  let e, t = (
    /*p*/
    i[40].index != null && Ei(i)
  );
  return {
    c() {
      t && t.c(), e = le();
    },
    l(n) {
      t && t.l(n), e = le();
    },
    m(n, a) {
      t && t.m(n, a), B(n, e, a);
    },
    p(n, a) {
      /*p*/
      n[40].index != null ? t ? t.p(n, a) : (t = Ei(n), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(n) {
      n && S(e), t && t.d(n);
    }
  };
}
function Si(i) {
  let e, t = (
    /*eta*/
    i[0] ? `/${/*formatted_eta*/
    i[19]}` : ""
  ), n, a;
  return {
    c() {
      e = N(
        /*formatted_timer*/
        i[20]
      ), n = N(t), a = N("s");
    },
    l(r) {
      e = P(
        r,
        /*formatted_timer*/
        i[20]
      ), n = P(r, t), a = P(r, "s");
    },
    m(r, l) {
      B(r, e, l), B(r, n, l), B(r, a, l);
    },
    p(r, l) {
      l[0] & /*formatted_timer*/
      1048576 && re(
        e,
        /*formatted_timer*/
        r[20]
      ), l[0] & /*eta, formatted_eta*/
      524289 && t !== (t = /*eta*/
      r[0] ? `/${/*formatted_eta*/
      r[19]}` : "") && re(n, t);
    },
    d(r) {
      r && (S(e), S(n), S(a));
    }
  };
}
function xs(i) {
  let e, t;
  return e = new fs({
    props: { margin: (
      /*variant*/
      i[8] === "default"
    ) }
  }), {
    c() {
      Ca(e.$$.fragment);
    },
    l(n) {
      $a(e.$$.fragment, n);
    },
    m(n, a) {
      Ta(e, n, a), t = !0;
    },
    p(n, a) {
      const r = {};
      a[0] & /*variant*/
      256 && (r.margin = /*variant*/
      n[8] === "default"), e.$set(r);
    },
    i(n) {
      t || (he(e.$$.fragment, n), t = !0);
    },
    o(n) {
      ke(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Aa(e, n);
    }
  };
}
function Bs(i) {
  let e, t, n, a, r, l = `${/*last_progress_level*/
  i[15] * 100}%`, o = (
    /*progress*/
    i[7] != null && xi(i)
  );
  return {
    c() {
      e = Fe("div"), t = Fe("div"), o && o.c(), n = ae(), a = Fe("div"), r = Fe("div"), this.h();
    },
    l(s) {
      e = ye(s, "DIV", { class: !0 });
      var u = we(e);
      t = ye(u, "DIV", { class: !0 });
      var _ = we(t);
      o && o.l(_), _.forEach(S), n = ie(u), a = ye(u, "DIV", { class: !0 });
      var f = we(a);
      r = ye(f, "DIV", { class: !0 }), we(r).forEach(S), f.forEach(S), u.forEach(S), this.h();
    },
    h() {
      fe(t, "class", "progress-level-inner svelte-17v219f"), fe(r, "class", "progress-bar svelte-17v219f"), Ee(r, "width", l), fe(a, "class", "progress-bar-wrap svelte-17v219f"), fe(e, "class", "progress-level svelte-17v219f");
    },
    m(s, u) {
      B(s, e, u), xe(e, t), o && o.m(t, null), xe(e, n), xe(e, a), xe(a, r), i[31](r);
    },
    p(s, u) {
      /*progress*/
      s[7] != null ? o ? o.p(s, u) : (o = xi(s), o.c(), o.m(t, null)) : o && (o.d(1), o = null), u[0] & /*last_progress_level*/
      32768 && l !== (l = `${/*last_progress_level*/
      s[15] * 100}%`) && Ee(r, "width", l);
    },
    i: ln,
    o: ln,
    d(s) {
      s && S(e), o && o.d(), i[31](null);
    }
  };
}
function xi(i) {
  let e, t = kt(
    /*progress*/
    i[7]
  ), n = [];
  for (let a = 0; a < t.length; a += 1)
    n[a] = zi(ki(i, t, a));
  return {
    c() {
      for (let a = 0; a < n.length; a += 1)
        n[a].c();
      e = le();
    },
    l(a) {
      for (let r = 0; r < n.length; r += 1)
        n[r].l(a);
      e = le();
    },
    m(a, r) {
      for (let l = 0; l < n.length; l += 1)
        n[l] && n[l].m(a, r);
      B(a, e, r);
    },
    p(a, r) {
      if (r[0] & /*progress_level, progress*/
      16512) {
        t = kt(
          /*progress*/
          a[7]
        );
        let l;
        for (l = 0; l < t.length; l += 1) {
          const o = ki(a, t, l);
          n[l] ? n[l].p(o, r) : (n[l] = zi(o), n[l].c(), n[l].m(e.parentNode, e));
        }
        for (; l < n.length; l += 1)
          n[l].d(1);
        n.length = t.length;
      }
    },
    d(a) {
      a && S(e), Sa(n, a);
    }
  };
}
function Bi(i) {
  let e, t, n, a, r = (
    /*i*/
    i[42] !== 0 && Ts()
  ), l = (
    /*p*/
    i[40].desc != null && Ti(i)
  ), o = (
    /*p*/
    i[40].desc != null && /*progress_level*/
    i[14] && /*progress_level*/
    i[14][
      /*i*/
      i[42]
    ] != null && qi()
  ), s = (
    /*progress_level*/
    i[14] != null && Li(i)
  );
  return {
    c() {
      r && r.c(), e = ae(), l && l.c(), t = ae(), o && o.c(), n = ae(), s && s.c(), a = le();
    },
    l(u) {
      r && r.l(u), e = ie(u), l && l.l(u), t = ie(u), o && o.l(u), n = ie(u), s && s.l(u), a = le();
    },
    m(u, _) {
      r && r.m(u, _), B(u, e, _), l && l.m(u, _), B(u, t, _), o && o.m(u, _), B(u, n, _), s && s.m(u, _), B(u, a, _);
    },
    p(u, _) {
      /*p*/
      u[40].desc != null ? l ? l.p(u, _) : (l = Ti(u), l.c(), l.m(t.parentNode, t)) : l && (l.d(1), l = null), /*p*/
      u[40].desc != null && /*progress_level*/
      u[14] && /*progress_level*/
      u[14][
        /*i*/
        u[42]
      ] != null ? o || (o = qi(), o.c(), o.m(n.parentNode, n)) : o && (o.d(1), o = null), /*progress_level*/
      u[14] != null ? s ? s.p(u, _) : (s = Li(u), s.c(), s.m(a.parentNode, a)) : s && (s.d(1), s = null);
    },
    d(u) {
      u && (S(e), S(t), S(n), S(a)), r && r.d(u), l && l.d(u), o && o.d(u), s && s.d(u);
    }
  };
}
function Ts(i) {
  let e;
  return {
    c() {
      e = N(" /");
    },
    l(t) {
      e = P(t, " /");
    },
    m(t, n) {
      B(t, e, n);
    },
    d(t) {
      t && S(e);
    }
  };
}
function Ti(i) {
  let e = (
    /*p*/
    i[40].desc + ""
  ), t;
  return {
    c() {
      t = N(e);
    },
    l(n) {
      t = P(n, e);
    },
    m(n, a) {
      B(n, t, a);
    },
    p(n, a) {
      a[0] & /*progress*/
      128 && e !== (e = /*p*/
      n[40].desc + "") && re(t, e);
    },
    d(n) {
      n && S(t);
    }
  };
}
function qi(i) {
  let e;
  return {
    c() {
      e = N("-");
    },
    l(t) {
      e = P(t, "-");
    },
    m(t, n) {
      B(t, e, n);
    },
    d(t) {
      t && S(e);
    }
  };
}
function Li(i) {
  let e = (100 * /*progress_level*/
  (i[14][
    /*i*/
    i[42]
  ] || 0)).toFixed(1) + "", t, n;
  return {
    c() {
      t = N(e), n = N("%");
    },
    l(a) {
      t = P(a, e), n = P(a, "%");
    },
    m(a, r) {
      B(a, t, r), B(a, n, r);
    },
    p(a, r) {
      r[0] & /*progress_level*/
      16384 && e !== (e = (100 * /*progress_level*/
      (a[14][
        /*i*/
        a[42]
      ] || 0)).toFixed(1) + "") && re(t, e);
    },
    d(a) {
      a && (S(t), S(n));
    }
  };
}
function zi(i) {
  let e, t = (
    /*p*/
    (i[40].desc != null || /*progress_level*/
    i[14] && /*progress_level*/
    i[14][
      /*i*/
      i[42]
    ] != null) && Bi(i)
  );
  return {
    c() {
      t && t.c(), e = le();
    },
    l(n) {
      t && t.l(n), e = le();
    },
    m(n, a) {
      t && t.m(n, a), B(n, e, a);
    },
    p(n, a) {
      /*p*/
      n[40].desc != null || /*progress_level*/
      n[14] && /*progress_level*/
      n[14][
        /*i*/
        n[42]
      ] != null ? t ? t.p(n, a) : (t = Bi(n), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(n) {
      n && S(e), t && t.d(n);
    }
  };
}
function Ii(i) {
  let e, t, n, a;
  const r = (
    /*#slots*/
    i[30]["additional-loading-text"]
  ), l = Ea(
    r,
    i,
    /*$$scope*/
    i[29],
    Fi
  );
  return {
    c() {
      e = Fe("p"), t = N(
        /*loading_text*/
        i[9]
      ), n = ae(), l && l.c(), this.h();
    },
    l(o) {
      e = ye(o, "P", { class: !0 });
      var s = we(e);
      t = P(
        s,
        /*loading_text*/
        i[9]
      ), s.forEach(S), n = ie(o), l && l.l(o), this.h();
    },
    h() {
      fe(e, "class", "loading svelte-17v219f");
    },
    m(o, s) {
      B(o, e, s), xe(e, t), B(o, n, s), l && l.m(o, s), a = !0;
    },
    p(o, s) {
      (!a || s[0] & /*loading_text*/
      512) && re(
        t,
        /*loading_text*/
        o[9]
      ), l && l.p && (!a || s[0] & /*$$scope*/
      536870912) && qa(
        l,
        r,
        o,
        /*$$scope*/
        o[29],
        a ? Ba(
          r,
          /*$$scope*/
          o[29],
          s,
          ys
        ) : xa(
          /*$$scope*/
          o[29]
        ),
        Fi
      );
    },
    i(o) {
      a || (he(l, o), a = !0);
    },
    o(o) {
      ke(l, o), a = !1;
    },
    d(o) {
      o && (S(e), S(n)), l && l.d(o);
    }
  };
}
function qs(i) {
  let e, t, n, a, r;
  const l = [ks, Fs], o = [];
  function s(u, _) {
    return (
      /*status*/
      u[4] === "pending" ? 0 : (
        /*status*/
        u[4] === "error" ? 1 : -1
      )
    );
  }
  return ~(t = s(i)) && (n = o[t] = l[t](i)), {
    c() {
      e = Fe("div"), n && n.c(), this.h();
    },
    l(u) {
      e = ye(u, "DIV", { class: !0 });
      var _ = we(e);
      n && n.l(_), _.forEach(S), this.h();
    },
    h() {
      fe(e, "class", a = "wrap " + /*variant*/
      i[8] + " " + /*show_progress*/
      i[6] + " svelte-17v219f"), ne(e, "hide", !/*status*/
      i[4] || /*status*/
      i[4] === "complete" || /*show_progress*/
      i[6] === "hidden" || /*status*/
      i[4] == "streaming"), ne(
        e,
        "translucent",
        /*variant*/
        i[8] === "center" && /*status*/
        (i[4] === "pending" || /*status*/
        i[4] === "error") || /*translucent*/
        i[11] || /*show_progress*/
        i[6] === "minimal"
      ), ne(
        e,
        "generating",
        /*status*/
        i[4] === "generating" && /*show_progress*/
        i[6] === "full"
      ), ne(
        e,
        "border",
        /*border*/
        i[12]
      ), Ee(
        e,
        "position",
        /*absolute*/
        i[10] ? "absolute" : "static"
      ), Ee(
        e,
        "padding",
        /*absolute*/
        i[10] ? "0" : "var(--size-8) 0"
      );
    },
    m(u, _) {
      B(u, e, _), ~t && o[t].m(e, null), i[33](e), r = !0;
    },
    p(u, _) {
      let f = t;
      t = s(u), t === f ? ~t && o[t].p(u, _) : (n && (an(), ke(o[f], 1, 1, () => {
        o[f] = null;
      }), nn()), ~t ? (n = o[t], n ? n.p(u, _) : (n = o[t] = l[t](u), n.c()), he(n, 1), n.m(e, null)) : n = null), (!r || _[0] & /*variant, show_progress*/
      320 && a !== (a = "wrap " + /*variant*/
      u[8] + " " + /*show_progress*/
      u[6] + " svelte-17v219f")) && fe(e, "class", a), (!r || _[0] & /*variant, show_progress, status, show_progress*/
      336) && ne(e, "hide", !/*status*/
      u[4] || /*status*/
      u[4] === "complete" || /*show_progress*/
      u[6] === "hidden" || /*status*/
      u[4] == "streaming"), (!r || _[0] & /*variant, show_progress, variant, status, translucent, show_progress*/
      2384) && ne(
        e,
        "translucent",
        /*variant*/
        u[8] === "center" && /*status*/
        (u[4] === "pending" || /*status*/
        u[4] === "error") || /*translucent*/
        u[11] || /*show_progress*/
        u[6] === "minimal"
      ), (!r || _[0] & /*variant, show_progress, status, show_progress*/
      336) && ne(
        e,
        "generating",
        /*status*/
        u[4] === "generating" && /*show_progress*/
        u[6] === "full"
      ), (!r || _[0] & /*variant, show_progress, border*/
      4416) && ne(
        e,
        "border",
        /*border*/
        u[12]
      ), _[0] & /*absolute*/
      1024 && Ee(
        e,
        "position",
        /*absolute*/
        u[10] ? "absolute" : "static"
      ), _[0] & /*absolute*/
      1024 && Ee(
        e,
        "padding",
        /*absolute*/
        u[10] ? "0" : "var(--size-8) 0"
      );
    },
    i(u) {
      r || (he(n), r = !0);
    },
    o(u) {
      ke(n), r = !1;
    },
    d(u) {
      u && S(e), ~t && o[t].d(), i[33](null);
    }
  };
}
var Ls = function(i, e, t, n) {
  function a(r) {
    return r instanceof t ? r : new t(function(l) {
      l(r);
    });
  }
  return new (t || (t = Promise))(function(r, l) {
    function o(_) {
      try {
        u(n.next(_));
      } catch (f) {
        l(f);
      }
    }
    function s(_) {
      try {
        u(n.throw(_));
      } catch (f) {
        l(f);
      }
    }
    function u(_) {
      _.done ? r(_.value) : a(_.value).then(o, s);
    }
    u((n = n.apply(i, e || [])).next());
  });
};
let ft = [], Gt = !1;
const zs = typeof window < "u", La = zs ? window.requestAnimationFrame : (i) => {
};
function Is(i) {
  return Ls(this, arguments, void 0, function* (e, t = !0) {
    if (!(window.__gradio_mode__ === "website" || window.__gradio_mode__ !== "app" && t !== !0)) {
      if (ft.push(e), !Gt) Gt = !0;
      else return;
      yield vs(), La(() => {
        let n = [0, 0];
        for (let a = 0; a < ft.length; a++) {
          const l = ft[a].getBoundingClientRect();
          (a === 0 || l.top + window.scrollY <= n[0]) && (n[0] = l.top + window.scrollY, n[1] = a);
        }
        window.scrollTo({ top: n[0] - 20, behavior: "smooth" }), Gt = !1, ft = [];
      });
    }
  });
}
function Rs(i, e, t) {
  let n, { $$slots: a = {}, $$scope: r } = e;
  const l = bs();
  let { i18n: o } = e, { eta: s = null } = e, { queue_position: u } = e, { queue_size: _ } = e, { status: f } = e, { scroll_to_output: d = !1 } = e, { timer: h = !0 } = e, { show_progress: m = "full" } = e, { message: w = null } = e, { progress: y = null } = e, { variant: E = "default" } = e, { loading_text: p = "Loading..." } = e, { absolute: c = !0 } = e, { translucent: v = !1 } = e, { border: F = !1 } = e, { autoscroll: b } = e, g, k = !1, D = 0, C = 0, x = null, T = null, V = 0, j = null, U, R = null, H = !0;
  const O = () => {
    t(0, s = t(27, x = t(19, $ = null))), t(25, D = performance.now()), t(26, C = 0), k = !0, Y();
  };
  function Y() {
    La(() => {
      t(26, C = (performance.now() - D) / 1e3), k && Y();
    });
  }
  function oe() {
    t(26, C = 0), t(0, s = t(27, x = t(19, $ = null))), k && (k = !1);
  }
  Ds(() => {
    k && oe();
  });
  let $ = null;
  function Z(A) {
    wi[A ? "unshift" : "push"](() => {
      R = A, t(16, R), t(7, y), t(14, j), t(15, U);
    });
  }
  const Le = () => {
    l("clear_status");
  };
  function K(A) {
    wi[A ? "unshift" : "push"](() => {
      g = A, t(13, g);
    });
  }
  return i.$$set = (A) => {
    "i18n" in A && t(1, o = A.i18n), "eta" in A && t(0, s = A.eta), "queue_position" in A && t(2, u = A.queue_position), "queue_size" in A && t(3, _ = A.queue_size), "status" in A && t(4, f = A.status), "scroll_to_output" in A && t(22, d = A.scroll_to_output), "timer" in A && t(5, h = A.timer), "show_progress" in A && t(6, m = A.show_progress), "message" in A && t(23, w = A.message), "progress" in A && t(7, y = A.progress), "variant" in A && t(8, E = A.variant), "loading_text" in A && t(9, p = A.loading_text), "absolute" in A && t(10, c = A.absolute), "translucent" in A && t(11, v = A.translucent), "border" in A && t(12, F = A.border), "autoscroll" in A && t(24, b = A.autoscroll), "$$scope" in A && t(29, r = A.$$scope);
  }, i.$$.update = () => {
    i.$$.dirty[0] & /*eta, old_eta, timer_start, eta_from_start*/
    436207617 && (s === null && t(0, s = x), s != null && x !== s && (t(28, T = (performance.now() - D) / 1e3 + s), t(19, $ = T.toFixed(1)), t(27, x = s))), i.$$.dirty[0] & /*eta_from_start, timer_diff*/
    335544320 && t(17, V = T === null || T <= 0 || !C ? null : Math.min(C / T, 1)), i.$$.dirty[0] & /*progress*/
    128 && y != null && t(18, H = !1), i.$$.dirty[0] & /*progress, progress_level, progress_bar, last_progress_level*/
    114816 && (y != null ? t(14, j = y.map((A) => {
      if (A.index != null && A.length != null)
        return A.index / A.length;
      if (A.progress != null)
        return A.progress;
    })) : t(14, j = null), j ? (t(15, U = j[j.length - 1]), R && (U === 0 ? t(16, R.style.transition = "0", R) : t(16, R.style.transition = "150ms", R))) : t(15, U = void 0)), i.$$.dirty[0] & /*status*/
    16 && (f === "pending" ? O() : oe()), i.$$.dirty[0] & /*el, scroll_to_output, status, autoscroll*/
    20979728 && g && d && (f === "pending" || f === "complete") && Is(g, b), i.$$.dirty[0] & /*status, message*/
    8388624, i.$$.dirty[0] & /*timer_diff*/
    67108864 && t(20, n = C.toFixed(1));
  }, [
    s,
    o,
    u,
    _,
    f,
    h,
    m,
    y,
    E,
    p,
    c,
    v,
    F,
    g,
    j,
    U,
    R,
    V,
    H,
    $,
    n,
    l,
    d,
    w,
    b,
    D,
    C,
    x,
    T,
    r,
    a,
    Z,
    Le,
    K
  ];
}
class Ms extends ps {
  constructor(e) {
    super(), ms(
      this,
      e,
      Rs,
      qs,
      gs,
      {
        i18n: 1,
        eta: 0,
        queue_position: 2,
        queue_size: 3,
        status: 4,
        scroll_to_output: 22,
        timer: 5,
        show_progress: 6,
        message: 23,
        progress: 7,
        variant: 8,
        loading_text: 9,
        absolute: 10,
        translucent: 11,
        border: 12,
        autoscroll: 24
      },
      null,
      [-1, -1]
    );
  }
}
const {
  HtmlTagHydration: Nk,
  SvelteComponent: Hk,
  add_render_callback: jk,
  append_hydration: Gk,
  attr: Uk,
  bubble: Vk,
  check_outros: Zk,
  children: Xk,
  claim_component: Wk,
  claim_element: Yk,
  claim_html_tag: Kk,
  claim_space: Qk,
  claim_text: Jk,
  create_component: e$,
  create_in_transition: t$,
  create_out_transition: n$,
  destroy_component: i$,
  detach: a$,
  element: l$,
  get_svelte_dataset: r$,
  group_outros: o$,
  init: s$,
  insert_hydration: u$,
  listen: c$,
  mount_component: _$,
  run_all: d$,
  safe_not_equal: h$,
  set_data: f$,
  space: p$,
  stop_propagation: m$,
  text: g$,
  toggle_class: v$,
  transition_in: D$,
  transition_out: b$
} = window.__gradio__svelte__internal, { createEventDispatcher: w$, onMount: y$ } = window.__gradio__svelte__internal, {
  SvelteComponent: F$,
  append_hydration: k$,
  attr: $$,
  bubble: C$,
  check_outros: E$,
  children: A$,
  claim_component: S$,
  claim_element: x$,
  claim_space: B$,
  create_animation: T$,
  create_component: q$,
  destroy_component: L$,
  detach: z$,
  element: I$,
  ensure_array_like: R$,
  fix_and_outro_and_destroy_block: M$,
  fix_position: O$,
  group_outros: P$,
  init: N$,
  insert_hydration: H$,
  mount_component: j$,
  noop: G$,
  safe_not_equal: U$,
  set_style: V$,
  space: Z$,
  transition_in: X$,
  transition_out: W$,
  update_keyed_each: Y$
} = window.__gradio__svelte__internal, {
  SvelteComponent: K$,
  attr: Q$,
  children: J$,
  claim_element: eC,
  detach: tC,
  element: nC,
  empty: iC,
  init: aC,
  insert_hydration: lC,
  noop: rC,
  safe_not_equal: oC,
  set_style: sC
} = window.__gradio__svelte__internal, {
  SvelteComponent: Os,
  attr: Ps,
  children: Ns,
  claim_component: Hs,
  claim_element: js,
  create_component: Gs,
  destroy_component: Us,
  detach: Ri,
  element: Vs,
  init: Zs,
  insert_hydration: Xs,
  mount_component: Ws,
  safe_not_equal: Ys,
  toggle_class: Re,
  transition_in: Ks,
  transition_out: Qs
} = window.__gradio__svelte__internal;
function Js(i) {
  let e, t, n;
  return t = new va({
    props: {
      message: Mi(
        /*value*/
        i[0]
      ),
      latex_delimiters: (
        /*latex_delimiters*/
        i[5]
      ),
      sanitize_html: (
        /*sanitize_html*/
        i[3]
      ),
      line_breaks: (
        /*line_breaks*/
        i[4]
      ),
      chatbot: !1
    }
  }), {
    c() {
      e = Vs("div"), Gs(t.$$.fragment), this.h();
    },
    l(a) {
      e = js(a, "DIV", { class: !0 });
      var r = Ns(e);
      Hs(t.$$.fragment, r), r.forEach(Ri), this.h();
    },
    h() {
      Ps(e, "class", "prose svelte-1gecy8w"), Re(
        e,
        "table",
        /*type*/
        i[1] === "table"
      ), Re(
        e,
        "gallery",
        /*type*/
        i[1] === "gallery"
      ), Re(
        e,
        "selected",
        /*selected*/
        i[2]
      );
    },
    m(a, r) {
      Xs(a, e, r), Ws(t, e, null), n = !0;
    },
    p(a, [r]) {
      const l = {};
      r & /*value*/
      1 && (l.message = Mi(
        /*value*/
        a[0]
      )), r & /*latex_delimiters*/
      32 && (l.latex_delimiters = /*latex_delimiters*/
      a[5]), r & /*sanitize_html*/
      8 && (l.sanitize_html = /*sanitize_html*/
      a[3]), r & /*line_breaks*/
      16 && (l.line_breaks = /*line_breaks*/
      a[4]), t.$set(l), (!n || r & /*type*/
      2) && Re(
        e,
        "table",
        /*type*/
        a[1] === "table"
      ), (!n || r & /*type*/
      2) && Re(
        e,
        "gallery",
        /*type*/
        a[1] === "gallery"
      ), (!n || r & /*selected*/
      4) && Re(
        e,
        "selected",
        /*selected*/
        a[2]
      );
    },
    i(a) {
      n || (Ks(t.$$.fragment, a), n = !0);
    },
    o(a) {
      Qs(t.$$.fragment, a), n = !1;
    },
    d(a) {
      a && Ri(e), Us(t);
    }
  };
}
function Mi(i, e = 60) {
  if (!i) return "";
  const t = String(i);
  return t.length <= e ? t : t.slice(0, e) + "...";
}
function eu(i, e, t) {
  let { value: n } = e, { type: a } = e, { selected: r = !1 } = e, { sanitize_html: l } = e, { line_breaks: o } = e, { latex_delimiters: s } = e;
  return i.$$set = (u) => {
    "value" in u && t(0, n = u.value), "type" in u && t(1, a = u.type), "selected" in u && t(2, r = u.selected), "sanitize_html" in u && t(3, l = u.sanitize_html), "line_breaks" in u && t(4, o = u.line_breaks), "latex_delimiters" in u && t(5, s = u.latex_delimiters);
  }, [n, a, r, l, o, s];
}
class uC extends Os {
  constructor(e) {
    super(), Zs(this, e, eu, Js, Ys, {
      value: 0,
      type: 1,
      selected: 2,
      sanitize_html: 3,
      line_breaks: 4,
      latex_delimiters: 5
    });
  }
}
const {
  SvelteComponent: tu,
  assign: nu,
  attr: iu,
  children: au,
  claim_component: rn,
  claim_element: lu,
  claim_space: ru,
  create_component: on,
  destroy_component: sn,
  detach: Ut,
  element: ou,
  get_spread_object: su,
  get_spread_update: uu,
  init: cu,
  insert_hydration: Oi,
  mount_component: un,
  safe_not_equal: _u,
  space: du,
  toggle_class: pt,
  transition_in: cn,
  transition_out: _n
} = window.__gradio__svelte__internal;
function hu(i) {
  let e, t, n, a, r;
  const l = [
    { autoscroll: (
      /*gradio*/
      i[9].autoscroll
    ) },
    { i18n: (
      /*gradio*/
      i[9].i18n
    ) },
    /*loading_status*/
    i[5],
    { variant: "center" }
  ];
  let o = {};
  for (let s = 0; s < l.length; s += 1)
    o = nu(o, l[s]);
  return e = new Ms({ props: o }), e.$on(
    "clear_status",
    /*clear_status_handler*/
    i[19]
  ), a = new ns({
    props: {
      value: (
        /*value*/
        i[3]
      ),
      tooltip: (
        /*tooltip*/
        i[4]
      ),
      elem_classes: (
        /*elem_classes*/
        i[1]
      ),
      visible: (
        /*visible*/
        i[2]
      ),
      rtl: (
        /*rtl*/
        i[6]
      ),
      latex_delimiters: (
        /*latex_delimiters*/
        i[10]
      ),
      sanitize_html: (
        /*sanitize_html*/
        i[7]
      ),
      line_breaks: (
        /*line_breaks*/
        i[8]
      ),
      header_links: (
        /*header_links*/
        i[11]
      ),
      show_copy_button: (
        /*show_copy_button*/
        i[15]
      ),
      loading_status: (
        /*loading_status*/
        i[5]
      ),
      theme_mode: (
        /*theme_mode*/
        i[17]
      )
    }
  }), a.$on(
    "change",
    /*change_handler*/
    i[20]
  ), a.$on(
    "copy",
    /*copy_handler*/
    i[21]
  ), {
    c() {
      on(e.$$.fragment), t = du(), n = ou("div"), on(a.$$.fragment), this.h();
    },
    l(s) {
      rn(e.$$.fragment, s), t = ru(s), n = lu(s, "DIV", { class: !0 });
      var u = au(n);
      rn(a.$$.fragment, u), u.forEach(Ut), this.h();
    },
    h() {
      var s;
      iu(n, "class", "svelte-bohy2l"), pt(
        n,
        "padding",
        /*padding*/
        i[18]
      ), pt(
        n,
        "pending",
        /*loading_status*/
        ((s = i[5]) == null ? void 0 : s.status) === "pending"
      );
    },
    m(s, u) {
      un(e, s, u), Oi(s, t, u), Oi(s, n, u), un(a, n, null), r = !0;
    },
    p(s, u) {
      var d;
      const _ = u & /*gradio, loading_status*/
      544 ? uu(l, [
        u & /*gradio*/
        512 && { autoscroll: (
          /*gradio*/
          s[9].autoscroll
        ) },
        u & /*gradio*/
        512 && { i18n: (
          /*gradio*/
          s[9].i18n
        ) },
        u & /*loading_status*/
        32 && su(
          /*loading_status*/
          s[5]
        ),
        l[3]
      ]) : {};
      e.$set(_);
      const f = {};
      u & /*value*/
      8 && (f.value = /*value*/
      s[3]), u & /*tooltip*/
      16 && (f.tooltip = /*tooltip*/
      s[4]), u & /*elem_classes*/
      2 && (f.elem_classes = /*elem_classes*/
      s[1]), u & /*visible*/
      4 && (f.visible = /*visible*/
      s[2]), u & /*rtl*/
      64 && (f.rtl = /*rtl*/
      s[6]), u & /*latex_delimiters*/
      1024 && (f.latex_delimiters = /*latex_delimiters*/
      s[10]), u & /*sanitize_html*/
      128 && (f.sanitize_html = /*sanitize_html*/
      s[7]), u & /*line_breaks*/
      256 && (f.line_breaks = /*line_breaks*/
      s[8]), u & /*header_links*/
      2048 && (f.header_links = /*header_links*/
      s[11]), u & /*show_copy_button*/
      32768 && (f.show_copy_button = /*show_copy_button*/
      s[15]), u & /*loading_status*/
      32 && (f.loading_status = /*loading_status*/
      s[5]), u & /*theme_mode*/
      131072 && (f.theme_mode = /*theme_mode*/
      s[17]), a.$set(f), (!r || u & /*padding*/
      262144) && pt(
        n,
        "padding",
        /*padding*/
        s[18]
      ), (!r || u & /*loading_status*/
      32) && pt(
        n,
        "pending",
        /*loading_status*/
        ((d = s[5]) == null ? void 0 : d.status) === "pending"
      );
    },
    i(s) {
      r || (cn(e.$$.fragment, s), cn(a.$$.fragment, s), r = !0);
    },
    o(s) {
      _n(e.$$.fragment, s), _n(a.$$.fragment, s), r = !1;
    },
    d(s) {
      s && (Ut(t), Ut(n)), sn(e, s), sn(a);
    }
  };
}
function fu(i) {
  let e, t;
  return e = new bl({
    props: {
      visible: (
        /*visible*/
        i[2]
      ),
      elem_id: (
        /*elem_id*/
        i[0]
      ),
      elem_classes: (
        /*elem_classes*/
        i[1]
      ),
      container: (
        /*container*/
        i[16]
      ),
      allow_overflow: !0,
      overflow_behavior: "auto",
      height: (
        /*height*/
        i[12]
      ),
      min_height: (
        /*min_height*/
        i[13]
      ),
      max_height: (
        /*max_height*/
        i[14]
      ),
      $$slots: { default: [hu] },
      $$scope: { ctx: i }
    }
  }), {
    c() {
      on(e.$$.fragment);
    },
    l(n) {
      rn(e.$$.fragment, n);
    },
    m(n, a) {
      un(e, n, a), t = !0;
    },
    p(n, [a]) {
      const r = {};
      a & /*visible*/
      4 && (r.visible = /*visible*/
      n[2]), a & /*elem_id*/
      1 && (r.elem_id = /*elem_id*/
      n[0]), a & /*elem_classes*/
      2 && (r.elem_classes = /*elem_classes*/
      n[1]), a & /*container*/
      65536 && (r.container = /*container*/
      n[16]), a & /*height*/
      4096 && (r.height = /*height*/
      n[12]), a & /*min_height*/
      8192 && (r.min_height = /*min_height*/
      n[13]), a & /*max_height*/
      16384 && (r.max_height = /*max_height*/
      n[14]), a & /*$$scope, padding, loading_status, value, tooltip, elem_classes, visible, rtl, latex_delimiters, sanitize_html, line_breaks, header_links, show_copy_button, theme_mode, gradio*/
      4624382 && (r.$$scope = { dirty: a, ctx: n }), e.$set(r);
    },
    i(n) {
      t || (cn(e.$$.fragment, n), t = !0);
    },
    o(n) {
      _n(e.$$.fragment, n), t = !1;
    },
    d(n) {
      sn(e, n);
    }
  };
}
function pu(i, e, t) {
  let { elem_id: n = "" } = e, { elem_classes: a = [] } = e, { visible: r = !0 } = e, { value: l = "" } = e, { tooltip: o = null } = e, { loading_status: s } = e, { rtl: u = !1 } = e, { sanitize_html: _ = !0 } = e, { line_breaks: f = !1 } = e, { gradio: d } = e, { latex_delimiters: h } = e, { header_links: m = !1 } = e, { height: w } = e, { min_height: y } = e, { max_height: E } = e, { show_copy_button: p = !1 } = e, { container: c = !1 } = e, { theme_mode: v } = e, { padding: F = !1 } = e;
  const b = () => d.dispatch("clear_status", s), g = () => d.dispatch("change"), k = (D) => d.dispatch("copy", D.detail);
  return i.$$set = (D) => {
    "elem_id" in D && t(0, n = D.elem_id), "elem_classes" in D && t(1, a = D.elem_classes), "visible" in D && t(2, r = D.visible), "value" in D && t(3, l = D.value), "tooltip" in D && t(4, o = D.tooltip), "loading_status" in D && t(5, s = D.loading_status), "rtl" in D && t(6, u = D.rtl), "sanitize_html" in D && t(7, _ = D.sanitize_html), "line_breaks" in D && t(8, f = D.line_breaks), "gradio" in D && t(9, d = D.gradio), "latex_delimiters" in D && t(10, h = D.latex_delimiters), "header_links" in D && t(11, m = D.header_links), "height" in D && t(12, w = D.height), "min_height" in D && t(13, y = D.min_height), "max_height" in D && t(14, E = D.max_height), "show_copy_button" in D && t(15, p = D.show_copy_button), "container" in D && t(16, c = D.container), "theme_mode" in D && t(17, v = D.theme_mode), "padding" in D && t(18, F = D.padding);
  }, [
    n,
    a,
    r,
    l,
    o,
    s,
    u,
    _,
    f,
    d,
    h,
    m,
    w,
    y,
    E,
    p,
    c,
    v,
    F,
    b,
    g,
    k
  ];
}
class cC extends tu {
  constructor(e) {
    super(), cu(this, e, pu, fu, _u, {
      elem_id: 0,
      elem_classes: 1,
      visible: 2,
      value: 3,
      tooltip: 4,
      loading_status: 5,
      rtl: 6,
      sanitize_html: 7,
      line_breaks: 8,
      gradio: 9,
      latex_delimiters: 10,
      header_links: 11,
      height: 12,
      min_height: 13,
      max_height: 14,
      show_copy_button: 15,
      container: 16,
      theme_mode: 17,
      padding: 18
    });
  }
}
export {
  uC as E,
  cC as I,
  ns as M,
  Zn as c,
  By as g
};
