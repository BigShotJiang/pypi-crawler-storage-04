# Copyright 2024-present, Extralit Labs, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from datetime import datetime
from typing import Annotated, Any, Literal, Union
from uuid import UUID

from fastapi import Body
from pydantic import BaseModel, ConfigDict, Field, StrictInt, StrictStr, model_validator

from extralit_server.api.schemas.v1.questions import QuestionName
from extralit_server.enums import ResponseStatus

RESPONSES_BULK_CREATE_MIN_ITEMS = 1
RESPONSES_BULK_CREATE_MAX_ITEMS = 100

SPAN_QUESTION_RESPONSE_VALUE_MAX_ITEMS = 10_000

SPAN_QUESTION_RESPONSE_VALUE_ITEM_START_GREATER_THAN_OR_EQUAL = 0
SPAN_QUESTION_RESPONSE_VALUE_ITEM_END_GREATER_THAN_OR_EQUAL = 1


class RankingQuestionResponseValueItem(BaseModel):
    value: str
    rank: int | None = None


class SpanQuestionResponseValueItem(BaseModel):
    label: str
    start: int = Field(..., ge=SPAN_QUESTION_RESPONSE_VALUE_ITEM_START_GREATER_THAN_OR_EQUAL)
    end: int = Field(..., ge=SPAN_QUESTION_RESPONSE_VALUE_ITEM_END_GREATER_THAN_OR_EQUAL)

    @model_validator(mode="after")
    @classmethod
    def check_start_and_end(cls, instance: "SpanQuestionResponseValueItem") -> "SpanQuestionResponseValueItem":
        start, end = instance.start, instance.end

        if start is not None and end is not None and end <= start:
            raise ValueError("span question response value 'end' must have a value greater than 'start'")

        return instance


RankingQuestionResponseValue = list[RankingQuestionResponseValueItem]
SpanQuestionResponseValue = Annotated[
    list[SpanQuestionResponseValueItem], Field(..., max_length=SPAN_QUESTION_RESPONSE_VALUE_MAX_ITEMS)
]
MultiLabelSelectionQuestionResponseValue = list[str]
RatingQuestionResponseValue = StrictInt
TextAndLabelSelectionQuestionResponseValue = StrictStr
TableQuestionResponseValue = dict[str, Any]

ResponseValueTypes = Union[
    SpanQuestionResponseValue,
    RankingQuestionResponseValue,
    MultiLabelSelectionQuestionResponseValue,
    RatingQuestionResponseValue,
    TextAndLabelSelectionQuestionResponseValue,
    TableQuestionResponseValue,
]


class ResponseValue(BaseModel):
    value: Any


class ResponseValueCreate(BaseModel):
    value: ResponseValueTypes

    model_config = ConfigDict(coerce_numbers_to_str=True)


class ResponseValueUpdate(BaseModel):
    value: ResponseValueTypes

    model_config = ConfigDict(coerce_numbers_to_str=True)


ResponseValues = dict[str, ResponseValue]
ResponseValuesCreate = dict[QuestionName, ResponseValueCreate]
ResponseValuesUpdate = dict[QuestionName, ResponseValueUpdate]


class Response(BaseModel):
    id: UUID
    values: ResponseValues | None = None
    status: ResponseStatus
    record_id: UUID
    user_id: UUID
    inserted_at: datetime
    updated_at: datetime

    model_config = ConfigDict(from_attributes=True)


class ResponseCreate(BaseModel):
    values: ResponseValuesCreate | None = None
    status: ResponseStatus


class ResponseFilterScope(BaseModel):
    entity: Literal["response"]
    question: QuestionName | None = None
    property: Literal["status"] | None = None


class SubmittedResponseUpdate(BaseModel):
    values: ResponseValuesUpdate
    status: Literal[ResponseStatus.submitted]


class DiscardedResponseUpdate(BaseModel):
    values: ResponseValuesUpdate | None = None
    status: Literal[ResponseStatus.discarded]


class DraftResponseUpdate(BaseModel):
    values: ResponseValuesUpdate | None = None
    status: Literal[ResponseStatus.draft]


ResponseUpdate = Annotated[
    SubmittedResponseUpdate | DiscardedResponseUpdate | DraftResponseUpdate,
    Body(..., discriminator="status"),
]


class SubmittedResponseUpsert(BaseModel):
    values: ResponseValuesUpdate
    status: Literal[ResponseStatus.submitted]
    record_id: UUID


class DiscardedResponseUpsert(BaseModel):
    values: ResponseValuesUpdate | None = None
    status: Literal[ResponseStatus.discarded]
    record_id: UUID


class DraftResponseUpsert(BaseModel):
    values: ResponseValuesUpdate | None = None
    status: Literal[ResponseStatus.draft]
    record_id: UUID


ResponseUpsert = Annotated[
    SubmittedResponseUpsert | DiscardedResponseUpsert | DraftResponseUpsert,
    Body(..., discriminator="status"),
]


class ResponsesBulkCreate(BaseModel):
    items: list[ResponseUpsert] = Field(
        ...,
        min_length=RESPONSES_BULK_CREATE_MIN_ITEMS,
        max_length=RESPONSES_BULK_CREATE_MAX_ITEMS,
    )


class ResponseBulkError(BaseModel):
    detail: str


class ResponseBulk(BaseModel):
    item: Response | None = None
    error: ResponseBulkError | None = None


class ResponsesBulk(BaseModel):
    items: list[ResponseBulk]


class UserDraftResponseCreate(BaseModel):
    user_id: UUID
    values: ResponseValuesCreate
    status: Literal[ResponseStatus.draft]


class UserDiscardedResponseCreate(BaseModel):
    user_id: UUID
    values: ResponseValuesCreate | None = None
    status: Literal[ResponseStatus.discarded]


class UserSubmittedResponseCreate(BaseModel):
    user_id: UUID
    values: ResponseValuesCreate
    status: Literal[ResponseStatus.submitted]


UserResponseCreate = Annotated[
    UserSubmittedResponseCreate | UserDraftResponseCreate | UserDiscardedResponseCreate,
    Field(discriminator="status"),
]
