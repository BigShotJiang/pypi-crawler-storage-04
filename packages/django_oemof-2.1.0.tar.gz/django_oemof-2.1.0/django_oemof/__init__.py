"""Init of django_oemof app, holds version"""

VERSION = "2.1.0"
