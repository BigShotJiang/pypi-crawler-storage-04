from setuptools import setup, find_packages

setup(
    name="alphabuilder-signal",
    version='0.2.0',
    packages=find_packages(),
    install_requires = [
        # dependencies
    ],
    entry_points={
        "console_scripts": [
            "alphabuilder-signal = indicators:TechnicalIndicators"
        ],
    },
)