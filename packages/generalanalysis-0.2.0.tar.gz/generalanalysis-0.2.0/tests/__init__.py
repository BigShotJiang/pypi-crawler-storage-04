"""Test suite for the General Analysis SDK."""
