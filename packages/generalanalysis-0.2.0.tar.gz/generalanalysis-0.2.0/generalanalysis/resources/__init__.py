"""Resources for the General Analysis SDK."""
