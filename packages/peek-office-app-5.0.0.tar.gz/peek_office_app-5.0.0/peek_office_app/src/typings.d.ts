/* SystemJS module definition */
declare let module: {
  id: string;
};
