export { ConfigPage } from "./config.page";
