- Enable Stock locations in Inventory > Configuration > Settings
- In order to be able to recompute the putaways, you need to enable it on
  the picking type level.
