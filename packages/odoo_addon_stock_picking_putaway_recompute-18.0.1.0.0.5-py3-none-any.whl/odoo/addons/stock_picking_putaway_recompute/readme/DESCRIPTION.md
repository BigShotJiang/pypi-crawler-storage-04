This module will allow to recompute the destination locations from putaway rules
on the picking operations side.
