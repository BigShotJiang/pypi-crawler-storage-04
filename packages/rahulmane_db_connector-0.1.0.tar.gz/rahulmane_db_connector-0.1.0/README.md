# Simple DB Connector

A simple Python library to quickly establish connections to MySQL, SQLite, and PostgreSQL databases.

## Installation

Install the package using pip:

```bash
pip install simple-db-connector-lib