from setuptools import setup,find_packages

setup(
 name="third_package",
 version="0.1",
 package=find_packages(),
 python_requires=">=3.7",
)