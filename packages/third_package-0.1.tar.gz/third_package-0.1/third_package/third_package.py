class Abc:
    def printfun(self,name):
        return (f"hi hello {name}")