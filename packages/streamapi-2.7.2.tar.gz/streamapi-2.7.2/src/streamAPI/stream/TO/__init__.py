from streamAPI.stream.TO.TerminalOperations import *

del TerminalOperations
