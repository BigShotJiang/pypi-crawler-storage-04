from http import HTTPStatus
from typing import Any, Optional, Union

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.create_api_key_request import CreateAPIKeyRequest
from ...models.create_api_key_response import CreateAPIKeyResponse
from ...models.http_validation_error import HTTPValidationError
from ...types import UNSET, Response, Unset


def _get_kwargs(
  *,
  body: CreateAPIKeyRequest,
  authorization: Union[None, Unset, str] = UNSET,
  auth_token: Union[None, Unset, str] = UNSET,
) -> dict[str, Any]:
  headers: dict[str, Any] = {}
  if not isinstance(authorization, Unset):
    headers["authorization"] = authorization

  cookies = {}
  if auth_token is not UNSET:
    cookies["auth-token"] = auth_token

  _kwargs: dict[str, Any] = {
    "method": "post",
    "url": "/v1/user/api-keys",
    "cookies": cookies,
  }

  _kwargs["json"] = body.to_dict()

  headers["Content-Type"] = "application/json"

  _kwargs["headers"] = headers
  return _kwargs


def _parse_response(
  *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Optional[Union[CreateAPIKeyResponse, HTTPValidationError]]:
  if response.status_code == 201:
    response_201 = CreateAPIKeyResponse.from_dict(response.json())

    return response_201
  if response.status_code == 422:
    response_422 = HTTPValidationError.from_dict(response.json())

    return response_422
  if client.raise_on_unexpected_status:
    raise errors.UnexpectedStatus(response.status_code, response.content)
  else:
    return None


def _build_response(
  *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Response[Union[CreateAPIKeyResponse, HTTPValidationError]]:
  return Response(
    status_code=HTTPStatus(response.status_code),
    content=response.content,
    headers=response.headers,
    parsed=_parse_response(client=client, response=response),
  )


def sync_detailed(
  *,
  client: AuthenticatedClient,
  body: CreateAPIKeyRequest,
  authorization: Union[None, Unset, str] = UNSET,
  auth_token: Union[None, Unset, str] = UNSET,
) -> Response[Union[CreateAPIKeyResponse, HTTPValidationError]]:
  """Create API Key

   Create a new API key for the current user.

  Args:
      authorization (Union[None, Unset, str]):
      auth_token (Union[None, Unset, str]):
      body (CreateAPIKeyRequest): Request model for creating a new API key.

  Raises:
      errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
      httpx.TimeoutException: If the request takes longer than Client.timeout.

  Returns:
      Response[Union[CreateAPIKeyResponse, HTTPValidationError]]
  """

  kwargs = _get_kwargs(
    body=body,
    authorization=authorization,
    auth_token=auth_token,
  )

  response = client.get_httpx_client().request(
    **kwargs,
  )

  return _build_response(client=client, response=response)


def sync(
  *,
  client: AuthenticatedClient,
  body: CreateAPIKeyRequest,
  authorization: Union[None, Unset, str] = UNSET,
  auth_token: Union[None, Unset, str] = UNSET,
) -> Optional[Union[CreateAPIKeyResponse, HTTPValidationError]]:
  """Create API Key

   Create a new API key for the current user.

  Args:
      authorization (Union[None, Unset, str]):
      auth_token (Union[None, Unset, str]):
      body (CreateAPIKeyRequest): Request model for creating a new API key.

  Raises:
      errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
      httpx.TimeoutException: If the request takes longer than Client.timeout.

  Returns:
      Union[CreateAPIKeyResponse, HTTPValidationError]
  """

  return sync_detailed(
    client=client,
    body=body,
    authorization=authorization,
    auth_token=auth_token,
  ).parsed


async def asyncio_detailed(
  *,
  client: AuthenticatedClient,
  body: CreateAPIKeyRequest,
  authorization: Union[None, Unset, str] = UNSET,
  auth_token: Union[None, Unset, str] = UNSET,
) -> Response[Union[CreateAPIKeyResponse, HTTPValidationError]]:
  """Create API Key

   Create a new API key for the current user.

  Args:
      authorization (Union[None, Unset, str]):
      auth_token (Union[None, Unset, str]):
      body (CreateAPIKeyRequest): Request model for creating a new API key.

  Raises:
      errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
      httpx.TimeoutException: If the request takes longer than Client.timeout.

  Returns:
      Response[Union[CreateAPIKeyResponse, HTTPValidationError]]
  """

  kwargs = _get_kwargs(
    body=body,
    authorization=authorization,
    auth_token=auth_token,
  )

  response = await client.get_async_httpx_client().request(**kwargs)

  return _build_response(client=client, response=response)


async def asyncio(
  *,
  client: AuthenticatedClient,
  body: CreateAPIKeyRequest,
  authorization: Union[None, Unset, str] = UNSET,
  auth_token: Union[None, Unset, str] = UNSET,
) -> Optional[Union[CreateAPIKeyResponse, HTTPValidationError]]:
  """Create API Key

   Create a new API key for the current user.

  Args:
      authorization (Union[None, Unset, str]):
      auth_token (Union[None, Unset, str]):
      body (CreateAPIKeyRequest): Request model for creating a new API key.

  Raises:
      errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
      httpx.TimeoutException: If the request takes longer than Client.timeout.

  Returns:
      Union[CreateAPIKeyResponse, HTTPValidationError]
  """

  return (
    await asyncio_detailed(
      client=client,
      body=body,
      authorization=authorization,
      auth_token=auth_token,
    )
  ).parsed
