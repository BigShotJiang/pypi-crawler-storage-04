TOKEN_MESSAGE_REQUERIED = "Henrik token not provided. LanoValoPy will not be able to make some requests to the Henrik API."

USER_AGENT = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36"
CONTENT_TYPE = "application/json"

VALIDATE_DATA_MESSAGE_ERROR = "Invalid response data"