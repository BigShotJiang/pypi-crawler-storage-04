=============================
Peek Platform - Agent Service
=============================

The Peek Agent service is where Peek Apps can run their I/O code. Code that may
require push data to other systems, or pull data from other systems.