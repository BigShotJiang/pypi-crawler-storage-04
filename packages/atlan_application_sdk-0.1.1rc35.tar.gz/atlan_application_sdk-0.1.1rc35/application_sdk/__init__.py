"""
Application SDK for developing applications on the Atlan Platform.
"""

from application_sdk.version import __version__

__all__ = ["__version__"]
