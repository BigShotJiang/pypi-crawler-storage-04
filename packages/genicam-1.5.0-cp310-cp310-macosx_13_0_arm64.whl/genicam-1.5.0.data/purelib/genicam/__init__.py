# Do not modify. This is an auto-generated file.

components = ['1.5.0']

if int('0'):
    # In general, this release should be a patch for the Python Bindings
    # that is created for an urgent case.
    components.append('dev' + '7041')

__version__ = '.'.join(components)
del components
