from .idle_term import print_fancy, paint_line, clear
