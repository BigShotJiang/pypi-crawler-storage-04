__author__ = "Prahlad Yeri"
__email__ = "prahladyeri@yahoo.com"
__copyright__ = "(c) 2019 Prahlad Yeri"

__license__ = "MIT"
__version__ = "1.0.20"
__title__ = 'VTScan'
__description__ = 'Utility to scan for malicious files using the VirusTotal API'
