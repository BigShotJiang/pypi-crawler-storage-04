> ⚠️ **Notice:** This SDK is currently in pre-release alpha state and subject to change.
> To get more info or access to test features check out the
> [Strangeworks Backstage Pass Program](https://strangeworks.com/backstage).

# Strangeworks Braket Extension

Strangeworks Python SDK extension for Braket.

For more information on using the SDK check out the
[Strangeworks-Braket documentation](https://docs.strangeworks.com/quantum/braket).
