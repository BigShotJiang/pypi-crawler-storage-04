from lgtm_ai.base.exceptions import LGTMException


class GitDiffParseError(LGTMException): ...
