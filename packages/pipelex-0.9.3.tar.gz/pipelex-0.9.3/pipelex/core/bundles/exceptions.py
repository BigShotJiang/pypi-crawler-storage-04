class PipelexBundleBlueprintError(Exception):
    pass
