import anvil_downlink_host

if __name__ == '__main__':
    anvil_downlink_host.run_downlink_host()

