def do_exec(code, scope):
    exec code in scope
