
.. _behave:     https://github.com/behave/behave
.. _behave4cmd: https://github.com/behave/behave4cmd
.. _`behave.example`: https://github.com/behave/behave.example

.. _`pytest.fixture`:   https://docs.pytest.org/en/latest/fixture.html
.. _`@pytest.fixture`:  https://docs.pytest.org/en/latest/fixture.html
.. _`scope guard`:      https://en.wikibooks.org/wiki/More_C++_Idioms/Scope_Guard
.. _`C++ scope guard`:  https://en.wikibooks.org/wiki/More_C++_Idioms/Scope_Guard

.. _Cucumber:   https://cucumber.io/
.. _Selenium:   https://docs.seleniumhq.org/

.. _PyCharm:        https://www.jetbrains.com/pycharm/
.. _Eclipse:        https://www.eclipse.org/
.. _VisualStudio:   https://www.visualstudio.com/

.. _`PyCharm BDD`: https://blog.jetbrains.com/pycharm/2014/09/feature-spotlight-behavior-driven-development-in-pycharm/
.. _`Cucumber-Eclipse`: https://cucumber.github.io/cucumber-eclipse/

.. _ctags:      https://ctags.sourceforge.net/
