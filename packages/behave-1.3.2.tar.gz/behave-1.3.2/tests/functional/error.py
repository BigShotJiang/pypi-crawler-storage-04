class SomeError(RuntimeError):
    pass
