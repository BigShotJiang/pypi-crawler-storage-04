"""
Tests for :mod:`behave.model_type` module.
"""

# -- PREPARED:
# from behave.model_type import Status, ScenarioStatus, OuterStatus, FileLocation
import pytest

todo = pytest.mark.todo()


# -----------------------------------------------------------------------------
# TEST SUITE
# -----------------------------------------------------------------------------
@todo
class TestStatus(object):
    pass

@todo
class TestScenarioStatus(object):
    pass

@todo
class TestOuterStatus(object):
    pass

@todo
class TestFileLocation(object):
    pass
