Project Info
===============================================================================

=============== ===================================================================
Category        Hyperlink
=============== ===================================================================
Documentation:  https://behave.readthedocs.io/ for `latest`_ and `stable`_
Download:       https://pypi.python.org/pypi/behave (or: `github archive`_)
Repository:     https://github.com/behave/behave
Issues:         https://github.com/behave/behave/issues
Changelog:      `CHANGES.rst <CHANGES.rst>`_
Newsgroup:      https://groups.google.com/forum/#!forum/behave-users
=============== ===================================================================

.. hint::

    The PyPI version is the latest stable version.
    Otherwise, use the latest stable tag or the "bleeding edge" from Github.

.. _latest: https://behave.readthedocs.io/en/latest/
.. _stable: https://behave.readthedocs.io/en/stable/

.. _`github archive`: https://github.com/behave/behave/tags
