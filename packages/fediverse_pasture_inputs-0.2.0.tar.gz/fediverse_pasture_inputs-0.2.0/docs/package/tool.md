# fediverse_pasture_inputs.tool

::: mkdocs-click
    :module: fediverse_pasture_inputs.__main__
    :prog_name: python -mfediverse_pasture_inputs
    :command: main
    :depth: 2
    :style: table
    :list_subcommands: true

:::fediverse_pasture_inputs.tool
    options:
        show_submodules: true
