# fediverse_pasture_inputs.types

:::fediverse_pasture_inputs.types
