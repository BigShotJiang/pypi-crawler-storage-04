from enum import Enum


class TargetedPart(Enum):
    HEADER = 1
    FOOTER = 2
