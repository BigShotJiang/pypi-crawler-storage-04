from pyfusefilter.pyfusefilter import Xor8, Xor16, Fuse8, Fuse16

VERSION = "1.1.3"
__all__ = ["Xor8", "Xor16", "Fuse8", "Fuse16"]
