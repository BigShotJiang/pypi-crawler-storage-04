This module is intended for backend use only, and extends the
functionality of events to avoid duplicating attendees.

It is designed to work alongside *partner_event* (which is a
dependency), and it is advisable to enable it by clicking on **Create
Partners in registration**; this way it will create new partners or will
match existing ones, but at the same time will avoid creating duplicates
from partners already existing.
