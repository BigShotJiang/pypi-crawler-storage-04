"""Alliance Auth application providing a common backend for managing type prices"""

# pylint: disable = invalid-name
default_app_config = "example.apps.ExampleConfig"

app_name = "AA-Eveprices"
__version__ = "0.1.3"
__url__ = "http://gitlab.com/r0kym/aa-eveprices"
