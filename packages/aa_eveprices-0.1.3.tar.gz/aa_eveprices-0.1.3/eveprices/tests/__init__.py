from .providers.evetycoon import TestEvetycoonProvider
from .providers.fuzzwork import TestFuzzworkProvider
from .providers.janice import TestJanicePriceProvider
from .providers.priceinformation import TestPriceInformation
