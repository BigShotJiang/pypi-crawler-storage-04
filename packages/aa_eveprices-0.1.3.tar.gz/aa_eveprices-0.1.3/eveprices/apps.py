from django.apps import AppConfig


class EvePricesConfig(AppConfig):
    name = "eveprices"
    label = "eveprices"
    verbose_name = "Eve Prices"
