Este módulo permite o envio automático de e-mails de notificação sempre que o status de um documento fiscal é alterado. Ele inclui dois modelos de e-mail pré-configurados:

- Um modelo específico para NFSe
- Um modelo genérico para os demais documentos fiscais

Observação: É importante destacar que funcionalidades semelhantes de notificação podem ser implementadas de forma mais genérica utilizando o módulo automation_oca (disponível no repositório OCA/automation).
