from sage.logic.logic import SymbolicLogic

from sage.logic import propcalc
