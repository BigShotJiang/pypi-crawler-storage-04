"""
GiteeGit - 一个简单的工具，用于将Python代码文件自动发送到GiteeGit

这个库提供了多种方式来自动发送Python代码文件到GiteeGit：
- 装饰器方式：@giteegit_on_run
- 上下文管理器方式：with GiteeGit():
- 手动调用方式：GiteeGit().send_current_file()

使用示例：
    from giteegit import giteegit_on_run, GiteeGit
    
    @giteegit_on_run
    def main():
        print("Hello World")
    
    # 或者
    with GiteeGit():
        print("Hello World")
"""

from .giteegit import (
    GiteeGit,
    giteegit_on_run,
    git,
    giteegit_file,
    auto_giteegit,
    CodeSender,
)

__author__ = "Your Name"
__email__ = "your.email@example.com"

__all__ = [
    "GiteeGit",
    "giteegit_on_run",
    "git", 
    "giteegit_file",
    "auto_giteegit",
    "CodeSender",
    "__version__",
]