# Giteegit

## 快速开始

### 装饰器方式（推荐）

```python
from giteegit import giteegit_on_run

@giteegit_on_run
def main():
    print("Hello, World!")
    # 你的代码逻辑
    
if __name__ == "__main__":
    main()  # 函数执行完后会自动发送当前文件到 GiteeGit
```

### 上下文管理器方式

```python
from giteegit import GiteeGit

with GiteeGit():
    print("Hello, World!")
    # 你的代码逻辑
# 退出 with 块时会自动发送当前文件到 GiteeGit
```

### 手动调用方式

```python
from giteegit import GiteeGit

def main():
    print("Hello, World!")
    # 你的代码逻辑
    
    # 手动发送当前文件
    GiteeGit().send_current_file()

if __name__ == "__main__":
    main()
```

## API 参考

### GiteeGit

主要的发送器类。

```python
class GiteeGit:
    def __init__(self, bot_token: Optional[str] = None, chat_id: Optional[str] = None)
    def send_current_file(self) -> bool
    def send_file(self, file_path: str) -> bool
```

### 便捷函数

- `giteegit_on_run(func)` - 装饰器，函数执行完后发送当前文件
- `git()` - 发送当前运行的文件
- `giteegit_file(file_path)` - 发送指定文件
- `auto_giteegit` - `giteegit_on_run` 的别名
- `CodeSender` - `GiteeGit` 的别名

## 许可证

MIT License
