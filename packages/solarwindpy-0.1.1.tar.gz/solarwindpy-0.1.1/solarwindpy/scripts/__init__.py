"""Helper scripts for SolarWindPy."""
