# Tests package for SolarWindPy
