class BrilcalcError(Exception):
    pass
