from .auto_installer import auto_installer
auto_installer()
from .img import img
from .info import info
from .spacex import spacex
from .search import search
from .apod import apod
from .celestrak import celestrak
from .feedback import feedback
from .wiki import wiki
from .update import update
from .get import get
from .oolit import oolit
from . import api

