"""Hardware module."""

from __future__ import annotations

from .deebot import get_static_device_info

__all__ = ["get_static_device_info"]
