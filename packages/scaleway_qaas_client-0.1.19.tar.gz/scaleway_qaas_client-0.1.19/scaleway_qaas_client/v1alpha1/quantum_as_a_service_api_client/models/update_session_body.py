from collections.abc import Mapping
from typing import Any, TypeVar, Union, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="UpdateSessionBody")


@_attrs_define
class UpdateSessionBody:
    """
    Attributes:
        name (Union[None, Unset, str]): Name of the session.
        max_idle_duration (Union[None, Unset, str]): Maximum idle duration before the session ends. (in seconds)
            Example: 2.5s.
        max_duration (Union[None, Unset, str]): Maximum time before the session ends. (in seconds) Example: 2.5s.
        tags (Union[None, Unset, list[str]]): Tags of the session.
    """

    name: Union[None, Unset, str] = UNSET
    max_idle_duration: Union[None, Unset, str] = UNSET
    max_duration: Union[None, Unset, str] = UNSET
    tags: Union[None, Unset, list[str]] = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name: Union[None, Unset, str]
        if isinstance(self.name, Unset):
            name = UNSET
        else:
            name = self.name

        max_idle_duration: Union[None, Unset, str]
        if isinstance(self.max_idle_duration, Unset):
            max_idle_duration = UNSET
        else:
            max_idle_duration = self.max_idle_duration

        max_duration: Union[None, Unset, str]
        if isinstance(self.max_duration, Unset):
            max_duration = UNSET
        else:
            max_duration = self.max_duration

        tags: Union[None, Unset, list[str]]
        if isinstance(self.tags, Unset):
            tags = UNSET
        elif isinstance(self.tags, list):
            tags = self.tags

        else:
            tags = self.tags

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if name is not UNSET:
            field_dict["name"] = name
        if max_idle_duration is not UNSET:
            field_dict["max_idle_duration"] = max_idle_duration
        if max_duration is not UNSET:
            field_dict["max_duration"] = max_duration
        if tags is not UNSET:
            field_dict["tags"] = tags

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)

        def _parse_name(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        name = _parse_name(d.pop("name", UNSET))

        def _parse_max_idle_duration(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        max_idle_duration = _parse_max_idle_duration(d.pop("max_idle_duration", UNSET))

        def _parse_max_duration(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        max_duration = _parse_max_duration(d.pop("max_duration", UNSET))

        def _parse_tags(data: object) -> Union[None, Unset, list[str]]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                tags_type_0 = cast(list[str], data)

                return tags_type_0
            except:  # noqa: E722
                pass
            return cast(Union[None, Unset, list[str]], data)

        tags = _parse_tags(d.pop("tags", UNSET))

        update_session_body = cls(
            name=name,
            max_idle_duration=max_idle_duration,
            max_duration=max_duration,
            tags=tags,
        )

        update_session_body.additional_properties = d
        return update_session_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
