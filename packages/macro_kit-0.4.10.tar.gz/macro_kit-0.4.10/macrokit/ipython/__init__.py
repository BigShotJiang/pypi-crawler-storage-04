from .magic import register_magic

__all__ = ["register_magic"]