Dataset
=======

Header file: ``<libs/zarr/simple_dataset.hpp>``
`[simple dataset source] <https://github.com/yoctoyotta1024/CLEO/blob/main/libs/zarr/simple_dataset.hpp>`_

(Work in Progress, no doxygen strings yet).

Header file: ``<libs/zarr/collective_dataset.hpp>``
`[collective dataset source] <https://github.com/yoctoyotta1024/CLEO/blob/main/libs/zarr/collective_dataset.hpp>`_

(Work in Progress, no doxygen strings yet).
