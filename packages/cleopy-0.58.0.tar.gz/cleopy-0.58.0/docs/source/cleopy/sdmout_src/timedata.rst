TIMEDATA
========

.. automodule:: cleopy.sdmout_src.timedata
  :members:
