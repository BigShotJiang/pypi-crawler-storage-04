# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl).

from . import models
from .hooks import create_code_equal_to_id, assign_old_sequences
