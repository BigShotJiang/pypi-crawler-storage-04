* Ana Juaristi <anajuarist@avanzosc.es>
* Iker Coranti <ikercoranti@avanzosc.com>
* Oihane Crucelaegui <oihanecrucelaegi@avanzosc.es>
* Alfredo de la Fuente <alfredodelafuente@avanzosc.es>
* Tharathip Chaweewongphan <tharathipc@ecosoft.co.th>
* `Tecnativa <https://www.tecnativa.com>`_:

  * Ernesto Tejeda
  * Pedro M. Baeza
  * Vicent Cubells
