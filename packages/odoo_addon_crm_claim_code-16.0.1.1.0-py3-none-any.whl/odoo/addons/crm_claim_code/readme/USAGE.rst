To use this module, you need to:

* Go to menu **CRM > After Sale > Claims** and create a new claim.
* Enter claim subject and Save it. You must see a new number for this claim.
