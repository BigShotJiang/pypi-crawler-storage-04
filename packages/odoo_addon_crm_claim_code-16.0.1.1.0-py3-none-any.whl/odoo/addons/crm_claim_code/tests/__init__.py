# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl).

from . import test_crm_claim_code
