from evolution.main.server.PredictorServer import PredictorServer

PredictorServer = PredictorServer()