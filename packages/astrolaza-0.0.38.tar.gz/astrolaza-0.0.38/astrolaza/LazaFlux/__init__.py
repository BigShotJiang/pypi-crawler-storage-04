from . import mags,SED



