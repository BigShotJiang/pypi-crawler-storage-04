# Description: Configuration file for the SpatialBound API

BASE_URL = 'https://api.spatialbound.com/v1'
ALLOWED_VIDEO_EXTENSIONS = ['.mp4', '.mov', '.avi']