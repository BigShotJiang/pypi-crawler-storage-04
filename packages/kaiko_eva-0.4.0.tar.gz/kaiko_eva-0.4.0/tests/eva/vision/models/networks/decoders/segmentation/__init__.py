"""Vision segmentation decoders tests."""
