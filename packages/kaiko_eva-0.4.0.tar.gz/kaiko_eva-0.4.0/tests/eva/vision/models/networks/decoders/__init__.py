"""Vision decoders tests."""
