"""Vision datasets tests."""
