"""WSI patch extraction tests."""
