"""WSI module tests."""
