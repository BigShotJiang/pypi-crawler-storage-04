"""Language data tests."""
