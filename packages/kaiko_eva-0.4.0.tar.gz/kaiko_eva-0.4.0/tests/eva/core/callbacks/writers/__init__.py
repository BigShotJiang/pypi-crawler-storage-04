"""Writer callback unit tests."""
