"""eva core tests."""
