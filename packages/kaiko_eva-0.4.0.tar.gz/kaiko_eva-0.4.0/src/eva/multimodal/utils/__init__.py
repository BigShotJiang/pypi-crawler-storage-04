"""Multimodal utilities API."""
