"""
Word文档内容添加MCP服务

提供Word文档内容添加功能的MCP服务器
"""

__version__ = "1.0.0"
__author__ = "Word MCP Services"
__description__ = "Word文档内容添加MCP服务 - 提供文档内容添加相关功能"
