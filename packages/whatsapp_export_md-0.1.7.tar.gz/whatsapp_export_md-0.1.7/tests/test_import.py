def test_import():
    import whatsapp_export_md
    assert hasattr(whatsapp_export_md, "__version__")
