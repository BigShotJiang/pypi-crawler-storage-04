## 8.1.49 (2025-08-19)

### Feat

- add org.apache.poi (#326)

### Refactor

- **org**: correctly implement interfaces (#329)

## 8.1.48.post2 (2025-06-09)

### Feat

- add org.apache.poi (#326)

### Refactor

- **org**: correctly implement interfaces (#329)

## 8.1.48.post1 (2025-05-28)

### Feat

- add org.apache.poi (#326)

## 8.1.48 (2025-04-30)

## 8.1.47 (2025-04-22)

### Feat

- **java**: add ByteArray[In|out]putStream classes to io (#320)
- **java**: add missing classes and arguments (#315)

### Fix

- **ia**: add PyDataSet.getUnderlyingDataset function (#314)
- **system**: update build version

### Refactor

- **ia**: add propertyArrayIndices argument to readRawMultiple (#309)

## 8.1.45.post4 (2025-02-26)

### Feat

- **java**: add missing classes and arguments (#315)

## 8.1.45.post3 (2025-02-24)

### Fix

- **ia**: add PyDataSet.getUnderlyingDataset function (#314)

## 8.1.45.post2 (2025-01-20)

### Fix

- **system**: update build version

## 8.1.45.post1 (2025-01-13)

### Refactor

- **ia**: add propertyArrayIndices argument to readRawMultiple (#309)

## 8.1.45.post4 (2025-02-26)

### Feat

- **java**: add missing classes and arguments (#315)

## 8.1.45.post3 (2025-02-24)

### Fix

- **ia**: add PyDataSet.getUnderlyingDataset function (#314)

## 8.1.45.post2 (2025-01-20)

### Fix

- **system**: update build version

## 8.1.45.post1 (2025-01-13)

### Refactor

- **ia**: add propertyArrayIndices argument to readRawMultiple (#309)

## 8.1.45.post3 (2025-02-24)

### Fix

- **ia**: add PyDataSet.getUnderlyingDataset function (#314)

## 8.1.45.post2 (2025-01-20)

### Fix

- **system**: update build version

## 8.1.45.post1 (2025-01-13)

### Refactor

- **ia**: add propertyArrayIndices argument to readRawMultiple (#309)

## 8.1.45.post2 (2025-01-20)

### Fix

- **system**: update build version

## 8.1.45.post1 (2025-01-13)

### Refactor

- **ia**: add propertyArrayIndices argument to readRawMultiple (#309)

## 8.1.45.post1 (2025-01-13)

### Refactor

- **ia**: add propertyArrayIndices argument to readRawMultiple (#309)

## 8.1.45 (2025-01-08)

## 8.1.44.post1 (2024-11-06)

### Fix

- **ia**: fix AlarmQueryResult method names (#307)
- #306

## 8.1.44.post1 (2024-11-06)

### Fix

- **ia**: fix AlarmQueryResult method names (#307)
- #306

## 8.1.44 (2024-10-23)

## 8.1.43 (2024-08-21)

## 8.1.42 (2024-06-24)

### Fix

- **ia**: inherit from java.util.ArrayList (#286)

## 8.1.41 (2024-05-29)

### Fix

- fix regression found in 8.1.40 (#280)

## 8.1.40 (2024-05-15)

### Feat

- bump to 8.1.40 (#277)

## 8.1.39.post1 (2024-04-30)

### Feat

- **java**: add all Calendar methods (#271)

## 8.1.39.post1 (2024-04-30)

### Feat

- **java**: add all Calendar methods (#271)

## 8.1.39 (2024-04-12)

### Refactor

- update default boolean returns (#267)

## 8.1.38 (2024-03-06)

## 8.1.37.post1 (2024-02-21)

### Refactor

- **ia**: import PyStringMap from org.python.core (#262)

## 8.1.37.post1 (2024-02-21)

### Refactor

- **ia**: import PyStringMap from org.python.core (#262)

## 8.1.37 (2024-02-01)

## 8.1.36.post2 (2024-01-11)

### Fix

- **system**: fix issue when importing system.gui and system.nav (#258)

## 8.1.36.post1 (2024-01-11)

### Feat

- **java**: add io.InputStreamReader and supporting classes (#257)

### Refactor

- **system**: change db.runNamedQuery return type to Any (#256)

## 8.1.36.post2 (2024-01-11)

### Fix

- **system**: fix issue when importing system.gui and system.nav (#258)

## 8.1.36.post1 (2024-01-11)

### Feat

- **java**: add io.InputStreamReader and supporting classes (#257)

### Refactor

- **system**: change db.runNamedQuery return type to Any (#256)

## 8.1.36.post1 (2024-01-11)

### Feat

- **java**: add io.InputStreamReader and supporting classes (#257)

### Refactor

- **system**: change db.runNamedQuery return type to Any (#256)

## 8.1.36 (2024-01-09)

### Refactor

- **dev**: rename thecesrom to coatl (#253)

## 8.1.35 (2023-12-07)

### Fix

- patch remote tag provider issue in 8.1.34 (#249)

## 8.1.34 (2023-11-29)

### Feat

- **system**: add includeShelved parameter to alarm.queryJournal (#248)

## 8.1.33 (2023-10-20)

## 8.1.32 (2023-09-15)

### Feat

- **system**: add Ignition 8.1.32 new features (#231)

## 8.1.31.post1 (2023-08-28)

### Feat

- **system**: add mongodb module (#227)

## 8.1.31.post1 (2023-08-28)

### Feat

- **system**: add mongodb module (#227)

## 8.1.31 (2023-08-20)

### Refactor

- **system**: add kwargs to named query functions (#225)

## 8.1.30.post1 (2023-07-29)

### Fix

- **system**: solve system.tag import error (#223)

## 8.1.30.post1 (2023-07-29)

### Fix

- **system**: solve system.tag import error (#223)

## 8.1.30 (2023-07-14)

### Fix

- **system**: prepare for 8.1.30 (#221)

## 8.1.29 (2023-07-07)

## 8.1.28 (2023-06-02)

### Feat

- **system**: add system.vision.getKeyboardLayouts (#209)
- **system**: add system.project.requestScan (#208)

## 8.1.27 (2023-04-25)

### Refactor

- **ia**: set TagPath as an interface (#195)

## 8.1.26.post2 (2023-04-06)

### Feat

- **system**: add system.utils.globals dictionary (#194)
- **system**: add missing print functions from 8.1.22 (#190)

### Fix

- **ia**: solve cyclic import error (#193)

### Refactor

- **system**: fix types and return types (#189)
- **system**: return AttributeInfo and ReadResult (#188)

## 8.1.26.post2 (2023-04-06)

### Feat

- **system**: add system.utils.globals dictionary (#194)
- **system**: add missing print functions from 8.1.22 (#190)

### Fix

- **ia**: solve cyclic import error (#193)

### Refactor

- **system**: fix types and return types (#189)
- **system**: return AttributeInfo and ReadResult (#188)

## 8.1.26.post1 (2023-04-04)

### Feat

- **system**: add missing print functions from 8.1.22 (#190)

### Refactor

- **system**: fix types and return types (#189)
- **system**: return AttributeInfo and RadResult (#188)

## 8.1.26 (2023-03-26)

## 8.1.25.post5 (2023-03-20)

### Refactor

- **system**: replace BasicDataset with Dataset (#184)

## 8.1.25.post4 (2023-03-09)

### Feat

- **system**: add iec61850 module (#181)

## 8.1.25.post3 (2023-02-23)

## 8.1.24.post4 (2023-02-23)

### Fix

- **javax**: add return type to JPasswordField.getPassword (#176)

## 8.1.25.post2 (2023-02-23)

## 8.1.24.post3 (2023-02-23)

## 8.1.24.post2 (2023-02-23)

### Feat

- **java**: create the String class (#174)
- **javax**: add JPasswordField getText (#172)

### Refactor

- **java**: call super init from Object (#173)
- **system**: change how we extract the version (#171)

## 8.1.25.post1 (2023-02-21)

## 8.1.24.post1 (2023-02-21)

### Feat

- **java**: add GridLayout and JPasswordField (#170)
- **java**: add util.Arrays static class (#167)

## 8.1.25.post5 (2023-03-20)

### Refactor

- **system**: replace BasicDataset with Dataset (#184)

## 8.1.25.post4 (2023-03-09)

### Feat

- **system**: add iec61850 module (#181)

## 8.1.25.post3 (2023-02-23)

## 8.1.24.post4 (2023-02-23)

### Fix

- **javax**: add return type to JPasswordField.getPassword (#176)

## 8.1.25.post2 (2023-02-23)

## 8.1.24.post3 (2023-02-23)

## 8.1.24.post2 (2023-02-23)

### Feat

- **java**: create the String class (#174)
- **javax**: add JPasswordField getText (#172)

### Refactor

- **java**: call super init from Object (#173)
- **system**: change how we extract the version (#171)

## 8.1.25.post1 (2023-02-21)

## 8.1.24.post1 (2023-02-21)

### Feat

- **java**: add GridLayout and JPasswordField (#170)
- **java**: add util.Arrays static class (#167)

## 8.1.25.post4 (2023-03-09)

### Feat

- **system**: add iec61850 module (#181)

## 8.1.25.post3 (2023-02-23)

## 8.1.24.post4 (2023-02-23)

### Fix

- **javax**: add return type to JPasswordField.getPassword (#176)

## 8.1.25.post2 (2023-02-23)

## 8.1.24.post3 (2023-02-23)

## 8.1.24.post2 (2023-02-23)

### Feat

- **java**: create the String class (#174)
- **javax**: add JPasswordField getText (#172)

### Refactor

- **java**: call super init from Object (#173)
- **system**: change how we extract the version (#171)

## 8.1.25.post1 (2023-02-21)

## 8.1.24.post1 (2023-02-21)

### Feat

- **java**: add GridLayout and JPasswordField (#170)
- **java**: add util.Arrays static class (#167)

## 8.1.25.post3 (2023-02-23)

## 8.1.24.post4 (2023-02-23)

### Fix

- **javax**: add return type to JPasswordField.getPassword (#176)

## 8.1.25.post2 (2023-02-23)

## 8.1.24.post3 (2023-02-23)

## 8.1.24.post2 (2023-02-23)

### Feat

- **java**: create the String class (#174)
- **javax**: add JPasswordField getText (#172)

### Refactor

- **java**: call super init from Object (#173)
- **system**: change how we extract the version (#171)

## 8.1.25.post1 (2023-02-21)

## 8.1.24.post1 (2023-02-21)

### Feat

- **java**: add GridLayout and JPasswordField (#170)
- **java**: add util.Arrays static class (#167)

## 8.1.25 (2023-02-15)

## 8.1.24.post4 (2023-02-23)

### Fix

- **javax**: add return type to JPasswordField.getPassword (#176)

## 8.1.25.post2 (2023-02-23)

## 8.1.24.post3 (2023-02-23)

## 8.1.24.post2 (2023-02-23)

### Feat

- **java**: create the String class (#174)
- **javax**: add JPasswordField getText (#172)

### Refactor

- **java**: call super init from Object (#173)
- **system**: change how we extract the version (#171)

## 8.1.25.post1 (2023-02-21)

## 8.1.24.post1 (2023-02-21)

### Feat

- **java**: add GridLayout and JPasswordField (#170)
- **java**: add util.Arrays static class (#167)

## 8.1.25.post2 (2023-02-23)

## 8.1.24.post3 (2023-02-23)

## 8.1.24.post2 (2023-02-23)

### Feat

- **java**: create the String class (#174)
- **javax**: add JPasswordField getText (#172)

### Refactor

- **java**: call super init from Object (#173)
- **system**: change how we extract the version (#171)

## 8.1.25.post1 (2023-02-21)

## 8.1.24.post1 (2023-02-21)

### Feat

- **java**: add GridLayout and JPasswordField (#170)
- **java**: add util.Arrays static class (#167)

## 8.1.25 (2023-02-15)

## 8.1.24.post3 (2023-02-23)

## 8.1.24.post2 (2023-02-23)

### Feat

- **java**: create the String class (#174)
- **javax**: add JPasswordField getText (#172)

### Refactor

- **java**: call super init from Object (#173)
- **system**: change how we extract the version (#171)

## 8.1.25.post1 (2023-02-21)

## 8.1.24.post1 (2023-02-21)

### Feat

- **java**: add GridLayout and JPasswordField (#170)
- **java**: add util.Arrays static class (#167)

## 8.1.25 (2023-02-15)

## 8.1.24.post2 (2023-02-23)

### Feat

- **java**: create the String class (#174)
- **javax**: add JPasswordField getText (#172)

### Refactor

- **java**: call super init from Object (#173)
- **system**: change how we extract the version (#171)

## 8.1.25.post1 (2023-02-21)

## 8.1.24.post1 (2023-02-21)

### Feat

- **java**: add GridLayout and JPasswordField (#170)
- **java**: add util.Arrays static class (#167)

## 8.1.25.post1 (2023-02-21)

## 8.1.24.post1 (2023-02-21)

### Feat

- **java**: add GridLayout and JPasswordField (#170)
- **java**: add util.Arrays static class (#167)

## 8.1.25 (2023-02-15)

## 8.1.24.post1 (2023-02-21)

### Feat

- **java**: add GridLayout and JPasswordField (#170)
- **java**: add util.Arrays static class (#167)

## 8.1.25 (2023-02-15)

## 8.1.24 (2023-01-13)

### Feat

- **system**: add vision module (#149)

### Refactor

- **ci**: simplify ci workflow (#147)

## 8.1.23 (2022-12-14)

### Fix

- create Number type alias (#136)

## 8.1.22.post1 (2022-11-29)

### Fix

- update default boolean returns (#130)

### Refactor

- **ci**: run on ubuntu-20.04 (#129)

## 8.1.22 (2022-11-02)

### Feat

- **system**: allow java.util.Locale objects to be passed in as parameters (#125)

### Refactor

- **org**: update MathIllegalArgumentException __init__ signature (#127)

## 8.1.21.post3 (2022-10-21)

### Fix

- change type hints on __iter__ methods (#119)

## 8.1.21.post2 (2022-10-19)

### Refactor

- improve type hints (#116)
- **ia**: add type hints to DatasetUtilities and WindowUtilities (#115)
- **ia**: add type hint to common.script.abc classes (#114)

## 8.1.21.post1 (2022-10-13)

### Feat

- **ia**: add classes implementing TagPath (#107)
- **ia**: add TagPathParser class (#105)

## 8.1.21 (2022-09-30)

### Feat

- **system**: add new roster functions from 8.1.21 (#99)
- **system**: add util.getModules function (#98)

### Refactor

- use correct typing notation for args and kwargs (#97)

## 8.1.20.post5 (2022-09-21)

### Feat

- **ia**: add LocaleUtils (#94)
- **java**: add java.text.SimpleDateFormat class (#93)

## 8.1.20.post4 (2022-09-13)

### Feat

- **java**: add java.nio Files and Paths (#90)
- **java**: add java.io.IOException (#89)
- **java**: add type hints to all java and javax classes and methods (#83)

### Fix

- **system**: set smtp keyword argument as optional (#86)

## 8.1.20.post3 (2022-08-30)

### Feat

- **ia**: add ApplicationScope class (#82)

## 8.1.20.post2 (2022-08-30)

### Feat

- **system**: add missing `system` constants (#77)

### Fix

- **ia**: accept unicode arg in SProcCall functions (#80)

### Refactor

- **system**: remove class aliases (#78)

## 8.1.20.post1 (2022-08-26)

### Fix

- **system**: accept String arguments for popup position (#74)

## 8.1.20 (2022-08-26)

### Feat

- add toString implementation (#73)
- **ia**: add TypeUtilities under ignition.common (#72)
- **ia**: add PerspectiveModule class (#71)
- **ia**: implement ignition.common.BrowseElement (#70)
- **ia**: add getNodeId() to OPCBrowseElement (#69)
- **java**: improve typing (#63)
- **java**: add functions to awt classes (#62)
- **java**: add type hints to Socket functions (#56)

### Refactor

- return Iterator from iter methods (#61)
- **system**: change type for `tags` argument (#57)

### Perf

- remove unused imports (#59)

## 8.1.19.post4 (2022-08-05)

### Feat

- **ia**: add fields to SprocCall, SprocArg, and SProcArgKey (#53)

### Fix

- **system**: accept instances of Dataset (#52)

## 8.1.19.post3 (2022-08-02)

### Fix

- **ia**: change the return type of dataset columns (#50)

### Refactor

- use java.lang.String for continuation/continuationPoint

## 8.1.19.post2 (2022-08-02)

### Fix

- **system**: fix args and return type of tag.query (#49)

## 8.1.19.post1 (2022-08-01)

### Fix

- **ia**: make class' properties accessible (#48)

### Refactor

- **java**: move classproperty class (#46)

## 8.1.19 (2022-07-29)

### Feat

- **system**: add new perspective and tag functions (#44)
- **system**: add constants to __all__ (#43)
- improve type hints (#39)
- **ia**: add type hints to all PyUser functions (Sourcery refactored) (#38)
- **system**: add db constants to __all__ (#36)

### Fix

- **java**: rollback change on classproperty (#42)
- improve type hinting (#41)

### Refactor

- improve code quality (#32)
- **org**: add TYPE field to PyObject class (#31)

## 8.1.18.post2 (2022-07-09)

### Fix

- **java**: add typing to Java code (#29)

### Refactor

- use java.lang.String (#30)

## 8.1.18.post1 (2022-07-05)

### Feat

- **ia**: implement all LoggerEx functions (#27)

## 8.1.18 (2022-06-20)

### Feat

- **system**: add `readRaw`, `writeRaw` to `bacnet` module (#23)
- **system**: add fields to Results class (#22)

## 8.1.17 (2022-05-13)

### Fix

- **system**: update type hint for `html` arg (#20)

### Refactor

- **system**: update type hint for payload arg

## 8.1.16.post1 (2022-04-08)

### Feat

- **system**: add perspective.authenticationChallenge (#17)

## 8.1.16 (2022-04-06)

### Feat

- **system**: add version argument to httpClient (#16)

### Fix

- **ci**: fix `ci.yml` (#5)

### Refactor

- improve Version comparison logic (#11)
- Sourcery refactored main branch (#1)
- change parent class to Java `Object`

## 8.1.15 (2022-03-02)

### Feat

- add `system.user.getUserSources` function

## 8.1.14 (2022-01-27)

## 8.1.13.post1 (2022-01-20)

### Feat

- **mypy**: update type hinting on `translate`

## 8.1.13 (2021-12-22)

### BREAKING CHANGE

- `system.util.beep()` will print "Beep!" when called
regardless of platform

### Feat

- simplify `beep` code

### Refactor

- move `String` alias to `java.util`
- define ColType as a type alias
- integrate minor changes
- rename argument from pageID to pageId
- change return type to `unicode`

## 8.1.12.post3 (2021-11-29)

### Feat

- add `String` type

## 8.1.12.post2 (2021-11-26)

## 8.1.12.post1 (2021-11-26)

### Fix

- install now requires `typing`

## 8.1.12 (2021-11-23)

### BREAKING CHANGE

- * Python versions below or above 2.7.18 are not supported
* `system.date` and Java's Date are no longer using `datetime` functions
* remove deprecated functions from `system.tag`

### Feat

- add type hints on all system functions
- improve `date.format`
- add symbols to `format` to cover most cases

## 8.1.11 (2021-10-20)

### Feat

- add AlarmEvent, PyAlarmEvent, and PyAlarmEventImpl
- add org.python.core package
- add Iterable Java interface

## 8.1.10.post7 (2021-10-11)

### Feat

- add PrintStream class to java.io package

## 8.1.10.post6 (2021-10-10)

### Feat

- add Java supporting classes
- add fields and implement more methods
- return instance of BasicDataset

### Fix

- PyUser now returns an instance of User

### Refactor

- informal interfaces
- return instance of implementing classes
- switch to informal interfaces
- turn fields into properties

## 8.1.10.post5 (2021-09-24)

### Fix

- remove builtins import statement

## 8.1.10.post4 (2021-09-22)

### Feat

- make code compatible with Python3

## 8.1.10.post3 (2021-09-21)

### Feat

- make PyDataSet iterable

## 8.1.10.post2 (2021-09-20)

### Feat

- add `com` package to `pip` release
- **setup**: disallow installation on Python 3

### Fix

- move `WindowUtilities` to the correct package

### Refactor

- improve code quality
- improve code quality
- add `com` package

## 8.1.10 (2021-09-09)

### Feat

- 8.1.10
- **setup**: add setup.py

### Refactor

- allow any import level for winsound
- add pylint

## 8.1.9 (2021-08-09)

### Feat

- add new OPC-UA functions

## 8.1.7 (2021-06-05)

### Feat

- **release**: 8.1.7
- **ignition**: bump Ignition 8.1.5 -> 8.1.6

### Refactor

- java.util.Date

## 8.1.6 (2021-05-24)

## 8.1.5-fix (2021-05-11)

### Feat

- **pre-commit**: update black 21.5b0 -> 21.5b1
- **pre-commit**: update flake8 3.9.1 -> 3.9.2
- **pre-commit**: update black 21.4b2 -> 21.5b0

### Fix

- add missing parameter to…
- correct typo in docstring

## 8.1.5 (2021-04-28)

### Feat

- add 8.1.5 changes
- **pre-commit**: update black 21.4b1 -> 21.4b2
- **pre-commit**: update black 21.4b0 -> 21.4b1
- **pre-commit**: update black 20.8b1 -> 21.4b0
- **pre-commit**: bump flake8 to 3.9.1
- add toParseableString implementation
- add build number and update all references

## 8.1.4 (2021-04-02)

### Feat

- **perspective**: add getSessionInfo

## 8.1.3 (2021-03-04)

### Feat

- add new arguments to Perspective functions

## 8.1.2 (2021-02-12)

### Feat

- add flake8 and isort pre-commit hooks

## 8.1.1-fix (2021-01-05)

## 8.1.1 (2020-12-09)

## 8.1.0 (2020-11-15)
