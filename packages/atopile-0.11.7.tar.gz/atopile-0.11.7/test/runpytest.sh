#!/bin/bash

pytest -o addopts='' -s --log-cli-level=INFO $@

