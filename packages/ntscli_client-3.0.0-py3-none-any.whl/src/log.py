import logging

LOGGER_NAME = "nts"
logger = logging.getLogger(LOGGER_NAME)
