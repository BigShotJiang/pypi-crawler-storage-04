# dagster-embedded-elt

The docs for `dagster-embedded-elt` can be found
[here](https://docs.dagster.io/integrations/embedded-elt).
