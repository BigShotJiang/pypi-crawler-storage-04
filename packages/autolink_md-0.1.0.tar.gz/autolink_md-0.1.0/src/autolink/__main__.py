from . import terminal_operation

if __name__ == "__main__":
    terminal_operation()
