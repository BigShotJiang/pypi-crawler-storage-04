"""Cligent - Chat Parser Library for parsing AI agent conversation logs."""

__version__ = "0.1.1"
