"""Common, reusable metrics."""

from openbench.metrics.grouped import grouped

__all__ = ["grouped"]
