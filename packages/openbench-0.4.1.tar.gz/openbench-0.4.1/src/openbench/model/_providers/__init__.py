"""OpenBench custom model providers."""
