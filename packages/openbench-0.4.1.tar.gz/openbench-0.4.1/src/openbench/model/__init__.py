"""OpenBench model providers."""
