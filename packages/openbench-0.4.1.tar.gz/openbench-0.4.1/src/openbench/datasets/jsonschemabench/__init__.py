"""JSONSchemaBench dataset module."""

from .jsonschemabench import get_dataset, Compatibility

__all__ = ["get_dataset", "Compatibility"]
