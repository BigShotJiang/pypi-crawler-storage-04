Go to Picking and in Additional Information select the field 'Invoice
State', if choosed 'To be Invoice' should be inform the Fiscal Operation
and the Taxes after Confirm and Tranfer the Picking an button will
appear to 'Create Invoice' with the possibility to create invoice based
in Grouped Pickings.
