from ._pairwise import is_installed, pairwise_distances

__all__ = (
    "is_installed",
    "pairwise_distances",
)
