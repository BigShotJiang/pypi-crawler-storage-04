"""Configuration module for AIMCP."""
