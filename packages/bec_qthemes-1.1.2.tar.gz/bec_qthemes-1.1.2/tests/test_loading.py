if __name__ == "__main__":
    import bec_qthemes

    bec_qthemes.load_palette("dark")
