# `title.toml`

- The `title.toml` file in this directory is pre-populated with the project title we have on record.  
- It is your responsibility to keep this file up to date.

## Validating with GitHub Actions

To ensure that your `title.toml` file is correctly formatted and readable, make sure the `title` GitHub Actions workflow passes successfully.
