"""
Module: 'ucryptolib' on micropython-v1.26.0-esp32-ESP32_GENERIC_C6
"""

# MCU: {'variant': '', 'build': '', 'arch': 'rv32imc', 'port': 'esp32', 'board': 'ESP32_GENERIC_C6', 'board_id': 'ESP32_GENERIC_C6', 'mpy': 'v6.3', 'ver': '1.26.0', 'family': 'micropython', 'cpu': 'ESP32C6', 'version': '1.26.0'}
# Stubber: v1.26.0
from __future__ import annotations
from typing import Any, Final, Generator
from _typeshed import Incomplete

class aes:
    def encrypt(self, *args, **kwargs) -> Incomplete: ...
    def decrypt(self, *args, **kwargs) -> Incomplete: ...
    def __init__(self, *argv, **kwargs) -> None: ...
