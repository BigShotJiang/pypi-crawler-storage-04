1.  Create a new transfer and assign an scheduled date.
2.  Mark the transfer as to-do.
3.  Change the scheduled date.
4.  Original scheduled date is kept unchanged.
