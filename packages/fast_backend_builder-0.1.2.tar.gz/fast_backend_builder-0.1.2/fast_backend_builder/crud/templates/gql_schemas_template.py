import strawberry

'''IMPORTS'''

@strawberry.type
class CRUDQuery():
    pass
    
@strawberry.type
class CRUDMutation():
    pass