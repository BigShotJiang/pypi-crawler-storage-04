from .base import IndexProvider
from .loader import resolve_provider

__all__ = ["IndexProvider", "resolve_provider"]
