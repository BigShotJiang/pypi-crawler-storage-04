"""Core pattern expansion engine."""

from .compiler import PatternCompiler

__all__ = ["PatternCompiler"]
