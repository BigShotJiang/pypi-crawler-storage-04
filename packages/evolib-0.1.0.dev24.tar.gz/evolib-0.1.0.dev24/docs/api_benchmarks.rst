Benchmarkfunctions
===================

.. automodule:: evolib.utils.benchmarks
   :members:
   :undoc-members:
   :show-inheritance:
