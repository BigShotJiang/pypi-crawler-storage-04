Numeric
===================

.. automodule:: evolib.globals.numeric
   :members:
   :undoc-members:
   :show-inheritance:
