# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.2] - 2025-09-02
### Changed
- Revert to treating residues and nucleic acids as ligands

## [0.1] - 2025-08-27
### Added
- Treat residues as PTMs, nucleic acids as ligands
- Publish package on PyPI
