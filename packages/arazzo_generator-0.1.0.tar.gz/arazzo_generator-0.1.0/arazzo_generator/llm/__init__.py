"""LLM integration modules for enhancing workflow generation."""
