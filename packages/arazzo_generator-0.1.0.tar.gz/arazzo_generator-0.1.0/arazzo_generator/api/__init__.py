"""API module for Arazzo generator.

This module provides a REST API interface for the Arazzo generator functionality.
"""
