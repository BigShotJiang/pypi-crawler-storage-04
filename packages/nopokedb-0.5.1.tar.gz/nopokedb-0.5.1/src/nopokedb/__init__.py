"""
NoPokeDB
"""

__version__ = "0.5.1"

from .core import NoPokeDB
