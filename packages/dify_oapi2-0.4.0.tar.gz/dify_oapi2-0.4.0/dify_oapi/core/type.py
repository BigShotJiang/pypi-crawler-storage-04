from typing import TypeVar

from dify_oapi.core.model.base_response import BaseResponse

T = TypeVar("T", bound=BaseResponse)
