from __future__ import annotations

from dify_oapi.core.model.base_response import BaseResponse


class DeleteAnnotationResponse(BaseResponse):
    pass
