from .lexorank_service import LexoRank

__all__ = ["LexoRank"]
