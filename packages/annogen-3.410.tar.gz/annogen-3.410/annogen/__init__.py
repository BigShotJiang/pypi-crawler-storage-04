"""Annotator Generator is an application, not a library.  You can run it with "python -m annogen --help" to see the options."""
