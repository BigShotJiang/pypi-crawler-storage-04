# enode

Developer-friendly & type-safe Python SDK specifically catered to leverage *enode* API.

<div align="left">
    <a href="https://www.speakeasy.com/?utm_source=enode&utm_campaign=python"><img src="https://www.speakeasy.com/assets/badges/built-by-speakeasy.svg" /></a>
    <a href="https://opensource.org/licenses/MIT">
        <img src="https://img.shields.io/badge/License-MIT-blue.svg" style="width: 100px; height: 28px;" />
    </a>
</div>


<br /><br />
> [!IMPORTANT]
> This SDK is not yet ready for production use. To complete setup please follow the steps outlined in your [workspace](https://app.speakeasy.com/org/enode/johan). Delete this section before > publishing to a package manager.

<!-- Start Summary [summary] -->
## Summary

Enode API: The Enode API is designed to make smart charging applications easy to develop. We provide an abstraction layer that reduces the complexity when extracting vehicle data and sending commands to vehicles from a variety of manufacturers.
The API has a RESTful architecture and utilizes OAuth2 authorization.
<!-- End Summary [summary] -->

<!-- Start Table of Contents [toc] -->
## Table of Contents
<!-- $toc-max-depth=2 -->
* [enode](#enode)
  * [SDK Installation](#sdk-installation)
  * [IDE Support](#ide-support)
  * [SDK Example Usage](#sdk-example-usage)
  * [Authentication](#authentication)
  * [Available Resources and Operations](#available-resources-and-operations)
  * [Retries](#retries)
  * [Error Handling](#error-handling)
  * [Server Selection](#server-selection)
  * [Custom HTTP Client](#custom-http-client)
  * [Resource Management](#resource-management)
  * [Debugging](#debugging)
* [Development](#development)
  * [Maturity](#maturity)
  * [Contributions](#contributions)

<!-- End Table of Contents [toc] -->

<!-- Start SDK Installation [installation] -->
## SDK Installation

> [!NOTE]
> **Python version upgrade policy**
>
> Once a Python version reaches its [official end of life date](https://devguide.python.org/versions/), a 3-month grace period is provided for users to upgrade. Following this grace period, the minimum python version supported in the SDK will be updated.

The SDK can be installed with *uv*, *pip*, or *poetry* package managers.

### uv

*uv* is a fast Python package installer and resolver, designed as a drop-in replacement for pip and pip-tools. It's recommended for its speed and modern Python tooling capabilities.

```bash
uv add enode
```

### PIP

*PIP* is the default package installer for Python, enabling easy installation and management of packages from PyPI via the command line.

```bash
pip install enode
```

### Poetry

*Poetry* is a modern tool that simplifies dependency management and package publishing by using a single `pyproject.toml` file to handle project metadata and dependencies.

```bash
poetry add enode
```

### Shell and script usage with `uv`

You can use this SDK in a Python shell with [uv](https://docs.astral.sh/uv/) and the `uvx` command that comes with it like so:

```shell
uvx --from enode python
```

It's also possible to write a standalone Python script without needing to set up a whole project like so:

```python
#!/usr/bin/env -S uv run --script
# /// script
# requires-python = ">=3.9"
# dependencies = [
#     "enode",
# ]
# ///

from enode import Enode

sdk = Enode(
  # SDK arguments
)

# Rest of script here...
```

Once that is saved to a file, you can run it with `uv run script.py` where
`script.py` can be replaced with the actual file name.
<!-- End SDK Installation [installation] -->

<!-- Start IDE Support [idesupport] -->
## IDE Support

### PyCharm

Generally, the SDK will work well with most IDEs out of the box. However, when using PyCharm, you can enjoy much better integration with Pydantic by installing an additional plugin.

- [PyCharm Pydantic Plugin](https://docs.pydantic.dev/latest/integrations/pycharm/)
<!-- End IDE Support [idesupport] -->

<!-- Start SDK Example Usage [usage] -->
## SDK Example Usage

### Example

```python
# Synchronous Example
from enode import Enode, models
import os


with Enode(
    security=models.Security(
        client_id=os.getenv("ENODE_CLIENT_ID", ""),
        client_secret=os.getenv("ENODE_CLIENT_SECRET", ""),
    ),
) as e_client:

    res = e_client.batteries.list(after="MjAyMy0wNy0xOFQxMDowODowMi4zNzNa", before="MjAyMy0wNy0xOFQxMDowODowMi4zNzNa", page_size=50)

    # Handle response
    print(res)
```

</br>

The same SDK client can also be used to make asynchronous requests by importing asyncio.
```python
# Asynchronous Example
import asyncio
from enode import Enode, models
import os

async def main():

    async with Enode(
        security=models.Security(
            client_id=os.getenv("ENODE_CLIENT_ID", ""),
            client_secret=os.getenv("ENODE_CLIENT_SECRET", ""),
        ),
    ) as e_client:

        res = await e_client.batteries.list_async(after="MjAyMy0wNy0xOFQxMDowODowMi4zNzNa", before="MjAyMy0wNy0xOFQxMDowODowMi4zNzNa", page_size=50)

        # Handle response
        print(res)

asyncio.run(main())
```
<!-- End SDK Example Usage [usage] -->

<!-- Start Authentication [security] -->
## Authentication

### Per-Client Security Schemes

This SDK supports the following security scheme globally:

| Name                            | Type   | Scheme                         | Environment Variable                                              |
| ------------------------------- | ------ | ------------------------------ | ----------------------------------------------------------------- |
| `client_id`<br/>`client_secret` | oauth2 | OAuth2 Client Credentials Flow | `ENODE_CLIENT_ID`<br/>`ENODE_CLIENT_SECRET`<br/>`ENODE_TOKEN_URL` |

You can set the security parameters through the `security` optional parameter when initializing the SDK client instance. For example:
```python
from enode import Enode, models
import os


with Enode(
    security=models.Security(
        client_id=os.getenv("ENODE_CLIENT_ID", ""),
        client_secret=os.getenv("ENODE_CLIENT_SECRET", ""),
    ),
) as e_client:

    res = e_client.batteries.list(after="MjAyMy0wNy0xOFQxMDowODowMi4zNzNa", before="MjAyMy0wNy0xOFQxMDowODowMi4zNzNa", page_size=50)

    # Handle response
    print(res)

```
<!-- End Authentication [security] -->

<!-- Start Available Resources and Operations [operations] -->
## Available Resources and Operations

<details open>
<summary>Available methods</summary>

### [batteries](docs/sdks/batteries/README.md)

* [list](docs/sdks/batteries/README.md#list) - List Batteries
* [list_user_batteries](docs/sdks/batteries/README.md#list_user_batteries) - List User Batteries
* [get](docs/sdks/batteries/README.md#get) - Get Battery
* [set_operation_mode](docs/sdks/batteries/README.md#set_operation_mode) - Set Operation Mode for Battery
* [get_action](docs/sdks/batteries/README.md#get_action) - Get Operation Mode Action
* [cancel_action](docs/sdks/batteries/README.md#cancel_action) - Cancel Battery Action
* [refresh_data](docs/sdks/batteries/README.md#refresh_data) - Refresh Battery Data

### [chargers](docs/sdks/chargers/README.md)

* [list](docs/sdks/chargers/README.md#list) - List Chargers
* [list_for_user](docs/sdks/chargers/README.md#list_for_user) - List User Chargers
* [get](docs/sdks/chargers/README.md#get) - Get Charger
* [update](docs/sdks/chargers/README.md#update) - Set location for a charger
* [control_charging](docs/sdks/chargers/README.md#control_charging) - Control Charging
* [set_max_current](docs/sdks/chargers/README.md#set_max_current) - Set Max Current
* [get_action](docs/sdks/chargers/README.md#get_action) - Get Charger Action
* [cancel_action](docs/sdks/chargers/README.md#cancel_action) - Cancel Charger Action
* [refresh_data](docs/sdks/chargers/README.md#refresh_data) - Refresh Charger Data


### [experimental](docs/sdks/experimental/README.md)

* [set_max_current](docs/sdks/experimental/README.md#set_max_current) - Set Max Current

### [hem_systems](docs/sdks/hemsystems/README.md)

* [get_hems_statistics](docs/sdks/hemsystems/README.md#get_hems_statistics) - Get HEMS statistics
* [get_hems_status](docs/sdks/hemsystems/README.md#get_hems_status) - Get HEMS status

### [hems](docs/sdks/hems/README.md)

* [list](docs/sdks/hems/README.md#list) - Get HEMS status

### [hvac](docs/sdks/hvac/README.md)

* [list](docs/sdks/hvac/README.md#list) - List HVAC units
* [update](docs/sdks/hvac/README.md#update) - Set Location for an HVAC unit
* [get_action](docs/sdks/hvac/README.md#get_action) - Get Action
* [list_user_hva_cs](docs/sdks/hvac/README.md#list_user_hva_cs) - List User HVAC units
* [cancel_hvac_action](docs/sdks/hvac/README.md#cancel_hvac_action) - Cancel HVAC Action

### [hvacs](docs/sdks/hvacs/README.md)

* [get](docs/sdks/hvacs/README.md#get) - Get HVAC Unit
* [set_follow_schedule](docs/sdks/hvacs/README.md#set_follow_schedule) - Set HVAC unit to follow device schedule
* [refresh_hint](docs/sdks/hvacs/README.md#refresh_hint) - Refresh HVAC unit data
* [set_permanent_hold](docs/sdks/hvacs/README.md#set_permanent_hold) - Set HVAC unit Mode as Permanent Hold

### [interventions](docs/sdks/interventions/README.md)

* [list](docs/sdks/interventions/README.md#list) - List Interventions
* [get](docs/sdks/interventions/README.md#get) - Get Intervention

### [locations](docs/sdks/locations/README.md)

* [list](docs/sdks/locations/README.md#list) - List Locations
* [list_for_user](docs/sdks/locations/README.md#list_for_user) - List User Locations
* [create](docs/sdks/locations/README.md#create) - Create Location
* [get](docs/sdks/locations/README.md#get) - Get Location
* [delete](docs/sdks/locations/README.md#delete) - Delete Location
* [update](docs/sdks/locations/README.md#update) - Update Location

### [meters](docs/sdks/meters/README.md)

* [get_meter](docs/sdks/meters/README.md#get_meter) - Get Meter
* [refresh_hint](docs/sdks/meters/README.md#refresh_hint) - Refresh meter data
* [get_by_user](docs/sdks/meters/README.md#get_by_user) - List User Meters
* [list](docs/sdks/meters/README.md#list) - List Meters

### [schedules](docs/sdks/schedules/README.md)

* [get_by_user](docs/sdks/schedules/README.md#get_by_user) - List Schedules
* [create](docs/sdks/schedules/README.md#create) - Create Schedule
* [get](docs/sdks/schedules/README.md#get) - Get Schedule
* [update](docs/sdks/schedules/README.md#update) - Update Schedule
* [delete](docs/sdks/schedules/README.md#delete) - Delete Schedule
* [get_status](docs/sdks/schedules/README.md#get_status) - Get Schedule Status

### [service_health](docs/sdks/servicehealth/README.md)

* [list_integrations](docs/sdks/servicehealth/README.md#list_integrations) - List supported vendors per asset type
* [check_charger_vendors](docs/sdks/servicehealth/README.md#check_charger_vendors) - Check Available Charger Vendors
* [get_vehicle_vendors](docs/sdks/servicehealth/README.md#get_vehicle_vendors) - Check Available Vehicle Vendors
* [get_battery_vendors](docs/sdks/servicehealth/README.md#get_battery_vendors) - Check Available Battery Vendors
* [get_inverter_vendors](docs/sdks/servicehealth/README.md#get_inverter_vendors) - Check Available Inverter Vendors
* [get_hvac_vendors](docs/sdks/servicehealth/README.md#get_hvac_vendors) - Check Available Hvac Vendors
* [get_meter_vendors](docs/sdks/servicehealth/README.md#get_meter_vendors) - Check Available Meter Vendors
* [check_readiness](docs/sdks/servicehealth/README.md#check_readiness) - Check Service Readiness

### [solar_inverters](docs/sdks/solarinverters/README.md)

* [list_inverters](docs/sdks/solarinverters/README.md#list_inverters) - List Solar Inverters
* [list_user_inverters](docs/sdks/solarinverters/README.md#list_user_inverters) - List User Solar Inverters
* [get_inverter](docs/sdks/solarinverters/README.md#get_inverter) - Get Solar Inverter
* [refresh_hint](docs/sdks/solarinverters/README.md#refresh_hint) - Refresh Inverter data
* [get_statistics](docs/sdks/solarinverters/README.md#get_statistics) - Get Inverter Statistics

### [statistics](docs/sdks/statistics/README.md)

* [get_charging_sessions](docs/sdks/statistics/README.md#get_charging_sessions) - Get User Statistics on Charging Sessions
* [get_charging](docs/sdks/statistics/README.md#get_charging) - Get User Charging Statistics

### [tariffs](docs/sdks/tariffs/README.md)

* [get](docs/sdks/tariffs/README.md#get) - Get Tariff
* [create](docs/sdks/tariffs/README.md#create) - Create a Tariff
* [link_to_location](docs/sdks/tariffs/README.md#link_to_location) - Link Tariff to Location
* [get_by_location](docs/sdks/tariffs/README.md#get_by_location) - Get Tariff Schedule

### [user_management](docs/sdks/usermanagement/README.md)

* [list](docs/sdks/usermanagement/README.md#list) - List Users
* [get](docs/sdks/usermanagement/README.md#get) - Get User
* [post_users_userid_link](docs/sdks/usermanagement/README.md#post_users_userid_link) - Link User
* [delete_users_userid_authorization](docs/sdks/usermanagement/README.md#delete_users_userid_authorization) - Deauthorize User
* [unlink_user](docs/sdks/usermanagement/README.md#unlink_user) - Unlink User
* [relink_asset](docs/sdks/usermanagement/README.md#relink_asset) - Relink Asset

### [vehicles](docs/sdks/vehicles/README.md)

* [list](docs/sdks/vehicles/README.md#list) - List Vehicles
* [list_for_user](docs/sdks/vehicles/README.md#list_for_user) - List User Vehicles
* [get](docs/sdks/vehicles/README.md#get) - Get Vehicle
* [control_charging](docs/sdks/vehicles/README.md#control_charging) - Control Charging
* [set_max_current](docs/sdks/vehicles/README.md#set_max_current) - Set Max Current
* [get_action](docs/sdks/vehicles/README.md#get_action) - Get Vehicle Action
* [cancel_action](docs/sdks/vehicles/README.md#cancel_action) - Cancel Vehicle Action
* [refresh_hint](docs/sdks/vehicles/README.md#refresh_hint) - Refresh Vehicle Data
* [get_smart_charging_policy](docs/sdks/vehicles/README.md#get_smart_charging_policy) - Get Vehicle Smart Charging Policy
* [update_smart_charging_policy](docs/sdks/vehicles/README.md#update_smart_charging_policy) - Update Vehicle Smart Charging Policy
* [create_smart_override](docs/sdks/vehicles/README.md#create_smart_override) - Create Smart Override
* [end_smart_override](docs/sdks/vehicles/README.md#end_smart_override) - End Smart Override
* [get_smart_charging_status](docs/sdks/vehicles/README.md#get_smart_charging_status) - Get Vehicle Smart Charging Status

### [webhooks](docs/sdks/webhooks/README.md)

* [create](docs/sdks/webhooks/README.md#create) - Create Webhook
* [list](docs/sdks/webhooks/README.md#list) - List Webhooks
* [update](docs/sdks/webhooks/README.md#update) - Update Webhook
* [get](docs/sdks/webhooks/README.md#get) - Get Webhook
* [delete](docs/sdks/webhooks/README.md#delete) - Delete Webhook
* [test](docs/sdks/webhooks/README.md#test) - Test Webhook

</details>
<!-- End Available Resources and Operations [operations] -->

<!-- Start Retries [retries] -->
## Retries

Some of the endpoints in this SDK support retries. If you use the SDK without any configuration, it will fall back to the default retry strategy provided by the API. However, the default retry strategy can be overridden on a per-operation basis, or across the entire SDK.

To change the default retry strategy for a single API call, simply provide a `RetryConfig` object to the call:
```python
from enode import Enode, models
from enode.utils import BackoffStrategy, RetryConfig
import os


with Enode(
    security=models.Security(
        client_id=os.getenv("ENODE_CLIENT_ID", ""),
        client_secret=os.getenv("ENODE_CLIENT_SECRET", ""),
    ),
) as e_client:

    res = e_client.batteries.list(after="MjAyMy0wNy0xOFQxMDowODowMi4zNzNa", before="MjAyMy0wNy0xOFQxMDowODowMi4zNzNa", page_size=50,
        RetryConfig("backoff", BackoffStrategy(1, 50, 1.1, 100), False))

    # Handle response
    print(res)

```

If you'd like to override the default retry strategy for all operations that support retries, you can use the `retry_config` optional parameter when initializing the SDK:
```python
from enode import Enode, models
from enode.utils import BackoffStrategy, RetryConfig
import os


with Enode(
    retry_config=RetryConfig("backoff", BackoffStrategy(1, 50, 1.1, 100), False),
    security=models.Security(
        client_id=os.getenv("ENODE_CLIENT_ID", ""),
        client_secret=os.getenv("ENODE_CLIENT_SECRET", ""),
    ),
) as e_client:

    res = e_client.batteries.list(after="MjAyMy0wNy0xOFQxMDowODowMi4zNzNa", before="MjAyMy0wNy0xOFQxMDowODowMi4zNzNa", page_size=50)

    # Handle response
    print(res)

```
<!-- End Retries [retries] -->

<!-- Start Error Handling [errors] -->
## Error Handling

[`EnodeError`](./src/enode/errors/enodeerror.py) is the base class for all HTTP error responses. It has the following properties:

| Property           | Type             | Description                                                                             |
| ------------------ | ---------------- | --------------------------------------------------------------------------------------- |
| `err.message`      | `str`            | Error message                                                                           |
| `err.status_code`  | `int`            | HTTP response status code eg `404`                                                      |
| `err.headers`      | `httpx.Headers`  | HTTP response headers                                                                   |
| `err.body`         | `str`            | HTTP body. Can be empty string if no body is returned.                                  |
| `err.raw_response` | `httpx.Response` | Raw HTTP response                                                                       |
| `err.data`         |                  | Optional. Some errors may contain structured data. [See Error Classes](#error-classes). |

### Example
```python
from enode import Enode, errors, models
import os


with Enode(
    security=models.Security(
        client_id=os.getenv("ENODE_CLIENT_ID", ""),
        client_secret=os.getenv("ENODE_CLIENT_SECRET", ""),
    ),
) as e_client:
    res = None
    try:

        res = e_client.batteries.set_operation_mode(battery_id="54d827e1-8355-4fed-97b5-55940d1d09ba", operation_mode=models.SetBatteryOperationModePayloadOperationMode.IMPORT_FOCUS)

        # Handle response
        print(res)


    except errors.EnodeError as e:
        # The base class for HTTP error responses
        print(e.message)
        print(e.status_code)
        print(e.body)
        print(e.headers)
        print(e.raw_response)

        # Depending on the method different errors may be thrown
        if isinstance(e, errors.ProblemError):
            print(e.data.type)  # str
            print(e.data.title)  # str
            print(e.data.detail)  # str
            print(e.data.issues)  # Optional[List[models.ProblemIssue]]
```

### Error Classes
**Primary error:**
* [`EnodeError`](./src/enode/errors/enodeerror.py): The base class for HTTP error responses.

<details><summary>Less common errors (17)</summary>

<br />

**Network errors:**
* [`httpx.RequestError`](https://www.python-httpx.org/exceptions/#httpx.RequestError): Base class for request errors.
    * [`httpx.ConnectError`](https://www.python-httpx.org/exceptions/#httpx.ConnectError): HTTP client was unable to make a request to a server.
    * [`httpx.TimeoutException`](https://www.python-httpx.org/exceptions/#httpx.TimeoutException): HTTP request timed out.


**Inherit from [`EnodeError`](./src/enode/errors/enodeerror.py)**:
* [`ProblemError`](./src/enode/errors/problemerror.py): Standard Problem Error. Applicable to 13 of 91 methods.*
* [`WebhookNotFoundProblemError`](./src/enode/errors/webhooknotfoundproblemerror.py): Webhook not found problem error. Status code `404`. Applicable to 4 of 91 methods.*
* [`ChargeActionError`](./src/enode/errors/chargeactionerror.py): Successful. Status code `409`. Applicable to 2 of 91 methods.*
* [`GetInverterStatisticsBadRequestError`](./src/enode/errors/getinverterstatisticsbadrequesterror.py): Invalid date input. Status code `400`. Applicable to 1 of 91 methods.*
* [`UpdateVehicleSmartChargingPolicyBadRequestError`](./src/enode/errors/updatevehiclesmartchargingpolicybadrequesterror.py): Various Bad Request errors. Title and detail can vary. Status code `400`. Applicable to 1 of 91 methods.*
* [`WebhookNotValidProblemError`](./src/enode/errors/webhooknotvalidproblemerror.py): Webhook input is not valid. Status code `400`. Applicable to 1 of 91 methods.*
* [`ConnectionsLimitReachedProblemError`](./src/enode/errors/connectionslimitreachedproblemerror.py): Connections limit reached. Status code `403`. Applicable to 1 of 91 methods.*
* [`NotFoundError`](./src/enode/errors/notfounderror.py): Inverter not found. Status code `404`. Applicable to 1 of 91 methods.*
* [`BatteryError`](./src/enode/errors/batteryerror.py): Action already in a resolved state and can therefore not be cancelled. Status code `409`. Applicable to 1 of 91 methods.*
* [`MaxCurrentActionError`](./src/enode/errors/maxcurrentactionerror.py): Successful. Status code `409`. Applicable to 1 of 91 methods.*
* [`HvacActionPermanentHoldError`](./src/enode/errors/hvacactionpermanentholderror.py): Successful. Status code `409`. Applicable to 1 of 91 methods.*
* [`HvacActionFollowScheduleError`](./src/enode/errors/hvacactionfollowscheduleerror.py): Successful. Status code `409`. Applicable to 1 of 91 methods.*
* [`ResponseValidationError`](./src/enode/errors/responsevalidationerror.py): Type mismatch between the response data and the expected Pydantic model. Provides access to the Pydantic validation error via the `cause` attribute.

</details>

\* Check [the method documentation](#available-resources-and-operations) to see if the error is applicable.
<!-- End Error Handling [errors] -->

<!-- Start Server Selection [server] -->
## Server Selection

### Override Server URL Per-Client

The default server can be overridden globally by passing a URL to the `server_url: str` optional parameter when initializing the SDK client instance. For example:
```python
from enode import Enode, models
import os


with Enode(
    server_url="https://enode-api.production.enode.io",
    security=models.Security(
        client_id=os.getenv("ENODE_CLIENT_ID", ""),
        client_secret=os.getenv("ENODE_CLIENT_SECRET", ""),
    ),
) as e_client:

    res = e_client.batteries.list(after="MjAyMy0wNy0xOFQxMDowODowMi4zNzNa", before="MjAyMy0wNy0xOFQxMDowODowMi4zNzNa", page_size=50)

    # Handle response
    print(res)

```
<!-- End Server Selection [server] -->

<!-- Start Custom HTTP Client [http-client] -->
## Custom HTTP Client

The Python SDK makes API calls using the [httpx](https://www.python-httpx.org/) HTTP library.  In order to provide a convenient way to configure timeouts, cookies, proxies, custom headers, and other low-level configuration, you can initialize the SDK client with your own HTTP client instance.
Depending on whether you are using the sync or async version of the SDK, you can pass an instance of `HttpClient` or `AsyncHttpClient` respectively, which are Protocol's ensuring that the client has the necessary methods to make API calls.
This allows you to wrap the client with your own custom logic, such as adding custom headers, logging, or error handling, or you can just pass an instance of `httpx.Client` or `httpx.AsyncClient` directly.

For example, you could specify a header for every request that this sdk makes as follows:
```python
from enode import Enode
import httpx

http_client = httpx.Client(headers={"x-custom-header": "someValue"})
s = Enode(client=http_client)
```

or you could wrap the client with your own custom logic:
```python
from enode import Enode
from enode.httpclient import AsyncHttpClient
import httpx

class CustomClient(AsyncHttpClient):
    client: AsyncHttpClient

    def __init__(self, client: AsyncHttpClient):
        self.client = client

    async def send(
        self,
        request: httpx.Request,
        *,
        stream: bool = False,
        auth: Union[
            httpx._types.AuthTypes, httpx._client.UseClientDefault, None
        ] = httpx.USE_CLIENT_DEFAULT,
        follow_redirects: Union[
            bool, httpx._client.UseClientDefault
        ] = httpx.USE_CLIENT_DEFAULT,
    ) -> httpx.Response:
        request.headers["Client-Level-Header"] = "added by client"

        return await self.client.send(
            request, stream=stream, auth=auth, follow_redirects=follow_redirects
        )

    def build_request(
        self,
        method: str,
        url: httpx._types.URLTypes,
        *,
        content: Optional[httpx._types.RequestContent] = None,
        data: Optional[httpx._types.RequestData] = None,
        files: Optional[httpx._types.RequestFiles] = None,
        json: Optional[Any] = None,
        params: Optional[httpx._types.QueryParamTypes] = None,
        headers: Optional[httpx._types.HeaderTypes] = None,
        cookies: Optional[httpx._types.CookieTypes] = None,
        timeout: Union[
            httpx._types.TimeoutTypes, httpx._client.UseClientDefault
        ] = httpx.USE_CLIENT_DEFAULT,
        extensions: Optional[httpx._types.RequestExtensions] = None,
    ) -> httpx.Request:
        return self.client.build_request(
            method,
            url,
            content=content,
            data=data,
            files=files,
            json=json,
            params=params,
            headers=headers,
            cookies=cookies,
            timeout=timeout,
            extensions=extensions,
        )

s = Enode(async_client=CustomClient(httpx.AsyncClient()))
```
<!-- End Custom HTTP Client [http-client] -->

<!-- Start Resource Management [resource-management] -->
## Resource Management

The `Enode` class implements the context manager protocol and registers a finalizer function to close the underlying sync and async HTTPX clients it uses under the hood. This will close HTTP connections, release memory and free up other resources held by the SDK. In short-lived Python programs and notebooks that make a few SDK method calls, resource management may not be a concern. However, in longer-lived programs, it is beneficial to create a single SDK instance via a [context manager][context-manager] and reuse it across the application.

[context-manager]: https://docs.python.org/3/reference/datamodel.html#context-managers

```python
from enode import Enode, models
import os
def main():

    with Enode(
        security=models.Security(
            client_id=os.getenv("ENODE_CLIENT_ID", ""),
            client_secret=os.getenv("ENODE_CLIENT_SECRET", ""),
        ),
    ) as e_client:
        # Rest of application here...


# Or when using async:
async def amain():

    async with Enode(
        security=models.Security(
            client_id=os.getenv("ENODE_CLIENT_ID", ""),
            client_secret=os.getenv("ENODE_CLIENT_SECRET", ""),
        ),
    ) as e_client:
        # Rest of application here...
```
<!-- End Resource Management [resource-management] -->

<!-- Start Debugging [debug] -->
## Debugging

You can setup your SDK to emit debug logs for SDK requests and responses.

You can pass your own logger class directly into your SDK.
```python
from enode import Enode
import logging

logging.basicConfig(level=logging.DEBUG)
s = Enode(debug_logger=logging.getLogger("enode"))
```

You can also enable a default debug logger by setting an environment variable `ENODE_DEBUG` to true.
<!-- End Debugging [debug] -->

<!-- Placeholder for Future Speakeasy SDK Sections -->

# Development

## Maturity

This SDK is in beta, and there may be breaking changes between versions without a major version update. Therefore, we recommend pinning usage
to a specific package version. This way, you can install the same version each time without breaking changes unless you are intentionally
looking for the latest version.

## Contributions

While we value open-source contributions to this SDK, this library is generated programmatically. Any manual changes added to internal files will be overwritten on the next generation. 
We look forward to hearing your feedback. Feel free to open a PR or an issue with a proof of concept and we'll do our best to include it in a future release. 

### SDK Created by [Speakeasy](https://www.speakeasy.com/?utm_source=enode&utm_campaign=python)
