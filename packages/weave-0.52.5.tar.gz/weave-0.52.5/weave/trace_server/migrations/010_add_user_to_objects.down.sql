ALTER TABLE object_versions
    DROP COLUMN wb_user_id;

ALTER TABLE object_versions_stats
    DROP COLUMN wb_user_id;
