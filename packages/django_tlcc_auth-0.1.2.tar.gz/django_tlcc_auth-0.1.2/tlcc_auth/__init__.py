
__version__ = "0.1.1"

def get_version():
    return __version__
