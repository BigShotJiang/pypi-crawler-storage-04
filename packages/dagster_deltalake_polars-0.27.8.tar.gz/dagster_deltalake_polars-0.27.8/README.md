# dagster-deltalake-polars

The docs for `dagster-deltalake-polars` can be found
[here](https://docs.dagster.io/api/python-api/libraries/dagster-deltalake-polars).
