from .base_repository import BaseRepository

__all__ = ["BaseRepository"]