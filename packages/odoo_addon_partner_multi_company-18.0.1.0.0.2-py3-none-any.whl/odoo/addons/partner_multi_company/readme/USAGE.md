On the partner form view, go to the "Sales & Purchases" tab, and put the
companies in which you want to use that partner. If none is selected,
the partner will be visible in all of them. The default value is the
current one.
