#!/bin/bash

echo "A simple test"
