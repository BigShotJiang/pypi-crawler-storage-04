# nilla net

dependencies
- CuPy must be pre-installed on your system.

installation

`
pip3 install nillanet
`

read documentation at
- [github.io](https://j-s-135.github.io/nillanet)

disclaimer
- Nilla net is not designed for production. It was built for small neural nets for the purpose of experimentation. We are not responsible for problems resulting from the use of nilla net. By using nilla net, you implicitly agree to these terms.
