MsgTools
========

Travis-CI Build Status: [![Build Status](https://travis-ci.org/MilesEngineering/MsgTools.svg?branch=master)](https://travis-ci.org/MilesEngineering/MsgTools.svg?branch=master)

Message Tools for embedded systems

The entirety of this project is dual licensed under LGPLv2 and a commercial license.  Read http://en.wikipedia.org/wiki/Multi-licensing#Single-Vendor_Commercial_Open_Source_Business_Model for general information on dual licensing.  Contact Miles Gazic (miles.gazic@gmail.com) to obtain a commercial license.

All contributors to this project must assign copyright of their additions/modifications to Miles Gazic before contributing.

See further documentation in the [GitHub Wiki](https://github.com/MilesEngineering/MsgTools/wiki) or the Docs directory.
