# Recommended FineCode preset for Python projects
