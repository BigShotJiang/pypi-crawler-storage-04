# Relocated jupyter notebooks

Jupyter notebooks from current folder have been relocated to [pyspedas_example](https://github.com/spedas/pyspedas_examples) project.

You can find the notebooks by the following link:
[https://github.com/spedas/pyspedas_examples/tree/mth5/pyspedas_examples/notebooks/mth5](https://github.com/spedas/pyspedas_examples/tree/mth5/pyspedas_examples/notebooks/mth5)

# The python scripts

The Python scripts in this folder are basic examples of MTH5. We strongly encourage you to check the Jupyter notebooks specified above.