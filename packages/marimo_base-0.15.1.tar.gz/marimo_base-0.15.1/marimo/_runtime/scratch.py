# Copyright 2024 Marimo. All rights reserved.
from __future__ import annotations

from marimo._types.ids import CellId_t

SCRATCH_CELL_ID = CellId_t("__scratch__")
