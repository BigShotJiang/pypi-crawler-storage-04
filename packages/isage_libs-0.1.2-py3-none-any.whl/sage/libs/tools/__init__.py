"""
SAGE - Stream Analysis and Graph Engine
智能流分析和图计算引擎
"""

__version__ = "0.1.1"
__author__ = "IntelliStream"
__email__ = "intellistream@outlook.com"