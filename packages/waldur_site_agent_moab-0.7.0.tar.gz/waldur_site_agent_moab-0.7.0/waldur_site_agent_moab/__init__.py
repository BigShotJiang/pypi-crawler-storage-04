"""Module for MOAB-related functions and classes."""
