from enum import Enum


class GeneratorVersion(str, Enum):
    V1 = "V1"
    V2 = "V2"