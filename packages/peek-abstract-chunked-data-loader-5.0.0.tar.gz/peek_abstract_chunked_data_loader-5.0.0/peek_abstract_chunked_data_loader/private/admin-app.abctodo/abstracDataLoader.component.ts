import { Component, OnInit } from "@angular/core";

@Component({
    selector: "abstracDataLoader-admin",
    templateUrl: "abstracDataLoader.component.html",
})
export class AbstractDataLoaderComponent implements OnInit {
    ngOnInit() {}
}
