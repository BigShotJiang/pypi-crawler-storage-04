"""
Infrastructure layer tests.
"""
