# visaionlibrary

## install
```
pip install \
-i https://pypi.tuna.tsinghua.edu.cn/simple \
-f https://download.openmmlab.com/mmcv/dist/cu117/torch1.13/index.html \
--extra-index-url https://download.pytorch.org/whl/cu117 \
visaionlibrary
```

## usage
ref: https://github.com/open-mmlab