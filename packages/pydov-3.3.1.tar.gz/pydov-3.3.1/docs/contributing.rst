.. include:: ../.github/CONTRIBUTING.rst
