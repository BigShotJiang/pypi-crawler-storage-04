.. _authors:

=======
Credits
=======

* Pieter Jan Haest <pieterjan.haest@agt.be>
* Stijn Van Hoey
* Johan Van de Wauw
* Roel Huybrechts <roel@huybrechts.re>
* Joris Synaeve
