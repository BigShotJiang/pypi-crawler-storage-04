# DashboardPropertyItems

A list of [dashboard items](#dashboard-item).

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | [**[DashboardItem], none_type**](DashboardItem.md) | A list of [dashboard items](#dashboard-item). | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


