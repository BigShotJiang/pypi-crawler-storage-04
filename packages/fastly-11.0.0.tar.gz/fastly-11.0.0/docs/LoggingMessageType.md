# LoggingMessageType

How the message should be formatted.

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** | How the message should be formatted. | defaults to "classic",  must be one of ["classic", "loggly", "logplex", "blank", ]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


