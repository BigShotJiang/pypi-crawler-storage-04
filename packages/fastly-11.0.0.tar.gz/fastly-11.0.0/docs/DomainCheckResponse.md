# DomainCheckResponse


## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **[bool, date, datetime, dict, float, int, list, str, none_type]** |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


