from fastapi import APIRouter

main_site_router = APIRouter()
