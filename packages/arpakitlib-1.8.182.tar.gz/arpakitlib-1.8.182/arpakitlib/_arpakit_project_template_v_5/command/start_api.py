from project.api.start_api import start_api


def __command():
    start_api()


if __name__ == '__main__':
    __command()
