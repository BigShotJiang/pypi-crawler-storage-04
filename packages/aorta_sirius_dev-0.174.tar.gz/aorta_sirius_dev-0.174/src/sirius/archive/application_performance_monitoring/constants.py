from enum import Enum


class Operation(Enum):
    DATABASE = "Database"
    DISCORD = "Discord"
    HTTP_REQUEST = "HTTP Request"
    AORTA_SIRIUS = "Aorta-Sirius"
