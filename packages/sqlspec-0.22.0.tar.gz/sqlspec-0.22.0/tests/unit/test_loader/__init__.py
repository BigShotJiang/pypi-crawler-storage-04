"""Unit tests for SQLSpec loader module.

Tests for SQL file loading, parsing, and caching functionality.
"""
