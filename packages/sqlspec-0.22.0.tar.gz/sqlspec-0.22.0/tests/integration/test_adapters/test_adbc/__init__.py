"""ADBC adapter integration tests."""
