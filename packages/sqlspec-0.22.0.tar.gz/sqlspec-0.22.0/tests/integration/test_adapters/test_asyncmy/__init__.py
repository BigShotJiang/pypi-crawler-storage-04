import pytest

pytestmark = [pytest.mark.mysql, pytest.mark.asyncmy]
