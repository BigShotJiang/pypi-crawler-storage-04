# BakedPotato

To install

```bash
pip install bakedpotato
```

To run

```bash
bakedpotato
```

