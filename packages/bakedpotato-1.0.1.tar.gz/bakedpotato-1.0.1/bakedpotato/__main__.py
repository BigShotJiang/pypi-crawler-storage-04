from .potato import PotatoApp

def main():
    app = PotatoApp()
    app.mainloop()

if __name__ == "__main__":
    main()