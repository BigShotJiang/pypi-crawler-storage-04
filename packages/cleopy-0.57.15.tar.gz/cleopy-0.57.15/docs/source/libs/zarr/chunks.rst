Chunks
======

Header file: ``<libs/zarr/chunks.hpp>``
`[source] <https://github.com/yoctoyotta1024/CLEO/blob/main/libs/zarr/chunks.hpp>`_

.. doxygenfunction:: vec_product(const std::vector<size_t>& vec)
   :project: zarr

.. doxygenfunction:: vec_product(const std::vector<size_t>& vec, const size_t aa)
   :project: zarr

.. doxygenclass:: Chunks
   :project: zarr
   :private-members:
   :protected-members:
   :members:
   :undoc-members:
