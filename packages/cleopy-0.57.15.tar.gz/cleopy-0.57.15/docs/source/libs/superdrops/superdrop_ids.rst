Superdrop IDs
=============

Header file: ``<libs/superdrops/superdrop_ids.hpp>``
`[source] <https://github.com/yoctoyotta1024/CLEO/blob/main/libs/superdrops/superdrop_ids.hpp>`_

.. doxygenstruct:: IntID
   :project: superdrops
   :private-members:
   :protected-members:
   :members:
   :undoc-members:

.. doxygenstruct:: EmptyID
   :project: superdrops
   :private-members:
   :protected-members:
   :members:
   :undoc-members:

.. doxygenfunction:: operator<<(std::ostream &os, const EmptyID &id)
   :project: superdrops

.. doxygenfunction:: operator<<(std::ostream &os, const IntID &id)
   :project: superdrops
