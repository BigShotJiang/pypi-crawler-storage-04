__authors__ = ", ".join(
    (
        "Sébastien Vallet <sebastien.vallet@roseautechnologies.com>",
        "Ali Hamdan <ali.hamdan@roseautechnologies.com>",
        "Benoît Vinot <benoit.vinot@roseautechnologies.com>",
        "Florent Cadoux <florent.cadoux@roseautechnologies.com>",
        "Victor Gouin",
    )
)
__copyright__ = "Roseau Technologies 2018"
__credits__ = "Roseau Technologies"
__license__ = "Proprietary"
__maintainer__ = "Sébastien Vallet"
__email__ = "sebastien.vallet@roseautechnologies.com"
__status__ = "In development"
__url__ = "https://github.com/RoseauTechnologies/Roseau_Load_Flow/"
