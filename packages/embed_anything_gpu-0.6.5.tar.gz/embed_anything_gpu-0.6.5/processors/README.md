# Processors

This crate contains various "processors" that accept files/folders/bytes and produced a chunked, metadata-rich document
description. This is especially helpful for retrieval-augmented generation!
