from .models import TimModel, TimRecord

__all__ = [
    "TimModel",
    "TimRecord",
]
