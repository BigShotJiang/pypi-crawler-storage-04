class TestObject:
    testClassProperty = object()
