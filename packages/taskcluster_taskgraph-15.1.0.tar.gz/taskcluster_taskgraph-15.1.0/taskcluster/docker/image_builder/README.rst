The out-of-tree version of taskgraph uses the image build for mozilla-central.
The image can be found `here <https://searchfox.org/mozilla-central/source/taskcluster/docker/image_builder>`_.
