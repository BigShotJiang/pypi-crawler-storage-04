from ..notebooks import launch_jupyter_example


def run_example():
    """Run a jupyter notebook example.

    """
    launch_jupyter_example()