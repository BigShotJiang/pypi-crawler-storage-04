AshDisperse
===========

**AshDisperse** is a numerical tool that solves the *steady-state* Advection-Diffusion-Sedimentation (ADS) Equation for a model volcanic eruption emission profile in a real wind field.

The solver is designed to be computationally efficient while solving the ADS equation accurately.