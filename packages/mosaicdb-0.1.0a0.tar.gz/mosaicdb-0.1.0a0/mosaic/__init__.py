"""mosaic - Simple universal ORM (MVP)

Expose Mosaic class and package version.
"""
from .orm import Mosaic

__all__ = ["Mosaic"]
__version__ = "0.1.0"
