#
# Copyright (c) 2024–2025, Daily
#
# SPDX-License-Identifier: BSD 2-Clause License
#

import sys

from piopiy.services import DeprecatedModuleProxy

from .base_stt import *
from .stt import *

sys.modules[__name__] = DeprecatedModuleProxy(globals(), "whisper", "whisper.stt")
