#!/bin/sh

uv sync