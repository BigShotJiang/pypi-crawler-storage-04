"""
Core domain layer tests.
"""
