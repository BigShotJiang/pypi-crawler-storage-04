"""
Example DAG demonstrating the fast_bi_replication_control package usage.

This DAG provides a single, configurable task to monitor and manage Airbyte jobs:
- Monitor ALL connections by default (or specific connections if provided)
- Track job durations across DAG runs using XCom
- Provide full context (connection names, workspace info, job details)
- Cancel jobs that exceed time limits (with dry_run safety)

Configuration:
- DRY_RUN: Default True (safe mode) - set to False to actually cancel jobs
- CONNECTION_IDS: Default None (monitor all) - provide list to monitor specific connections
- MAX_RUNTIME_HOURS: Default 3.0 hours - time limit before canceling jobs
- JOB_TYPE: Default 'sync' - monitor sync jobs only

The system uses proper API filters (status=running) and provides detailed logging
similar to simulate_production_tracking.sh output.
"""

from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.dummy import DummyOperator

# Import our custom package
from fast_bi_replication_control import AirbyteJobMonitorOperator

# DAG configuration
default_args = {
    'owner': 'data-team',
    'depends_on_past': False,
    'start_date': datetime(2025, 1, 1),
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

dag = DAG(
    'airbyte_job_monitoring',
    default_args=default_args,
    description='Monitor and manage long-running Airbyte jobs with advanced tracking',
    schedule_interval='*/5 * * * *',  # Every 5 minutes
    catchup=False,
    tags=['airbyte', 'monitoring', 'data-replication', 'job-tracking'],
)

# Start task
start = DummyOperator(task_id='start', dag=dag)

# Single monitoring task - configurable via parameters
# This task will:
# - Get all connections with names and workspace info
# - Find running jobs using proper API filters (status=running)
# - Track job durations across DAG runs using XCom
# - Provide detailed logging like simulate_production_tracking.sh
# - Cancel jobs that exceed max_runtime_hours (if dry_run=False)
airbyte_job_monitor = AirbyteJobMonitorOperator(
    task_id='airbyte_job_monitor',
    airbyte_conn_id='Data-Replication',
    connection_ids=None,  # None = monitor all connections (default)
    max_runtime_hours=0.5,  # Cancel jobs running longer than 30 minutes
    job_type='sync',  # Monitor sync jobs only
    dry_run=True,  # Default to True for safety - set to False to actually cancel
    queue='default',  # Use default queue (correct for this environment)
    dag=dag,
)

# End task
end = DummyOperator(task_id='end', dag=dag)

# Simple linear flow
start >> airbyte_job_monitor >> end 