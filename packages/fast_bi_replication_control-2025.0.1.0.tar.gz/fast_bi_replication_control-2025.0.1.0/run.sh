#!/usr/bin/env bash

set -euo pipefail

# Simple runner to test the fast_bi_replication_control package against a local Airbyte
# Instance expected at http://127.0.0.1:8080 (override via --host or AIRBYTE_API_LINK)

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VENV_DIR="${SCRIPT_DIR}/.venv"
PYTHON_BIN="${PYTHON:-python3}"

AIRBYTE_HOST_DEFAULT="http://127.0.0.1:8080"
AIRBYTE_HOST="${AIRBYTE_API_LINK:-${AIRBYTE_HOST_DEFAULT}}"
AIRBYTE_API_BASE_DEFAULT="api/public"
AIRBYTE_API_BASE="${AIRBYTE_API_BASE:-${AIRBYTE_API_BASE_DEFAULT}}"

REINSTALL=0

usage() {
  cat <<USAGE
Usage: $(basename "$0") [options]

Options:
  --host URL          Airbyte base URL (default: ${AIRBYTE_HOST_DEFAULT})
  --api-base PATH     Airbyte API base path (default: ${AIRBYTE_API_BASE_DEFAULT})
  --reinstall         Delete and recreate virtual environment
  -h, --help          Show this help and exit

Environment overrides:
  AIRBYTE_API_LINK    Same as --host
  AIRBYTE_API_BASE    Same as --api-base
  PYTHON              Python interpreter to use (default: python3)
USAGE
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --host)
      AIRBYTE_HOST="$2"; shift 2 ;;
    --api-base)
      AIRBYTE_API_BASE="$2"; shift 2 ;;
    --reinstall)
      REINSTALL=1; shift ;;
    -h|--help)
      usage; exit 0 ;;
    *)
      echo "Unknown argument: $1" >&2
      usage; exit 1 ;;
  esac
done

echo "[INFO] Using Airbyte host: ${AIRBYTE_HOST}"
echo "[INFO] Using Airbyte API base: ${AIRBYTE_API_BASE}"

if [[ ${REINSTALL} -eq 1 && -d "${VENV_DIR}" ]]; then
  echo "[INFO] Removing existing venv at ${VENV_DIR}"
  rm -rf "${VENV_DIR}"
fi

if [[ ! -d "${VENV_DIR}" ]]; then
  echo "[INFO] Creating virtual environment at ${VENV_DIR}"
  "${PYTHON_BIN}" -m venv "${VENV_DIR}"
fi

source "${VENV_DIR}/bin/activate"

echo "[INFO] Upgrading pip/setuptools/wheel"
python -m pip install --upgrade pip setuptools wheel

echo "[INFO] Installing requirements from requirements.txt"
pip install -r "${SCRIPT_DIR}/requirements.txt"

echo "[INFO] Installing package (editable)"
pip install -e "${SCRIPT_DIR}"

# Keep Airflow files isolated
export AIRFLOW_HOME="${SCRIPT_DIR}/.airflow_home"
mkdir -p "${AIRFLOW_HOME}"

# Point the hook to the provided Airbyte host
export AIRBYTE_API_LINK="${AIRBYTE_HOST}"
export AIRBYTE_API_BASE="${AIRBYTE_API_BASE}"

echo "[INFO] Verifying connectivity to Airbyte API via fast_bi_replication_control hook"
python - <<'PY'
import json
import sys

try:
    from fast_bi_replication_control.airbyte.hook import AirbyteApiHook
except Exception as e:
    print(f"[ERROR] Failed to import package: {e}")
    sys.exit(2)

hook = AirbyteApiHook(airbyte_conn_id='Data-Replication')

def safe_call(name, fn):
    try:
        res = fn()
        if isinstance(res, dict) and 'data' in res:
            print(f"[OK] {name}: {len(res['data'])} items")
        else:
            print(f"[OK] {name}:\n{json.dumps(res, indent=2)[:1000]}")
    except Exception as e:
        print(f"[ERROR] {name} failed: {e}")
        sys.exit(3)

# Try a simple sequence of API calls
safe_call('List workspaces', hook.list_workspaces)
safe_call('List connections', hook.list_connections)
safe_call('List sync jobs', lambda: hook.list_jobs(job_type='sync'))

print("[INFO] All checks completed successfully.")
PY

echo "[INFO] Done. Virtual env is at: ${VENV_DIR}"
echo "[INFO] To reuse it later: source \"${VENV_DIR}/bin/activate\""


