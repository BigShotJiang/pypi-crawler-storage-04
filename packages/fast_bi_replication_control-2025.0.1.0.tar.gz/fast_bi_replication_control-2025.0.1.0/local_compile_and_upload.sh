#!/usr/bin/env bash

set -euo pipefail

# Local script to compile and upload fast_bi_replication_control package
# This mimics the GitLab CI pipeline for local development

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT="fast-bi-common"
REPOSITORY="bi-platform-pypi-packages"
LOCATION="europe-central2"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

usage() {
    cat <<USAGE
Usage: $(basename "$0") [options]

Options:
    --version VERSION    Set package version (default: 0.0.0)
    --dry-run           Build package but don't upload
    --help              Show this help and exit

Environment variables:
    CI_COMMIT_TAG       Git tag for versioning (overrides --version)

Prerequisites:
    gcloud auth login    Must be authenticated with gcloud CLI

Examples:
    # Build and upload with version 1.0.0
    ./local_compile_and_upload.sh --version 1.0.0

    # Dry run - just build without uploading
    ./local_compile_and_upload.sh --dry-run

    # Use git tag for versioning
    CI_COMMIT_TAG=v1.0.0 ./local_compile_and_upload.sh
USAGE
}

VERSION="0.0.0"
DRY_RUN=false

while [[ $# -gt 0 ]]; do
    case "$1" in
        --version)
            VERSION="$2"; shift 2 ;;
        --dry-run)
            DRY_RUN=true; shift ;;
        -h|--help)
            usage; exit 0 ;;
        *)
            log_error "Unknown argument: $1"
            usage; exit 1 ;;
    esac
done

# Check if we're in the right directory
if [[ ! -f "${SCRIPT_DIR}/setup.py" ]]; then
    log_error "setup.py not found. Please run this script from the package directory."
    exit 1
fi

cd "${SCRIPT_DIR}"

# Use CI_COMMIT_TAG if available, otherwise use provided version
if [[ -n "${CI_COMMIT_TAG:-}" ]]; then
    VERSION="${CI_COMMIT_TAG}"
    log_info "Using version from CI_COMMIT_TAG: ${VERSION}"
else
    log_info "Using version: ${VERSION}"
fi

# Install build dependencies
log_info "Installing build dependencies..."
pip install -r requirements.txt
pip install setuptools wheel

# Clean previous builds
log_info "Cleaning previous builds..."
rm -rf build/ dist/ *.egg-info/

# Build package
log_info "Building package..."
export CI_COMMIT_TAG="${VERSION}"
python setup.py sdist bdist_wheel

# List built packages
log_info "Built packages:"
ls -la dist/

if [[ "${DRY_RUN}" == "true" ]]; then
    log_warn "Dry run mode - skipping upload"
    log_info "To upload manually, run:"
    echo "python -m twine upload -r ${REPOSITORY} dist/*"
    exit 0
fi

# # Check for service account key
# if [[ -z "${GCP_SA_SECRET:-}" ]]; then
#     log_error "GCP_SA_SECRET environment variable not set"
#     log_error "Please set it to a base64 encoded service account key"
#     exit 1
# fi

# Setup Google Cloud authentication
log_info "Setting up Google Cloud authentication..."
mkdir -p "${HOME}/.config/pip/"

# Check if user is authenticated with gcloud
if ! gcloud auth list --filter=status:ACTIVE --format="value(account)" | grep -q .; then
    log_error "No active gcloud authentication found"
    log_error "Please run: gcloud auth login"
    exit 1
fi

log_info "Using existing gcloud authentication: $(gcloud auth list --filter=status:ACTIVE --format="value(account)")"

# Configure artifacts repository
gcloud config set artifacts/repository "${REPOSITORY}"
gcloud config set artifacts/location "${LOCATION}"

# Generate pip configuration for pip installs
log_info "Generating pip configuration..."
gcloud artifacts print-settings python \
    --project="${PROJECT}" \
    --repository="${REPOSITORY}" \
    --location="${LOCATION}" \
    > "${HOME}/.config/pip/pip.conf"

# Upload package using gcloud authentication
log_info "Uploading package to repository..."
TWINE_USERNAME=oauth2accesstoken TWINE_PASSWORD=$(gcloud auth print-access-token) python -m twine upload -r "${REPOSITORY}" dist/* --verbose

log_info "Package uploaded successfully!"
log_info "Version: ${VERSION}"
log_info "Repository: ${REPOSITORY}"
