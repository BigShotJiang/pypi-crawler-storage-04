# Arithmetic Package

This is a simple example package. You can use to write your content.

```python

from arith_veeru4a4 import arith

arith.sum(1,2,3,4,5)

```
