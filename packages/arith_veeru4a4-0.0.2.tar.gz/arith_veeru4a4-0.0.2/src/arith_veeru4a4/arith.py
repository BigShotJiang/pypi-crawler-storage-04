'''
* Author : Veeru <veeru.mandli@gmail.com>
* Purpose : Arithmetic Operation
* Last Modified: 2025-09-05 9:46 AM

'''


def add(*params):
    return sum(params)
