from enum import Enum


class NameTypes(Enum):
    ALPHABETICAL = "alphabetical"
    NUMERICAL = "numerical"
    ROMAN = "roman"
