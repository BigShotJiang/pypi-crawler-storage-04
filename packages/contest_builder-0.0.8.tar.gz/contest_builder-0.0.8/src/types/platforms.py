from enum import Enum


class Platforms(Enum):
    WINDOWS = "windows"
    DARWIN = "darwin"
    JAVA = "java"
    LINUX = "linux"
