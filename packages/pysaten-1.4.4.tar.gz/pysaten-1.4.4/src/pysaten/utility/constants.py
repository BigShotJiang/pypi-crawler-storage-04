from typing import Final

SR: Final[int] = 96000
NYQ: Final[int] = int(SR / 2)
F0_FLOOR: Final[int] = 71  # from WORLD library
F0_CEIL: Final[int] = 800  # from WORLD library
