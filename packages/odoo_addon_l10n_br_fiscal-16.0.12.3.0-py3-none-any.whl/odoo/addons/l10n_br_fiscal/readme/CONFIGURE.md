Para uma boa configuração fiscal, você tem que revisar bem:

- em Configurações: as operaçoes fiscais que você vai usar, as linhas de
  operação fiscal e as definições das taxas nessas linhas.
- a configuração fiscal da sua empresa (aba fiscal)
- a configuração fiscal dos clientes e fornecedores (aba fiscal) e dos
  produtos (aba fiscal).
