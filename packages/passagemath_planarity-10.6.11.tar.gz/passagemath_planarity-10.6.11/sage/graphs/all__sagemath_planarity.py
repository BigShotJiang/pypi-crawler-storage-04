# sage_setup: distribution = sagemath-planarity
