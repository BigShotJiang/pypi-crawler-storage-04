# encoding: utf-8

import setuptools

setuptools.setup()
