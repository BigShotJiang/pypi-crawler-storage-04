#!/usr/bin/env python3
"""


"""
# Imports:
from __future__ import annotations

# ##-- stdlib imports
import datetime
import enum
import functools as ftz
import itertools as itz
import logging as logmod
import pathlib as pl
import re
import time
import types
import collections
import contextlib
import hashlib
from copy import deepcopy
from uuid import UUID, uuid1
from weakref import ref
import atexit # for @atexit.register
import faulthandler
# ##-- end stdlib imports

# ##-- types
# isort: off
import abc
import collections.abc
from typing import TYPE_CHECKING, cast, assert_type, assert_never
from typing import Generic, NewType
# Protocols:
from typing import Protocol, runtime_checkable
# Typing Decorators:
from typing import no_type_check, final, override, overload
# from dataclasses import InitVar, dataclass, field
# from pydantic import BaseModel, Field, model_validator, field_validator, ValidationError

if TYPE_CHECKING:
    from jgdv import Maybe
    from typing import Final
    from typing import ClassVar, Any, LiteralString
    from typing import Never, Self, Literal
    from typing import TypeGuard
    from collections.abc import Iterable, Iterator, Callable, Generator
    from collections.abc import Sequence, Mapping, MutableMapping, Hashable

##--|

# isort: on
# ##-- end types

##-- logging
logging = logmod.getLogger(__name__)
##-- end logging

# Vars:
FF_DRIVER          : Final[str] = "__$ff_driver"
READER_PREFIX      : Final[str] = "about:reader?url="
LOAD_TIMEOUT       : Final[int] = 2
WAYBACK_USER_AGENT : Final[str] = "Mozilla/5.0 (Windows NT 5.1; rv:40.0) Gecko/20100101 Firefox/40.0"
GECKO_DRIVER       : Final[str] = "/snap/bin/geckodriver"
##--|
SELENIUM_OPTS : Final[list] = ["--headless"
                               # "--start-maximized"
]

SELENIUM_PREFS : Final[dict] = {
        "print.always_print_silent"                           :  True,
        "print.printer_Mozilla_Save_to_PDF.print_to_file"     :  True,
        "print_printer"                                       :  "Mozilla Save to PDF",
        "print.printer_Mozilla_Save_to_PDF.use_simplify_page" :  True,
        "print.printer_Mozilla_Save_to_PDF.print_page_delay"  :  50,
}
# Body:
