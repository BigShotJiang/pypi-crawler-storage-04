from pydantic import model_validator as _mv

model_validator = _mv
