from __future__ import annotations


def entity[T](cls: type[T]) -> type[T]:
    return cls
