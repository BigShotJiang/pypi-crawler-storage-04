def get_extension_from_filename(filename: str) -> str:
    ext = filename.split(".")[-1]
    return ext
