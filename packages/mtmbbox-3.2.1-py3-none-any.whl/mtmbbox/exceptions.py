class QujingInvokeError(Exception):
    pass


class APPServerHighLoadError(Exception):
    pass


class APPTooManyRequestsError(Exception):
    pass
