from .py_api import deploy, destroy

__all__ = ["deploy", "destroy"]
