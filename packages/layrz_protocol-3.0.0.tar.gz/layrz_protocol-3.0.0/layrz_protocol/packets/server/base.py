from layrz_protocol.packets.base import Packet


class ServerPacket(Packet):
  """Server packet definition"""
