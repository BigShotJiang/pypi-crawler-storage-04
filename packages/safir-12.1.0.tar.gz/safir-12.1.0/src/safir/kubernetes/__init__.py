"""Utilities for configuring a Kubernetes client."""

from ._init import initialize_kubernetes

__all__ = ["initialize_kubernetes"]
