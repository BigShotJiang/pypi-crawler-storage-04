# Handlers and Handler Functions

::: osmium.SimpleHandler
::: osmium.MergeInputReader
::: osmium.NodeLocationsForWays

## Handler functions

::: osmium.apply
    options:
        heading_level: 3

::: osmium.make_simple_handler
    options:
        heading_level: 3
