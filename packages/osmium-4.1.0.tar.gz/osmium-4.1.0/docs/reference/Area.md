# Area building

::: osmium.area.AreaManager

