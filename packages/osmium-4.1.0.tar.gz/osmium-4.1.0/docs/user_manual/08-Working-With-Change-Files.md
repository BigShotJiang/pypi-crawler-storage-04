# Working With Change Files

OpenStreetMap produces two kinds of data, full data files and diff files with updates. This chapter explains how to handle diff files.
