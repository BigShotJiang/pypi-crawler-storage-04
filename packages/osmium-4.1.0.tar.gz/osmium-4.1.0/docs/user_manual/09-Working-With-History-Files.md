# Working With History Files

An OSM data file usually contains data of a snapshot of the OpenStreetMap database at a certain point in time. The full database contains even more data. It has all the changes that were ever made. The full version of the database with the complete history is contained in so called history files. They do require some special attention when processing.
