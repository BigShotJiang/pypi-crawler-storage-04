# 这是一个测试模块
def test_function():
    print("TheFuck AI Assistant package is working!")
