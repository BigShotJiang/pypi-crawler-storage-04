__version__ = "0.1.1"

from .main import (
    LossBalancer,
    LinearTrajectoryTarget,
    ConstantTarget,
    RelativeTarget,
    Target,
)
