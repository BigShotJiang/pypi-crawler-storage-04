# Internal helper modules - not for direct user access
