"""
SAGE Web UI Module

FastAPI-based Web管理界面 for SAGE Framework.
"""

from .main import main

__all__ = ["main"]
