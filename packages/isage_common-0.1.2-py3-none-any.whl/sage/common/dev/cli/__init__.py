"""CLI module initialization."""

__all__ = []
