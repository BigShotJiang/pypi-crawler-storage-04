The files there are somehow produced by stephan ?

I copied them from lin1 
/home/klima/Hill/BRM_meteo/2022/Bero*.csv 

scp command: 

scp lin1:/home/klima/Hill/BRM_meteo/2022/Bero*.csv C:\Users\coli\Documents\ovoc-calculations