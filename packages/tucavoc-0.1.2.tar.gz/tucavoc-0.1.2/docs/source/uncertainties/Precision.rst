.. Long description for this file

