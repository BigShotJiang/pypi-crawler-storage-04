"""Formula 6.12 from EN 1992-1-1:2004: Chapter 6 - Ultimate Limit State."""

from blueprints.codes.eurocode.en_1992_1_1_2004 import EN_1992_1_1_2004
from blueprints.codes.formula import Formula
from blueprints.codes.latex_formula import LatexFormula
from blueprints.type_alias import DIMENSIONLESS, MM, MM2, MPA
from blueprints.validations import raise_if_less_or_equal_to_zero, raise_if_negative


class Form6Dot12CheckMaxEffectiveCrossSectionalAreaShearReinf(Formula):
    r"""Class representing formula 6.12 for checking the maximum effective cross-sectional area of the shear reinforcement."""

    label = "6.12"
    source_document = EN_1992_1_1_2004

    def __init__(
        self,
        a_sw_max: MM2,
        f_ywd: MPA,
        b_w: MM,
        s: MM,
        alpha_cw: DIMENSIONLESS,
        nu_1: DIMENSIONLESS,
        f_cd: MPA,
    ) -> None:
        r"""Check the maximum effective cross-sectional area of the shear reinforcement.

        EN 1992-1-1:2004 art.6.2.3(3) - Formula (6.12)

        Parameters
        ----------
        a_sw_max : MM2
            [$A_{sw,max}$] Maximum effective cross-sectional area of the shear reinforcement [$mm^2$].
        f_ywd : MPA
            [$f_{ywd}$] Design yield strength of the shear reinforcement [$MPa$].
        b_w : MM
            [$b_{w}$] Width of the web [$mm$].
        s : MM
            [$s$] Spacing of the shear reinforcement [$mm$].
        alpha_cw : DIMENSIONLESS
            [$\alpha_{cw}$] Coefficient taking account of the state of stress in the compression chord [$-$].
        nu_1 : DIMENSIONLESS
            [$\nu_{1}$] Strength reduction factor for concrete [$-$].
        f_cd : MPA
            [$f_{cd}$] Design value of concrete compressive strength [$MPa$].
        """
        super().__init__()
        self.a_sw_max = a_sw_max
        self.f_ywd = f_ywd
        self.b_w = b_w
        self.s = s
        self.alpha_cw = alpha_cw
        self.nu_1 = nu_1
        self.f_cd = f_cd

    @staticmethod
    def _evaluate(
        a_sw_max: MM2,
        f_ywd: MPA,
        b_w: MM,
        s: MM,
        alpha_cw: DIMENSIONLESS,
        nu_1: DIMENSIONLESS,
        f_cd: MPA,
    ) -> bool:
        """Evaluates the formula, for more information see the __init__ method."""
        raise_if_less_or_equal_to_zero(
            b_w=b_w,
            s=s,
        )
        raise_if_negative(a_sw_max=a_sw_max, f_ywd=f_ywd, alpha_cw=alpha_cw, nu_1=nu_1, f_cd=f_cd)

        return (a_sw_max * f_ywd / (b_w * s)) <= (0.5 * alpha_cw * nu_1 * f_cd)

    def latex(self, n: int = 3) -> LatexFormula:
        """Returns LatexFormula object for formula 6.12."""
        return LatexFormula(
            return_symbol=r"CHECK",
            result="OK" if self.__bool__() else "\\text{Not OK}",
            equation=r"\frac{A_{sw,max} \cdot f_{ywd}}{b_{w} \cdot s} \leq \frac{1}{2} \cdot \alpha_{cw} \cdot \nu_{1} \cdot f_{cd}",
            numeric_equation=rf"\frac{{{self.a_sw_max:.{n}f} \cdot {self.f_ywd:.{n}f}}}{{{self.b_w:.{n}f} \cdot {self.s:.{n}f}}}"
            rf" \leq \frac{{1}}{{2}} \cdot {self.alpha_cw:.{n}f} \cdot {self.nu_1:.{n}f} \cdot {self.f_cd:.{n}f}",
            comparison_operator_label="\\to",
            unit="",
        )
