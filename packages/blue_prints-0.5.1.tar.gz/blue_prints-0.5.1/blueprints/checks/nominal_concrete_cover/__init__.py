"""Nominal concrete cover."""
