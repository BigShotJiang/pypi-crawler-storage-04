"""Eurocode tests."""
