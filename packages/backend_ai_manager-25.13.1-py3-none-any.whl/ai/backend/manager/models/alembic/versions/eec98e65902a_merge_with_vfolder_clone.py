"""merge-with-vfolder-clone

Revision ID: eec98e65902a
Revises: d463fc5d6109, 97f6c80c8aa5
Create Date: 2020-10-03 18:11:06.270486

"""

# revision identifiers, used by Alembic.
revision = "eec98e65902a"
down_revision = ("d463fc5d6109", "97f6c80c8aa5")
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
