from blissoda.demo.id31 import id31_xrpd_processor

if id31_xrpd_processor._HAS_BLISS:
    id31_xrpd_processor.enable()
