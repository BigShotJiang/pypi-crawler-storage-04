# imagerotate
Image rotate plugin for CKEditor

http://ckeditor.com/addon/imagerotate
