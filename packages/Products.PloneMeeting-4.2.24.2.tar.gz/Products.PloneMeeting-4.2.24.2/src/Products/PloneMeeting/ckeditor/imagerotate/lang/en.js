﻿CKEDITOR.plugins.setLang('imagerotate', 'en', {
  rotateRight: 'Rotate Clockwise',
  rotateLeft: 'Rotate Counter-clockwise',
  errorNoImage: "no image element?",
  errorNoDOMImage: "no DOM image element?",
  errorImageFromOtherDomain: "Image is from other domain and can't be rotated",
});
