
ActivityIDHeader         = "X-Activity-ID"
EnvironmentIDHeader      = "X-Environment-ID"
EnvironmentNameHeader    = "X-Environment-Name"
WorkflowTokenHeader      = "X-Workflow-Token"
EngineAPIEndpointHeader  = "X-Engine-Endpoint"
ActivityFileUploadHeader = "X-Activity-File-Upload"
