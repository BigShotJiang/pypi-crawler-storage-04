2025-08-18 Version: 4.1.0
- Support API CreateWuyingServer.
- Support API ListWuyingServer.
- Support API ModifyWuyingServerAttribute.
- Support API RenewWuyingServer.
- Support API RestartWuyingServer.
- Support API StartWuyingServer.
- Support API StopWuyingServer.


2025-07-10 Version: 4.0.1
- Update API RenewAppInstanceGroup: add request parameters RenewAmount.
- Update API RenewAppInstanceGroup: add request parameters RenewMode.
- Update API RenewAppInstanceGroup: add request parameters RenewNodes.


2025-06-25 Version: 4.0.0
- Support API ListAuthorizedUserGroups.
- Delete API AccessPageSetAcl.
- Delete API AskSessionPackagePrice.
- Delete API BuySessionPackage.
- Delete API CreateAccessPage.
- Delete API DeleteAccessPage.
- Delete API GetAccessPageSession.
- Delete API ListAccessPages.
- Delete API ListSessionPackages.
- Update API AuthorizeInstanceGroup: add request parameters AuthorizeUserGroupIds.
- Update API AuthorizeInstanceGroup: add request parameters AvatarId.
- Update API AuthorizeInstanceGroup: add request parameters UnAuthorizeUserGroupIds.
- Update API GetAppInstanceGroup: add response parameters Body.AppInstanceGroupModels.AccessType.
- Update API GetAppInstanceGroup: add response parameters Body.AppInstanceGroupModels.AuthMode.
- Update API GetConnectionTicket: add request parameters AppPolicyId.
- Update API GetConnectionTicket: add response parameters Body.AvatarId.
- Update API ListAppInstanceGroup: add response parameters Body.AppInstanceGroupModels.$.AccessType.
- Update API ListAppInstanceGroup: add response parameters Body.AppInstanceGroupModels.$.AuthMode.


2025-04-27 Version: 3.2.4
- Update API GetAppInstanceGroup: add response parameters Body.AppInstanceGroupModels.Tags.


2025-04-25 Version: 3.2.3
- Update API ListAppInstanceGroup: add request parameters Tag.
- Update API ListAppInstanceGroup: add response parameters Body.AppInstanceGroupModels.$.Tags.


2025-04-11 Version: 3.2.2
- Generated python 2021-09-01 for appstream-center.

2025-04-07 Version: 3.2.1
- Update API GetConnectionTicket: add request parameters AccessType.


2025-03-28 Version: 3.2.0
- Support API ListPersistentAppInstances.


2025-03-27 Version: 3.1.1
- Update API AuthorizeInstanceGroup: add request parameters AppInstancePersistentId.
- Update API CreateAppInstanceGroup: add request parameters AuthMode.
- Update API CreateAppInstanceGroup: add request parameters RuntimePolicy.PersistentAppInstanceScheduleMode.


2025-03-13 Version: 3.1.0
- Support API ListNodes.
- Support API ListTagCloudResources.
- Support API ModifyNodePoolAmount.
- Support API TagCloudResources.
- Support API UntagCloudResources.


2025-03-12 Version: 3.0.3
- Update API ListAppInstanceGroup: update response param.
- Update API ListAppInstances: update response param.


2024-10-22 Version: 2.0.4
- Update API AuthorizeInstanceGroup: add param UserMeta.
- Update API CreateAppInstanceGroup: update param AppInstanceGroupName.
- Update API CreateAppInstanceGroup: update param Network.
- Update API GetAppInstanceGroup: update response param.
- Update API ListAppInstanceGroup: add param OfficeSiteId.
- Update API ListAppInstanceGroup: update response param.
- Update API ListNodeInstanceType: add param Cpu.
- Update API ListNodeInstanceType: add param Gpu.
- Update API ListNodeInstanceType: add param GpuMemory.
- Update API ListNodeInstanceType: add param Memory.
- Update API ListNodeInstanceType: add param NodeInstanceTypeFamily.
- Update API ListNodeInstanceType: add param OrderBy.
- Update API ListNodeInstanceType: add param SortType.
- Update API ListNodeInstanceType: update response param.


2024-09-12 Version: 2.0.3
- Update API CreateAppInstanceGroup: update param NodePool.
- Update API GetAppInstanceGroup: update response param.
- Update API ListAppInstanceGroup: update response param.
- Update API ModifyNodePoolAttribute: update param NodePoolStrategy.


2024-08-02 Version: 2.0.2
- Update API AuthorizeInstanceGroup: update param AuthorizeUserIds.
- Update API AuthorizeInstanceGroup: update param UnAuthorizeUserIds.
- Update API ListRegions: add param BizSource.


2024-07-23 Version: 2.0.1
- Generated python 2021-09-01 for appstream-center.

2024-07-22 Version: 2.0.0
- Support API ModifyAppPolicy.
- Update API BuySessionPackage: add param AutoPay.
- Update API CreateAppInstanceGroup: add param UserDefinePolicy.
- Update API CreateAppInstanceGroup: add param VideoPolicy.
- Update API ListAppInstanceGroup: add param RegionId.
- Update API ListRegions: add param ProductType.


2024-01-15 Version: 1.1.0
- Generated python 2021-09-01 for appstream-center.

2023-08-22 Version: 1.0.8
- Generated python 2021-09-01 for appstream-center.

2023-05-09 Version: 1.0.7
- Modify ListAppInstance.

2023-04-03 Version: 1.0.6
- Add ListAppInstances Open API.

2023-03-22 Version: 1.0.5
- Add ListAppInstances Open API.

2023-03-21 Version: 1.0.4
- Add Unbind Open API.

2023-03-10 Version: 1.0.3
- Add Unbind Open API.

2023-03-09 Version: 1.0.2
- Add GetConnectionTicket Open API.

2023-01-30 Version: 1.0.1
- For new api version.

2022-11-01 Version: 1.0.0
- For new api version.

