pub struct EnvVars;

impl EnvVars {
    pub const MEOWDA_LOCAL_VENV_DIR: &'static str = "MEOWDA_LOCAL_VENV_DIR";
    pub const MEOWDA_GLOBAL_VENV_DIR: &'static str = "MEOWDA_GLOBAL_VENV_DIR";
}
