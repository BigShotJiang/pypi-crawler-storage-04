var xo = Object.defineProperty;
var ur = (t) => {
  throw TypeError(t);
};
var Bo = (t, e, n) => e in t ? xo(t, e, { enumerable: !0, configurable: !0, writable: !0, value: n }) : t[e] = n;
var Q = (t, e, n) => Bo(t, typeof e != "symbol" ? e + "" : e, n), To = (t, e, n) => e.has(t) || ur("Cannot " + n);
var cr = (t, e, n) => e.has(t) ? ur("Cannot add the same private member more than once") : e instanceof WeakSet ? e.add(t) : e.set(t, n);
var on = (t, e, n) => (To(t, e, "access private method"), n);
function lt() {
}
function Io(t) {
  return t();
}
function Lo(t) {
  return typeof t == "function";
}
function Ho(t, ...e) {
  if (t == null) {
    for (const i of e) i(void 0);
    return lt;
  }
  const n = t.subscribe(...e);
  return n.unsubscribe ? () => n.unsubscribe() : n;
}
function hr(t) {
  const e = typeof t == "string" && t.match(/^\s*(-?[\d.]+)([^\s]*)\s*$/);
  return e ? [parseFloat(e[1]), e[2] || "px"] : [t, "px"];
}
const al = typeof window < "u";
let fr = al ? () => window.performance.now() : () => Date.now(), ll = al ? (t) => requestAnimationFrame(t) : lt;
const Dt = /* @__PURE__ */ new Set();
function ol(t) {
  Dt.forEach((e) => {
    e.c(t) || (Dt.delete(e), e.f());
  }), Dt.size !== 0 && ll(ol);
}
function Po(t) {
  let e;
  return Dt.size === 0 && ll(ol), { promise: new Promise((n) => {
    Dt.add(e = { c: t, f: n });
  }), abort() {
    Dt.delete(e);
  } };
}
function No(t) {
  const e = t - 1;
  return e * e * e + 1;
}
function _r(t, { delay: e = 0, duration: n = 400, easing: i = No, x: r = 0, y: l = 0, opacity: a = 0 } = {}) {
  const o = getComputedStyle(t), s = +o.opacity, u = o.transform === "none" ? "" : o.transform, c = s * (1 - a), [_, h] = hr(r), [d, D] = hr(l);
  return { delay: e, duration: n, easing: i, css: (E, F) => `
			transform: ${u} translate(${(1 - E) * _}${h}, ${(1 - E) * d}${D});
			opacity: ${s - c * F}` };
}
const ft = [];
function Oo(t, e) {
  return { subscribe: Qt(t, e).subscribe };
}
function Qt(t, e = lt) {
  let n;
  const i = /* @__PURE__ */ new Set();
  function r(a) {
    if (s = a, ((o = t) != o ? s == s : o !== s || o && typeof o == "object" || typeof o == "function") && (t = a, n)) {
      const u = !ft.length;
      for (const c of i) c[1](), ft.push(c, t);
      if (u) {
        for (let c = 0; c < ft.length; c += 2) ft[c][0](ft[c + 1]);
        ft.length = 0;
      }
    }
    var o, s;
  }
  function l(a) {
    r(a(t));
  }
  return { set: r, update: l, subscribe: function(a, o = lt) {
    const s = [a, o];
    return i.add(s), i.size === 1 && (n = e(r, l) || lt), a(t), () => {
      i.delete(s), i.size === 0 && n && (n(), n = null);
    };
  } };
}
function $t(t, e, n) {
  const i = !Array.isArray(t), r = i ? [t] : t;
  if (!r.every(Boolean)) throw new Error("derived() expects stores as input, got a falsy value");
  const l = e.length < 2;
  return Oo(n, (a, o) => {
    let s = !1;
    const u = [];
    let c = 0, _ = lt;
    const h = () => {
      if (c) return;
      _();
      const D = e(i ? u[0] : u, a, o);
      l ? a(D) : _ = Lo(D) ? D : lt;
    }, d = r.map((D, E) => Ho(D, (F) => {
      u[E] = F, c &= ~(1 << E), s && h();
    }, () => {
      c |= 1 << E;
    }));
    return s = !0, h(), function() {
      d.forEach(Io), _(), s = !1;
    };
  });
}
function dr(t) {
  return Object.prototype.toString.call(t) === "[object Date]";
}
function yi(t, e, n, i) {
  if (typeof n == "number" || dr(n)) {
    const r = i - n, l = (n - e) / (t.dt || 1 / 60), a = (l + (t.opts.stiffness * r - t.opts.damping * l) * t.inv_mass) * t.dt;
    return Math.abs(a) < t.opts.precision && Math.abs(r) < t.opts.precision ? i : (t.settled = !1, dr(n) ? new Date(n.getTime() + a) : n + a);
  }
  if (Array.isArray(n)) return n.map((r, l) => yi(t, e[l], n[l], i[l]));
  if (typeof n == "object") {
    const r = {};
    for (const l in n) r[l] = yi(t, e[l], n[l], i[l]);
    return r;
  }
  throw new Error(`Cannot spring ${typeof n} values`);
}
function mr(t, e = {}) {
  const n = Qt(t), { stiffness: i = 0.15, damping: r = 0.8, precision: l = 0.01 } = e;
  let a, o, s, u = t, c = t, _ = 1, h = 0, d = !1;
  function D(F, C = {}) {
    c = F;
    const g = s = {};
    return t == null || C.hard || E.stiffness >= 1 && E.damping >= 1 ? (d = !0, a = fr(), u = F, n.set(t = c), Promise.resolve()) : (C.soft && (h = 1 / (60 * (C.soft === !0 ? 0.5 : +C.soft)), _ = 0), o || (a = fr(), d = !1, o = Po((f) => {
      if (d) return d = !1, o = null, !1;
      _ = Math.min(_ + h, 1);
      const m = { inv_mass: _, opts: E, settled: !0, dt: 60 * (f - a) / 1e3 }, v = yi(m, u, t, c);
      return a = f, u = t, n.set(t = v), m.settled && (o = null), !m.settled;
    })), new Promise((f) => {
      o.promise.then(() => {
        g === s && f();
      });
    }));
  }
  const E = { set: D, update: (F, C) => D(F(c, t), C), subscribe: n.subscribe, stiffness: i, damping: r, precision: l };
  return E;
}
function Ro(t) {
  return Mo(t) && !qo(t);
}
function Mo(t) {
  return !!t && typeof t == "object";
}
function qo(t) {
  var e = Object.prototype.toString.call(t);
  return e === "[object RegExp]" || e === "[object Date]" || zo(t);
}
var Uo = typeof Symbol == "function" && Symbol.for, Go = Uo ? Symbol.for("react.element") : 60103;
function zo(t) {
  return t.$$typeof === Go;
}
var jo = Ro;
function Vo(t) {
  return Array.isArray(t) ? [] : {};
}
function Gt(t, e) {
  return e.clone !== !1 && e.isMergeableObject(t) ? kt(Vo(t), t, e) : t;
}
function Xo(t, e, n) {
  return t.concat(e).map(function(i) {
    return Gt(i, n);
  });
}
function Zo(t, e) {
  if (!e.customMerge)
    return kt;
  var n = e.customMerge(t);
  return typeof n == "function" ? n : kt;
}
function Wo(t) {
  return Object.getOwnPropertySymbols ? Object.getOwnPropertySymbols(t).filter(function(e) {
    return Object.propertyIsEnumerable.call(t, e);
  }) : [];
}
function pr(t) {
  return Object.keys(t).concat(Wo(t));
}
function sl(t, e) {
  try {
    return e in t;
  } catch {
    return !1;
  }
}
function Qo(t, e) {
  return sl(t, e) && !(Object.hasOwnProperty.call(t, e) && Object.propertyIsEnumerable.call(t, e));
}
function Yo(t, e, n) {
  var i = {};
  return n.isMergeableObject(t) && pr(t).forEach(function(r) {
    i[r] = Gt(t[r], n);
  }), pr(e).forEach(function(r) {
    Qo(t, r) || (sl(t, r) && n.isMergeableObject(e[r]) ? i[r] = Zo(r, n)(t[r], e[r], n) : i[r] = Gt(e[r], n));
  }), i;
}
function kt(t, e, n) {
  n = n || {}, n.arrayMerge = n.arrayMerge || Xo, n.isMergeableObject = n.isMergeableObject || jo, n.cloneUnlessOtherwiseSpecified = Gt;
  var i = Array.isArray(e), r = Array.isArray(t), l = i === r;
  return l ? i ? n.arrayMerge(t, e, n) : Yo(t, e, n) : Gt(e, n);
}
kt.all = function(e, n) {
  if (!Array.isArray(e))
    throw new Error("first argument should be an array");
  return e.reduce(function(i, r) {
    return kt(i, r, n);
  }, {});
};
var wi = function(t, e) {
  return wi = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(n, i) {
    n.__proto__ = i;
  } || function(n, i) {
    for (var r in i) Object.prototype.hasOwnProperty.call(i, r) && (n[r] = i[r]);
  }, wi(t, e);
};
function Un(t, e) {
  if (typeof e != "function" && e !== null)
    throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
  wi(t, e);
  function n() {
    this.constructor = t;
  }
  t.prototype = e === null ? Object.create(e) : (n.prototype = e.prototype, new n());
}
var z = function() {
  return z = Object.assign || function(e) {
    for (var n, i = 1, r = arguments.length; i < r; i++) {
      n = arguments[i];
      for (var l in n) Object.prototype.hasOwnProperty.call(n, l) && (e[l] = n[l]);
    }
    return e;
  }, z.apply(this, arguments);
};
function Jn(t, e, n) {
  if (n || arguments.length === 2) for (var i = 0, r = e.length, l; i < r; i++)
    (l || !(i in e)) && (l || (l = Array.prototype.slice.call(e, 0, i)), l[i] = e[i]);
  return t.concat(l || Array.prototype.slice.call(e));
}
var R;
(function(t) {
  t[t.EXPECT_ARGUMENT_CLOSING_BRACE = 1] = "EXPECT_ARGUMENT_CLOSING_BRACE", t[t.EMPTY_ARGUMENT = 2] = "EMPTY_ARGUMENT", t[t.MALFORMED_ARGUMENT = 3] = "MALFORMED_ARGUMENT", t[t.EXPECT_ARGUMENT_TYPE = 4] = "EXPECT_ARGUMENT_TYPE", t[t.INVALID_ARGUMENT_TYPE = 5] = "INVALID_ARGUMENT_TYPE", t[t.EXPECT_ARGUMENT_STYLE = 6] = "EXPECT_ARGUMENT_STYLE", t[t.INVALID_NUMBER_SKELETON = 7] = "INVALID_NUMBER_SKELETON", t[t.INVALID_DATE_TIME_SKELETON = 8] = "INVALID_DATE_TIME_SKELETON", t[t.EXPECT_NUMBER_SKELETON = 9] = "EXPECT_NUMBER_SKELETON", t[t.EXPECT_DATE_TIME_SKELETON = 10] = "EXPECT_DATE_TIME_SKELETON", t[t.UNCLOSED_QUOTE_IN_ARGUMENT_STYLE = 11] = "UNCLOSED_QUOTE_IN_ARGUMENT_STYLE", t[t.EXPECT_SELECT_ARGUMENT_OPTIONS = 12] = "EXPECT_SELECT_ARGUMENT_OPTIONS", t[t.EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE = 13] = "EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE", t[t.INVALID_PLURAL_ARGUMENT_OFFSET_VALUE = 14] = "INVALID_PLURAL_ARGUMENT_OFFSET_VALUE", t[t.EXPECT_SELECT_ARGUMENT_SELECTOR = 15] = "EXPECT_SELECT_ARGUMENT_SELECTOR", t[t.EXPECT_PLURAL_ARGUMENT_SELECTOR = 16] = "EXPECT_PLURAL_ARGUMENT_SELECTOR", t[t.EXPECT_SELECT_ARGUMENT_SELECTOR_FRAGMENT = 17] = "EXPECT_SELECT_ARGUMENT_SELECTOR_FRAGMENT", t[t.EXPECT_PLURAL_ARGUMENT_SELECTOR_FRAGMENT = 18] = "EXPECT_PLURAL_ARGUMENT_SELECTOR_FRAGMENT", t[t.INVALID_PLURAL_ARGUMENT_SELECTOR = 19] = "INVALID_PLURAL_ARGUMENT_SELECTOR", t[t.DUPLICATE_PLURAL_ARGUMENT_SELECTOR = 20] = "DUPLICATE_PLURAL_ARGUMENT_SELECTOR", t[t.DUPLICATE_SELECT_ARGUMENT_SELECTOR = 21] = "DUPLICATE_SELECT_ARGUMENT_SELECTOR", t[t.MISSING_OTHER_CLAUSE = 22] = "MISSING_OTHER_CLAUSE", t[t.INVALID_TAG = 23] = "INVALID_TAG", t[t.INVALID_TAG_NAME = 25] = "INVALID_TAG_NAME", t[t.UNMATCHED_CLOSING_TAG = 26] = "UNMATCHED_CLOSING_TAG", t[t.UNCLOSED_TAG = 27] = "UNCLOSED_TAG";
})(R || (R = {}));
var K;
(function(t) {
  t[t.literal = 0] = "literal", t[t.argument = 1] = "argument", t[t.number = 2] = "number", t[t.date = 3] = "date", t[t.time = 4] = "time", t[t.select = 5] = "select", t[t.plural = 6] = "plural", t[t.pound = 7] = "pound", t[t.tag = 8] = "tag";
})(K || (K = {}));
var At;
(function(t) {
  t[t.number = 0] = "number", t[t.dateTime = 1] = "dateTime";
})(At || (At = {}));
function gr(t) {
  return t.type === K.literal;
}
function Jo(t) {
  return t.type === K.argument;
}
function ul(t) {
  return t.type === K.number;
}
function cl(t) {
  return t.type === K.date;
}
function hl(t) {
  return t.type === K.time;
}
function fl(t) {
  return t.type === K.select;
}
function _l(t) {
  return t.type === K.plural;
}
function Ko(t) {
  return t.type === K.pound;
}
function dl(t) {
  return t.type === K.tag;
}
function ml(t) {
  return !!(t && typeof t == "object" && t.type === At.number);
}
function Di(t) {
  return !!(t && typeof t == "object" && t.type === At.dateTime);
}
var pl = /[ \xA0\u1680\u2000-\u200A\u202F\u205F\u3000]/, es = /(?:[Eec]{1,6}|G{1,5}|[Qq]{1,5}|(?:[yYur]+|U{1,5})|[ML]{1,5}|d{1,2}|D{1,3}|F{1}|[abB]{1,5}|[hkHK]{1,2}|w{1,2}|W{1}|m{1,2}|s{1,2}|[zZOvVxX]{1,4})(?=([^']*'[^']*')*[^']*$)/g;
function ts(t) {
  var e = {};
  return t.replace(es, function(n) {
    var i = n.length;
    switch (n[0]) {
      case "G":
        e.era = i === 4 ? "long" : i === 5 ? "narrow" : "short";
        break;
      case "y":
        e.year = i === 2 ? "2-digit" : "numeric";
        break;
      case "Y":
      case "u":
      case "U":
      case "r":
        throw new RangeError("`Y/u/U/r` (year) patterns are not supported, use `y` instead");
      case "q":
      case "Q":
        throw new RangeError("`q/Q` (quarter) patterns are not supported");
      case "M":
      case "L":
        e.month = ["numeric", "2-digit", "short", "long", "narrow"][i - 1];
        break;
      case "w":
      case "W":
        throw new RangeError("`w/W` (week) patterns are not supported");
      case "d":
        e.day = ["numeric", "2-digit"][i - 1];
        break;
      case "D":
      case "F":
      case "g":
        throw new RangeError("`D/F/g` (day) patterns are not supported, use `d` instead");
      case "E":
        e.weekday = i === 4 ? "short" : i === 5 ? "narrow" : "short";
        break;
      case "e":
        if (i < 4)
          throw new RangeError("`e..eee` (weekday) patterns are not supported");
        e.weekday = ["short", "long", "narrow", "short"][i - 4];
        break;
      case "c":
        if (i < 4)
          throw new RangeError("`c..ccc` (weekday) patterns are not supported");
        e.weekday = ["short", "long", "narrow", "short"][i - 4];
        break;
      case "a":
        e.hour12 = !0;
        break;
      case "b":
      case "B":
        throw new RangeError("`b/B` (period) patterns are not supported, use `a` instead");
      case "h":
        e.hourCycle = "h12", e.hour = ["numeric", "2-digit"][i - 1];
        break;
      case "H":
        e.hourCycle = "h23", e.hour = ["numeric", "2-digit"][i - 1];
        break;
      case "K":
        e.hourCycle = "h11", e.hour = ["numeric", "2-digit"][i - 1];
        break;
      case "k":
        e.hourCycle = "h24", e.hour = ["numeric", "2-digit"][i - 1];
        break;
      case "j":
      case "J":
      case "C":
        throw new RangeError("`j/J/C` (hour) patterns are not supported, use `h/H/K/k` instead");
      case "m":
        e.minute = ["numeric", "2-digit"][i - 1];
        break;
      case "s":
        e.second = ["numeric", "2-digit"][i - 1];
        break;
      case "S":
      case "A":
        throw new RangeError("`S/A` (second) patterns are not supported, use `s` instead");
      case "z":
        e.timeZoneName = i < 4 ? "short" : "long";
        break;
      case "Z":
      case "O":
      case "v":
      case "V":
      case "X":
      case "x":
        throw new RangeError("`Z/O/v/V/X/x` (timeZone) patterns are not supported, use `z` instead");
    }
    return "";
  }), e;
}
var ns = /[\t-\r \x85\u200E\u200F\u2028\u2029]/i;
function is(t) {
  if (t.length === 0)
    throw new Error("Number skeleton cannot be empty");
  for (var e = t.split(ns).filter(function(h) {
    return h.length > 0;
  }), n = [], i = 0, r = e; i < r.length; i++) {
    var l = r[i], a = l.split("/");
    if (a.length === 0)
      throw new Error("Invalid number skeleton");
    for (var o = a[0], s = a.slice(1), u = 0, c = s; u < c.length; u++) {
      var _ = c[u];
      if (_.length === 0)
        throw new Error("Invalid number skeleton");
    }
    n.push({ stem: o, options: s });
  }
  return n;
}
function rs(t) {
  return t.replace(/^(.*?)-/, "");
}
var br = /^\.(?:(0+)(\*)?|(#+)|(0+)(#+))$/g, gl = /^(@+)?(\+|#+)?[rs]?$/g, as = /(\*)(0+)|(#+)(0+)|(0+)/g, bl = /^(0+)$/;
function vr(t) {
  var e = {};
  return t[t.length - 1] === "r" ? e.roundingPriority = "morePrecision" : t[t.length - 1] === "s" && (e.roundingPriority = "lessPrecision"), t.replace(gl, function(n, i, r) {
    return typeof r != "string" ? (e.minimumSignificantDigits = i.length, e.maximumSignificantDigits = i.length) : r === "+" ? e.minimumSignificantDigits = i.length : i[0] === "#" ? e.maximumSignificantDigits = i.length : (e.minimumSignificantDigits = i.length, e.maximumSignificantDigits = i.length + (typeof r == "string" ? r.length : 0)), "";
  }), e;
}
function vl(t) {
  switch (t) {
    case "sign-auto":
      return {
        signDisplay: "auto"
      };
    case "sign-accounting":
    case "()":
      return {
        currencySign: "accounting"
      };
    case "sign-always":
    case "+!":
      return {
        signDisplay: "always"
      };
    case "sign-accounting-always":
    case "()!":
      return {
        signDisplay: "always",
        currencySign: "accounting"
      };
    case "sign-except-zero":
    case "+?":
      return {
        signDisplay: "exceptZero"
      };
    case "sign-accounting-except-zero":
    case "()?":
      return {
        signDisplay: "exceptZero",
        currencySign: "accounting"
      };
    case "sign-never":
    case "+_":
      return {
        signDisplay: "never"
      };
  }
}
function ls(t) {
  var e;
  if (t[0] === "E" && t[1] === "E" ? (e = {
    notation: "engineering"
  }, t = t.slice(2)) : t[0] === "E" && (e = {
    notation: "scientific"
  }, t = t.slice(1)), e) {
    var n = t.slice(0, 2);
    if (n === "+!" ? (e.signDisplay = "always", t = t.slice(2)) : n === "+?" && (e.signDisplay = "exceptZero", t = t.slice(2)), !bl.test(t))
      throw new Error("Malformed concise eng/scientific notation");
    e.minimumIntegerDigits = t.length;
  }
  return e;
}
function yr(t) {
  var e = {}, n = vl(t);
  return n || e;
}
function os(t) {
  for (var e = {}, n = 0, i = t; n < i.length; n++) {
    var r = i[n];
    switch (r.stem) {
      case "percent":
      case "%":
        e.style = "percent";
        continue;
      case "%x100":
        e.style = "percent", e.scale = 100;
        continue;
      case "currency":
        e.style = "currency", e.currency = r.options[0];
        continue;
      case "group-off":
      case ",_":
        e.useGrouping = !1;
        continue;
      case "precision-integer":
      case ".":
        e.maximumFractionDigits = 0;
        continue;
      case "measure-unit":
      case "unit":
        e.style = "unit", e.unit = rs(r.options[0]);
        continue;
      case "compact-short":
      case "K":
        e.notation = "compact", e.compactDisplay = "short";
        continue;
      case "compact-long":
      case "KK":
        e.notation = "compact", e.compactDisplay = "long";
        continue;
      case "scientific":
        e = z(z(z({}, e), { notation: "scientific" }), r.options.reduce(function(s, u) {
          return z(z({}, s), yr(u));
        }, {}));
        continue;
      case "engineering":
        e = z(z(z({}, e), { notation: "engineering" }), r.options.reduce(function(s, u) {
          return z(z({}, s), yr(u));
        }, {}));
        continue;
      case "notation-simple":
        e.notation = "standard";
        continue;
      case "unit-width-narrow":
        e.currencyDisplay = "narrowSymbol", e.unitDisplay = "narrow";
        continue;
      case "unit-width-short":
        e.currencyDisplay = "code", e.unitDisplay = "short";
        continue;
      case "unit-width-full-name":
        e.currencyDisplay = "name", e.unitDisplay = "long";
        continue;
      case "unit-width-iso-code":
        e.currencyDisplay = "symbol";
        continue;
      case "scale":
        e.scale = parseFloat(r.options[0]);
        continue;
      case "integer-width":
        if (r.options.length > 1)
          throw new RangeError("integer-width stems only accept a single optional option");
        r.options[0].replace(as, function(s, u, c, _, h, d) {
          if (u)
            e.minimumIntegerDigits = c.length;
          else {
            if (_ && h)
              throw new Error("We currently do not support maximum integer digits");
            if (d)
              throw new Error("We currently do not support exact integer digits");
          }
          return "";
        });
        continue;
    }
    if (bl.test(r.stem)) {
      e.minimumIntegerDigits = r.stem.length;
      continue;
    }
    if (br.test(r.stem)) {
      if (r.options.length > 1)
        throw new RangeError("Fraction-precision stems only accept a single optional option");
      r.stem.replace(br, function(s, u, c, _, h, d) {
        return c === "*" ? e.minimumFractionDigits = u.length : _ && _[0] === "#" ? e.maximumFractionDigits = _.length : h && d ? (e.minimumFractionDigits = h.length, e.maximumFractionDigits = h.length + d.length) : (e.minimumFractionDigits = u.length, e.maximumFractionDigits = u.length), "";
      });
      var l = r.options[0];
      l === "w" ? e = z(z({}, e), { trailingZeroDisplay: "stripIfInteger" }) : l && (e = z(z({}, e), vr(l)));
      continue;
    }
    if (gl.test(r.stem)) {
      e = z(z({}, e), vr(r.stem));
      continue;
    }
    var a = vl(r.stem);
    a && (e = z(z({}, e), a));
    var o = ls(r.stem);
    o && (e = z(z({}, e), o));
  }
  return e;
}
var sn = {
  AX: [
    "H"
  ],
  BQ: [
    "H"
  ],
  CP: [
    "H"
  ],
  CZ: [
    "H"
  ],
  DK: [
    "H"
  ],
  FI: [
    "H"
  ],
  ID: [
    "H"
  ],
  IS: [
    "H"
  ],
  ML: [
    "H"
  ],
  NE: [
    "H"
  ],
  RU: [
    "H"
  ],
  SE: [
    "H"
  ],
  SJ: [
    "H"
  ],
  SK: [
    "H"
  ],
  AS: [
    "h",
    "H"
  ],
  BT: [
    "h",
    "H"
  ],
  DJ: [
    "h",
    "H"
  ],
  ER: [
    "h",
    "H"
  ],
  GH: [
    "h",
    "H"
  ],
  IN: [
    "h",
    "H"
  ],
  LS: [
    "h",
    "H"
  ],
  PG: [
    "h",
    "H"
  ],
  PW: [
    "h",
    "H"
  ],
  SO: [
    "h",
    "H"
  ],
  TO: [
    "h",
    "H"
  ],
  VU: [
    "h",
    "H"
  ],
  WS: [
    "h",
    "H"
  ],
  "001": [
    "H",
    "h"
  ],
  AL: [
    "h",
    "H",
    "hB"
  ],
  TD: [
    "h",
    "H",
    "hB"
  ],
  "ca-ES": [
    "H",
    "h",
    "hB"
  ],
  CF: [
    "H",
    "h",
    "hB"
  ],
  CM: [
    "H",
    "h",
    "hB"
  ],
  "fr-CA": [
    "H",
    "h",
    "hB"
  ],
  "gl-ES": [
    "H",
    "h",
    "hB"
  ],
  "it-CH": [
    "H",
    "h",
    "hB"
  ],
  "it-IT": [
    "H",
    "h",
    "hB"
  ],
  LU: [
    "H",
    "h",
    "hB"
  ],
  NP: [
    "H",
    "h",
    "hB"
  ],
  PF: [
    "H",
    "h",
    "hB"
  ],
  SC: [
    "H",
    "h",
    "hB"
  ],
  SM: [
    "H",
    "h",
    "hB"
  ],
  SN: [
    "H",
    "h",
    "hB"
  ],
  TF: [
    "H",
    "h",
    "hB"
  ],
  VA: [
    "H",
    "h",
    "hB"
  ],
  CY: [
    "h",
    "H",
    "hb",
    "hB"
  ],
  GR: [
    "h",
    "H",
    "hb",
    "hB"
  ],
  CO: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  DO: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  KP: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  KR: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  NA: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  PA: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  PR: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  VE: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  AC: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  AI: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  BW: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  BZ: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  CC: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  CK: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  CX: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  DG: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  FK: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  GB: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  GG: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  GI: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  IE: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  IM: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  IO: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  JE: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  LT: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  MK: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  MN: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  MS: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  NF: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  NG: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  NR: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  NU: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  PN: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  SH: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  SX: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  TA: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  ZA: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  "af-ZA": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  AR: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  CL: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  CR: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  CU: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  EA: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-BO": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-BR": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-EC": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-ES": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-GQ": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-PE": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  GT: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  HN: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  IC: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  KG: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  KM: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  LK: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  MA: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  MX: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  NI: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  PY: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  SV: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  UY: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  JP: [
    "H",
    "h",
    "K"
  ],
  AD: [
    "H",
    "hB"
  ],
  AM: [
    "H",
    "hB"
  ],
  AO: [
    "H",
    "hB"
  ],
  AT: [
    "H",
    "hB"
  ],
  AW: [
    "H",
    "hB"
  ],
  BE: [
    "H",
    "hB"
  ],
  BF: [
    "H",
    "hB"
  ],
  BJ: [
    "H",
    "hB"
  ],
  BL: [
    "H",
    "hB"
  ],
  BR: [
    "H",
    "hB"
  ],
  CG: [
    "H",
    "hB"
  ],
  CI: [
    "H",
    "hB"
  ],
  CV: [
    "H",
    "hB"
  ],
  DE: [
    "H",
    "hB"
  ],
  EE: [
    "H",
    "hB"
  ],
  FR: [
    "H",
    "hB"
  ],
  GA: [
    "H",
    "hB"
  ],
  GF: [
    "H",
    "hB"
  ],
  GN: [
    "H",
    "hB"
  ],
  GP: [
    "H",
    "hB"
  ],
  GW: [
    "H",
    "hB"
  ],
  HR: [
    "H",
    "hB"
  ],
  IL: [
    "H",
    "hB"
  ],
  IT: [
    "H",
    "hB"
  ],
  KZ: [
    "H",
    "hB"
  ],
  MC: [
    "H",
    "hB"
  ],
  MD: [
    "H",
    "hB"
  ],
  MF: [
    "H",
    "hB"
  ],
  MQ: [
    "H",
    "hB"
  ],
  MZ: [
    "H",
    "hB"
  ],
  NC: [
    "H",
    "hB"
  ],
  NL: [
    "H",
    "hB"
  ],
  PM: [
    "H",
    "hB"
  ],
  PT: [
    "H",
    "hB"
  ],
  RE: [
    "H",
    "hB"
  ],
  RO: [
    "H",
    "hB"
  ],
  SI: [
    "H",
    "hB"
  ],
  SR: [
    "H",
    "hB"
  ],
  ST: [
    "H",
    "hB"
  ],
  TG: [
    "H",
    "hB"
  ],
  TR: [
    "H",
    "hB"
  ],
  WF: [
    "H",
    "hB"
  ],
  YT: [
    "H",
    "hB"
  ],
  BD: [
    "h",
    "hB",
    "H"
  ],
  PK: [
    "h",
    "hB",
    "H"
  ],
  AZ: [
    "H",
    "hB",
    "h"
  ],
  BA: [
    "H",
    "hB",
    "h"
  ],
  BG: [
    "H",
    "hB",
    "h"
  ],
  CH: [
    "H",
    "hB",
    "h"
  ],
  GE: [
    "H",
    "hB",
    "h"
  ],
  LI: [
    "H",
    "hB",
    "h"
  ],
  ME: [
    "H",
    "hB",
    "h"
  ],
  RS: [
    "H",
    "hB",
    "h"
  ],
  UA: [
    "H",
    "hB",
    "h"
  ],
  UZ: [
    "H",
    "hB",
    "h"
  ],
  XK: [
    "H",
    "hB",
    "h"
  ],
  AG: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  AU: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  BB: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  BM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  BS: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  CA: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  DM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  "en-001": [
    "h",
    "hb",
    "H",
    "hB"
  ],
  FJ: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  FM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  GD: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  GM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  GU: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  GY: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  JM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  KI: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  KN: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  KY: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  LC: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  LR: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  MH: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  MP: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  MW: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  NZ: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  SB: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  SG: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  SL: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  SS: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  SZ: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  TC: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  TT: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  UM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  US: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  VC: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  VG: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  VI: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  ZM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  BO: [
    "H",
    "hB",
    "h",
    "hb"
  ],
  EC: [
    "H",
    "hB",
    "h",
    "hb"
  ],
  ES: [
    "H",
    "hB",
    "h",
    "hb"
  ],
  GQ: [
    "H",
    "hB",
    "h",
    "hb"
  ],
  PE: [
    "H",
    "hB",
    "h",
    "hb"
  ],
  AE: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  "ar-001": [
    "h",
    "hB",
    "hb",
    "H"
  ],
  BH: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  DZ: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  EG: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  EH: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  HK: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  IQ: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  JO: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  KW: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  LB: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  LY: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  MO: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  MR: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  OM: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  PH: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  PS: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  QA: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  SA: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  SD: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  SY: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  TN: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  YE: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  AF: [
    "H",
    "hb",
    "hB",
    "h"
  ],
  LA: [
    "H",
    "hb",
    "hB",
    "h"
  ],
  CN: [
    "H",
    "hB",
    "hb",
    "h"
  ],
  LV: [
    "H",
    "hB",
    "hb",
    "h"
  ],
  TL: [
    "H",
    "hB",
    "hb",
    "h"
  ],
  "zu-ZA": [
    "H",
    "hB",
    "hb",
    "h"
  ],
  CD: [
    "hB",
    "H"
  ],
  IR: [
    "hB",
    "H"
  ],
  "hi-IN": [
    "hB",
    "h",
    "H"
  ],
  "kn-IN": [
    "hB",
    "h",
    "H"
  ],
  "ml-IN": [
    "hB",
    "h",
    "H"
  ],
  "te-IN": [
    "hB",
    "h",
    "H"
  ],
  KH: [
    "hB",
    "h",
    "H",
    "hb"
  ],
  "ta-IN": [
    "hB",
    "h",
    "hb",
    "H"
  ],
  BN: [
    "hb",
    "hB",
    "h",
    "H"
  ],
  MY: [
    "hb",
    "hB",
    "h",
    "H"
  ],
  ET: [
    "hB",
    "hb",
    "h",
    "H"
  ],
  "gu-IN": [
    "hB",
    "hb",
    "h",
    "H"
  ],
  "mr-IN": [
    "hB",
    "hb",
    "h",
    "H"
  ],
  "pa-IN": [
    "hB",
    "hb",
    "h",
    "H"
  ],
  TW: [
    "hB",
    "hb",
    "h",
    "H"
  ],
  KE: [
    "hB",
    "hb",
    "H",
    "h"
  ],
  MM: [
    "hB",
    "hb",
    "H",
    "h"
  ],
  TZ: [
    "hB",
    "hb",
    "H",
    "h"
  ],
  UG: [
    "hB",
    "hb",
    "H",
    "h"
  ]
};
function ss(t, e) {
  for (var n = "", i = 0; i < t.length; i++) {
    var r = t.charAt(i);
    if (r === "j") {
      for (var l = 0; i + 1 < t.length && t.charAt(i + 1) === r; )
        l++, i++;
      var a = 1 + (l & 1), o = l < 2 ? 1 : 3 + (l >> 1), s = "a", u = us(e);
      for ((u == "H" || u == "k") && (o = 0); o-- > 0; )
        n += s;
      for (; a-- > 0; )
        n = u + n;
    } else r === "J" ? n += "H" : n += r;
  }
  return n;
}
function us(t) {
  var e = t.hourCycle;
  if (e === void 0 && // @ts-ignore hourCycle(s) is not identified yet
  t.hourCycles && // @ts-ignore
  t.hourCycles.length && (e = t.hourCycles[0]), e)
    switch (e) {
      case "h24":
        return "k";
      case "h23":
        return "H";
      case "h12":
        return "h";
      case "h11":
        return "K";
      default:
        throw new Error("Invalid hourCycle");
    }
  var n = t.language, i;
  n !== "root" && (i = t.maximize().region);
  var r = sn[i || ""] || sn[n || ""] || sn["".concat(n, "-001")] || sn["001"];
  return r[0];
}
var Kn, cs = new RegExp("^".concat(pl.source, "*")), hs = new RegExp("".concat(pl.source, "*$"));
function M(t, e) {
  return { start: t, end: e };
}
var fs = !!String.prototype.startsWith, _s = !!String.fromCodePoint, ds = !!Object.fromEntries, ms = !!String.prototype.codePointAt, ps = !!String.prototype.trimStart, gs = !!String.prototype.trimEnd, bs = !!Number.isSafeInteger, vs = bs ? Number.isSafeInteger : function(t) {
  return typeof t == "number" && isFinite(t) && Math.floor(t) === t && Math.abs(t) <= 9007199254740991;
}, Ei = !0;
try {
  var ys = wl("([^\\p{White_Space}\\p{Pattern_Syntax}]*)", "yu");
  Ei = ((Kn = ys.exec("a")) === null || Kn === void 0 ? void 0 : Kn[0]) === "a";
} catch {
  Ei = !1;
}
var wr = fs ? (
  // Native
  function(e, n, i) {
    return e.startsWith(n, i);
  }
) : (
  // For IE11
  function(e, n, i) {
    return e.slice(i, i + n.length) === n;
  }
), Fi = _s ? String.fromCodePoint : (
  // IE11
  function() {
    for (var e = [], n = 0; n < arguments.length; n++)
      e[n] = arguments[n];
    for (var i = "", r = e.length, l = 0, a; r > l; ) {
      if (a = e[l++], a > 1114111)
        throw RangeError(a + " is not a valid code point");
      i += a < 65536 ? String.fromCharCode(a) : String.fromCharCode(((a -= 65536) >> 10) + 55296, a % 1024 + 56320);
    }
    return i;
  }
), Dr = (
  // native
  ds ? Object.fromEntries : (
    // Ponyfill
    function(e) {
      for (var n = {}, i = 0, r = e; i < r.length; i++) {
        var l = r[i], a = l[0], o = l[1];
        n[a] = o;
      }
      return n;
    }
  )
), yl = ms ? (
  // Native
  function(e, n) {
    return e.codePointAt(n);
  }
) : (
  // IE 11
  function(e, n) {
    var i = e.length;
    if (!(n < 0 || n >= i)) {
      var r = e.charCodeAt(n), l;
      return r < 55296 || r > 56319 || n + 1 === i || (l = e.charCodeAt(n + 1)) < 56320 || l > 57343 ? r : (r - 55296 << 10) + (l - 56320) + 65536;
    }
  }
), ws = ps ? (
  // Native
  function(e) {
    return e.trimStart();
  }
) : (
  // Ponyfill
  function(e) {
    return e.replace(cs, "");
  }
), Ds = gs ? (
  // Native
  function(e) {
    return e.trimEnd();
  }
) : (
  // Ponyfill
  function(e) {
    return e.replace(hs, "");
  }
);
function wl(t, e) {
  return new RegExp(t, e);
}
var ki;
if (Ei) {
  var Er = wl("([^\\p{White_Space}\\p{Pattern_Syntax}]*)", "yu");
  ki = function(e, n) {
    var i;
    Er.lastIndex = n;
    var r = Er.exec(e);
    return (i = r[1]) !== null && i !== void 0 ? i : "";
  };
} else
  ki = function(e, n) {
    for (var i = []; ; ) {
      var r = yl(e, n);
      if (r === void 0 || Dl(r) || As(r))
        break;
      i.push(r), n += r >= 65536 ? 2 : 1;
    }
    return Fi.apply(void 0, i);
  };
var Es = (
  /** @class */
  function() {
    function t(e, n) {
      n === void 0 && (n = {}), this.message = e, this.position = { offset: 0, line: 1, column: 1 }, this.ignoreTag = !!n.ignoreTag, this.locale = n.locale, this.requiresOtherClause = !!n.requiresOtherClause, this.shouldParseSkeletons = !!n.shouldParseSkeletons;
    }
    return t.prototype.parse = function() {
      if (this.offset() !== 0)
        throw Error("parser can only be used once");
      return this.parseMessage(0, "", !1);
    }, t.prototype.parseMessage = function(e, n, i) {
      for (var r = []; !this.isEOF(); ) {
        var l = this.char();
        if (l === 123) {
          var a = this.parseArgument(e, i);
          if (a.err)
            return a;
          r.push(a.val);
        } else {
          if (l === 125 && e > 0)
            break;
          if (l === 35 && (n === "plural" || n === "selectordinal")) {
            var o = this.clonePosition();
            this.bump(), r.push({
              type: K.pound,
              location: M(o, this.clonePosition())
            });
          } else if (l === 60 && !this.ignoreTag && this.peek() === 47) {
            if (i)
              break;
            return this.error(R.UNMATCHED_CLOSING_TAG, M(this.clonePosition(), this.clonePosition()));
          } else if (l === 60 && !this.ignoreTag && Ai(this.peek() || 0)) {
            var a = this.parseTag(e, n);
            if (a.err)
              return a;
            r.push(a.val);
          } else {
            var a = this.parseLiteral(e, n);
            if (a.err)
              return a;
            r.push(a.val);
          }
        }
      }
      return { val: r, err: null };
    }, t.prototype.parseTag = function(e, n) {
      var i = this.clonePosition();
      this.bump();
      var r = this.parseTagName();
      if (this.bumpSpace(), this.bumpIf("/>"))
        return {
          val: {
            type: K.literal,
            value: "<".concat(r, "/>"),
            location: M(i, this.clonePosition())
          },
          err: null
        };
      if (this.bumpIf(">")) {
        var l = this.parseMessage(e + 1, n, !0);
        if (l.err)
          return l;
        var a = l.val, o = this.clonePosition();
        if (this.bumpIf("</")) {
          if (this.isEOF() || !Ai(this.char()))
            return this.error(R.INVALID_TAG, M(o, this.clonePosition()));
          var s = this.clonePosition(), u = this.parseTagName();
          return r !== u ? this.error(R.UNMATCHED_CLOSING_TAG, M(s, this.clonePosition())) : (this.bumpSpace(), this.bumpIf(">") ? {
            val: {
              type: K.tag,
              value: r,
              children: a,
              location: M(i, this.clonePosition())
            },
            err: null
          } : this.error(R.INVALID_TAG, M(o, this.clonePosition())));
        } else
          return this.error(R.UNCLOSED_TAG, M(i, this.clonePosition()));
      } else
        return this.error(R.INVALID_TAG, M(i, this.clonePosition()));
    }, t.prototype.parseTagName = function() {
      var e = this.offset();
      for (this.bump(); !this.isEOF() && ks(this.char()); )
        this.bump();
      return this.message.slice(e, this.offset());
    }, t.prototype.parseLiteral = function(e, n) {
      for (var i = this.clonePosition(), r = ""; ; ) {
        var l = this.tryParseQuote(n);
        if (l) {
          r += l;
          continue;
        }
        var a = this.tryParseUnquoted(e, n);
        if (a) {
          r += a;
          continue;
        }
        var o = this.tryParseLeftAngleBracket();
        if (o) {
          r += o;
          continue;
        }
        break;
      }
      var s = M(i, this.clonePosition());
      return {
        val: { type: K.literal, value: r, location: s },
        err: null
      };
    }, t.prototype.tryParseLeftAngleBracket = function() {
      return !this.isEOF() && this.char() === 60 && (this.ignoreTag || // If at the opening tag or closing tag position, bail.
      !Fs(this.peek() || 0)) ? (this.bump(), "<") : null;
    }, t.prototype.tryParseQuote = function(e) {
      if (this.isEOF() || this.char() !== 39)
        return null;
      switch (this.peek()) {
        case 39:
          return this.bump(), this.bump(), "'";
        case 123:
        case 60:
        case 62:
        case 125:
          break;
        case 35:
          if (e === "plural" || e === "selectordinal")
            break;
          return null;
        default:
          return null;
      }
      this.bump();
      var n = [this.char()];
      for (this.bump(); !this.isEOF(); ) {
        var i = this.char();
        if (i === 39)
          if (this.peek() === 39)
            n.push(39), this.bump();
          else {
            this.bump();
            break;
          }
        else
          n.push(i);
        this.bump();
      }
      return Fi.apply(void 0, n);
    }, t.prototype.tryParseUnquoted = function(e, n) {
      if (this.isEOF())
        return null;
      var i = this.char();
      return i === 60 || i === 123 || i === 35 && (n === "plural" || n === "selectordinal") || i === 125 && e > 0 ? null : (this.bump(), Fi(i));
    }, t.prototype.parseArgument = function(e, n) {
      var i = this.clonePosition();
      if (this.bump(), this.bumpSpace(), this.isEOF())
        return this.error(R.EXPECT_ARGUMENT_CLOSING_BRACE, M(i, this.clonePosition()));
      if (this.char() === 125)
        return this.bump(), this.error(R.EMPTY_ARGUMENT, M(i, this.clonePosition()));
      var r = this.parseIdentifierIfPossible().value;
      if (!r)
        return this.error(R.MALFORMED_ARGUMENT, M(i, this.clonePosition()));
      if (this.bumpSpace(), this.isEOF())
        return this.error(R.EXPECT_ARGUMENT_CLOSING_BRACE, M(i, this.clonePosition()));
      switch (this.char()) {
        case 125:
          return this.bump(), {
            val: {
              type: K.argument,
              // value does not include the opening and closing braces.
              value: r,
              location: M(i, this.clonePosition())
            },
            err: null
          };
        case 44:
          return this.bump(), this.bumpSpace(), this.isEOF() ? this.error(R.EXPECT_ARGUMENT_CLOSING_BRACE, M(i, this.clonePosition())) : this.parseArgumentOptions(e, n, r, i);
        default:
          return this.error(R.MALFORMED_ARGUMENT, M(i, this.clonePosition()));
      }
    }, t.prototype.parseIdentifierIfPossible = function() {
      var e = this.clonePosition(), n = this.offset(), i = ki(this.message, n), r = n + i.length;
      this.bumpTo(r);
      var l = this.clonePosition(), a = M(e, l);
      return { value: i, location: a };
    }, t.prototype.parseArgumentOptions = function(e, n, i, r) {
      var l, a = this.clonePosition(), o = this.parseIdentifierIfPossible().value, s = this.clonePosition();
      switch (o) {
        case "":
          return this.error(R.EXPECT_ARGUMENT_TYPE, M(a, s));
        case "number":
        case "date":
        case "time": {
          this.bumpSpace();
          var u = null;
          if (this.bumpIf(",")) {
            this.bumpSpace();
            var c = this.clonePosition(), _ = this.parseSimpleArgStyleIfPossible();
            if (_.err)
              return _;
            var h = Ds(_.val);
            if (h.length === 0)
              return this.error(R.EXPECT_ARGUMENT_STYLE, M(this.clonePosition(), this.clonePosition()));
            var d = M(c, this.clonePosition());
            u = { style: h, styleLocation: d };
          }
          var D = this.tryParseArgumentClose(r);
          if (D.err)
            return D;
          var E = M(r, this.clonePosition());
          if (u && wr(u == null ? void 0 : u.style, "::", 0)) {
            var F = ws(u.style.slice(2));
            if (o === "number") {
              var _ = this.parseNumberSkeletonFromString(F, u.styleLocation);
              return _.err ? _ : {
                val: { type: K.number, value: i, location: E, style: _.val },
                err: null
              };
            } else {
              if (F.length === 0)
                return this.error(R.EXPECT_DATE_TIME_SKELETON, E);
              var C = F;
              this.locale && (C = ss(F, this.locale));
              var h = {
                type: At.dateTime,
                pattern: C,
                location: u.styleLocation,
                parsedOptions: this.shouldParseSkeletons ? ts(C) : {}
              }, g = o === "date" ? K.date : K.time;
              return {
                val: { type: g, value: i, location: E, style: h },
                err: null
              };
            }
          }
          return {
            val: {
              type: o === "number" ? K.number : o === "date" ? K.date : K.time,
              value: i,
              location: E,
              style: (l = u == null ? void 0 : u.style) !== null && l !== void 0 ? l : null
            },
            err: null
          };
        }
        case "plural":
        case "selectordinal":
        case "select": {
          var f = this.clonePosition();
          if (this.bumpSpace(), !this.bumpIf(","))
            return this.error(R.EXPECT_SELECT_ARGUMENT_OPTIONS, M(f, z({}, f)));
          this.bumpSpace();
          var m = this.parseIdentifierIfPossible(), v = 0;
          if (o !== "select" && m.value === "offset") {
            if (!this.bumpIf(":"))
              return this.error(R.EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE, M(this.clonePosition(), this.clonePosition()));
            this.bumpSpace();
            var _ = this.tryParseDecimalInteger(R.EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE, R.INVALID_PLURAL_ARGUMENT_OFFSET_VALUE);
            if (_.err)
              return _;
            this.bumpSpace(), m = this.parseIdentifierIfPossible(), v = _.val;
          }
          var p = this.tryParsePluralOrSelectOptions(e, o, n, m);
          if (p.err)
            return p;
          var D = this.tryParseArgumentClose(r);
          if (D.err)
            return D;
          var b = M(r, this.clonePosition());
          return o === "select" ? {
            val: {
              type: K.select,
              value: i,
              options: Dr(p.val),
              location: b
            },
            err: null
          } : {
            val: {
              type: K.plural,
              value: i,
              options: Dr(p.val),
              offset: v,
              pluralType: o === "plural" ? "cardinal" : "ordinal",
              location: b
            },
            err: null
          };
        }
        default:
          return this.error(R.INVALID_ARGUMENT_TYPE, M(a, s));
      }
    }, t.prototype.tryParseArgumentClose = function(e) {
      return this.isEOF() || this.char() !== 125 ? this.error(R.EXPECT_ARGUMENT_CLOSING_BRACE, M(e, this.clonePosition())) : (this.bump(), { val: !0, err: null });
    }, t.prototype.parseSimpleArgStyleIfPossible = function() {
      for (var e = 0, n = this.clonePosition(); !this.isEOF(); ) {
        var i = this.char();
        switch (i) {
          case 39: {
            this.bump();
            var r = this.clonePosition();
            if (!this.bumpUntil("'"))
              return this.error(R.UNCLOSED_QUOTE_IN_ARGUMENT_STYLE, M(r, this.clonePosition()));
            this.bump();
            break;
          }
          case 123: {
            e += 1, this.bump();
            break;
          }
          case 125: {
            if (e > 0)
              e -= 1;
            else
              return {
                val: this.message.slice(n.offset, this.offset()),
                err: null
              };
            break;
          }
          default:
            this.bump();
            break;
        }
      }
      return {
        val: this.message.slice(n.offset, this.offset()),
        err: null
      };
    }, t.prototype.parseNumberSkeletonFromString = function(e, n) {
      var i = [];
      try {
        i = is(e);
      } catch {
        return this.error(R.INVALID_NUMBER_SKELETON, n);
      }
      return {
        val: {
          type: At.number,
          tokens: i,
          location: n,
          parsedOptions: this.shouldParseSkeletons ? os(i) : {}
        },
        err: null
      };
    }, t.prototype.tryParsePluralOrSelectOptions = function(e, n, i, r) {
      for (var l, a = !1, o = [], s = /* @__PURE__ */ new Set(), u = r.value, c = r.location; ; ) {
        if (u.length === 0) {
          var _ = this.clonePosition();
          if (n !== "select" && this.bumpIf("=")) {
            var h = this.tryParseDecimalInteger(R.EXPECT_PLURAL_ARGUMENT_SELECTOR, R.INVALID_PLURAL_ARGUMENT_SELECTOR);
            if (h.err)
              return h;
            c = M(_, this.clonePosition()), u = this.message.slice(_.offset, this.offset());
          } else
            break;
        }
        if (s.has(u))
          return this.error(n === "select" ? R.DUPLICATE_SELECT_ARGUMENT_SELECTOR : R.DUPLICATE_PLURAL_ARGUMENT_SELECTOR, c);
        u === "other" && (a = !0), this.bumpSpace();
        var d = this.clonePosition();
        if (!this.bumpIf("{"))
          return this.error(n === "select" ? R.EXPECT_SELECT_ARGUMENT_SELECTOR_FRAGMENT : R.EXPECT_PLURAL_ARGUMENT_SELECTOR_FRAGMENT, M(this.clonePosition(), this.clonePosition()));
        var D = this.parseMessage(e + 1, n, i);
        if (D.err)
          return D;
        var E = this.tryParseArgumentClose(d);
        if (E.err)
          return E;
        o.push([
          u,
          {
            value: D.val,
            location: M(d, this.clonePosition())
          }
        ]), s.add(u), this.bumpSpace(), l = this.parseIdentifierIfPossible(), u = l.value, c = l.location;
      }
      return o.length === 0 ? this.error(n === "select" ? R.EXPECT_SELECT_ARGUMENT_SELECTOR : R.EXPECT_PLURAL_ARGUMENT_SELECTOR, M(this.clonePosition(), this.clonePosition())) : this.requiresOtherClause && !a ? this.error(R.MISSING_OTHER_CLAUSE, M(this.clonePosition(), this.clonePosition())) : { val: o, err: null };
    }, t.prototype.tryParseDecimalInteger = function(e, n) {
      var i = 1, r = this.clonePosition();
      this.bumpIf("+") || this.bumpIf("-") && (i = -1);
      for (var l = !1, a = 0; !this.isEOF(); ) {
        var o = this.char();
        if (o >= 48 && o <= 57)
          l = !0, a = a * 10 + (o - 48), this.bump();
        else
          break;
      }
      var s = M(r, this.clonePosition());
      return l ? (a *= i, vs(a) ? { val: a, err: null } : this.error(n, s)) : this.error(e, s);
    }, t.prototype.offset = function() {
      return this.position.offset;
    }, t.prototype.isEOF = function() {
      return this.offset() === this.message.length;
    }, t.prototype.clonePosition = function() {
      return {
        offset: this.position.offset,
        line: this.position.line,
        column: this.position.column
      };
    }, t.prototype.char = function() {
      var e = this.position.offset;
      if (e >= this.message.length)
        throw Error("out of bound");
      var n = yl(this.message, e);
      if (n === void 0)
        throw Error("Offset ".concat(e, " is at invalid UTF-16 code unit boundary"));
      return n;
    }, t.prototype.error = function(e, n) {
      return {
        val: null,
        err: {
          kind: e,
          message: this.message,
          location: n
        }
      };
    }, t.prototype.bump = function() {
      if (!this.isEOF()) {
        var e = this.char();
        e === 10 ? (this.position.line += 1, this.position.column = 1, this.position.offset += 1) : (this.position.column += 1, this.position.offset += e < 65536 ? 1 : 2);
      }
    }, t.prototype.bumpIf = function(e) {
      if (wr(this.message, e, this.offset())) {
        for (var n = 0; n < e.length; n++)
          this.bump();
        return !0;
      }
      return !1;
    }, t.prototype.bumpUntil = function(e) {
      var n = this.offset(), i = this.message.indexOf(e, n);
      return i >= 0 ? (this.bumpTo(i), !0) : (this.bumpTo(this.message.length), !1);
    }, t.prototype.bumpTo = function(e) {
      if (this.offset() > e)
        throw Error("targetOffset ".concat(e, " must be greater than or equal to the current offset ").concat(this.offset()));
      for (e = Math.min(e, this.message.length); ; ) {
        var n = this.offset();
        if (n === e)
          break;
        if (n > e)
          throw Error("targetOffset ".concat(e, " is at invalid UTF-16 code unit boundary"));
        if (this.bump(), this.isEOF())
          break;
      }
    }, t.prototype.bumpSpace = function() {
      for (; !this.isEOF() && Dl(this.char()); )
        this.bump();
    }, t.prototype.peek = function() {
      if (this.isEOF())
        return null;
      var e = this.char(), n = this.offset(), i = this.message.charCodeAt(n + (e >= 65536 ? 2 : 1));
      return i ?? null;
    }, t;
  }()
);
function Ai(t) {
  return t >= 97 && t <= 122 || t >= 65 && t <= 90;
}
function Fs(t) {
  return Ai(t) || t === 47;
}
function ks(t) {
  return t === 45 || t === 46 || t >= 48 && t <= 57 || t === 95 || t >= 97 && t <= 122 || t >= 65 && t <= 90 || t == 183 || t >= 192 && t <= 214 || t >= 216 && t <= 246 || t >= 248 && t <= 893 || t >= 895 && t <= 8191 || t >= 8204 && t <= 8205 || t >= 8255 && t <= 8256 || t >= 8304 && t <= 8591 || t >= 11264 && t <= 12271 || t >= 12289 && t <= 55295 || t >= 63744 && t <= 64975 || t >= 65008 && t <= 65533 || t >= 65536 && t <= 983039;
}
function Dl(t) {
  return t >= 9 && t <= 13 || t === 32 || t === 133 || t >= 8206 && t <= 8207 || t === 8232 || t === 8233;
}
function As(t) {
  return t >= 33 && t <= 35 || t === 36 || t >= 37 && t <= 39 || t === 40 || t === 41 || t === 42 || t === 43 || t === 44 || t === 45 || t >= 46 && t <= 47 || t >= 58 && t <= 59 || t >= 60 && t <= 62 || t >= 63 && t <= 64 || t === 91 || t === 92 || t === 93 || t === 94 || t === 96 || t === 123 || t === 124 || t === 125 || t === 126 || t === 161 || t >= 162 && t <= 165 || t === 166 || t === 167 || t === 169 || t === 171 || t === 172 || t === 174 || t === 176 || t === 177 || t === 182 || t === 187 || t === 191 || t === 215 || t === 247 || t >= 8208 && t <= 8213 || t >= 8214 && t <= 8215 || t === 8216 || t === 8217 || t === 8218 || t >= 8219 && t <= 8220 || t === 8221 || t === 8222 || t === 8223 || t >= 8224 && t <= 8231 || t >= 8240 && t <= 8248 || t === 8249 || t === 8250 || t >= 8251 && t <= 8254 || t >= 8257 && t <= 8259 || t === 8260 || t === 8261 || t === 8262 || t >= 8263 && t <= 8273 || t === 8274 || t === 8275 || t >= 8277 && t <= 8286 || t >= 8592 && t <= 8596 || t >= 8597 && t <= 8601 || t >= 8602 && t <= 8603 || t >= 8604 && t <= 8607 || t === 8608 || t >= 8609 && t <= 8610 || t === 8611 || t >= 8612 && t <= 8613 || t === 8614 || t >= 8615 && t <= 8621 || t === 8622 || t >= 8623 && t <= 8653 || t >= 8654 && t <= 8655 || t >= 8656 && t <= 8657 || t === 8658 || t === 8659 || t === 8660 || t >= 8661 && t <= 8691 || t >= 8692 && t <= 8959 || t >= 8960 && t <= 8967 || t === 8968 || t === 8969 || t === 8970 || t === 8971 || t >= 8972 && t <= 8991 || t >= 8992 && t <= 8993 || t >= 8994 && t <= 9e3 || t === 9001 || t === 9002 || t >= 9003 && t <= 9083 || t === 9084 || t >= 9085 && t <= 9114 || t >= 9115 && t <= 9139 || t >= 9140 && t <= 9179 || t >= 9180 && t <= 9185 || t >= 9186 && t <= 9254 || t >= 9255 && t <= 9279 || t >= 9280 && t <= 9290 || t >= 9291 && t <= 9311 || t >= 9472 && t <= 9654 || t === 9655 || t >= 9656 && t <= 9664 || t === 9665 || t >= 9666 && t <= 9719 || t >= 9720 && t <= 9727 || t >= 9728 && t <= 9838 || t === 9839 || t >= 9840 && t <= 10087 || t === 10088 || t === 10089 || t === 10090 || t === 10091 || t === 10092 || t === 10093 || t === 10094 || t === 10095 || t === 10096 || t === 10097 || t === 10098 || t === 10099 || t === 10100 || t === 10101 || t >= 10132 && t <= 10175 || t >= 10176 && t <= 10180 || t === 10181 || t === 10182 || t >= 10183 && t <= 10213 || t === 10214 || t === 10215 || t === 10216 || t === 10217 || t === 10218 || t === 10219 || t === 10220 || t === 10221 || t === 10222 || t === 10223 || t >= 10224 && t <= 10239 || t >= 10240 && t <= 10495 || t >= 10496 && t <= 10626 || t === 10627 || t === 10628 || t === 10629 || t === 10630 || t === 10631 || t === 10632 || t === 10633 || t === 10634 || t === 10635 || t === 10636 || t === 10637 || t === 10638 || t === 10639 || t === 10640 || t === 10641 || t === 10642 || t === 10643 || t === 10644 || t === 10645 || t === 10646 || t === 10647 || t === 10648 || t >= 10649 && t <= 10711 || t === 10712 || t === 10713 || t === 10714 || t === 10715 || t >= 10716 && t <= 10747 || t === 10748 || t === 10749 || t >= 10750 && t <= 11007 || t >= 11008 && t <= 11055 || t >= 11056 && t <= 11076 || t >= 11077 && t <= 11078 || t >= 11079 && t <= 11084 || t >= 11085 && t <= 11123 || t >= 11124 && t <= 11125 || t >= 11126 && t <= 11157 || t === 11158 || t >= 11159 && t <= 11263 || t >= 11776 && t <= 11777 || t === 11778 || t === 11779 || t === 11780 || t === 11781 || t >= 11782 && t <= 11784 || t === 11785 || t === 11786 || t === 11787 || t === 11788 || t === 11789 || t >= 11790 && t <= 11798 || t === 11799 || t >= 11800 && t <= 11801 || t === 11802 || t === 11803 || t === 11804 || t === 11805 || t >= 11806 && t <= 11807 || t === 11808 || t === 11809 || t === 11810 || t === 11811 || t === 11812 || t === 11813 || t === 11814 || t === 11815 || t === 11816 || t === 11817 || t >= 11818 && t <= 11822 || t === 11823 || t >= 11824 && t <= 11833 || t >= 11834 && t <= 11835 || t >= 11836 && t <= 11839 || t === 11840 || t === 11841 || t === 11842 || t >= 11843 && t <= 11855 || t >= 11856 && t <= 11857 || t === 11858 || t >= 11859 && t <= 11903 || t >= 12289 && t <= 12291 || t === 12296 || t === 12297 || t === 12298 || t === 12299 || t === 12300 || t === 12301 || t === 12302 || t === 12303 || t === 12304 || t === 12305 || t >= 12306 && t <= 12307 || t === 12308 || t === 12309 || t === 12310 || t === 12311 || t === 12312 || t === 12313 || t === 12314 || t === 12315 || t === 12316 || t === 12317 || t >= 12318 && t <= 12319 || t === 12320 || t === 12336 || t === 64830 || t === 64831 || t >= 65093 && t <= 65094;
}
function Ci(t) {
  t.forEach(function(e) {
    if (delete e.location, fl(e) || _l(e))
      for (var n in e.options)
        delete e.options[n].location, Ci(e.options[n].value);
    else ul(e) && ml(e.style) || (cl(e) || hl(e)) && Di(e.style) ? delete e.style.location : dl(e) && Ci(e.children);
  });
}
function Cs(t, e) {
  e === void 0 && (e = {}), e = z({ shouldParseSkeletons: !0, requiresOtherClause: !0 }, e);
  var n = new Es(t, e).parse();
  if (n.err) {
    var i = SyntaxError(R[n.err.kind]);
    throw i.location = n.err.location, i.originalMessage = n.err.message, i;
  }
  return e != null && e.captureLocation || Ci(n.val), n.val;
}
function ei(t, e) {
  var n = e && e.cache ? e.cache : Is, i = e && e.serializer ? e.serializer : Ts, r = e && e.strategy ? e.strategy : xs;
  return r(t, {
    cache: n,
    serializer: i
  });
}
function Ss(t) {
  return t == null || typeof t == "number" || typeof t == "boolean";
}
function $s(t, e, n, i) {
  var r = Ss(i) ? i : n(i), l = e.get(r);
  return typeof l > "u" && (l = t.call(this, i), e.set(r, l)), l;
}
function El(t, e, n) {
  var i = Array.prototype.slice.call(arguments, 3), r = n(i), l = e.get(r);
  return typeof l > "u" && (l = t.apply(this, i), e.set(r, l)), l;
}
function Fl(t, e, n, i, r) {
  return n.bind(e, t, i, r);
}
function xs(t, e) {
  var n = t.length === 1 ? $s : El;
  return Fl(t, this, n, e.cache.create(), e.serializer);
}
function Bs(t, e) {
  return Fl(t, this, El, e.cache.create(), e.serializer);
}
var Ts = function() {
  return JSON.stringify(arguments);
};
function Xi() {
  this.cache = /* @__PURE__ */ Object.create(null);
}
Xi.prototype.get = function(t) {
  return this.cache[t];
};
Xi.prototype.set = function(t, e) {
  this.cache[t] = e;
};
var Is = {
  create: function() {
    return new Xi();
  }
}, ti = {
  variadic: Bs
}, Ct;
(function(t) {
  t.MISSING_VALUE = "MISSING_VALUE", t.INVALID_VALUE = "INVALID_VALUE", t.MISSING_INTL_API = "MISSING_INTL_API";
})(Ct || (Ct = {}));
var Gn = (
  /** @class */
  function(t) {
    Un(e, t);
    function e(n, i, r) {
      var l = t.call(this, n) || this;
      return l.code = i, l.originalMessage = r, l;
    }
    return e.prototype.toString = function() {
      return "[formatjs Error: ".concat(this.code, "] ").concat(this.message);
    }, e;
  }(Error)
), Fr = (
  /** @class */
  function(t) {
    Un(e, t);
    function e(n, i, r, l) {
      return t.call(this, 'Invalid values for "'.concat(n, '": "').concat(i, '". Options are "').concat(Object.keys(r).join('", "'), '"'), Ct.INVALID_VALUE, l) || this;
    }
    return e;
  }(Gn)
), Ls = (
  /** @class */
  function(t) {
    Un(e, t);
    function e(n, i, r) {
      return t.call(this, 'Value for "'.concat(n, '" must be of type ').concat(i), Ct.INVALID_VALUE, r) || this;
    }
    return e;
  }(Gn)
), Hs = (
  /** @class */
  function(t) {
    Un(e, t);
    function e(n, i) {
      return t.call(this, 'The intl string context variable "'.concat(n, '" was not provided to the string "').concat(i, '"'), Ct.MISSING_VALUE, i) || this;
    }
    return e;
  }(Gn)
), _e;
(function(t) {
  t[t.literal = 0] = "literal", t[t.object = 1] = "object";
})(_e || (_e = {}));
function Ps(t) {
  return t.length < 2 ? t : t.reduce(function(e, n) {
    var i = e[e.length - 1];
    return !i || i.type !== _e.literal || n.type !== _e.literal ? e.push(n) : i.value += n.value, e;
  }, []);
}
function Ns(t) {
  return typeof t == "function";
}
function Dn(t, e, n, i, r, l, a) {
  if (t.length === 1 && gr(t[0]))
    return [
      {
        type: _e.literal,
        value: t[0].value
      }
    ];
  for (var o = [], s = 0, u = t; s < u.length; s++) {
    var c = u[s];
    if (gr(c)) {
      o.push({
        type: _e.literal,
        value: c.value
      });
      continue;
    }
    if (Ko(c)) {
      typeof l == "number" && o.push({
        type: _e.literal,
        value: n.getNumberFormat(e).format(l)
      });
      continue;
    }
    var _ = c.value;
    if (!(r && _ in r))
      throw new Hs(_, a);
    var h = r[_];
    if (Jo(c)) {
      (!h || typeof h == "string" || typeof h == "number") && (h = typeof h == "string" || typeof h == "number" ? String(h) : ""), o.push({
        type: typeof h == "string" ? _e.literal : _e.object,
        value: h
      });
      continue;
    }
    if (cl(c)) {
      var d = typeof c.style == "string" ? i.date[c.style] : Di(c.style) ? c.style.parsedOptions : void 0;
      o.push({
        type: _e.literal,
        value: n.getDateTimeFormat(e, d).format(h)
      });
      continue;
    }
    if (hl(c)) {
      var d = typeof c.style == "string" ? i.time[c.style] : Di(c.style) ? c.style.parsedOptions : i.time.medium;
      o.push({
        type: _e.literal,
        value: n.getDateTimeFormat(e, d).format(h)
      });
      continue;
    }
    if (ul(c)) {
      var d = typeof c.style == "string" ? i.number[c.style] : ml(c.style) ? c.style.parsedOptions : void 0;
      d && d.scale && (h = h * (d.scale || 1)), o.push({
        type: _e.literal,
        value: n.getNumberFormat(e, d).format(h)
      });
      continue;
    }
    if (dl(c)) {
      var D = c.children, E = c.value, F = r[E];
      if (!Ns(F))
        throw new Ls(E, "function", a);
      var C = Dn(D, e, n, i, r, l), g = F(C.map(function(v) {
        return v.value;
      }));
      Array.isArray(g) || (g = [g]), o.push.apply(o, g.map(function(v) {
        return {
          type: typeof v == "string" ? _e.literal : _e.object,
          value: v
        };
      }));
    }
    if (fl(c)) {
      var f = c.options[h] || c.options.other;
      if (!f)
        throw new Fr(c.value, h, Object.keys(c.options), a);
      o.push.apply(o, Dn(f.value, e, n, i, r));
      continue;
    }
    if (_l(c)) {
      var f = c.options["=".concat(h)];
      if (!f) {
        if (!Intl.PluralRules)
          throw new Gn(`Intl.PluralRules is not available in this environment.
Try polyfilling it using "@formatjs/intl-pluralrules"
`, Ct.MISSING_INTL_API, a);
        var m = n.getPluralRules(e, { type: c.pluralType }).select(h - (c.offset || 0));
        f = c.options[m] || c.options.other;
      }
      if (!f)
        throw new Fr(c.value, h, Object.keys(c.options), a);
      o.push.apply(o, Dn(f.value, e, n, i, r, h - (c.offset || 0)));
      continue;
    }
  }
  return Ps(o);
}
function Os(t, e) {
  return e ? z(z(z({}, t || {}), e || {}), Object.keys(t).reduce(function(n, i) {
    return n[i] = z(z({}, t[i]), e[i] || {}), n;
  }, {})) : t;
}
function Rs(t, e) {
  return e ? Object.keys(t).reduce(function(n, i) {
    return n[i] = Os(t[i], e[i]), n;
  }, z({}, t)) : t;
}
function ni(t) {
  return {
    create: function() {
      return {
        get: function(e) {
          return t[e];
        },
        set: function(e, n) {
          t[e] = n;
        }
      };
    }
  };
}
function Ms(t) {
  return t === void 0 && (t = {
    number: {},
    dateTime: {},
    pluralRules: {}
  }), {
    getNumberFormat: ei(function() {
      for (var e, n = [], i = 0; i < arguments.length; i++)
        n[i] = arguments[i];
      return new ((e = Intl.NumberFormat).bind.apply(e, Jn([void 0], n, !1)))();
    }, {
      cache: ni(t.number),
      strategy: ti.variadic
    }),
    getDateTimeFormat: ei(function() {
      for (var e, n = [], i = 0; i < arguments.length; i++)
        n[i] = arguments[i];
      return new ((e = Intl.DateTimeFormat).bind.apply(e, Jn([void 0], n, !1)))();
    }, {
      cache: ni(t.dateTime),
      strategy: ti.variadic
    }),
    getPluralRules: ei(function() {
      for (var e, n = [], i = 0; i < arguments.length; i++)
        n[i] = arguments[i];
      return new ((e = Intl.PluralRules).bind.apply(e, Jn([void 0], n, !1)))();
    }, {
      cache: ni(t.pluralRules),
      strategy: ti.variadic
    })
  };
}
var qs = (
  /** @class */
  function() {
    function t(e, n, i, r) {
      var l = this;
      if (n === void 0 && (n = t.defaultLocale), this.formatterCache = {
        number: {},
        dateTime: {},
        pluralRules: {}
      }, this.format = function(a) {
        var o = l.formatToParts(a);
        if (o.length === 1)
          return o[0].value;
        var s = o.reduce(function(u, c) {
          return !u.length || c.type !== _e.literal || typeof u[u.length - 1] != "string" ? u.push(c.value) : u[u.length - 1] += c.value, u;
        }, []);
        return s.length <= 1 ? s[0] || "" : s;
      }, this.formatToParts = function(a) {
        return Dn(l.ast, l.locales, l.formatters, l.formats, a, void 0, l.message);
      }, this.resolvedOptions = function() {
        return {
          locale: l.resolvedLocale.toString()
        };
      }, this.getAst = function() {
        return l.ast;
      }, this.locales = n, this.resolvedLocale = t.resolveLocale(n), typeof e == "string") {
        if (this.message = e, !t.__parse)
          throw new TypeError("IntlMessageFormat.__parse must be set to process `message` of type `string`");
        this.ast = t.__parse(e, {
          ignoreTag: r == null ? void 0 : r.ignoreTag,
          locale: this.resolvedLocale
        });
      } else
        this.ast = e;
      if (!Array.isArray(this.ast))
        throw new TypeError("A message must be provided as a String or AST.");
      this.formats = Rs(t.formats, i), this.formatters = r && r.formatters || Ms(this.formatterCache);
    }
    return Object.defineProperty(t, "defaultLocale", {
      get: function() {
        return t.memoizedDefaultLocale || (t.memoizedDefaultLocale = new Intl.NumberFormat().resolvedOptions().locale), t.memoizedDefaultLocale;
      },
      enumerable: !1,
      configurable: !0
    }), t.memoizedDefaultLocale = null, t.resolveLocale = function(e) {
      var n = Intl.NumberFormat.supportedLocalesOf(e);
      return n.length > 0 ? new Intl.Locale(n[0]) : new Intl.Locale(typeof e == "string" ? e : e[0]);
    }, t.__parse = Cs, t.formats = {
      number: {
        integer: {
          maximumFractionDigits: 0
        },
        currency: {
          style: "currency"
        },
        percent: {
          style: "percent"
        }
      },
      date: {
        short: {
          month: "numeric",
          day: "numeric",
          year: "2-digit"
        },
        medium: {
          month: "short",
          day: "numeric",
          year: "numeric"
        },
        long: {
          month: "long",
          day: "numeric",
          year: "numeric"
        },
        full: {
          weekday: "long",
          month: "long",
          day: "numeric",
          year: "numeric"
        }
      },
      time: {
        short: {
          hour: "numeric",
          minute: "numeric"
        },
        medium: {
          hour: "numeric",
          minute: "numeric",
          second: "numeric"
        },
        long: {
          hour: "numeric",
          minute: "numeric",
          second: "numeric",
          timeZoneName: "short"
        },
        full: {
          hour: "numeric",
          minute: "numeric",
          second: "numeric",
          timeZoneName: "short"
        }
      }
    }, t;
  }()
);
function Us(t, e) {
  if (e == null)
    return;
  if (e in t)
    return t[e];
  const n = e.split(".");
  let i = t;
  for (let r = 0; r < n.length; r++)
    if (typeof i == "object") {
      if (r > 0) {
        const l = n.slice(r, n.length).join(".");
        if (l in i) {
          i = i[l];
          break;
        }
      }
      i = i[n[r]];
    } else
      i = void 0;
  return i;
}
const et = {}, Gs = (t, e, n) => n && (e in et || (et[e] = {}), t in et[e] || (et[e][t] = n), n), kl = (t, e) => {
  if (e == null)
    return;
  if (e in et && t in et[e])
    return et[e][t];
  const n = zn(e);
  for (let i = 0; i < n.length; i++) {
    const r = n[i], l = js(r, t);
    if (l)
      return Gs(t, e, l);
  }
};
let Zi;
const Yt = Qt({});
function zs(t) {
  return Zi[t] || null;
}
function Al(t) {
  return t in Zi;
}
function js(t, e) {
  if (!Al(t))
    return null;
  const n = zs(t);
  return Us(n, e);
}
function Vs(t) {
  if (t == null)
    return;
  const e = zn(t);
  for (let n = 0; n < e.length; n++) {
    const i = e[n];
    if (Al(i))
      return i;
  }
}
function Xs(t, ...e) {
  delete et[t], Yt.update((n) => (n[t] = kt.all([n[t] || {}, ...e]), n));
}
$t(
  [Yt],
  ([t]) => Object.keys(t)
);
Yt.subscribe((t) => Zi = t);
const En = {};
function Zs(t, e) {
  En[t].delete(e), En[t].size === 0 && delete En[t];
}
function Cl(t) {
  return En[t];
}
function Ws(t) {
  return zn(t).map((e) => {
    const n = Cl(e);
    return [e, n ? [...n] : []];
  }).filter(([, e]) => e.length > 0);
}
function Si(t) {
  return t == null ? !1 : zn(t).some(
    (e) => {
      var n;
      return (n = Cl(e)) == null ? void 0 : n.size;
    }
  );
}
function Qs(t, e) {
  return Promise.all(
    e.map((i) => (Zs(t, i), i().then((r) => r.default || r)))
  ).then((i) => Xs(t, ...i));
}
const Bt = {};
function Sl(t) {
  if (!Si(t))
    return t in Bt ? Bt[t] : Promise.resolve();
  const e = Ws(t);
  return Bt[t] = Promise.all(
    e.map(
      ([n, i]) => Qs(n, i)
    )
  ).then(() => {
    if (Si(t))
      return Sl(t);
    delete Bt[t];
  }), Bt[t];
}
const Ys = {
  number: {
    scientific: { notation: "scientific" },
    engineering: { notation: "engineering" },
    compactLong: { notation: "compact", compactDisplay: "long" },
    compactShort: { notation: "compact", compactDisplay: "short" }
  },
  date: {
    short: { month: "numeric", day: "numeric", year: "2-digit" },
    medium: { month: "short", day: "numeric", year: "numeric" },
    long: { month: "long", day: "numeric", year: "numeric" },
    full: { weekday: "long", month: "long", day: "numeric", year: "numeric" }
  },
  time: {
    short: { hour: "numeric", minute: "numeric" },
    medium: { hour: "numeric", minute: "numeric", second: "numeric" },
    long: {
      hour: "numeric",
      minute: "numeric",
      second: "numeric",
      timeZoneName: "short"
    },
    full: {
      hour: "numeric",
      minute: "numeric",
      second: "numeric",
      timeZoneName: "short"
    }
  }
}, Js = {
  fallbackLocale: null,
  loadingDelay: 200,
  formats: Ys,
  warnOnMissingMessages: !0,
  handleMissingMessage: void 0,
  ignoreTag: !0
}, Ks = Js;
function St() {
  return Ks;
}
const ii = Qt(!1);
var eu = Object.defineProperty, tu = Object.defineProperties, nu = Object.getOwnPropertyDescriptors, kr = Object.getOwnPropertySymbols, iu = Object.prototype.hasOwnProperty, ru = Object.prototype.propertyIsEnumerable, Ar = (t, e, n) => e in t ? eu(t, e, { enumerable: !0, configurable: !0, writable: !0, value: n }) : t[e] = n, au = (t, e) => {
  for (var n in e || (e = {}))
    iu.call(e, n) && Ar(t, n, e[n]);
  if (kr)
    for (var n of kr(e))
      ru.call(e, n) && Ar(t, n, e[n]);
  return t;
}, lu = (t, e) => tu(t, nu(e));
let $i;
const Sn = Qt(null);
function Cr(t) {
  return t.split("-").map((e, n, i) => i.slice(0, n + 1).join("-")).reverse();
}
function zn(t, e = St().fallbackLocale) {
  const n = Cr(t);
  return e ? [.../* @__PURE__ */ new Set([...n, ...Cr(e)])] : n;
}
function ut() {
  return $i ?? void 0;
}
Sn.subscribe((t) => {
  $i = t ?? void 0, typeof window < "u" && t != null && document.documentElement.setAttribute("lang", t);
});
const ou = (t) => {
  if (t && Vs(t) && Si(t)) {
    const { loadingDelay: e } = St();
    let n;
    return typeof window < "u" && ut() != null && e ? n = window.setTimeout(
      () => ii.set(!0),
      e
    ) : ii.set(!0), Sl(t).then(() => {
      Sn.set(t);
    }).finally(() => {
      clearTimeout(n), ii.set(!1);
    });
  }
  return Sn.set(t);
}, Jt = lu(au({}, Sn), {
  set: ou
}), jn = (t) => {
  const e = /* @__PURE__ */ Object.create(null);
  return (i) => {
    const r = JSON.stringify(i);
    return r in e ? e[r] : e[r] = t(i);
  };
};
var su = Object.defineProperty, $n = Object.getOwnPropertySymbols, $l = Object.prototype.hasOwnProperty, xl = Object.prototype.propertyIsEnumerable, Sr = (t, e, n) => e in t ? su(t, e, { enumerable: !0, configurable: !0, writable: !0, value: n }) : t[e] = n, Wi = (t, e) => {
  for (var n in e || (e = {}))
    $l.call(e, n) && Sr(t, n, e[n]);
  if ($n)
    for (var n of $n(e))
      xl.call(e, n) && Sr(t, n, e[n]);
  return t;
}, xt = (t, e) => {
  var n = {};
  for (var i in t)
    $l.call(t, i) && e.indexOf(i) < 0 && (n[i] = t[i]);
  if (t != null && $n)
    for (var i of $n(t))
      e.indexOf(i) < 0 && xl.call(t, i) && (n[i] = t[i]);
  return n;
};
const zt = (t, e) => {
  const { formats: n } = St();
  if (t in n && e in n[t])
    return n[t][e];
  throw new Error(`[svelte-i18n] Unknown "${e}" ${t} format.`);
}, uu = jn(
  (t) => {
    var e = t, { locale: n, format: i } = e, r = xt(e, ["locale", "format"]);
    if (n == null)
      throw new Error('[svelte-i18n] A "locale" must be set to format numbers');
    return i && (r = zt("number", i)), new Intl.NumberFormat(n, r);
  }
), cu = jn(
  (t) => {
    var e = t, { locale: n, format: i } = e, r = xt(e, ["locale", "format"]);
    if (n == null)
      throw new Error('[svelte-i18n] A "locale" must be set to format dates');
    return i ? r = zt("date", i) : Object.keys(r).length === 0 && (r = zt("date", "short")), new Intl.DateTimeFormat(n, r);
  }
), hu = jn(
  (t) => {
    var e = t, { locale: n, format: i } = e, r = xt(e, ["locale", "format"]);
    if (n == null)
      throw new Error(
        '[svelte-i18n] A "locale" must be set to format time values'
      );
    return i ? r = zt("time", i) : Object.keys(r).length === 0 && (r = zt("time", "short")), new Intl.DateTimeFormat(n, r);
  }
), fu = (t = {}) => {
  var e = t, {
    locale: n = ut()
  } = e, i = xt(e, [
    "locale"
  ]);
  return uu(Wi({ locale: n }, i));
}, _u = (t = {}) => {
  var e = t, {
    locale: n = ut()
  } = e, i = xt(e, [
    "locale"
  ]);
  return cu(Wi({ locale: n }, i));
}, du = (t = {}) => {
  var e = t, {
    locale: n = ut()
  } = e, i = xt(e, [
    "locale"
  ]);
  return hu(Wi({ locale: n }, i));
}, mu = jn(
  // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
  (t, e = ut()) => new qs(t, e, St().formats, {
    ignoreTag: St().ignoreTag
  })
), pu = (t, e = {}) => {
  var n, i, r, l;
  let a = e;
  typeof t == "object" && (a = t, t = a.id);
  const {
    values: o,
    locale: s = ut(),
    default: u
  } = a;
  if (s == null)
    throw new Error(
      "[svelte-i18n] Cannot format a message without first setting the initial locale."
    );
  let c = kl(t, s);
  if (!c)
    c = (l = (r = (i = (n = St()).handleMissingMessage) == null ? void 0 : i.call(n, { locale: s, id: t, defaultValue: u })) != null ? r : u) != null ? l : t;
  else if (typeof c != "string")
    return console.warn(
      `[svelte-i18n] Message with id "${t}" must be of type "string", found: "${typeof c}". Gettin its value through the "$format" method is deprecated; use the "json" method instead.`
    ), c;
  if (!o)
    return c;
  let _ = c;
  try {
    _ = mu(c, s).format(o);
  } catch (h) {
    h instanceof Error && console.warn(
      `[svelte-i18n] Message "${t}" has syntax error:`,
      h.message
    );
  }
  return _;
}, gu = (t, e) => du(e).format(t), bu = (t, e) => _u(e).format(t), vu = (t, e) => fu(e).format(t), yu = (t, e = ut()) => kl(t, e);
$t([Jt, Yt], () => pu);
$t([Jt], () => gu);
$t([Jt], () => bu);
$t([Jt], () => vu);
$t([Jt, Yt], () => yu);
const {
  SvelteComponent: wu,
  append_hydration: xi,
  assign: Du,
  attr: se,
  binding_callbacks: Eu,
  children: Ot,
  claim_element: Bl,
  claim_space: Tl,
  claim_svg_element: ri,
  create_slot: Fu,
  detach: qe,
  element: Il,
  empty: $r,
  get_all_dirty_from_scope: ku,
  get_slot_changes: Au,
  get_spread_update: Cu,
  init: Su,
  insert_hydration: jt,
  listen: $u,
  noop: xu,
  safe_not_equal: Bu,
  set_dynamic_element_data: xr,
  set_style: V,
  space: Ll,
  svg_element: ai,
  toggle_class: ae,
  transition_in: Hl,
  transition_out: Pl,
  update_slot_base: Tu
} = window.__gradio__svelte__internal;
function Br(t) {
  let e, n, i, r, l;
  return {
    c() {
      e = ai("svg"), n = ai("line"), i = ai("line"), this.h();
    },
    l(a) {
      e = ri(a, "svg", { class: !0, xmlns: !0, viewBox: !0 });
      var o = Ot(e);
      n = ri(o, "line", {
        x1: !0,
        y1: !0,
        x2: !0,
        y2: !0,
        stroke: !0,
        "stroke-width": !0
      }), Ot(n).forEach(qe), i = ri(o, "line", {
        x1: !0,
        y1: !0,
        x2: !0,
        y2: !0,
        stroke: !0,
        "stroke-width": !0
      }), Ot(i).forEach(qe), o.forEach(qe), this.h();
    },
    h() {
      se(n, "x1", "1"), se(n, "y1", "9"), se(n, "x2", "9"), se(n, "y2", "1"), se(n, "stroke", "gray"), se(n, "stroke-width", "0.5"), se(i, "x1", "5"), se(i, "y1", "9"), se(i, "x2", "9"), se(i, "y2", "5"), se(i, "stroke", "gray"), se(i, "stroke-width", "0.5"), se(e, "class", "resize-handle svelte-239wnu"), se(e, "xmlns", "http://www.w3.org/2000/svg"), se(e, "viewBox", "0 0 10 10");
    },
    m(a, o) {
      jt(a, e, o), xi(e, n), xi(e, i), r || (l = $u(
        e,
        "mousedown",
        /*resize*/
        t[27]
      ), r = !0);
    },
    p: xu,
    d(a) {
      a && qe(e), r = !1, l();
    }
  };
}
function Iu(t) {
  var _;
  let e, n, i, r, l;
  const a = (
    /*#slots*/
    t[31].default
  ), o = Fu(
    a,
    t,
    /*$$scope*/
    t[30],
    null
  );
  let s = (
    /*resizable*/
    t[19] && Br(t)
  ), u = [
    { "data-testid": (
      /*test_id*/
      t[11]
    ) },
    { id: (
      /*elem_id*/
      t[6]
    ) },
    {
      class: i = "block " + /*elem_classes*/
      (((_ = t[7]) == null ? void 0 : _.join(" ")) || "") + " svelte-239wnu"
    },
    {
      dir: r = /*rtl*/
      t[20] ? "rtl" : "ltr"
    }
  ], c = {};
  for (let h = 0; h < u.length; h += 1)
    c = Du(c, u[h]);
  return {
    c() {
      e = Il(
        /*tag*/
        t[25]
      ), o && o.c(), n = Ll(), s && s.c(), this.h();
    },
    l(h) {
      e = Bl(
        h,
        /*tag*/
        (t[25] || "null").toUpperCase(),
        {
          "data-testid": !0,
          id: !0,
          class: !0,
          dir: !0
        }
      );
      var d = Ot(e);
      o && o.l(d), n = Tl(d), s && s.l(d), d.forEach(qe), this.h();
    },
    h() {
      xr(
        /*tag*/
        t[25]
      )(e, c), ae(
        e,
        "hidden",
        /*visible*/
        t[14] === !1
      ), ae(
        e,
        "padded",
        /*padding*/
        t[10]
      ), ae(
        e,
        "flex",
        /*flex*/
        t[1]
      ), ae(
        e,
        "border_focus",
        /*border_mode*/
        t[9] === "focus"
      ), ae(
        e,
        "border_contrast",
        /*border_mode*/
        t[9] === "contrast"
      ), ae(e, "hide-container", !/*explicit_call*/
      t[12] && !/*container*/
      t[13]), ae(
        e,
        "fullscreen",
        /*fullscreen*/
        t[0]
      ), ae(
        e,
        "animating",
        /*fullscreen*/
        t[0] && /*preexpansionBoundingRect*/
        t[24] !== null
      ), ae(
        e,
        "auto-margin",
        /*scale*/
        t[17] === null
      ), V(
        e,
        "height",
        /*fullscreen*/
        t[0] ? void 0 : (
          /*get_dimension*/
          t[26](
            /*height*/
            t[2]
          )
        )
      ), V(
        e,
        "min-height",
        /*fullscreen*/
        t[0] ? void 0 : (
          /*get_dimension*/
          t[26](
            /*min_height*/
            t[3]
          )
        )
      ), V(
        e,
        "max-height",
        /*fullscreen*/
        t[0] ? void 0 : (
          /*get_dimension*/
          t[26](
            /*max_height*/
            t[4]
          )
        )
      ), V(
        e,
        "--start-top",
        /*preexpansionBoundingRect*/
        t[24] ? `${/*preexpansionBoundingRect*/
        t[24].top}px` : "0px"
      ), V(
        e,
        "--start-left",
        /*preexpansionBoundingRect*/
        t[24] ? `${/*preexpansionBoundingRect*/
        t[24].left}px` : "0px"
      ), V(
        e,
        "--start-width",
        /*preexpansionBoundingRect*/
        t[24] ? `${/*preexpansionBoundingRect*/
        t[24].width}px` : "0px"
      ), V(
        e,
        "--start-height",
        /*preexpansionBoundingRect*/
        t[24] ? `${/*preexpansionBoundingRect*/
        t[24].height}px` : "0px"
      ), V(
        e,
        "width",
        /*fullscreen*/
        t[0] ? void 0 : typeof /*width*/
        t[5] == "number" ? `calc(min(${/*width*/
        t[5]}px, 100%))` : (
          /*get_dimension*/
          t[26](
            /*width*/
            t[5]
          )
        )
      ), V(
        e,
        "border-style",
        /*variant*/
        t[8]
      ), V(
        e,
        "overflow",
        /*allow_overflow*/
        t[15] ? (
          /*overflow_behavior*/
          t[16]
        ) : "hidden"
      ), V(
        e,
        "flex-grow",
        /*scale*/
        t[17]
      ), V(e, "min-width", `calc(min(${/*min_width*/
      t[18]}px, 100%))`), V(e, "border-width", "var(--block-border-width)");
    },
    m(h, d) {
      jt(h, e, d), o && o.m(e, null), xi(e, n), s && s.m(e, null), t[32](e), l = !0;
    },
    p(h, d) {
      var D;
      o && o.p && (!l || d[0] & /*$$scope*/
      1073741824) && Tu(
        o,
        a,
        h,
        /*$$scope*/
        h[30],
        l ? Au(
          a,
          /*$$scope*/
          h[30],
          d,
          null
        ) : ku(
          /*$$scope*/
          h[30]
        ),
        null
      ), /*resizable*/
      h[19] ? s ? s.p(h, d) : (s = Br(h), s.c(), s.m(e, null)) : s && (s.d(1), s = null), xr(
        /*tag*/
        h[25]
      )(e, c = Cu(u, [
        (!l || d[0] & /*test_id*/
        2048) && { "data-testid": (
          /*test_id*/
          h[11]
        ) },
        (!l || d[0] & /*elem_id*/
        64) && { id: (
          /*elem_id*/
          h[6]
        ) },
        (!l || d[0] & /*elem_classes*/
        128 && i !== (i = "block " + /*elem_classes*/
        (((D = h[7]) == null ? void 0 : D.join(" ")) || "") + " svelte-239wnu")) && { class: i },
        (!l || d[0] & /*rtl*/
        1048576 && r !== (r = /*rtl*/
        h[20] ? "rtl" : "ltr")) && { dir: r }
      ])), ae(
        e,
        "hidden",
        /*visible*/
        h[14] === !1
      ), ae(
        e,
        "padded",
        /*padding*/
        h[10]
      ), ae(
        e,
        "flex",
        /*flex*/
        h[1]
      ), ae(
        e,
        "border_focus",
        /*border_mode*/
        h[9] === "focus"
      ), ae(
        e,
        "border_contrast",
        /*border_mode*/
        h[9] === "contrast"
      ), ae(e, "hide-container", !/*explicit_call*/
      h[12] && !/*container*/
      h[13]), ae(
        e,
        "fullscreen",
        /*fullscreen*/
        h[0]
      ), ae(
        e,
        "animating",
        /*fullscreen*/
        h[0] && /*preexpansionBoundingRect*/
        h[24] !== null
      ), ae(
        e,
        "auto-margin",
        /*scale*/
        h[17] === null
      ), d[0] & /*fullscreen, height*/
      5 && V(
        e,
        "height",
        /*fullscreen*/
        h[0] ? void 0 : (
          /*get_dimension*/
          h[26](
            /*height*/
            h[2]
          )
        )
      ), d[0] & /*fullscreen, min_height*/
      9 && V(
        e,
        "min-height",
        /*fullscreen*/
        h[0] ? void 0 : (
          /*get_dimension*/
          h[26](
            /*min_height*/
            h[3]
          )
        )
      ), d[0] & /*fullscreen, max_height*/
      17 && V(
        e,
        "max-height",
        /*fullscreen*/
        h[0] ? void 0 : (
          /*get_dimension*/
          h[26](
            /*max_height*/
            h[4]
          )
        )
      ), d[0] & /*preexpansionBoundingRect*/
      16777216 && V(
        e,
        "--start-top",
        /*preexpansionBoundingRect*/
        h[24] ? `${/*preexpansionBoundingRect*/
        h[24].top}px` : "0px"
      ), d[0] & /*preexpansionBoundingRect*/
      16777216 && V(
        e,
        "--start-left",
        /*preexpansionBoundingRect*/
        h[24] ? `${/*preexpansionBoundingRect*/
        h[24].left}px` : "0px"
      ), d[0] & /*preexpansionBoundingRect*/
      16777216 && V(
        e,
        "--start-width",
        /*preexpansionBoundingRect*/
        h[24] ? `${/*preexpansionBoundingRect*/
        h[24].width}px` : "0px"
      ), d[0] & /*preexpansionBoundingRect*/
      16777216 && V(
        e,
        "--start-height",
        /*preexpansionBoundingRect*/
        h[24] ? `${/*preexpansionBoundingRect*/
        h[24].height}px` : "0px"
      ), d[0] & /*fullscreen, width*/
      33 && V(
        e,
        "width",
        /*fullscreen*/
        h[0] ? void 0 : typeof /*width*/
        h[5] == "number" ? `calc(min(${/*width*/
        h[5]}px, 100%))` : (
          /*get_dimension*/
          h[26](
            /*width*/
            h[5]
          )
        )
      ), d[0] & /*variant*/
      256 && V(
        e,
        "border-style",
        /*variant*/
        h[8]
      ), d[0] & /*allow_overflow, overflow_behavior*/
      98304 && V(
        e,
        "overflow",
        /*allow_overflow*/
        h[15] ? (
          /*overflow_behavior*/
          h[16]
        ) : "hidden"
      ), d[0] & /*scale*/
      131072 && V(
        e,
        "flex-grow",
        /*scale*/
        h[17]
      ), d[0] & /*min_width*/
      262144 && V(e, "min-width", `calc(min(${/*min_width*/
      h[18]}px, 100%))`);
    },
    i(h) {
      l || (Hl(o, h), l = !0);
    },
    o(h) {
      Pl(o, h), l = !1;
    },
    d(h) {
      h && qe(e), o && o.d(h), s && s.d(), t[32](null);
    }
  };
}
function Tr(t) {
  let e;
  return {
    c() {
      e = Il("div"), this.h();
    },
    l(n) {
      e = Bl(n, "DIV", { class: !0 }), Ot(e).forEach(qe), this.h();
    },
    h() {
      se(e, "class", "placeholder svelte-239wnu"), V(
        e,
        "height",
        /*placeholder_height*/
        t[22] + "px"
      ), V(
        e,
        "width",
        /*placeholder_width*/
        t[23] + "px"
      );
    },
    m(n, i) {
      jt(n, e, i);
    },
    p(n, i) {
      i[0] & /*placeholder_height*/
      4194304 && V(
        e,
        "height",
        /*placeholder_height*/
        n[22] + "px"
      ), i[0] & /*placeholder_width*/
      8388608 && V(
        e,
        "width",
        /*placeholder_width*/
        n[23] + "px"
      );
    },
    d(n) {
      n && qe(e);
    }
  };
}
function Lu(t) {
  let e, n, i, r = (
    /*tag*/
    t[25] && Iu(t)
  ), l = (
    /*fullscreen*/
    t[0] && Tr(t)
  );
  return {
    c() {
      r && r.c(), e = Ll(), l && l.c(), n = $r();
    },
    l(a) {
      r && r.l(a), e = Tl(a), l && l.l(a), n = $r();
    },
    m(a, o) {
      r && r.m(a, o), jt(a, e, o), l && l.m(a, o), jt(a, n, o), i = !0;
    },
    p(a, o) {
      /*tag*/
      a[25] && r.p(a, o), /*fullscreen*/
      a[0] ? l ? l.p(a, o) : (l = Tr(a), l.c(), l.m(n.parentNode, n)) : l && (l.d(1), l = null);
    },
    i(a) {
      i || (Hl(r, a), i = !0);
    },
    o(a) {
      Pl(r, a), i = !1;
    },
    d(a) {
      a && (qe(e), qe(n)), r && r.d(a), l && l.d(a);
    }
  };
}
function Hu(t, e, n) {
  let { $$slots: i = {}, $$scope: r } = e, { height: l = void 0 } = e, { min_height: a = void 0 } = e, { max_height: o = void 0 } = e, { width: s = void 0 } = e, { elem_id: u = "" } = e, { elem_classes: c = [] } = e, { variant: _ = "solid" } = e, { border_mode: h = "base" } = e, { padding: d = !0 } = e, { type: D = "normal" } = e, { test_id: E = void 0 } = e, { explicit_call: F = !1 } = e, { container: C = !0 } = e, { visible: g = !0 } = e, { allow_overflow: f = !0 } = e, { overflow_behavior: m = "auto" } = e, { scale: v = null } = e, { min_width: p = 0 } = e, { flex: b = !1 } = e, { resizable: k = !1 } = e, { rtl: y = !1 } = e, { fullscreen: w = !1 } = e, A = w, B, q = D === "fieldset" ? "fieldset" : "div", P = 0, U = 0, O = null;
  function W($) {
    w && $.key === "Escape" && n(0, w = !1);
  }
  const j = ($) => {
    if ($ !== void 0) {
      if (typeof $ == "number")
        return $ + "px";
      if (typeof $ == "string")
        return $;
    }
  }, T = ($) => {
    let I = $.clientY;
    const Se = (L) => {
      const Je = L.clientY - I;
      I = L.clientY, n(21, B.style.height = `${B.offsetHeight + Je}px`, B);
    }, x = () => {
      window.removeEventListener("mousemove", Se), window.removeEventListener("mouseup", x);
    };
    window.addEventListener("mousemove", Se), window.addEventListener("mouseup", x);
  };
  function ne($) {
    Eu[$ ? "unshift" : "push"](() => {
      B = $, n(21, B);
    });
  }
  return t.$$set = ($) => {
    "height" in $ && n(2, l = $.height), "min_height" in $ && n(3, a = $.min_height), "max_height" in $ && n(4, o = $.max_height), "width" in $ && n(5, s = $.width), "elem_id" in $ && n(6, u = $.elem_id), "elem_classes" in $ && n(7, c = $.elem_classes), "variant" in $ && n(8, _ = $.variant), "border_mode" in $ && n(9, h = $.border_mode), "padding" in $ && n(10, d = $.padding), "type" in $ && n(28, D = $.type), "test_id" in $ && n(11, E = $.test_id), "explicit_call" in $ && n(12, F = $.explicit_call), "container" in $ && n(13, C = $.container), "visible" in $ && n(14, g = $.visible), "allow_overflow" in $ && n(15, f = $.allow_overflow), "overflow_behavior" in $ && n(16, m = $.overflow_behavior), "scale" in $ && n(17, v = $.scale), "min_width" in $ && n(18, p = $.min_width), "flex" in $ && n(1, b = $.flex), "resizable" in $ && n(19, k = $.resizable), "rtl" in $ && n(20, y = $.rtl), "fullscreen" in $ && n(0, w = $.fullscreen), "$$scope" in $ && n(30, r = $.$$scope);
  }, t.$$.update = () => {
    t.$$.dirty[0] & /*fullscreen, old_fullscreen, element*/
    538968065 && w !== A && (n(29, A = w), w ? (n(24, O = B.getBoundingClientRect()), n(22, P = B.offsetHeight), n(23, U = B.offsetWidth), window.addEventListener("keydown", W)) : (n(24, O = null), window.removeEventListener("keydown", W))), t.$$.dirty[0] & /*visible*/
    16384 && (g || n(1, b = !1));
  }, [
    w,
    b,
    l,
    a,
    o,
    s,
    u,
    c,
    _,
    h,
    d,
    E,
    F,
    C,
    g,
    f,
    m,
    v,
    p,
    k,
    y,
    B,
    P,
    U,
    O,
    q,
    j,
    T,
    D,
    A,
    r,
    i,
    ne
  ];
}
class Pu extends wu {
  constructor(e) {
    super(), Su(
      this,
      e,
      Hu,
      Lu,
      Bu,
      {
        height: 2,
        min_height: 3,
        max_height: 4,
        width: 5,
        elem_id: 6,
        elem_classes: 7,
        variant: 8,
        border_mode: 9,
        padding: 10,
        type: 28,
        test_id: 11,
        explicit_call: 12,
        container: 13,
        visible: 14,
        allow_overflow: 15,
        overflow_behavior: 16,
        scale: 17,
        min_width: 18,
        flex: 1,
        resizable: 19,
        rtl: 20,
        fullscreen: 0
      },
      null,
      [-1, -1]
    );
  }
}
function Qi() {
  return {
    async: !1,
    breaks: !1,
    extensions: null,
    gfm: !0,
    hooks: null,
    pedantic: !1,
    renderer: null,
    silent: !1,
    tokenizer: null,
    walkTokens: null
  };
}
let ct = Qi();
function Nl(t) {
  ct = t;
}
const Ol = /[&<>"']/, Nu = new RegExp(Ol.source, "g"), Rl = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, Ou = new RegExp(Rl.source, "g"), Ru = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, Ir = (t) => Ru[t];
function be(t, e) {
  if (e) {
    if (Ol.test(t))
      return t.replace(Nu, Ir);
  } else if (Rl.test(t))
    return t.replace(Ou, Ir);
  return t;
}
const Mu = /&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/ig;
function qu(t) {
  return t.replace(Mu, (e, n) => (n = n.toLowerCase(), n === "colon" ? ":" : n.charAt(0) === "#" ? n.charAt(1) === "x" ? String.fromCharCode(parseInt(n.substring(2), 16)) : String.fromCharCode(+n.substring(1)) : ""));
}
const Uu = /(^|[^\[])\^/g;
function Z(t, e) {
  let n = typeof t == "string" ? t : t.source;
  e = e || "";
  const i = {
    replace: (r, l) => {
      let a = typeof l == "string" ? l : l.source;
      return a = a.replace(Uu, "$1"), n = n.replace(r, a), i;
    },
    getRegex: () => new RegExp(n, e)
  };
  return i;
}
function Lr(t) {
  try {
    t = encodeURI(t).replace(/%25/g, "%");
  } catch {
    return null;
  }
  return t;
}
const Rt = { exec: () => null };
function Hr(t, e) {
  const n = t.replace(/\|/g, (l, a, o) => {
    let s = !1, u = a;
    for (; --u >= 0 && o[u] === "\\"; )
      s = !s;
    return s ? "|" : " |";
  }), i = n.split(/ \|/);
  let r = 0;
  if (i[0].trim() || i.shift(), i.length > 0 && !i[i.length - 1].trim() && i.pop(), e)
    if (i.length > e)
      i.splice(e);
    else
      for (; i.length < e; )
        i.push("");
  for (; r < i.length; r++)
    i[r] = i[r].trim().replace(/\\\|/g, "|");
  return i;
}
function un(t, e, n) {
  const i = t.length;
  if (i === 0)
    return "";
  let r = 0;
  for (; r < i && t.charAt(i - r - 1) === e; )
    r++;
  return t.slice(0, i - r);
}
function Gu(t, e) {
  if (t.indexOf(e[1]) === -1)
    return -1;
  let n = 0;
  for (let i = 0; i < t.length; i++)
    if (t[i] === "\\")
      i++;
    else if (t[i] === e[0])
      n++;
    else if (t[i] === e[1] && (n--, n < 0))
      return i;
  return -1;
}
function Pr(t, e, n, i) {
  const r = e.href, l = e.title ? be(e.title) : null, a = t[1].replace(/\\([\[\]])/g, "$1");
  if (t[0].charAt(0) !== "!") {
    i.state.inLink = !0;
    const o = {
      type: "link",
      raw: n,
      href: r,
      title: l,
      text: a,
      tokens: i.inlineTokens(a)
    };
    return i.state.inLink = !1, o;
  }
  return {
    type: "image",
    raw: n,
    href: r,
    title: l,
    text: be(a)
  };
}
function zu(t, e) {
  const n = t.match(/^(\s+)(?:```)/);
  if (n === null)
    return e;
  const i = n[1];
  return e.split(`
`).map((r) => {
    const l = r.match(/^\s+/);
    if (l === null)
      return r;
    const [a] = l;
    return a.length >= i.length ? r.slice(i.length) : r;
  }).join(`
`);
}
class xn {
  // set by the lexer
  constructor(e) {
    Q(this, "options");
    Q(this, "rules");
    // set by the lexer
    Q(this, "lexer");
    this.options = e || ct;
  }
  space(e) {
    const n = this.rules.block.newline.exec(e);
    if (n && n[0].length > 0)
      return {
        type: "space",
        raw: n[0]
      };
  }
  code(e) {
    const n = this.rules.block.code.exec(e);
    if (n) {
      const i = n[0].replace(/^ {1,4}/gm, "");
      return {
        type: "code",
        raw: n[0],
        codeBlockStyle: "indented",
        text: this.options.pedantic ? i : un(i, `
`)
      };
    }
  }
  fences(e) {
    const n = this.rules.block.fences.exec(e);
    if (n) {
      const i = n[0], r = zu(i, n[3] || "");
      return {
        type: "code",
        raw: i,
        lang: n[2] ? n[2].trim().replace(this.rules.inline.anyPunctuation, "$1") : n[2],
        text: r
      };
    }
  }
  heading(e) {
    const n = this.rules.block.heading.exec(e);
    if (n) {
      let i = n[2].trim();
      if (/#$/.test(i)) {
        const r = un(i, "#");
        (this.options.pedantic || !r || / $/.test(r)) && (i = r.trim());
      }
      return {
        type: "heading",
        raw: n[0],
        depth: n[1].length,
        text: i,
        tokens: this.lexer.inline(i)
      };
    }
  }
  hr(e) {
    const n = this.rules.block.hr.exec(e);
    if (n)
      return {
        type: "hr",
        raw: n[0]
      };
  }
  blockquote(e) {
    const n = this.rules.block.blockquote.exec(e);
    if (n) {
      let i = n[0].replace(/\n {0,3}((?:=+|-+) *)(?=\n|$)/g, `
    $1`);
      i = un(i.replace(/^ *>[ \t]?/gm, ""), `
`);
      const r = this.lexer.state.top;
      this.lexer.state.top = !0;
      const l = this.lexer.blockTokens(i);
      return this.lexer.state.top = r, {
        type: "blockquote",
        raw: n[0],
        tokens: l,
        text: i
      };
    }
  }
  list(e) {
    let n = this.rules.block.list.exec(e);
    if (n) {
      let i = n[1].trim();
      const r = i.length > 1, l = {
        type: "list",
        raw: "",
        ordered: r,
        start: r ? +i.slice(0, -1) : "",
        loose: !1,
        items: []
      };
      i = r ? `\\d{1,9}\\${i.slice(-1)}` : `\\${i}`, this.options.pedantic && (i = r ? i : "[*+-]");
      const a = new RegExp(`^( {0,3}${i})((?:[	 ][^\\n]*)?(?:\\n|$))`);
      let o = "", s = "", u = !1;
      for (; e; ) {
        let c = !1;
        if (!(n = a.exec(e)) || this.rules.block.hr.test(e))
          break;
        o = n[0], e = e.substring(o.length);
        let _ = n[2].split(`
`, 1)[0].replace(/^\t+/, (C) => " ".repeat(3 * C.length)), h = e.split(`
`, 1)[0], d = 0;
        this.options.pedantic ? (d = 2, s = _.trimStart()) : (d = n[2].search(/[^ ]/), d = d > 4 ? 1 : d, s = _.slice(d), d += n[1].length);
        let D = !1;
        if (!_ && /^ *$/.test(h) && (o += h + `
`, e = e.substring(h.length + 1), c = !0), !c) {
          const C = new RegExp(`^ {0,${Math.min(3, d - 1)}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`), g = new RegExp(`^ {0,${Math.min(3, d - 1)}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)`), f = new RegExp(`^ {0,${Math.min(3, d - 1)}}(?:\`\`\`|~~~)`), m = new RegExp(`^ {0,${Math.min(3, d - 1)}}#`);
          for (; e; ) {
            const v = e.split(`
`, 1)[0];
            if (h = v, this.options.pedantic && (h = h.replace(/^ {1,4}(?=( {4})*[^ ])/g, "  ")), f.test(h) || m.test(h) || C.test(h) || g.test(e))
              break;
            if (h.search(/[^ ]/) >= d || !h.trim())
              s += `
` + h.slice(d);
            else {
              if (D || _.search(/[^ ]/) >= 4 || f.test(_) || m.test(_) || g.test(_))
                break;
              s += `
` + h;
            }
            !D && !h.trim() && (D = !0), o += v + `
`, e = e.substring(v.length + 1), _ = h.slice(d);
          }
        }
        l.loose || (u ? l.loose = !0 : /\n *\n *$/.test(o) && (u = !0));
        let E = null, F;
        this.options.gfm && (E = /^\[[ xX]\] /.exec(s), E && (F = E[0] !== "[ ] ", s = s.replace(/^\[[ xX]\] +/, ""))), l.items.push({
          type: "list_item",
          raw: o,
          task: !!E,
          checked: F,
          loose: !1,
          text: s,
          tokens: []
        }), l.raw += o;
      }
      l.items[l.items.length - 1].raw = o.trimEnd(), l.items[l.items.length - 1].text = s.trimEnd(), l.raw = l.raw.trimEnd();
      for (let c = 0; c < l.items.length; c++)
        if (this.lexer.state.top = !1, l.items[c].tokens = this.lexer.blockTokens(l.items[c].text, []), !l.loose) {
          const _ = l.items[c].tokens.filter((d) => d.type === "space"), h = _.length > 0 && _.some((d) => /\n.*\n/.test(d.raw));
          l.loose = h;
        }
      if (l.loose)
        for (let c = 0; c < l.items.length; c++)
          l.items[c].loose = !0;
      return l;
    }
  }
  html(e) {
    const n = this.rules.block.html.exec(e);
    if (n)
      return {
        type: "html",
        block: !0,
        raw: n[0],
        pre: n[1] === "pre" || n[1] === "script" || n[1] === "style",
        text: n[0]
      };
  }
  def(e) {
    const n = this.rules.block.def.exec(e);
    if (n) {
      const i = n[1].toLowerCase().replace(/\s+/g, " "), r = n[2] ? n[2].replace(/^<(.*)>$/, "$1").replace(this.rules.inline.anyPunctuation, "$1") : "", l = n[3] ? n[3].substring(1, n[3].length - 1).replace(this.rules.inline.anyPunctuation, "$1") : n[3];
      return {
        type: "def",
        tag: i,
        raw: n[0],
        href: r,
        title: l
      };
    }
  }
  table(e) {
    const n = this.rules.block.table.exec(e);
    if (!n || !/[:|]/.test(n[2]))
      return;
    const i = Hr(n[1]), r = n[2].replace(/^\||\| *$/g, "").split("|"), l = n[3] && n[3].trim() ? n[3].replace(/\n[ \t]*$/, "").split(`
`) : [], a = {
      type: "table",
      raw: n[0],
      header: [],
      align: [],
      rows: []
    };
    if (i.length === r.length) {
      for (const o of r)
        /^ *-+: *$/.test(o) ? a.align.push("right") : /^ *:-+: *$/.test(o) ? a.align.push("center") : /^ *:-+ *$/.test(o) ? a.align.push("left") : a.align.push(null);
      for (const o of i)
        a.header.push({
          text: o,
          tokens: this.lexer.inline(o)
        });
      for (const o of l)
        a.rows.push(Hr(o, a.header.length).map((s) => ({
          text: s,
          tokens: this.lexer.inline(s)
        })));
      return a;
    }
  }
  lheading(e) {
    const n = this.rules.block.lheading.exec(e);
    if (n)
      return {
        type: "heading",
        raw: n[0],
        depth: n[2].charAt(0) === "=" ? 1 : 2,
        text: n[1],
        tokens: this.lexer.inline(n[1])
      };
  }
  paragraph(e) {
    const n = this.rules.block.paragraph.exec(e);
    if (n) {
      const i = n[1].charAt(n[1].length - 1) === `
` ? n[1].slice(0, -1) : n[1];
      return {
        type: "paragraph",
        raw: n[0],
        text: i,
        tokens: this.lexer.inline(i)
      };
    }
  }
  text(e) {
    const n = this.rules.block.text.exec(e);
    if (n)
      return {
        type: "text",
        raw: n[0],
        text: n[0],
        tokens: this.lexer.inline(n[0])
      };
  }
  escape(e) {
    const n = this.rules.inline.escape.exec(e);
    if (n)
      return {
        type: "escape",
        raw: n[0],
        text: be(n[1])
      };
  }
  tag(e) {
    const n = this.rules.inline.tag.exec(e);
    if (n)
      return !this.lexer.state.inLink && /^<a /i.test(n[0]) ? this.lexer.state.inLink = !0 : this.lexer.state.inLink && /^<\/a>/i.test(n[0]) && (this.lexer.state.inLink = !1), !this.lexer.state.inRawBlock && /^<(pre|code|kbd|script)(\s|>)/i.test(n[0]) ? this.lexer.state.inRawBlock = !0 : this.lexer.state.inRawBlock && /^<\/(pre|code|kbd|script)(\s|>)/i.test(n[0]) && (this.lexer.state.inRawBlock = !1), {
        type: "html",
        raw: n[0],
        inLink: this.lexer.state.inLink,
        inRawBlock: this.lexer.state.inRawBlock,
        block: !1,
        text: n[0]
      };
  }
  link(e) {
    const n = this.rules.inline.link.exec(e);
    if (n) {
      const i = n[2].trim();
      if (!this.options.pedantic && /^</.test(i)) {
        if (!/>$/.test(i))
          return;
        const a = un(i.slice(0, -1), "\\");
        if ((i.length - a.length) % 2 === 0)
          return;
      } else {
        const a = Gu(n[2], "()");
        if (a > -1) {
          const s = (n[0].indexOf("!") === 0 ? 5 : 4) + n[1].length + a;
          n[2] = n[2].substring(0, a), n[0] = n[0].substring(0, s).trim(), n[3] = "";
        }
      }
      let r = n[2], l = "";
      if (this.options.pedantic) {
        const a = /^([^'"]*[^\s])\s+(['"])(.*)\2/.exec(r);
        a && (r = a[1], l = a[3]);
      } else
        l = n[3] ? n[3].slice(1, -1) : "";
      return r = r.trim(), /^</.test(r) && (this.options.pedantic && !/>$/.test(i) ? r = r.slice(1) : r = r.slice(1, -1)), Pr(n, {
        href: r && r.replace(this.rules.inline.anyPunctuation, "$1"),
        title: l && l.replace(this.rules.inline.anyPunctuation, "$1")
      }, n[0], this.lexer);
    }
  }
  reflink(e, n) {
    let i;
    if ((i = this.rules.inline.reflink.exec(e)) || (i = this.rules.inline.nolink.exec(e))) {
      const r = (i[2] || i[1]).replace(/\s+/g, " "), l = n[r.toLowerCase()];
      if (!l) {
        const a = i[0].charAt(0);
        return {
          type: "text",
          raw: a,
          text: a
        };
      }
      return Pr(i, l, i[0], this.lexer);
    }
  }
  emStrong(e, n, i = "") {
    let r = this.rules.inline.emStrongLDelim.exec(e);
    if (!r || r[3] && i.match(/[\p{L}\p{N}]/u))
      return;
    if (!(r[1] || r[2] || "") || !i || this.rules.inline.punctuation.exec(i)) {
      const a = [...r[0]].length - 1;
      let o, s, u = a, c = 0;
      const _ = r[0][0] === "*" ? this.rules.inline.emStrongRDelimAst : this.rules.inline.emStrongRDelimUnd;
      for (_.lastIndex = 0, n = n.slice(-1 * e.length + a); (r = _.exec(n)) != null; ) {
        if (o = r[1] || r[2] || r[3] || r[4] || r[5] || r[6], !o)
          continue;
        if (s = [...o].length, r[3] || r[4]) {
          u += s;
          continue;
        } else if ((r[5] || r[6]) && a % 3 && !((a + s) % 3)) {
          c += s;
          continue;
        }
        if (u -= s, u > 0)
          continue;
        s = Math.min(s, s + u + c);
        const h = [...r[0]][0].length, d = e.slice(0, a + r.index + h + s);
        if (Math.min(a, s) % 2) {
          const E = d.slice(1, -1);
          return {
            type: "em",
            raw: d,
            text: E,
            tokens: this.lexer.inlineTokens(E)
          };
        }
        const D = d.slice(2, -2);
        return {
          type: "strong",
          raw: d,
          text: D,
          tokens: this.lexer.inlineTokens(D)
        };
      }
    }
  }
  codespan(e) {
    const n = this.rules.inline.code.exec(e);
    if (n) {
      let i = n[2].replace(/\n/g, " ");
      const r = /[^ ]/.test(i), l = /^ /.test(i) && / $/.test(i);
      return r && l && (i = i.substring(1, i.length - 1)), i = be(i, !0), {
        type: "codespan",
        raw: n[0],
        text: i
      };
    }
  }
  br(e) {
    const n = this.rules.inline.br.exec(e);
    if (n)
      return {
        type: "br",
        raw: n[0]
      };
  }
  del(e) {
    const n = this.rules.inline.del.exec(e);
    if (n)
      return {
        type: "del",
        raw: n[0],
        text: n[2],
        tokens: this.lexer.inlineTokens(n[2])
      };
  }
  autolink(e) {
    const n = this.rules.inline.autolink.exec(e);
    if (n) {
      let i, r;
      return n[2] === "@" ? (i = be(n[1]), r = "mailto:" + i) : (i = be(n[1]), r = i), {
        type: "link",
        raw: n[0],
        text: i,
        href: r,
        tokens: [
          {
            type: "text",
            raw: i,
            text: i
          }
        ]
      };
    }
  }
  url(e) {
    var i;
    let n;
    if (n = this.rules.inline.url.exec(e)) {
      let r, l;
      if (n[2] === "@")
        r = be(n[0]), l = "mailto:" + r;
      else {
        let a;
        do
          a = n[0], n[0] = ((i = this.rules.inline._backpedal.exec(n[0])) == null ? void 0 : i[0]) ?? "";
        while (a !== n[0]);
        r = be(n[0]), n[1] === "www." ? l = "http://" + n[0] : l = n[0];
      }
      return {
        type: "link",
        raw: n[0],
        text: r,
        href: l,
        tokens: [
          {
            type: "text",
            raw: r,
            text: r
          }
        ]
      };
    }
  }
  inlineText(e) {
    const n = this.rules.inline.text.exec(e);
    if (n) {
      let i;
      return this.lexer.state.inRawBlock ? i = n[0] : i = be(n[0]), {
        type: "text",
        raw: n[0],
        text: i
      };
    }
  }
}
const ju = /^(?: *(?:\n|$))+/, Vu = /^( {4}[^\n]+(?:\n(?: *(?:\n|$))*)?)+/, Xu = /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/, Kt = /^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/, Zu = /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/, Ml = /(?:[*+-]|\d{1,9}[.)])/, ql = Z(/^(?!bull |blockCode|fences|blockquote|heading|html)((?:.|\n(?!\s*?\n|bull |blockCode|fences|blockquote|heading|html))+?)\n {0,3}(=+|-+) *(?:\n+|$)/).replace(/bull/g, Ml).replace(/blockCode/g, / {4}/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).getRegex(), Yi = /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/, Wu = /^[^\n]+/, Ji = /(?!\s*\])(?:\\.|[^\[\]\\])+/, Qu = Z(/^ {0,3}\[(label)\]: *(?:\n *)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n *)?| *\n *)(title))? *(?:\n+|$)/).replace("label", Ji).replace("title", /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/).getRegex(), Yu = Z(/^( {0,3}bull)([ \t][^\n]+?)?(?:\n|$)/).replace(/bull/g, Ml).getRegex(), Vn = "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul", Ki = /<!--(?:-?>|[\s\S]*?(?:-->|$))/, Ju = Z("^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>\\n*|$)|<![A-Z][\\s\\S]*?(?:>\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n *)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$))", "i").replace("comment", Ki).replace("tag", Vn).replace("attribute", / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex(), Ul = Z(Yi).replace("hr", Kt).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("|table", "").replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Vn).getRegex(), Ku = Z(/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/).replace("paragraph", Ul).getRegex(), er = {
  blockquote: Ku,
  code: Vu,
  def: Qu,
  fences: Xu,
  heading: Zu,
  hr: Kt,
  html: Ju,
  lheading: ql,
  list: Yu,
  newline: ju,
  paragraph: Ul,
  table: Rt,
  text: Wu
}, Nr = Z("^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)").replace("hr", Kt).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("blockquote", " {0,3}>").replace("code", " {4}[^\\n]").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Vn).getRegex(), ec = {
  ...er,
  table: Nr,
  paragraph: Z(Yi).replace("hr", Kt).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("table", Nr).replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Vn).getRegex()
}, tc = {
  ...er,
  html: Z(`^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`).replace("comment", Ki).replace(/tag/g, "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(),
  def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/,
  heading: /^(#{1,6})(.*)(?:\n+|$)/,
  fences: Rt,
  // fences not supported
  lheading: /^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/,
  paragraph: Z(Yi).replace("hr", Kt).replace("heading", ` *#{1,6} *[^
]`).replace("lheading", ql).replace("|table", "").replace("blockquote", " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html", "").replace("|tag", "").getRegex()
}, Gl = /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/, nc = /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/, zl = /^( {2,}|\\)\n(?!\s*$)/, ic = /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/, en = "\\p{P}\\p{S}", rc = Z(/^((?![*_])[\spunctuation])/, "u").replace(/punctuation/g, en).getRegex(), ac = /\[[^[\]]*?\]\([^\(\)]*?\)|`[^`]*?`|<[^<>]*?>/g, lc = Z(/^(?:\*+(?:((?!\*)[punct])|[^\s*]))|^_+(?:((?!_)[punct])|([^\s_]))/, "u").replace(/punct/g, en).getRegex(), oc = Z("^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)[punct](\\*+)(?=[\\s]|$)|[^punct\\s](\\*+)(?!\\*)(?=[punct\\s]|$)|(?!\\*)[punct\\s](\\*+)(?=[^punct\\s])|[\\s](\\*+)(?!\\*)(?=[punct])|(?!\\*)[punct](\\*+)(?!\\*)(?=[punct])|[^punct\\s](\\*+)(?=[^punct\\s])", "gu").replace(/punct/g, en).getRegex(), sc = Z("^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)[punct](_+)(?=[\\s]|$)|[^punct\\s](_+)(?!_)(?=[punct\\s]|$)|(?!_)[punct\\s](_+)(?=[^punct\\s])|[\\s](_+)(?!_)(?=[punct])|(?!_)[punct](_+)(?!_)(?=[punct])", "gu").replace(/punct/g, en).getRegex(), uc = Z(/\\([punct])/, "gu").replace(/punct/g, en).getRegex(), cc = Z(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/).replace("scheme", /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/).replace("email", /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/).getRegex(), hc = Z(Ki).replace("(?:-->|$)", "-->").getRegex(), fc = Z("^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>").replace("comment", hc).replace("attribute", /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/).getRegex(), Bn = /(?:\[(?:\\.|[^\[\]\\])*\]|\\.|`[^`]*`|[^\[\]\\`])*?/, _c = Z(/^!?\[(label)\]\(\s*(href)(?:\s+(title))?\s*\)/).replace("label", Bn).replace("href", /<(?:\\.|[^\n<>\\])+>|[^\s\x00-\x1f]*/).replace("title", /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/).getRegex(), jl = Z(/^!?\[(label)\]\[(ref)\]/).replace("label", Bn).replace("ref", Ji).getRegex(), Vl = Z(/^!?\[(ref)\](?:\[\])?/).replace("ref", Ji).getRegex(), dc = Z("reflink|nolink(?!\\()", "g").replace("reflink", jl).replace("nolink", Vl).getRegex(), tr = {
  _backpedal: Rt,
  // only used for GFM url
  anyPunctuation: uc,
  autolink: cc,
  blockSkip: ac,
  br: zl,
  code: nc,
  del: Rt,
  emStrongLDelim: lc,
  emStrongRDelimAst: oc,
  emStrongRDelimUnd: sc,
  escape: Gl,
  link: _c,
  nolink: Vl,
  punctuation: rc,
  reflink: jl,
  reflinkSearch: dc,
  tag: fc,
  text: ic,
  url: Rt
}, mc = {
  ...tr,
  link: Z(/^!?\[(label)\]\((.*?)\)/).replace("label", Bn).getRegex(),
  reflink: Z(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", Bn).getRegex()
}, Bi = {
  ...tr,
  escape: Z(Gl).replace("])", "~|])").getRegex(),
  url: Z(/^((?:ftp|https?):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/, "i").replace("email", /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/).getRegex(),
  _backpedal: /(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/,
  del: /^(~~?)(?=[^\s~])([\s\S]*?[^\s~])\1(?=[^~]|$)/,
  text: /^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|https?:\/\/|ftp:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/
}, pc = {
  ...Bi,
  br: Z(zl).replace("{2,}", "*").getRegex(),
  text: Z(Bi.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex()
}, cn = {
  normal: er,
  gfm: ec,
  pedantic: tc
}, Tt = {
  normal: tr,
  gfm: Bi,
  breaks: pc,
  pedantic: mc
};
class Ue {
  constructor(e) {
    Q(this, "tokens");
    Q(this, "options");
    Q(this, "state");
    Q(this, "tokenizer");
    Q(this, "inlineQueue");
    this.tokens = [], this.tokens.links = /* @__PURE__ */ Object.create(null), this.options = e || ct, this.options.tokenizer = this.options.tokenizer || new xn(), this.tokenizer = this.options.tokenizer, this.tokenizer.options = this.options, this.tokenizer.lexer = this, this.inlineQueue = [], this.state = {
      inLink: !1,
      inRawBlock: !1,
      top: !0
    };
    const n = {
      block: cn.normal,
      inline: Tt.normal
    };
    this.options.pedantic ? (n.block = cn.pedantic, n.inline = Tt.pedantic) : this.options.gfm && (n.block = cn.gfm, this.options.breaks ? n.inline = Tt.breaks : n.inline = Tt.gfm), this.tokenizer.rules = n;
  }
  /**
   * Expose Rules
   */
  static get rules() {
    return {
      block: cn,
      inline: Tt
    };
  }
  /**
   * Static Lex Method
   */
  static lex(e, n) {
    return new Ue(n).lex(e);
  }
  /**
   * Static Lex Inline Method
   */
  static lexInline(e, n) {
    return new Ue(n).inlineTokens(e);
  }
  /**
   * Preprocessing
   */
  lex(e) {
    e = e.replace(/\r\n|\r/g, `
`), this.blockTokens(e, this.tokens);
    for (let n = 0; n < this.inlineQueue.length; n++) {
      const i = this.inlineQueue[n];
      this.inlineTokens(i.src, i.tokens);
    }
    return this.inlineQueue = [], this.tokens;
  }
  blockTokens(e, n = []) {
    this.options.pedantic ? e = e.replace(/\t/g, "    ").replace(/^ +$/gm, "") : e = e.replace(/^( *)(\t+)/gm, (o, s, u) => s + "    ".repeat(u.length));
    let i, r, l, a;
    for (; e; )
      if (!(this.options.extensions && this.options.extensions.block && this.options.extensions.block.some((o) => (i = o.call({ lexer: this }, e, n)) ? (e = e.substring(i.raw.length), n.push(i), !0) : !1))) {
        if (i = this.tokenizer.space(e)) {
          e = e.substring(i.raw.length), i.raw.length === 1 && n.length > 0 ? n[n.length - 1].raw += `
` : n.push(i);
          continue;
        }
        if (i = this.tokenizer.code(e)) {
          e = e.substring(i.raw.length), r = n[n.length - 1], r && (r.type === "paragraph" || r.type === "text") ? (r.raw += `
` + i.raw, r.text += `
` + i.text, this.inlineQueue[this.inlineQueue.length - 1].src = r.text) : n.push(i);
          continue;
        }
        if (i = this.tokenizer.fences(e)) {
          e = e.substring(i.raw.length), n.push(i);
          continue;
        }
        if (i = this.tokenizer.heading(e)) {
          e = e.substring(i.raw.length), n.push(i);
          continue;
        }
        if (i = this.tokenizer.hr(e)) {
          e = e.substring(i.raw.length), n.push(i);
          continue;
        }
        if (i = this.tokenizer.blockquote(e)) {
          e = e.substring(i.raw.length), n.push(i);
          continue;
        }
        if (i = this.tokenizer.list(e)) {
          e = e.substring(i.raw.length), n.push(i);
          continue;
        }
        if (i = this.tokenizer.html(e)) {
          e = e.substring(i.raw.length), n.push(i);
          continue;
        }
        if (i = this.tokenizer.def(e)) {
          e = e.substring(i.raw.length), r = n[n.length - 1], r && (r.type === "paragraph" || r.type === "text") ? (r.raw += `
` + i.raw, r.text += `
` + i.raw, this.inlineQueue[this.inlineQueue.length - 1].src = r.text) : this.tokens.links[i.tag] || (this.tokens.links[i.tag] = {
            href: i.href,
            title: i.title
          });
          continue;
        }
        if (i = this.tokenizer.table(e)) {
          e = e.substring(i.raw.length), n.push(i);
          continue;
        }
        if (i = this.tokenizer.lheading(e)) {
          e = e.substring(i.raw.length), n.push(i);
          continue;
        }
        if (l = e, this.options.extensions && this.options.extensions.startBlock) {
          let o = 1 / 0;
          const s = e.slice(1);
          let u;
          this.options.extensions.startBlock.forEach((c) => {
            u = c.call({ lexer: this }, s), typeof u == "number" && u >= 0 && (o = Math.min(o, u));
          }), o < 1 / 0 && o >= 0 && (l = e.substring(0, o + 1));
        }
        if (this.state.top && (i = this.tokenizer.paragraph(l))) {
          r = n[n.length - 1], a && r.type === "paragraph" ? (r.raw += `
` + i.raw, r.text += `
` + i.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = r.text) : n.push(i), a = l.length !== e.length, e = e.substring(i.raw.length);
          continue;
        }
        if (i = this.tokenizer.text(e)) {
          e = e.substring(i.raw.length), r = n[n.length - 1], r && r.type === "text" ? (r.raw += `
` + i.raw, r.text += `
` + i.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = r.text) : n.push(i);
          continue;
        }
        if (e) {
          const o = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(o);
            break;
          } else
            throw new Error(o);
        }
      }
    return this.state.top = !0, n;
  }
  inline(e, n = []) {
    return this.inlineQueue.push({ src: e, tokens: n }), n;
  }
  /**
   * Lexing/Compiling
   */
  inlineTokens(e, n = []) {
    let i, r, l, a = e, o, s, u;
    if (this.tokens.links) {
      const c = Object.keys(this.tokens.links);
      if (c.length > 0)
        for (; (o = this.tokenizer.rules.inline.reflinkSearch.exec(a)) != null; )
          c.includes(o[0].slice(o[0].lastIndexOf("[") + 1, -1)) && (a = a.slice(0, o.index) + "[" + "a".repeat(o[0].length - 2) + "]" + a.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex));
    }
    for (; (o = this.tokenizer.rules.inline.blockSkip.exec(a)) != null; )
      a = a.slice(0, o.index) + "[" + "a".repeat(o[0].length - 2) + "]" + a.slice(this.tokenizer.rules.inline.blockSkip.lastIndex);
    for (; (o = this.tokenizer.rules.inline.anyPunctuation.exec(a)) != null; )
      a = a.slice(0, o.index) + "++" + a.slice(this.tokenizer.rules.inline.anyPunctuation.lastIndex);
    for (; e; )
      if (s || (u = ""), s = !1, !(this.options.extensions && this.options.extensions.inline && this.options.extensions.inline.some((c) => (i = c.call({ lexer: this }, e, n)) ? (e = e.substring(i.raw.length), n.push(i), !0) : !1))) {
        if (i = this.tokenizer.escape(e)) {
          e = e.substring(i.raw.length), n.push(i);
          continue;
        }
        if (i = this.tokenizer.tag(e)) {
          e = e.substring(i.raw.length), r = n[n.length - 1], r && i.type === "text" && r.type === "text" ? (r.raw += i.raw, r.text += i.text) : n.push(i);
          continue;
        }
        if (i = this.tokenizer.link(e)) {
          e = e.substring(i.raw.length), n.push(i);
          continue;
        }
        if (i = this.tokenizer.reflink(e, this.tokens.links)) {
          e = e.substring(i.raw.length), r = n[n.length - 1], r && i.type === "text" && r.type === "text" ? (r.raw += i.raw, r.text += i.text) : n.push(i);
          continue;
        }
        if (i = this.tokenizer.emStrong(e, a, u)) {
          e = e.substring(i.raw.length), n.push(i);
          continue;
        }
        if (i = this.tokenizer.codespan(e)) {
          e = e.substring(i.raw.length), n.push(i);
          continue;
        }
        if (i = this.tokenizer.br(e)) {
          e = e.substring(i.raw.length), n.push(i);
          continue;
        }
        if (i = this.tokenizer.del(e)) {
          e = e.substring(i.raw.length), n.push(i);
          continue;
        }
        if (i = this.tokenizer.autolink(e)) {
          e = e.substring(i.raw.length), n.push(i);
          continue;
        }
        if (!this.state.inLink && (i = this.tokenizer.url(e))) {
          e = e.substring(i.raw.length), n.push(i);
          continue;
        }
        if (l = e, this.options.extensions && this.options.extensions.startInline) {
          let c = 1 / 0;
          const _ = e.slice(1);
          let h;
          this.options.extensions.startInline.forEach((d) => {
            h = d.call({ lexer: this }, _), typeof h == "number" && h >= 0 && (c = Math.min(c, h));
          }), c < 1 / 0 && c >= 0 && (l = e.substring(0, c + 1));
        }
        if (i = this.tokenizer.inlineText(l)) {
          e = e.substring(i.raw.length), i.raw.slice(-1) !== "_" && (u = i.raw.slice(-1)), s = !0, r = n[n.length - 1], r && r.type === "text" ? (r.raw += i.raw, r.text += i.text) : n.push(i);
          continue;
        }
        if (e) {
          const c = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(c);
            break;
          } else
            throw new Error(c);
        }
      }
    return n;
  }
}
class Tn {
  constructor(e) {
    Q(this, "options");
    this.options = e || ct;
  }
  code(e, n, i) {
    var l;
    const r = (l = (n || "").match(/^\S*/)) == null ? void 0 : l[0];
    return e = e.replace(/\n$/, "") + `
`, r ? '<pre><code class="language-' + be(r) + '">' + (i ? e : be(e, !0)) + `</code></pre>
` : "<pre><code>" + (i ? e : be(e, !0)) + `</code></pre>
`;
  }
  blockquote(e) {
    return `<blockquote>
${e}</blockquote>
`;
  }
  html(e, n) {
    return e;
  }
  heading(e, n, i) {
    return `<h${n}>${e}</h${n}>
`;
  }
  hr() {
    return `<hr>
`;
  }
  list(e, n, i) {
    const r = n ? "ol" : "ul", l = n && i !== 1 ? ' start="' + i + '"' : "";
    return "<" + r + l + `>
` + e + "</" + r + `>
`;
  }
  listitem(e, n, i) {
    return `<li>${e}</li>
`;
  }
  checkbox(e) {
    return "<input " + (e ? 'checked="" ' : "") + 'disabled="" type="checkbox">';
  }
  paragraph(e) {
    return `<p>${e}</p>
`;
  }
  table(e, n) {
    return n && (n = `<tbody>${n}</tbody>`), `<table>
<thead>
` + e + `</thead>
` + n + `</table>
`;
  }
  tablerow(e) {
    return `<tr>
${e}</tr>
`;
  }
  tablecell(e, n) {
    const i = n.header ? "th" : "td";
    return (n.align ? `<${i} align="${n.align}">` : `<${i}>`) + e + `</${i}>
`;
  }
  /**
   * span level renderer
   */
  strong(e) {
    return `<strong>${e}</strong>`;
  }
  em(e) {
    return `<em>${e}</em>`;
  }
  codespan(e) {
    return `<code>${e}</code>`;
  }
  br() {
    return "<br>";
  }
  del(e) {
    return `<del>${e}</del>`;
  }
  link(e, n, i) {
    const r = Lr(e);
    if (r === null)
      return i;
    e = r;
    let l = '<a href="' + e + '"';
    return n && (l += ' title="' + n + '"'), l += ">" + i + "</a>", l;
  }
  image(e, n, i) {
    const r = Lr(e);
    if (r === null)
      return i;
    e = r;
    let l = `<img src="${e}" alt="${i}"`;
    return n && (l += ` title="${n}"`), l += ">", l;
  }
  text(e) {
    return e;
  }
}
class nr {
  // no need for block level renderers
  strong(e) {
    return e;
  }
  em(e) {
    return e;
  }
  codespan(e) {
    return e;
  }
  del(e) {
    return e;
  }
  html(e) {
    return e;
  }
  text(e) {
    return e;
  }
  link(e, n, i) {
    return "" + i;
  }
  image(e, n, i) {
    return "" + i;
  }
  br() {
    return "";
  }
}
class Ge {
  constructor(e) {
    Q(this, "options");
    Q(this, "renderer");
    Q(this, "textRenderer");
    this.options = e || ct, this.options.renderer = this.options.renderer || new Tn(), this.renderer = this.options.renderer, this.renderer.options = this.options, this.textRenderer = new nr();
  }
  /**
   * Static Parse Method
   */
  static parse(e, n) {
    return new Ge(n).parse(e);
  }
  /**
   * Static Parse Inline Method
   */
  static parseInline(e, n) {
    return new Ge(n).parseInline(e);
  }
  /**
   * Parse Loop
   */
  parse(e, n = !0) {
    let i = "";
    for (let r = 0; r < e.length; r++) {
      const l = e[r];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[l.type]) {
        const a = l, o = this.options.extensions.renderers[a.type].call({ parser: this }, a);
        if (o !== !1 || !["space", "hr", "heading", "code", "table", "blockquote", "list", "html", "paragraph", "text"].includes(a.type)) {
          i += o || "";
          continue;
        }
      }
      switch (l.type) {
        case "space":
          continue;
        case "hr": {
          i += this.renderer.hr();
          continue;
        }
        case "heading": {
          const a = l;
          i += this.renderer.heading(this.parseInline(a.tokens), a.depth, qu(this.parseInline(a.tokens, this.textRenderer)));
          continue;
        }
        case "code": {
          const a = l;
          i += this.renderer.code(a.text, a.lang, !!a.escaped);
          continue;
        }
        case "table": {
          const a = l;
          let o = "", s = "";
          for (let c = 0; c < a.header.length; c++)
            s += this.renderer.tablecell(this.parseInline(a.header[c].tokens), { header: !0, align: a.align[c] });
          o += this.renderer.tablerow(s);
          let u = "";
          for (let c = 0; c < a.rows.length; c++) {
            const _ = a.rows[c];
            s = "";
            for (let h = 0; h < _.length; h++)
              s += this.renderer.tablecell(this.parseInline(_[h].tokens), { header: !1, align: a.align[h] });
            u += this.renderer.tablerow(s);
          }
          i += this.renderer.table(o, u);
          continue;
        }
        case "blockquote": {
          const a = l, o = this.parse(a.tokens);
          i += this.renderer.blockquote(o);
          continue;
        }
        case "list": {
          const a = l, o = a.ordered, s = a.start, u = a.loose;
          let c = "";
          for (let _ = 0; _ < a.items.length; _++) {
            const h = a.items[_], d = h.checked, D = h.task;
            let E = "";
            if (h.task) {
              const F = this.renderer.checkbox(!!d);
              u ? h.tokens.length > 0 && h.tokens[0].type === "paragraph" ? (h.tokens[0].text = F + " " + h.tokens[0].text, h.tokens[0].tokens && h.tokens[0].tokens.length > 0 && h.tokens[0].tokens[0].type === "text" && (h.tokens[0].tokens[0].text = F + " " + h.tokens[0].tokens[0].text)) : h.tokens.unshift({
                type: "text",
                text: F + " "
              }) : E += F + " ";
            }
            E += this.parse(h.tokens, u), c += this.renderer.listitem(E, D, !!d);
          }
          i += this.renderer.list(c, o, s);
          continue;
        }
        case "html": {
          const a = l;
          i += this.renderer.html(a.text, a.block);
          continue;
        }
        case "paragraph": {
          const a = l;
          i += this.renderer.paragraph(this.parseInline(a.tokens));
          continue;
        }
        case "text": {
          let a = l, o = a.tokens ? this.parseInline(a.tokens) : a.text;
          for (; r + 1 < e.length && e[r + 1].type === "text"; )
            a = e[++r], o += `
` + (a.tokens ? this.parseInline(a.tokens) : a.text);
          i += n ? this.renderer.paragraph(o) : o;
          continue;
        }
        default: {
          const a = 'Token with "' + l.type + '" type was not found.';
          if (this.options.silent)
            return console.error(a), "";
          throw new Error(a);
        }
      }
    }
    return i;
  }
  /**
   * Parse Inline Tokens
   */
  parseInline(e, n) {
    n = n || this.renderer;
    let i = "";
    for (let r = 0; r < e.length; r++) {
      const l = e[r];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[l.type]) {
        const a = this.options.extensions.renderers[l.type].call({ parser: this }, l);
        if (a !== !1 || !["escape", "html", "link", "image", "strong", "em", "codespan", "br", "del", "text"].includes(l.type)) {
          i += a || "";
          continue;
        }
      }
      switch (l.type) {
        case "escape": {
          const a = l;
          i += n.text(a.text);
          break;
        }
        case "html": {
          const a = l;
          i += n.html(a.text);
          break;
        }
        case "link": {
          const a = l;
          i += n.link(a.href, a.title, this.parseInline(a.tokens, n));
          break;
        }
        case "image": {
          const a = l;
          i += n.image(a.href, a.title, a.text);
          break;
        }
        case "strong": {
          const a = l;
          i += n.strong(this.parseInline(a.tokens, n));
          break;
        }
        case "em": {
          const a = l;
          i += n.em(this.parseInline(a.tokens, n));
          break;
        }
        case "codespan": {
          const a = l;
          i += n.codespan(a.text);
          break;
        }
        case "br": {
          i += n.br();
          break;
        }
        case "del": {
          const a = l;
          i += n.del(this.parseInline(a.tokens, n));
          break;
        }
        case "text": {
          const a = l;
          i += n.text(a.text);
          break;
        }
        default: {
          const a = 'Token with "' + l.type + '" type was not found.';
          if (this.options.silent)
            return console.error(a), "";
          throw new Error(a);
        }
      }
    }
    return i;
  }
}
class Mt {
  constructor(e) {
    Q(this, "options");
    this.options = e || ct;
  }
  /**
   * Process markdown before marked
   */
  preprocess(e) {
    return e;
  }
  /**
   * Process HTML after marked is finished
   */
  postprocess(e) {
    return e;
  }
  /**
   * Process all tokens before walk tokens
   */
  processAllTokens(e) {
    return e;
  }
}
Q(Mt, "passThroughHooks", /* @__PURE__ */ new Set([
  "preprocess",
  "postprocess",
  "processAllTokens"
]));
var st, Ti, Zl;
class Xl {
  constructor(...e) {
    cr(this, st);
    Q(this, "defaults", Qi());
    Q(this, "options", this.setOptions);
    Q(this, "parse", on(this, st, Ti).call(this, Ue.lex, Ge.parse));
    Q(this, "parseInline", on(this, st, Ti).call(this, Ue.lexInline, Ge.parseInline));
    Q(this, "Parser", Ge);
    Q(this, "Renderer", Tn);
    Q(this, "TextRenderer", nr);
    Q(this, "Lexer", Ue);
    Q(this, "Tokenizer", xn);
    Q(this, "Hooks", Mt);
    this.use(...e);
  }
  /**
   * Run callback for every token
   */
  walkTokens(e, n) {
    var r, l;
    let i = [];
    for (const a of e)
      switch (i = i.concat(n.call(this, a)), a.type) {
        case "table": {
          const o = a;
          for (const s of o.header)
            i = i.concat(this.walkTokens(s.tokens, n));
          for (const s of o.rows)
            for (const u of s)
              i = i.concat(this.walkTokens(u.tokens, n));
          break;
        }
        case "list": {
          const o = a;
          i = i.concat(this.walkTokens(o.items, n));
          break;
        }
        default: {
          const o = a;
          (l = (r = this.defaults.extensions) == null ? void 0 : r.childTokens) != null && l[o.type] ? this.defaults.extensions.childTokens[o.type].forEach((s) => {
            const u = o[s].flat(1 / 0);
            i = i.concat(this.walkTokens(u, n));
          }) : o.tokens && (i = i.concat(this.walkTokens(o.tokens, n)));
        }
      }
    return i;
  }
  use(...e) {
    const n = this.defaults.extensions || { renderers: {}, childTokens: {} };
    return e.forEach((i) => {
      const r = { ...i };
      if (r.async = this.defaults.async || r.async || !1, i.extensions && (i.extensions.forEach((l) => {
        if (!l.name)
          throw new Error("extension name required");
        if ("renderer" in l) {
          const a = n.renderers[l.name];
          a ? n.renderers[l.name] = function(...o) {
            let s = l.renderer.apply(this, o);
            return s === !1 && (s = a.apply(this, o)), s;
          } : n.renderers[l.name] = l.renderer;
        }
        if ("tokenizer" in l) {
          if (!l.level || l.level !== "block" && l.level !== "inline")
            throw new Error("extension level must be 'block' or 'inline'");
          const a = n[l.level];
          a ? a.unshift(l.tokenizer) : n[l.level] = [l.tokenizer], l.start && (l.level === "block" ? n.startBlock ? n.startBlock.push(l.start) : n.startBlock = [l.start] : l.level === "inline" && (n.startInline ? n.startInline.push(l.start) : n.startInline = [l.start]));
        }
        "childTokens" in l && l.childTokens && (n.childTokens[l.name] = l.childTokens);
      }), r.extensions = n), i.renderer) {
        const l = this.defaults.renderer || new Tn(this.defaults);
        for (const a in i.renderer) {
          if (!(a in l))
            throw new Error(`renderer '${a}' does not exist`);
          if (a === "options")
            continue;
          const o = a, s = i.renderer[o], u = l[o];
          l[o] = (...c) => {
            let _ = s.apply(l, c);
            return _ === !1 && (_ = u.apply(l, c)), _ || "";
          };
        }
        r.renderer = l;
      }
      if (i.tokenizer) {
        const l = this.defaults.tokenizer || new xn(this.defaults);
        for (const a in i.tokenizer) {
          if (!(a in l))
            throw new Error(`tokenizer '${a}' does not exist`);
          if (["options", "rules", "lexer"].includes(a))
            continue;
          const o = a, s = i.tokenizer[o], u = l[o];
          l[o] = (...c) => {
            let _ = s.apply(l, c);
            return _ === !1 && (_ = u.apply(l, c)), _;
          };
        }
        r.tokenizer = l;
      }
      if (i.hooks) {
        const l = this.defaults.hooks || new Mt();
        for (const a in i.hooks) {
          if (!(a in l))
            throw new Error(`hook '${a}' does not exist`);
          if (a === "options")
            continue;
          const o = a, s = i.hooks[o], u = l[o];
          Mt.passThroughHooks.has(a) ? l[o] = (c) => {
            if (this.defaults.async)
              return Promise.resolve(s.call(l, c)).then((h) => u.call(l, h));
            const _ = s.call(l, c);
            return u.call(l, _);
          } : l[o] = (...c) => {
            let _ = s.apply(l, c);
            return _ === !1 && (_ = u.apply(l, c)), _;
          };
        }
        r.hooks = l;
      }
      if (i.walkTokens) {
        const l = this.defaults.walkTokens, a = i.walkTokens;
        r.walkTokens = function(o) {
          let s = [];
          return s.push(a.call(this, o)), l && (s = s.concat(l.call(this, o))), s;
        };
      }
      this.defaults = { ...this.defaults, ...r };
    }), this;
  }
  setOptions(e) {
    return this.defaults = { ...this.defaults, ...e }, this;
  }
  lexer(e, n) {
    return Ue.lex(e, n ?? this.defaults);
  }
  parser(e, n) {
    return Ge.parse(e, n ?? this.defaults);
  }
}
st = new WeakSet(), Ti = function(e, n) {
  return (i, r) => {
    const l = { ...r }, a = { ...this.defaults, ...l };
    this.defaults.async === !0 && l.async === !1 && (a.silent || console.warn("marked(): The async option was set to true by an extension. The async: false option sent to parse will be ignored."), a.async = !0);
    const o = on(this, st, Zl).call(this, !!a.silent, !!a.async);
    if (typeof i > "u" || i === null)
      return o(new Error("marked(): input parameter is undefined or null"));
    if (typeof i != "string")
      return o(new Error("marked(): input parameter is of type " + Object.prototype.toString.call(i) + ", string expected"));
    if (a.hooks && (a.hooks.options = a), a.async)
      return Promise.resolve(a.hooks ? a.hooks.preprocess(i) : i).then((s) => e(s, a)).then((s) => a.hooks ? a.hooks.processAllTokens(s) : s).then((s) => a.walkTokens ? Promise.all(this.walkTokens(s, a.walkTokens)).then(() => s) : s).then((s) => n(s, a)).then((s) => a.hooks ? a.hooks.postprocess(s) : s).catch(o);
    try {
      a.hooks && (i = a.hooks.preprocess(i));
      let s = e(i, a);
      a.hooks && (s = a.hooks.processAllTokens(s)), a.walkTokens && this.walkTokens(s, a.walkTokens);
      let u = n(s, a);
      return a.hooks && (u = a.hooks.postprocess(u)), u;
    } catch (s) {
      return o(s);
    }
  };
}, Zl = function(e, n) {
  return (i) => {
    if (i.message += `
Please report this to https://github.com/markedjs/marked.`, e) {
      const r = "<p>An error occurred:</p><pre>" + be(i.message + "", !0) + "</pre>";
      return n ? Promise.resolve(r) : r;
    }
    if (n)
      return Promise.reject(i);
    throw i;
  };
};
const ot = new Xl();
function X(t, e) {
  return ot.parse(t, e);
}
X.options = X.setOptions = function(t) {
  return ot.setOptions(t), X.defaults = ot.defaults, Nl(X.defaults), X;
};
X.getDefaults = Qi;
X.defaults = ct;
X.use = function(...t) {
  return ot.use(...t), X.defaults = ot.defaults, Nl(X.defaults), X;
};
X.walkTokens = function(t, e) {
  return ot.walkTokens(t, e);
};
X.parseInline = ot.parseInline;
X.Parser = Ge;
X.parser = Ge.parse;
X.Renderer = Tn;
X.TextRenderer = nr;
X.Lexer = Ue;
X.lexer = Ue.lex;
X.Tokenizer = xn;
X.Hooks = Mt;
X.parse = X;
X.options;
X.setOptions;
X.use;
X.walkTokens;
X.parseInline;
Ge.parse;
Ue.lex;
function gc(t) {
  if (typeof t == "function" && (t = {
    highlight: t
  }), !t || typeof t.highlight != "function")
    throw new Error("Must provide highlight function");
  return typeof t.langPrefix != "string" && (t.langPrefix = "language-"), typeof t.emptyLangClass != "string" && (t.emptyLangClass = ""), {
    async: !!t.async,
    walkTokens(e) {
      if (e.type !== "code")
        return;
      const n = Or(e.lang);
      if (t.async)
        return Promise.resolve(t.highlight(e.text, n, e.lang || "")).then(Rr(e));
      const i = t.highlight(e.text, n, e.lang || "");
      if (i instanceof Promise)
        throw new Error("markedHighlight is not set to async but the highlight function is async. Set the async option to true on markedHighlight to await the async highlight function.");
      Rr(e)(i);
    },
    useNewRenderer: !0,
    renderer: {
      code(e, n, i) {
        typeof e == "object" && (i = e.escaped, n = e.lang, e = e.text);
        const r = Or(n), l = r ? t.langPrefix + qr(r) : t.emptyLangClass, a = l ? ` class="${l}"` : "";
        return e = e.replace(/\n$/, ""), `<pre><code${a}>${i ? e : qr(e, !0)}
</code></pre>`;
      }
    }
  };
}
function Or(t) {
  return (t || "").match(/\S*/)[0];
}
function Rr(t) {
  return (e) => {
    typeof e == "string" && e !== t.text && (t.escaped = !0, t.text = e);
  };
}
const Wl = /[&<>"']/, bc = new RegExp(Wl.source, "g"), Ql = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, vc = new RegExp(Ql.source, "g"), yc = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, Mr = (t) => yc[t];
function qr(t, e) {
  if (e) {
    if (Wl.test(t))
      return t.replace(bc, Mr);
  } else if (Ql.test(t))
    return t.replace(vc, Mr);
  return t;
}
const wc = /[\0-\x1F!-,\.\/:-@\[-\^`\{-\xA9\xAB-\xB4\xB6-\xB9\xBB-\xBF\xD7\xF7\u02C2-\u02C5\u02D2-\u02DF\u02E5-\u02EB\u02ED\u02EF-\u02FF\u0375\u0378\u0379\u037E\u0380-\u0385\u0387\u038B\u038D\u03A2\u03F6\u0482\u0530\u0557\u0558\u055A-\u055F\u0589-\u0590\u05BE\u05C0\u05C3\u05C6\u05C8-\u05CF\u05EB-\u05EE\u05F3-\u060F\u061B-\u061F\u066A-\u066D\u06D4\u06DD\u06DE\u06E9\u06FD\u06FE\u0700-\u070F\u074B\u074C\u07B2-\u07BF\u07F6-\u07F9\u07FB\u07FC\u07FE\u07FF\u082E-\u083F\u085C-\u085F\u086B-\u089F\u08B5\u08C8-\u08D2\u08E2\u0964\u0965\u0970\u0984\u098D\u098E\u0991\u0992\u09A9\u09B1\u09B3-\u09B5\u09BA\u09BB\u09C5\u09C6\u09C9\u09CA\u09CF-\u09D6\u09D8-\u09DB\u09DE\u09E4\u09E5\u09F2-\u09FB\u09FD\u09FF\u0A00\u0A04\u0A0B-\u0A0E\u0A11\u0A12\u0A29\u0A31\u0A34\u0A37\u0A3A\u0A3B\u0A3D\u0A43-\u0A46\u0A49\u0A4A\u0A4E-\u0A50\u0A52-\u0A58\u0A5D\u0A5F-\u0A65\u0A76-\u0A80\u0A84\u0A8E\u0A92\u0AA9\u0AB1\u0AB4\u0ABA\u0ABB\u0AC6\u0ACA\u0ACE\u0ACF\u0AD1-\u0ADF\u0AE4\u0AE5\u0AF0-\u0AF8\u0B00\u0B04\u0B0D\u0B0E\u0B11\u0B12\u0B29\u0B31\u0B34\u0B3A\u0B3B\u0B45\u0B46\u0B49\u0B4A\u0B4E-\u0B54\u0B58-\u0B5B\u0B5E\u0B64\u0B65\u0B70\u0B72-\u0B81\u0B84\u0B8B-\u0B8D\u0B91\u0B96-\u0B98\u0B9B\u0B9D\u0BA0-\u0BA2\u0BA5-\u0BA7\u0BAB-\u0BAD\u0BBA-\u0BBD\u0BC3-\u0BC5\u0BC9\u0BCE\u0BCF\u0BD1-\u0BD6\u0BD8-\u0BE5\u0BF0-\u0BFF\u0C0D\u0C11\u0C29\u0C3A-\u0C3C\u0C45\u0C49\u0C4E-\u0C54\u0C57\u0C5B-\u0C5F\u0C64\u0C65\u0C70-\u0C7F\u0C84\u0C8D\u0C91\u0CA9\u0CB4\u0CBA\u0CBB\u0CC5\u0CC9\u0CCE-\u0CD4\u0CD7-\u0CDD\u0CDF\u0CE4\u0CE5\u0CF0\u0CF3-\u0CFF\u0D0D\u0D11\u0D45\u0D49\u0D4F-\u0D53\u0D58-\u0D5E\u0D64\u0D65\u0D70-\u0D79\u0D80\u0D84\u0D97-\u0D99\u0DB2\u0DBC\u0DBE\u0DBF\u0DC7-\u0DC9\u0DCB-\u0DCE\u0DD5\u0DD7\u0DE0-\u0DE5\u0DF0\u0DF1\u0DF4-\u0E00\u0E3B-\u0E3F\u0E4F\u0E5A-\u0E80\u0E83\u0E85\u0E8B\u0EA4\u0EA6\u0EBE\u0EBF\u0EC5\u0EC7\u0ECE\u0ECF\u0EDA\u0EDB\u0EE0-\u0EFF\u0F01-\u0F17\u0F1A-\u0F1F\u0F2A-\u0F34\u0F36\u0F38\u0F3A-\u0F3D\u0F48\u0F6D-\u0F70\u0F85\u0F98\u0FBD-\u0FC5\u0FC7-\u0FFF\u104A-\u104F\u109E\u109F\u10C6\u10C8-\u10CC\u10CE\u10CF\u10FB\u1249\u124E\u124F\u1257\u1259\u125E\u125F\u1289\u128E\u128F\u12B1\u12B6\u12B7\u12BF\u12C1\u12C6\u12C7\u12D7\u1311\u1316\u1317\u135B\u135C\u1360-\u137F\u1390-\u139F\u13F6\u13F7\u13FE-\u1400\u166D\u166E\u1680\u169B-\u169F\u16EB-\u16ED\u16F9-\u16FF\u170D\u1715-\u171F\u1735-\u173F\u1754-\u175F\u176D\u1771\u1774-\u177F\u17D4-\u17D6\u17D8-\u17DB\u17DE\u17DF\u17EA-\u180A\u180E\u180F\u181A-\u181F\u1879-\u187F\u18AB-\u18AF\u18F6-\u18FF\u191F\u192C-\u192F\u193C-\u1945\u196E\u196F\u1975-\u197F\u19AC-\u19AF\u19CA-\u19CF\u19DA-\u19FF\u1A1C-\u1A1F\u1A5F\u1A7D\u1A7E\u1A8A-\u1A8F\u1A9A-\u1AA6\u1AA8-\u1AAF\u1AC1-\u1AFF\u1B4C-\u1B4F\u1B5A-\u1B6A\u1B74-\u1B7F\u1BF4-\u1BFF\u1C38-\u1C3F\u1C4A-\u1C4C\u1C7E\u1C7F\u1C89-\u1C8F\u1CBB\u1CBC\u1CC0-\u1CCF\u1CD3\u1CFB-\u1CFF\u1DFA\u1F16\u1F17\u1F1E\u1F1F\u1F46\u1F47\u1F4E\u1F4F\u1F58\u1F5A\u1F5C\u1F5E\u1F7E\u1F7F\u1FB5\u1FBD\u1FBF-\u1FC1\u1FC5\u1FCD-\u1FCF\u1FD4\u1FD5\u1FDC-\u1FDF\u1FED-\u1FF1\u1FF5\u1FFD-\u203E\u2041-\u2053\u2055-\u2070\u2072-\u207E\u2080-\u208F\u209D-\u20CF\u20F1-\u2101\u2103-\u2106\u2108\u2109\u2114\u2116-\u2118\u211E-\u2123\u2125\u2127\u2129\u212E\u213A\u213B\u2140-\u2144\u214A-\u214D\u214F-\u215F\u2189-\u24B5\u24EA-\u2BFF\u2C2F\u2C5F\u2CE5-\u2CEA\u2CF4-\u2CFF\u2D26\u2D28-\u2D2C\u2D2E\u2D2F\u2D68-\u2D6E\u2D70-\u2D7E\u2D97-\u2D9F\u2DA7\u2DAF\u2DB7\u2DBF\u2DC7\u2DCF\u2DD7\u2DDF\u2E00-\u2E2E\u2E30-\u3004\u3008-\u3020\u3030\u3036\u3037\u303D-\u3040\u3097\u3098\u309B\u309C\u30A0\u30FB\u3100-\u3104\u3130\u318F-\u319F\u31C0-\u31EF\u3200-\u33FF\u4DC0-\u4DFF\u9FFD-\u9FFF\uA48D-\uA4CF\uA4FE\uA4FF\uA60D-\uA60F\uA62C-\uA63F\uA673\uA67E\uA6F2-\uA716\uA720\uA721\uA789\uA78A\uA7C0\uA7C1\uA7CB-\uA7F4\uA828-\uA82B\uA82D-\uA83F\uA874-\uA87F\uA8C6-\uA8CF\uA8DA-\uA8DF\uA8F8-\uA8FA\uA8FC\uA92E\uA92F\uA954-\uA95F\uA97D-\uA97F\uA9C1-\uA9CE\uA9DA-\uA9DF\uA9FF\uAA37-\uAA3F\uAA4E\uAA4F\uAA5A-\uAA5F\uAA77-\uAA79\uAAC3-\uAADA\uAADE\uAADF\uAAF0\uAAF1\uAAF7-\uAB00\uAB07\uAB08\uAB0F\uAB10\uAB17-\uAB1F\uAB27\uAB2F\uAB5B\uAB6A-\uAB6F\uABEB\uABEE\uABEF\uABFA-\uABFF\uD7A4-\uD7AF\uD7C7-\uD7CA\uD7FC-\uD7FF\uE000-\uF8FF\uFA6E\uFA6F\uFADA-\uFAFF\uFB07-\uFB12\uFB18-\uFB1C\uFB29\uFB37\uFB3D\uFB3F\uFB42\uFB45\uFBB2-\uFBD2\uFD3E-\uFD4F\uFD90\uFD91\uFDC8-\uFDEF\uFDFC-\uFDFF\uFE10-\uFE1F\uFE30-\uFE32\uFE35-\uFE4C\uFE50-\uFE6F\uFE75\uFEFD-\uFF0F\uFF1A-\uFF20\uFF3B-\uFF3E\uFF40\uFF5B-\uFF65\uFFBF-\uFFC1\uFFC8\uFFC9\uFFD0\uFFD1\uFFD8\uFFD9\uFFDD-\uFFFF]|\uD800[\uDC0C\uDC27\uDC3B\uDC3E\uDC4E\uDC4F\uDC5E-\uDC7F\uDCFB-\uDD3F\uDD75-\uDDFC\uDDFE-\uDE7F\uDE9D-\uDE9F\uDED1-\uDEDF\uDEE1-\uDEFF\uDF20-\uDF2C\uDF4B-\uDF4F\uDF7B-\uDF7F\uDF9E\uDF9F\uDFC4-\uDFC7\uDFD0\uDFD6-\uDFFF]|\uD801[\uDC9E\uDC9F\uDCAA-\uDCAF\uDCD4-\uDCD7\uDCFC-\uDCFF\uDD28-\uDD2F\uDD64-\uDDFF\uDF37-\uDF3F\uDF56-\uDF5F\uDF68-\uDFFF]|\uD802[\uDC06\uDC07\uDC09\uDC36\uDC39-\uDC3B\uDC3D\uDC3E\uDC56-\uDC5F\uDC77-\uDC7F\uDC9F-\uDCDF\uDCF3\uDCF6-\uDCFF\uDD16-\uDD1F\uDD3A-\uDD7F\uDDB8-\uDDBD\uDDC0-\uDDFF\uDE04\uDE07-\uDE0B\uDE14\uDE18\uDE36\uDE37\uDE3B-\uDE3E\uDE40-\uDE5F\uDE7D-\uDE7F\uDE9D-\uDEBF\uDEC8\uDEE7-\uDEFF\uDF36-\uDF3F\uDF56-\uDF5F\uDF73-\uDF7F\uDF92-\uDFFF]|\uD803[\uDC49-\uDC7F\uDCB3-\uDCBF\uDCF3-\uDCFF\uDD28-\uDD2F\uDD3A-\uDE7F\uDEAA\uDEAD-\uDEAF\uDEB2-\uDEFF\uDF1D-\uDF26\uDF28-\uDF2F\uDF51-\uDFAF\uDFC5-\uDFDF\uDFF7-\uDFFF]|\uD804[\uDC47-\uDC65\uDC70-\uDC7E\uDCBB-\uDCCF\uDCE9-\uDCEF\uDCFA-\uDCFF\uDD35\uDD40-\uDD43\uDD48-\uDD4F\uDD74\uDD75\uDD77-\uDD7F\uDDC5-\uDDC8\uDDCD\uDDDB\uDDDD-\uDDFF\uDE12\uDE38-\uDE3D\uDE3F-\uDE7F\uDE87\uDE89\uDE8E\uDE9E\uDEA9-\uDEAF\uDEEB-\uDEEF\uDEFA-\uDEFF\uDF04\uDF0D\uDF0E\uDF11\uDF12\uDF29\uDF31\uDF34\uDF3A\uDF45\uDF46\uDF49\uDF4A\uDF4E\uDF4F\uDF51-\uDF56\uDF58-\uDF5C\uDF64\uDF65\uDF6D-\uDF6F\uDF75-\uDFFF]|\uD805[\uDC4B-\uDC4F\uDC5A-\uDC5D\uDC62-\uDC7F\uDCC6\uDCC8-\uDCCF\uDCDA-\uDD7F\uDDB6\uDDB7\uDDC1-\uDDD7\uDDDE-\uDDFF\uDE41-\uDE43\uDE45-\uDE4F\uDE5A-\uDE7F\uDEB9-\uDEBF\uDECA-\uDEFF\uDF1B\uDF1C\uDF2C-\uDF2F\uDF3A-\uDFFF]|\uD806[\uDC3B-\uDC9F\uDCEA-\uDCFE\uDD07\uDD08\uDD0A\uDD0B\uDD14\uDD17\uDD36\uDD39\uDD3A\uDD44-\uDD4F\uDD5A-\uDD9F\uDDA8\uDDA9\uDDD8\uDDD9\uDDE2\uDDE5-\uDDFF\uDE3F-\uDE46\uDE48-\uDE4F\uDE9A-\uDE9C\uDE9E-\uDEBF\uDEF9-\uDFFF]|\uD807[\uDC09\uDC37\uDC41-\uDC4F\uDC5A-\uDC71\uDC90\uDC91\uDCA8\uDCB7-\uDCFF\uDD07\uDD0A\uDD37-\uDD39\uDD3B\uDD3E\uDD48-\uDD4F\uDD5A-\uDD5F\uDD66\uDD69\uDD8F\uDD92\uDD99-\uDD9F\uDDAA-\uDEDF\uDEF7-\uDFAF\uDFB1-\uDFFF]|\uD808[\uDF9A-\uDFFF]|\uD809[\uDC6F-\uDC7F\uDD44-\uDFFF]|[\uD80A\uD80B\uD80E-\uD810\uD812-\uD819\uD824-\uD82B\uD82D\uD82E\uD830-\uD833\uD837\uD839\uD83D\uD83F\uD87B-\uD87D\uD87F\uD885-\uDB3F\uDB41-\uDBFF][\uDC00-\uDFFF]|\uD80D[\uDC2F-\uDFFF]|\uD811[\uDE47-\uDFFF]|\uD81A[\uDE39-\uDE3F\uDE5F\uDE6A-\uDECF\uDEEE\uDEEF\uDEF5-\uDEFF\uDF37-\uDF3F\uDF44-\uDF4F\uDF5A-\uDF62\uDF78-\uDF7C\uDF90-\uDFFF]|\uD81B[\uDC00-\uDE3F\uDE80-\uDEFF\uDF4B-\uDF4E\uDF88-\uDF8E\uDFA0-\uDFDF\uDFE2\uDFE5-\uDFEF\uDFF2-\uDFFF]|\uD821[\uDFF8-\uDFFF]|\uD823[\uDCD6-\uDCFF\uDD09-\uDFFF]|\uD82C[\uDD1F-\uDD4F\uDD53-\uDD63\uDD68-\uDD6F\uDEFC-\uDFFF]|\uD82F[\uDC6B-\uDC6F\uDC7D-\uDC7F\uDC89-\uDC8F\uDC9A-\uDC9C\uDC9F-\uDFFF]|\uD834[\uDC00-\uDD64\uDD6A-\uDD6C\uDD73-\uDD7A\uDD83\uDD84\uDD8C-\uDDA9\uDDAE-\uDE41\uDE45-\uDFFF]|\uD835[\uDC55\uDC9D\uDCA0\uDCA1\uDCA3\uDCA4\uDCA7\uDCA8\uDCAD\uDCBA\uDCBC\uDCC4\uDD06\uDD0B\uDD0C\uDD15\uDD1D\uDD3A\uDD3F\uDD45\uDD47-\uDD49\uDD51\uDEA6\uDEA7\uDEC1\uDEDB\uDEFB\uDF15\uDF35\uDF4F\uDF6F\uDF89\uDFA9\uDFC3\uDFCC\uDFCD]|\uD836[\uDC00-\uDDFF\uDE37-\uDE3A\uDE6D-\uDE74\uDE76-\uDE83\uDE85-\uDE9A\uDEA0\uDEB0-\uDFFF]|\uD838[\uDC07\uDC19\uDC1A\uDC22\uDC25\uDC2B-\uDCFF\uDD2D-\uDD2F\uDD3E\uDD3F\uDD4A-\uDD4D\uDD4F-\uDEBF\uDEFA-\uDFFF]|\uD83A[\uDCC5-\uDCCF\uDCD7-\uDCFF\uDD4C-\uDD4F\uDD5A-\uDFFF]|\uD83B[\uDC00-\uDDFF\uDE04\uDE20\uDE23\uDE25\uDE26\uDE28\uDE33\uDE38\uDE3A\uDE3C-\uDE41\uDE43-\uDE46\uDE48\uDE4A\uDE4C\uDE50\uDE53\uDE55\uDE56\uDE58\uDE5A\uDE5C\uDE5E\uDE60\uDE63\uDE65\uDE66\uDE6B\uDE73\uDE78\uDE7D\uDE7F\uDE8A\uDE9C-\uDEA0\uDEA4\uDEAA\uDEBC-\uDFFF]|\uD83C[\uDC00-\uDD2F\uDD4A-\uDD4F\uDD6A-\uDD6F\uDD8A-\uDFFF]|\uD83E[\uDC00-\uDFEF\uDFFA-\uDFFF]|\uD869[\uDEDE-\uDEFF]|\uD86D[\uDF35-\uDF3F]|\uD86E[\uDC1E\uDC1F]|\uD873[\uDEA2-\uDEAF]|\uD87A[\uDFE1-\uDFFF]|\uD87E[\uDE1E-\uDFFF]|\uD884[\uDF4B-\uDFFF]|\uDB40[\uDC00-\uDCFF\uDDF0-\uDFFF]/g, Dc = Object.hasOwnProperty;
class ir {
  /**
   * Create a new slug class.
   */
  constructor() {
    this.occurrences, this.reset();
  }
  /**
   * Generate a unique slug.
  *
  * Tracks previously generated slugs: repeated calls with the same value
  * will result in different slugs.
  * Use the `slug` function to get same slugs.
   *
   * @param  {string} value
   *   String of text to slugify
   * @param  {boolean} [maintainCase=false]
   *   Keep the current case, otherwise make all lowercase
   * @return {string}
   *   A unique slug string
   */
  slug(e, n) {
    const i = this;
    let r = Ec(e, n === !0);
    const l = r;
    for (; Dc.call(i.occurrences, r); )
      i.occurrences[l]++, r = l + "-" + i.occurrences[l];
    return i.occurrences[r] = 0, r;
  }
  /**
   * Reset - Forget all previous slugs
   *
   * @return void
   */
  reset() {
    this.occurrences = /* @__PURE__ */ Object.create(null);
  }
}
function Ec(t, e) {
  return typeof t != "string" ? "" : (e || (t = t.toLowerCase()), t.replace(wc, "").replace(/ /g, "-"));
}
let Yl = new ir(), Jl = [];
function Fc({ prefix: t = "", globalSlugs: e = !1 } = {}) {
  return {
    headerIds: !1,
    // prevent deprecation warning; remove this once headerIds option is removed
    hooks: {
      preprocess(n) {
        return e || kc(), n;
      }
    },
    renderer: {
      heading(n, i, r) {
        r = r.toLowerCase().trim().replace(/<[!\/a-z].*?>/gi, "");
        const l = `${t}${Yl.slug(r)}`, a = { level: i, text: n, id: l };
        return Jl.push(a), `<h${i} id="${l}">${n}</h${i}>
`;
      }
    }
  };
}
function kc() {
  Jl = [], Yl = new ir();
}
var Ur = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {};
function zd(t) {
  return t && t.__esModule && Object.prototype.hasOwnProperty.call(t, "default") ? t.default : t;
}
var Kl = { exports: {} };
(function(t) {
  var e = typeof window < "u" ? window : typeof WorkerGlobalScope < "u" && self instanceof WorkerGlobalScope ? self : {};
  /**
   * Prism: Lightweight, robust, elegant syntax highlighting
   *
   * @license MIT <https://opensource.org/licenses/MIT>
   * @author Lea Verou <https://lea.verou.me>
   * @namespace
   * @public
   */
  var n = function(i) {
    var r = /(?:^|\s)lang(?:uage)?-([\w-]+)(?=\s|$)/i, l = 0, a = {}, o = {
      /**
       * By default, Prism will attempt to highlight all code elements (by calling {@link Prism.highlightAll}) on the
       * current page after the page finished loading. This might be a problem if e.g. you wanted to asynchronously load
       * additional languages or plugins yourself.
       *
       * By setting this value to `true`, Prism will not automatically highlight all code elements on the page.
       *
       * You obviously have to change this value before the automatic highlighting started. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.manual = true;
       * // add a new <script> to load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      manual: i.Prism && i.Prism.manual,
      /**
       * By default, if Prism is in a web worker, it assumes that it is in a worker it created itself, so it uses
       * `addEventListener` to communicate with its parent instance. However, if you're using Prism manually in your
       * own worker, you don't want it to do this.
       *
       * By setting this value to `true`, Prism will not add its own listeners to the worker.
       *
       * You obviously have to change this value before Prism executes. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.disableWorkerMessageHandler = true;
       * // Load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      disableWorkerMessageHandler: i.Prism && i.Prism.disableWorkerMessageHandler,
      /**
       * A namespace for utility methods.
       *
       * All function in this namespace that are not explicitly marked as _public_ are for __internal use only__ and may
       * change or disappear at any time.
       *
       * @namespace
       * @memberof Prism
       */
      util: {
        encode: function g(f) {
          return f instanceof s ? new s(f.type, g(f.content), f.alias) : Array.isArray(f) ? f.map(g) : f.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/\u00a0/g, " ");
        },
        /**
         * Returns the name of the type of the given value.
         *
         * @param {any} o
         * @returns {string}
         * @example
         * type(null)      === 'Null'
         * type(undefined) === 'Undefined'
         * type(123)       === 'Number'
         * type('foo')     === 'String'
         * type(true)      === 'Boolean'
         * type([1, 2])    === 'Array'
         * type({})        === 'Object'
         * type(String)    === 'Function'
         * type(/abc+/)    === 'RegExp'
         */
        type: function(g) {
          return Object.prototype.toString.call(g).slice(8, -1);
        },
        /**
         * Returns a unique number for the given object. Later calls will still return the same number.
         *
         * @param {Object} obj
         * @returns {number}
         */
        objId: function(g) {
          return g.__id || Object.defineProperty(g, "__id", { value: ++l }), g.__id;
        },
        /**
         * Creates a deep clone of the given object.
         *
         * The main intended use of this function is to clone language definitions.
         *
         * @param {T} o
         * @param {Record<number, any>} [visited]
         * @returns {T}
         * @template T
         */
        clone: function g(f, m) {
          m = m || {};
          var v, p;
          switch (o.util.type(f)) {
            case "Object":
              if (p = o.util.objId(f), m[p])
                return m[p];
              v = /** @type {Record<string, any>} */
              {}, m[p] = v;
              for (var b in f)
                f.hasOwnProperty(b) && (v[b] = g(f[b], m));
              return (
                /** @type {any} */
                v
              );
            case "Array":
              return p = o.util.objId(f), m[p] ? m[p] : (v = [], m[p] = v, /** @type {Array} */
              /** @type {any} */
              f.forEach(function(k, y) {
                v[y] = g(k, m);
              }), /** @type {any} */
              v);
            default:
              return f;
          }
        },
        /**
         * Returns the Prism language of the given element set by a `language-xxxx` or `lang-xxxx` class.
         *
         * If no language is set for the element or the element is `null` or `undefined`, `none` will be returned.
         *
         * @param {Element} element
         * @returns {string}
         */
        getLanguage: function(g) {
          for (; g; ) {
            var f = r.exec(g.className);
            if (f)
              return f[1].toLowerCase();
            g = g.parentElement;
          }
          return "none";
        },
        /**
         * Sets the Prism `language-xxxx` class of the given element.
         *
         * @param {Element} element
         * @param {string} language
         * @returns {void}
         */
        setLanguage: function(g, f) {
          g.className = g.className.replace(RegExp(r, "gi"), ""), g.classList.add("language-" + f);
        },
        /**
         * Returns the script element that is currently executing.
         *
         * This does __not__ work for line script element.
         *
         * @returns {HTMLScriptElement | null}
         */
        currentScript: function() {
          if (typeof document > "u")
            return null;
          if ("currentScript" in document)
            return (
              /** @type {any} */
              document.currentScript
            );
          try {
            throw new Error();
          } catch (v) {
            var g = (/at [^(\r\n]*\((.*):[^:]+:[^:]+\)$/i.exec(v.stack) || [])[1];
            if (g) {
              var f = document.getElementsByTagName("script");
              for (var m in f)
                if (f[m].src == g)
                  return f[m];
            }
            return null;
          }
        },
        /**
         * Returns whether a given class is active for `element`.
         *
         * The class can be activated if `element` or one of its ancestors has the given class and it can be deactivated
         * if `element` or one of its ancestors has the negated version of the given class. The _negated version_ of the
         * given class is just the given class with a `no-` prefix.
         *
         * Whether the class is active is determined by the closest ancestor of `element` (where `element` itself is
         * closest ancestor) that has the given class or the negated version of it. If neither `element` nor any of its
         * ancestors have the given class or the negated version of it, then the default activation will be returned.
         *
         * In the paradoxical situation where the closest ancestor contains __both__ the given class and the negated
         * version of it, the class is considered active.
         *
         * @param {Element} element
         * @param {string} className
         * @param {boolean} [defaultActivation=false]
         * @returns {boolean}
         */
        isActive: function(g, f, m) {
          for (var v = "no-" + f; g; ) {
            var p = g.classList;
            if (p.contains(f))
              return !0;
            if (p.contains(v))
              return !1;
            g = g.parentElement;
          }
          return !!m;
        }
      },
      /**
       * This namespace contains all currently loaded languages and the some helper functions to create and modify languages.
       *
       * @namespace
       * @memberof Prism
       * @public
       */
      languages: {
        /**
         * The grammar for plain, unformatted text.
         */
        plain: a,
        plaintext: a,
        text: a,
        txt: a,
        /**
         * Creates a deep copy of the language with the given id and appends the given tokens.
         *
         * If a token in `redef` also appears in the copied language, then the existing token in the copied language
         * will be overwritten at its original position.
         *
         * ## Best practices
         *
         * Since the position of overwriting tokens (token in `redef` that overwrite tokens in the copied language)
         * doesn't matter, they can technically be in any order. However, this can be confusing to others that trying to
         * understand the language definition because, normally, the order of tokens matters in Prism grammars.
         *
         * Therefore, it is encouraged to order overwriting tokens according to the positions of the overwritten tokens.
         * Furthermore, all non-overwriting tokens should be placed after the overwriting ones.
         *
         * @param {string} id The id of the language to extend. This has to be a key in `Prism.languages`.
         * @param {Grammar} redef The new tokens to append.
         * @returns {Grammar} The new language created.
         * @public
         * @example
         * Prism.languages['css-with-colors'] = Prism.languages.extend('css', {
         *     // Prism.languages.css already has a 'comment' token, so this token will overwrite CSS' 'comment' token
         *     // at its original position
         *     'comment': { ... },
         *     // CSS doesn't have a 'color' token, so this token will be appended
         *     'color': /\b(?:red|green|blue)\b/
         * });
         */
        extend: function(g, f) {
          var m = o.util.clone(o.languages[g]);
          for (var v in f)
            m[v] = f[v];
          return m;
        },
        /**
         * Inserts tokens _before_ another token in a language definition or any other grammar.
         *
         * ## Usage
         *
         * This helper method makes it easy to modify existing languages. For example, the CSS language definition
         * not only defines CSS highlighting for CSS documents, but also needs to define highlighting for CSS embedded
         * in HTML through `<style>` elements. To do this, it needs to modify `Prism.languages.markup` and add the
         * appropriate tokens. However, `Prism.languages.markup` is a regular JavaScript object literal, so if you do
         * this:
         *
         * ```js
         * Prism.languages.markup.style = {
         *     // token
         * };
         * ```
         *
         * then the `style` token will be added (and processed) at the end. `insertBefore` allows you to insert tokens
         * before existing tokens. For the CSS example above, you would use it like this:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'cdata', {
         *     'style': {
         *         // token
         *     }
         * });
         * ```
         *
         * ## Special cases
         *
         * If the grammars of `inside` and `insert` have tokens with the same name, the tokens in `inside`'s grammar
         * will be ignored.
         *
         * This behavior can be used to insert tokens after `before`:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'comment', {
         *     'comment': Prism.languages.markup.comment,
         *     // tokens after 'comment'
         * });
         * ```
         *
         * ## Limitations
         *
         * The main problem `insertBefore` has to solve is iteration order. Since ES2015, the iteration order for object
         * properties is guaranteed to be the insertion order (except for integer keys) but some browsers behave
         * differently when keys are deleted and re-inserted. So `insertBefore` can't be implemented by temporarily
         * deleting properties which is necessary to insert at arbitrary positions.
         *
         * To solve this problem, `insertBefore` doesn't actually insert the given tokens into the target object.
         * Instead, it will create a new object and replace all references to the target object with the new one. This
         * can be done without temporarily deleting properties, so the iteration order is well-defined.
         *
         * However, only references that can be reached from `Prism.languages` or `insert` will be replaced. I.e. if
         * you hold the target object in a variable, then the value of the variable will not change.
         *
         * ```js
         * var oldMarkup = Prism.languages.markup;
         * var newMarkup = Prism.languages.insertBefore('markup', 'comment', { ... });
         *
         * assert(oldMarkup !== Prism.languages.markup);
         * assert(newMarkup === Prism.languages.markup);
         * ```
         *
         * @param {string} inside The property of `root` (e.g. a language id in `Prism.languages`) that contains the
         * object to be modified.
         * @param {string} before The key to insert before.
         * @param {Grammar} insert An object containing the key-value pairs to be inserted.
         * @param {Object<string, any>} [root] The object containing `inside`, i.e. the object that contains the
         * object to be modified.
         *
         * Defaults to `Prism.languages`.
         * @returns {Grammar} The new grammar object.
         * @public
         */
        insertBefore: function(g, f, m, v) {
          v = v || /** @type {any} */
          o.languages;
          var p = v[g], b = {};
          for (var k in p)
            if (p.hasOwnProperty(k)) {
              if (k == f)
                for (var y in m)
                  m.hasOwnProperty(y) && (b[y] = m[y]);
              m.hasOwnProperty(k) || (b[k] = p[k]);
            }
          var w = v[g];
          return v[g] = b, o.languages.DFS(o.languages, function(A, B) {
            B === w && A != g && (this[A] = b);
          }), b;
        },
        // Traverse a language definition with Depth First Search
        DFS: function g(f, m, v, p) {
          p = p || {};
          var b = o.util.objId;
          for (var k in f)
            if (f.hasOwnProperty(k)) {
              m.call(f, k, f[k], v || k);
              var y = f[k], w = o.util.type(y);
              w === "Object" && !p[b(y)] ? (p[b(y)] = !0, g(y, m, null, p)) : w === "Array" && !p[b(y)] && (p[b(y)] = !0, g(y, m, k, p));
            }
        }
      },
      plugins: {},
      /**
       * This is the most high-level function in Prism’s API.
       * It fetches all the elements that have a `.language-xxxx` class and then calls {@link Prism.highlightElement} on
       * each one of them.
       *
       * This is equivalent to `Prism.highlightAllUnder(document, async, callback)`.
       *
       * @param {boolean} [async=false] Same as in {@link Prism.highlightAllUnder}.
       * @param {HighlightCallback} [callback] Same as in {@link Prism.highlightAllUnder}.
       * @memberof Prism
       * @public
       */
      highlightAll: function(g, f) {
        o.highlightAllUnder(document, g, f);
      },
      /**
       * Fetches all the descendants of `container` that have a `.language-xxxx` class and then calls
       * {@link Prism.highlightElement} on each one of them.
       *
       * The following hooks will be run:
       * 1. `before-highlightall`
       * 2. `before-all-elements-highlight`
       * 3. All hooks of {@link Prism.highlightElement} for each element.
       *
       * @param {ParentNode} container The root element, whose descendants that have a `.language-xxxx` class will be highlighted.
       * @param {boolean} [async=false] Whether each element is to be highlighted asynchronously using Web Workers.
       * @param {HighlightCallback} [callback] An optional callback to be invoked on each element after its highlighting is done.
       * @memberof Prism
       * @public
       */
      highlightAllUnder: function(g, f, m) {
        var v = {
          callback: m,
          container: g,
          selector: 'code[class*="language-"], [class*="language-"] code, code[class*="lang-"], [class*="lang-"] code'
        };
        o.hooks.run("before-highlightall", v), v.elements = Array.prototype.slice.apply(v.container.querySelectorAll(v.selector)), o.hooks.run("before-all-elements-highlight", v);
        for (var p = 0, b; b = v.elements[p++]; )
          o.highlightElement(b, f === !0, v.callback);
      },
      /**
       * Highlights the code inside a single element.
       *
       * The following hooks will be run:
       * 1. `before-sanity-check`
       * 2. `before-highlight`
       * 3. All hooks of {@link Prism.highlight}. These hooks will be run by an asynchronous worker if `async` is `true`.
       * 4. `before-insert`
       * 5. `after-highlight`
       * 6. `complete`
       *
       * Some the above hooks will be skipped if the element doesn't contain any text or there is no grammar loaded for
       * the element's language.
       *
       * @param {Element} element The element containing the code.
       * It must have a class of `language-xxxx` to be processed, where `xxxx` is a valid language identifier.
       * @param {boolean} [async=false] Whether the element is to be highlighted asynchronously using Web Workers
       * to improve performance and avoid blocking the UI when highlighting very large chunks of code. This option is
       * [disabled by default](https://prismjs.com/faq.html#why-is-asynchronous-highlighting-disabled-by-default).
       *
       * Note: All language definitions required to highlight the code must be included in the main `prism.js` file for
       * asynchronous highlighting to work. You can build your own bundle on the
       * [Download page](https://prismjs.com/download.html).
       * @param {HighlightCallback} [callback] An optional callback to be invoked after the highlighting is done.
       * Mostly useful when `async` is `true`, since in that case, the highlighting is done asynchronously.
       * @memberof Prism
       * @public
       */
      highlightElement: function(g, f, m) {
        var v = o.util.getLanguage(g), p = o.languages[v];
        o.util.setLanguage(g, v);
        var b = g.parentElement;
        b && b.nodeName.toLowerCase() === "pre" && o.util.setLanguage(b, v);
        var k = g.textContent, y = {
          element: g,
          language: v,
          grammar: p,
          code: k
        };
        function w(B) {
          y.highlightedCode = B, o.hooks.run("before-insert", y), y.element.innerHTML = y.highlightedCode, o.hooks.run("after-highlight", y), o.hooks.run("complete", y), m && m.call(y.element);
        }
        if (o.hooks.run("before-sanity-check", y), b = y.element.parentElement, b && b.nodeName.toLowerCase() === "pre" && !b.hasAttribute("tabindex") && b.setAttribute("tabindex", "0"), !y.code) {
          o.hooks.run("complete", y), m && m.call(y.element);
          return;
        }
        if (o.hooks.run("before-highlight", y), !y.grammar) {
          w(o.util.encode(y.code));
          return;
        }
        if (f && i.Worker) {
          var A = new Worker(o.filename);
          A.onmessage = function(B) {
            w(B.data);
          }, A.postMessage(JSON.stringify({
            language: y.language,
            code: y.code,
            immediateClose: !0
          }));
        } else
          w(o.highlight(y.code, y.grammar, y.language));
      },
      /**
       * Low-level function, only use if you know what you’re doing. It accepts a string of text as input
       * and the language definitions to use, and returns a string with the HTML produced.
       *
       * The following hooks will be run:
       * 1. `before-tokenize`
       * 2. `after-tokenize`
       * 3. `wrap`: On each {@link Token}.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @param {string} language The name of the language definition passed to `grammar`.
       * @returns {string} The highlighted HTML.
       * @memberof Prism
       * @public
       * @example
       * Prism.highlight('var foo = true;', Prism.languages.javascript, 'javascript');
       */
      highlight: function(g, f, m) {
        var v = {
          code: g,
          grammar: f,
          language: m
        };
        if (o.hooks.run("before-tokenize", v), !v.grammar)
          throw new Error('The language "' + v.language + '" has no grammar.');
        return v.tokens = o.tokenize(v.code, v.grammar), o.hooks.run("after-tokenize", v), s.stringify(o.util.encode(v.tokens), v.language);
      },
      /**
       * This is the heart of Prism, and the most low-level function you can use. It accepts a string of text as input
       * and the language definitions to use, and returns an array with the tokenized code.
       *
       * When the language definition includes nested tokens, the function is called recursively on each of these tokens.
       *
       * This method could be useful in other contexts as well, as a very crude parser.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @returns {TokenStream} An array of strings and tokens, a token stream.
       * @memberof Prism
       * @public
       * @example
       * let code = `var foo = 0;`;
       * let tokens = Prism.tokenize(code, Prism.languages.javascript);
       * tokens.forEach(token => {
       *     if (token instanceof Prism.Token && token.type === 'number') {
       *         console.log(`Found numeric literal: ${token.content}`);
       *     }
       * });
       */
      tokenize: function(g, f) {
        var m = f.rest;
        if (m) {
          for (var v in m)
            f[v] = m[v];
          delete f.rest;
        }
        var p = new _();
        return h(p, p.head, g), c(g, p, f, p.head, 0), D(p);
      },
      /**
       * @namespace
       * @memberof Prism
       * @public
       */
      hooks: {
        all: {},
        /**
         * Adds the given callback to the list of callbacks for the given hook.
         *
         * The callback will be invoked when the hook it is registered for is run.
         * Hooks are usually directly run by a highlight function but you can also run hooks yourself.
         *
         * One callback function can be registered to multiple hooks and the same hook multiple times.
         *
         * @param {string} name The name of the hook.
         * @param {HookCallback} callback The callback function which is given environment variables.
         * @public
         */
        add: function(g, f) {
          var m = o.hooks.all;
          m[g] = m[g] || [], m[g].push(f);
        },
        /**
         * Runs a hook invoking all registered callbacks with the given environment variables.
         *
         * Callbacks will be invoked synchronously and in the order in which they were registered.
         *
         * @param {string} name The name of the hook.
         * @param {Object<string, any>} env The environment variables of the hook passed to all callbacks registered.
         * @public
         */
        run: function(g, f) {
          var m = o.hooks.all[g];
          if (!(!m || !m.length))
            for (var v = 0, p; p = m[v++]; )
              p(f);
        }
      },
      Token: s
    };
    i.Prism = o;
    function s(g, f, m, v) {
      this.type = g, this.content = f, this.alias = m, this.length = (v || "").length | 0;
    }
    s.stringify = function g(f, m) {
      if (typeof f == "string")
        return f;
      if (Array.isArray(f)) {
        var v = "";
        return f.forEach(function(w) {
          v += g(w, m);
        }), v;
      }
      var p = {
        type: f.type,
        content: g(f.content, m),
        tag: "span",
        classes: ["token", f.type],
        attributes: {},
        language: m
      }, b = f.alias;
      b && (Array.isArray(b) ? Array.prototype.push.apply(p.classes, b) : p.classes.push(b)), o.hooks.run("wrap", p);
      var k = "";
      for (var y in p.attributes)
        k += " " + y + '="' + (p.attributes[y] || "").replace(/"/g, "&quot;") + '"';
      return "<" + p.tag + ' class="' + p.classes.join(" ") + '"' + k + ">" + p.content + "</" + p.tag + ">";
    };
    function u(g, f, m, v) {
      g.lastIndex = f;
      var p = g.exec(m);
      if (p && v && p[1]) {
        var b = p[1].length;
        p.index += b, p[0] = p[0].slice(b);
      }
      return p;
    }
    function c(g, f, m, v, p, b) {
      for (var k in m)
        if (!(!m.hasOwnProperty(k) || !m[k])) {
          var y = m[k];
          y = Array.isArray(y) ? y : [y];
          for (var w = 0; w < y.length; ++w) {
            if (b && b.cause == k + "," + w)
              return;
            var A = y[w], B = A.inside, q = !!A.lookbehind, P = !!A.greedy, U = A.alias;
            if (P && !A.pattern.global) {
              var O = A.pattern.toString().match(/[imsuy]*$/)[0];
              A.pattern = RegExp(A.pattern.source, O + "g");
            }
            for (var W = A.pattern || A, j = v.next, T = p; j !== f.tail && !(b && T >= b.reach); T += j.value.length, j = j.next) {
              var ne = j.value;
              if (f.length > g.length)
                return;
              if (!(ne instanceof s)) {
                var $ = 1, I;
                if (P) {
                  if (I = u(W, T, g, q), !I || I.index >= g.length)
                    break;
                  var Je = I.index, Se = I.index + I[0].length, x = T;
                  for (x += j.value.length; Je >= x; )
                    j = j.next, x += j.value.length;
                  if (x -= j.value.length, T = x, j.value instanceof s)
                    continue;
                  for (var L = j; L !== f.tail && (x < Se || typeof L.value == "string"); L = L.next)
                    $++, x += L.value.length;
                  $--, ne = g.slice(T, x), I.index -= T;
                } else if (I = u(W, 0, ne, q), !I)
                  continue;
                var Je = I.index, ht = I[0], S = ne.slice(0, Je), fe = ne.slice(Je + ht.length), it = T + ne.length;
                b && it > b.reach && (b.reach = it);
                var ln = j.prev;
                S && (ln = h(f, ln, S), T += S.length), d(f, ln, $);
                var $o = new s(k, B ? o.tokenize(ht, B) : ht, U, ht);
                if (j = h(f, ln, $o), fe && h(f, j, fe), $ > 1) {
                  var Yn = {
                    cause: k + "," + w,
                    reach: it
                  };
                  c(g, f, m, j.prev, T, Yn), b && Yn.reach > b.reach && (b.reach = Yn.reach);
                }
              }
            }
          }
        }
    }
    function _() {
      var g = { value: null, prev: null, next: null }, f = { value: null, prev: g, next: null };
      g.next = f, this.head = g, this.tail = f, this.length = 0;
    }
    function h(g, f, m) {
      var v = f.next, p = { value: m, prev: f, next: v };
      return f.next = p, v.prev = p, g.length++, p;
    }
    function d(g, f, m) {
      for (var v = f.next, p = 0; p < m && v !== g.tail; p++)
        v = v.next;
      f.next = v, v.prev = f, g.length -= p;
    }
    function D(g) {
      for (var f = [], m = g.head.next; m !== g.tail; )
        f.push(m.value), m = m.next;
      return f;
    }
    if (!i.document)
      return i.addEventListener && (o.disableWorkerMessageHandler || i.addEventListener("message", function(g) {
        var f = JSON.parse(g.data), m = f.language, v = f.code, p = f.immediateClose;
        i.postMessage(o.highlight(v, o.languages[m], m)), p && i.close();
      }, !1)), o;
    var E = o.util.currentScript();
    E && (o.filename = E.src, E.hasAttribute("data-manual") && (o.manual = !0));
    function F() {
      o.manual || o.highlightAll();
    }
    if (!o.manual) {
      var C = document.readyState;
      C === "loading" || C === "interactive" && E && E.defer ? document.addEventListener("DOMContentLoaded", F) : window.requestAnimationFrame ? window.requestAnimationFrame(F) : window.setTimeout(F, 16);
    }
    return o;
  }(e);
  t.exports && (t.exports = n), typeof Ur < "u" && (Ur.Prism = n), n.languages.markup = {
    comment: {
      pattern: /<!--(?:(?!<!--)[\s\S])*?-->/,
      greedy: !0
    },
    prolog: {
      pattern: /<\?[\s\S]+?\?>/,
      greedy: !0
    },
    doctype: {
      // https://www.w3.org/TR/xml/#NT-doctypedecl
      pattern: /<!DOCTYPE(?:[^>"'[\]]|"[^"]*"|'[^']*')+(?:\[(?:[^<"'\]]|"[^"]*"|'[^']*'|<(?!!--)|<!--(?:[^-]|-(?!->))*-->)*\]\s*)?>/i,
      greedy: !0,
      inside: {
        "internal-subset": {
          pattern: /(^[^\[]*\[)[\s\S]+(?=\]>$)/,
          lookbehind: !0,
          greedy: !0,
          inside: null
          // see below
        },
        string: {
          pattern: /"[^"]*"|'[^']*'/,
          greedy: !0
        },
        punctuation: /^<!|>$|[[\]]/,
        "doctype-tag": /^DOCTYPE/i,
        name: /[^\s<>'"]+/
      }
    },
    cdata: {
      pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
      greedy: !0
    },
    tag: {
      pattern: /<\/?(?!\d)[^\s>\/=$<%]+(?:\s(?:\s*[^\s>\/=]+(?:\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))|(?=[\s/>])))+)?\s*\/?>/,
      greedy: !0,
      inside: {
        tag: {
          pattern: /^<\/?[^\s>\/]+/,
          inside: {
            punctuation: /^<\/?/,
            namespace: /^[^\s>\/:]+:/
          }
        },
        "special-attr": [],
        "attr-value": {
          pattern: /=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+)/,
          inside: {
            punctuation: [
              {
                pattern: /^=/,
                alias: "attr-equals"
              },
              {
                pattern: /^(\s*)["']|["']$/,
                lookbehind: !0
              }
            ]
          }
        },
        punctuation: /\/?>/,
        "attr-name": {
          pattern: /[^\s>\/]+/,
          inside: {
            namespace: /^[^\s>\/:]+:/
          }
        }
      }
    },
    entity: [
      {
        pattern: /&[\da-z]{1,8};/i,
        alias: "named-entity"
      },
      /&#x?[\da-f]{1,8};/i
    ]
  }, n.languages.markup.tag.inside["attr-value"].inside.entity = n.languages.markup.entity, n.languages.markup.doctype.inside["internal-subset"].inside = n.languages.markup, n.hooks.add("wrap", function(i) {
    i.type === "entity" && (i.attributes.title = i.content.replace(/&amp;/, "&"));
  }), Object.defineProperty(n.languages.markup.tag, "addInlined", {
    /**
     * Adds an inlined language to markup.
     *
     * An example of an inlined language is CSS with `<style>` tags.
     *
     * @param {string} tagName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addInlined('style', 'css');
     */
    value: function(r, l) {
      var a = {};
      a["language-" + l] = {
        pattern: /(^<!\[CDATA\[)[\s\S]+?(?=\]\]>$)/i,
        lookbehind: !0,
        inside: n.languages[l]
      }, a.cdata = /^<!\[CDATA\[|\]\]>$/i;
      var o = {
        "included-cdata": {
          pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
          inside: a
        }
      };
      o["language-" + l] = {
        pattern: /[\s\S]+/,
        inside: n.languages[l]
      };
      var s = {};
      s[r] = {
        pattern: RegExp(/(<__[^>]*>)(?:<!\[CDATA\[(?:[^\]]|\](?!\]>))*\]\]>|(?!<!\[CDATA\[)[\s\S])*?(?=<\/__>)/.source.replace(/__/g, function() {
          return r;
        }), "i"),
        lookbehind: !0,
        greedy: !0,
        inside: o
      }, n.languages.insertBefore("markup", "cdata", s);
    }
  }), Object.defineProperty(n.languages.markup.tag, "addAttribute", {
    /**
     * Adds an pattern to highlight languages embedded in HTML attributes.
     *
     * An example of an inlined language is CSS with `style` attributes.
     *
     * @param {string} attrName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addAttribute('style', 'css');
     */
    value: function(i, r) {
      n.languages.markup.tag.inside["special-attr"].push({
        pattern: RegExp(
          /(^|["'\s])/.source + "(?:" + i + ")" + /\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))/.source,
          "i"
        ),
        lookbehind: !0,
        inside: {
          "attr-name": /^[^\s=]+/,
          "attr-value": {
            pattern: /=[\s\S]+/,
            inside: {
              value: {
                pattern: /(^=\s*(["']|(?!["'])))\S[\s\S]*(?=\2$)/,
                lookbehind: !0,
                alias: [r, "language-" + r],
                inside: n.languages[r]
              },
              punctuation: [
                {
                  pattern: /^=/,
                  alias: "attr-equals"
                },
                /"|'/
              ]
            }
          }
        }
      });
    }
  }), n.languages.html = n.languages.markup, n.languages.mathml = n.languages.markup, n.languages.svg = n.languages.markup, n.languages.xml = n.languages.extend("markup", {}), n.languages.ssml = n.languages.xml, n.languages.atom = n.languages.xml, n.languages.rss = n.languages.xml, function(i) {
    var r = /(?:"(?:\\(?:\r\n|[\s\S])|[^"\\\r\n])*"|'(?:\\(?:\r\n|[\s\S])|[^'\\\r\n])*')/;
    i.languages.css = {
      comment: /\/\*[\s\S]*?\*\//,
      atrule: {
        pattern: RegExp("@[\\w-](?:" + /[^;{\s"']|\s+(?!\s)/.source + "|" + r.source + ")*?" + /(?:;|(?=\s*\{))/.source),
        inside: {
          rule: /^@[\w-]+/,
          "selector-function-argument": {
            pattern: /(\bselector\s*\(\s*(?![\s)]))(?:[^()\s]|\s+(?![\s)])|\((?:[^()]|\([^()]*\))*\))+(?=\s*\))/,
            lookbehind: !0,
            alias: "selector"
          },
          keyword: {
            pattern: /(^|[^\w-])(?:and|not|only|or)(?![\w-])/,
            lookbehind: !0
          }
          // See rest below
        }
      },
      url: {
        // https://drafts.csswg.org/css-values-3/#urls
        pattern: RegExp("\\burl\\((?:" + r.source + "|" + /(?:[^\\\r\n()"']|\\[\s\S])*/.source + ")\\)", "i"),
        greedy: !0,
        inside: {
          function: /^url/i,
          punctuation: /^\(|\)$/,
          string: {
            pattern: RegExp("^" + r.source + "$"),
            alias: "url"
          }
        }
      },
      selector: {
        pattern: RegExp(`(^|[{}\\s])[^{}\\s](?:[^{};"'\\s]|\\s+(?![\\s{])|` + r.source + ")*(?=\\s*\\{)"),
        lookbehind: !0
      },
      string: {
        pattern: r,
        greedy: !0
      },
      property: {
        pattern: /(^|[^-\w\xA0-\uFFFF])(?!\s)[-_a-z\xA0-\uFFFF](?:(?!\s)[-\w\xA0-\uFFFF])*(?=\s*:)/i,
        lookbehind: !0
      },
      important: /!important\b/i,
      function: {
        pattern: /(^|[^-a-z0-9])[-a-z0-9]+(?=\()/i,
        lookbehind: !0
      },
      punctuation: /[(){};:,]/
    }, i.languages.css.atrule.inside.rest = i.languages.css;
    var l = i.languages.markup;
    l && (l.tag.addInlined("style", "css"), l.tag.addAttribute("style", "css"));
  }(n), n.languages.clike = {
    comment: [
      {
        pattern: /(^|[^\\])\/\*[\s\S]*?(?:\*\/|$)/,
        lookbehind: !0,
        greedy: !0
      },
      {
        pattern: /(^|[^\\:])\/\/.*/,
        lookbehind: !0,
        greedy: !0
      }
    ],
    string: {
      pattern: /(["'])(?:\\(?:\r\n|[\s\S])|(?!\1)[^\\\r\n])*\1/,
      greedy: !0
    },
    "class-name": {
      pattern: /(\b(?:class|extends|implements|instanceof|interface|new|trait)\s+|\bcatch\s+\()[\w.\\]+/i,
      lookbehind: !0,
      inside: {
        punctuation: /[.\\]/
      }
    },
    keyword: /\b(?:break|catch|continue|do|else|finally|for|function|if|in|instanceof|new|null|return|throw|try|while)\b/,
    boolean: /\b(?:false|true)\b/,
    function: /\b\w+(?=\()/,
    number: /\b0x[\da-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:e[+-]?\d+)?/i,
    operator: /[<>]=?|[!=]=?=?|--?|\+\+?|&&?|\|\|?|[?*/~^%]/,
    punctuation: /[{}[\];(),.:]/
  }, n.languages.javascript = n.languages.extend("clike", {
    "class-name": [
      n.languages.clike["class-name"],
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$A-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\.(?:constructor|prototype))/,
        lookbehind: !0
      }
    ],
    keyword: [
      {
        pattern: /((?:^|\})\s*)catch\b/,
        lookbehind: !0
      },
      {
        pattern: /(^|[^.]|\.\.\.\s*)\b(?:as|assert(?=\s*\{)|async(?=\s*(?:function\b|\(|[$\w\xA0-\uFFFF]|$))|await|break|case|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally(?=\s*(?:\{|$))|for|from(?=\s*(?:['"]|$))|function|(?:get|set)(?=\s*(?:[#\[$\w\xA0-\uFFFF]|$))|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)\b/,
        lookbehind: !0
      }
    ],
    // Allow for all non-ASCII characters (See http://stackoverflow.com/a/2008444)
    function: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*(?:\.\s*(?:apply|bind|call)\s*)?\()/,
    number: {
      pattern: RegExp(
        /(^|[^\w$])/.source + "(?:" + // constant
        (/NaN|Infinity/.source + "|" + // binary integer
        /0[bB][01]+(?:_[01]+)*n?/.source + "|" + // octal integer
        /0[oO][0-7]+(?:_[0-7]+)*n?/.source + "|" + // hexadecimal integer
        /0[xX][\dA-Fa-f]+(?:_[\dA-Fa-f]+)*n?/.source + "|" + // decimal bigint
        /\d+(?:_\d+)*n/.source + "|" + // decimal number (integer or float) but no bigint
        /(?:\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\.\d+(?:_\d+)*)(?:[Ee][+-]?\d+(?:_\d+)*)?/.source) + ")" + /(?![\w$])/.source
      ),
      lookbehind: !0
    },
    operator: /--|\+\+|\*\*=?|=>|&&=?|\|\|=?|[!=]==|<<=?|>>>?=?|[-+*/%&|^!=<>]=?|\.{3}|\?\?=?|\?\.?|[~:]/
  }), n.languages.javascript["class-name"][0].pattern = /(\b(?:class|extends|implements|instanceof|interface|new)\s+)[\w.\\]+/, n.languages.insertBefore("javascript", "keyword", {
    regex: {
      pattern: RegExp(
        // lookbehind
        // eslint-disable-next-line regexp/no-dupe-characters-character-class
        /((?:^|[^$\w\xA0-\uFFFF."'\])\s]|\b(?:return|yield))\s*)/.source + // Regex pattern:
        // There are 2 regex patterns here. The RegExp set notation proposal added support for nested character
        // classes if the `v` flag is present. Unfortunately, nested CCs are both context-free and incompatible
        // with the only syntax, so we have to define 2 different regex patterns.
        /\//.source + "(?:" + /(?:\[(?:[^\]\\\r\n]|\\.)*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}/.source + "|" + // `v` flag syntax. This supports 3 levels of nested character classes.
        /(?:\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.)*\])*\])*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}v[dgimyus]{0,7}/.source + ")" + // lookahead
        /(?=(?:\s|\/\*(?:[^*]|\*(?!\/))*\*\/)*(?:$|[\r\n,.;:})\]]|\/\/))/.source
      ),
      lookbehind: !0,
      greedy: !0,
      inside: {
        "regex-source": {
          pattern: /^(\/)[\s\S]+(?=\/[a-z]*$)/,
          lookbehind: !0,
          alias: "language-regex",
          inside: n.languages.regex
        },
        "regex-delimiter": /^\/|\/$/,
        "regex-flags": /^[a-z]+$/
      }
    },
    // This must be declared before keyword because we use "function" inside the look-forward
    "function-variable": {
      pattern: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*[=:]\s*(?:async\s*)?(?:\bfunction\b|(?:\((?:[^()]|\([^()]*\))*\)|(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)\s*=>))/,
      alias: "function"
    },
    parameter: [
      {
        pattern: /(function(?:\s+(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)?\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\))/,
        lookbehind: !0,
        inside: n.languages.javascript
      },
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$a-z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*=>)/i,
        lookbehind: !0,
        inside: n.languages.javascript
      },
      {
        pattern: /(\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*=>)/,
        lookbehind: !0,
        inside: n.languages.javascript
      },
      {
        pattern: /((?:\b|\s|^)(?!(?:as|async|await|break|case|catch|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally|for|from|function|get|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|set|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)(?![$\w\xA0-\uFFFF]))(?:(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*\s*)\(\s*|\]\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*\{)/,
        lookbehind: !0,
        inside: n.languages.javascript
      }
    ],
    constant: /\b[A-Z](?:[A-Z_]|\dx?)*\b/
  }), n.languages.insertBefore("javascript", "string", {
    hashbang: {
      pattern: /^#!.*/,
      greedy: !0,
      alias: "comment"
    },
    "template-string": {
      pattern: /`(?:\\[\s\S]|\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}|(?!\$\{)[^\\`])*`/,
      greedy: !0,
      inside: {
        "template-punctuation": {
          pattern: /^`|`$/,
          alias: "string"
        },
        interpolation: {
          pattern: /((?:^|[^\\])(?:\\{2})*)\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}/,
          lookbehind: !0,
          inside: {
            "interpolation-punctuation": {
              pattern: /^\$\{|\}$/,
              alias: "punctuation"
            },
            rest: n.languages.javascript
          }
        },
        string: /[\s\S]+/
      }
    },
    "string-property": {
      pattern: /((?:^|[,{])[ \t]*)(["'])(?:\\(?:\r\n|[\s\S])|(?!\2)[^\\\r\n])*\2(?=\s*:)/m,
      lookbehind: !0,
      greedy: !0,
      alias: "property"
    }
  }), n.languages.insertBefore("javascript", "operator", {
    "literal-property": {
      pattern: /((?:^|[,{])[ \t]*)(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*:)/m,
      lookbehind: !0,
      alias: "property"
    }
  }), n.languages.markup && (n.languages.markup.tag.addInlined("script", "javascript"), n.languages.markup.tag.addAttribute(
    /on(?:abort|blur|change|click|composition(?:end|start|update)|dblclick|error|focus(?:in|out)?|key(?:down|up)|load|mouse(?:down|enter|leave|move|out|over|up)|reset|resize|scroll|select|slotchange|submit|unload|wheel)/.source,
    "javascript"
  )), n.languages.js = n.languages.javascript, function() {
    if (typeof n > "u" || typeof document > "u")
      return;
    Element.prototype.matches || (Element.prototype.matches = Element.prototype.msMatchesSelector || Element.prototype.webkitMatchesSelector);
    var i = "Loading…", r = function(E, F) {
      return "✖ Error " + E + " while fetching file: " + F;
    }, l = "✖ Error: File does not exist or is empty", a = {
      js: "javascript",
      py: "python",
      rb: "ruby",
      ps1: "powershell",
      psm1: "powershell",
      sh: "bash",
      bat: "batch",
      h: "c",
      tex: "latex"
    }, o = "data-src-status", s = "loading", u = "loaded", c = "failed", _ = "pre[data-src]:not([" + o + '="' + u + '"]):not([' + o + '="' + s + '"])';
    function h(E, F, C) {
      var g = new XMLHttpRequest();
      g.open("GET", E, !0), g.onreadystatechange = function() {
        g.readyState == 4 && (g.status < 400 && g.responseText ? F(g.responseText) : g.status >= 400 ? C(r(g.status, g.statusText)) : C(l));
      }, g.send(null);
    }
    function d(E) {
      var F = /^\s*(\d+)\s*(?:(,)\s*(?:(\d+)\s*)?)?$/.exec(E || "");
      if (F) {
        var C = Number(F[1]), g = F[2], f = F[3];
        return g ? f ? [C, Number(f)] : [C, void 0] : [C, C];
      }
    }
    n.hooks.add("before-highlightall", function(E) {
      E.selector += ", " + _;
    }), n.hooks.add("before-sanity-check", function(E) {
      var F = (
        /** @type {HTMLPreElement} */
        E.element
      );
      if (F.matches(_)) {
        E.code = "", F.setAttribute(o, s);
        var C = F.appendChild(document.createElement("CODE"));
        C.textContent = i;
        var g = F.getAttribute("data-src"), f = E.language;
        if (f === "none") {
          var m = (/\.(\w+)$/.exec(g) || [, "none"])[1];
          f = a[m] || m;
        }
        n.util.setLanguage(C, f), n.util.setLanguage(F, f);
        var v = n.plugins.autoloader;
        v && v.loadLanguages(f), h(
          g,
          function(p) {
            F.setAttribute(o, u);
            var b = d(F.getAttribute("data-range"));
            if (b) {
              var k = p.split(/\r\n?|\n/g), y = b[0], w = b[1] == null ? k.length : b[1];
              y < 0 && (y += k.length), y = Math.max(0, Math.min(y - 1, k.length)), w < 0 && (w += k.length), w = Math.max(0, Math.min(w, k.length)), p = k.slice(y, w).join(`
`), F.hasAttribute("data-start") || F.setAttribute("data-start", String(y + 1));
            }
            C.textContent = p, n.highlightElement(C);
          },
          function(p) {
            F.setAttribute(o, c), C.textContent = p;
          }
        );
      }
    }), n.plugins.fileHighlight = {
      /**
       * Executes the File Highlight plugin for all matching `pre` elements under the given container.
       *
       * Note: Elements which are already loaded or currently loading will not be touched by this method.
       *
       * @param {ParentNode} [container=document]
       */
      highlight: function(F) {
        for (var C = (F || document).querySelectorAll(_), g = 0, f; f = C[g++]; )
          n.highlightElement(f);
      }
    };
    var D = !1;
    n.fileHighlight = function() {
      D || (console.warn("Prism.fileHighlight is deprecated. Use `Prism.plugins.fileHighlight.highlight` instead."), D = !0), n.plugins.fileHighlight.highlight.apply(this, arguments);
    };
  }();
})(Kl);
var li = Kl.exports;
Prism.languages.python = {
  comment: {
    pattern: /(^|[^\\])#.*/,
    lookbehind: !0,
    greedy: !0
  },
  "string-interpolation": {
    pattern: /(?:f|fr|rf)(?:("""|''')[\s\S]*?\1|("|')(?:\\.|(?!\2)[^\\\r\n])*\2)/i,
    greedy: !0,
    inside: {
      interpolation: {
        // "{" <expression> <optional "!s", "!r", or "!a"> <optional ":" format specifier> "}"
        pattern: /((?:^|[^{])(?:\{\{)*)\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}])+\})+\})+\}/,
        lookbehind: !0,
        inside: {
          "format-spec": {
            pattern: /(:)[^:(){}]+(?=\}$)/,
            lookbehind: !0
          },
          "conversion-option": {
            pattern: /![sra](?=[:}]$)/,
            alias: "punctuation"
          },
          rest: null
        }
      },
      string: /[\s\S]+/
    }
  },
  "triple-quoted-string": {
    pattern: /(?:[rub]|br|rb)?("""|''')[\s\S]*?\1/i,
    greedy: !0,
    alias: "string"
  },
  string: {
    pattern: /(?:[rub]|br|rb)?("|')(?:\\.|(?!\1)[^\\\r\n])*\1/i,
    greedy: !0
  },
  function: {
    pattern: /((?:^|\s)def[ \t]+)[a-zA-Z_]\w*(?=\s*\()/g,
    lookbehind: !0
  },
  "class-name": {
    pattern: /(\bclass\s+)\w+/i,
    lookbehind: !0
  },
  decorator: {
    pattern: /(^[\t ]*)@\w+(?:\.\w+)*/m,
    lookbehind: !0,
    alias: ["annotation", "punctuation"],
    inside: {
      punctuation: /\./
    }
  },
  keyword: /\b(?:_(?=\s*:)|and|as|assert|async|await|break|case|class|continue|def|del|elif|else|except|exec|finally|for|from|global|if|import|in|is|lambda|match|nonlocal|not|or|pass|print|raise|return|try|while|with|yield)\b/,
  builtin: /\b(?:__import__|abs|all|any|apply|ascii|basestring|bin|bool|buffer|bytearray|bytes|callable|chr|classmethod|cmp|coerce|compile|complex|delattr|dict|dir|divmod|enumerate|eval|execfile|file|filter|float|format|frozenset|getattr|globals|hasattr|hash|help|hex|id|input|int|intern|isinstance|issubclass|iter|len|list|locals|long|map|max|memoryview|min|next|object|oct|open|ord|pow|property|range|raw_input|reduce|reload|repr|reversed|round|set|setattr|slice|sorted|staticmethod|str|sum|super|tuple|type|unichr|unicode|vars|xrange|zip)\b/,
  boolean: /\b(?:False|None|True)\b/,
  number: /\b0(?:b(?:_?[01])+|o(?:_?[0-7])+|x(?:_?[a-f0-9])+)\b|(?:\b\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\B\.\d+(?:_\d+)*)(?:e[+-]?\d+(?:_\d+)*)?j?(?!\w)/i,
  operator: /[-+%=]=?|!=|:=|\*\*?=?|\/\/?=?|<[<=>]?|>[=>]?|[&|^~]/,
  punctuation: /[{}[\];(),.:]/
};
Prism.languages.python["string-interpolation"].inside.interpolation.inside.rest = Prism.languages.python;
Prism.languages.py = Prism.languages.python;
(function(t) {
  var e = /\\(?:[^a-z()[\]]|[a-z*]+)/i, n = {
    "equation-command": {
      pattern: e,
      alias: "regex"
    }
  };
  t.languages.latex = {
    comment: /%.*/,
    // the verbatim environment prints whitespace to the document
    cdata: {
      pattern: /(\\begin\{((?:lstlisting|verbatim)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
      lookbehind: !0
    },
    /*
     * equations can be between $$ $$ or $ $ or \( \) or \[ \]
     * (all are multiline)
     */
    equation: [
      {
        pattern: /\$\$(?:\\[\s\S]|[^\\$])+\$\$|\$(?:\\[\s\S]|[^\\$])+\$|\\\([\s\S]*?\\\)|\\\[[\s\S]*?\\\]/,
        inside: n,
        alias: "string"
      },
      {
        pattern: /(\\begin\{((?:align|eqnarray|equation|gather|math|multline)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
        lookbehind: !0,
        inside: n,
        alias: "string"
      }
    ],
    /*
     * arguments which are keywords or references are highlighted
     * as keywords
     */
    keyword: {
      pattern: /(\\(?:begin|cite|documentclass|end|label|ref|usepackage)(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    url: {
      pattern: /(\\url\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    /*
     * section or chapter headlines are highlighted as bold so that
     * they stand out more
     */
    headline: {
      pattern: /(\\(?:chapter|frametitle|paragraph|part|section|subparagraph|subsection|subsubparagraph|subsubsection|subsubsubparagraph)\*?(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0,
      alias: "class-name"
    },
    function: {
      pattern: e,
      alias: "selector"
    },
    punctuation: /[[\]{}&]/
  }, t.languages.tex = t.languages.latex, t.languages.context = t.languages.latex;
})(Prism);
(function(t) {
  var e = "\\b(?:BASH|BASHOPTS|BASH_ALIASES|BASH_ARGC|BASH_ARGV|BASH_CMDS|BASH_COMPLETION_COMPAT_DIR|BASH_LINENO|BASH_REMATCH|BASH_SOURCE|BASH_VERSINFO|BASH_VERSION|COLORTERM|COLUMNS|COMP_WORDBREAKS|DBUS_SESSION_BUS_ADDRESS|DEFAULTS_PATH|DESKTOP_SESSION|DIRSTACK|DISPLAY|EUID|GDMSESSION|GDM_LANG|GNOME_KEYRING_CONTROL|GNOME_KEYRING_PID|GPG_AGENT_INFO|GROUPS|HISTCONTROL|HISTFILE|HISTFILESIZE|HISTSIZE|HOME|HOSTNAME|HOSTTYPE|IFS|INSTANCE|JOB|LANG|LANGUAGE|LC_ADDRESS|LC_ALL|LC_IDENTIFICATION|LC_MEASUREMENT|LC_MONETARY|LC_NAME|LC_NUMERIC|LC_PAPER|LC_TELEPHONE|LC_TIME|LESSCLOSE|LESSOPEN|LINES|LOGNAME|LS_COLORS|MACHTYPE|MAILCHECK|MANDATORY_PATH|NO_AT_BRIDGE|OLDPWD|OPTERR|OPTIND|ORBIT_SOCKETDIR|OSTYPE|PAPERSIZE|PATH|PIPESTATUS|PPID|PS1|PS2|PS3|PS4|PWD|RANDOM|REPLY|SECONDS|SELINUX_INIT|SESSION|SESSIONTYPE|SESSION_MANAGER|SHELL|SHELLOPTS|SHLVL|SSH_AUTH_SOCK|TERM|UID|UPSTART_EVENTS|UPSTART_INSTANCE|UPSTART_JOB|UPSTART_SESSION|USER|WINDOWID|XAUTHORITY|XDG_CONFIG_DIRS|XDG_CURRENT_DESKTOP|XDG_DATA_DIRS|XDG_GREETER_DATA_DIR|XDG_MENU_PREFIX|XDG_RUNTIME_DIR|XDG_SEAT|XDG_SEAT_PATH|XDG_SESSION_DESKTOP|XDG_SESSION_ID|XDG_SESSION_PATH|XDG_SESSION_TYPE|XDG_VTNR|XMODIFIERS)\\b", n = {
    pattern: /(^(["']?)\w+\2)[ \t]+\S.*/,
    lookbehind: !0,
    alias: "punctuation",
    // this looks reasonably well in all themes
    inside: null
    // see below
  }, i = {
    bash: n,
    environment: {
      pattern: RegExp("\\$" + e),
      alias: "constant"
    },
    variable: [
      // [0]: Arithmetic Environment
      {
        pattern: /\$?\(\([\s\S]+?\)\)/,
        greedy: !0,
        inside: {
          // If there is a $ sign at the beginning highlight $(( and )) as variable
          variable: [
            {
              pattern: /(^\$\(\([\s\S]+)\)\)/,
              lookbehind: !0
            },
            /^\$\(\(/
          ],
          number: /\b0x[\dA-Fa-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:[Ee]-?\d+)?/,
          // Operators according to https://www.gnu.org/software/bash/manual/bashref.html#Shell-Arithmetic
          operator: /--|\+\+|\*\*=?|<<=?|>>=?|&&|\|\||[=!+\-*/%<>^&|]=?|[?~:]/,
          // If there is no $ sign at the beginning highlight (( and )) as punctuation
          punctuation: /\(\(?|\)\)?|,|;/
        }
      },
      // [1]: Command Substitution
      {
        pattern: /\$\((?:\([^)]+\)|[^()])+\)|`[^`]+`/,
        greedy: !0,
        inside: {
          variable: /^\$\(|^`|\)$|`$/
        }
      },
      // [2]: Brace expansion
      {
        pattern: /\$\{[^}]+\}/,
        greedy: !0,
        inside: {
          operator: /:[-=?+]?|[!\/]|##?|%%?|\^\^?|,,?/,
          punctuation: /[\[\]]/,
          environment: {
            pattern: RegExp("(\\{)" + e),
            lookbehind: !0,
            alias: "constant"
          }
        }
      },
      /\$(?:\w+|[#?*!@$])/
    ],
    // Escape sequences from echo and printf's manuals, and escaped quotes.
    entity: /\\(?:[abceEfnrtv\\"]|O?[0-7]{1,3}|U[0-9a-fA-F]{8}|u[0-9a-fA-F]{4}|x[0-9a-fA-F]{1,2})/
  };
  t.languages.bash = {
    shebang: {
      pattern: /^#!\s*\/.*/,
      alias: "important"
    },
    comment: {
      pattern: /(^|[^"{\\$])#.*/,
      lookbehind: !0
    },
    "function-name": [
      // a) function foo {
      // b) foo() {
      // c) function foo() {
      // but not “foo {”
      {
        // a) and c)
        pattern: /(\bfunction\s+)[\w-]+(?=(?:\s*\(?:\s*\))?\s*\{)/,
        lookbehind: !0,
        alias: "function"
      },
      {
        // b)
        pattern: /\b[\w-]+(?=\s*\(\s*\)\s*\{)/,
        alias: "function"
      }
    ],
    // Highlight variable names as variables in for and select beginnings.
    "for-or-select": {
      pattern: /(\b(?:for|select)\s+)\w+(?=\s+in\s)/,
      alias: "variable",
      lookbehind: !0
    },
    // Highlight variable names as variables in the left-hand part
    // of assignments (“=” and “+=”).
    "assign-left": {
      pattern: /(^|[\s;|&]|[<>]\()\w+(?:\.\w+)*(?=\+?=)/,
      inside: {
        environment: {
          pattern: RegExp("(^|[\\s;|&]|[<>]\\()" + e),
          lookbehind: !0,
          alias: "constant"
        }
      },
      alias: "variable",
      lookbehind: !0
    },
    // Highlight parameter names as variables
    parameter: {
      pattern: /(^|\s)-{1,2}(?:\w+:[+-]?)?\w+(?:\.\w+)*(?=[=\s]|$)/,
      alias: "variable",
      lookbehind: !0
    },
    string: [
      // Support for Here-documents https://en.wikipedia.org/wiki/Here_document
      {
        pattern: /((?:^|[^<])<<-?\s*)(\w+)\s[\s\S]*?(?:\r?\n|\r)\2/,
        lookbehind: !0,
        greedy: !0,
        inside: i
      },
      // Here-document with quotes around the tag
      // → No expansion (so no “inside”).
      {
        pattern: /((?:^|[^<])<<-?\s*)(["'])(\w+)\2\s[\s\S]*?(?:\r?\n|\r)\3/,
        lookbehind: !0,
        greedy: !0,
        inside: {
          bash: n
        }
      },
      // “Normal” string
      {
        // https://www.gnu.org/software/bash/manual/html_node/Double-Quotes.html
        pattern: /(^|[^\\](?:\\\\)*)"(?:\\[\s\S]|\$\([^)]+\)|\$(?!\()|`[^`]+`|[^"\\`$])*"/,
        lookbehind: !0,
        greedy: !0,
        inside: i
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/Single-Quotes.html
        pattern: /(^|[^$\\])'[^']*'/,
        lookbehind: !0,
        greedy: !0
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/ANSI_002dC-Quoting.html
        pattern: /\$'(?:[^'\\]|\\[\s\S])*'/,
        greedy: !0,
        inside: {
          entity: i.entity
        }
      }
    ],
    environment: {
      pattern: RegExp("\\$?" + e),
      alias: "constant"
    },
    variable: i.variable,
    function: {
      pattern: /(^|[\s;|&]|[<>]\()(?:add|apropos|apt|apt-cache|apt-get|aptitude|aspell|automysqlbackup|awk|basename|bash|bc|bconsole|bg|bzip2|cal|cargo|cat|cfdisk|chgrp|chkconfig|chmod|chown|chroot|cksum|clear|cmp|column|comm|composer|cp|cron|crontab|csplit|curl|cut|date|dc|dd|ddrescue|debootstrap|df|diff|diff3|dig|dir|dircolors|dirname|dirs|dmesg|docker|docker-compose|du|egrep|eject|env|ethtool|expand|expect|expr|fdformat|fdisk|fg|fgrep|file|find|fmt|fold|format|free|fsck|ftp|fuser|gawk|git|gparted|grep|groupadd|groupdel|groupmod|groups|grub-mkconfig|gzip|halt|head|hg|history|host|hostname|htop|iconv|id|ifconfig|ifdown|ifup|import|install|ip|java|jobs|join|kill|killall|less|link|ln|locate|logname|logrotate|look|lpc|lpr|lprint|lprintd|lprintq|lprm|ls|lsof|lynx|make|man|mc|mdadm|mkconfig|mkdir|mke2fs|mkfifo|mkfs|mkisofs|mknod|mkswap|mmv|more|most|mount|mtools|mtr|mutt|mv|nano|nc|netstat|nice|nl|node|nohup|notify-send|npm|nslookup|op|open|parted|passwd|paste|pathchk|ping|pkill|pnpm|podman|podman-compose|popd|pr|printcap|printenv|ps|pushd|pv|quota|quotacheck|quotactl|ram|rar|rcp|reboot|remsync|rename|renice|rev|rm|rmdir|rpm|rsync|scp|screen|sdiff|sed|sendmail|seq|service|sftp|sh|shellcheck|shuf|shutdown|sleep|slocate|sort|split|ssh|stat|strace|su|sudo|sum|suspend|swapon|sync|sysctl|tac|tail|tar|tee|time|timeout|top|touch|tr|traceroute|tsort|tty|umount|uname|unexpand|uniq|units|unrar|unshar|unzip|update-grub|uptime|useradd|userdel|usermod|users|uudecode|uuencode|v|vcpkg|vdir|vi|vim|virsh|vmstat|wait|watch|wc|wget|whereis|which|who|whoami|write|xargs|xdg-open|yarn|yes|zenity|zip|zsh|zypper)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    keyword: {
      pattern: /(^|[\s;|&]|[<>]\()(?:case|do|done|elif|else|esac|fi|for|function|if|in|select|then|until|while)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    // https://www.gnu.org/software/bash/manual/html_node/Shell-Builtin-Commands.html
    builtin: {
      pattern: /(^|[\s;|&]|[<>]\()(?:\.|:|alias|bind|break|builtin|caller|cd|command|continue|declare|echo|enable|eval|exec|exit|export|getopts|hash|help|let|local|logout|mapfile|printf|pwd|read|readarray|readonly|return|set|shift|shopt|source|test|times|trap|type|typeset|ulimit|umask|unalias|unset)(?=$|[)\s;|&])/,
      lookbehind: !0,
      // Alias added to make those easier to distinguish from strings.
      alias: "class-name"
    },
    boolean: {
      pattern: /(^|[\s;|&]|[<>]\()(?:false|true)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    "file-descriptor": {
      pattern: /\B&\d\b/,
      alias: "important"
    },
    operator: {
      // Lots of redirections here, but not just that.
      pattern: /\d?<>|>\||\+=|=[=~]?|!=?|<<[<-]?|[&\d]?>>|\d[<>]&?|[<>][&=]?|&[>&]?|\|[&|]?/,
      inside: {
        "file-descriptor": {
          pattern: /^\d/,
          alias: "important"
        }
      }
    },
    punctuation: /\$?\(\(?|\)\)?|\.\.|[{}[\];\\]/,
    number: {
      pattern: /(^|\s)(?:[1-9]\d*|0)(?:[.,]\d+)?\b/,
      lookbehind: !0
    }
  }, n.inside = t.languages.bash;
  for (var r = [
    "comment",
    "function-name",
    "for-or-select",
    "assign-left",
    "parameter",
    "string",
    "environment",
    "function",
    "keyword",
    "builtin",
    "boolean",
    "file-descriptor",
    "operator",
    "punctuation",
    "number"
  ], l = i.variable[1].inside, a = 0; a < r.length; a++)
    l[r[a]] = t.languages.bash[r[a]];
  t.languages.sh = t.languages.bash, t.languages.shell = t.languages.bash;
})(Prism);
const Ac = '<svg class="md-link-icon" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true" fill="currentColor"><path d="m7.775 3.275 1.25-1.25a3.5 3.5 0 1 1 4.95 4.95l-2.5 2.5a3.5 3.5 0 0 1-4.95 0 .751.751 0 0 1 .018-1.042.751.751 0 0 1 1.042-.018 1.998 1.998 0 0 0 2.83 0l2.5-2.5a2.002 2.002 0 0 0-2.83-2.83l-1.25 1.25a.751.751 0 0 1-1.042-.018.751.751 0 0 1-.018-1.042Zm-4.69 9.64a1.998 1.998 0 0 0 2.83 0l1.25-1.25a.751.751 0 0 1 1.042.018.751.751 0 0 1 .018 1.042l-1.25 1.25a3.5 3.5 0 1 1-4.95-4.95l2.5-2.5a3.5 3.5 0 0 1 4.95 0 .751.751 0 0 1-.018 1.042.751.751 0 0 1-1.042.018 1.998 1.998 0 0 0-2.83 0l-2.5 2.5a1.998 1.998 0 0 0 0 2.83Z"></path></svg>', Cc = `
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 15 15" color="currentColor" aria-hidden="true" aria-label="Copy" stroke-width="1.3" width="15" height="15">
  <path fill="currentColor" d="M12.728 4.545v8.182H4.545V4.545zm0 -0.909H4.545a0.909 0.909 0 0 0 -0.909 0.909v8.182a0.909 0.909 0 0 0 0.909 0.909h8.182a0.909 0.909 0 0 0 0.909 -0.909V4.545a0.909 0.909 0 0 0 -0.909 -0.909"/>
  <path fill="currentColor" d="M1.818 8.182H0.909V1.818a0.909 0.909 0 0 1 0.909 -0.909h6.364v0.909H1.818Z"/>
</svg>

`, Sc = `<svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 17 17" aria-hidden="true" aria-label="Copied" fill="none" stroke="currentColor" stroke-width="1.3">
  <path d="m13.813 4.781 -7.438 7.438 -3.188 -3.188"/>
</svg>
`, Gr = `<button title="copy" class="copy_code_button">
  <span class="copy-text">${Cc}</span>
  <span class="check">${Sc}</span>
</button>`, eo = /[&<>"']/, $c = new RegExp(eo.source, "g"), to = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, xc = new RegExp(to.source, "g"), Bc = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, zr = (t) => Bc[t] || "";
function oi(t, e) {
  if (e) {
    if (eo.test(t))
      return t.replace($c, zr);
  } else if (to.test(t))
    return t.replace(xc, zr);
  return t;
}
function Tc(t) {
  const e = t.map((n) => ({
    start: new RegExp(n.left.replace(/[-\/\\^$*+?.()|[\]{}]/g, "\\$&")),
    end: new RegExp(n.right.replace(/[-\/\\^$*+?.()|[\]{}]/g, "\\$&"))
  }));
  return {
    name: "latex",
    level: "block",
    start(n) {
      for (const i of e) {
        const r = n.match(i.start);
        if (r)
          return r.index;
      }
      return -1;
    },
    tokenizer(n, i) {
      for (const r of e) {
        const l = new RegExp(
          `${r.start.source}([\\s\\S]+?)${r.end.source}`
        ).exec(n);
        if (l)
          return {
            type: "latex",
            raw: l[0],
            text: l[1].trim()
          };
      }
    },
    renderer(n) {
      return `<div class="latex-block">${n.text}</div>`;
    }
  };
}
function Ic() {
  return {
    name: "mermaid",
    level: "block",
    start(t) {
      var e;
      return (e = t.match(/^```mermaid\s*\n/)) == null ? void 0 : e.index;
    },
    tokenizer(t) {
      const e = /^```mermaid\s*\n([\s\S]*?)```\s*(?:\n|$)/.exec(t);
      if (e)
        return {
          type: "mermaid",
          raw: e[0],
          text: e[1].trim()
        };
    },
    renderer(t) {
      return `<div class="mermaid">${t.text}</div>
`;
    }
  };
}
const Lc = {
  code(t, e, n) {
    var r;
    const i = ((r = (e ?? "").match(/\S*/)) == null ? void 0 : r[0]) ?? "";
    return t = t.replace(/\n$/, "") + `
`, !i || i === "mermaid" ? '<div class="code_wrap">' + Gr + "<pre><code>" + (n ? t : oi(t, !0)) + `</code></pre></div>
` : '<div class="code_wrap">' + Gr + '<pre><code class="language-' + oi(i) + '">' + (n ? t : oi(t, !0)) + `</code></pre></div>
`;
  }
}, Hc = new ir();
function Pc({
  header_links: t,
  line_breaks: e,
  latex_delimiters: n
}) {
  const i = new Xl();
  i.use(
    {
      gfm: !0,
      pedantic: !1,
      breaks: e
    },
    gc({
      highlight: (a, o) => {
        var s;
        return (s = li.languages) != null && s[o] ? li.highlight(a, li.languages[o], o) : a;
      }
    }),
    { renderer: Lc }
  ), t && (i.use(Fc()), i.use({
    extensions: [
      {
        name: "heading",
        level: "block",
        renderer(a) {
          const o = a.raw.toLowerCase().trim().replace(/<[!\/a-z].*?>/gi, ""), s = "h" + Hc.slug(o), u = a.depth, c = this.parser.parseInline(a.tokens);
          return `<h${u} id="${s}"><a class="md-header-anchor" href="#${s}">${Ac}</a>${c}</h${u}>
`;
        }
      }
    ]
  }));
  const r = Ic(), l = Tc(n);
  return i.use({
    extensions: [r, l]
  }), i;
}
const Ii = (t) => JSON.parse(JSON.stringify(t)), Nc = (t) => t.nodeType === 1, Oc = (t) => ah.has(t.tagName), Rc = (t) => "action" in t, Mc = (t) => t.tagName === "IFRAME", qc = (t) => "formAction" in t, Uc = (t) => "protocol" in t, hn = /* @__PURE__ */ (() => {
  const t = /^(?:\w+script|data):/i;
  return (e) => t.test(e);
})(), Gc = /* @__PURE__ */ (() => {
  const t = /(?:script|data):/i;
  return (e) => t.test(e);
})(), zc = (t) => {
  const e = {};
  for (let n = 0, i = t.length; n < i; n++) {
    const r = t[n];
    for (const l in r)
      e[l] ? e[l] = e[l].concat(r[l]) : e[l] = r[l];
  }
  return e;
}, no = (t, e) => {
  let n = t.firstChild;
  for (; n; ) {
    const i = n.nextSibling;
    Nc(n) && (e(n, t), n.parentNode && no(n, e)), n = i;
  }
}, jc = (t, e) => {
  const n = document.createNodeIterator(t, NodeFilter.SHOW_ELEMENT);
  let i;
  for (; i = n.nextNode(); ) {
    const r = i.parentNode;
    r && e(i, r);
  }
}, Vc = (t, e) => !!globalThis.document && !!globalThis.document.createNodeIterator ? jc(t, e) : no(t, e), io = [
  "a",
  "abbr",
  "acronym",
  "address",
  "area",
  "article",
  "aside",
  "audio",
  "b",
  "bdi",
  "bdo",
  "bgsound",
  "big",
  "blockquote",
  "body",
  "br",
  "button",
  "canvas",
  "caption",
  "center",
  "cite",
  "code",
  "col",
  "colgroup",
  "datalist",
  "dd",
  "del",
  "details",
  "dfn",
  "dialog",
  "dir",
  "div",
  "dl",
  "dt",
  "em",
  "fieldset",
  "figcaption",
  "figure",
  "font",
  "footer",
  "form",
  "h1",
  "h2",
  "h3",
  "h4",
  "h5",
  "h6",
  "head",
  "header",
  "hgroup",
  "hr",
  "html",
  "i",
  "img",
  "input",
  "ins",
  "kbd",
  "keygen",
  "label",
  "layer",
  "legend",
  "li",
  "link",
  "listing",
  "main",
  "map",
  "mark",
  "marquee",
  "menu",
  "meta",
  "meter",
  "nav",
  "nobr",
  "ol",
  "optgroup",
  "option",
  "output",
  "p",
  "picture",
  "popup",
  "pre",
  "progress",
  "q",
  "rb",
  "rp",
  "rt",
  "rtc",
  "ruby",
  "s",
  "samp",
  "section",
  "select",
  "selectmenu",
  "small",
  "source",
  "span",
  "strike",
  "strong",
  "style",
  "sub",
  "summary",
  "sup",
  "table",
  "tbody",
  "td",
  "tfoot",
  "th",
  "thead",
  "time",
  "tr",
  "track",
  "tt",
  "u",
  "ul",
  "var",
  "video",
  "wbr"
], Xc = [
  "basefont",
  "command",
  "data",
  "iframe",
  "image",
  "plaintext",
  "portal",
  "slot",
  // 'template', //TODO: Not exactly correct to never allow this, too strict
  "textarea",
  "title",
  "xmp"
], Zc = /* @__PURE__ */ new Set([
  ...io,
  ...Xc
]), ro = [
  "svg",
  "a",
  "altglyph",
  "altglyphdef",
  "altglyphitem",
  "animatecolor",
  "animatemotion",
  "animatetransform",
  "circle",
  "clippath",
  "defs",
  "desc",
  "ellipse",
  "filter",
  "font",
  "g",
  "glyph",
  "glyphref",
  "hkern",
  "image",
  "line",
  "lineargradient",
  "marker",
  "mask",
  "metadata",
  "mpath",
  "path",
  "pattern",
  "polygon",
  "polyline",
  "radialgradient",
  "rect",
  "stop",
  "style",
  "switch",
  "symbol",
  "text",
  "textpath",
  "title",
  "tref",
  "tspan",
  "view",
  "vkern",
  /* FILTERS */
  "feBlend",
  "feColorMatrix",
  "feComponentTransfer",
  "feComposite",
  "feConvolveMatrix",
  "feDiffuseLighting",
  "feDisplacementMap",
  "feDistantLight",
  "feFlood",
  "feFuncA",
  "feFuncB",
  "feFuncG",
  "feFuncR",
  "feGaussianBlur",
  "feImage",
  "feMerge",
  "feMergeNode",
  "feMorphology",
  "feOffset",
  "fePointLight",
  "feSpecularLighting",
  "feSpotLight",
  "feTile",
  "feTurbulence"
], Wc = [
  "animate",
  "color-profile",
  "cursor",
  "discard",
  "fedropshadow",
  "font-face",
  "font-face-format",
  "font-face-name",
  "font-face-src",
  "font-face-uri",
  "foreignobject",
  "hatch",
  "hatchpath",
  "mesh",
  "meshgradient",
  "meshpatch",
  "meshrow",
  "missing-glyph",
  "script",
  "set",
  "solidcolor",
  "unknown",
  "use"
], Qc = /* @__PURE__ */ new Set([
  ...ro,
  ...Wc
]), ao = [
  "math",
  "menclose",
  "merror",
  "mfenced",
  "mfrac",
  "mglyph",
  "mi",
  "mlabeledtr",
  "mmultiscripts",
  "mn",
  "mo",
  "mover",
  "mpadded",
  "mphantom",
  "mroot",
  "mrow",
  "ms",
  "mspace",
  "msqrt",
  "mstyle",
  "msub",
  "msup",
  "msubsup",
  "mtable",
  "mtd",
  "mtext",
  "mtr",
  "munder",
  "munderover"
], Yc = [
  "maction",
  "maligngroup",
  "malignmark",
  "mlongdiv",
  "mscarries",
  "mscarry",
  "msgroup",
  "mstack",
  "msline",
  "msrow",
  "semantics",
  "annotation",
  "annotation-xml",
  "mprescripts",
  "none"
], Jc = /* @__PURE__ */ new Set([
  ...ao,
  ...Yc
]), Kc = [
  "abbr",
  "accept",
  "accept-charset",
  "accesskey",
  "action",
  "align",
  "alink",
  "allow",
  "allowfullscreen",
  "alt",
  "anchor",
  "archive",
  "as",
  "async",
  "autocapitalize",
  "autocomplete",
  "autocorrect",
  "autofocus",
  "autopictureinpicture",
  "autoplay",
  "axis",
  "background",
  "behavior",
  "bgcolor",
  "border",
  "bordercolor",
  "capture",
  "cellpadding",
  "cellspacing",
  "challenge",
  "char",
  "charoff",
  "charset",
  "checked",
  "cite",
  "class",
  "classid",
  "clear",
  "code",
  "codebase",
  "codetype",
  "color",
  "cols",
  "colspan",
  "compact",
  "content",
  "contenteditable",
  "controls",
  "controlslist",
  "conversiondestination",
  "coords",
  "crossorigin",
  "csp",
  "data",
  "datetime",
  "declare",
  "decoding",
  "default",
  "defer",
  "dir",
  "direction",
  "dirname",
  "disabled",
  "disablepictureinpicture",
  "disableremoteplayback",
  "disallowdocumentaccess",
  "download",
  "draggable",
  "elementtiming",
  "enctype",
  "end",
  "enterkeyhint",
  "event",
  "exportparts",
  "face",
  "for",
  "form",
  "formaction",
  "formenctype",
  "formmethod",
  "formnovalidate",
  "formtarget",
  "frame",
  "frameborder",
  "headers",
  "height",
  "hidden",
  "high",
  "href",
  "hreflang",
  "hreftranslate",
  "hspace",
  "http-equiv",
  "id",
  "imagesizes",
  "imagesrcset",
  "importance",
  "impressiondata",
  "impressionexpiry",
  "incremental",
  "inert",
  "inputmode",
  "integrity",
  "invisible",
  "ismap",
  "keytype",
  "kind",
  "label",
  "lang",
  "language",
  "latencyhint",
  "leftmargin",
  "link",
  "list",
  "loading",
  "longdesc",
  "loop",
  "low",
  "lowsrc",
  "manifest",
  "marginheight",
  "marginwidth",
  "max",
  "maxlength",
  "mayscript",
  "media",
  "method",
  "min",
  "minlength",
  "multiple",
  "muted",
  "name",
  "nohref",
  "nomodule",
  "nonce",
  "noresize",
  "noshade",
  "novalidate",
  "nowrap",
  "object",
  "open",
  "optimum",
  "part",
  "pattern",
  "ping",
  "placeholder",
  "playsinline",
  "policy",
  "poster",
  "preload",
  "pseudo",
  "readonly",
  "referrerpolicy",
  "rel",
  "reportingorigin",
  "required",
  "resources",
  "rev",
  "reversed",
  "role",
  "rows",
  "rowspan",
  "rules",
  "sandbox",
  "scheme",
  "scope",
  "scopes",
  "scrollamount",
  "scrolldelay",
  "scrolling",
  "select",
  "selected",
  "shadowroot",
  "shadowrootdelegatesfocus",
  "shape",
  "size",
  "sizes",
  "slot",
  "span",
  "spellcheck",
  "src",
  "srclang",
  "srcset",
  "standby",
  "start",
  "step",
  "style",
  "summary",
  "tabindex",
  "target",
  "text",
  "title",
  "topmargin",
  "translate",
  "truespeed",
  "trusttoken",
  "type",
  "usemap",
  "valign",
  "value",
  "valuetype",
  "version",
  "virtualkeyboardpolicy",
  "vlink",
  "vspace",
  "webkitdirectory",
  "width",
  "wrap"
], eh = [
  "accent-height",
  "accumulate",
  "additive",
  "alignment-baseline",
  "ascent",
  "attributename",
  "attributetype",
  "azimuth",
  "basefrequency",
  "baseline-shift",
  "begin",
  "bias",
  "by",
  "class",
  "clip",
  "clippathunits",
  "clip-path",
  "clip-rule",
  "color",
  "color-interpolation",
  "color-interpolation-filters",
  "color-profile",
  "color-rendering",
  "cx",
  "cy",
  "d",
  "dx",
  "dy",
  "diffuseconstant",
  "direction",
  "display",
  "divisor",
  "dominant-baseline",
  "dur",
  "edgemode",
  "elevation",
  "end",
  "fill",
  "fill-opacity",
  "fill-rule",
  "filter",
  "filterunits",
  "flood-color",
  "flood-opacity",
  "font-family",
  "font-size",
  "font-size-adjust",
  "font-stretch",
  "font-style",
  "font-variant",
  "font-weight",
  "fx",
  "fy",
  "g1",
  "g2",
  "glyph-name",
  "glyphref",
  "gradientunits",
  "gradienttransform",
  "height",
  "href",
  "id",
  "image-rendering",
  "in",
  "in2",
  "k",
  "k1",
  "k2",
  "k3",
  "k4",
  "kerning",
  "keypoints",
  "keysplines",
  "keytimes",
  "lang",
  "lengthadjust",
  "letter-spacing",
  "kernelmatrix",
  "kernelunitlength",
  "lighting-color",
  "local",
  "marker-end",
  "marker-mid",
  "marker-start",
  "markerheight",
  "markerunits",
  "markerwidth",
  "maskcontentunits",
  "maskunits",
  "max",
  "mask",
  "media",
  "method",
  "mode",
  "min",
  "name",
  "numoctaves",
  "offset",
  "operator",
  "opacity",
  "order",
  "orient",
  "orientation",
  "origin",
  "overflow",
  "paint-order",
  "path",
  "pathlength",
  "patterncontentunits",
  "patterntransform",
  "patternunits",
  "points",
  "preservealpha",
  "preserveaspectratio",
  "primitiveunits",
  "r",
  "rx",
  "ry",
  "radius",
  "refx",
  "refy",
  "repeatcount",
  "repeatdur",
  "restart",
  "result",
  "rotate",
  "scale",
  "seed",
  "shape-rendering",
  "specularconstant",
  "specularexponent",
  "spreadmethod",
  "startoffset",
  "stddeviation",
  "stitchtiles",
  "stop-color",
  "stop-opacity",
  "stroke-dasharray",
  "stroke-dashoffset",
  "stroke-linecap",
  "stroke-linejoin",
  "stroke-miterlimit",
  "stroke-opacity",
  "stroke",
  "stroke-width",
  "style",
  "surfacescale",
  "systemlanguage",
  "tabindex",
  "targetx",
  "targety",
  "transform",
  "transform-origin",
  "text-anchor",
  "text-decoration",
  "text-rendering",
  "textlength",
  "type",
  "u1",
  "u2",
  "unicode",
  "values",
  "viewbox",
  "visibility",
  "version",
  "vert-adv-y",
  "vert-origin-x",
  "vert-origin-y",
  "width",
  "word-spacing",
  "wrap",
  "writing-mode",
  "xchannelselector",
  "ychannelselector",
  "x",
  "x1",
  "x2",
  "xmlns",
  "y",
  "y1",
  "y2",
  "z",
  "zoomandpan"
], th = [
  "accent",
  "accentunder",
  "align",
  "bevelled",
  "close",
  "columnsalign",
  "columnlines",
  "columnspan",
  "denomalign",
  "depth",
  "dir",
  "display",
  "displaystyle",
  "encoding",
  "fence",
  "frame",
  "height",
  "href",
  "id",
  "largeop",
  "length",
  "linethickness",
  "lspace",
  "lquote",
  "mathbackground",
  "mathcolor",
  "mathsize",
  "mathvariant",
  "maxsize",
  "minsize",
  "movablelimits",
  "notation",
  "numalign",
  "open",
  "rowalign",
  "rowlines",
  "rowspacing",
  "rowspan",
  "rspace",
  "rquote",
  "scriptlevel",
  "scriptminsize",
  "scriptsizemultiplier",
  "selection",
  "separator",
  "separators",
  "stretchy",
  "subscriptshift",
  "supscriptshift",
  "symmetric",
  "voffset",
  "width",
  "xmlns"
], He = {
  HTML: "http://www.w3.org/1999/xhtml",
  SVG: "http://www.w3.org/2000/svg",
  MATH: "http://www.w3.org/1998/Math/MathML"
}, nh = {
  [He.HTML]: Zc,
  [He.SVG]: Qc,
  [He.MATH]: Jc
}, ih = {
  [He.HTML]: "html",
  [He.SVG]: "svg",
  [He.MATH]: "math"
}, rh = {
  [He.HTML]: "",
  [He.SVG]: "svg:",
  [He.MATH]: "math:"
}, ah = /* @__PURE__ */ new Set([
  "A",
  "AREA",
  "BUTTON",
  "FORM",
  "IFRAME",
  "INPUT"
]), lo = {
  allowComments: !0,
  allowCustomElements: !1,
  allowUnknownMarkup: !1,
  allowElements: [
    ...io,
    ...ro.map((t) => `svg:${t}`),
    ...ao.map((t) => `math:${t}`)
  ],
  allowAttributes: zc([
    Object.fromEntries(Kc.map((t) => [t, ["*"]])),
    Object.fromEntries(eh.map((t) => [t, ["svg:*"]])),
    Object.fromEntries(th.map((t) => [t, ["math:*"]]))
  ])
};
var si = function(t, e, n, i, r) {
  if (i === "m") throw new TypeError("Private method is not writable");
  if (i === "a" && !r) throw new TypeError("Private accessor was defined without a setter");
  if (typeof e == "function" ? t !== e || !r : !e.has(t)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return i === "a" ? r.call(t, n) : r ? r.value = n : e.set(t, n), n;
}, rt = function(t, e, n, i) {
  if (n === "a" && !i) throw new TypeError("Private accessor was defined without a getter");
  if (typeof e == "function" ? t !== e || !i : !e.has(t)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return n === "m" ? i : n === "a" ? i.call(t) : i ? i.value : e.get(t);
}, Ke, Fn, kn;
class oo {
  /* CONSTRUCTOR */
  constructor(e = {}) {
    Ke.set(this, void 0), Fn.set(this, void 0), kn.set(this, void 0), this.getConfiguration = () => Ii(rt(this, Ke, "f")), this.sanitize = (c) => {
      const _ = rt(this, Fn, "f"), h = rt(this, kn, "f");
      return Vc(c, (d, D) => {
        const E = d.namespaceURI || He.HTML, F = D.namespaceURI || He.HTML, C = nh[E], g = ih[E], f = rh[E], m = d.tagName.toLowerCase(), v = `${f}${m}`, b = `${f}*`;
        if (!C.has(m) || !_.has(v) || E !== F && m !== g)
          D.removeChild(d);
        else {
          const k = d.getAttributeNames(), y = k.length;
          if (y) {
            for (let w = 0; w < y; w++) {
              const A = k[w], B = h[A];
              (!B || !B.has(b) && !B.has(v)) && d.removeAttribute(A);
            }
            if (Oc(d))
              if (Uc(d)) {
                const w = d.getAttribute("href");
                w && Gc(w) && hn(d.protocol) && d.removeAttribute("href");
              } else Rc(d) ? hn(d.action) && d.removeAttribute("action") : qc(d) ? hn(d.formAction) && d.removeAttribute("formaction") : Mc(d) && (hn(d.src) && d.removeAttribute("formaction"), d.setAttribute("sandbox", "allow-scripts"));
          }
        }
      }), c;
    }, this.sanitizeFor = (c, _) => {
      throw new Error('"sanitizeFor" is not implemented yet');
    };
    const { allowComments: n, allowCustomElements: i, allowUnknownMarkup: r, blockElements: l, dropElements: a, dropAttributes: o } = e;
    if (n === !1)
      throw new Error('A false "allowComments" is not supported yet');
    if (i)
      throw new Error('A true "allowCustomElements" is not supported yet');
    if (r)
      throw new Error('A true "allowUnknownMarkup" is not supported yet');
    if (l)
      throw new Error('"blockElements" is not supported yet, use "allowElements" instead');
    if (a)
      throw new Error('"dropElements" is not supported yet, use "allowElements" instead');
    if (o)
      throw new Error('"dropAttributes" is not supported yet, use "allowAttributes" instead');
    si(this, Ke, Ii(lo), "f");
    const { allowElements: s, allowAttributes: u } = e;
    s && (rt(this, Ke, "f").allowElements = e.allowElements), u && (rt(this, Ke, "f").allowAttributes = e.allowAttributes), si(this, Fn, new Set(rt(this, Ke, "f").allowElements), "f"), si(this, kn, Object.fromEntries(Object.entries(rt(this, Ke, "f").allowAttributes || {}).map(([c, _]) => [c, new Set(_)])), "f");
  }
}
Ke = /* @__PURE__ */ new WeakMap(), Fn = /* @__PURE__ */ new WeakMap(), kn = /* @__PURE__ */ new WeakMap();
oo.getDefaultConfiguration = () => Ii(lo);
const lh = (t, e = location.href) => {
  try {
    return !!t && new URL(t).origin !== new URL(e).origin;
  } catch {
    return !1;
  }
};
function jr(t) {
  const e = new oo(), n = new DOMParser().parseFromString(t, "text/html");
  return so(n.body, "A", (i) => {
    i instanceof HTMLElement && "target" in i && lh(i.getAttribute("href"), location.href) && (i.setAttribute("target", "_blank"), i.setAttribute("rel", "noopener noreferrer"));
  }), e.sanitize(n).body.innerHTML;
}
function so(t, e, n) {
  t && (t.nodeName === e || typeof e == "function") && n(t);
  const i = (t == null ? void 0 : t.childNodes) || [];
  for (let r = 0; r < i.length; r++)
    so(i[r], e, n);
}
const Vr = [
  "!--",
  "!doctype",
  "a",
  "abbr",
  "acronym",
  "address",
  "applet",
  "area",
  "article",
  "aside",
  "audio",
  "b",
  "base",
  "basefont",
  "bdi",
  "bdo",
  "big",
  "blockquote",
  "body",
  "br",
  "button",
  "canvas",
  "caption",
  "center",
  "cite",
  "code",
  "col",
  "colgroup",
  "data",
  "datalist",
  "dd",
  "del",
  "details",
  "dfn",
  "dialog",
  "dir",
  "div",
  "dl",
  "dt",
  "em",
  "embed",
  "fieldset",
  "figcaption",
  "figure",
  "font",
  "footer",
  "form",
  "frame",
  "frameset",
  "h1",
  "h2",
  "h3",
  "h4",
  "h5",
  "h6",
  "head",
  "header",
  "hgroup",
  "hr",
  "html",
  "i",
  "iframe",
  "img",
  "input",
  "ins",
  "kbd",
  "label",
  "legend",
  "li",
  "link",
  "main",
  "map",
  "mark",
  "menu",
  "meta",
  "meter",
  "nav",
  "noframes",
  "noscript",
  "object",
  "ol",
  "optgroup",
  "option",
  "output",
  "p",
  "param",
  "picture",
  "pre",
  "progress",
  "q",
  "rp",
  "rt",
  "ruby",
  "s",
  "samp",
  "script",
  "search",
  "section",
  "select",
  "small",
  "source",
  "span",
  "strike",
  "strong",
  "style",
  "sub",
  "summary",
  "sup",
  "svg",
  "table",
  "tbody",
  "td",
  "template",
  "textarea",
  "tfoot",
  "th",
  "thead",
  "time",
  "title",
  "tr",
  "track",
  "tt",
  "u",
  "ul",
  "var",
  "video",
  "wbr"
], oh = [
  // Base structural elements
  "g",
  "defs",
  "use",
  "symbol",
  // Shape elements
  "rect",
  "circle",
  "ellipse",
  "line",
  "polyline",
  "polygon",
  "path",
  "image",
  // Text elements
  "text",
  "tspan",
  "textPath",
  // Gradient and effects
  "linearGradient",
  "radialGradient",
  "stop",
  "pattern",
  "clipPath",
  "mask",
  "filter",
  // Filter effects
  "feBlend",
  "feColorMatrix",
  "feComponentTransfer",
  "feComposite",
  "feConvolveMatrix",
  "feDiffuseLighting",
  "feDisplacementMap",
  "feGaussianBlur",
  "feMerge",
  "feMorphology",
  "feOffset",
  "feSpecularLighting",
  "feTurbulence",
  "feMergeNode",
  "feFuncR",
  "feFuncG",
  "feFuncB",
  "feFuncA",
  "feDistantLight",
  "fePointLight",
  "feSpotLight",
  "feFlood",
  "feTile",
  // Animation elements
  "animate",
  "animateTransform",
  "animateMotion",
  "mpath",
  "set",
  // Interactive and other elements
  "view",
  "cursor",
  "foreignObject",
  "desc",
  "title",
  "metadata",
  "switch"
], sh = [
  ...Vr,
  ...oh.filter((t) => !Vr.includes(t))
], {
  HtmlTagHydration: uh,
  SvelteComponent: ch,
  attr: hh,
  binding_callbacks: fh,
  children: _h,
  claim_element: dh,
  claim_html_tag: mh,
  detach: Xr,
  element: ph,
  init: gh,
  insert_hydration: bh,
  noop: Zr,
  safe_not_equal: vh,
  toggle_class: fn
} = window.__gradio__svelte__internal, { afterUpdate: yh, tick: wh, onMount: jd } = window.__gradio__svelte__internal;
function Dh(t) {
  let e, n;
  return {
    c() {
      e = ph("span"), n = new uh(!1), this.h();
    },
    l(i) {
      e = dh(i, "SPAN", { class: !0 });
      var r = _h(e);
      n = mh(r, !1), r.forEach(Xr), this.h();
    },
    h() {
      n.a = null, hh(e, "class", "md svelte-1m32c2s"), fn(
        e,
        "chatbot",
        /*chatbot*/
        t[0]
      ), fn(
        e,
        "prose",
        /*render_markdown*/
        t[1]
      );
    },
    m(i, r) {
      bh(i, e, r), n.m(
        /*html*/
        t[3],
        e
      ), t[11](e);
    },
    p(i, [r]) {
      r & /*html*/
      8 && n.p(
        /*html*/
        i[3]
      ), r & /*chatbot*/
      1 && fn(
        e,
        "chatbot",
        /*chatbot*/
        i[0]
      ), r & /*render_markdown*/
      2 && fn(
        e,
        "prose",
        /*render_markdown*/
        i[1]
      );
    },
    i: Zr,
    o: Zr,
    d(i) {
      i && Xr(e), t[11](null);
    }
  };
}
function Wr(t) {
  return t.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function Eh(t, e, n) {
  var i = this && this.__awaiter || function(p, b, k, y) {
    function w(A) {
      return A instanceof k ? A : new k(function(B) {
        B(A);
      });
    }
    return new (k || (k = Promise))(function(A, B) {
      function q(O) {
        try {
          U(y.next(O));
        } catch (W) {
          B(W);
        }
      }
      function P(O) {
        try {
          U(y.throw(O));
        } catch (W) {
          B(W);
        }
      }
      function U(O) {
        O.done ? A(O.value) : w(O.value).then(q, P);
      }
      U((y = y.apply(p, b || [])).next());
    });
  };
  let { chatbot: r = !0 } = e, { message: l } = e, { sanitize_html: a = !0 } = e, { latex_delimiters: o = [] } = e, { render_markdown: s = !0 } = e, { line_breaks: u = !0 } = e, { header_links: c = !1 } = e, { allow_tags: _ = !1 } = e, { theme_mode: h = "system" } = e, d, D, E = !1;
  const F = Pc({
    header_links: c,
    line_breaks: u,
    latex_delimiters: o || []
  });
  function C(p) {
    return !o || o.length === 0 ? !1 : o.some((b) => p.includes(b.left) && p.includes(b.right));
  }
  function g(p, b) {
    if (b === !0) {
      const k = /<\/?([a-zA-Z][a-zA-Z0-9-]*)([\s>])/g;
      return p.replace(k, (y, w, A) => sh.includes(w.toLowerCase()) ? y : y.replace(/</g, "&lt;").replace(/>/g, "&gt;"));
    }
    if (Array.isArray(b)) {
      const k = b.map((w) => ({
        open: new RegExp(`<(${w})(\\s+[^>]*)?>`, "gi"),
        close: new RegExp(`</(${w})>`, "gi")
      }));
      let y = p;
      return k.forEach((w) => {
        y = y.replace(w.open, (A) => A.replace(/</g, "&lt;").replace(/>/g, "&gt;")), y = y.replace(w.close, (A) => A.replace(/</g, "&lt;").replace(/>/g, "&gt;"));
      }), y;
    }
    return p;
  }
  function f(p) {
    let b = p;
    if (s) {
      const k = [];
      o.forEach((y, w) => {
        const A = Wr(y.left), B = Wr(y.right), q = new RegExp(`${A}([\\s\\S]+?)${B}`, "g");
        b = b.replace(q, (P, U) => (k.push(P), `%%%LATEX_BLOCK_${k.length - 1}%%%`));
      }), b = F.parse(b), b = b.replace(/%%%LATEX_BLOCK_(\d+)%%%/g, (y, w) => k[parseInt(w, 10)]);
    }
    return _ && (b = g(b, _)), a && jr && (b = jr(b)), b;
  }
  function m(p) {
    return i(this, void 0, void 0, function* () {
      if (o.length > 0 && p && C(p))
        if (!E)
          yield Promise.all([
            Promise.resolve({              }),
            import("./auto-render-BwaQGe8P.js")
          ]).then(([, { default: b }]) => {
            E = !0, b(d, {
              delimiters: o,
              throwOnError: !1
            });
          });
        else {
          const { default: b } = yield import("./auto-render-BwaQGe8P.js");
          b(d, {
            delimiters: o,
            throwOnError: !1
          });
        }
      if (d) {
        const b = d.querySelectorAll(".mermaid");
        if (b.length > 0) {
          yield wh();
          const { default: k } = yield import("./mermaid.core-D58rAnek.js").then((y) => y.bB);
          k.initialize({
            startOnLoad: !1,
            theme: h === "dark" ? "dark" : "default",
            securityLevel: "antiscript"
          }), yield k.run({
            nodes: Array.from(b).map((y) => y)
          });
        }
      }
    });
  }
  yh(() => i(void 0, void 0, void 0, function* () {
    d && document.body.contains(d) ? yield m(l) : console.error("Element is not in the DOM");
  }));
  function v(p) {
    fh[p ? "unshift" : "push"](() => {
      d = p, n(2, d);
    });
  }
  return t.$$set = (p) => {
    "chatbot" in p && n(0, r = p.chatbot), "message" in p && n(4, l = p.message), "sanitize_html" in p && n(5, a = p.sanitize_html), "latex_delimiters" in p && n(6, o = p.latex_delimiters), "render_markdown" in p && n(1, s = p.render_markdown), "line_breaks" in p && n(7, u = p.line_breaks), "header_links" in p && n(8, c = p.header_links), "allow_tags" in p && n(9, _ = p.allow_tags), "theme_mode" in p && n(10, h = p.theme_mode);
  }, t.$$.update = () => {
    t.$$.dirty & /*message*/
    16 && (l && l.trim() ? n(3, D = f(l)) : n(3, D = ""));
  }, [
    r,
    s,
    d,
    D,
    l,
    a,
    o,
    u,
    c,
    _,
    h,
    v
  ];
}
class Fh extends ch {
  constructor(e) {
    super(), gh(this, e, Eh, Dh, vh, {
      chatbot: 0,
      message: 4,
      sanitize_html: 5,
      latex_delimiters: 6,
      render_markdown: 1,
      line_breaks: 7,
      header_links: 8,
      allow_tags: 9,
      theme_mode: 10
    });
  }
}
const {
  SvelteComponent: kh,
  attr: Ah,
  children: Ch,
  claim_component: Sh,
  claim_element: $h,
  create_component: xh,
  destroy_component: Bh,
  detach: Qr,
  element: Th,
  init: Ih,
  insert_hydration: Lh,
  mount_component: Hh,
  safe_not_equal: Ph,
  transition_in: Nh,
  transition_out: Oh
} = window.__gradio__svelte__internal;
function Rh(t) {
  let e, n, i;
  return n = new Fh({
    props: {
      message: (
        /*info*/
        t[0]
      ),
      sanitize_html: !0
    }
  }), {
    c() {
      e = Th("div"), xh(n.$$.fragment), this.h();
    },
    l(r) {
      e = $h(r, "DIV", { class: !0 });
      var l = Ch(e);
      Sh(n.$$.fragment, l), l.forEach(Qr), this.h();
    },
    h() {
      Ah(e, "class", "svelte-17qq50w");
    },
    m(r, l) {
      Lh(r, e, l), Hh(n, e, null), i = !0;
    },
    p(r, [l]) {
      const a = {};
      l & /*info*/
      1 && (a.message = /*info*/
      r[0]), n.$set(a);
    },
    i(r) {
      i || (Nh(n.$$.fragment, r), i = !0);
    },
    o(r) {
      Oh(n.$$.fragment, r), i = !1;
    },
    d(r) {
      r && Qr(e), Bh(n);
    }
  };
}
function Mh(t, e, n) {
  let { info: i } = e;
  return t.$$set = (r) => {
    "info" in r && n(0, i = r.info);
  }, [i];
}
class qh extends kh {
  constructor(e) {
    super(), Ih(this, e, Mh, Rh, Ph, { info: 0 });
  }
}
const {
  SvelteComponent: Uh,
  attr: _n,
  check_outros: Gh,
  children: zh,
  claim_component: jh,
  claim_element: Vh,
  claim_space: Xh,
  create_component: Zh,
  create_slot: Wh,
  destroy_component: Qh,
  detach: dn,
  element: Yh,
  empty: Yr,
  get_all_dirty_from_scope: Jh,
  get_slot_changes: Kh,
  group_outros: ef,
  init: tf,
  insert_hydration: ui,
  mount_component: nf,
  safe_not_equal: rf,
  space: af,
  toggle_class: _t,
  transition_in: Pt,
  transition_out: An,
  update_slot_base: lf
} = window.__gradio__svelte__internal;
function Jr(t) {
  let e, n;
  return e = new qh({ props: { info: (
    /*info*/
    t[1]
  ) } }), {
    c() {
      Zh(e.$$.fragment);
    },
    l(i) {
      jh(e.$$.fragment, i);
    },
    m(i, r) {
      nf(e, i, r), n = !0;
    },
    p(i, r) {
      const l = {};
      r & /*info*/
      2 && (l.info = /*info*/
      i[1]), e.$set(l);
    },
    i(i) {
      n || (Pt(e.$$.fragment, i), n = !0);
    },
    o(i) {
      An(e.$$.fragment, i), n = !1;
    },
    d(i) {
      Qh(e, i);
    }
  };
}
function of(t) {
  let e, n, i, r, l;
  const a = (
    /*#slots*/
    t[4].default
  ), o = Wh(
    a,
    t,
    /*$$scope*/
    t[3],
    null
  );
  let s = (
    /*info*/
    t[1] && Jr(t)
  );
  return {
    c() {
      e = Yh("span"), o && o.c(), i = af(), s && s.c(), r = Yr(), this.h();
    },
    l(u) {
      e = Vh(u, "SPAN", {
        "data-testid": !0,
        dir: !0,
        class: !0
      });
      var c = zh(e);
      o && o.l(c), c.forEach(dn), i = Xh(u), s && s.l(u), r = Yr(), this.h();
    },
    h() {
      _n(e, "data-testid", "block-info"), _n(e, "dir", n = /*rtl*/
      t[2] ? "rtl" : "ltr"), _n(e, "class", "svelte-zgrq3"), _t(e, "sr-only", !/*show_label*/
      t[0]), _t(e, "hide", !/*show_label*/
      t[0]), _t(
        e,
        "has-info",
        /*info*/
        t[1] != null
      );
    },
    m(u, c) {
      ui(u, e, c), o && o.m(e, null), ui(u, i, c), s && s.m(u, c), ui(u, r, c), l = !0;
    },
    p(u, [c]) {
      o && o.p && (!l || c & /*$$scope*/
      8) && lf(
        o,
        a,
        u,
        /*$$scope*/
        u[3],
        l ? Kh(
          a,
          /*$$scope*/
          u[3],
          c,
          null
        ) : Jh(
          /*$$scope*/
          u[3]
        ),
        null
      ), (!l || c & /*rtl*/
      4 && n !== (n = /*rtl*/
      u[2] ? "rtl" : "ltr")) && _n(e, "dir", n), (!l || c & /*show_label*/
      1) && _t(e, "sr-only", !/*show_label*/
      u[0]), (!l || c & /*show_label*/
      1) && _t(e, "hide", !/*show_label*/
      u[0]), (!l || c & /*info*/
      2) && _t(
        e,
        "has-info",
        /*info*/
        u[1] != null
      ), /*info*/
      u[1] ? s ? (s.p(u, c), c & /*info*/
      2 && Pt(s, 1)) : (s = Jr(u), s.c(), Pt(s, 1), s.m(r.parentNode, r)) : s && (ef(), An(s, 1, 1, () => {
        s = null;
      }), Gh());
    },
    i(u) {
      l || (Pt(o, u), Pt(s), l = !0);
    },
    o(u) {
      An(o, u), An(s), l = !1;
    },
    d(u) {
      u && (dn(e), dn(i), dn(r)), o && o.d(u), s && s.d(u);
    }
  };
}
function sf(t, e, n) {
  let { $$slots: i = {}, $$scope: r } = e, { show_label: l = !0 } = e, { info: a = void 0 } = e, { rtl: o = !1 } = e;
  return t.$$set = (s) => {
    "show_label" in s && n(0, l = s.show_label), "info" in s && n(1, a = s.info), "rtl" in s && n(2, o = s.rtl), "$$scope" in s && n(3, r = s.$$scope);
  }, [l, a, o, r, i];
}
class uo extends Uh {
  constructor(e) {
    super(), tf(this, e, sf, of, rf, { show_label: 0, info: 1, rtl: 2 });
  }
}
const {
  SvelteComponent: Vd,
  append_hydration: Xd,
  attr: Zd,
  children: Wd,
  claim_component: Qd,
  claim_element: Yd,
  claim_space: Jd,
  claim_text: Kd,
  create_component: em,
  destroy_component: tm,
  detach: nm,
  element: im,
  init: rm,
  insert_hydration: am,
  mount_component: lm,
  safe_not_equal: om,
  set_data: sm,
  space: um,
  text: cm,
  toggle_class: hm,
  transition_in: fm,
  transition_out: _m
} = window.__gradio__svelte__internal, {
  SvelteComponent: uf,
  append_hydration: Cn,
  attr: Ze,
  bubble: cf,
  check_outros: hf,
  children: Li,
  claim_component: ff,
  claim_element: Hi,
  claim_space: Kr,
  claim_text: _f,
  construct_svelte_component: ea,
  create_component: ta,
  create_slot: df,
  destroy_component: na,
  detach: qt,
  element: Pi,
  get_all_dirty_from_scope: mf,
  get_slot_changes: pf,
  group_outros: gf,
  init: bf,
  insert_hydration: co,
  listen: vf,
  mount_component: ia,
  safe_not_equal: yf,
  set_data: wf,
  set_style: mn,
  space: ra,
  text: Df,
  toggle_class: oe,
  transition_in: ci,
  transition_out: hi,
  update_slot_base: Ef
} = window.__gradio__svelte__internal;
function aa(t) {
  let e, n;
  return {
    c() {
      e = Pi("span"), n = Df(
        /*label*/
        t[1]
      ), this.h();
    },
    l(i) {
      e = Hi(i, "SPAN", { class: !0 });
      var r = Li(e);
      n = _f(
        r,
        /*label*/
        t[1]
      ), r.forEach(qt), this.h();
    },
    h() {
      Ze(e, "class", "svelte-qgco6m");
    },
    m(i, r) {
      co(i, e, r), Cn(e, n);
    },
    p(i, r) {
      r & /*label*/
      2 && wf(
        n,
        /*label*/
        i[1]
      );
    },
    d(i) {
      i && qt(e);
    }
  };
}
function Ff(t) {
  let e, n, i, r, l, a, o, s, u = (
    /*show_label*/
    t[2] && aa(t)
  );
  var c = (
    /*Icon*/
    t[0]
  );
  function _(D, E) {
    return {};
  }
  c && (r = ea(c, _()));
  const h = (
    /*#slots*/
    t[14].default
  ), d = df(
    h,
    t,
    /*$$scope*/
    t[13],
    null
  );
  return {
    c() {
      e = Pi("button"), u && u.c(), n = ra(), i = Pi("div"), r && ta(r.$$.fragment), l = ra(), d && d.c(), this.h();
    },
    l(D) {
      e = Hi(D, "BUTTON", {
        "aria-label": !0,
        "aria-haspopup": !0,
        title: !0,
        class: !0
      });
      var E = Li(e);
      u && u.l(E), n = Kr(E), i = Hi(E, "DIV", { class: !0 });
      var F = Li(i);
      r && ff(r.$$.fragment, F), l = Kr(F), d && d.l(F), F.forEach(qt), E.forEach(qt), this.h();
    },
    h() {
      Ze(i, "class", "svelte-qgco6m"), oe(
        i,
        "x-small",
        /*size*/
        t[4] === "x-small"
      ), oe(
        i,
        "small",
        /*size*/
        t[4] === "small"
      ), oe(
        i,
        "large",
        /*size*/
        t[4] === "large"
      ), oe(
        i,
        "medium",
        /*size*/
        t[4] === "medium"
      ), e.disabled = /*disabled*/
      t[7], Ze(
        e,
        "aria-label",
        /*label*/
        t[1]
      ), Ze(
        e,
        "aria-haspopup",
        /*hasPopup*/
        t[8]
      ), Ze(
        e,
        "title",
        /*label*/
        t[1]
      ), Ze(e, "class", "svelte-qgco6m"), oe(
        e,
        "pending",
        /*pending*/
        t[3]
      ), oe(
        e,
        "padded",
        /*padded*/
        t[5]
      ), oe(
        e,
        "highlight",
        /*highlight*/
        t[6]
      ), oe(
        e,
        "transparent",
        /*transparent*/
        t[9]
      ), mn(e, "color", !/*disabled*/
      t[7] && /*_color*/
      t[11] ? (
        /*_color*/
        t[11]
      ) : "var(--block-label-text-color)"), mn(e, "--bg-color", /*disabled*/
      t[7] ? "auto" : (
        /*background*/
        t[10]
      ));
    },
    m(D, E) {
      co(D, e, E), u && u.m(e, null), Cn(e, n), Cn(e, i), r && ia(r, i, null), Cn(i, l), d && d.m(i, null), a = !0, o || (s = vf(
        e,
        "click",
        /*click_handler*/
        t[15]
      ), o = !0);
    },
    p(D, [E]) {
      if (/*show_label*/
      D[2] ? u ? u.p(D, E) : (u = aa(D), u.c(), u.m(e, n)) : u && (u.d(1), u = null), E & /*Icon*/
      1 && c !== (c = /*Icon*/
      D[0])) {
        if (r) {
          gf();
          const F = r;
          hi(F.$$.fragment, 1, 0, () => {
            na(F, 1);
          }), hf();
        }
        c ? (r = ea(c, _()), ta(r.$$.fragment), ci(r.$$.fragment, 1), ia(r, i, l)) : r = null;
      }
      d && d.p && (!a || E & /*$$scope*/
      8192) && Ef(
        d,
        h,
        D,
        /*$$scope*/
        D[13],
        a ? pf(
          h,
          /*$$scope*/
          D[13],
          E,
          null
        ) : mf(
          /*$$scope*/
          D[13]
        ),
        null
      ), (!a || E & /*size*/
      16) && oe(
        i,
        "x-small",
        /*size*/
        D[4] === "x-small"
      ), (!a || E & /*size*/
      16) && oe(
        i,
        "small",
        /*size*/
        D[4] === "small"
      ), (!a || E & /*size*/
      16) && oe(
        i,
        "large",
        /*size*/
        D[4] === "large"
      ), (!a || E & /*size*/
      16) && oe(
        i,
        "medium",
        /*size*/
        D[4] === "medium"
      ), (!a || E & /*disabled*/
      128) && (e.disabled = /*disabled*/
      D[7]), (!a || E & /*label*/
      2) && Ze(
        e,
        "aria-label",
        /*label*/
        D[1]
      ), (!a || E & /*hasPopup*/
      256) && Ze(
        e,
        "aria-haspopup",
        /*hasPopup*/
        D[8]
      ), (!a || E & /*label*/
      2) && Ze(
        e,
        "title",
        /*label*/
        D[1]
      ), (!a || E & /*pending*/
      8) && oe(
        e,
        "pending",
        /*pending*/
        D[3]
      ), (!a || E & /*padded*/
      32) && oe(
        e,
        "padded",
        /*padded*/
        D[5]
      ), (!a || E & /*highlight*/
      64) && oe(
        e,
        "highlight",
        /*highlight*/
        D[6]
      ), (!a || E & /*transparent*/
      512) && oe(
        e,
        "transparent",
        /*transparent*/
        D[9]
      ), E & /*disabled, _color*/
      2176 && mn(e, "color", !/*disabled*/
      D[7] && /*_color*/
      D[11] ? (
        /*_color*/
        D[11]
      ) : "var(--block-label-text-color)"), E & /*disabled, background*/
      1152 && mn(e, "--bg-color", /*disabled*/
      D[7] ? "auto" : (
        /*background*/
        D[10]
      ));
    },
    i(D) {
      a || (r && ci(r.$$.fragment, D), ci(d, D), a = !0);
    },
    o(D) {
      r && hi(r.$$.fragment, D), hi(d, D), a = !1;
    },
    d(D) {
      D && qt(e), u && u.d(), r && na(r), d && d.d(D), o = !1, s();
    }
  };
}
function kf(t, e, n) {
  let i, { $$slots: r = {}, $$scope: l } = e, { Icon: a } = e, { label: o = "" } = e, { show_label: s = !1 } = e, { pending: u = !1 } = e, { size: c = "small" } = e, { padded: _ = !0 } = e, { highlight: h = !1 } = e, { disabled: d = !1 } = e, { hasPopup: D = !1 } = e, { color: E = "var(--block-label-text-color)" } = e, { transparent: F = !1 } = e, { background: C = "var(--block-background-fill)" } = e;
  function g(f) {
    cf.call(this, t, f);
  }
  return t.$$set = (f) => {
    "Icon" in f && n(0, a = f.Icon), "label" in f && n(1, o = f.label), "show_label" in f && n(2, s = f.show_label), "pending" in f && n(3, u = f.pending), "size" in f && n(4, c = f.size), "padded" in f && n(5, _ = f.padded), "highlight" in f && n(6, h = f.highlight), "disabled" in f && n(7, d = f.disabled), "hasPopup" in f && n(8, D = f.hasPopup), "color" in f && n(12, E = f.color), "transparent" in f && n(9, F = f.transparent), "background" in f && n(10, C = f.background), "$$scope" in f && n(13, l = f.$$scope);
  }, t.$$.update = () => {
    t.$$.dirty & /*highlight, color*/
    4160 && n(11, i = h ? "var(--color-accent)" : E);
  }, [
    a,
    o,
    s,
    u,
    c,
    _,
    h,
    d,
    D,
    F,
    C,
    i,
    E,
    l,
    r,
    g
  ];
}
class Af extends uf {
  constructor(e) {
    super(), bf(this, e, kf, Ff, yf, {
      Icon: 0,
      label: 1,
      show_label: 2,
      pending: 3,
      size: 4,
      padded: 5,
      highlight: 6,
      disabled: 7,
      hasPopup: 8,
      color: 12,
      transparent: 9,
      background: 10
    });
  }
}
const {
  SvelteComponent: dm,
  append_hydration: mm,
  attr: pm,
  binding_callbacks: gm,
  children: bm,
  claim_element: vm,
  create_slot: ym,
  detach: wm,
  element: Dm,
  get_all_dirty_from_scope: Em,
  get_slot_changes: Fm,
  init: km,
  insert_hydration: Am,
  safe_not_equal: Cm,
  toggle_class: Sm,
  transition_in: $m,
  transition_out: xm,
  update_slot_base: Bm
} = window.__gradio__svelte__internal, {
  SvelteComponent: Tm,
  append_hydration: Im,
  attr: Lm,
  children: Hm,
  claim_svg_element: Pm,
  detach: Nm,
  init: Om,
  insert_hydration: Rm,
  noop: Mm,
  safe_not_equal: qm,
  svg_element: Um
} = window.__gradio__svelte__internal, {
  SvelteComponent: Gm,
  append_hydration: zm,
  attr: jm,
  children: Vm,
  claim_svg_element: Xm,
  detach: Zm,
  init: Wm,
  insert_hydration: Qm,
  noop: Ym,
  safe_not_equal: Jm,
  svg_element: Km
} = window.__gradio__svelte__internal, {
  SvelteComponent: e0,
  append_hydration: t0,
  attr: n0,
  children: i0,
  claim_svg_element: r0,
  detach: a0,
  init: l0,
  insert_hydration: o0,
  noop: s0,
  safe_not_equal: u0,
  svg_element: c0
} = window.__gradio__svelte__internal, {
  SvelteComponent: h0,
  append_hydration: f0,
  attr: _0,
  children: d0,
  claim_svg_element: m0,
  detach: p0,
  init: g0,
  insert_hydration: b0,
  noop: v0,
  safe_not_equal: y0,
  svg_element: w0
} = window.__gradio__svelte__internal, {
  SvelteComponent: D0,
  append_hydration: E0,
  attr: F0,
  children: k0,
  claim_svg_element: A0,
  detach: C0,
  init: S0,
  insert_hydration: $0,
  noop: x0,
  safe_not_equal: B0,
  svg_element: T0
} = window.__gradio__svelte__internal, {
  SvelteComponent: I0,
  append_hydration: L0,
  attr: H0,
  children: P0,
  claim_svg_element: N0,
  detach: O0,
  init: R0,
  insert_hydration: M0,
  noop: q0,
  safe_not_equal: U0,
  svg_element: G0
} = window.__gradio__svelte__internal, {
  SvelteComponent: z0,
  append_hydration: j0,
  attr: V0,
  children: X0,
  claim_svg_element: Z0,
  detach: W0,
  init: Q0,
  insert_hydration: Y0,
  noop: J0,
  safe_not_equal: K0,
  svg_element: ep
} = window.__gradio__svelte__internal, {
  SvelteComponent: tp,
  append_hydration: np,
  attr: ip,
  children: rp,
  claim_svg_element: ap,
  detach: lp,
  init: op,
  insert_hydration: sp,
  noop: up,
  safe_not_equal: cp,
  svg_element: hp
} = window.__gradio__svelte__internal, {
  SvelteComponent: fp,
  append_hydration: _p,
  attr: dp,
  children: mp,
  claim_svg_element: pp,
  detach: gp,
  init: bp,
  insert_hydration: vp,
  noop: yp,
  safe_not_equal: wp,
  svg_element: Dp
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ep,
  append_hydration: Fp,
  attr: kp,
  children: Ap,
  claim_svg_element: Cp,
  detach: Sp,
  init: $p,
  insert_hydration: xp,
  noop: Bp,
  safe_not_equal: Tp,
  svg_element: Ip
} = window.__gradio__svelte__internal, {
  SvelteComponent: Lp,
  append_hydration: Hp,
  attr: Pp,
  children: Np,
  claim_svg_element: Op,
  detach: Rp,
  init: Mp,
  insert_hydration: qp,
  noop: Up,
  safe_not_equal: Gp,
  svg_element: zp
} = window.__gradio__svelte__internal, {
  SvelteComponent: jp,
  append_hydration: Vp,
  attr: Xp,
  children: Zp,
  claim_svg_element: Wp,
  detach: Qp,
  init: Yp,
  insert_hydration: Jp,
  noop: Kp,
  safe_not_equal: eg,
  svg_element: tg
} = window.__gradio__svelte__internal, {
  SvelteComponent: Cf,
  append_hydration: fi,
  attr: $e,
  children: pn,
  claim_svg_element: gn,
  detach: It,
  init: Sf,
  insert_hydration: $f,
  noop: _i,
  safe_not_equal: xf,
  set_style: Ne,
  svg_element: bn
} = window.__gradio__svelte__internal;
function Bf(t) {
  let e, n, i, r;
  return {
    c() {
      e = bn("svg"), n = bn("g"), i = bn("path"), r = bn("path"), this.h();
    },
    l(l) {
      e = gn(l, "svg", {
        width: !0,
        height: !0,
        viewBox: !0,
        version: !0,
        xmlns: !0,
        "xmlns:xlink": !0,
        "xml:space": !0,
        stroke: !0,
        style: !0
      });
      var a = pn(e);
      n = gn(a, "g", { transform: !0 });
      var o = pn(n);
      i = gn(o, "path", { d: !0, style: !0 }), pn(i).forEach(It), o.forEach(It), r = gn(a, "path", { d: !0, style: !0 }), pn(r).forEach(It), a.forEach(It), this.h();
    },
    h() {
      $e(i, "d", "M18,6L6.087,17.913"), Ne(i, "fill", "none"), Ne(i, "fill-rule", "nonzero"), Ne(i, "stroke-width", "2px"), $e(n, "transform", "matrix(1.14096,-0.140958,-0.140958,1.14096,-0.0559523,0.0559523)"), $e(r, "d", "M4.364,4.364L19.636,19.636"), Ne(r, "fill", "none"), Ne(r, "fill-rule", "nonzero"), Ne(r, "stroke-width", "2px"), $e(e, "width", "100%"), $e(e, "height", "100%"), $e(e, "viewBox", "0 0 24 24"), $e(e, "version", "1.1"), $e(e, "xmlns", "http://www.w3.org/2000/svg"), $e(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), $e(e, "xml:space", "preserve"), $e(e, "stroke", "currentColor"), Ne(e, "fill-rule", "evenodd"), Ne(e, "clip-rule", "evenodd"), Ne(e, "stroke-linecap", "round"), Ne(e, "stroke-linejoin", "round");
    },
    m(l, a) {
      $f(l, e, a), fi(e, n), fi(n, i), fi(e, r);
    },
    p: _i,
    i: _i,
    o: _i,
    d(l) {
      l && It(e);
    }
  };
}
class Tf extends Cf {
  constructor(e) {
    super(), Sf(this, e, null, Bf, xf, {});
  }
}
const {
  SvelteComponent: ng,
  append_hydration: ig,
  attr: rg,
  children: ag,
  claim_svg_element: lg,
  detach: og,
  init: sg,
  insert_hydration: ug,
  noop: cg,
  safe_not_equal: hg,
  svg_element: fg
} = window.__gradio__svelte__internal, {
  SvelteComponent: _g,
  append_hydration: dg,
  attr: mg,
  children: pg,
  claim_svg_element: gg,
  detach: bg,
  init: vg,
  insert_hydration: yg,
  noop: wg,
  safe_not_equal: Dg,
  svg_element: Eg
} = window.__gradio__svelte__internal, {
  SvelteComponent: Fg,
  append_hydration: kg,
  attr: Ag,
  children: Cg,
  claim_svg_element: Sg,
  detach: $g,
  init: xg,
  insert_hydration: Bg,
  noop: Tg,
  safe_not_equal: Ig,
  svg_element: Lg
} = window.__gradio__svelte__internal, {
  SvelteComponent: Hg,
  append_hydration: Pg,
  attr: Ng,
  children: Og,
  claim_svg_element: Rg,
  detach: Mg,
  init: qg,
  insert_hydration: Ug,
  noop: Gg,
  safe_not_equal: zg,
  svg_element: jg
} = window.__gradio__svelte__internal, {
  SvelteComponent: Vg,
  append_hydration: Xg,
  attr: Zg,
  children: Wg,
  claim_svg_element: Qg,
  detach: Yg,
  init: Jg,
  insert_hydration: Kg,
  noop: e1,
  safe_not_equal: t1,
  svg_element: n1
} = window.__gradio__svelte__internal, {
  SvelteComponent: i1,
  append_hydration: r1,
  attr: a1,
  children: l1,
  claim_svg_element: o1,
  detach: s1,
  init: u1,
  insert_hydration: c1,
  noop: h1,
  safe_not_equal: f1,
  svg_element: _1
} = window.__gradio__svelte__internal, {
  SvelteComponent: d1,
  append_hydration: m1,
  attr: p1,
  children: g1,
  claim_svg_element: b1,
  detach: v1,
  init: y1,
  insert_hydration: w1,
  noop: D1,
  safe_not_equal: E1,
  svg_element: F1
} = window.__gradio__svelte__internal, {
  SvelteComponent: If,
  append_hydration: Lf,
  attr: dt,
  children: la,
  claim_svg_element: oa,
  detach: di,
  init: Hf,
  insert_hydration: Pf,
  noop: mi,
  safe_not_equal: Nf,
  svg_element: sa
} = window.__gradio__svelte__internal;
function Of(t) {
  let e, n;
  return {
    c() {
      e = sa("svg"), n = sa("path"), this.h();
    },
    l(i) {
      e = oa(i, "svg", {
        class: !0,
        xmlns: !0,
        width: !0,
        height: !0,
        viewBox: !0
      });
      var r = la(e);
      n = oa(r, "path", { d: !0 }), la(n).forEach(di), r.forEach(di), this.h();
    },
    h() {
      dt(n, "d", "M5 8l4 4 4-4z"), dt(e, "class", "dropdown-arrow svelte-145leq6"), dt(e, "xmlns", "http://www.w3.org/2000/svg"), dt(e, "width", "100%"), dt(e, "height", "100%"), dt(e, "viewBox", "0 0 18 18");
    },
    m(i, r) {
      Pf(i, e, r), Lf(e, n);
    },
    p: mi,
    i: mi,
    o: mi,
    d(i) {
      i && di(e);
    }
  };
}
class ho extends If {
  constructor(e) {
    super(), Hf(this, e, null, Of, Nf, {});
  }
}
const {
  SvelteComponent: k1,
  append_hydration: A1,
  attr: C1,
  children: S1,
  claim_svg_element: $1,
  detach: x1,
  init: B1,
  insert_hydration: T1,
  noop: I1,
  safe_not_equal: L1,
  svg_element: H1
} = window.__gradio__svelte__internal, {
  SvelteComponent: P1,
  append_hydration: N1,
  attr: O1,
  children: R1,
  claim_svg_element: M1,
  detach: q1,
  init: U1,
  insert_hydration: G1,
  noop: z1,
  safe_not_equal: j1,
  svg_element: V1
} = window.__gradio__svelte__internal, {
  SvelteComponent: X1,
  append_hydration: Z1,
  attr: W1,
  children: Q1,
  claim_svg_element: Y1,
  detach: J1,
  init: K1,
  insert_hydration: eb,
  noop: tb,
  safe_not_equal: nb,
  svg_element: ib
} = window.__gradio__svelte__internal, {
  SvelteComponent: rb,
  append_hydration: ab,
  attr: lb,
  children: ob,
  claim_svg_element: sb,
  detach: ub,
  init: cb,
  insert_hydration: hb,
  noop: fb,
  safe_not_equal: _b,
  svg_element: db
} = window.__gradio__svelte__internal, {
  SvelteComponent: mb,
  append_hydration: pb,
  attr: gb,
  children: bb,
  claim_svg_element: vb,
  detach: yb,
  init: wb,
  insert_hydration: Db,
  noop: Eb,
  safe_not_equal: Fb,
  svg_element: kb
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ab,
  append_hydration: Cb,
  attr: Sb,
  children: $b,
  claim_svg_element: xb,
  detach: Bb,
  init: Tb,
  insert_hydration: Ib,
  noop: Lb,
  safe_not_equal: Hb,
  svg_element: Pb
} = window.__gradio__svelte__internal, {
  SvelteComponent: Nb,
  append_hydration: Ob,
  attr: Rb,
  children: Mb,
  claim_svg_element: qb,
  detach: Ub,
  init: Gb,
  insert_hydration: zb,
  noop: jb,
  safe_not_equal: Vb,
  svg_element: Xb
} = window.__gradio__svelte__internal, {
  SvelteComponent: Zb,
  append_hydration: Wb,
  attr: Qb,
  children: Yb,
  claim_svg_element: Jb,
  detach: Kb,
  init: ev,
  insert_hydration: tv,
  noop: nv,
  safe_not_equal: iv,
  svg_element: rv
} = window.__gradio__svelte__internal, {
  SvelteComponent: av,
  append_hydration: lv,
  attr: ov,
  children: sv,
  claim_svg_element: uv,
  detach: cv,
  init: hv,
  insert_hydration: fv,
  noop: _v,
  safe_not_equal: dv,
  svg_element: mv
} = window.__gradio__svelte__internal, {
  SvelteComponent: pv,
  append_hydration: gv,
  attr: bv,
  children: vv,
  claim_svg_element: yv,
  detach: wv,
  init: Dv,
  insert_hydration: Ev,
  noop: Fv,
  safe_not_equal: kv,
  svg_element: Av
} = window.__gradio__svelte__internal, {
  SvelteComponent: Cv,
  append_hydration: Sv,
  attr: $v,
  children: xv,
  claim_svg_element: Bv,
  detach: Tv,
  init: Iv,
  insert_hydration: Lv,
  noop: Hv,
  safe_not_equal: Pv,
  svg_element: Nv
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ov,
  append_hydration: Rv,
  attr: Mv,
  children: qv,
  claim_svg_element: Uv,
  detach: Gv,
  init: zv,
  insert_hydration: jv,
  noop: Vv,
  safe_not_equal: Xv,
  svg_element: Zv
} = window.__gradio__svelte__internal, {
  SvelteComponent: Wv,
  append_hydration: Qv,
  attr: Yv,
  children: Jv,
  claim_svg_element: Kv,
  detach: e2,
  init: t2,
  insert_hydration: n2,
  noop: i2,
  safe_not_equal: r2,
  svg_element: a2
} = window.__gradio__svelte__internal, {
  SvelteComponent: l2,
  append_hydration: o2,
  attr: s2,
  children: u2,
  claim_svg_element: c2,
  detach: h2,
  init: f2,
  insert_hydration: _2,
  noop: d2,
  safe_not_equal: m2,
  svg_element: p2
} = window.__gradio__svelte__internal, {
  SvelteComponent: g2,
  append_hydration: b2,
  attr: v2,
  children: y2,
  claim_svg_element: w2,
  detach: D2,
  init: E2,
  insert_hydration: F2,
  noop: k2,
  safe_not_equal: A2,
  svg_element: C2
} = window.__gradio__svelte__internal, {
  SvelteComponent: S2,
  append_hydration: $2,
  attr: x2,
  children: B2,
  claim_svg_element: T2,
  detach: I2,
  init: L2,
  insert_hydration: H2,
  noop: P2,
  safe_not_equal: N2,
  svg_element: O2
} = window.__gradio__svelte__internal, {
  SvelteComponent: R2,
  append_hydration: M2,
  attr: q2,
  children: U2,
  claim_svg_element: G2,
  detach: z2,
  init: j2,
  insert_hydration: V2,
  noop: X2,
  safe_not_equal: Z2,
  svg_element: W2
} = window.__gradio__svelte__internal, {
  SvelteComponent: Q2,
  append_hydration: Y2,
  attr: J2,
  children: K2,
  claim_svg_element: ey,
  detach: ty,
  init: ny,
  insert_hydration: iy,
  noop: ry,
  safe_not_equal: ay,
  svg_element: ly
} = window.__gradio__svelte__internal, {
  SvelteComponent: oy,
  append_hydration: sy,
  attr: uy,
  children: cy,
  claim_svg_element: hy,
  detach: fy,
  init: _y,
  insert_hydration: dy,
  noop: my,
  safe_not_equal: py,
  svg_element: gy
} = window.__gradio__svelte__internal, {
  SvelteComponent: by,
  append_hydration: vy,
  attr: yy,
  children: wy,
  claim_svg_element: Dy,
  detach: Ey,
  init: Fy,
  insert_hydration: ky,
  noop: Ay,
  safe_not_equal: Cy,
  svg_element: Sy
} = window.__gradio__svelte__internal, {
  SvelteComponent: $y,
  append_hydration: xy,
  attr: By,
  children: Ty,
  claim_svg_element: Iy,
  detach: Ly,
  init: Hy,
  insert_hydration: Py,
  noop: Ny,
  safe_not_equal: Oy,
  svg_element: Ry
} = window.__gradio__svelte__internal, {
  SvelteComponent: My,
  append_hydration: qy,
  attr: Uy,
  children: Gy,
  claim_svg_element: zy,
  detach: jy,
  init: Vy,
  insert_hydration: Xy,
  noop: Zy,
  safe_not_equal: Wy,
  svg_element: Qy
} = window.__gradio__svelte__internal, {
  SvelteComponent: Yy,
  append_hydration: Jy,
  attr: Ky,
  children: ew,
  claim_svg_element: tw,
  detach: nw,
  init: iw,
  insert_hydration: rw,
  noop: aw,
  safe_not_equal: lw,
  svg_element: ow
} = window.__gradio__svelte__internal, {
  SvelteComponent: sw,
  append_hydration: uw,
  attr: cw,
  children: hw,
  claim_svg_element: fw,
  detach: _w,
  init: dw,
  insert_hydration: mw,
  noop: pw,
  safe_not_equal: gw,
  svg_element: bw
} = window.__gradio__svelte__internal, {
  SvelteComponent: vw,
  append_hydration: yw,
  attr: ww,
  children: Dw,
  claim_svg_element: Ew,
  detach: Fw,
  init: kw,
  insert_hydration: Aw,
  noop: Cw,
  safe_not_equal: Sw,
  svg_element: $w
} = window.__gradio__svelte__internal, {
  SvelteComponent: xw,
  append_hydration: Bw,
  attr: Tw,
  children: Iw,
  claim_svg_element: Lw,
  detach: Hw,
  init: Pw,
  insert_hydration: Nw,
  noop: Ow,
  safe_not_equal: Rw,
  set_style: Mw,
  svg_element: qw
} = window.__gradio__svelte__internal, {
  SvelteComponent: Rf,
  append_hydration: Mf,
  attr: Lt,
  children: ua,
  claim_svg_element: ca,
  detach: pi,
  init: qf,
  insert_hydration: Uf,
  noop: gi,
  safe_not_equal: Gf,
  svg_element: ha
} = window.__gradio__svelte__internal;
function zf(t) {
  let e, n;
  return {
    c() {
      e = ha("svg"), n = ha("path"), this.h();
    },
    l(i) {
      e = ca(i, "svg", {
        xmlns: !0,
        viewBox: !0,
        width: !0,
        height: !0
      });
      var r = ua(e);
      n = ca(r, "path", { d: !0 }), ua(n).forEach(pi), r.forEach(pi), this.h();
    },
    h() {
      Lt(n, "d", "M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"), Lt(e, "xmlns", "http://www.w3.org/2000/svg"), Lt(e, "viewBox", "0 0 24 24"), Lt(e, "width", "100%"), Lt(e, "height", "100%");
    },
    m(i, r) {
      Uf(i, e, r), Mf(e, n);
    },
    p: gi,
    i: gi,
    o: gi,
    d(i) {
      i && pi(e);
    }
  };
}
class fo extends Rf {
  constructor(e) {
    super(), qf(this, e, null, zf, Gf, {});
  }
}
const {
  SvelteComponent: Uw,
  append_hydration: Gw,
  attr: zw,
  children: jw,
  claim_svg_element: Vw,
  detach: Xw,
  init: Zw,
  insert_hydration: Ww,
  noop: Qw,
  safe_not_equal: Yw,
  svg_element: Jw
} = window.__gradio__svelte__internal, {
  SvelteComponent: Kw,
  append_hydration: eD,
  attr: tD,
  children: nD,
  claim_svg_element: iD,
  detach: rD,
  init: aD,
  insert_hydration: lD,
  noop: oD,
  safe_not_equal: sD,
  svg_element: uD
} = window.__gradio__svelte__internal, {
  SvelteComponent: cD,
  append_hydration: hD,
  attr: fD,
  children: _D,
  claim_svg_element: dD,
  detach: mD,
  init: pD,
  insert_hydration: gD,
  noop: bD,
  safe_not_equal: vD,
  svg_element: yD
} = window.__gradio__svelte__internal, {
  SvelteComponent: wD,
  append_hydration: DD,
  attr: ED,
  children: FD,
  claim_svg_element: kD,
  detach: AD,
  init: CD,
  insert_hydration: SD,
  noop: $D,
  safe_not_equal: xD,
  svg_element: BD
} = window.__gradio__svelte__internal, {
  SvelteComponent: TD,
  append_hydration: ID,
  attr: LD,
  children: HD,
  claim_svg_element: PD,
  detach: ND,
  init: OD,
  insert_hydration: RD,
  noop: MD,
  safe_not_equal: qD,
  svg_element: UD
} = window.__gradio__svelte__internal, {
  SvelteComponent: GD,
  append_hydration: zD,
  attr: jD,
  children: VD,
  claim_svg_element: XD,
  detach: ZD,
  init: WD,
  insert_hydration: QD,
  noop: YD,
  safe_not_equal: JD,
  svg_element: KD
} = window.__gradio__svelte__internal, {
  SvelteComponent: eE,
  append_hydration: tE,
  attr: nE,
  children: iE,
  claim_svg_element: rE,
  detach: aE,
  init: lE,
  insert_hydration: oE,
  noop: sE,
  safe_not_equal: uE,
  svg_element: cE
} = window.__gradio__svelte__internal, {
  SvelteComponent: hE,
  append_hydration: fE,
  attr: _E,
  children: dE,
  claim_svg_element: mE,
  claim_text: pE,
  detach: gE,
  init: bE,
  insert_hydration: vE,
  noop: yE,
  safe_not_equal: wE,
  svg_element: DE,
  text: EE
} = window.__gradio__svelte__internal, {
  SvelteComponent: FE,
  append_hydration: kE,
  attr: AE,
  children: CE,
  claim_svg_element: SE,
  detach: $E,
  init: xE,
  insert_hydration: BE,
  noop: TE,
  safe_not_equal: IE,
  svg_element: LE
} = window.__gradio__svelte__internal, {
  SvelteComponent: HE,
  append_hydration: PE,
  attr: NE,
  children: OE,
  claim_svg_element: RE,
  detach: ME,
  init: qE,
  insert_hydration: UE,
  noop: GE,
  safe_not_equal: zE,
  svg_element: jE
} = window.__gradio__svelte__internal, {
  SvelteComponent: VE,
  append_hydration: XE,
  attr: ZE,
  children: WE,
  claim_svg_element: QE,
  detach: YE,
  init: JE,
  insert_hydration: KE,
  noop: eF,
  safe_not_equal: tF,
  svg_element: nF
} = window.__gradio__svelte__internal, {
  SvelteComponent: iF,
  append_hydration: rF,
  attr: aF,
  children: lF,
  claim_svg_element: oF,
  detach: sF,
  init: uF,
  insert_hydration: cF,
  noop: hF,
  safe_not_equal: fF,
  svg_element: _F
} = window.__gradio__svelte__internal, {
  SvelteComponent: dF,
  append_hydration: mF,
  attr: pF,
  children: gF,
  claim_svg_element: bF,
  detach: vF,
  init: yF,
  insert_hydration: wF,
  noop: DF,
  safe_not_equal: EF,
  svg_element: FF
} = window.__gradio__svelte__internal, {
  SvelteComponent: kF,
  append_hydration: AF,
  attr: CF,
  children: SF,
  claim_svg_element: $F,
  detach: xF,
  init: BF,
  insert_hydration: TF,
  noop: IF,
  safe_not_equal: LF,
  svg_element: HF
} = window.__gradio__svelte__internal, {
  SvelteComponent: PF,
  append_hydration: NF,
  attr: OF,
  children: RF,
  claim_svg_element: MF,
  detach: qF,
  init: UF,
  insert_hydration: GF,
  noop: zF,
  safe_not_equal: jF,
  svg_element: VF
} = window.__gradio__svelte__internal, {
  SvelteComponent: XF,
  append_hydration: ZF,
  attr: WF,
  children: QF,
  claim_svg_element: YF,
  claim_text: JF,
  detach: KF,
  init: ek,
  insert_hydration: tk,
  noop: nk,
  safe_not_equal: ik,
  svg_element: rk,
  text: ak
} = window.__gradio__svelte__internal, {
  SvelteComponent: lk,
  append_hydration: ok,
  attr: sk,
  children: uk,
  claim_svg_element: ck,
  claim_text: hk,
  detach: fk,
  init: _k,
  insert_hydration: dk,
  noop: mk,
  safe_not_equal: pk,
  svg_element: gk,
  text: bk
} = window.__gradio__svelte__internal, {
  SvelteComponent: vk,
  append_hydration: yk,
  attr: wk,
  children: Dk,
  claim_svg_element: Ek,
  claim_text: Fk,
  detach: kk,
  init: Ak,
  insert_hydration: Ck,
  noop: Sk,
  safe_not_equal: $k,
  svg_element: xk,
  text: Bk
} = window.__gradio__svelte__internal, {
  SvelteComponent: Tk,
  append_hydration: Ik,
  attr: Lk,
  children: Hk,
  claim_svg_element: Pk,
  detach: Nk,
  init: Ok,
  insert_hydration: Rk,
  noop: Mk,
  safe_not_equal: qk,
  svg_element: Uk
} = window.__gradio__svelte__internal, {
  SvelteComponent: Gk,
  append_hydration: zk,
  attr: jk,
  children: Vk,
  claim_svg_element: Xk,
  detach: Zk,
  init: Wk,
  insert_hydration: Qk,
  noop: Yk,
  safe_not_equal: Jk,
  svg_element: Kk
} = window.__gradio__svelte__internal, {
  SvelteComponent: eA,
  append_hydration: tA,
  attr: nA,
  children: iA,
  claim_svg_element: rA,
  detach: aA,
  init: lA,
  insert_hydration: oA,
  noop: sA,
  safe_not_equal: uA,
  svg_element: cA
} = window.__gradio__svelte__internal, {
  SvelteComponent: hA,
  append_hydration: fA,
  attr: _A,
  children: dA,
  claim_svg_element: mA,
  detach: pA,
  init: gA,
  insert_hydration: bA,
  noop: vA,
  safe_not_equal: yA,
  svg_element: wA
} = window.__gradio__svelte__internal, {
  SvelteComponent: DA,
  append_hydration: EA,
  attr: FA,
  children: kA,
  claim_svg_element: AA,
  detach: CA,
  init: SA,
  insert_hydration: $A,
  noop: xA,
  safe_not_equal: BA,
  svg_element: TA
} = window.__gradio__svelte__internal, {
  SvelteComponent: IA,
  append_hydration: LA,
  attr: HA,
  children: PA,
  claim_svg_element: NA,
  detach: OA,
  init: RA,
  insert_hydration: MA,
  noop: qA,
  safe_not_equal: UA,
  svg_element: GA
} = window.__gradio__svelte__internal, {
  SvelteComponent: zA,
  append_hydration: jA,
  attr: VA,
  children: XA,
  claim_svg_element: ZA,
  detach: WA,
  init: QA,
  insert_hydration: YA,
  noop: JA,
  safe_not_equal: KA,
  svg_element: e3
} = window.__gradio__svelte__internal, {
  SvelteComponent: t3,
  append_hydration: n3,
  attr: i3,
  children: r3,
  claim_svg_element: a3,
  detach: l3,
  init: o3,
  insert_hydration: s3,
  noop: u3,
  safe_not_equal: c3,
  svg_element: h3
} = window.__gradio__svelte__internal, {
  SvelteComponent: f3,
  append_hydration: _3,
  attr: d3,
  children: m3,
  claim_svg_element: p3,
  detach: g3,
  init: b3,
  insert_hydration: v3,
  noop: y3,
  safe_not_equal: w3,
  svg_element: D3
} = window.__gradio__svelte__internal, {
  SvelteComponent: E3,
  append_hydration: F3,
  attr: k3,
  children: A3,
  claim_svg_element: C3,
  detach: S3,
  init: $3,
  insert_hydration: x3,
  noop: B3,
  safe_not_equal: T3,
  svg_element: I3
} = window.__gradio__svelte__internal, {
  SvelteComponent: L3,
  append_hydration: H3,
  attr: P3,
  children: N3,
  claim_svg_element: O3,
  detach: R3,
  init: M3,
  insert_hydration: q3,
  noop: U3,
  safe_not_equal: G3,
  svg_element: z3
} = window.__gradio__svelte__internal, jf = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], fa = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
jf.reduce(
  (t, { color: e, primary: n, secondary: i }) => ({
    ...t,
    [e]: {
      primary: fa[e][n],
      secondary: fa[e][i]
    }
  }),
  {}
);
const {
  SvelteComponent: j3,
  claim_component: V3,
  create_component: X3,
  destroy_component: Z3,
  init: W3,
  mount_component: Q3,
  safe_not_equal: Y3,
  transition_in: J3,
  transition_out: K3
} = window.__gradio__svelte__internal, { createEventDispatcher: eC } = window.__gradio__svelte__internal, {
  SvelteComponent: tC,
  append_hydration: nC,
  attr: iC,
  check_outros: rC,
  children: aC,
  claim_component: lC,
  claim_element: oC,
  claim_space: sC,
  claim_text: uC,
  create_component: cC,
  destroy_component: hC,
  detach: fC,
  element: _C,
  empty: dC,
  group_outros: mC,
  init: pC,
  insert_hydration: gC,
  mount_component: bC,
  safe_not_equal: vC,
  set_data: yC,
  space: wC,
  text: DC,
  toggle_class: EC,
  transition_in: FC,
  transition_out: kC
} = window.__gradio__svelte__internal, {
  SvelteComponent: AC,
  attr: CC,
  children: SC,
  claim_element: $C,
  create_slot: xC,
  detach: BC,
  element: TC,
  get_all_dirty_from_scope: IC,
  get_slot_changes: LC,
  init: HC,
  insert_hydration: PC,
  safe_not_equal: NC,
  toggle_class: OC,
  transition_in: RC,
  transition_out: MC,
  update_slot_base: qC
} = window.__gradio__svelte__internal, {
  SvelteComponent: UC,
  append_hydration: GC,
  attr: zC,
  check_outros: jC,
  children: VC,
  claim_component: XC,
  claim_element: ZC,
  claim_space: WC,
  create_component: QC,
  destroy_component: YC,
  detach: JC,
  element: KC,
  empty: eS,
  group_outros: tS,
  init: nS,
  insert_hydration: iS,
  listen: rS,
  mount_component: aS,
  safe_not_equal: lS,
  space: oS,
  toggle_class: sS,
  transition_in: uS,
  transition_out: cS
} = window.__gradio__svelte__internal, {
  SvelteComponent: hS,
  attr: fS,
  children: _S,
  claim_element: dS,
  create_slot: mS,
  detach: pS,
  element: gS,
  get_all_dirty_from_scope: bS,
  get_slot_changes: vS,
  init: yS,
  insert_hydration: wS,
  null_to_empty: DS,
  safe_not_equal: ES,
  transition_in: FS,
  transition_out: kS,
  update_slot_base: AS
} = window.__gradio__svelte__internal, {
  SvelteComponent: CS,
  check_outros: SS,
  claim_component: $S,
  create_component: xS,
  destroy_component: BS,
  detach: TS,
  empty: IS,
  group_outros: LS,
  init: HS,
  insert_hydration: PS,
  mount_component: NS,
  noop: OS,
  safe_not_equal: RS,
  transition_in: MS,
  transition_out: qS
} = window.__gradio__svelte__internal, { createEventDispatcher: US } = window.__gradio__svelte__internal, {
  SvelteComponent: Vf,
  add_render_callback: _o,
  append_hydration: vn,
  attr: ge,
  binding_callbacks: _a,
  check_outros: Xf,
  children: rr,
  claim_element: In,
  claim_space: Ni,
  claim_text: Zf,
  create_bidirectional_transition: da,
  destroy_each: Wf,
  detach: tt,
  element: Ln,
  empty: ma,
  ensure_array_like: pa,
  get_svelte_dataset: Qf,
  group_outros: Yf,
  init: Jf,
  insert_hydration: Ut,
  listen: Hn,
  prevent_default: Kf,
  run_all: mo,
  safe_not_equal: e_,
  set_data: t_,
  set_style: Re,
  space: Oi,
  text: n_,
  toggle_class: Oe,
  transition_in: bi,
  transition_out: ga
} = window.__gradio__svelte__internal, { createEventDispatcher: i_ } = window.__gradio__svelte__internal;
function ba(t, e, n) {
  const i = t.slice();
  return i[32] = e[n], i;
}
function va(t) {
  let e, n, i, r, l, a = pa(
    /*filtered_indices*/
    t[1]
  ), o = [];
  for (let s = 0; s < a.length; s += 1)
    o[s] = ya(ba(t, a, s));
  return {
    c() {
      e = Ln("ul");
      for (let s = 0; s < o.length; s += 1)
        o[s].c();
      this.h();
    },
    l(s) {
      e = In(s, "UL", { class: !0, role: !0 });
      var u = rr(e);
      for (let c = 0; c < o.length; c += 1)
        o[c].l(u);
      u.forEach(tt), this.h();
    },
    h() {
      ge(e, "class", "options svelte-wmd465"), ge(e, "role", "listbox"), Re(
        e,
        "top",
        /*top*/
        t[9]
      ), Re(
        e,
        "bottom",
        /*bottom*/
        t[10]
      ), Re(e, "max-height", `calc(${/*max_height*/
      t[11]}px - var(--window-padding))`), Re(
        e,
        "width",
        /*input_width*/
        t[8] + "px"
      );
    },
    m(s, u) {
      Ut(s, e, u);
      for (let c = 0; c < o.length; c += 1)
        o[c] && o[c].m(e, null);
      t[28](e), i = !0, r || (l = [
        Hn(e, "mousedown", Kf(
          /*mousedown_handler*/
          t[26]
        )),
        Hn(
          e,
          "scroll",
          /*scroll_handler*/
          t[27]
        )
      ], r = !0);
    },
    p(s, u) {
      if (u[0] & /*filtered_indices, choices, selected_indices, active_index, input_width*/
      307) {
        a = pa(
          /*filtered_indices*/
          s[1]
        );
        let c;
        for (c = 0; c < a.length; c += 1) {
          const _ = ba(s, a, c);
          o[c] ? o[c].p(_, u) : (o[c] = ya(_), o[c].c(), o[c].m(e, null));
        }
        for (; c < o.length; c += 1)
          o[c].d(1);
        o.length = a.length;
      }
      u[0] & /*top*/
      512 && Re(
        e,
        "top",
        /*top*/
        s[9]
      ), u[0] & /*bottom*/
      1024 && Re(
        e,
        "bottom",
        /*bottom*/
        s[10]
      ), u[0] & /*max_height*/
      2048 && Re(e, "max-height", `calc(${/*max_height*/
      s[11]}px - var(--window-padding))`), u[0] & /*input_width*/
      256 && Re(
        e,
        "width",
        /*input_width*/
        s[8] + "px"
      );
    },
    i(s) {
      i || (s && _o(() => {
        i && (n || (n = da(e, _r, { duration: 200, y: 5 }, !0)), n.run(1));
      }), i = !0);
    },
    o(s) {
      s && (n || (n = da(e, _r, { duration: 200, y: 5 }, !1)), n.run(0)), i = !1;
    },
    d(s) {
      s && tt(e), Wf(o, s), t[28](null), s && n && n.end(), r = !1, mo(l);
    }
  };
}
function ya(t) {
  let e, n, i = "✓", r, l = (
    /*choices*/
    t[0][
      /*index*/
      t[32]
    ][0] + ""
  ), a, o, s, u, c;
  return {
    c() {
      e = Ln("li"), n = Ln("span"), n.textContent = i, r = Oi(), a = n_(l), o = Oi(), this.h();
    },
    l(_) {
      e = In(_, "LI", {
        class: !0,
        "data-index": !0,
        "aria-label": !0,
        "data-testid": !0,
        role: !0,
        "aria-selected": !0
      });
      var h = rr(e);
      n = In(h, "SPAN", { class: !0, "data-svelte-h": !0 }), Qf(n) !== "svelte-1id9b8g" && (n.textContent = i), r = Ni(h), a = Zf(h, l), o = Ni(h), h.forEach(tt), this.h();
    },
    h() {
      ge(n, "class", "inner-item svelte-wmd465"), Oe(n, "hide", !/*selected_indices*/
      t[4].includes(
        /*index*/
        t[32]
      )), ge(e, "class", "item svelte-wmd465"), ge(e, "data-index", s = /*index*/
      t[32]), ge(e, "aria-label", u = /*choices*/
      t[0][
        /*index*/
        t[32]
      ][0]), ge(e, "data-testid", "dropdown-option"), ge(e, "role", "option"), ge(e, "aria-selected", c = /*selected_indices*/
      t[4].includes(
        /*index*/
        t[32]
      )), Oe(
        e,
        "selected",
        /*selected_indices*/
        t[4].includes(
          /*index*/
          t[32]
        )
      ), Oe(
        e,
        "active",
        /*index*/
        t[32] === /*active_index*/
        t[5]
      ), Oe(
        e,
        "bg-gray-100",
        /*index*/
        t[32] === /*active_index*/
        t[5]
      ), Oe(
        e,
        "dark:bg-gray-600",
        /*index*/
        t[32] === /*active_index*/
        t[5]
      ), Re(
        e,
        "width",
        /*input_width*/
        t[8] + "px"
      );
    },
    m(_, h) {
      Ut(_, e, h), vn(e, n), vn(e, r), vn(e, a), vn(e, o);
    },
    p(_, h) {
      h[0] & /*selected_indices, filtered_indices*/
      18 && Oe(n, "hide", !/*selected_indices*/
      _[4].includes(
        /*index*/
        _[32]
      )), h[0] & /*choices, filtered_indices*/
      3 && l !== (l = /*choices*/
      _[0][
        /*index*/
        _[32]
      ][0] + "") && t_(a, l), h[0] & /*filtered_indices*/
      2 && s !== (s = /*index*/
      _[32]) && ge(e, "data-index", s), h[0] & /*choices, filtered_indices*/
      3 && u !== (u = /*choices*/
      _[0][
        /*index*/
        _[32]
      ][0]) && ge(e, "aria-label", u), h[0] & /*selected_indices, filtered_indices*/
      18 && c !== (c = /*selected_indices*/
      _[4].includes(
        /*index*/
        _[32]
      )) && ge(e, "aria-selected", c), h[0] & /*selected_indices, filtered_indices*/
      18 && Oe(
        e,
        "selected",
        /*selected_indices*/
        _[4].includes(
          /*index*/
          _[32]
        )
      ), h[0] & /*filtered_indices, active_index*/
      34 && Oe(
        e,
        "active",
        /*index*/
        _[32] === /*active_index*/
        _[5]
      ), h[0] & /*filtered_indices, active_index*/
      34 && Oe(
        e,
        "bg-gray-100",
        /*index*/
        _[32] === /*active_index*/
        _[5]
      ), h[0] & /*filtered_indices, active_index*/
      34 && Oe(
        e,
        "dark:bg-gray-600",
        /*index*/
        _[32] === /*active_index*/
        _[5]
      ), h[0] & /*input_width*/
      256 && Re(
        e,
        "width",
        /*input_width*/
        _[8] + "px"
      );
    },
    d(_) {
      _ && tt(e);
    }
  };
}
function r_(t) {
  let e, n, i, r, l;
  _o(
    /*onwindowresize*/
    t[24]
  );
  let a = (
    /*show_options*/
    t[2] && !/*disabled*/
    t[3] && va(t)
  );
  return {
    c() {
      e = Ln("div"), n = Oi(), a && a.c(), i = ma(), this.h();
    },
    l(o) {
      e = In(o, "DIV", { class: !0 }), rr(e).forEach(tt), n = Ni(o), a && a.l(o), i = ma(), this.h();
    },
    h() {
      ge(e, "class", "reference");
    },
    m(o, s) {
      Ut(o, e, s), t[25](e), Ut(o, n, s), a && a.m(o, s), Ut(o, i, s), r || (l = [
        Hn(
          window,
          "scroll",
          /*scroll_listener*/
          t[14]
        ),
        Hn(
          window,
          "resize",
          /*onwindowresize*/
          t[24]
        )
      ], r = !0);
    },
    p(o, s) {
      /*show_options*/
      o[2] && !/*disabled*/
      o[3] ? a ? (a.p(o, s), s[0] & /*show_options, disabled*/
      12 && bi(a, 1)) : (a = va(o), a.c(), bi(a, 1), a.m(i.parentNode, i)) : a && (Yf(), ga(a, 1, 1, () => {
        a = null;
      }), Xf());
    },
    i(o) {
      bi(a);
    },
    o(o) {
      ga(a);
    },
    d(o) {
      o && (tt(e), tt(n), tt(i)), t[25](null), a && a.d(o), r = !1, mo(l);
    }
  };
}
function a_(t, e, n) {
  var i, r;
  let { choices: l } = e, { filtered_indices: a } = e, { show_options: o = !1 } = e, { disabled: s = !1 } = e, { selected_indices: u = [] } = e, { active_index: c = null } = e, { remember_scroll: _ = !1 } = e, { offset_from_top: h = 0 } = e, { from_top: d = !1 } = e, D, E, F, C, g, f, m, v, p, b, k = 0;
  function y() {
    const { top: T, bottom: ne } = g.getBoundingClientRect();
    d ? n(21, D = h) : n(21, D = T), n(22, E = b - ne);
  }
  let w = null;
  function A() {
    o && (w !== null && clearTimeout(w), w = setTimeout(
      () => {
        y(), w = null;
      },
      10
    ));
  }
  function B() {
    var T;
    (T = f == null ? void 0 : f.scrollTo) === null || T === void 0 || T.call(f, 0, k);
  }
  const q = i_();
  function P() {
    n(12, b = window.innerHeight);
  }
  function U(T) {
    _a[T ? "unshift" : "push"](() => {
      g = T, n(6, g);
    });
  }
  const O = (T) => q("change", T), W = (T) => n(13, k = T.currentTarget.scrollTop);
  function j(T) {
    _a[T ? "unshift" : "push"](() => {
      f = T, n(7, f);
    });
  }
  return t.$$set = (T) => {
    "choices" in T && n(0, l = T.choices), "filtered_indices" in T && n(1, a = T.filtered_indices), "show_options" in T && n(2, o = T.show_options), "disabled" in T && n(3, s = T.disabled), "selected_indices" in T && n(4, u = T.selected_indices), "active_index" in T && n(5, c = T.active_index), "remember_scroll" in T && n(16, _ = T.remember_scroll), "offset_from_top" in T && n(17, h = T.offset_from_top), "from_top" in T && n(18, d = T.from_top);
  }, t.$$.update = () => {
    if (t.$$.dirty[0] & /*show_options, refElement, remember_scroll, listElement, selected_indices, _a, _b, distance_from_bottom, distance_from_top, from_top, input_height*/
    16580820) {
      if (o && g) {
        if (_)
          B();
        else if (f && u.length > 0) {
          let ne = f.querySelectorAll("li");
          for (const $ of Array.from(ne))
            if ($.getAttribute("data-index") === u[0].toString()) {
              n(19, i = f == null ? void 0 : f.scrollTo) === null || i === void 0 || i.call(f, 0, $.offsetTop);
              break;
            }
        }
        y();
        const T = n(20, r = g.parentElement) === null || r === void 0 ? void 0 : r.getBoundingClientRect();
        n(23, F = (T == null ? void 0 : T.height) || 0), n(8, C = (T == null ? void 0 : T.width) || 0);
      }
      E > D || d ? (n(9, m = `${D}px`), n(11, p = E), n(10, v = null)) : (n(10, v = `${E + F}px`), n(11, p = D - F), n(9, m = null));
    }
  }, [
    l,
    a,
    o,
    s,
    u,
    c,
    g,
    f,
    C,
    m,
    v,
    p,
    b,
    k,
    A,
    q,
    _,
    h,
    d,
    i,
    r,
    D,
    E,
    F,
    P,
    U,
    O,
    W,
    j
  ];
}
class po extends Vf {
  constructor(e) {
    super(), Jf(
      this,
      e,
      a_,
      r_,
      e_,
      {
        choices: 0,
        filtered_indices: 1,
        show_options: 2,
        disabled: 3,
        selected_indices: 4,
        active_index: 5,
        remember_scroll: 16,
        offset_from_top: 17,
        from_top: 18
      },
      null,
      [-1, -1]
    );
  }
}
function l_(t, e) {
  return (t % e + e) % e;
}
function Ri(t, e) {
  return t.reduce((n, i, r) => ((!e || i[0].toLowerCase().includes(e.toLowerCase())) && n.push(r), n), []);
}
function go(t, e, n) {
  t("change", e), n || t("input");
}
function bo(t, e, n) {
  if (t.key === "Escape")
    return [!1, e];
  if ((t.key === "ArrowDown" || t.key === "ArrowUp") && n.length > 0)
    if (e === null)
      e = t.key === "ArrowDown" ? n[0] : n[n.length - 1];
    else {
      const i = n.indexOf(e), r = t.key === "ArrowUp" ? -1 : 1;
      e = n[l_(i + r, n.length)];
    }
  return [!0, e];
}
const {
  SvelteComponent: o_,
  append_hydration: re,
  attr: Y,
  binding_callbacks: s_,
  check_outros: Pn,
  children: me,
  claim_component: Vt,
  claim_element: ce,
  claim_space: We,
  claim_text: tn,
  create_component: Xt,
  destroy_component: Zt,
  destroy_each: u_,
  detach: J,
  element: he,
  ensure_array_like: wa,
  get_svelte_dataset: c_,
  group_outros: Nn,
  init: h_,
  insert_hydration: Pe,
  listen: Ye,
  mount_component: Wt,
  prevent_default: Da,
  run_all: ar,
  safe_not_equal: f_,
  set_data: nn,
  set_input_value: Ea,
  space: Qe,
  text: rn,
  toggle_class: mt,
  transition_in: le,
  transition_out: ve
} = window.__gradio__svelte__internal, { afterUpdate: __, createEventDispatcher: d_ } = window.__gradio__svelte__internal;
function Fa(t, e, n) {
  const i = t.slice();
  return i[41] = e[n], i;
}
function m_(t) {
  let e;
  return {
    c() {
      e = rn(
        /*label*/
        t[0]
      );
    },
    l(n) {
      e = tn(
        n,
        /*label*/
        t[0]
      );
    },
    m(n, i) {
      Pe(n, e, i);
    },
    p(n, i) {
      i[0] & /*label*/
      1 && nn(
        e,
        /*label*/
        n[0]
      );
    },
    d(n) {
      n && J(e);
    }
  };
}
function ka(t) {
  let e, n, i = "?", r, l, a;
  return {
    c() {
      e = he("div"), n = he("span"), n.textContent = i, r = Qe(), l = he("span"), a = rn(
        /*help*/
        t[2]
      ), this.h();
    },
    l(o) {
      e = ce(o, "DIV", { class: !0 });
      var s = me(e);
      n = ce(s, "SPAN", { class: !0, "data-svelte-h": !0 }), c_(n) !== "svelte-fzek5l" && (n.textContent = i), r = We(s), l = ce(s, "SPAN", { class: !0 });
      var u = me(l);
      a = tn(
        u,
        /*help*/
        t[2]
      ), u.forEach(J), s.forEach(J), this.h();
    },
    h() {
      Y(n, "class", "tooltip-icon svelte-wdyyoi"), Y(l, "class", "tooltip-text svelte-wdyyoi"), Y(e, "class", "tooltip-container svelte-wdyyoi");
    },
    m(o, s) {
      Pe(o, e, s), re(e, n), re(e, r), re(e, l), re(l, a);
    },
    p(o, s) {
      s[0] & /*help*/
      4 && nn(
        a,
        /*help*/
        o[2]
      );
    },
    d(o) {
      o && J(e);
    }
  };
}
function Aa(t) {
  let e, n;
  return {
    c() {
      e = he("div"), n = rn(
        /*info*/
        t[1]
      ), this.h();
    },
    l(i) {
      e = ce(i, "DIV", { class: !0 });
      var r = me(e);
      n = tn(
        r,
        /*info*/
        t[1]
      ), r.forEach(J), this.h();
    },
    h() {
      Y(e, "class", "info-text svelte-wdyyoi");
    },
    m(i, r) {
      Pe(i, e, r), re(e, n);
    },
    p(i, r) {
      r[0] & /*info*/
      2 && nn(
        n,
        /*info*/
        i[1]
      );
    },
    d(i) {
      i && J(e);
    }
  };
}
function p_(t) {
  let e = (
    /*s*/
    t[41] + ""
  ), n;
  return {
    c() {
      n = rn(e);
    },
    l(i) {
      n = tn(i, e);
    },
    m(i, r) {
      Pe(i, n, r);
    },
    p(i, r) {
      r[0] & /*selected_indices*/
      8192 && e !== (e = /*s*/
      i[41] + "") && nn(n, e);
    },
    d(i) {
      i && J(n);
    }
  };
}
function g_(t) {
  let e = (
    /*choices_names*/
    t[16][
      /*s*/
      t[41]
    ] + ""
  ), n;
  return {
    c() {
      n = rn(e);
    },
    l(i) {
      n = tn(i, e);
    },
    m(i, r) {
      Pe(i, n, r);
    },
    p(i, r) {
      r[0] & /*choices_names, selected_indices*/
      73728 && e !== (e = /*choices_names*/
      i[16][
        /*s*/
        i[41]
      ] + "") && nn(n, e);
    },
    d(i) {
      i && J(n);
    }
  };
}
function Ca(t) {
  let e, n, i, r, l, a;
  n = new fo({});
  function o() {
    return (
      /*click_handler*/
      t[32](
        /*s*/
        t[41]
      )
    );
  }
  function s(...u) {
    return (
      /*keydown_handler*/
      t[33](
        /*s*/
        t[41],
        ...u
      )
    );
  }
  return {
    c() {
      e = he("div"), Xt(n.$$.fragment), this.h();
    },
    l(u) {
      e = ce(u, "DIV", {
        class: !0,
        role: !0,
        tabindex: !0,
        title: !0
      });
      var c = me(e);
      Vt(n.$$.fragment, c), c.forEach(J), this.h();
    },
    h() {
      Y(e, "class", "token-remove svelte-wdyyoi"), Y(e, "role", "button"), Y(e, "tabindex", "0"), Y(e, "title", i = /*i18n*/
      t[10]("common.remove") + " " + /*s*/
      t[41]);
    },
    m(u, c) {
      Pe(u, e, c), Wt(n, e, null), r = !0, l || (a = [
        Ye(e, "click", Da(o)),
        Ye(e, "keydown", Da(s))
      ], l = !0);
    },
    p(u, c) {
      t = u, (!r || c[0] & /*i18n, selected_indices*/
      9216 && i !== (i = /*i18n*/
      t[10]("common.remove") + " " + /*s*/
      t[41])) && Y(e, "title", i);
    },
    i(u) {
      r || (le(n.$$.fragment, u), r = !0);
    },
    o(u) {
      ve(n.$$.fragment, u), r = !1;
    },
    d(u) {
      u && J(e), Zt(n), l = !1, ar(a);
    }
  };
}
function Sa(t) {
  let e, n, i, r;
  function l(u, c) {
    return typeof /*s*/
    u[41] == "number" ? g_ : p_;
  }
  let a = l(t), o = a(t), s = !/*disabled*/
  t[5] && Ca(t);
  return {
    c() {
      e = he("div"), n = he("span"), o.c(), i = Qe(), s && s.c(), this.h();
    },
    l(u) {
      e = ce(u, "DIV", { class: !0 });
      var c = me(e);
      n = ce(c, "SPAN", { class: !0 });
      var _ = me(n);
      o.l(_), _.forEach(J), i = We(c), s && s.l(c), c.forEach(J), this.h();
    },
    h() {
      Y(n, "class", "svelte-wdyyoi"), Y(e, "class", "token svelte-wdyyoi");
    },
    m(u, c) {
      Pe(u, e, c), re(e, n), o.m(n, null), re(e, i), s && s.m(e, null), r = !0;
    },
    p(u, c) {
      a === (a = l(u)) && o ? o.p(u, c) : (o.d(1), o = a(u), o && (o.c(), o.m(n, null))), /*disabled*/
      u[5] ? s && (Nn(), ve(s, 1, 1, () => {
        s = null;
      }), Pn()) : s ? (s.p(u, c), c[0] & /*disabled*/
      32 && le(s, 1)) : (s = Ca(u), s.c(), le(s, 1), s.m(e, null));
    },
    i(u) {
      r || (le(s), r = !0);
    },
    o(u) {
      ve(s), r = !1;
    },
    d(u) {
      u && J(e), o.d(), s && s.d();
    }
  };
}
function $a(t) {
  let e, n, i, r, l = (
    /*selected_indices*/
    t[13].length > 0 && xa(t)
  );
  return i = new ho({}), {
    c() {
      l && l.c(), e = Qe(), n = he("span"), Xt(i.$$.fragment), this.h();
    },
    l(a) {
      l && l.l(a), e = We(a), n = ce(a, "SPAN", { class: !0 });
      var o = me(n);
      Vt(i.$$.fragment, o), o.forEach(J), this.h();
    },
    h() {
      Y(n, "class", "icon-wrap svelte-wdyyoi");
    },
    m(a, o) {
      l && l.m(a, o), Pe(a, e, o), Pe(a, n, o), Wt(i, n, null), r = !0;
    },
    p(a, o) {
      /*selected_indices*/
      a[13].length > 0 ? l ? (l.p(a, o), o[0] & /*selected_indices*/
      8192 && le(l, 1)) : (l = xa(a), l.c(), le(l, 1), l.m(e.parentNode, e)) : l && (Nn(), ve(l, 1, 1, () => {
        l = null;
      }), Pn());
    },
    i(a) {
      r || (le(l), le(i.$$.fragment, a), r = !0);
    },
    o(a) {
      ve(l), ve(i.$$.fragment, a), r = !1;
    },
    d(a) {
      a && (J(e), J(n)), l && l.d(a), Zt(i);
    }
  };
}
function xa(t) {
  let e, n, i, r, l, a;
  return n = new fo({}), {
    c() {
      e = he("div"), Xt(n.$$.fragment), this.h();
    },
    l(o) {
      e = ce(o, "DIV", {
        role: !0,
        tabindex: !0,
        class: !0,
        title: !0
      });
      var s = me(e);
      Vt(n.$$.fragment, s), s.forEach(J), this.h();
    },
    h() {
      Y(e, "role", "button"), Y(e, "tabindex", "0"), Y(e, "class", "token-remove remove-all svelte-wdyyoi"), Y(e, "title", i = /*i18n*/
      t[10]("common.clear"));
    },
    m(o, s) {
      Pe(o, e, s), Wt(n, e, null), r = !0, l || (a = [
        Ye(
          e,
          "click",
          /*remove_all*/
          t[22]
        ),
        Ye(
          e,
          "keydown",
          /*keydown_handler_1*/
          t[37]
        )
      ], l = !0);
    },
    p(o, s) {
      (!r || s[0] & /*i18n*/
      1024 && i !== (i = /*i18n*/
      o[10]("common.clear"))) && Y(e, "title", i);
    },
    i(o) {
      r || (le(n.$$.fragment, o), r = !0);
    },
    o(o) {
      ve(n.$$.fragment, o), r = !1;
    },
    d(o) {
      o && J(e), Zt(n), l = !1, ar(a);
    }
  };
}
function b_(t) {
  let e, n, i, r, l, a, o, s, u, c, _, h, d, D, E, F, C, g, f;
  r = new uo({
    props: {
      show_label: (
        /*show_label*/
        t[6]
      ),
      info: void 0,
      $$slots: { default: [m_] },
      $$scope: { ctx: t }
    }
  });
  let m = (
    /*help*/
    t[2] && /*show_label*/
    t[6] && ka(t)
  ), v = (
    /*info*/
    t[1] && /*show_label*/
    t[6] && Aa(t)
  ), p = wa(
    /*selected_indices*/
    t[13]
  ), b = [];
  for (let w = 0; w < p.length; w += 1)
    b[w] = Sa(Fa(t, p, w));
  const k = (w) => ve(b[w], 1, 1, () => {
    b[w] = null;
  });
  let y = !/*disabled*/
  t[5] && $a(t);
  return F = new po({
    props: {
      show_options: (
        /*show_options*/
        t[15]
      ),
      choices: (
        /*choices*/
        t[4]
      ),
      filtered_indices: (
        /*filtered_indices*/
        t[12]
      ),
      disabled: (
        /*disabled*/
        t[5]
      ),
      selected_indices: (
        /*selected_indices*/
        t[13]
      ),
      active_index: (
        /*active_index*/
        t[17]
      ),
      remember_scroll: !0
    }
  }), F.$on(
    "change",
    /*handle_option_selected*/
    t[21]
  ), {
    c() {
      e = he("label"), n = he("div"), i = he("div"), Xt(r.$$.fragment), l = Qe(), m && m.c(), a = Qe(), v && v.c(), o = Qe(), s = he("div"), u = he("div");
      for (let w = 0; w < b.length; w += 1)
        b[w].c();
      c = Qe(), _ = he("div"), h = he("input"), D = Qe(), y && y.c(), E = Qe(), Xt(F.$$.fragment), this.h();
    },
    l(w) {
      e = ce(w, "LABEL", { class: !0 });
      var A = me(e);
      n = ce(A, "DIV", { class: !0 });
      var B = me(n);
      i = ce(B, "DIV", { class: !0 });
      var q = me(i);
      Vt(r.$$.fragment, q), l = We(q), m && m.l(q), q.forEach(J), a = We(B), v && v.l(B), B.forEach(J), o = We(A), s = ce(A, "DIV", { class: !0 });
      var P = me(s);
      u = ce(P, "DIV", { class: !0 });
      var U = me(u);
      for (let W = 0; W < b.length; W += 1)
        b[W].l(U);
      c = We(U), _ = ce(U, "DIV", { class: !0 });
      var O = me(_);
      h = ce(O, "INPUT", { class: !0, autocomplete: !0 }), D = We(O), y && y.l(O), O.forEach(J), U.forEach(J), E = We(P), Vt(F.$$.fragment, P), P.forEach(J), A.forEach(J), this.h();
    },
    h() {
      Y(i, "class", "title-line svelte-wdyyoi"), Y(n, "class", "label-container svelte-wdyyoi"), Y(h, "class", "border-none svelte-wdyyoi"), h.disabled = /*disabled*/
      t[5], Y(h, "autocomplete", "off"), h.readOnly = d = !/*filterable*/
      t[9], mt(h, "subdued", !/*choices_names*/
      t[16].includes(
        /*input_text*/
        t[11]
      ) && !/*allow_custom_value*/
      t[8] || /*selected_indices*/
      t[13].length === /*max_choices*/
      t[3]), Y(_, "class", "secondary-wrap svelte-wdyyoi"), Y(u, "class", "wrap-inner svelte-wdyyoi"), mt(
        u,
        "show_options",
        /*show_options*/
        t[15]
      ), Y(s, "class", "wrap svelte-wdyyoi"), Y(e, "class", "svelte-wdyyoi"), mt(
        e,
        "container",
        /*container*/
        t[7]
      );
    },
    m(w, A) {
      Pe(w, e, A), re(e, n), re(n, i), Wt(r, i, null), re(i, l), m && m.m(i, null), re(n, a), v && v.m(n, null), re(e, o), re(e, s), re(s, u);
      for (let B = 0; B < b.length; B += 1)
        b[B] && b[B].m(u, null);
      re(u, c), re(u, _), re(_, h), Ea(
        h,
        /*input_text*/
        t[11]
      ), t[35](h), re(_, D), y && y.m(_, null), re(s, E), Wt(F, s, null), C = !0, g || (f = [
        Ye(
          h,
          "input",
          /*input_input_handler*/
          t[34]
        ),
        Ye(
          h,
          "keydown",
          /*handle_key_down*/
          t[24]
        ),
        Ye(
          h,
          "keyup",
          /*keyup_handler*/
          t[36]
        ),
        Ye(
          h,
          "blur",
          /*handle_blur*/
          t[19]
        ),
        Ye(
          h,
          "focus",
          /*handle_focus*/
          t[23]
        )
      ], g = !0);
    },
    p(w, A) {
      const B = {};
      if (A[0] & /*show_label*/
      64 && (B.show_label = /*show_label*/
      w[6]), A[0] & /*label*/
      1 | A[1] & /*$$scope*/
      8192 && (B.$$scope = { dirty: A, ctx: w }), r.$set(B), /*help*/
      w[2] && /*show_label*/
      w[6] ? m ? m.p(w, A) : (m = ka(w), m.c(), m.m(i, null)) : m && (m.d(1), m = null), /*info*/
      w[1] && /*show_label*/
      w[6] ? v ? v.p(w, A) : (v = Aa(w), v.c(), v.m(n, null)) : v && (v.d(1), v = null), A[0] & /*i18n, selected_indices, remove_selected_choice, disabled, choices_names*/
      1123360) {
        p = wa(
          /*selected_indices*/
          w[13]
        );
        let P;
        for (P = 0; P < p.length; P += 1) {
          const U = Fa(w, p, P);
          b[P] ? (b[P].p(U, A), le(b[P], 1)) : (b[P] = Sa(U), b[P].c(), le(b[P], 1), b[P].m(u, c));
        }
        for (Nn(), P = p.length; P < b.length; P += 1)
          k(P);
        Pn();
      }
      (!C || A[0] & /*disabled*/
      32) && (h.disabled = /*disabled*/
      w[5]), (!C || A[0] & /*filterable*/
      512 && d !== (d = !/*filterable*/
      w[9])) && (h.readOnly = d), A[0] & /*input_text*/
      2048 && h.value !== /*input_text*/
      w[11] && Ea(
        h,
        /*input_text*/
        w[11]
      ), (!C || A[0] & /*choices_names, input_text, allow_custom_value, selected_indices, max_choices*/
      76040) && mt(h, "subdued", !/*choices_names*/
      w[16].includes(
        /*input_text*/
        w[11]
      ) && !/*allow_custom_value*/
      w[8] || /*selected_indices*/
      w[13].length === /*max_choices*/
      w[3]), /*disabled*/
      w[5] ? y && (Nn(), ve(y, 1, 1, () => {
        y = null;
      }), Pn()) : y ? (y.p(w, A), A[0] & /*disabled*/
      32 && le(y, 1)) : (y = $a(w), y.c(), le(y, 1), y.m(_, null)), (!C || A[0] & /*show_options*/
      32768) && mt(
        u,
        "show_options",
        /*show_options*/
        w[15]
      );
      const q = {};
      A[0] & /*show_options*/
      32768 && (q.show_options = /*show_options*/
      w[15]), A[0] & /*choices*/
      16 && (q.choices = /*choices*/
      w[4]), A[0] & /*filtered_indices*/
      4096 && (q.filtered_indices = /*filtered_indices*/
      w[12]), A[0] & /*disabled*/
      32 && (q.disabled = /*disabled*/
      w[5]), A[0] & /*selected_indices*/
      8192 && (q.selected_indices = /*selected_indices*/
      w[13]), A[0] & /*active_index*/
      131072 && (q.active_index = /*active_index*/
      w[17]), F.$set(q), (!C || A[0] & /*container*/
      128) && mt(
        e,
        "container",
        /*container*/
        w[7]
      );
    },
    i(w) {
      if (!C) {
        le(r.$$.fragment, w);
        for (let A = 0; A < p.length; A += 1)
          le(b[A]);
        le(y), le(F.$$.fragment, w), C = !0;
      }
    },
    o(w) {
      ve(r.$$.fragment, w), b = b.filter(Boolean);
      for (let A = 0; A < b.length; A += 1)
        ve(b[A]);
      ve(y), ve(F.$$.fragment, w), C = !1;
    },
    d(w) {
      w && J(e), Zt(r), m && m.d(), v && v.d(), u_(b, w), t[35](null), y && y.d(), Zt(F), g = !1, ar(f);
    }
  };
}
function v_(t, e, n) {
  let { label: i } = e, { info: r = void 0 } = e, { help: l = void 0 } = e, { value: a = [] } = e, o = [], { value_is_output: s = !1 } = e, { max_choices: u = null } = e, { choices: c } = e, _, { disabled: h = !1 } = e, { show_label: d } = e, { container: D = !0 } = e, { allow_custom_value: E = !1 } = e, { filterable: F = !0 } = e, { i18n: C } = e, g, f = "", m = "", v = !1, p, b, k = [], y = null, w = [], A = [];
  const B = d_();
  Array.isArray(a) && a.forEach((S) => {
    const fe = c.map((it) => it[1]).indexOf(S);
    fe !== -1 ? w.push(fe) : w.push(S);
  });
  function q() {
    E || n(11, f = ""), E && f !== "" && (U(f), n(11, f = "")), n(15, v = !1), n(17, y = null), B("blur");
  }
  function P(S) {
    n(13, w = w.filter((fe) => fe !== S)), B("select", {
      index: typeof S == "number" ? S : -1,
      value: typeof S == "number" ? b[S] : S,
      selected: !1
    });
  }
  function U(S) {
    (u === null || w.length < u) && (n(13, w = [...w, S]), B("select", {
      index: typeof S == "number" ? S : -1,
      value: typeof S == "number" ? b[S] : S,
      selected: !0
    })), w.length === u && (n(15, v = !1), n(17, y = null), g.blur());
  }
  function O(S) {
    const fe = parseInt(S.detail.target.dataset.index);
    W(fe);
  }
  function W(S) {
    w.includes(S) ? P(S) : U(S), n(11, f = "");
  }
  function j(S) {
    n(13, w = []), n(11, f = ""), S.preventDefault();
  }
  function T(S) {
    n(12, k = c.map((fe, it) => it)), (u === null || w.length < u) && n(15, v = !0), B("focus");
  }
  function ne(S) {
    n(15, [v, y] = bo(S, y, k), v, (n(17, y), n(4, c), n(28, _), n(11, f), n(29, m), n(8, E), n(12, k))), S.key === "Enter" && (y !== null ? W(y) : E && (U(f), n(11, f = ""))), S.key === "Backspace" && f === "" && n(13, w = [...w.slice(0, -1)]), w.length === u && (n(15, v = !1), n(17, y = null));
  }
  function $() {
    a === void 0 ? n(13, w = []) : Array.isArray(a) && n(13, w = a.map((S) => {
      const fe = b.indexOf(S);
      if (fe !== -1)
        return fe;
      if (E)
        return S;
    }).filter((S) => S !== void 0));
  }
  __(() => {
    n(26, s = !1);
  });
  const I = (S) => P(S), Se = (S, fe) => {
    fe.key === "Enter" && P(S);
  };
  function x() {
    f = this.value, n(11, f);
  }
  function L(S) {
    s_[S ? "unshift" : "push"](() => {
      g = S, n(14, g);
    });
  }
  const Je = (S) => B("key_up", { key: S.key, input_value: f }), ht = (S) => {
    S.key === "Enter" && j(S);
  };
  return t.$$set = (S) => {
    "label" in S && n(0, i = S.label), "info" in S && n(1, r = S.info), "help" in S && n(2, l = S.help), "value" in S && n(25, a = S.value), "value_is_output" in S && n(26, s = S.value_is_output), "max_choices" in S && n(3, u = S.max_choices), "choices" in S && n(4, c = S.choices), "disabled" in S && n(5, h = S.disabled), "show_label" in S && n(6, d = S.show_label), "container" in S && n(7, D = S.container), "allow_custom_value" in S && n(8, E = S.allow_custom_value), "filterable" in S && n(9, F = S.filterable), "i18n" in S && n(10, C = S.i18n);
  }, t.$$.update = () => {
    t.$$.dirty[0] & /*choices*/
    16 && (n(16, p = c.map((S) => S[0])), n(30, b = c.map((S) => S[1]))), t.$$.dirty[0] & /*choices, old_choices, input_text, old_input_text, allow_custom_value, filtered_indices*/
    805312784 && (c !== _ || f !== m) && (n(12, k = Ri(c, f)), n(28, _ = c), n(29, m = f), E || n(17, y = k[0])), t.$$.dirty[0] & /*selected_indices, choices_values*/
    1073750016 | t.$$.dirty[1] & /*old_selected_index*/
    1 && JSON.stringify(w) != JSON.stringify(A) && (n(25, a = w.map((S) => typeof S == "number" ? b[S] : S)), n(31, A = w.slice())), t.$$.dirty[0] & /*value, old_value, value_is_output*/
    234881024 && JSON.stringify(a) != JSON.stringify(o) && (go(B, a, s), n(27, o = Array.isArray(a) ? a.slice() : a)), t.$$.dirty[0] & /*value*/
    33554432 && $();
  }, [
    i,
    r,
    l,
    u,
    c,
    h,
    d,
    D,
    E,
    F,
    C,
    f,
    k,
    w,
    g,
    v,
    p,
    y,
    B,
    q,
    P,
    O,
    j,
    T,
    ne,
    a,
    s,
    o,
    _,
    m,
    b,
    A,
    I,
    Se,
    x,
    L,
    Je,
    ht
  ];
}
class y_ extends o_ {
  constructor(e) {
    super(), h_(
      this,
      e,
      v_,
      b_,
      f_,
      {
        label: 0,
        info: 1,
        help: 2,
        value: 25,
        value_is_output: 26,
        max_choices: 3,
        choices: 4,
        disabled: 5,
        show_label: 6,
        container: 7,
        allow_custom_value: 8,
        filterable: 9,
        i18n: 10
      },
      null,
      [-1, -1]
    );
  }
}
const {
  SvelteComponent: w_,
  append_hydration: ue,
  attr: ie,
  binding_callbacks: D_,
  check_outros: E_,
  children: Me,
  claim_component: Mi,
  claim_element: De,
  claim_space: bt,
  claim_text: lr,
  create_component: qi,
  destroy_component: Ui,
  detach: de,
  element: Ee,
  get_svelte_dataset: F_,
  group_outros: k_,
  init: A_,
  insert_hydration: an,
  listen: Ht,
  mount_component: Gi,
  run_all: C_,
  safe_not_equal: S_,
  set_data: or,
  set_input_value: Ba,
  space: vt,
  text: sr,
  toggle_class: pt,
  transition_in: yt,
  transition_out: Nt
} = window.__gradio__svelte__internal, { createEventDispatcher: $_, afterUpdate: x_ } = window.__gradio__svelte__internal;
function B_(t) {
  let e;
  return {
    c() {
      e = sr(
        /*label*/
        t[0]
      );
    },
    l(n) {
      e = lr(
        n,
        /*label*/
        t[0]
      );
    },
    m(n, i) {
      an(n, e, i);
    },
    p(n, i) {
      i[0] & /*label*/
      1 && or(
        e,
        /*label*/
        n[0]
      );
    },
    d(n) {
      n && de(e);
    }
  };
}
function Ta(t) {
  let e, n, i = "?", r, l, a;
  return {
    c() {
      e = Ee("div"), n = Ee("span"), n.textContent = i, r = vt(), l = Ee("span"), a = sr(
        /*help*/
        t[2]
      ), this.h();
    },
    l(o) {
      e = De(o, "DIV", { class: !0 });
      var s = Me(e);
      n = De(s, "SPAN", { class: !0, "data-svelte-h": !0 }), F_(n) !== "svelte-fzek5l" && (n.textContent = i), r = bt(s), l = De(s, "SPAN", { class: !0 });
      var u = Me(l);
      a = lr(
        u,
        /*help*/
        t[2]
      ), u.forEach(de), s.forEach(de), this.h();
    },
    h() {
      ie(n, "class", "tooltip-icon svelte-okfi1s"), ie(l, "class", "tooltip-text svelte-okfi1s"), ie(e, "class", "tooltip-container svelte-okfi1s");
    },
    m(o, s) {
      an(o, e, s), ue(e, n), ue(e, r), ue(e, l), ue(l, a);
    },
    p(o, s) {
      s[0] & /*help*/
      4 && or(
        a,
        /*help*/
        o[2]
      );
    },
    d(o) {
      o && de(e);
    }
  };
}
function Ia(t) {
  let e, n;
  return {
    c() {
      e = Ee("div"), n = sr(
        /*info*/
        t[1]
      ), this.h();
    },
    l(i) {
      e = De(i, "DIV", { class: !0 });
      var r = Me(e);
      n = lr(
        r,
        /*info*/
        t[1]
      ), r.forEach(de), this.h();
    },
    h() {
      ie(e, "class", "info-text svelte-okfi1s");
    },
    m(i, r) {
      an(i, e, r), ue(e, n);
    },
    p(i, r) {
      r[0] & /*info*/
      2 && or(
        n,
        /*info*/
        i[1]
      );
    },
    d(i) {
      i && de(e);
    }
  };
}
function La(t) {
  let e, n, i;
  return n = new ho({}), {
    c() {
      e = Ee("div"), qi(n.$$.fragment), this.h();
    },
    l(r) {
      e = De(r, "DIV", { class: !0 });
      var l = Me(e);
      Mi(n.$$.fragment, l), l.forEach(de), this.h();
    },
    h() {
      ie(e, "class", "icon-wrap svelte-okfi1s");
    },
    m(r, l) {
      an(r, e, l), Gi(n, e, null), i = !0;
    },
    i(r) {
      i || (yt(n.$$.fragment, r), i = !0);
    },
    o(r) {
      Nt(n.$$.fragment, r), i = !1;
    },
    d(r) {
      r && de(e), Ui(n);
    }
  };
}
function T_(t) {
  let e, n, i, r, l, a, o, s, u, c, _, h, d, D, E, F, C, g;
  r = new uo({
    props: {
      show_label: (
        /*show_label*/
        t[5]
      ),
      info: void 0,
      $$slots: { default: [B_] },
      $$scope: { ctx: t }
    }
  });
  let f = (
    /*help*/
    t[2] && /*show_label*/
    t[5] && Ta(t)
  ), m = (
    /*info*/
    t[1] && /*show_label*/
    t[5] && Ia(t)
  ), v = !/*disabled*/
  t[4] && La();
  return E = new po({
    props: {
      show_options: (
        /*show_options*/
        t[13]
      ),
      choices: (
        /*choices*/
        t[3]
      ),
      filtered_indices: (
        /*filtered_indices*/
        t[11]
      ),
      disabled: (
        /*disabled*/
        t[4]
      ),
      selected_indices: (
        /*selected_index*/
        t[12] === null ? [] : [
          /*selected_index*/
          t[12]
        ]
      ),
      active_index: (
        /*active_index*/
        t[15]
      )
    }
  }), E.$on(
    "change",
    /*handle_option_selected*/
    t[17]
  ), {
    c() {
      e = Ee("div"), n = Ee("div"), i = Ee("div"), qi(r.$$.fragment), l = vt(), f && f.c(), a = vt(), m && m.c(), o = vt(), s = Ee("div"), u = Ee("div"), c = Ee("div"), _ = Ee("input"), d = vt(), v && v.c(), D = vt(), qi(E.$$.fragment), this.h();
    },
    l(p) {
      e = De(p, "DIV", { class: !0 });
      var b = Me(e);
      n = De(b, "DIV", { class: !0 });
      var k = Me(n);
      i = De(k, "DIV", { class: !0 });
      var y = Me(i);
      Mi(r.$$.fragment, y), l = bt(y), f && f.l(y), y.forEach(de), a = bt(k), m && m.l(k), k.forEach(de), o = bt(b), s = De(b, "DIV", { class: !0 });
      var w = Me(s);
      u = De(w, "DIV", { class: !0 });
      var A = Me(u);
      c = De(A, "DIV", { class: !0 });
      var B = Me(c);
      _ = De(B, "INPUT", {
        role: !0,
        "aria-controls": !0,
        "aria-expanded": !0,
        "aria-label": !0,
        class: !0,
        autocomplete: !0
      }), d = bt(B), v && v.l(B), B.forEach(de), A.forEach(de), D = bt(w), Mi(E.$$.fragment, w), w.forEach(de), b.forEach(de), this.h();
    },
    h() {
      ie(i, "class", "title-line svelte-okfi1s"), ie(n, "class", "label-container svelte-okfi1s"), ie(_, "role", "listbox"), ie(_, "aria-controls", "dropdown-options"), ie(
        _,
        "aria-expanded",
        /*show_options*/
        t[13]
      ), ie(
        _,
        "aria-label",
        /*label*/
        t[0]
      ), ie(_, "class", "border-none svelte-okfi1s"), _.disabled = /*disabled*/
      t[4], ie(_, "autocomplete", "off"), _.readOnly = h = !/*filterable*/
      t[8], pt(_, "subdued", !/*choices_names*/
      t[14].includes(
        /*input_text*/
        t[10]
      ) && !/*allow_custom_value*/
      t[7]), ie(c, "class", "secondary-wrap svelte-okfi1s"), ie(u, "class", "wrap-inner svelte-okfi1s"), pt(
        u,
        "show_options",
        /*show_options*/
        t[13]
      ), ie(s, "class", "wrap svelte-okfi1s"), ie(e, "class", "svelte-okfi1s"), pt(
        e,
        "container",
        /*container*/
        t[6]
      );
    },
    m(p, b) {
      an(p, e, b), ue(e, n), ue(n, i), Gi(r, i, null), ue(i, l), f && f.m(i, null), ue(n, a), m && m.m(n, null), ue(e, o), ue(e, s), ue(s, u), ue(u, c), ue(c, _), Ba(
        _,
        /*input_text*/
        t[10]
      ), t[30](_), ue(c, d), v && v.m(c, null), ue(s, D), Gi(E, s, null), F = !0, C || (g = [
        Ht(
          _,
          "input",
          /*input_input_handler*/
          t[29]
        ),
        Ht(
          _,
          "keydown",
          /*handle_key_down*/
          t[20]
        ),
        Ht(
          _,
          "keyup",
          /*keyup_handler*/
          t[31]
        ),
        Ht(
          _,
          "blur",
          /*handle_blur*/
          t[19]
        ),
        Ht(
          _,
          "focus",
          /*handle_focus*/
          t[18]
        )
      ], C = !0);
    },
    p(p, b) {
      const k = {};
      b[0] & /*show_label*/
      32 && (k.show_label = /*show_label*/
      p[5]), b[0] & /*label*/
      1 | b[1] & /*$$scope*/
      16 && (k.$$scope = { dirty: b, ctx: p }), r.$set(k), /*help*/
      p[2] && /*show_label*/
      p[5] ? f ? f.p(p, b) : (f = Ta(p), f.c(), f.m(i, null)) : f && (f.d(1), f = null), /*info*/
      p[1] && /*show_label*/
      p[5] ? m ? m.p(p, b) : (m = Ia(p), m.c(), m.m(n, null)) : m && (m.d(1), m = null), (!F || b[0] & /*show_options*/
      8192) && ie(
        _,
        "aria-expanded",
        /*show_options*/
        p[13]
      ), (!F || b[0] & /*label*/
      1) && ie(
        _,
        "aria-label",
        /*label*/
        p[0]
      ), (!F || b[0] & /*disabled*/
      16) && (_.disabled = /*disabled*/
      p[4]), (!F || b[0] & /*filterable*/
      256 && h !== (h = !/*filterable*/
      p[8])) && (_.readOnly = h), b[0] & /*input_text*/
      1024 && _.value !== /*input_text*/
      p[10] && Ba(
        _,
        /*input_text*/
        p[10]
      ), (!F || b[0] & /*choices_names, input_text, allow_custom_value*/
      17536) && pt(_, "subdued", !/*choices_names*/
      p[14].includes(
        /*input_text*/
        p[10]
      ) && !/*allow_custom_value*/
      p[7]), /*disabled*/
      p[4] ? v && (k_(), Nt(v, 1, 1, () => {
        v = null;
      }), E_()) : v ? b[0] & /*disabled*/
      16 && yt(v, 1) : (v = La(), v.c(), yt(v, 1), v.m(c, null)), (!F || b[0] & /*show_options*/
      8192) && pt(
        u,
        "show_options",
        /*show_options*/
        p[13]
      );
      const y = {};
      b[0] & /*show_options*/
      8192 && (y.show_options = /*show_options*/
      p[13]), b[0] & /*choices*/
      8 && (y.choices = /*choices*/
      p[3]), b[0] & /*filtered_indices*/
      2048 && (y.filtered_indices = /*filtered_indices*/
      p[11]), b[0] & /*disabled*/
      16 && (y.disabled = /*disabled*/
      p[4]), b[0] & /*selected_index*/
      4096 && (y.selected_indices = /*selected_index*/
      p[12] === null ? [] : [
        /*selected_index*/
        p[12]
      ]), b[0] & /*active_index*/
      32768 && (y.active_index = /*active_index*/
      p[15]), E.$set(y), (!F || b[0] & /*container*/
      64) && pt(
        e,
        "container",
        /*container*/
        p[6]
      );
    },
    i(p) {
      F || (yt(r.$$.fragment, p), yt(v), yt(E.$$.fragment, p), F = !0);
    },
    o(p) {
      Nt(r.$$.fragment, p), Nt(v), Nt(E.$$.fragment, p), F = !1;
    },
    d(p) {
      p && de(e), Ui(r), f && f.d(), m && m.d(), t[30](null), v && v.d(), Ui(E), C = !1, C_(g);
    }
  };
}
function I_(t, e, n) {
  let { label: i } = e, { info: r = void 0 } = e, { help: l = void 0 } = e, { value: a = void 0 } = e, o, { value_is_output: s = !1 } = e, { choices: u } = e, c, { disabled: _ = !1 } = e, { show_label: h } = e, { container: d = !0 } = e, { allow_custom_value: D = !1 } = e, { filterable: E = !0 } = e, F, C = !1, g, f, m = "", v = "", p = !1, b = [], k = null, y = null, w;
  const A = $_();
  a && (w = u.map((I) => I[1]).indexOf(a), y = w, y === -1 ? (o = a, y = null) : ([m, o] = u[y], v = m), P());
  function B() {
    n(14, g = u.map((I) => I[0])), n(25, f = u.map((I) => I[1]));
  }
  const q = typeof window < "u";
  function P() {
    B(), a === void 0 || Array.isArray(a) && a.length === 0 ? (n(10, m = ""), n(12, y = null)) : f.includes(a) ? (n(10, m = g[f.indexOf(a)]), n(12, y = f.indexOf(a))) : D ? (n(10, m = a), n(12, y = null)) : (n(10, m = ""), n(12, y = null)), n(28, w = y);
  }
  function U(I) {
    if (n(12, y = parseInt(I.detail.target.dataset.index)), isNaN(y)) {
      n(12, y = null);
      return;
    }
    n(13, C = !1), n(15, k = null), F.blur();
  }
  function O(I) {
    n(11, b = u.map((Se, x) => x)), n(13, C = !0), A("focus");
  }
  function W() {
    D ? n(21, a = m) : n(10, m = g[f.indexOf(a)]), n(13, C = !1), n(15, k = null), A("blur");
  }
  function j(I) {
    n(13, [C, k] = bo(I, k, b), C, (n(15, k), n(3, u), n(24, c), n(7, D), n(10, m), n(11, b), n(9, F), n(26, v), n(12, y), n(28, w), n(27, p), n(25, f))), I.key === "Enter" && (k !== null ? (n(12, y = k), n(13, C = !1), F.blur(), n(15, k = null)) : g.includes(m) ? (n(12, y = g.indexOf(m)), n(13, C = !1), n(15, k = null), F.blur()) : D && (n(21, a = m), n(12, y = null), n(13, C = !1), n(15, k = null), F.blur()));
  }
  x_(() => {
    n(22, s = !1), n(27, p = !0);
  });
  function T() {
    m = this.value, n(10, m), n(12, y), n(28, w), n(27, p), n(3, u), n(25, f);
  }
  function ne(I) {
    D_[I ? "unshift" : "push"](() => {
      F = I, n(9, F);
    });
  }
  const $ = (I) => A("key_up", { key: I.key, input_value: m });
  return t.$$set = (I) => {
    "label" in I && n(0, i = I.label), "info" in I && n(1, r = I.info), "help" in I && n(2, l = I.help), "value" in I && n(21, a = I.value), "value_is_output" in I && n(22, s = I.value_is_output), "choices" in I && n(3, u = I.choices), "disabled" in I && n(4, _ = I.disabled), "show_label" in I && n(5, h = I.show_label), "container" in I && n(6, d = I.container), "allow_custom_value" in I && n(7, D = I.allow_custom_value), "filterable" in I && n(8, E = I.filterable);
  }, t.$$.update = () => {
    t.$$.dirty[0] & /*selected_index, old_selected_index, initialized, choices, choices_values*/
    436211720 && y !== w && y !== null && p && (n(10, [m, a] = u[y], m, (n(21, a), n(12, y), n(28, w), n(27, p), n(3, u), n(25, f))), n(28, w = y), A("select", {
      index: y,
      value: f[y],
      selected: !0
    })), t.$$.dirty[0] & /*old_value, value, value_is_output*/
    14680064 && JSON.stringify(o) !== JSON.stringify(a) && (P(), go(A, a, s), n(23, o = a)), t.$$.dirty[0] & /*choices*/
    8 && B(), t.$$.dirty[0] & /*choices, old_choices, allow_custom_value, input_text, filtered_indices, filter_input*/
    16780936 && u !== c && (D || P(), n(24, c = u), n(11, b = Ri(u, m)), !D && b.length > 0 && n(15, k = b[0]), q && F === document.activeElement && n(13, C = !0)), t.$$.dirty[0] & /*input_text, old_input_text, choices, allow_custom_value, filtered_indices*/
    67112072 && m !== v && (n(11, b = Ri(u, m)), n(26, v = m), !D && b.length > 0 && n(15, k = b[0]));
  }, [
    i,
    r,
    l,
    u,
    _,
    h,
    d,
    D,
    E,
    F,
    m,
    b,
    y,
    C,
    g,
    k,
    A,
    U,
    O,
    W,
    j,
    a,
    s,
    o,
    c,
    f,
    v,
    p,
    w,
    T,
    ne,
    $
  ];
}
class L_ extends w_ {
  constructor(e) {
    super(), A_(
      this,
      e,
      I_,
      T_,
      S_,
      {
        label: 0,
        info: 1,
        help: 2,
        value: 21,
        value_is_output: 22,
        choices: 3,
        disabled: 4,
        show_label: 5,
        container: 6,
        allow_custom_value: 7,
        filterable: 8
      },
      null,
      [-1, -1]
    );
  }
}
function wt(t) {
  let e = ["", "k", "M", "G", "T", "P", "E", "Z"], n = 0;
  for (; t > 1e3 && n < e.length - 1; )
    t /= 1e3, n++;
  let i = e[n];
  return (Number.isInteger(t) ? t : t.toFixed(1)) + i;
}
const {
  SvelteComponent: H_,
  append_hydration: xe,
  attr: G,
  children: ye,
  claim_element: P_,
  claim_svg_element: Be,
  component_subscribe: Ha,
  detach: pe,
  element: N_,
  init: O_,
  insert_hydration: R_,
  noop: Pa,
  safe_not_equal: M_,
  set_style: yn,
  svg_element: Te,
  toggle_class: Na
} = window.__gradio__svelte__internal, { onMount: q_ } = window.__gradio__svelte__internal;
function U_(t) {
  let e, n, i, r, l, a, o, s, u, c, _, h;
  return {
    c() {
      e = N_("div"), n = Te("svg"), i = Te("g"), r = Te("path"), l = Te("path"), a = Te("path"), o = Te("path"), s = Te("g"), u = Te("path"), c = Te("path"), _ = Te("path"), h = Te("path"), this.h();
    },
    l(d) {
      e = P_(d, "DIV", { class: !0 });
      var D = ye(e);
      n = Be(D, "svg", {
        viewBox: !0,
        fill: !0,
        xmlns: !0,
        class: !0
      });
      var E = ye(n);
      i = Be(E, "g", { style: !0 });
      var F = ye(i);
      r = Be(F, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), ye(r).forEach(pe), l = Be(F, "path", { d: !0, fill: !0, class: !0 }), ye(l).forEach(pe), a = Be(F, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), ye(a).forEach(pe), o = Be(F, "path", { d: !0, fill: !0, class: !0 }), ye(o).forEach(pe), F.forEach(pe), s = Be(E, "g", { style: !0 });
      var C = ye(s);
      u = Be(C, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), ye(u).forEach(pe), c = Be(C, "path", { d: !0, fill: !0, class: !0 }), ye(c).forEach(pe), _ = Be(C, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), ye(_).forEach(pe), h = Be(C, "path", { d: !0, fill: !0, class: !0 }), ye(h).forEach(pe), C.forEach(pe), E.forEach(pe), D.forEach(pe), this.h();
    },
    h() {
      G(r, "d", "M255.926 0.754768L509.702 139.936V221.027L255.926 81.8465V0.754768Z"), G(r, "fill", "#FF7C00"), G(r, "fill-opacity", "0.4"), G(r, "class", "svelte-43sxxs"), G(l, "d", "M509.69 139.936L254.981 279.641V361.255L509.69 221.55V139.936Z"), G(l, "fill", "#FF7C00"), G(l, "class", "svelte-43sxxs"), G(a, "d", "M0.250138 139.937L254.981 279.641V361.255L0.250138 221.55V139.937Z"), G(a, "fill", "#FF7C00"), G(a, "fill-opacity", "0.4"), G(a, "class", "svelte-43sxxs"), G(o, "d", "M255.923 0.232622L0.236328 139.936V221.55L255.923 81.8469V0.232622Z"), G(o, "fill", "#FF7C00"), G(o, "class", "svelte-43sxxs"), yn(i, "transform", "translate(" + /*$top*/
      t[1][0] + "px, " + /*$top*/
      t[1][1] + "px)"), G(u, "d", "M255.926 141.5L509.702 280.681V361.773L255.926 222.592V141.5Z"), G(u, "fill", "#FF7C00"), G(u, "fill-opacity", "0.4"), G(u, "class", "svelte-43sxxs"), G(c, "d", "M509.69 280.679L254.981 420.384V501.998L509.69 362.293V280.679Z"), G(c, "fill", "#FF7C00"), G(c, "class", "svelte-43sxxs"), G(_, "d", "M0.250138 280.681L254.981 420.386V502L0.250138 362.295V280.681Z"), G(_, "fill", "#FF7C00"), G(_, "fill-opacity", "0.4"), G(_, "class", "svelte-43sxxs"), G(h, "d", "M255.923 140.977L0.236328 280.68V362.294L255.923 222.591V140.977Z"), G(h, "fill", "#FF7C00"), G(h, "class", "svelte-43sxxs"), yn(s, "transform", "translate(" + /*$bottom*/
      t[2][0] + "px, " + /*$bottom*/
      t[2][1] + "px)"), G(n, "viewBox", "-1200 -1200 3000 3000"), G(n, "fill", "none"), G(n, "xmlns", "http://www.w3.org/2000/svg"), G(n, "class", "svelte-43sxxs"), G(e, "class", "svelte-43sxxs"), Na(
        e,
        "margin",
        /*margin*/
        t[0]
      );
    },
    m(d, D) {
      R_(d, e, D), xe(e, n), xe(n, i), xe(i, r), xe(i, l), xe(i, a), xe(i, o), xe(n, s), xe(s, u), xe(s, c), xe(s, _), xe(s, h);
    },
    p(d, [D]) {
      D & /*$top*/
      2 && yn(i, "transform", "translate(" + /*$top*/
      d[1][0] + "px, " + /*$top*/
      d[1][1] + "px)"), D & /*$bottom*/
      4 && yn(s, "transform", "translate(" + /*$bottom*/
      d[2][0] + "px, " + /*$bottom*/
      d[2][1] + "px)"), D & /*margin*/
      1 && Na(
        e,
        "margin",
        /*margin*/
        d[0]
      );
    },
    i: Pa,
    o: Pa,
    d(d) {
      d && pe(e);
    }
  };
}
function G_(t, e, n) {
  let i, r;
  var l = this && this.__awaiter || function(d, D, E, F) {
    function C(g) {
      return g instanceof E ? g : new E(function(f) {
        f(g);
      });
    }
    return new (E || (E = Promise))(function(g, f) {
      function m(b) {
        try {
          p(F.next(b));
        } catch (k) {
          f(k);
        }
      }
      function v(b) {
        try {
          p(F.throw(b));
        } catch (k) {
          f(k);
        }
      }
      function p(b) {
        b.done ? g(b.value) : C(b.value).then(m, v);
      }
      p((F = F.apply(d, D || [])).next());
    });
  };
  let { margin: a = !0 } = e;
  const o = mr([0, 0]);
  Ha(t, o, (d) => n(1, i = d));
  const s = mr([0, 0]);
  Ha(t, s, (d) => n(2, r = d));
  let u;
  function c() {
    return l(this, void 0, void 0, function* () {
      yield Promise.all([o.set([125, 140]), s.set([-125, -140])]), yield Promise.all([o.set([-125, 140]), s.set([125, -140])]), yield Promise.all([o.set([-125, 0]), s.set([125, -0])]), yield Promise.all([o.set([125, 0]), s.set([-125, 0])]);
    });
  }
  function _() {
    return l(this, void 0, void 0, function* () {
      yield c(), u || _();
    });
  }
  function h() {
    return l(this, void 0, void 0, function* () {
      yield Promise.all([o.set([125, 0]), s.set([-125, 0])]), _();
    });
  }
  return q_(() => (h(), () => u = !0)), t.$$set = (d) => {
    "margin" in d && n(0, a = d.margin);
  }, [a, i, r, o, s];
}
class z_ extends H_ {
  constructor(e) {
    super(), O_(this, e, G_, U_, M_, { margin: 0 });
  }
}
const {
  SvelteComponent: j_,
  append_hydration: at,
  attr: Le,
  binding_callbacks: Oa,
  check_outros: zi,
  children: ze,
  claim_component: vo,
  claim_element: je,
  claim_space: Fe,
  claim_text: ee,
  create_component: yo,
  create_slot: wo,
  destroy_component: Do,
  destroy_each: Eo,
  detach: H,
  element: Ve,
  empty: Ae,
  ensure_array_like: On,
  get_all_dirty_from_scope: Fo,
  get_slot_changes: ko,
  group_outros: ji,
  init: V_,
  insert_hydration: N,
  mount_component: Ao,
  noop: Vi,
  safe_not_equal: X_,
  set_data: Ce,
  set_style: nt,
  space: ke,
  text: te,
  toggle_class: we,
  transition_in: Ie,
  transition_out: Xe,
  update_slot_base: Co
} = window.__gradio__svelte__internal, { tick: Z_ } = window.__gradio__svelte__internal, { onDestroy: W_ } = window.__gradio__svelte__internal, { createEventDispatcher: Q_ } = window.__gradio__svelte__internal, Y_ = (t) => ({}), Ra = (t) => ({}), J_ = (t) => ({}), Ma = (t) => ({});
function qa(t, e, n) {
  const i = t.slice();
  return i[40] = e[n], i[42] = n, i;
}
function Ua(t, e, n) {
  const i = t.slice();
  return i[40] = e[n], i;
}
function K_(t) {
  let e, n, i, r, l = (
    /*i18n*/
    t[1]("common.error") + ""
  ), a, o, s;
  n = new Af({
    props: {
      Icon: Tf,
      label: (
        /*i18n*/
        t[1]("common.clear")
      ),
      disabled: !1
    }
  }), n.$on(
    "click",
    /*click_handler*/
    t[32]
  );
  const u = (
    /*#slots*/
    t[30].error
  ), c = wo(
    u,
    t,
    /*$$scope*/
    t[29],
    Ra
  );
  return {
    c() {
      e = Ve("div"), yo(n.$$.fragment), i = ke(), r = Ve("span"), a = te(l), o = ke(), c && c.c(), this.h();
    },
    l(_) {
      e = je(_, "DIV", { class: !0 });
      var h = ze(e);
      vo(n.$$.fragment, h), h.forEach(H), i = Fe(_), r = je(_, "SPAN", { class: !0 });
      var d = ze(r);
      a = ee(d, l), d.forEach(H), o = Fe(_), c && c.l(_), this.h();
    },
    h() {
      Le(e, "class", "clear-status svelte-17v219f"), Le(r, "class", "error svelte-17v219f");
    },
    m(_, h) {
      N(_, e, h), Ao(n, e, null), N(_, i, h), N(_, r, h), at(r, a), N(_, o, h), c && c.m(_, h), s = !0;
    },
    p(_, h) {
      const d = {};
      h[0] & /*i18n*/
      2 && (d.label = /*i18n*/
      _[1]("common.clear")), n.$set(d), (!s || h[0] & /*i18n*/
      2) && l !== (l = /*i18n*/
      _[1]("common.error") + "") && Ce(a, l), c && c.p && (!s || h[0] & /*$$scope*/
      536870912) && Co(
        c,
        u,
        _,
        /*$$scope*/
        _[29],
        s ? ko(
          u,
          /*$$scope*/
          _[29],
          h,
          Y_
        ) : Fo(
          /*$$scope*/
          _[29]
        ),
        Ra
      );
    },
    i(_) {
      s || (Ie(n.$$.fragment, _), Ie(c, _), s = !0);
    },
    o(_) {
      Xe(n.$$.fragment, _), Xe(c, _), s = !1;
    },
    d(_) {
      _ && (H(e), H(i), H(r), H(o)), Do(n), c && c.d(_);
    }
  };
}
function ed(t) {
  let e, n, i, r, l, a, o, s, u, c = (
    /*variant*/
    t[8] === "default" && /*show_eta_bar*/
    t[18] && /*show_progress*/
    t[6] === "full" && Ga(t)
  );
  function _(f, m) {
    if (
      /*progress*/
      f[7]
    ) return id;
    if (
      /*queue_position*/
      f[2] !== null && /*queue_size*/
      f[3] !== void 0 && /*queue_position*/
      f[2] >= 0
    ) return nd;
    if (
      /*queue_position*/
      f[2] === 0
    ) return td;
  }
  let h = _(t), d = h && h(t), D = (
    /*timer*/
    t[5] && Va(t)
  );
  const E = [od, ld], F = [];
  function C(f, m) {
    return (
      /*last_progress_level*/
      f[15] != null ? 0 : (
        /*show_progress*/
        f[6] === "full" ? 1 : -1
      )
    );
  }
  ~(l = C(t)) && (a = F[l] = E[l](t));
  let g = !/*timer*/
  t[5] && Ka(t);
  return {
    c() {
      c && c.c(), e = ke(), n = Ve("div"), d && d.c(), i = ke(), D && D.c(), r = ke(), a && a.c(), o = ke(), g && g.c(), s = Ae(), this.h();
    },
    l(f) {
      c && c.l(f), e = Fe(f), n = je(f, "DIV", { class: !0 });
      var m = ze(n);
      d && d.l(m), i = Fe(m), D && D.l(m), m.forEach(H), r = Fe(f), a && a.l(f), o = Fe(f), g && g.l(f), s = Ae(), this.h();
    },
    h() {
      Le(n, "class", "progress-text svelte-17v219f"), we(
        n,
        "meta-text-center",
        /*variant*/
        t[8] === "center"
      ), we(
        n,
        "meta-text",
        /*variant*/
        t[8] === "default"
      );
    },
    m(f, m) {
      c && c.m(f, m), N(f, e, m), N(f, n, m), d && d.m(n, null), at(n, i), D && D.m(n, null), N(f, r, m), ~l && F[l].m(f, m), N(f, o, m), g && g.m(f, m), N(f, s, m), u = !0;
    },
    p(f, m) {
      /*variant*/
      f[8] === "default" && /*show_eta_bar*/
      f[18] && /*show_progress*/
      f[6] === "full" ? c ? c.p(f, m) : (c = Ga(f), c.c(), c.m(e.parentNode, e)) : c && (c.d(1), c = null), h === (h = _(f)) && d ? d.p(f, m) : (d && d.d(1), d = h && h(f), d && (d.c(), d.m(n, i))), /*timer*/
      f[5] ? D ? D.p(f, m) : (D = Va(f), D.c(), D.m(n, null)) : D && (D.d(1), D = null), (!u || m[0] & /*variant*/
      256) && we(
        n,
        "meta-text-center",
        /*variant*/
        f[8] === "center"
      ), (!u || m[0] & /*variant*/
      256) && we(
        n,
        "meta-text",
        /*variant*/
        f[8] === "default"
      );
      let v = l;
      l = C(f), l === v ? ~l && F[l].p(f, m) : (a && (ji(), Xe(F[v], 1, 1, () => {
        F[v] = null;
      }), zi()), ~l ? (a = F[l], a ? a.p(f, m) : (a = F[l] = E[l](f), a.c()), Ie(a, 1), a.m(o.parentNode, o)) : a = null), /*timer*/
      f[5] ? g && (ji(), Xe(g, 1, 1, () => {
        g = null;
      }), zi()) : g ? (g.p(f, m), m[0] & /*timer*/
      32 && Ie(g, 1)) : (g = Ka(f), g.c(), Ie(g, 1), g.m(s.parentNode, s));
    },
    i(f) {
      u || (Ie(a), Ie(g), u = !0);
    },
    o(f) {
      Xe(a), Xe(g), u = !1;
    },
    d(f) {
      f && (H(e), H(n), H(r), H(o), H(s)), c && c.d(f), d && d.d(), D && D.d(), ~l && F[l].d(f), g && g.d(f);
    }
  };
}
function Ga(t) {
  let e, n = `translateX(${/*eta_level*/
  (t[17] || 0) * 100 - 100}%)`;
  return {
    c() {
      e = Ve("div"), this.h();
    },
    l(i) {
      e = je(i, "DIV", { class: !0 }), ze(e).forEach(H), this.h();
    },
    h() {
      Le(e, "class", "eta-bar svelte-17v219f"), nt(e, "transform", n);
    },
    m(i, r) {
      N(i, e, r);
    },
    p(i, r) {
      r[0] & /*eta_level*/
      131072 && n !== (n = `translateX(${/*eta_level*/
      (i[17] || 0) * 100 - 100}%)`) && nt(e, "transform", n);
    },
    d(i) {
      i && H(e);
    }
  };
}
function td(t) {
  let e;
  return {
    c() {
      e = te("processing |");
    },
    l(n) {
      e = ee(n, "processing |");
    },
    m(n, i) {
      N(n, e, i);
    },
    p: Vi,
    d(n) {
      n && H(e);
    }
  };
}
function nd(t) {
  let e, n = (
    /*queue_position*/
    t[2] + 1 + ""
  ), i, r, l, a;
  return {
    c() {
      e = te("queue: "), i = te(n), r = te("/"), l = te(
        /*queue_size*/
        t[3]
      ), a = te(" |");
    },
    l(o) {
      e = ee(o, "queue: "), i = ee(o, n), r = ee(o, "/"), l = ee(
        o,
        /*queue_size*/
        t[3]
      ), a = ee(o, " |");
    },
    m(o, s) {
      N(o, e, s), N(o, i, s), N(o, r, s), N(o, l, s), N(o, a, s);
    },
    p(o, s) {
      s[0] & /*queue_position*/
      4 && n !== (n = /*queue_position*/
      o[2] + 1 + "") && Ce(i, n), s[0] & /*queue_size*/
      8 && Ce(
        l,
        /*queue_size*/
        o[3]
      );
    },
    d(o) {
      o && (H(e), H(i), H(r), H(l), H(a));
    }
  };
}
function id(t) {
  let e, n = On(
    /*progress*/
    t[7]
  ), i = [];
  for (let r = 0; r < n.length; r += 1)
    i[r] = ja(Ua(t, n, r));
  return {
    c() {
      for (let r = 0; r < i.length; r += 1)
        i[r].c();
      e = Ae();
    },
    l(r) {
      for (let l = 0; l < i.length; l += 1)
        i[l].l(r);
      e = Ae();
    },
    m(r, l) {
      for (let a = 0; a < i.length; a += 1)
        i[a] && i[a].m(r, l);
      N(r, e, l);
    },
    p(r, l) {
      if (l[0] & /*progress*/
      128) {
        n = On(
          /*progress*/
          r[7]
        );
        let a;
        for (a = 0; a < n.length; a += 1) {
          const o = Ua(r, n, a);
          i[a] ? i[a].p(o, l) : (i[a] = ja(o), i[a].c(), i[a].m(e.parentNode, e));
        }
        for (; a < i.length; a += 1)
          i[a].d(1);
        i.length = n.length;
      }
    },
    d(r) {
      r && H(e), Eo(i, r);
    }
  };
}
function za(t) {
  let e, n = (
    /*p*/
    t[40].unit + ""
  ), i, r, l = " ", a;
  function o(c, _) {
    return (
      /*p*/
      c[40].length != null ? ad : rd
    );
  }
  let s = o(t), u = s(t);
  return {
    c() {
      u.c(), e = ke(), i = te(n), r = te(" | "), a = te(l);
    },
    l(c) {
      u.l(c), e = Fe(c), i = ee(c, n), r = ee(c, " | "), a = ee(c, l);
    },
    m(c, _) {
      u.m(c, _), N(c, e, _), N(c, i, _), N(c, r, _), N(c, a, _);
    },
    p(c, _) {
      s === (s = o(c)) && u ? u.p(c, _) : (u.d(1), u = s(c), u && (u.c(), u.m(e.parentNode, e))), _[0] & /*progress*/
      128 && n !== (n = /*p*/
      c[40].unit + "") && Ce(i, n);
    },
    d(c) {
      c && (H(e), H(i), H(r), H(a)), u.d(c);
    }
  };
}
function rd(t) {
  let e = wt(
    /*p*/
    t[40].index || 0
  ) + "", n;
  return {
    c() {
      n = te(e);
    },
    l(i) {
      n = ee(i, e);
    },
    m(i, r) {
      N(i, n, r);
    },
    p(i, r) {
      r[0] & /*progress*/
      128 && e !== (e = wt(
        /*p*/
        i[40].index || 0
      ) + "") && Ce(n, e);
    },
    d(i) {
      i && H(n);
    }
  };
}
function ad(t) {
  let e = wt(
    /*p*/
    t[40].index || 0
  ) + "", n, i, r = wt(
    /*p*/
    t[40].length
  ) + "", l;
  return {
    c() {
      n = te(e), i = te("/"), l = te(r);
    },
    l(a) {
      n = ee(a, e), i = ee(a, "/"), l = ee(a, r);
    },
    m(a, o) {
      N(a, n, o), N(a, i, o), N(a, l, o);
    },
    p(a, o) {
      o[0] & /*progress*/
      128 && e !== (e = wt(
        /*p*/
        a[40].index || 0
      ) + "") && Ce(n, e), o[0] & /*progress*/
      128 && r !== (r = wt(
        /*p*/
        a[40].length
      ) + "") && Ce(l, r);
    },
    d(a) {
      a && (H(n), H(i), H(l));
    }
  };
}
function ja(t) {
  let e, n = (
    /*p*/
    t[40].index != null && za(t)
  );
  return {
    c() {
      n && n.c(), e = Ae();
    },
    l(i) {
      n && n.l(i), e = Ae();
    },
    m(i, r) {
      n && n.m(i, r), N(i, e, r);
    },
    p(i, r) {
      /*p*/
      i[40].index != null ? n ? n.p(i, r) : (n = za(i), n.c(), n.m(e.parentNode, e)) : n && (n.d(1), n = null);
    },
    d(i) {
      i && H(e), n && n.d(i);
    }
  };
}
function Va(t) {
  let e, n = (
    /*eta*/
    t[0] ? `/${/*formatted_eta*/
    t[19]}` : ""
  ), i, r;
  return {
    c() {
      e = te(
        /*formatted_timer*/
        t[20]
      ), i = te(n), r = te("s");
    },
    l(l) {
      e = ee(
        l,
        /*formatted_timer*/
        t[20]
      ), i = ee(l, n), r = ee(l, "s");
    },
    m(l, a) {
      N(l, e, a), N(l, i, a), N(l, r, a);
    },
    p(l, a) {
      a[0] & /*formatted_timer*/
      1048576 && Ce(
        e,
        /*formatted_timer*/
        l[20]
      ), a[0] & /*eta, formatted_eta*/
      524289 && n !== (n = /*eta*/
      l[0] ? `/${/*formatted_eta*/
      l[19]}` : "") && Ce(i, n);
    },
    d(l) {
      l && (H(e), H(i), H(r));
    }
  };
}
function ld(t) {
  let e, n;
  return e = new z_({
    props: { margin: (
      /*variant*/
      t[8] === "default"
    ) }
  }), {
    c() {
      yo(e.$$.fragment);
    },
    l(i) {
      vo(e.$$.fragment, i);
    },
    m(i, r) {
      Ao(e, i, r), n = !0;
    },
    p(i, r) {
      const l = {};
      r[0] & /*variant*/
      256 && (l.margin = /*variant*/
      i[8] === "default"), e.$set(l);
    },
    i(i) {
      n || (Ie(e.$$.fragment, i), n = !0);
    },
    o(i) {
      Xe(e.$$.fragment, i), n = !1;
    },
    d(i) {
      Do(e, i);
    }
  };
}
function od(t) {
  let e, n, i, r, l, a = `${/*last_progress_level*/
  t[15] * 100}%`, o = (
    /*progress*/
    t[7] != null && Xa(t)
  );
  return {
    c() {
      e = Ve("div"), n = Ve("div"), o && o.c(), i = ke(), r = Ve("div"), l = Ve("div"), this.h();
    },
    l(s) {
      e = je(s, "DIV", { class: !0 });
      var u = ze(e);
      n = je(u, "DIV", { class: !0 });
      var c = ze(n);
      o && o.l(c), c.forEach(H), i = Fe(u), r = je(u, "DIV", { class: !0 });
      var _ = ze(r);
      l = je(_, "DIV", { class: !0 }), ze(l).forEach(H), _.forEach(H), u.forEach(H), this.h();
    },
    h() {
      Le(n, "class", "progress-level-inner svelte-17v219f"), Le(l, "class", "progress-bar svelte-17v219f"), nt(l, "width", a), Le(r, "class", "progress-bar-wrap svelte-17v219f"), Le(e, "class", "progress-level svelte-17v219f");
    },
    m(s, u) {
      N(s, e, u), at(e, n), o && o.m(n, null), at(e, i), at(e, r), at(r, l), t[31](l);
    },
    p(s, u) {
      /*progress*/
      s[7] != null ? o ? o.p(s, u) : (o = Xa(s), o.c(), o.m(n, null)) : o && (o.d(1), o = null), u[0] & /*last_progress_level*/
      32768 && a !== (a = `${/*last_progress_level*/
      s[15] * 100}%`) && nt(l, "width", a);
    },
    i: Vi,
    o: Vi,
    d(s) {
      s && H(e), o && o.d(), t[31](null);
    }
  };
}
function Xa(t) {
  let e, n = On(
    /*progress*/
    t[7]
  ), i = [];
  for (let r = 0; r < n.length; r += 1)
    i[r] = Ja(qa(t, n, r));
  return {
    c() {
      for (let r = 0; r < i.length; r += 1)
        i[r].c();
      e = Ae();
    },
    l(r) {
      for (let l = 0; l < i.length; l += 1)
        i[l].l(r);
      e = Ae();
    },
    m(r, l) {
      for (let a = 0; a < i.length; a += 1)
        i[a] && i[a].m(r, l);
      N(r, e, l);
    },
    p(r, l) {
      if (l[0] & /*progress_level, progress*/
      16512) {
        n = On(
          /*progress*/
          r[7]
        );
        let a;
        for (a = 0; a < n.length; a += 1) {
          const o = qa(r, n, a);
          i[a] ? i[a].p(o, l) : (i[a] = Ja(o), i[a].c(), i[a].m(e.parentNode, e));
        }
        for (; a < i.length; a += 1)
          i[a].d(1);
        i.length = n.length;
      }
    },
    d(r) {
      r && H(e), Eo(i, r);
    }
  };
}
function Za(t) {
  let e, n, i, r, l = (
    /*i*/
    t[42] !== 0 && sd()
  ), a = (
    /*p*/
    t[40].desc != null && Wa(t)
  ), o = (
    /*p*/
    t[40].desc != null && /*progress_level*/
    t[14] && /*progress_level*/
    t[14][
      /*i*/
      t[42]
    ] != null && Qa()
  ), s = (
    /*progress_level*/
    t[14] != null && Ya(t)
  );
  return {
    c() {
      l && l.c(), e = ke(), a && a.c(), n = ke(), o && o.c(), i = ke(), s && s.c(), r = Ae();
    },
    l(u) {
      l && l.l(u), e = Fe(u), a && a.l(u), n = Fe(u), o && o.l(u), i = Fe(u), s && s.l(u), r = Ae();
    },
    m(u, c) {
      l && l.m(u, c), N(u, e, c), a && a.m(u, c), N(u, n, c), o && o.m(u, c), N(u, i, c), s && s.m(u, c), N(u, r, c);
    },
    p(u, c) {
      /*p*/
      u[40].desc != null ? a ? a.p(u, c) : (a = Wa(u), a.c(), a.m(n.parentNode, n)) : a && (a.d(1), a = null), /*p*/
      u[40].desc != null && /*progress_level*/
      u[14] && /*progress_level*/
      u[14][
        /*i*/
        u[42]
      ] != null ? o || (o = Qa(), o.c(), o.m(i.parentNode, i)) : o && (o.d(1), o = null), /*progress_level*/
      u[14] != null ? s ? s.p(u, c) : (s = Ya(u), s.c(), s.m(r.parentNode, r)) : s && (s.d(1), s = null);
    },
    d(u) {
      u && (H(e), H(n), H(i), H(r)), l && l.d(u), a && a.d(u), o && o.d(u), s && s.d(u);
    }
  };
}
function sd(t) {
  let e;
  return {
    c() {
      e = te(" /");
    },
    l(n) {
      e = ee(n, " /");
    },
    m(n, i) {
      N(n, e, i);
    },
    d(n) {
      n && H(e);
    }
  };
}
function Wa(t) {
  let e = (
    /*p*/
    t[40].desc + ""
  ), n;
  return {
    c() {
      n = te(e);
    },
    l(i) {
      n = ee(i, e);
    },
    m(i, r) {
      N(i, n, r);
    },
    p(i, r) {
      r[0] & /*progress*/
      128 && e !== (e = /*p*/
      i[40].desc + "") && Ce(n, e);
    },
    d(i) {
      i && H(n);
    }
  };
}
function Qa(t) {
  let e;
  return {
    c() {
      e = te("-");
    },
    l(n) {
      e = ee(n, "-");
    },
    m(n, i) {
      N(n, e, i);
    },
    d(n) {
      n && H(e);
    }
  };
}
function Ya(t) {
  let e = (100 * /*progress_level*/
  (t[14][
    /*i*/
    t[42]
  ] || 0)).toFixed(1) + "", n, i;
  return {
    c() {
      n = te(e), i = te("%");
    },
    l(r) {
      n = ee(r, e), i = ee(r, "%");
    },
    m(r, l) {
      N(r, n, l), N(r, i, l);
    },
    p(r, l) {
      l[0] & /*progress_level*/
      16384 && e !== (e = (100 * /*progress_level*/
      (r[14][
        /*i*/
        r[42]
      ] || 0)).toFixed(1) + "") && Ce(n, e);
    },
    d(r) {
      r && (H(n), H(i));
    }
  };
}
function Ja(t) {
  let e, n = (
    /*p*/
    (t[40].desc != null || /*progress_level*/
    t[14] && /*progress_level*/
    t[14][
      /*i*/
      t[42]
    ] != null) && Za(t)
  );
  return {
    c() {
      n && n.c(), e = Ae();
    },
    l(i) {
      n && n.l(i), e = Ae();
    },
    m(i, r) {
      n && n.m(i, r), N(i, e, r);
    },
    p(i, r) {
      /*p*/
      i[40].desc != null || /*progress_level*/
      i[14] && /*progress_level*/
      i[14][
        /*i*/
        i[42]
      ] != null ? n ? n.p(i, r) : (n = Za(i), n.c(), n.m(e.parentNode, e)) : n && (n.d(1), n = null);
    },
    d(i) {
      i && H(e), n && n.d(i);
    }
  };
}
function Ka(t) {
  let e, n, i, r;
  const l = (
    /*#slots*/
    t[30]["additional-loading-text"]
  ), a = wo(
    l,
    t,
    /*$$scope*/
    t[29],
    Ma
  );
  return {
    c() {
      e = Ve("p"), n = te(
        /*loading_text*/
        t[9]
      ), i = ke(), a && a.c(), this.h();
    },
    l(o) {
      e = je(o, "P", { class: !0 });
      var s = ze(e);
      n = ee(
        s,
        /*loading_text*/
        t[9]
      ), s.forEach(H), i = Fe(o), a && a.l(o), this.h();
    },
    h() {
      Le(e, "class", "loading svelte-17v219f");
    },
    m(o, s) {
      N(o, e, s), at(e, n), N(o, i, s), a && a.m(o, s), r = !0;
    },
    p(o, s) {
      (!r || s[0] & /*loading_text*/
      512) && Ce(
        n,
        /*loading_text*/
        o[9]
      ), a && a.p && (!r || s[0] & /*$$scope*/
      536870912) && Co(
        a,
        l,
        o,
        /*$$scope*/
        o[29],
        r ? ko(
          l,
          /*$$scope*/
          o[29],
          s,
          J_
        ) : Fo(
          /*$$scope*/
          o[29]
        ),
        Ma
      );
    },
    i(o) {
      r || (Ie(a, o), r = !0);
    },
    o(o) {
      Xe(a, o), r = !1;
    },
    d(o) {
      o && (H(e), H(i)), a && a.d(o);
    }
  };
}
function ud(t) {
  let e, n, i, r, l;
  const a = [ed, K_], o = [];
  function s(u, c) {
    return (
      /*status*/
      u[4] === "pending" ? 0 : (
        /*status*/
        u[4] === "error" ? 1 : -1
      )
    );
  }
  return ~(n = s(t)) && (i = o[n] = a[n](t)), {
    c() {
      e = Ve("div"), i && i.c(), this.h();
    },
    l(u) {
      e = je(u, "DIV", { class: !0 });
      var c = ze(e);
      i && i.l(c), c.forEach(H), this.h();
    },
    h() {
      Le(e, "class", r = "wrap " + /*variant*/
      t[8] + " " + /*show_progress*/
      t[6] + " svelte-17v219f"), we(e, "hide", !/*status*/
      t[4] || /*status*/
      t[4] === "complete" || /*show_progress*/
      t[6] === "hidden" || /*status*/
      t[4] == "streaming"), we(
        e,
        "translucent",
        /*variant*/
        t[8] === "center" && /*status*/
        (t[4] === "pending" || /*status*/
        t[4] === "error") || /*translucent*/
        t[11] || /*show_progress*/
        t[6] === "minimal"
      ), we(
        e,
        "generating",
        /*status*/
        t[4] === "generating" && /*show_progress*/
        t[6] === "full"
      ), we(
        e,
        "border",
        /*border*/
        t[12]
      ), nt(
        e,
        "position",
        /*absolute*/
        t[10] ? "absolute" : "static"
      ), nt(
        e,
        "padding",
        /*absolute*/
        t[10] ? "0" : "var(--size-8) 0"
      );
    },
    m(u, c) {
      N(u, e, c), ~n && o[n].m(e, null), t[33](e), l = !0;
    },
    p(u, c) {
      let _ = n;
      n = s(u), n === _ ? ~n && o[n].p(u, c) : (i && (ji(), Xe(o[_], 1, 1, () => {
        o[_] = null;
      }), zi()), ~n ? (i = o[n], i ? i.p(u, c) : (i = o[n] = a[n](u), i.c()), Ie(i, 1), i.m(e, null)) : i = null), (!l || c[0] & /*variant, show_progress*/
      320 && r !== (r = "wrap " + /*variant*/
      u[8] + " " + /*show_progress*/
      u[6] + " svelte-17v219f")) && Le(e, "class", r), (!l || c[0] & /*variant, show_progress, status, show_progress*/
      336) && we(e, "hide", !/*status*/
      u[4] || /*status*/
      u[4] === "complete" || /*show_progress*/
      u[6] === "hidden" || /*status*/
      u[4] == "streaming"), (!l || c[0] & /*variant, show_progress, variant, status, translucent, show_progress*/
      2384) && we(
        e,
        "translucent",
        /*variant*/
        u[8] === "center" && /*status*/
        (u[4] === "pending" || /*status*/
        u[4] === "error") || /*translucent*/
        u[11] || /*show_progress*/
        u[6] === "minimal"
      ), (!l || c[0] & /*variant, show_progress, status, show_progress*/
      336) && we(
        e,
        "generating",
        /*status*/
        u[4] === "generating" && /*show_progress*/
        u[6] === "full"
      ), (!l || c[0] & /*variant, show_progress, border*/
      4416) && we(
        e,
        "border",
        /*border*/
        u[12]
      ), c[0] & /*absolute*/
      1024 && nt(
        e,
        "position",
        /*absolute*/
        u[10] ? "absolute" : "static"
      ), c[0] & /*absolute*/
      1024 && nt(
        e,
        "padding",
        /*absolute*/
        u[10] ? "0" : "var(--size-8) 0"
      );
    },
    i(u) {
      l || (Ie(i), l = !0);
    },
    o(u) {
      Xe(i), l = !1;
    },
    d(u) {
      u && H(e), ~n && o[n].d(), t[33](null);
    }
  };
}
var cd = function(t, e, n, i) {
  function r(l) {
    return l instanceof n ? l : new n(function(a) {
      a(l);
    });
  }
  return new (n || (n = Promise))(function(l, a) {
    function o(c) {
      try {
        u(i.next(c));
      } catch (_) {
        a(_);
      }
    }
    function s(c) {
      try {
        u(i.throw(c));
      } catch (_) {
        a(_);
      }
    }
    function u(c) {
      c.done ? l(c.value) : r(c.value).then(o, s);
    }
    u((i = i.apply(t, e || [])).next());
  });
};
let wn = [], vi = !1;
const hd = typeof window < "u", So = hd ? window.requestAnimationFrame : (t) => {
};
function fd(t) {
  return cd(this, arguments, void 0, function* (e, n = !0) {
    if (!(window.__gradio_mode__ === "website" || window.__gradio_mode__ !== "app" && n !== !0)) {
      if (wn.push(e), !vi) vi = !0;
      else return;
      yield Z_(), So(() => {
        let i = [0, 0];
        for (let r = 0; r < wn.length; r++) {
          const a = wn[r].getBoundingClientRect();
          (r === 0 || a.top + window.scrollY <= i[0]) && (i[0] = a.top + window.scrollY, i[1] = r);
        }
        window.scrollTo({ top: i[0] - 20, behavior: "smooth" }), vi = !1, wn = [];
      });
    }
  });
}
function _d(t, e, n) {
  let i, { $$slots: r = {}, $$scope: l } = e;
  const a = Q_();
  let { i18n: o } = e, { eta: s = null } = e, { queue_position: u } = e, { queue_size: c } = e, { status: _ } = e, { scroll_to_output: h = !1 } = e, { timer: d = !0 } = e, { show_progress: D = "full" } = e, { message: E = null } = e, { progress: F = null } = e, { variant: C = "default" } = e, { loading_text: g = "Loading..." } = e, { absolute: f = !0 } = e, { translucent: m = !1 } = e, { border: v = !1 } = e, { autoscroll: p } = e, b, k = !1, y = 0, w = 0, A = null, B = null, q = 0, P = null, U, O = null, W = !0;
  const j = () => {
    n(0, s = n(27, A = n(19, $ = null))), n(25, y = performance.now()), n(26, w = 0), k = !0, T();
  };
  function T() {
    So(() => {
      n(26, w = (performance.now() - y) / 1e3), k && T();
    });
  }
  function ne() {
    n(26, w = 0), n(0, s = n(27, A = n(19, $ = null))), k && (k = !1);
  }
  W_(() => {
    k && ne();
  });
  let $ = null;
  function I(L) {
    Oa[L ? "unshift" : "push"](() => {
      O = L, n(16, O), n(7, F), n(14, P), n(15, U);
    });
  }
  const Se = () => {
    a("clear_status");
  };
  function x(L) {
    Oa[L ? "unshift" : "push"](() => {
      b = L, n(13, b);
    });
  }
  return t.$$set = (L) => {
    "i18n" in L && n(1, o = L.i18n), "eta" in L && n(0, s = L.eta), "queue_position" in L && n(2, u = L.queue_position), "queue_size" in L && n(3, c = L.queue_size), "status" in L && n(4, _ = L.status), "scroll_to_output" in L && n(22, h = L.scroll_to_output), "timer" in L && n(5, d = L.timer), "show_progress" in L && n(6, D = L.show_progress), "message" in L && n(23, E = L.message), "progress" in L && n(7, F = L.progress), "variant" in L && n(8, C = L.variant), "loading_text" in L && n(9, g = L.loading_text), "absolute" in L && n(10, f = L.absolute), "translucent" in L && n(11, m = L.translucent), "border" in L && n(12, v = L.border), "autoscroll" in L && n(24, p = L.autoscroll), "$$scope" in L && n(29, l = L.$$scope);
  }, t.$$.update = () => {
    t.$$.dirty[0] & /*eta, old_eta, timer_start, eta_from_start*/
    436207617 && (s === null && n(0, s = A), s != null && A !== s && (n(28, B = (performance.now() - y) / 1e3 + s), n(19, $ = B.toFixed(1)), n(27, A = s))), t.$$.dirty[0] & /*eta_from_start, timer_diff*/
    335544320 && n(17, q = B === null || B <= 0 || !w ? null : Math.min(w / B, 1)), t.$$.dirty[0] & /*progress*/
    128 && F != null && n(18, W = !1), t.$$.dirty[0] & /*progress, progress_level, progress_bar, last_progress_level*/
    114816 && (F != null ? n(14, P = F.map((L) => {
      if (L.index != null && L.length != null)
        return L.index / L.length;
      if (L.progress != null)
        return L.progress;
    })) : n(14, P = null), P ? (n(15, U = P[P.length - 1]), O && (U === 0 ? n(16, O.style.transition = "0", O) : n(16, O.style.transition = "150ms", O))) : n(15, U = void 0)), t.$$.dirty[0] & /*status*/
    16 && (_ === "pending" ? j() : ne()), t.$$.dirty[0] & /*el, scroll_to_output, status, autoscroll*/
    20979728 && b && h && (_ === "pending" || _ === "complete") && fd(b, p), t.$$.dirty[0] & /*status, message*/
    8388624, t.$$.dirty[0] & /*timer_diff*/
    67108864 && n(20, i = w.toFixed(1));
  }, [
    s,
    o,
    u,
    c,
    _,
    d,
    D,
    F,
    C,
    g,
    f,
    m,
    v,
    b,
    P,
    U,
    O,
    q,
    W,
    $,
    i,
    a,
    h,
    E,
    p,
    y,
    w,
    A,
    B,
    l,
    r,
    I,
    Se,
    x
  ];
}
class dd extends j_ {
  constructor(e) {
    super(), V_(
      this,
      e,
      _d,
      ud,
      X_,
      {
        i18n: 1,
        eta: 0,
        queue_position: 2,
        queue_size: 3,
        status: 4,
        scroll_to_output: 22,
        timer: 5,
        show_progress: 6,
        message: 23,
        progress: 7,
        variant: 8,
        loading_text: 9,
        absolute: 10,
        translucent: 11,
        border: 12,
        autoscroll: 24
      },
      null,
      [-1, -1]
    );
  }
}
const {
  HtmlTagHydration: GS,
  SvelteComponent: zS,
  add_render_callback: jS,
  append_hydration: VS,
  attr: XS,
  bubble: ZS,
  check_outros: WS,
  children: QS,
  claim_component: YS,
  claim_element: JS,
  claim_html_tag: KS,
  claim_space: e4,
  claim_text: t4,
  create_component: n4,
  create_in_transition: i4,
  create_out_transition: r4,
  destroy_component: a4,
  detach: l4,
  element: o4,
  get_svelte_dataset: s4,
  group_outros: u4,
  init: c4,
  insert_hydration: h4,
  listen: f4,
  mount_component: _4,
  run_all: d4,
  safe_not_equal: m4,
  set_data: p4,
  space: g4,
  stop_propagation: b4,
  text: v4,
  toggle_class: y4,
  transition_in: w4,
  transition_out: D4
} = window.__gradio__svelte__internal, { createEventDispatcher: E4, onMount: F4 } = window.__gradio__svelte__internal, {
  SvelteComponent: k4,
  append_hydration: A4,
  attr: C4,
  bubble: S4,
  check_outros: $4,
  children: x4,
  claim_component: B4,
  claim_element: T4,
  claim_space: I4,
  create_animation: L4,
  create_component: H4,
  destroy_component: P4,
  detach: N4,
  element: O4,
  ensure_array_like: R4,
  fix_and_outro_and_destroy_block: M4,
  fix_position: q4,
  group_outros: U4,
  init: G4,
  insert_hydration: z4,
  mount_component: j4,
  noop: V4,
  safe_not_equal: X4,
  set_style: Z4,
  space: W4,
  transition_in: Q4,
  transition_out: Y4,
  update_keyed_each: J4
} = window.__gradio__svelte__internal, {
  SvelteComponent: K4,
  attr: e5,
  children: t5,
  claim_element: n5,
  detach: i5,
  element: r5,
  empty: a5,
  init: l5,
  insert_hydration: o5,
  noop: s5,
  safe_not_equal: u5,
  set_style: c5
} = window.__gradio__svelte__internal, {
  SvelteComponent: md,
  append_hydration: pd,
  attr: gd,
  children: bd,
  claim_element: vd,
  claim_text: yd,
  detach: el,
  element: wd,
  init: Dd,
  insert_hydration: Ed,
  noop: tl,
  safe_not_equal: Fd,
  text: kd,
  toggle_class: gt
} = window.__gradio__svelte__internal;
function Ad(t) {
  let e, n;
  return {
    c() {
      e = wd("div"), n = kd(
        /*names_string*/
        t[2]
      ), this.h();
    },
    l(i) {
      e = vd(i, "DIV", { class: !0 });
      var r = bd(e);
      n = yd(
        r,
        /*names_string*/
        t[2]
      ), r.forEach(el), this.h();
    },
    h() {
      gd(e, "class", "svelte-1gecy8w"), gt(
        e,
        "table",
        /*type*/
        t[0] === "table"
      ), gt(
        e,
        "gallery",
        /*type*/
        t[0] === "gallery"
      ), gt(
        e,
        "selected",
        /*selected*/
        t[1]
      );
    },
    m(i, r) {
      Ed(i, e, r), pd(e, n);
    },
    p(i, [r]) {
      r & /*type*/
      1 && gt(
        e,
        "table",
        /*type*/
        i[0] === "table"
      ), r & /*type*/
      1 && gt(
        e,
        "gallery",
        /*type*/
        i[0] === "gallery"
      ), r & /*selected*/
      2 && gt(
        e,
        "selected",
        /*selected*/
        i[1]
      );
    },
    i: tl,
    o: tl,
    d(i) {
      i && el(e);
    }
  };
}
function Cd(t, e, n) {
  let { value: i } = e, { type: r } = e, { selected: l = !1 } = e, { choices: a } = e, u = (i ? Array.isArray(i) ? i : [i] : []).map((c) => {
    var _;
    return (_ = a.find((h) => h[1] === c)) === null || _ === void 0 ? void 0 : _[0];
  }).filter((c) => c !== void 0).join(", ");
  return t.$$set = (c) => {
    "value" in c && n(3, i = c.value), "type" in c && n(0, r = c.type), "selected" in c && n(1, l = c.selected), "choices" in c && n(4, a = c.choices);
  }, [r, l, u, i, a];
}
class h5 extends md {
  constructor(e) {
    super(), Dd(this, e, Cd, Ad, Fd, {
      value: 3,
      type: 0,
      selected: 1,
      choices: 4
    });
  }
}
const {
  SvelteComponent: Sd,
  add_flush_callback: Rn,
  assign: $d,
  bind: Mn,
  binding_callbacks: qn,
  check_outros: xd,
  claim_component: Xn,
  claim_space: Bd,
  create_component: Zn,
  destroy_component: Wn,
  detach: nl,
  empty: il,
  get_spread_object: Td,
  get_spread_update: Id,
  group_outros: Ld,
  init: Hd,
  insert_hydration: rl,
  mount_component: Qn,
  safe_not_equal: Pd,
  space: Nd,
  transition_in: Et,
  transition_out: Ft
} = window.__gradio__svelte__internal;
function Od(t) {
  let e, n, i, r;
  function l(s) {
    t[29](s);
  }
  function a(s) {
    t[30](s);
  }
  let o = {
    choices: (
      /*choices*/
      t[10]
    ),
    label: (
      /*label*/
      t[2]
    ),
    info: (
      /*info*/
      t[3]
    ),
    help: (
      /*help*/
      t[4]
    ),
    show_label: (
      /*show_label*/
      t[11]
    ),
    filterable: (
      /*filterable*/
      t[12]
    ),
    allow_custom_value: (
      /*allow_custom_value*/
      t[17]
    ),
    container: (
      /*container*/
      t[13]
    ),
    disabled: !/*interactive*/
    t[19]
  };
  return (
    /*value*/
    t[0] !== void 0 && (o.value = /*value*/
    t[0]), /*value_is_output*/
    t[1] !== void 0 && (o.value_is_output = /*value_is_output*/
    t[1]), e = new L_({ props: o }), qn.push(() => Mn(e, "value", l)), qn.push(() => Mn(e, "value_is_output", a)), e.$on(
      "change",
      /*change_handler_1*/
      t[31]
    ), e.$on(
      "input",
      /*input_handler_1*/
      t[32]
    ), e.$on(
      "select",
      /*select_handler_1*/
      t[33]
    ), e.$on(
      "blur",
      /*blur_handler_1*/
      t[34]
    ), e.$on(
      "focus",
      /*focus_handler_1*/
      t[35]
    ), e.$on(
      "key_up",
      /*key_up_handler_1*/
      t[36]
    ), {
      c() {
        Zn(e.$$.fragment);
      },
      l(s) {
        Xn(e.$$.fragment, s);
      },
      m(s, u) {
        Qn(e, s, u), r = !0;
      },
      p(s, u) {
        const c = {};
        u[0] & /*choices*/
        1024 && (c.choices = /*choices*/
        s[10]), u[0] & /*label*/
        4 && (c.label = /*label*/
        s[2]), u[0] & /*info*/
        8 && (c.info = /*info*/
        s[3]), u[0] & /*help*/
        16 && (c.help = /*help*/
        s[4]), u[0] & /*show_label*/
        2048 && (c.show_label = /*show_label*/
        s[11]), u[0] & /*filterable*/
        4096 && (c.filterable = /*filterable*/
        s[12]), u[0] & /*allow_custom_value*/
        131072 && (c.allow_custom_value = /*allow_custom_value*/
        s[17]), u[0] & /*container*/
        8192 && (c.container = /*container*/
        s[13]), u[0] & /*interactive*/
        524288 && (c.disabled = !/*interactive*/
        s[19]), !n && u[0] & /*value*/
        1 && (n = !0, c.value = /*value*/
        s[0], Rn(() => n = !1)), !i && u[0] & /*value_is_output*/
        2 && (i = !0, c.value_is_output = /*value_is_output*/
        s[1], Rn(() => i = !1)), e.$set(c);
      },
      i(s) {
        r || (Et(e.$$.fragment, s), r = !0);
      },
      o(s) {
        Ft(e.$$.fragment, s), r = !1;
      },
      d(s) {
        Wn(e, s);
      }
    }
  );
}
function Rd(t) {
  let e, n, i, r;
  function l(s) {
    t[21](s);
  }
  function a(s) {
    t[22](s);
  }
  let o = {
    choices: (
      /*choices*/
      t[10]
    ),
    max_choices: (
      /*max_choices*/
      t[9]
    ),
    label: (
      /*label*/
      t[2]
    ),
    info: (
      /*info*/
      t[3]
    ),
    help: (
      /*help*/
      t[4]
    ),
    show_label: (
      /*show_label*/
      t[11]
    ),
    allow_custom_value: (
      /*allow_custom_value*/
      t[17]
    ),
    filterable: (
      /*filterable*/
      t[12]
    ),
    container: (
      /*container*/
      t[13]
    ),
    i18n: (
      /*gradio*/
      t[18].i18n
    ),
    disabled: !/*interactive*/
    t[19]
  };
  return (
    /*value*/
    t[0] !== void 0 && (o.value = /*value*/
    t[0]), /*value_is_output*/
    t[1] !== void 0 && (o.value_is_output = /*value_is_output*/
    t[1]), e = new y_({ props: o }), qn.push(() => Mn(e, "value", l)), qn.push(() => Mn(e, "value_is_output", a)), e.$on(
      "change",
      /*change_handler*/
      t[23]
    ), e.$on(
      "input",
      /*input_handler*/
      t[24]
    ), e.$on(
      "select",
      /*select_handler*/
      t[25]
    ), e.$on(
      "blur",
      /*blur_handler*/
      t[26]
    ), e.$on(
      "focus",
      /*focus_handler*/
      t[27]
    ), e.$on(
      "key_up",
      /*key_up_handler*/
      t[28]
    ), {
      c() {
        Zn(e.$$.fragment);
      },
      l(s) {
        Xn(e.$$.fragment, s);
      },
      m(s, u) {
        Qn(e, s, u), r = !0;
      },
      p(s, u) {
        const c = {};
        u[0] & /*choices*/
        1024 && (c.choices = /*choices*/
        s[10]), u[0] & /*max_choices*/
        512 && (c.max_choices = /*max_choices*/
        s[9]), u[0] & /*label*/
        4 && (c.label = /*label*/
        s[2]), u[0] & /*info*/
        8 && (c.info = /*info*/
        s[3]), u[0] & /*help*/
        16 && (c.help = /*help*/
        s[4]), u[0] & /*show_label*/
        2048 && (c.show_label = /*show_label*/
        s[11]), u[0] & /*allow_custom_value*/
        131072 && (c.allow_custom_value = /*allow_custom_value*/
        s[17]), u[0] & /*filterable*/
        4096 && (c.filterable = /*filterable*/
        s[12]), u[0] & /*container*/
        8192 && (c.container = /*container*/
        s[13]), u[0] & /*gradio*/
        262144 && (c.i18n = /*gradio*/
        s[18].i18n), u[0] & /*interactive*/
        524288 && (c.disabled = !/*interactive*/
        s[19]), !n && u[0] & /*value*/
        1 && (n = !0, c.value = /*value*/
        s[0], Rn(() => n = !1)), !i && u[0] & /*value_is_output*/
        2 && (i = !0, c.value_is_output = /*value_is_output*/
        s[1], Rn(() => i = !1)), e.$set(c);
      },
      i(s) {
        r || (Et(e.$$.fragment, s), r = !0);
      },
      o(s) {
        Ft(e.$$.fragment, s), r = !1;
      },
      d(s) {
        Wn(e, s);
      }
    }
  );
}
function Md(t) {
  let e, n, i, r, l, a;
  const o = [
    {
      autoscroll: (
        /*gradio*/
        t[18].autoscroll
      )
    },
    { i18n: (
      /*gradio*/
      t[18].i18n
    ) },
    /*loading_status*/
    t[16]
  ];
  let s = {};
  for (let h = 0; h < o.length; h += 1)
    s = $d(s, o[h]);
  e = new dd({ props: s }), e.$on(
    "clear_status",
    /*clear_status_handler*/
    t[20]
  );
  const u = [Rd, Od], c = [];
  function _(h, d) {
    return (
      /*multiselect*/
      h[8] ? 0 : 1
    );
  }
  return i = _(t), r = c[i] = u[i](t), {
    c() {
      Zn(e.$$.fragment), n = Nd(), r.c(), l = il();
    },
    l(h) {
      Xn(e.$$.fragment, h), n = Bd(h), r.l(h), l = il();
    },
    m(h, d) {
      Qn(e, h, d), rl(h, n, d), c[i].m(h, d), rl(h, l, d), a = !0;
    },
    p(h, d) {
      const D = d[0] & /*gradio, loading_status*/
      327680 ? Id(o, [
        d[0] & /*gradio*/
        262144 && {
          autoscroll: (
            /*gradio*/
            h[18].autoscroll
          )
        },
        d[0] & /*gradio*/
        262144 && { i18n: (
          /*gradio*/
          h[18].i18n
        ) },
        d[0] & /*loading_status*/
        65536 && Td(
          /*loading_status*/
          h[16]
        )
      ]) : {};
      e.$set(D);
      let E = i;
      i = _(h), i === E ? c[i].p(h, d) : (Ld(), Ft(c[E], 1, 1, () => {
        c[E] = null;
      }), xd(), r = c[i], r ? r.p(h, d) : (r = c[i] = u[i](h), r.c()), Et(r, 1), r.m(l.parentNode, l));
    },
    i(h) {
      a || (Et(e.$$.fragment, h), Et(r), a = !0);
    },
    o(h) {
      Ft(e.$$.fragment, h), Ft(r), a = !1;
    },
    d(h) {
      h && (nl(n), nl(l)), Wn(e, h), c[i].d(h);
    }
  };
}
function qd(t) {
  let e, n;
  return e = new Pu({
    props: {
      visible: (
        /*visible*/
        t[7]
      ),
      elem_id: (
        /*elem_id*/
        t[5]
      ),
      elem_classes: (
        /*elem_classes*/
        t[6]
      ),
      padding: (
        /*container*/
        t[13]
      ),
      allow_overflow: !1,
      scale: (
        /*scale*/
        t[14]
      ),
      min_width: (
        /*min_width*/
        t[15]
      ),
      $$slots: { default: [Md] },
      $$scope: { ctx: t }
    }
  }), {
    c() {
      Zn(e.$$.fragment);
    },
    l(i) {
      Xn(e.$$.fragment, i);
    },
    m(i, r) {
      Qn(e, i, r), n = !0;
    },
    p(i, r) {
      const l = {};
      r[0] & /*visible*/
      128 && (l.visible = /*visible*/
      i[7]), r[0] & /*elem_id*/
      32 && (l.elem_id = /*elem_id*/
      i[5]), r[0] & /*elem_classes*/
      64 && (l.elem_classes = /*elem_classes*/
      i[6]), r[0] & /*container*/
      8192 && (l.padding = /*container*/
      i[13]), r[0] & /*scale*/
      16384 && (l.scale = /*scale*/
      i[14]), r[0] & /*min_width*/
      32768 && (l.min_width = /*min_width*/
      i[15]), r[0] & /*choices, max_choices, label, info, help, show_label, allow_custom_value, filterable, container, gradio, interactive, value, value_is_output, multiselect, loading_status*/
      999199 | r[1] & /*$$scope*/
      64 && (l.$$scope = { dirty: r, ctx: i }), e.$set(l);
    },
    i(i) {
      n || (Et(e.$$.fragment, i), n = !0);
    },
    o(i) {
      Ft(e.$$.fragment, i), n = !1;
    },
    d(i) {
      Wn(e, i);
    }
  };
}
function Ud(t, e, n) {
  let { label: i = "Dropdown" } = e, { info: r = void 0 } = e, { help: l = void 0 } = e, { elem_id: a = "" } = e, { elem_classes: o = [] } = e, { visible: s = !0 } = e, { multiselect: u = !1 } = e, { value: c = u ? [] : void 0 } = e, { value_is_output: _ = !1 } = e, { max_choices: h = null } = e, { choices: d } = e, { show_label: D } = e, { filterable: E } = e, { container: F = !0 } = e, { scale: C = null } = e, { min_width: g = void 0 } = e, { loading_status: f } = e, { allow_custom_value: m = !1 } = e, { gradio: v } = e, { interactive: p } = e;
  const b = () => v.dispatch("clear_status", f);
  function k(x) {
    c = x, n(0, c);
  }
  function y(x) {
    _ = x, n(1, _);
  }
  const w = () => v.dispatch("change"), A = () => v.dispatch("input"), B = (x) => v.dispatch("select", x.detail), q = () => v.dispatch("blur"), P = () => v.dispatch("focus"), U = () => v.dispatch("key_up");
  function O(x) {
    c = x, n(0, c);
  }
  function W(x) {
    _ = x, n(1, _);
  }
  const j = () => v.dispatch("change"), T = () => v.dispatch("input"), ne = (x) => v.dispatch("select", x.detail), $ = () => v.dispatch("blur"), I = () => v.dispatch("focus"), Se = (x) => v.dispatch("key_up", x.detail);
  return t.$$set = (x) => {
    "label" in x && n(2, i = x.label), "info" in x && n(3, r = x.info), "help" in x && n(4, l = x.help), "elem_id" in x && n(5, a = x.elem_id), "elem_classes" in x && n(6, o = x.elem_classes), "visible" in x && n(7, s = x.visible), "multiselect" in x && n(8, u = x.multiselect), "value" in x && n(0, c = x.value), "value_is_output" in x && n(1, _ = x.value_is_output), "max_choices" in x && n(9, h = x.max_choices), "choices" in x && n(10, d = x.choices), "show_label" in x && n(11, D = x.show_label), "filterable" in x && n(12, E = x.filterable), "container" in x && n(13, F = x.container), "scale" in x && n(14, C = x.scale), "min_width" in x && n(15, g = x.min_width), "loading_status" in x && n(16, f = x.loading_status), "allow_custom_value" in x && n(17, m = x.allow_custom_value), "gradio" in x && n(18, v = x.gradio), "interactive" in x && n(19, p = x.interactive);
  }, [
    c,
    _,
    i,
    r,
    l,
    a,
    o,
    s,
    u,
    h,
    d,
    D,
    E,
    F,
    C,
    g,
    f,
    m,
    v,
    p,
    b,
    k,
    y,
    w,
    A,
    B,
    q,
    P,
    U,
    O,
    W,
    j,
    T,
    ne,
    $,
    I,
    Se
  ];
}
class f5 extends Sd {
  constructor(e) {
    super(), Hd(
      this,
      e,
      Ud,
      qd,
      Pd,
      {
        label: 2,
        info: 3,
        help: 4,
        elem_id: 5,
        elem_classes: 6,
        visible: 7,
        multiselect: 8,
        value: 0,
        value_is_output: 1,
        max_choices: 9,
        choices: 10,
        show_label: 11,
        filterable: 12,
        container: 13,
        scale: 14,
        min_width: 15,
        loading_status: 16,
        allow_custom_value: 17,
        gradio: 18,
        interactive: 19
      },
      null,
      [-1, -1]
    );
  }
}
export {
  po as D,
  h5 as E,
  f5 as I,
  y_ as M,
  L_ as a,
  Ur as c,
  zd as g
};
