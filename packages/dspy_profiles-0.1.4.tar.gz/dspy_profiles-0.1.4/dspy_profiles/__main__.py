from dspy_profiles.cli import app

app(prog_name="dspy-profiles")
