# 2023-02-17 - Gnosis Root Gauge Factory

Deployment of the `GnosisRootGaugeFactory`, for stakeless gauges that bridge funds to their Gnosis counterparts.

## Useful Files

- [Ethereum mainnet addresses](./output/mainnet.json)
- [`GnosisRootGaugeFactory` artifact](./artifact/GnosisRootGaugeFactory.json)
