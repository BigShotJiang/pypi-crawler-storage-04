# Tokens

This is not a real task, but rather a collection of token addresses that are useful so that they can be referenced in other tasks. The tokens included are WETH and BAL.

Not all networks use ETH as their native token: in these, WETH really represents the wrapped native token. Examples include WMATIC in Polygon, WBNB in Binance and WXDAI in Gnosis.
