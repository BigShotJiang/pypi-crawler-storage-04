# 2022-03-25 - Voting Escrow Delegation

Deployment of `VotingEscrowDelegation`, for delegation of veBAL-related boosts.

## Useful Files

- [Ethereum mainnet addresses](./output/mainnet.json)
- [Goerli testnet addresses](./output/goerli.json)
- [Sepolia testnet addresses](./output/sepolia.json)
- [`VotingEscrowDelegation` artifact](./artifact/VotingEscrowDelegation.json)
- [`VotingEscrowDelegationProxy` artifact](./artifact/VotingEscrowDelegationProxy.json)
