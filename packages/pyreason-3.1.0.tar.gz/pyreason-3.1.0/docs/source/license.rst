License
==========

This repository is licensed under `BSD-2-Clause <https://github.com/lab-v2/pyreason/blob/main/LICENSE.md>`_.

Trademark Permission
--------------------
.. |logo| image:: _static/pyreason_logo.jpg
   :width: 50

PyReason™ and PyReason Design Logo |logo| ™ are trademarks of the Arizona Board of Regents/Arizona State University. Users of the software are permitted to use PyReason™ in association with the software for any purpose, provided such use is related to the software (e.g., Powered by PyReason™). Additionally, educational institutions are permitted to use the PyReason Design Logo |logo| ™ for non-commercial purposes.

