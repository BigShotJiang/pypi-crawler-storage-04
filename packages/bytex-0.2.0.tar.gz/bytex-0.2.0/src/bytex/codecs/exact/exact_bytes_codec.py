from dataclasses import dataclass

from bytex.bits import BitBuffer, Bits, from_bits
from bytex.codecs.base_codec import BaseCodec
from bytex.codecs.basic.integer_codec import IntegerCodec
from bytex.endianness import Endianness
from bytex.errors import ValidationError
from bytex.sign import Sign

U8_CODEC = IntegerCodec(bit_count=8, sign=Sign.UNSIGNED)
EMPTY_BYTE = U8_CODEC.serialize(0, endianness=Endianness.BIG)


@dataclass(frozen=True)
class ExactBytesCodec(BaseCodec[bytes]):
    length: int

    def serialize(self, value: bytes, endianness: Endianness) -> Bits:
        bits = []

        for char in value:
            bits += U8_CODEC.serialize(char, endianness=endianness)

        return bits

    def deserialize(self, bit_buffer: BitBuffer, endianness: Endianness) -> bytes:
        return from_bits(
            bit_buffer.read(U8_CODEC.bit_count * self.length), endianness=Endianness.BIG
        )

    def validate(self, value: bytes) -> None:
        if not isinstance(value, bytes):
            print("What!", value)
            raise ValidationError(
                f"Invalid value, a {self.__class__.__name__}'s value must be of type '{str(bytes)}'"
            )

        if len(value) != self.length:
            raise ValidationError(
                f"Invalid value, a {self.__class__.__name__}'s value must be of length `length` - {self.length} characters"
            )
