from .main import runnerTab
from abstract_gui import startConsole
def startRunnerConsole():
    startConsole(runnerTab)
