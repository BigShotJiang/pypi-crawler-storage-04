from abstract_paths import ContentFinderConsole

from abstract_gui.QT6.startConsole import  startConsole

startConsole(ContentFinderConsole)
