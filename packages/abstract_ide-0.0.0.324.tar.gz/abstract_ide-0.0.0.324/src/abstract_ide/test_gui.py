from consoles import *
startIdeConsole()
