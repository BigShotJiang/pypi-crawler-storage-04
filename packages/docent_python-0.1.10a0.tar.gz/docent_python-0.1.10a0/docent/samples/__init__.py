from docent.samples.load import get_inspect_fpath, get_tau_bench_airline_fpath

__all__ = ["get_inspect_fpath", "get_tau_bench_airline_fpath"]
