# protoform

[![Release](https://img.shields.io/github/v/release/dataxight/protoform)](https://img.shields.io/github/v/release/dataxight/protoform)
[![Build status](https://img.shields.io/github/actions/workflow/status/dataxight/protoform/main.yml?branch=main)](https://github.com/dataxight/protoform/actions/workflows/main.yml?query=branch%3Amain)
[![Commit activity](https://img.shields.io/github/commit-activity/m/dataxight/protoform)](https://img.shields.io/github/commit-activity/m/dataxight/protoform)
[![License](https://img.shields.io/github/license/dataxight/protoform)](https://img.shields.io/github/license/dataxight/protoform)

Protoform is  a domain-agnostic data engineering and orchestration framework that enables reproducible data transformations across systems.
