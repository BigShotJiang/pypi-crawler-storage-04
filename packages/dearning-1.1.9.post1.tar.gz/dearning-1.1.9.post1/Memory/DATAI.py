# Ini file kosong 
memory = []