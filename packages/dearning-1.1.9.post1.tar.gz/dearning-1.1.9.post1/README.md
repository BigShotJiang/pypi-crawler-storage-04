# Dearning

<p align="center">
  <img src="https://raw.githubusercontent.com/maker-games/Logo-Dearning/main/logo8_27_84623.png"
 width=195">
</p>

![Downloads](https://static.pepy.tech/personalized-badge/dearning?period=total&units=INTERNATIONAL_SYSTEM&left_color=BLUE&right_color=LIGHTGREY&left_text=downloads)
![PyPI Version](https://img.shields.io/pypi/v/dearning)
![PyPI - Python Version](https://img.shields.io/pypi/pyversions/dearning)
![PyPI - Wheel](https://img.shields.io/pypi/wheel/dearning)
![PyPI - Implementation](https://img.shields.io/pypi/implementation/dearning)
![License](https://img.shields.io/pypi/l/dearning)
![Coverage](https://codecov.io/gh/username/repo/branch/main/graph/badge.svg)

**Dearning** adalah library buatan komunitas Python untuk deep learning dan machine learning yang menggunakan tenaga NumPy.Dirancang sebagai framework AI yang ringan sehingga cocok untuk berbagai device.

## Fitur

- ✅ Bisa membuat jaringan saraf multi-layer (custom)
- ✅ fitur yang cukup lengkap
- ✅ Preprocess dan evaluasi otomatis (MSE, R², akurasi)
- ✅ Cocok untuk edukasi dan pembuatan AI sederhana

## Instalasi

```bash
pip install Dearning
