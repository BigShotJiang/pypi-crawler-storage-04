All files in this folder (templates/guidelines) are meant as guidelines for Claude Code. They define
principles, patterns and guidelines for Claude Code to implement. They are NOT meant as human readable documentation.
