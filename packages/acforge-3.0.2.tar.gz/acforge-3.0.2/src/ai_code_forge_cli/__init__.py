"""AI Code Forge CLI - Template management for AI development workflows."""

__version__ = "3.0.2"
__author__ = "AI Code Forge"
__email__ = "noreply@example.com"