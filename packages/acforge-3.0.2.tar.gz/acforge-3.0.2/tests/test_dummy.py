"""Dummy test to ensure pytest doesn't fail with no tests."""

def test_dummy():
    """A basic test that always passes."""
    assert True