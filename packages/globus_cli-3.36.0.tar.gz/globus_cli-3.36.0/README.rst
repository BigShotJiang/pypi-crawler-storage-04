Globus CLI
==========

A Command Line Interface to `Globus <https://www.globus.org/>`_.

Source Code: https://github.com/globus/globus-cli

Installation, Running, Other Documentation: https://docs.globus.org/cli

Bugs and Feature Requests
-------------------------

Bugs reports and feature requests are open submission, and should be filed at
https://github.com/globusonline/globus-cli/issues
