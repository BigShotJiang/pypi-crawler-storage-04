from globus_cli.commands import main
from globus_cli.version import __version__

__all__ = ["main", "__version__"]
