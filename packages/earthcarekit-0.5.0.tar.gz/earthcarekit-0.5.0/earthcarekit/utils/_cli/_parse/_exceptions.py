class InvalidInputError(Exception):
    pass
