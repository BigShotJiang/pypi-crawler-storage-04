"""Version information for MongoFlow."""

__version__ = "0.0.3"
__author__ = "Caio Norder"
__email__ = "caio@caionorder.com"
__license__ = "MIT"
