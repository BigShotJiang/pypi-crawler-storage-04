#!/usr/bin/env python
"""Setup script for MongoFlow."""

from setuptools import setup

# All configuration is in pyproject.toml
setup()
