"""Helper functions for testing logging."""

from ._parse import parse_log_tuples

__all__ = ["parse_log_tuples"]
