from os import path
from setuptools import find_packages, setup

here = path.abspath(path.dirname(__file__))

# Obtenha a descrição longa do arquivo README
with open(path.join(here, 'README.md'), encoding='utf-8') as f:
    long_description = f.read()

setup(
    name='pdSharepoint',
    version='2.0.0',  # Certifique-se de incrementar esta versão a cada novo upload
    packages=find_packages(where='src'),
    package_dir={'': 'src'},
    url='https://github.com/danielsioli/pdSharepoint',
    author='Daniel Oliveira',
    author_email='danielsioli@gmail.com',
    license='MIT',  # Corrigido
    description='Pacote para obter arquivos excel ou listas do Sharepoint em um DataFrame pandas',
    long_description=long_description,
    long_description_content_type="text/markdown",
    keywords='sharepoint, pandas, office365, microsoft graph',
    install_requires=[
        'O365>=2.0',
        'pandas',
        'openpyxl',
    ],
    include_package_data=True,
    classifiers=[
        'Development Status :: 5 - Production/Stable',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: MIT License',  # Corrigido
        'Operating System :: OS Independent',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Topic :: Software Development :: Libraries :: Python Modules',
    ],
    python_requires='>=3.8', # Atualizado para versões mais modernas
)