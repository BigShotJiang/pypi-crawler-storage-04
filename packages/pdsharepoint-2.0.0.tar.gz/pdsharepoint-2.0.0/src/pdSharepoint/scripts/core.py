"""Core script for SharePoint integration."""

import contextlib
from pathlib import Path
from typing import Any

import pandas as pd
from O365 import Account, FileSystemTokenBackend, MSGraphProtocol
from O365.sharepoint import Site


class PdSharepoint:
    """A class to interact with SharePoint, read lists, and handle Excel files."""

    def __init__(self, credentials: tuple[str, str], token_filepath: Path):
        """Initializes the PdSharepoint object.

        Args:
            credentials: A tuple containing the client_id and client_secret.
            token_filepath: The path to the token file.

        Raises:
            RuntimeError: If the token file path does not exist.
        """
        if not token_filepath.exists():
            raise RuntimeError(
                "The token file path is required. Check the README for more details."
            )
        self.credentials = credentials
        self.token_filename = token_filepath.name
        self.token_path = token_filepath.parent

    def _authenticate(self) -> Account:
        """Authenticates the O365 account.

        Returns:
            An authenticated O365 Account object.

        Raises:
            RuntimeError: If authentication fails.
        """
        token_backend = FileSystemTokenBackend(
            token_path=self.token_path, token_filename=self.token_filename
        )
        account = Account(credentials=self.credentials, token_backend=token_backend)

        if not account.is_authenticated:
            scopes = MSGraphProtocol().get_scopes_for("sharepoint")
            if not account.authenticate(scopes=scopes):
                raise RuntimeError(
                    "Authentication failed with the provided credentials and token."
                )
        return account

    def _get_team_site(self, host: str, site: str) -> Site:
        """Gets a SharePoint site object.

        Args:
            host: The SharePoint host (e.g., 'anatel365.sharepoint.com').
            site: The name of the site or team.

        Returns:
            A SharePoint Site object.
        """
        account = self._authenticate()
        sharepoint = account.sharepoint()
        return sharepoint.get_site(host, f"sites/{site}")

    def download_sharepoint_excel(
        self,
        sharepoint_file_path: str,
        host: str,
        site: str,
        library: str,
        filename: Path,
    ) -> Path:
        """Downloads a SharePoint Excel file to local storage.

        Args:
            sharepoint_file_path: The file path in the SharePoint library
                (e.g., '/General/file.xlsx').
            host: The SharePoint host (e.g., 'anatel365.sharepoint.com').
            site: The name of the site or team.
            library: The library in the SharePoint site (e.g., 'Documents').
            filename: The local path where the downloaded file will be stored.

        Returns:
            The path to the downloaded file.

        Raises:
            ValueError: If the specified library is not found.
        """
        team_site = self._get_team_site(host=host, site=site)
        libraries = team_site.list_document_libraries()
        team_drive = next((lib for lib in libraries if lib.name == library), None)
        if not team_drive:
            raise ValueError(f"Library {library} not found!")

        item = team_drive.get_item_by_path(sharepoint_file_path)
        filename.parent.mkdir(parents=True, exist_ok=True)
        item.download(to_path=filename.parent, name=filename.name)
        return filename

    def read_sharepoint_list(
        self, list_name: str, host: str, site: str
    ) -> pd.DataFrame:
        """Reads a SharePoint list and returns its content as a pandas DataFrame.

        Args:
            list_name: The name of the SharePoint list.
            host: The SharePoint host (e.g., 'anatel365.sharepoint.com').
            site: The name of the site or team.

        Returns:
            A pandas DataFrame with the SharePoint list's contents.
        """
        team_site = self._get_team_site(host=host, site=site)
        sp_list = team_site.get_list_by_name(list_name)
        list_columns = sp_list.get_list_columns()

        excluded_columns = {
            "ComplianceAssetId",
            "Author",
            "Editor",
            "DocIcon",
            "_IsRecord",
            "AppAuthor",
            "AppEditor",
        }

        # Cria lista de dicionários para criar um pandas DataFrame
        items = sp_list.get_items(expand_fields=True)
        id_list = [item.object_id for item in items]
        rows = []

        for item_id in id_list:
            fields = sp_list.get_item_by_id(item_id, expand_fields=True).fields
            fields.pop("@odata.etag", None)
            for list_column in list_columns:
                if (
                    list_column.internal_name in fields
                    and list_column.display_name != list_column.internal_name
                    and list_column.internal_name
                    not in excluded_columns  # Display e Interno é o mesmo nome e não é uma coluna excluída.
                ) and (
                    "Title" in list_column.internal_name
                    and list_column.internal_name == "Title"
                    or "Title"
                    not in list_column.internal_name  # Se a coluna for 'Title <alguma coisa>' não mudar o nome da coluna.
                ):
                    fields[list_column.display_name] = fields[
                        list_column.internal_name
                    ]
                    fields.pop(list_column.internal_name, None)
            rows.append(fields)
        df = pd.DataFrame(rows)

        # Attempt to convert object columns to datetime
        for col in df.select_dtypes(include=["object"]).columns:
            with contextlib.suppress(ValueError, TypeError):
                df[col] = pd.to_datetime(df[col], format="%Y-%m-%d %H:%M:%S")
        return df

    def read_sharepoint_excel(
        self,
        sharepoint_file_path: str,
        host: str,
        site: str,
        library: str,
        **kwargs: Any,
    ) -> pd.DataFrame:
        """Reads a SharePoint Excel file into a pandas DataFrame.

        Args:
            sharepoint_file_path: The file path in the SharePoint library
                (e.g., '/General/file.xlsx').
            host: The SharePoint host (e.g., 'anatel365.sharepoint.com').
            site: The name of the site or team.
            library: The library in the SharePoint site (e.g., 'Documents').
            **kwargs: Keyword arguments to be passed to pandas.read_excel.

        Returns:
            A pandas DataFrame with the Excel file's contents.
        """
        temp_file = Path("temp_excel_file.xlsx")
        try:
            io = self.download_sharepoint_excel(
                sharepoint_file_path=sharepoint_file_path,
                host=host,
                site=site,
                library=library,
                filename=temp_file,
            )
            df = pd.read_excel(io, **kwargs)
        finally:
            # Clean up the temporary file
            temp_file.unlink(missing_ok=True)

        return df
