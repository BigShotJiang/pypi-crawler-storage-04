"""Testes para o módulo core."""

import configparser
import unittest
from pathlib import Path
from unittest.mock import MagicMock, patch

import pandas as pd
import pytest
from O365.sharepoint import SharepointList

from pdSharepoint.scripts.core import PdSharepoint


class TestPdSharepointUnit(unittest.TestCase):
    """Testes unitários para a classe PdSharepoint."""

    def setUp(self):
        """Configura o ambiente de teste."""
        self.credentials = ("client_id", "client_secret")
        self.token_filepath = Path("token.json")
        with open(self.token_filepath, "w") as f:
            f.write("test token")

    def tearDown(self):
        """Limpa o ambiente de teste."""
        if self.token_filepath.exists():
            self.token_filepath.unlink()

    def test_init_success(self):
        """Testa a inicialização bem-sucedida."""
        pd_sharepoint = PdSharepoint(self.credentials, self.token_filepath)
        self.assertEqual(pd_sharepoint.credentials, self.credentials)
        self.assertEqual(pd_sharepoint.token_filename, self.token_filepath.name)
        self.assertEqual(pd_sharepoint.token_path, self.token_filepath.parent)

    def test_init_file_not_found(self):
        """Testa a falha na inicialização quando o arquivo de token não existe."""
        with self.assertRaises(RuntimeError):
            PdSharepoint(self.credentials, Path("non_existent_file.json"))

    @patch("pdSharepoint.scripts.core.Account")
    def test_authenticate_success(self, mock_account):
        """Testa a autenticação bem-sucedida."""
        mock_account.return_value.is_authenticated = True
        pd_sharepoint = PdSharepoint(self.credentials, self.token_filepath)
        account = pd_sharepoint._authenticate()
        self.assertTrue(account.is_authenticated)

    @patch("pdSharepoint.scripts.core.Account")
    def test_authenticate_success2(self, mock_account):
        """Testa a autenticação bem-sucedida."""
        mock_account.return_value.is_authenticated = False
        mock_account.return_value.authenticate.return_value = True
        pd_sharepoint = PdSharepoint(self.credentials, self.token_filepath)
        account = pd_sharepoint._authenticate()
        self.assertFalse(account.is_authenticated)

    @patch("pdSharepoint.scripts.core.Account")
    def test_authenticate_failure(self, mock_account):
        """Testa a falha na autenticação."""
        mock_account.return_value.is_authenticated = False
        mock_account.return_value.authenticate.return_value = False
        pd_sharepoint = PdSharepoint(self.credentials, self.token_filepath)
        with self.assertRaises(RuntimeError):
            pd_sharepoint._authenticate()

    @patch("pdSharepoint.scripts.core.PdSharepoint._authenticate")
    def test_get_team_site(self, mock_authenticate):
        """Testa a obtenção do site da equipe."""
        mock_account = MagicMock()
        mock_authenticate.return_value = mock_account
        mock_site = MagicMock()
        mock_account.sharepoint.return_value.get_site.return_value = mock_site

        pd_sharepoint = PdSharepoint(self.credentials, self.token_filepath)
        site = pd_sharepoint._get_team_site("host", "site")

        self.assertEqual(site, mock_site)
        mock_authenticate.assert_called_once()
        mock_account.sharepoint.return_value.get_site.assert_called_once_with("host", "sites/site")

    @patch("pdSharepoint.scripts.core.PdSharepoint._get_team_site")
    def test_download_sharepoint_excel_success(self, mock_get_team_site):
        """Testa o download bem-sucedido de um arquivo Excel do SharePoint."""
        mock_site = MagicMock()
        mock_get_team_site.return_value = mock_site
        mock_drive = MagicMock()
        mock_drive.name = 'library'
        mock_site.list_document_libraries.return_value = [mock_drive]
        mock_item = MagicMock()
        mock_drive.get_item_by_path.return_value = mock_item

        pd_sharepoint = PdSharepoint(self.credentials, self.token_filepath)
        filename = Path("test.xlsx")
        result = pd_sharepoint.download_sharepoint_excel(
            "path", "host", "site", "library", filename
        )

        self.assertEqual(result, filename)
        mock_item.download.assert_called_once_with(to_path=filename.parent, name=filename.name)

    @patch("pdSharepoint.scripts.core.PdSharepoint._get_team_site")
    def test_download_sharepoint_excel_library_not_found(self, mock_get_team_site):
        """Testa a falha no download quando a biblioteca não é encontrada."""
        mock_site = MagicMock()
        mock_get_team_site.return_value = mock_site
        mock_site.get_document_library.return_value = None

        pd_sharepoint = PdSharepoint(self.credentials, self.token_filepath)
        with self.assertRaises(ValueError):
            pd_sharepoint.download_sharepoint_excel(
                "path", "host", "site", "library", Path("test.xlsx")
            )

    @patch("pdSharepoint.scripts.core.PdSharepoint._get_team_site")
    def test_read_sharepoint_list(self, mock_get_team_site):
        """Testa a leitura de uma lista do SharePoint."""
        mock_site = MagicMock()
        mock_get_team_site.return_value = mock_site
        mock_list = MagicMock(spec=SharepointList)
        mock_site.get_list_by_name.return_value = mock_list

        mock_item1 = MagicMock()
        mock_item1.object_id = "1"
        mock_item1.fields = {"Title": "Item 1", "OutraColuna": "Valor 1"}
        mock_item2 = MagicMock()
        mock_item2.object_id = "2"
        mock_item2.fields = {"Title": "Item 2", "OutraColuna": "Valor 2"}

        mock_list.get_items.return_value = [mock_item1, mock_item2]
        mock_list.get_item_by_id.side_effect = [mock_item1, mock_item2]
        mock_list.get_list_columns.return_value = []

        pd_sharepoint = PdSharepoint(self.credentials, self.token_filepath)
        df = pd_sharepoint.read_sharepoint_list("list_name", "host", "site")

        self.assertIsInstance(df, pd.DataFrame)
        self.assertEqual(len(df), 2)
        self.assertIn("Title", df.columns)

    @patch("pdSharepoint.scripts.core.pd.read_excel")
    @patch("pdSharepoint.scripts.core.PdSharepoint.download_sharepoint_excel")
    def test_read_sharepoint_excel(self, mock_download, mock_read_excel):
        """Testa a leitura de um arquivo Excel do SharePoint."""
        mock_download.return_value = "path/to/local/file.xlsx"
        mock_df = pd.DataFrame({"col1": [1, 2], "col2": [3, 4]})
        mock_read_excel.return_value = mock_df

        pd_sharepoint = PdSharepoint(self.credentials, self.token_filepath)
        df = pd_sharepoint.read_sharepoint_excel("path", "host", "site", "library")

        self.assertIsInstance(df, pd.DataFrame)
        self.assertEqual(df.shape, (2, 2))
        mock_download.assert_called_once()
        mock_read_excel.assert_called_once()


@pytest.mark.integration
class TestPdSharepointIntegration:
    """Testes de integração para a classe PdSharepoint."""

    @pytest.fixture(scope="class", autouse=True)
    def credentials_token(self):
        config_path = '/mnt/config/config-linux.ini'  # substitua pelo seu próprio arquivo
        config = configparser.RawConfigParser(allow_no_value=True)
        config.read(config_path, encoding='utf-8-sig')
        credentials = (config['anatel:azure']['client_id'], config['anatel:azure']['client_secret'])
        token_path = Path(config['anatel:azure']['token_path'])
        token_filename = config['anatel:azure']['token_filename']
        return credentials, token_path, token_filename

    @pytest.fixture(scope="class")
    def setup_integration(self, credentials_token):
        """Configura o ambiente de teste de integração."""

        credentials, token_path, token_filename = credentials_token
        token_filepath = token_path / token_filename

        if not token_filepath.exists():
            pytest.skip("Arquivo de token não encontrado. " "Pule os testes de integração.")

        return PdSharepoint(credentials, token_filepath)

    expected_df = pd.DataFrame({
        'LinkTitle': ['Título 1'],
        'ColunaPessoaLookupId': ['42'],
        'id': ['1'],
        'AuthorLookupId': ['42'],
        'EditorLookupId': ['42'],
        'LinkTitleNoMenu': ['Título 1'],
        'Título': ['Título 1'],
        'Coluna Texto Uma Linha': ['Texto'],
        'Coluna Texto Múltiplas Linhas': ['Texto\nTexto'],
        'Coluna Seleção Única': ['Choice 1'],
        'Coluna Seleção Múltipla': [['Choice 1', 'Choice 2']],
        'Coluna Data': ['2025-09-05T07:00:00Z'],
        # Não retorna essa coluna
        # 'Coluna Pessoa': ['Daniel da Silva Oliveira'],
        'Coluna Número': [123.0],
        'Coluna Binária': [True],
        'Coluna URL': [{'Description': 'Anatel', 'Url': 'https://gov.br/anatel'}],
        'Coluna Moeda': [123.0],
        'Coluna Localização': [{'displayName': 'Brasília'}],
        'Coluna Localização: Name': ['Brasília'],
        'Coluna Imagem': ['{"fileName":"Reserved_ImageAttachment_[12]_[ColunaImagem][32]_[a4962969f0b94d9e8b0e2235c5eb1c94][1]_[1].png","originalImageName":"propaganda"}'],
        'Coluna Metadados': [{'Label': 'cpae2', 'TermGuid': '2c81f24b-18ae-47e2-b47d-f8b30eedc108', 'WssId': 7}],
        # Não retorna essa coluna
        # 'Coluna Lookup': [None],
        'Tipo de Conteúdo': ['Item'],
        'Modificado': ['2025-09-05T19:46:31Z'],
        'Criado': ['2025-09-05T19:37:30Z'],
        'Versão': ['4.0'],
        'Anexos': [True],
        'Editar': [pd.NaT],
        'Contagem de Itens Filhos': ['0'],
        'Contagem de Elementos Filho da Pasta': ['0'],
        'Configuração do rótulo': [pd.NaT],
        'Rótulo de retenção': [pd.NaT],
        'Rótulo de retenção Aplicado': [pd.NaT],
        'Rótulo aplicado por': [pd.NaT],
    })

    def test_read_sharepoint_list_integration(self, setup_integration):
        """Testa a leitura de uma lista do SharePoint (real)."""
        # Substitua com informações reais do seu ambiente
        host = "anatel365.sharepoint.com"
        site = "CPAE"
        list_name = "test_pdSharepoint"

        try:
            df = setup_integration.read_sharepoint_list(list_name, host, site)
            assert isinstance(df, pd.DataFrame)
            assert not df.empty
            pd.testing.assert_frame_equal(df, self.expected_df)
        except Exception as e:
            pytest.fail(f"Falha no teste de integração de leitura de lista: {e}")

    def test_download_sharepoint_excel_integration(self, setup_integration):
        """Testa o download de um arquivo Excel do SharePoint (real)."""
        # Substitua com informações reais do seu ambiente
        host = "anatel365.sharepoint.com"
        site = "CPAE"
        library = "Documentos"
        sharepoint_file_path = "/Curadoria Dados/tests/test_pdSharepoint.xlsx"
        local_filename = Path("test_pdSharepoint.xlsx")

        try:
            path = setup_integration.download_sharepoint_excel(
                sharepoint_file_path, host, site, library, local_filename
            )
            assert path.exists()
            assert path.name == local_filename.name
            df = pd.read_excel(path)
            assert isinstance(df, pd.DataFrame)
            assert not df.empty

            expected_df = pd.DataFrame({
                'Coluna 1': ['Item 1'],
                'Coluna 2': ['Item 2']
            })

            pd.testing.assert_frame_equal(df, expected_df)
        except Exception as e:
            pytest.fail(f"Falha no teste de integração de download: {e}")
        finally:
            local_filename.unlink(missing_ok=True)
            local_filename.unlink(missing_ok=True)
