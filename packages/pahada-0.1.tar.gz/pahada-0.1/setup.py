from setuptools import setup, find_packages

setup(
    name="pahada",
    version="0.1",
    description="A simple Python library to generate multiplication tables",
    author="Shrey",
    packages=find_packages(),
    install_requires=[],
    python_requires=">=3.6",
)
