# kabukit

A Python toolkit for Japanese financial market data, supporting J-Quants and EDINET APIs.

## Gemini CLI

https://github.com/google-gemini/gemini-cli/issues/6297

```bash
echo $GEMINI_CLI_IDE_SERVER_PORT
sudo sh -c 'echo "127.0.0.1 host.docker.internal" >> /etc/hosts'
```

## References

https://jpx.gitbook.io/j-quants-ja/api-reference
https://japanexchangegroup.github.io/J-Quants-Tutorial/
https://www.jpx.co.jp/corporate/news/news-releases/0010/20210813-01.html
https://disclosure2dl.edinet-fsa.go.jp/guide/static/disclosure/WZEK0110.html