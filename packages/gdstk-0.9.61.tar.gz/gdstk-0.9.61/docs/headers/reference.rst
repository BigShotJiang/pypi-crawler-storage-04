reference.h
===========

.. literalinclude:: ../../include/gdstk/reference.hpp
   :language: c++
   :start-after: namespace gdstk {
   :end-before: }  // namespace gdstk
