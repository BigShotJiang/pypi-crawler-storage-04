curve.h
=======

.. literalinclude:: ../../include/gdstk/curve.hpp
   :language: c++
   :start-after: namespace gdstk {
   :end-before: }  // namespace gdstk
