clipper_tools.h
===============

.. literalinclude:: ../../include/gdstk/clipper_tools.hpp
   :language: c++
   :start-after: namespace gdstk {
   :end-before: }  // namespace gdstk
