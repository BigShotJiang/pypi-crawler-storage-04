allocator.h
===========

.. literalinclude:: ../../include/gdstk/allocator.hpp
   :language: c++
   :start-after: namespace gdstk {
   :end-before: }  // namespace gdstk
