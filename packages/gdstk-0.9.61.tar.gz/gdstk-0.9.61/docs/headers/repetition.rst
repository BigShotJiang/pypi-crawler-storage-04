repetition.h
============

.. literalinclude:: ../../include/gdstk/repetition.hpp
   :language: c++
   :start-after: namespace gdstk {
   :end-before: }  // namespace gdstk
