"""DDS CLI version."""

# Do not change bump the major version unless absolutely necessary - makes incompatible with API
# If mid or minor version reaches 9, continue to 10, 11 etc.
__version__ = "2.12.0"
