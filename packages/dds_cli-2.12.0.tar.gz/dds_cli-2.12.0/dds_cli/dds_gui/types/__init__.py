"""DDS GUI types package."""
