"""DDS GUI components package."""
