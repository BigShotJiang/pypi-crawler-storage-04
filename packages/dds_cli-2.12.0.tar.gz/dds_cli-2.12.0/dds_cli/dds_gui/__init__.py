"""DDS GUI package."""

# Make the GUI components available for import
from dds_cli.dds_gui.app import DDSApp

__all__ = ["DDSApp"]
