"""DDS GUI authentication package."""
