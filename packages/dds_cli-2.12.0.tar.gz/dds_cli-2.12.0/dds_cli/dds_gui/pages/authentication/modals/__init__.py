"""DDS GUI authentication modals package."""
