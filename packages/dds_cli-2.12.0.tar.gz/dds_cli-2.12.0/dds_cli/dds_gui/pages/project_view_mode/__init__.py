"""DDS GUI project view mode package."""
