"""DDS GUI project actions tabs package."""
