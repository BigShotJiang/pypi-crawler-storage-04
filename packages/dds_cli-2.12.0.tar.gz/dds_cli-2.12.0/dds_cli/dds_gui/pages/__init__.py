"""DDS GUI pages package."""
