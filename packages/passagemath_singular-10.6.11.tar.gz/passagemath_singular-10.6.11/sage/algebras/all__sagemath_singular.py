# sage_setup: distribution = sagemath-singular

from sage.algebras.quatalg.all import *
