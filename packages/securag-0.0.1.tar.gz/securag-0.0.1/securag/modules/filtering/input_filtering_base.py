from abc import ABC, abstractmethod

from securag.modules import Module

class Filter(Module):
    pass