webmerc = {'init':'epsg:3857'}
wgs84 = {'init':'epsg:4326'}
