'''IOC Extractor is a tool for extracting indicators of compromise from files.'''
__version__ = "0.1.0"