from enum import StrEnum


class SortOrder(StrEnum):
    ASC = "asc"
    DESC = "desc"
