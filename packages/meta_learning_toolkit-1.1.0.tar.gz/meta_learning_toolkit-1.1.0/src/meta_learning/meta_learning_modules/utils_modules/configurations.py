"""
Configuration Classes for Meta-Learning Utilities
================================================

Author: Benedict Chen (benedict@benedictchen.com)

This module contains all configuration dataclasses and classes for meta-learning
utilities, providing type-safe configuration management with sensible defaults.
"""

from dataclasses import dataclass
from typing import Optional, List, Dict, Any


@dataclass
class TaskConfiguration:
    """Configuration for meta-learning tasks."""
    n_way: int = 5
    k_shot: int = 5
    q_query: int = 15
    num_tasks: int = 1000
    task_type: str = "classification"
    augmentation_strategy: str = "basic"  # basic, advanced, none
    
    # Configuration options for difficulty estimation methods
    difficulty_estimation_method: str = "pairwise_distance"  # "pairwise_distance", "silhouette", "entropy", "knn"
    use_research_accurate_difficulty: bool = False  # Enable research-backed methods


@dataclass
class EvaluationConfig:
    """Configuration for meta-learning evaluation."""
    confidence_intervals: bool = True
    num_bootstrap_samples: int = 1000
    significance_level: float = 0.05
    track_adaptation_curve: bool = True
    compute_uncertainty: bool = True
    
    # Configuration options for confidence interval methods
    ci_method: str = "bootstrap"  # "bootstrap", "t_distribution", "meta_learning_standard", "bca_bootstrap"
    use_research_accurate_ci: bool = False  # Enable research-backed CI methods
    num_episodes: int = 600  # Standard meta-learning evaluation protocol
    
    # Additional configuration for advanced CI methods
    min_sample_size_for_bootstrap: int = 30  # Minimum sample size for bootstrap vs t-distribution
    auto_method_selection: bool = True  # Automatically select best CI method based on data


class DatasetConfig:
    """Configuration for meta-learning dataset creation."""
    
    def __init__(
        self,
        dataset_type: str = "episodic",
        augmentation_strategy: str = "minimal",
        shuffle: bool = True,
        stratified: bool = True,
        normalize: bool = True,
        cache_episodes: bool = False,
        **kwargs
    ):
        self.dataset_type = dataset_type
        self.augmentation_strategy = augmentation_strategy
        self.shuffle = shuffle
        self.stratified = stratified
        self.normalize = normalize
        self.cache_episodes = cache_episodes
        for key, value in kwargs.items():
            setattr(self, key, value)


class MetricsConfig:
    """Configuration for evaluation metrics computation."""
    
    def __init__(
        self,
        compute_accuracy: bool = True,
        compute_loss: bool = True,
        compute_adaptation_speed: bool = False,
        compute_uncertainty: bool = False,
        track_gradients: bool = False,
        save_predictions: bool = False,
        **kwargs
    ):
        self.compute_accuracy = compute_accuracy
        self.compute_loss = compute_loss
        self.compute_adaptation_speed = compute_adaptation_speed
        self.compute_uncertainty = compute_uncertainty
        self.track_gradients = track_gradients
        self.save_predictions = save_predictions
        for key, value in kwargs.items():
            setattr(self, key, value)


class StatsConfig:
    """Configuration for statistical analysis."""
    
    def __init__(
        self,
        confidence_level: float = 0.95,
        num_bootstrap_samples: int = 1000,
        significance_test: str = "t_test",
        multiple_comparison_correction: str = "bonferroni",
        effect_size_method: str = "cohen_d",
        **kwargs
    ):
        self.confidence_level = confidence_level
        self.num_bootstrap_samples = num_bootstrap_samples
        self.significance_test = significance_test
        self.multiple_comparison_correction = multiple_comparison_correction
        self.effect_size_method = effect_size_method
        for key, value in kwargs.items():
            setattr(self, key, value)


class CurriculumConfig:
    """Configuration for curriculum learning strategies."""
    
    def __init__(
        self,
        strategy: str = "difficulty_based",
        initial_difficulty: float = 0.3,
        difficulty_increment: float = 0.1,
        difficulty_threshold: float = 0.8,
        adaptation_patience: int = 5,
        **kwargs
    ):
        self.strategy = strategy
        self.initial_difficulty = initial_difficulty
        self.difficulty_increment = difficulty_increment
        self.difficulty_threshold = difficulty_threshold
        self.adaptation_patience = adaptation_patience
        for key, value in kwargs.items():
            setattr(self, key, value)


class DiversityConfig:
    """Configuration for task diversity tracking."""
    
    def __init__(
        self,
        diversity_metric: str = "cosine_similarity",
        track_class_distribution: bool = True,
        track_feature_diversity: bool = True,
        diversity_threshold: float = 0.7,
        **kwargs
    ):
        self.diversity_metric = diversity_metric
        self.track_class_distribution = track_class_distribution
        self.track_feature_diversity = track_feature_diversity
        self.diversity_threshold = diversity_threshold
        for key, value in kwargs.items():
            setattr(self, key, value)