"""Entry point for running csv-token-counter as a module."""

from .cli import main

if __name__ == "__main__":
    main()