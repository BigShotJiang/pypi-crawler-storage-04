# src/my_db_library/repositories/__init__.py
from .abstract_repo import BaseRepository

__all__ = ['BaseRepository']