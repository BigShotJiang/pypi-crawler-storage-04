# src/my_db_library/models/__init__.py
from .base_model import Base

__all__ = ['Base']