"""
API client package for GitLab integration
"""

from .client import GitLabAnalyzer

__all__ = ["GitLabAnalyzer"]
