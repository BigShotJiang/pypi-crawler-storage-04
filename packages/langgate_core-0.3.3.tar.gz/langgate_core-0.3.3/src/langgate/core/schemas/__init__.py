"""Schema package for configuration validation."""
