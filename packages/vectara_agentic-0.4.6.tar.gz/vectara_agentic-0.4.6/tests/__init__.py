"""
Tests package for vectara_agentic.
"""

# Suppress external dependency warnings globally for all tests
import warnings

warnings.simplefilter("ignore", DeprecationWarning)
