"""Implements configurations."""
