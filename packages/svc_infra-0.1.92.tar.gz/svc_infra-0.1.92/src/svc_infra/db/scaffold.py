from __future__ import annotations

from pathlib import Path
from string import Template
from typing import Dict, Any, Optional, Literal

# ---------------- helpers ----------------

_INIT_CONTENT = 'from . import models, schemas\n\n__all__ = ["models", "schemas"]\n'

def _normalize_dir(p: Path | str) -> Path:
    p = Path(p)
    return p if p.is_absolute() else (Path.cwd() / p).resolve()

def _write(dest: Path, content: str, overwrite: bool) -> Dict[str, Any]:
    dest = dest.resolve()
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.exists() and not overwrite:
        return {"path": str(dest), "action": "skipped", "reason": "exists"}
    dest.write_text(content, encoding="utf-8")
    return {"path": str(dest), "action": "wrote"}

def _ensure_init_py(dir_path: Path, overwrite: bool) -> Dict[str, Any]:
    """Create __init__.py that re-exports models/schemas."""
    return _write(dir_path / "__init__.py", _INIT_CONTENT, overwrite)

# ---------------- generic (entity) inline templates ----------------

_DEFAULT_MODELS_TPL = Template(
    """from __future__ import annotations
from datetime import datetime
from typing import Optional
import uuid

from sqlalchemy import String, Boolean, DateTime, JSON, Text, func, UniqueConstraint, Index
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column
from sqlalchemy.ext.mutable import MutableDict

from svc_infra.db.base import ModelBase


class ${Entity}(ModelBase):
    __tablename__ = "${table_name}"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text)

$tenant_field$soft_delete_field    extra: Mapped[dict] = mapped_column(MutableDict.as_mutable(JSON), default=dict)

    # auditing (DB-side timestamps)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)

$constraints    def __repr__(self) -> str:
        return f"<${Entity} id={self.id} name={self.name!r}>"

$indexes"""
)

_DEFAULT_SCHEMAS_TPL = Template(
    """from __future__ import annotations
from typing import Optional, Any, Dict
from datetime import datetime
from pydantic import BaseModel, Field, ConfigDict


class Timestamped(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    created_at: datetime
    updated_at: datetime


class ${Entity}Base(BaseModel):
    model_config = ConfigDict(from_attributes=True, populate_by_name=True)
    name: str
    description: Optional[str] = None
$tenant_field    is_active: bool = True
    extra: Dict[str, Any] = Field(default_factory=dict)


class ${Entity}Read(${Entity}Base, Timestamped):
    id: str


class ${Entity}Create(BaseModel):
    name: str
    description: Optional[str] = None
$tenant_field_create    is_active: bool = True
    extra: Dict[str, Any] = Field(default_factory=dict)


class ${Entity}Update(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
$tenant_field_update    is_active: Optional[bool] = None
    extra: Optional[Dict[str, Any]] = None
"""
)

# ---------------- auth templates (loaded from package) ----------------

def _render_auth_template(name: str) -> str:
    import importlib.resources as pkg
    from string import Template as _T
    txt = pkg.files("svc_infra.db.templates.auth").joinpath(name).read_text(encoding="utf-8")
    return _T(txt).substitute({})  # no variables today

# ---------------- tiny utilities ----------------

def _normalize_entity_name(name: str) -> str:
    parts = [p for p in _snake(name).split("_") if p]
    return "".join(p.capitalize() for p in parts) or "Item"

def _snake(name: str) -> str:
    import re
    s1 = re.sub("(.)([A-Z][a-z]+)", r"\\1_\\2", name)
    s2 = re.sub("([a-z0-9])([A-Z])", r"\\1_\\2", s1)
    return re.sub("[^a-zA-Z0-9_]+", "_", s2).lower().strip("_")

def _suggest_table_name(entity_pascal: str) -> str:
    base = _snake(entity_pascal)
    return base + "s" if not base.endswith("s") else base

# ---------------- unified public API ----------------
# kind: "entity" (generic) or "auth" (specialized templates)

Kind = Literal["entity", "auth"]

def scaffold_core(
        *,
        models_dir: Path | str,
        schemas_dir: Path | str,
        kind: Kind = "entity",
        entity_name: str = "Item",
        table_name: Optional[str] = None,
        include_tenant: bool = True,
        include_soft_delete: bool = False,
        overwrite: bool = False,
        same_dir: bool = False,
) -> Dict[str, Any]:
    """
    Create starter model + schema files.

    - Writes to `models.py` and `schemas.py` (always).
    - If same_dir=True, both are placed in models_dir.
    """
    models_dir = _normalize_dir(models_dir)
    schemas_dir = _normalize_dir(models_dir if same_dir else schemas_dir)

    # --- content per kind ---
    if kind == "auth":
        models_txt = _render_auth_template("models.py.tmpl")
        schemas_txt = _render_auth_template("schemas.py.tmpl")
    else:
        ent = _normalize_entity_name(entity_name)
        tbl = table_name or _suggest_table_name(ent)

        tenant_model_field = (
            '    tenant_id: Mapped[Optional[str]] = mapped_column(String(64), index=True)\n'
            if include_tenant else ""
        )
        soft_delete_model_field = (
            '    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)\n'
            '    deleted_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))\n'
            if include_soft_delete else
            '    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)\n'
        )

        constraints = (
            '    __table_args__ = (\n'
            f'        UniqueConstraint("tenant_id", "name", name="uq_{tbl}_tenant_name"),\n'
            '    )\n'
        ) if include_tenant else ""

        indexes = f'Index("ix_{tbl}_tenant_id", {ent}.tenant_id)\n' if include_tenant else ""

        models_txt = _DEFAULT_MODELS_TPL.substitute(
            Entity=ent,
            table_name=tbl,
            tenant_field=tenant_model_field,
            soft_delete_field=soft_delete_model_field,
            constraints=constraints,
            indexes=indexes,
        )

        tenant_schema_field = "    tenant_id: Optional[str] = None\n" if include_tenant else ""
        schemas_txt = _DEFAULT_SCHEMAS_TPL.substitute(
            Entity=ent,
            tenant_field=tenant_schema_field,
            tenant_field_create=tenant_schema_field,
            tenant_field_update=tenant_schema_field,
        )

    # --- file paths: always models.py / schemas.py ---
    models_path = models_dir / "models.py"
    schemas_path = schemas_dir / "schemas.py"

    models_res = _write(models_path, models_txt, overwrite)
    schemas_res = _write(schemas_path, schemas_txt, overwrite)

    # __init__.py in each destination folder
    init_results = [ _ensure_init_py(models_dir, overwrite) ]
    if schemas_dir != models_dir:
        init_results.append(_ensure_init_py(schemas_dir, overwrite))

    return {"status": "ok", "results": {"models": models_res, "schemas": schemas_res, "inits": init_results}}

def scaffold_models_core(
        *,
        dest_dir: Path | str,
        kind: Kind = "entity",
        entity_name: str = "Item",
        table_name: Optional[str] = None,
        include_tenant: bool = True,
        include_soft_delete: bool = False,
        overwrite: bool = False,
) -> Dict[str, Any]:
    """Create only models.py in the given directory."""
    dest = _normalize_dir(dest_dir)

    if kind == "auth":
        txt = _render_auth_template("models.py.tmpl")
    else:
        ent = _normalize_entity_name(entity_name)
        tbl = table_name or _suggest_table_name(ent)
        tenant_model_field = (
            '    tenant_id: Mapped[Optional[str]] = mapped_column(String(64), index=True)\n'
            if include_tenant else ""
        )
        soft_delete_model_field = (
            '    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)\n'
            '    deleted_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))\n'
            if include_soft_delete else
            '    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)\n'
        )
        constraints = (
            '    __table_args__ = (\n'
            f'        UniqueConstraint("tenant_id", "name", name="uq_{tbl}_tenant_name"),\n'
            '    )\n'
        ) if include_tenant else ""
        indexes = f'Index("ix_{tbl}_tenant_id", {ent}.tenant_id)\n' if include_tenant else ""

        txt = _DEFAULT_MODELS_TPL.substitute(
            Entity=ent,
            table_name=tbl,
            tenant_field=tenant_model_field,
            soft_delete_field=soft_delete_model_field,
            constraints=constraints,
            indexes=indexes,
        )

    res = _write(dest / "models.py", txt, overwrite)
    _ensure_init_py(dest, overwrite)
    return {"status": "ok", "result": res}

def scaffold_schemas_core(
        *,
        dest_dir: Path | str,
        kind: Kind = "entity",
        entity_name: str = "Item",
        include_tenant: bool = True,
        overwrite: bool = False,
) -> Dict[str, Any]:
    """Create only schemas.py in the given directory."""
    dest = _normalize_dir(dest_dir)

    if kind == "auth":
        txt = _render_auth_template("schemas.py.tmpl")
    else:
        ent = _normalize_entity_name(entity_name)
        tenant_field = "    tenant_id: Optional[str] = None\n" if include_tenant else ""
        txt = _DEFAULT_SCHEMAS_TPL.substitute(
            Entity=ent,
            tenant_field=tenant_field,
            tenant_field_create=tenant_field,
            tenant_field_update=tenant_field,
        )

    res = _write(dest / "schemas.py", txt, overwrite)
    _ensure_init_py(dest, overwrite)
    return {"status": "ok", "result": res}