"""Authentication module for the Eastmoney Trading Library."""
