# Federated Language

Federated Language is a framework for implementing federated algorithms and
computations on privacy-sensitive data.
