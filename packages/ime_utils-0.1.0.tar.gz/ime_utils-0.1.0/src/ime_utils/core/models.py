import re
from dataclasses import dataclass


@dataclass
class WordEntry:
    """词库文件单个词结构"""

    word: str  # 词语
    coding: list[str]  # 编码：一般为拼音
    weight: int  # 词频/权重
    is_pinyin: bool = True  # 是否拼音编码
    is_error: bool = False  # 是否解析异常

    def to_str(
        self, separator: str = "\t", coding_separator: str = " ", keep_weight: bool = True
    ) -> str:
        coding_str = self.coding_to_str(coding_separator)
        weight = self.weight if self.weight and self.weight > 0 else 0
        data = [self.word, coding_str] + ([weight] if keep_weight else [])
        return separator.join(map(str, data))

    def coding_to_str(self, coding_separator: str = " ") -> str:
        return coding_separator.join(self.coding)


@dataclass
class DictMeta:
    """词库文件元信息：词库名等配置内容"""

    file: str = None  # 词库文件名
    name: str = None  # 词库名
    category: str = None  # 词库分类
    version: str = None  # 版本
    description: str = None  # 描述信息
    author: str = None  # 作者
    examples: list[str] = None  # 词库示例
    count: int = 0  # 词条数量（可能来自文件内数据，可能是实际解析统计）

    def to_str(self, extra: str | None = None, keep_all: bool = False) -> True:
        """
        keep_all: 保留空白字段
        """
        prefix = "# "
        separator = ": "
        words = ""
        if self.examples:
            words = " ".join([re.sub(r"\s+", "", v) for v in self.examples])
        info_list = [
            ["文件名称", self.file],
            ["词库名称", self.name],
            ["词库分类", self.category],
            ["词库版本", self.version],
            ["词库作者", self.author],
            ["词库描述", self.description],
            ["词条样例", words],
            ["词条数量", self.count],
        ]

        info_text = [
            "".join(map(str, [prefix, key, separator, value]))
            for key, value in info_list
            if keep_all or value
        ]
        if extra:
            info_text.append(extra)
        return "\n".join(info_text)


@dataclass
class DictCell:
    """词库文件"""

    metadata: DictMeta
    words: list[WordEntry] = None

    def __post_init__(self):
        if self.words is None:
            self.words = []


@dataclass
class DictField:
    start: int
    end: int = None


@dataclass
class DictStruct:
    """词库文件结构分段"""

    suffix: str  # 文件后缀
    encoding: str = "utf-16le"  # 编码类型"utf-16le"最常见

    name: DictField = None  # 词库名位置
    category: DictField = None  # 词库分类
    version: DictField = None  # 版本
    description: DictField = None  # 描述信息
    author: DictField = None  # 作者
    examples: DictField = None  # 词库示例
    count: DictField = None  # 词条数量
    code_len: DictField = None  # 编码映射表长度
    code_map: DictField = None  # 编码映射表（一般为拼音）
    words: DictField = None  # 词语列表
    extra: DictField = None  # 额外字段

    def init_end(self, var_list: list[DictField]):
        # 根据后一字段补全end
        n = len(var_list)
        for i in range(1, n):
            if var_list[i]:
                var_list[i - 1].end = var_list[i].start
