# vllm-mock

[![Release](https://img.shields.io/github/v/release/vkehfdl1/vllm-mock)](https://img.shields.io/github/v/release/vkehfdl1/vllm-mock)
[![Build status](https://img.shields.io/github/actions/workflow/status/vkehfdl1/vllm-mock/main.yml?branch=main)](https://github.com/vkehfdl1/vllm-mock/actions/workflows/main.yml?query=branch%3Amain)
[![Commit activity](https://img.shields.io/github/commit-activity/m/vkehfdl1/vllm-mock)](https://img.shields.io/github/commit-activity/m/vkehfdl1/vllm-mock)
[![License](https://img.shields.io/github/license/vkehfdl1/vllm-mock)](https://img.shields.io/github/license/vkehfdl1/vllm-mock)

Provide mock instance to test vllm without CUDA or any GPUs.
