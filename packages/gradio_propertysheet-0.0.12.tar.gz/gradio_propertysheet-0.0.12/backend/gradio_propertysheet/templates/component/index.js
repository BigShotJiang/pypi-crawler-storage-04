var Wl = Object.defineProperty;
var Si = (i) => {
  throw TypeError(i);
};
var Zl = (i, e, t) => e in i ? Wl(i, e, { enumerable: !0, configurable: !0, writable: !0, value: t }) : i[e] = t;
var te = (i, e, t) => Zl(i, typeof e != "symbol" ? e + "" : e, t), Yl = (i, e, t) => e.has(i) || Si("Cannot " + t);
var Ti = (i, e, t) => e.has(i) ? Si("Cannot add the same private member more than once") : e instanceof WeakSet ? e.add(i) : e.set(i, t);
var pn = (i, e, t) => (Yl(i, e, "access private method"), t);
const {
  SvelteComponent: Xl,
  append_hydration: Kn,
  assign: Kl,
  attr: we,
  binding_callbacks: Ql,
  children: Jt,
  claim_element: Ya,
  claim_space: Xa,
  claim_svg_element: Mn,
  create_slot: Jl,
  detach: tt,
  element: Ka,
  empty: Bi,
  get_all_dirty_from_scope: eo,
  get_slot_changes: to,
  get_spread_update: no,
  init: io,
  insert_hydration: ln,
  listen: ao,
  noop: lo,
  safe_not_equal: oo,
  set_dynamic_element_data: Ri,
  set_style: Z,
  space: Qa,
  svg_element: Pn,
  toggle_class: pe,
  transition_in: Ja,
  transition_out: el,
  update_slot_base: ro
} = window.__gradio__svelte__internal;
function Ii(i) {
  let e, t, n, l, o;
  return {
    c() {
      e = Pn("svg"), t = Pn("line"), n = Pn("line"), this.h();
    },
    l(a) {
      e = Mn(a, "svg", { class: !0, xmlns: !0, viewBox: !0 });
      var r = Jt(e);
      t = Mn(r, "line", {
        x1: !0,
        y1: !0,
        x2: !0,
        y2: !0,
        stroke: !0,
        "stroke-width": !0
      }), Jt(t).forEach(tt), n = Mn(r, "line", {
        x1: !0,
        y1: !0,
        x2: !0,
        y2: !0,
        stroke: !0,
        "stroke-width": !0
      }), Jt(n).forEach(tt), r.forEach(tt), this.h();
    },
    h() {
      we(t, "x1", "1"), we(t, "y1", "9"), we(t, "x2", "9"), we(t, "y2", "1"), we(t, "stroke", "gray"), we(t, "stroke-width", "0.5"), we(n, "x1", "5"), we(n, "y1", "9"), we(n, "x2", "9"), we(n, "y2", "5"), we(n, "stroke", "gray"), we(n, "stroke-width", "0.5"), we(e, "class", "resize-handle svelte-239wnu"), we(e, "xmlns", "http://www.w3.org/2000/svg"), we(e, "viewBox", "0 0 10 10");
    },
    m(a, r) {
      ln(a, e, r), Kn(e, t), Kn(e, n), l || (o = ao(
        e,
        "mousedown",
        /*resize*/
        i[27]
      ), l = !0);
    },
    p: lo,
    d(a) {
      a && tt(e), l = !1, o();
    }
  };
}
function so(i) {
  var m;
  let e, t, n, l, o;
  const a = (
    /*#slots*/
    i[31].default
  ), r = Jl(
    a,
    i,
    /*$$scope*/
    i[30],
    null
  );
  let s = (
    /*resizable*/
    i[19] && Ii(i)
  ), u = [
    { "data-testid": (
      /*test_id*/
      i[11]
    ) },
    { id: (
      /*elem_id*/
      i[6]
    ) },
    {
      class: n = "block " + /*elem_classes*/
      (((m = i[7]) == null ? void 0 : m.join(" ")) || "") + " svelte-239wnu"
    },
    {
      dir: l = /*rtl*/
      i[20] ? "rtl" : "ltr"
    }
  ], c = {};
  for (let f = 0; f < u.length; f += 1)
    c = Kl(c, u[f]);
  return {
    c() {
      e = Ka(
        /*tag*/
        i[25]
      ), r && r.c(), t = Qa(), s && s.c(), this.h();
    },
    l(f) {
      e = Ya(
        f,
        /*tag*/
        (i[25] || "null").toUpperCase(),
        {
          "data-testid": !0,
          id: !0,
          class: !0,
          dir: !0
        }
      );
      var d = Jt(e);
      r && r.l(d), t = Xa(d), s && s.l(d), d.forEach(tt), this.h();
    },
    h() {
      Ri(
        /*tag*/
        i[25]
      )(e, c), pe(
        e,
        "hidden",
        /*visible*/
        i[14] === !1
      ), pe(
        e,
        "padded",
        /*padding*/
        i[10]
      ), pe(
        e,
        "flex",
        /*flex*/
        i[1]
      ), pe(
        e,
        "border_focus",
        /*border_mode*/
        i[9] === "focus"
      ), pe(
        e,
        "border_contrast",
        /*border_mode*/
        i[9] === "contrast"
      ), pe(e, "hide-container", !/*explicit_call*/
      i[12] && !/*container*/
      i[13]), pe(
        e,
        "fullscreen",
        /*fullscreen*/
        i[0]
      ), pe(
        e,
        "animating",
        /*fullscreen*/
        i[0] && /*preexpansionBoundingRect*/
        i[24] !== null
      ), pe(
        e,
        "auto-margin",
        /*scale*/
        i[17] === null
      ), Z(
        e,
        "height",
        /*fullscreen*/
        i[0] ? void 0 : (
          /*get_dimension*/
          i[26](
            /*height*/
            i[2]
          )
        )
      ), Z(
        e,
        "min-height",
        /*fullscreen*/
        i[0] ? void 0 : (
          /*get_dimension*/
          i[26](
            /*min_height*/
            i[3]
          )
        )
      ), Z(
        e,
        "max-height",
        /*fullscreen*/
        i[0] ? void 0 : (
          /*get_dimension*/
          i[26](
            /*max_height*/
            i[4]
          )
        )
      ), Z(
        e,
        "--start-top",
        /*preexpansionBoundingRect*/
        i[24] ? `${/*preexpansionBoundingRect*/
        i[24].top}px` : "0px"
      ), Z(
        e,
        "--start-left",
        /*preexpansionBoundingRect*/
        i[24] ? `${/*preexpansionBoundingRect*/
        i[24].left}px` : "0px"
      ), Z(
        e,
        "--start-width",
        /*preexpansionBoundingRect*/
        i[24] ? `${/*preexpansionBoundingRect*/
        i[24].width}px` : "0px"
      ), Z(
        e,
        "--start-height",
        /*preexpansionBoundingRect*/
        i[24] ? `${/*preexpansionBoundingRect*/
        i[24].height}px` : "0px"
      ), Z(
        e,
        "width",
        /*fullscreen*/
        i[0] ? void 0 : typeof /*width*/
        i[5] == "number" ? `calc(min(${/*width*/
        i[5]}px, 100%))` : (
          /*get_dimension*/
          i[26](
            /*width*/
            i[5]
          )
        )
      ), Z(
        e,
        "border-style",
        /*variant*/
        i[8]
      ), Z(
        e,
        "overflow",
        /*allow_overflow*/
        i[15] ? (
          /*overflow_behavior*/
          i[16]
        ) : "hidden"
      ), Z(
        e,
        "flex-grow",
        /*scale*/
        i[17]
      ), Z(e, "min-width", `calc(min(${/*min_width*/
      i[18]}px, 100%))`), Z(e, "border-width", "var(--block-border-width)");
    },
    m(f, d) {
      ln(f, e, d), r && r.m(e, null), Kn(e, t), s && s.m(e, null), i[32](e), o = !0;
    },
    p(f, d) {
      var v;
      r && r.p && (!o || d[0] & /*$$scope*/
      1073741824) && ro(
        r,
        a,
        f,
        /*$$scope*/
        f[30],
        o ? to(
          a,
          /*$$scope*/
          f[30],
          d,
          null
        ) : eo(
          /*$$scope*/
          f[30]
        ),
        null
      ), /*resizable*/
      f[19] ? s ? s.p(f, d) : (s = Ii(f), s.c(), s.m(e, null)) : s && (s.d(1), s = null), Ri(
        /*tag*/
        f[25]
      )(e, c = no(u, [
        (!o || d[0] & /*test_id*/
        2048) && { "data-testid": (
          /*test_id*/
          f[11]
        ) },
        (!o || d[0] & /*elem_id*/
        64) && { id: (
          /*elem_id*/
          f[6]
        ) },
        (!o || d[0] & /*elem_classes*/
        128 && n !== (n = "block " + /*elem_classes*/
        (((v = f[7]) == null ? void 0 : v.join(" ")) || "") + " svelte-239wnu")) && { class: n },
        (!o || d[0] & /*rtl*/
        1048576 && l !== (l = /*rtl*/
        f[20] ? "rtl" : "ltr")) && { dir: l }
      ])), pe(
        e,
        "hidden",
        /*visible*/
        f[14] === !1
      ), pe(
        e,
        "padded",
        /*padding*/
        f[10]
      ), pe(
        e,
        "flex",
        /*flex*/
        f[1]
      ), pe(
        e,
        "border_focus",
        /*border_mode*/
        f[9] === "focus"
      ), pe(
        e,
        "border_contrast",
        /*border_mode*/
        f[9] === "contrast"
      ), pe(e, "hide-container", !/*explicit_call*/
      f[12] && !/*container*/
      f[13]), pe(
        e,
        "fullscreen",
        /*fullscreen*/
        f[0]
      ), pe(
        e,
        "animating",
        /*fullscreen*/
        f[0] && /*preexpansionBoundingRect*/
        f[24] !== null
      ), pe(
        e,
        "auto-margin",
        /*scale*/
        f[17] === null
      ), d[0] & /*fullscreen, height*/
      5 && Z(
        e,
        "height",
        /*fullscreen*/
        f[0] ? void 0 : (
          /*get_dimension*/
          f[26](
            /*height*/
            f[2]
          )
        )
      ), d[0] & /*fullscreen, min_height*/
      9 && Z(
        e,
        "min-height",
        /*fullscreen*/
        f[0] ? void 0 : (
          /*get_dimension*/
          f[26](
            /*min_height*/
            f[3]
          )
        )
      ), d[0] & /*fullscreen, max_height*/
      17 && Z(
        e,
        "max-height",
        /*fullscreen*/
        f[0] ? void 0 : (
          /*get_dimension*/
          f[26](
            /*max_height*/
            f[4]
          )
        )
      ), d[0] & /*preexpansionBoundingRect*/
      16777216 && Z(
        e,
        "--start-top",
        /*preexpansionBoundingRect*/
        f[24] ? `${/*preexpansionBoundingRect*/
        f[24].top}px` : "0px"
      ), d[0] & /*preexpansionBoundingRect*/
      16777216 && Z(
        e,
        "--start-left",
        /*preexpansionBoundingRect*/
        f[24] ? `${/*preexpansionBoundingRect*/
        f[24].left}px` : "0px"
      ), d[0] & /*preexpansionBoundingRect*/
      16777216 && Z(
        e,
        "--start-width",
        /*preexpansionBoundingRect*/
        f[24] ? `${/*preexpansionBoundingRect*/
        f[24].width}px` : "0px"
      ), d[0] & /*preexpansionBoundingRect*/
      16777216 && Z(
        e,
        "--start-height",
        /*preexpansionBoundingRect*/
        f[24] ? `${/*preexpansionBoundingRect*/
        f[24].height}px` : "0px"
      ), d[0] & /*fullscreen, width*/
      33 && Z(
        e,
        "width",
        /*fullscreen*/
        f[0] ? void 0 : typeof /*width*/
        f[5] == "number" ? `calc(min(${/*width*/
        f[5]}px, 100%))` : (
          /*get_dimension*/
          f[26](
            /*width*/
            f[5]
          )
        )
      ), d[0] & /*variant*/
      256 && Z(
        e,
        "border-style",
        /*variant*/
        f[8]
      ), d[0] & /*allow_overflow, overflow_behavior*/
      98304 && Z(
        e,
        "overflow",
        /*allow_overflow*/
        f[15] ? (
          /*overflow_behavior*/
          f[16]
        ) : "hidden"
      ), d[0] & /*scale*/
      131072 && Z(
        e,
        "flex-grow",
        /*scale*/
        f[17]
      ), d[0] & /*min_width*/
      262144 && Z(e, "min-width", `calc(min(${/*min_width*/
      f[18]}px, 100%))`);
    },
    i(f) {
      o || (Ja(r, f), o = !0);
    },
    o(f) {
      el(r, f), o = !1;
    },
    d(f) {
      f && tt(e), r && r.d(f), s && s.d(), i[32](null);
    }
  };
}
function Li(i) {
  let e;
  return {
    c() {
      e = Ka("div"), this.h();
    },
    l(t) {
      e = Ya(t, "DIV", { class: !0 }), Jt(e).forEach(tt), this.h();
    },
    h() {
      we(e, "class", "placeholder svelte-239wnu"), Z(
        e,
        "height",
        /*placeholder_height*/
        i[22] + "px"
      ), Z(
        e,
        "width",
        /*placeholder_width*/
        i[23] + "px"
      );
    },
    m(t, n) {
      ln(t, e, n);
    },
    p(t, n) {
      n[0] & /*placeholder_height*/
      4194304 && Z(
        e,
        "height",
        /*placeholder_height*/
        t[22] + "px"
      ), n[0] & /*placeholder_width*/
      8388608 && Z(
        e,
        "width",
        /*placeholder_width*/
        t[23] + "px"
      );
    },
    d(t) {
      t && tt(e);
    }
  };
}
function uo(i) {
  let e, t, n, l = (
    /*tag*/
    i[25] && so(i)
  ), o = (
    /*fullscreen*/
    i[0] && Li(i)
  );
  return {
    c() {
      l && l.c(), e = Qa(), o && o.c(), t = Bi();
    },
    l(a) {
      l && l.l(a), e = Xa(a), o && o.l(a), t = Bi();
    },
    m(a, r) {
      l && l.m(a, r), ln(a, e, r), o && o.m(a, r), ln(a, t, r), n = !0;
    },
    p(a, r) {
      /*tag*/
      a[25] && l.p(a, r), /*fullscreen*/
      a[0] ? o ? o.p(a, r) : (o = Li(a), o.c(), o.m(t.parentNode, t)) : o && (o.d(1), o = null);
    },
    i(a) {
      n || (Ja(l, a), n = !0);
    },
    o(a) {
      el(l, a), n = !1;
    },
    d(a) {
      a && (tt(e), tt(t)), l && l.d(a), o && o.d(a);
    }
  };
}
function co(i, e, t) {
  let { $$slots: n = {}, $$scope: l } = e, { height: o = void 0 } = e, { min_height: a = void 0 } = e, { max_height: r = void 0 } = e, { width: s = void 0 } = e, { elem_id: u = "" } = e, { elem_classes: c = [] } = e, { variant: m = "solid" } = e, { border_mode: f = "base" } = e, { padding: d = !0 } = e, { type: v = "normal" } = e, { test_id: y = void 0 } = e, { explicit_call: w = !1 } = e, { container: C = !0 } = e, { visible: h = !0 } = e, { allow_overflow: _ = !0 } = e, { overflow_behavior: g = "auto" } = e, { scale: b = null } = e, { min_width: F = 0 } = e, { flex: A = !1 } = e, { resizable: T = !1 } = e, { rtl: S = !1 } = e, { fullscreen: N = !1 } = e, x = N, U, $e = v === "fieldset" ? "fieldset" : "div", ue = 0, ke = 0, _e = null;
  function le($) {
    N && $.key === "Escape" && t(0, N = !1);
  }
  const K = ($) => {
    if ($ !== void 0) {
      if (typeof $ == "number")
        return $ + "px";
      if (typeof $ == "string")
        return $;
    }
  }, re = ($) => {
    let oe = $.clientY;
    const Q = (E) => {
      const Se = E.clientY - oe;
      oe = E.clientY, t(21, U.style.height = `${U.offsetHeight + Se}px`, U);
    }, de = () => {
      window.removeEventListener("mousemove", Q), window.removeEventListener("mouseup", de);
    };
    window.addEventListener("mousemove", Q), window.addEventListener("mouseup", de);
  };
  function ge($) {
    Ql[$ ? "unshift" : "push"](() => {
      U = $, t(21, U);
    });
  }
  return i.$$set = ($) => {
    "height" in $ && t(2, o = $.height), "min_height" in $ && t(3, a = $.min_height), "max_height" in $ && t(4, r = $.max_height), "width" in $ && t(5, s = $.width), "elem_id" in $ && t(6, u = $.elem_id), "elem_classes" in $ && t(7, c = $.elem_classes), "variant" in $ && t(8, m = $.variant), "border_mode" in $ && t(9, f = $.border_mode), "padding" in $ && t(10, d = $.padding), "type" in $ && t(28, v = $.type), "test_id" in $ && t(11, y = $.test_id), "explicit_call" in $ && t(12, w = $.explicit_call), "container" in $ && t(13, C = $.container), "visible" in $ && t(14, h = $.visible), "allow_overflow" in $ && t(15, _ = $.allow_overflow), "overflow_behavior" in $ && t(16, g = $.overflow_behavior), "scale" in $ && t(17, b = $.scale), "min_width" in $ && t(18, F = $.min_width), "flex" in $ && t(1, A = $.flex), "resizable" in $ && t(19, T = $.resizable), "rtl" in $ && t(20, S = $.rtl), "fullscreen" in $ && t(0, N = $.fullscreen), "$$scope" in $ && t(30, l = $.$$scope);
  }, i.$$.update = () => {
    i.$$.dirty[0] & /*fullscreen, old_fullscreen, element*/
    538968065 && N !== x && (t(29, x = N), N ? (t(24, _e = U.getBoundingClientRect()), t(22, ue = U.offsetHeight), t(23, ke = U.offsetWidth), window.addEventListener("keydown", le)) : (t(24, _e = null), window.removeEventListener("keydown", le))), i.$$.dirty[0] & /*visible*/
    16384 && (h || t(1, A = !1));
  }, [
    N,
    A,
    o,
    a,
    r,
    s,
    u,
    c,
    m,
    f,
    d,
    y,
    w,
    C,
    h,
    _,
    g,
    b,
    F,
    T,
    S,
    U,
    ue,
    ke,
    _e,
    $e,
    K,
    re,
    v,
    x,
    l,
    n,
    ge
  ];
}
class _o extends Xl {
  constructor(e) {
    super(), io(
      this,
      e,
      co,
      uo,
      oo,
      {
        height: 2,
        min_height: 3,
        max_height: 4,
        width: 5,
        elem_id: 6,
        elem_classes: 7,
        variant: 8,
        border_mode: 9,
        padding: 10,
        type: 28,
        test_id: 11,
        explicit_call: 12,
        container: 13,
        visible: 14,
        allow_overflow: 15,
        overflow_behavior: 16,
        scale: 17,
        min_width: 18,
        flex: 1,
        resizable: 19,
        rtl: 20,
        fullscreen: 0
      },
      null,
      [-1, -1]
    );
  }
}
function ci() {
  return {
    async: !1,
    breaks: !1,
    extensions: null,
    gfm: !0,
    hooks: null,
    pedantic: !1,
    renderer: null,
    silent: !1,
    tokenizer: null,
    walkTokens: null
  };
}
let Tt = ci();
function tl(i) {
  Tt = i;
}
const nl = /[&<>"']/, fo = new RegExp(nl.source, "g"), il = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, po = new RegExp(il.source, "g"), ho = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, Oi = (i) => ho[i];
function Re(i, e) {
  if (e) {
    if (nl.test(i))
      return i.replace(fo, Oi);
  } else if (il.test(i))
    return i.replace(po, Oi);
  return i;
}
const mo = /&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/ig;
function go(i) {
  return i.replace(mo, (e, t) => (t = t.toLowerCase(), t === "colon" ? ":" : t.charAt(0) === "#" ? t.charAt(1) === "x" ? String.fromCharCode(parseInt(t.substring(2), 16)) : String.fromCharCode(+t.substring(1)) : ""));
}
const vo = /(^|[^\[])\^/g;
function X(i, e) {
  let t = typeof i == "string" ? i : i.source;
  e = e || "";
  const n = {
    replace: (l, o) => {
      let a = typeof o == "string" ? o : o.source;
      return a = a.replace(vo, "$1"), t = t.replace(l, a), n;
    },
    getRegex: () => new RegExp(t, e)
  };
  return n;
}
function qi(i) {
  try {
    i = encodeURI(i).replace(/%25/g, "%");
  } catch {
    return null;
  }
  return i;
}
const en = { exec: () => null };
function xi(i, e) {
  const t = i.replace(/\|/g, (o, a, r) => {
    let s = !1, u = a;
    for (; --u >= 0 && r[u] === "\\"; )
      s = !s;
    return s ? "|" : " |";
  }), n = t.split(/ \|/);
  let l = 0;
  if (n[0].trim() || n.shift(), n.length > 0 && !n[n.length - 1].trim() && n.pop(), e)
    if (n.length > e)
      n.splice(e);
    else
      for (; n.length < e; )
        n.push("");
  for (; l < n.length; l++)
    n[l] = n[l].trim().replace(/\\\|/g, "|");
  return n;
}
function hn(i, e, t) {
  const n = i.length;
  if (n === 0)
    return "";
  let l = 0;
  for (; l < n && i.charAt(n - l - 1) === e; )
    l++;
  return i.slice(0, n - l);
}
function Do(i, e) {
  if (i.indexOf(e[1]) === -1)
    return -1;
  let t = 0;
  for (let n = 0; n < i.length; n++)
    if (i[n] === "\\")
      n++;
    else if (i[n] === e[0])
      t++;
    else if (i[n] === e[1] && (t--, t < 0))
      return n;
  return -1;
}
function Ni(i, e, t, n) {
  const l = e.href, o = e.title ? Re(e.title) : null, a = i[1].replace(/\\([\[\]])/g, "$1");
  if (i[0].charAt(0) !== "!") {
    n.state.inLink = !0;
    const r = {
      type: "link",
      raw: t,
      href: l,
      title: o,
      text: a,
      tokens: n.inlineTokens(a)
    };
    return n.state.inLink = !1, r;
  }
  return {
    type: "image",
    raw: t,
    href: l,
    title: o,
    text: Re(a)
  };
}
function bo(i, e) {
  const t = i.match(/^(\s+)(?:```)/);
  if (t === null)
    return e;
  const n = t[1];
  return e.split(`
`).map((l) => {
    const o = l.match(/^\s+/);
    if (o === null)
      return l;
    const [a] = o;
    return a.length >= n.length ? l.slice(n.length) : l;
  }).join(`
`);
}
class Cn {
  // set by the lexer
  constructor(e) {
    te(this, "options");
    te(this, "rules");
    // set by the lexer
    te(this, "lexer");
    this.options = e || Tt;
  }
  space(e) {
    const t = this.rules.block.newline.exec(e);
    if (t && t[0].length > 0)
      return {
        type: "space",
        raw: t[0]
      };
  }
  code(e) {
    const t = this.rules.block.code.exec(e);
    if (t) {
      const n = t[0].replace(/^ {1,4}/gm, "");
      return {
        type: "code",
        raw: t[0],
        codeBlockStyle: "indented",
        text: this.options.pedantic ? n : hn(n, `
`)
      };
    }
  }
  fences(e) {
    const t = this.rules.block.fences.exec(e);
    if (t) {
      const n = t[0], l = bo(n, t[3] || "");
      return {
        type: "code",
        raw: n,
        lang: t[2] ? t[2].trim().replace(this.rules.inline.anyPunctuation, "$1") : t[2],
        text: l
      };
    }
  }
  heading(e) {
    const t = this.rules.block.heading.exec(e);
    if (t) {
      let n = t[2].trim();
      if (/#$/.test(n)) {
        const l = hn(n, "#");
        (this.options.pedantic || !l || / $/.test(l)) && (n = l.trim());
      }
      return {
        type: "heading",
        raw: t[0],
        depth: t[1].length,
        text: n,
        tokens: this.lexer.inline(n)
      };
    }
  }
  hr(e) {
    const t = this.rules.block.hr.exec(e);
    if (t)
      return {
        type: "hr",
        raw: t[0]
      };
  }
  blockquote(e) {
    const t = this.rules.block.blockquote.exec(e);
    if (t) {
      let n = t[0].replace(/\n {0,3}((?:=+|-+) *)(?=\n|$)/g, `
    $1`);
      n = hn(n.replace(/^ *>[ \t]?/gm, ""), `
`);
      const l = this.lexer.state.top;
      this.lexer.state.top = !0;
      const o = this.lexer.blockTokens(n);
      return this.lexer.state.top = l, {
        type: "blockquote",
        raw: t[0],
        tokens: o,
        text: n
      };
    }
  }
  list(e) {
    let t = this.rules.block.list.exec(e);
    if (t) {
      let n = t[1].trim();
      const l = n.length > 1, o = {
        type: "list",
        raw: "",
        ordered: l,
        start: l ? +n.slice(0, -1) : "",
        loose: !1,
        items: []
      };
      n = l ? `\\d{1,9}\\${n.slice(-1)}` : `\\${n}`, this.options.pedantic && (n = l ? n : "[*+-]");
      const a = new RegExp(`^( {0,3}${n})((?:[	 ][^\\n]*)?(?:\\n|$))`);
      let r = "", s = "", u = !1;
      for (; e; ) {
        let c = !1;
        if (!(t = a.exec(e)) || this.rules.block.hr.test(e))
          break;
        r = t[0], e = e.substring(r.length);
        let m = t[2].split(`
`, 1)[0].replace(/^\t+/, (C) => " ".repeat(3 * C.length)), f = e.split(`
`, 1)[0], d = 0;
        this.options.pedantic ? (d = 2, s = m.trimStart()) : (d = t[2].search(/[^ ]/), d = d > 4 ? 1 : d, s = m.slice(d), d += t[1].length);
        let v = !1;
        if (!m && /^ *$/.test(f) && (r += f + `
`, e = e.substring(f.length + 1), c = !0), !c) {
          const C = new RegExp(`^ {0,${Math.min(3, d - 1)}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`), h = new RegExp(`^ {0,${Math.min(3, d - 1)}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)`), _ = new RegExp(`^ {0,${Math.min(3, d - 1)}}(?:\`\`\`|~~~)`), g = new RegExp(`^ {0,${Math.min(3, d - 1)}}#`);
          for (; e; ) {
            const b = e.split(`
`, 1)[0];
            if (f = b, this.options.pedantic && (f = f.replace(/^ {1,4}(?=( {4})*[^ ])/g, "  ")), _.test(f) || g.test(f) || C.test(f) || h.test(e))
              break;
            if (f.search(/[^ ]/) >= d || !f.trim())
              s += `
` + f.slice(d);
            else {
              if (v || m.search(/[^ ]/) >= 4 || _.test(m) || g.test(m) || h.test(m))
                break;
              s += `
` + f;
            }
            !v && !f.trim() && (v = !0), r += b + `
`, e = e.substring(b.length + 1), m = f.slice(d);
          }
        }
        o.loose || (u ? o.loose = !0 : /\n *\n *$/.test(r) && (u = !0));
        let y = null, w;
        this.options.gfm && (y = /^\[[ xX]\] /.exec(s), y && (w = y[0] !== "[ ] ", s = s.replace(/^\[[ xX]\] +/, ""))), o.items.push({
          type: "list_item",
          raw: r,
          task: !!y,
          checked: w,
          loose: !1,
          text: s,
          tokens: []
        }), o.raw += r;
      }
      o.items[o.items.length - 1].raw = r.trimEnd(), o.items[o.items.length - 1].text = s.trimEnd(), o.raw = o.raw.trimEnd();
      for (let c = 0; c < o.items.length; c++)
        if (this.lexer.state.top = !1, o.items[c].tokens = this.lexer.blockTokens(o.items[c].text, []), !o.loose) {
          const m = o.items[c].tokens.filter((d) => d.type === "space"), f = m.length > 0 && m.some((d) => /\n.*\n/.test(d.raw));
          o.loose = f;
        }
      if (o.loose)
        for (let c = 0; c < o.items.length; c++)
          o.items[c].loose = !0;
      return o;
    }
  }
  html(e) {
    const t = this.rules.block.html.exec(e);
    if (t)
      return {
        type: "html",
        block: !0,
        raw: t[0],
        pre: t[1] === "pre" || t[1] === "script" || t[1] === "style",
        text: t[0]
      };
  }
  def(e) {
    const t = this.rules.block.def.exec(e);
    if (t) {
      const n = t[1].toLowerCase().replace(/\s+/g, " "), l = t[2] ? t[2].replace(/^<(.*)>$/, "$1").replace(this.rules.inline.anyPunctuation, "$1") : "", o = t[3] ? t[3].substring(1, t[3].length - 1).replace(this.rules.inline.anyPunctuation, "$1") : t[3];
      return {
        type: "def",
        tag: n,
        raw: t[0],
        href: l,
        title: o
      };
    }
  }
  table(e) {
    const t = this.rules.block.table.exec(e);
    if (!t || !/[:|]/.test(t[2]))
      return;
    const n = xi(t[1]), l = t[2].replace(/^\||\| *$/g, "").split("|"), o = t[3] && t[3].trim() ? t[3].replace(/\n[ \t]*$/, "").split(`
`) : [], a = {
      type: "table",
      raw: t[0],
      header: [],
      align: [],
      rows: []
    };
    if (n.length === l.length) {
      for (const r of l)
        /^ *-+: *$/.test(r) ? a.align.push("right") : /^ *:-+: *$/.test(r) ? a.align.push("center") : /^ *:-+ *$/.test(r) ? a.align.push("left") : a.align.push(null);
      for (const r of n)
        a.header.push({
          text: r,
          tokens: this.lexer.inline(r)
        });
      for (const r of o)
        a.rows.push(xi(r, a.header.length).map((s) => ({
          text: s,
          tokens: this.lexer.inline(s)
        })));
      return a;
    }
  }
  lheading(e) {
    const t = this.rules.block.lheading.exec(e);
    if (t)
      return {
        type: "heading",
        raw: t[0],
        depth: t[2].charAt(0) === "=" ? 1 : 2,
        text: t[1],
        tokens: this.lexer.inline(t[1])
      };
  }
  paragraph(e) {
    const t = this.rules.block.paragraph.exec(e);
    if (t) {
      const n = t[1].charAt(t[1].length - 1) === `
` ? t[1].slice(0, -1) : t[1];
      return {
        type: "paragraph",
        raw: t[0],
        text: n,
        tokens: this.lexer.inline(n)
      };
    }
  }
  text(e) {
    const t = this.rules.block.text.exec(e);
    if (t)
      return {
        type: "text",
        raw: t[0],
        text: t[0],
        tokens: this.lexer.inline(t[0])
      };
  }
  escape(e) {
    const t = this.rules.inline.escape.exec(e);
    if (t)
      return {
        type: "escape",
        raw: t[0],
        text: Re(t[1])
      };
  }
  tag(e) {
    const t = this.rules.inline.tag.exec(e);
    if (t)
      return !this.lexer.state.inLink && /^<a /i.test(t[0]) ? this.lexer.state.inLink = !0 : this.lexer.state.inLink && /^<\/a>/i.test(t[0]) && (this.lexer.state.inLink = !1), !this.lexer.state.inRawBlock && /^<(pre|code|kbd|script)(\s|>)/i.test(t[0]) ? this.lexer.state.inRawBlock = !0 : this.lexer.state.inRawBlock && /^<\/(pre|code|kbd|script)(\s|>)/i.test(t[0]) && (this.lexer.state.inRawBlock = !1), {
        type: "html",
        raw: t[0],
        inLink: this.lexer.state.inLink,
        inRawBlock: this.lexer.state.inRawBlock,
        block: !1,
        text: t[0]
      };
  }
  link(e) {
    const t = this.rules.inline.link.exec(e);
    if (t) {
      const n = t[2].trim();
      if (!this.options.pedantic && /^</.test(n)) {
        if (!/>$/.test(n))
          return;
        const a = hn(n.slice(0, -1), "\\");
        if ((n.length - a.length) % 2 === 0)
          return;
      } else {
        const a = Do(t[2], "()");
        if (a > -1) {
          const s = (t[0].indexOf("!") === 0 ? 5 : 4) + t[1].length + a;
          t[2] = t[2].substring(0, a), t[0] = t[0].substring(0, s).trim(), t[3] = "";
        }
      }
      let l = t[2], o = "";
      if (this.options.pedantic) {
        const a = /^([^'"]*[^\s])\s+(['"])(.*)\2/.exec(l);
        a && (l = a[1], o = a[3]);
      } else
        o = t[3] ? t[3].slice(1, -1) : "";
      return l = l.trim(), /^</.test(l) && (this.options.pedantic && !/>$/.test(n) ? l = l.slice(1) : l = l.slice(1, -1)), Ni(t, {
        href: l && l.replace(this.rules.inline.anyPunctuation, "$1"),
        title: o && o.replace(this.rules.inline.anyPunctuation, "$1")
      }, t[0], this.lexer);
    }
  }
  reflink(e, t) {
    let n;
    if ((n = this.rules.inline.reflink.exec(e)) || (n = this.rules.inline.nolink.exec(e))) {
      const l = (n[2] || n[1]).replace(/\s+/g, " "), o = t[l.toLowerCase()];
      if (!o) {
        const a = n[0].charAt(0);
        return {
          type: "text",
          raw: a,
          text: a
        };
      }
      return Ni(n, o, n[0], this.lexer);
    }
  }
  emStrong(e, t, n = "") {
    let l = this.rules.inline.emStrongLDelim.exec(e);
    if (!l || l[3] && n.match(/[\p{L}\p{N}]/u))
      return;
    if (!(l[1] || l[2] || "") || !n || this.rules.inline.punctuation.exec(n)) {
      const a = [...l[0]].length - 1;
      let r, s, u = a, c = 0;
      const m = l[0][0] === "*" ? this.rules.inline.emStrongRDelimAst : this.rules.inline.emStrongRDelimUnd;
      for (m.lastIndex = 0, t = t.slice(-1 * e.length + a); (l = m.exec(t)) != null; ) {
        if (r = l[1] || l[2] || l[3] || l[4] || l[5] || l[6], !r)
          continue;
        if (s = [...r].length, l[3] || l[4]) {
          u += s;
          continue;
        } else if ((l[5] || l[6]) && a % 3 && !((a + s) % 3)) {
          c += s;
          continue;
        }
        if (u -= s, u > 0)
          continue;
        s = Math.min(s, s + u + c);
        const f = [...l[0]][0].length, d = e.slice(0, a + l.index + f + s);
        if (Math.min(a, s) % 2) {
          const y = d.slice(1, -1);
          return {
            type: "em",
            raw: d,
            text: y,
            tokens: this.lexer.inlineTokens(y)
          };
        }
        const v = d.slice(2, -2);
        return {
          type: "strong",
          raw: d,
          text: v,
          tokens: this.lexer.inlineTokens(v)
        };
      }
    }
  }
  codespan(e) {
    const t = this.rules.inline.code.exec(e);
    if (t) {
      let n = t[2].replace(/\n/g, " ");
      const l = /[^ ]/.test(n), o = /^ /.test(n) && / $/.test(n);
      return l && o && (n = n.substring(1, n.length - 1)), n = Re(n, !0), {
        type: "codespan",
        raw: t[0],
        text: n
      };
    }
  }
  br(e) {
    const t = this.rules.inline.br.exec(e);
    if (t)
      return {
        type: "br",
        raw: t[0]
      };
  }
  del(e) {
    const t = this.rules.inline.del.exec(e);
    if (t)
      return {
        type: "del",
        raw: t[0],
        text: t[2],
        tokens: this.lexer.inlineTokens(t[2])
      };
  }
  autolink(e) {
    const t = this.rules.inline.autolink.exec(e);
    if (t) {
      let n, l;
      return t[2] === "@" ? (n = Re(t[1]), l = "mailto:" + n) : (n = Re(t[1]), l = n), {
        type: "link",
        raw: t[0],
        text: n,
        href: l,
        tokens: [
          {
            type: "text",
            raw: n,
            text: n
          }
        ]
      };
    }
  }
  url(e) {
    var n;
    let t;
    if (t = this.rules.inline.url.exec(e)) {
      let l, o;
      if (t[2] === "@")
        l = Re(t[0]), o = "mailto:" + l;
      else {
        let a;
        do
          a = t[0], t[0] = ((n = this.rules.inline._backpedal.exec(t[0])) == null ? void 0 : n[0]) ?? "";
        while (a !== t[0]);
        l = Re(t[0]), t[1] === "www." ? o = "http://" + t[0] : o = t[0];
      }
      return {
        type: "link",
        raw: t[0],
        text: l,
        href: o,
        tokens: [
          {
            type: "text",
            raw: l,
            text: l
          }
        ]
      };
    }
  }
  inlineText(e) {
    const t = this.rules.inline.text.exec(e);
    if (t) {
      let n;
      return this.lexer.state.inRawBlock ? n = t[0] : n = Re(t[0]), {
        type: "text",
        raw: t[0],
        text: n
      };
    }
  }
}
const yo = /^(?: *(?:\n|$))+/, wo = /^( {4}[^\n]+(?:\n(?: *(?:\n|$))*)?)+/, Fo = /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/, on = /^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/, $o = /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/, al = /(?:[*+-]|\d{1,9}[.)])/, ll = X(/^(?!bull |blockCode|fences|blockquote|heading|html)((?:.|\n(?!\s*?\n|bull |blockCode|fences|blockquote|heading|html))+?)\n {0,3}(=+|-+) *(?:\n+|$)/).replace(/bull/g, al).replace(/blockCode/g, / {4}/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).getRegex(), _i = /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/, ko = /^[^\n]+/, di = /(?!\s*\])(?:\\.|[^\[\]\\])+/, Eo = X(/^ {0,3}\[(label)\]: *(?:\n *)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n *)?| *\n *)(title))? *(?:\n+|$)/).replace("label", di).replace("title", /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/).getRegex(), Ao = X(/^( {0,3}bull)([ \t][^\n]+?)?(?:\n|$)/).replace(/bull/g, al).getRegex(), In = "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul", fi = /<!--(?:-?>|[\s\S]*?(?:-->|$))/, Co = X("^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>\\n*|$)|<![A-Z][\\s\\S]*?(?:>\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n *)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$))", "i").replace("comment", fi).replace("tag", In).replace("attribute", / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex(), ol = X(_i).replace("hr", on).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("|table", "").replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", In).getRegex(), So = X(/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/).replace("paragraph", ol).getRegex(), pi = {
  blockquote: So,
  code: wo,
  def: Eo,
  fences: Fo,
  heading: $o,
  hr: on,
  html: Co,
  lheading: ll,
  list: Ao,
  newline: yo,
  paragraph: ol,
  table: en,
  text: ko
}, Mi = X("^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)").replace("hr", on).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("blockquote", " {0,3}>").replace("code", " {4}[^\\n]").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", In).getRegex(), To = {
  ...pi,
  table: Mi,
  paragraph: X(_i).replace("hr", on).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("table", Mi).replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", In).getRegex()
}, Bo = {
  ...pi,
  html: X(`^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`).replace("comment", fi).replace(/tag/g, "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(),
  def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/,
  heading: /^(#{1,6})(.*)(?:\n+|$)/,
  fences: en,
  // fences not supported
  lheading: /^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/,
  paragraph: X(_i).replace("hr", on).replace("heading", ` *#{1,6} *[^
]`).replace("lheading", ll).replace("|table", "").replace("blockquote", " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html", "").replace("|tag", "").getRegex()
}, rl = /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/, Ro = /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/, sl = /^( {2,}|\\)\n(?!\s*$)/, Io = /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/, rn = "\\p{P}\\p{S}", Lo = X(/^((?![*_])[\spunctuation])/, "u").replace(/punctuation/g, rn).getRegex(), Oo = /\[[^[\]]*?\]\([^\(\)]*?\)|`[^`]*?`|<[^<>]*?>/g, qo = X(/^(?:\*+(?:((?!\*)[punct])|[^\s*]))|^_+(?:((?!_)[punct])|([^\s_]))/, "u").replace(/punct/g, rn).getRegex(), xo = X("^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)[punct](\\*+)(?=[\\s]|$)|[^punct\\s](\\*+)(?!\\*)(?=[punct\\s]|$)|(?!\\*)[punct\\s](\\*+)(?=[^punct\\s])|[\\s](\\*+)(?!\\*)(?=[punct])|(?!\\*)[punct](\\*+)(?!\\*)(?=[punct])|[^punct\\s](\\*+)(?=[^punct\\s])", "gu").replace(/punct/g, rn).getRegex(), No = X("^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)[punct](_+)(?=[\\s]|$)|[^punct\\s](_+)(?!_)(?=[punct\\s]|$)|(?!_)[punct\\s](_+)(?=[^punct\\s])|[\\s](_+)(?!_)(?=[punct])|(?!_)[punct](_+)(?!_)(?=[punct])", "gu").replace(/punct/g, rn).getRegex(), Mo = X(/\\([punct])/, "gu").replace(/punct/g, rn).getRegex(), Po = X(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/).replace("scheme", /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/).replace("email", /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/).getRegex(), zo = X(fi).replace("(?:-->|$)", "-->").getRegex(), Uo = X("^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>").replace("comment", zo).replace("attribute", /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/).getRegex(), Sn = /(?:\[(?:\\.|[^\[\]\\])*\]|\\.|`[^`]*`|[^\[\]\\`])*?/, Ho = X(/^!?\[(label)\]\(\s*(href)(?:\s+(title))?\s*\)/).replace("label", Sn).replace("href", /<(?:\\.|[^\n<>\\])+>|[^\s\x00-\x1f]*/).replace("title", /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/).getRegex(), ul = X(/^!?\[(label)\]\[(ref)\]/).replace("label", Sn).replace("ref", di).getRegex(), cl = X(/^!?\[(ref)\](?:\[\])?/).replace("ref", di).getRegex(), Go = X("reflink|nolink(?!\\()", "g").replace("reflink", ul).replace("nolink", cl).getRegex(), hi = {
  _backpedal: en,
  // only used for GFM url
  anyPunctuation: Mo,
  autolink: Po,
  blockSkip: Oo,
  br: sl,
  code: Ro,
  del: en,
  emStrongLDelim: qo,
  emStrongRDelimAst: xo,
  emStrongRDelimUnd: No,
  escape: rl,
  link: Ho,
  nolink: cl,
  punctuation: Lo,
  reflink: ul,
  reflinkSearch: Go,
  tag: Uo,
  text: Io,
  url: en
}, jo = {
  ...hi,
  link: X(/^!?\[(label)\]\((.*?)\)/).replace("label", Sn).getRegex(),
  reflink: X(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", Sn).getRegex()
}, Qn = {
  ...hi,
  escape: X(rl).replace("])", "~|])").getRegex(),
  url: X(/^((?:ftp|https?):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/, "i").replace("email", /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/).getRegex(),
  _backpedal: /(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/,
  del: /^(~~?)(?=[^\s~])([\s\S]*?[^\s~])\1(?=[^~]|$)/,
  text: /^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|https?:\/\/|ftp:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/
}, Vo = {
  ...Qn,
  br: X(sl).replace("{2,}", "*").getRegex(),
  text: X(Qn.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex()
}, mn = {
  normal: pi,
  gfm: To,
  pedantic: Bo
}, Vt = {
  normal: hi,
  gfm: Qn,
  breaks: Vo,
  pedantic: jo
};
class nt {
  constructor(e) {
    te(this, "tokens");
    te(this, "options");
    te(this, "state");
    te(this, "tokenizer");
    te(this, "inlineQueue");
    this.tokens = [], this.tokens.links = /* @__PURE__ */ Object.create(null), this.options = e || Tt, this.options.tokenizer = this.options.tokenizer || new Cn(), this.tokenizer = this.options.tokenizer, this.tokenizer.options = this.options, this.tokenizer.lexer = this, this.inlineQueue = [], this.state = {
      inLink: !1,
      inRawBlock: !1,
      top: !0
    };
    const t = {
      block: mn.normal,
      inline: Vt.normal
    };
    this.options.pedantic ? (t.block = mn.pedantic, t.inline = Vt.pedantic) : this.options.gfm && (t.block = mn.gfm, this.options.breaks ? t.inline = Vt.breaks : t.inline = Vt.gfm), this.tokenizer.rules = t;
  }
  /**
   * Expose Rules
   */
  static get rules() {
    return {
      block: mn,
      inline: Vt
    };
  }
  /**
   * Static Lex Method
   */
  static lex(e, t) {
    return new nt(t).lex(e);
  }
  /**
   * Static Lex Inline Method
   */
  static lexInline(e, t) {
    return new nt(t).inlineTokens(e);
  }
  /**
   * Preprocessing
   */
  lex(e) {
    e = e.replace(/\r\n|\r/g, `
`), this.blockTokens(e, this.tokens);
    for (let t = 0; t < this.inlineQueue.length; t++) {
      const n = this.inlineQueue[t];
      this.inlineTokens(n.src, n.tokens);
    }
    return this.inlineQueue = [], this.tokens;
  }
  blockTokens(e, t = []) {
    this.options.pedantic ? e = e.replace(/\t/g, "    ").replace(/^ +$/gm, "") : e = e.replace(/^( *)(\t+)/gm, (r, s, u) => s + "    ".repeat(u.length));
    let n, l, o, a;
    for (; e; )
      if (!(this.options.extensions && this.options.extensions.block && this.options.extensions.block.some((r) => (n = r.call({ lexer: this }, e, t)) ? (e = e.substring(n.raw.length), t.push(n), !0) : !1))) {
        if (n = this.tokenizer.space(e)) {
          e = e.substring(n.raw.length), n.raw.length === 1 && t.length > 0 ? t[t.length - 1].raw += `
` : t.push(n);
          continue;
        }
        if (n = this.tokenizer.code(e)) {
          e = e.substring(n.raw.length), l = t[t.length - 1], l && (l.type === "paragraph" || l.type === "text") ? (l.raw += `
` + n.raw, l.text += `
` + n.text, this.inlineQueue[this.inlineQueue.length - 1].src = l.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.fences(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.heading(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.hr(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.blockquote(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.list(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.html(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.def(e)) {
          e = e.substring(n.raw.length), l = t[t.length - 1], l && (l.type === "paragraph" || l.type === "text") ? (l.raw += `
` + n.raw, l.text += `
` + n.raw, this.inlineQueue[this.inlineQueue.length - 1].src = l.text) : this.tokens.links[n.tag] || (this.tokens.links[n.tag] = {
            href: n.href,
            title: n.title
          });
          continue;
        }
        if (n = this.tokenizer.table(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.lheading(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (o = e, this.options.extensions && this.options.extensions.startBlock) {
          let r = 1 / 0;
          const s = e.slice(1);
          let u;
          this.options.extensions.startBlock.forEach((c) => {
            u = c.call({ lexer: this }, s), typeof u == "number" && u >= 0 && (r = Math.min(r, u));
          }), r < 1 / 0 && r >= 0 && (o = e.substring(0, r + 1));
        }
        if (this.state.top && (n = this.tokenizer.paragraph(o))) {
          l = t[t.length - 1], a && l.type === "paragraph" ? (l.raw += `
` + n.raw, l.text += `
` + n.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = l.text) : t.push(n), a = o.length !== e.length, e = e.substring(n.raw.length);
          continue;
        }
        if (n = this.tokenizer.text(e)) {
          e = e.substring(n.raw.length), l = t[t.length - 1], l && l.type === "text" ? (l.raw += `
` + n.raw, l.text += `
` + n.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = l.text) : t.push(n);
          continue;
        }
        if (e) {
          const r = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(r);
            break;
          } else
            throw new Error(r);
        }
      }
    return this.state.top = !0, t;
  }
  inline(e, t = []) {
    return this.inlineQueue.push({ src: e, tokens: t }), t;
  }
  /**
   * Lexing/Compiling
   */
  inlineTokens(e, t = []) {
    let n, l, o, a = e, r, s, u;
    if (this.tokens.links) {
      const c = Object.keys(this.tokens.links);
      if (c.length > 0)
        for (; (r = this.tokenizer.rules.inline.reflinkSearch.exec(a)) != null; )
          c.includes(r[0].slice(r[0].lastIndexOf("[") + 1, -1)) && (a = a.slice(0, r.index) + "[" + "a".repeat(r[0].length - 2) + "]" + a.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex));
    }
    for (; (r = this.tokenizer.rules.inline.blockSkip.exec(a)) != null; )
      a = a.slice(0, r.index) + "[" + "a".repeat(r[0].length - 2) + "]" + a.slice(this.tokenizer.rules.inline.blockSkip.lastIndex);
    for (; (r = this.tokenizer.rules.inline.anyPunctuation.exec(a)) != null; )
      a = a.slice(0, r.index) + "++" + a.slice(this.tokenizer.rules.inline.anyPunctuation.lastIndex);
    for (; e; )
      if (s || (u = ""), s = !1, !(this.options.extensions && this.options.extensions.inline && this.options.extensions.inline.some((c) => (n = c.call({ lexer: this }, e, t)) ? (e = e.substring(n.raw.length), t.push(n), !0) : !1))) {
        if (n = this.tokenizer.escape(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.tag(e)) {
          e = e.substring(n.raw.length), l = t[t.length - 1], l && n.type === "text" && l.type === "text" ? (l.raw += n.raw, l.text += n.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.link(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.reflink(e, this.tokens.links)) {
          e = e.substring(n.raw.length), l = t[t.length - 1], l && n.type === "text" && l.type === "text" ? (l.raw += n.raw, l.text += n.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.emStrong(e, a, u)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.codespan(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.br(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.del(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.autolink(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (!this.state.inLink && (n = this.tokenizer.url(e))) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (o = e, this.options.extensions && this.options.extensions.startInline) {
          let c = 1 / 0;
          const m = e.slice(1);
          let f;
          this.options.extensions.startInline.forEach((d) => {
            f = d.call({ lexer: this }, m), typeof f == "number" && f >= 0 && (c = Math.min(c, f));
          }), c < 1 / 0 && c >= 0 && (o = e.substring(0, c + 1));
        }
        if (n = this.tokenizer.inlineText(o)) {
          e = e.substring(n.raw.length), n.raw.slice(-1) !== "_" && (u = n.raw.slice(-1)), s = !0, l = t[t.length - 1], l && l.type === "text" ? (l.raw += n.raw, l.text += n.text) : t.push(n);
          continue;
        }
        if (e) {
          const c = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(c);
            break;
          } else
            throw new Error(c);
        }
      }
    return t;
  }
}
class Tn {
  constructor(e) {
    te(this, "options");
    this.options = e || Tt;
  }
  code(e, t, n) {
    var o;
    const l = (o = (t || "").match(/^\S*/)) == null ? void 0 : o[0];
    return e = e.replace(/\n$/, "") + `
`, l ? '<pre><code class="language-' + Re(l) + '">' + (n ? e : Re(e, !0)) + `</code></pre>
` : "<pre><code>" + (n ? e : Re(e, !0)) + `</code></pre>
`;
  }
  blockquote(e) {
    return `<blockquote>
${e}</blockquote>
`;
  }
  html(e, t) {
    return e;
  }
  heading(e, t, n) {
    return `<h${t}>${e}</h${t}>
`;
  }
  hr() {
    return `<hr>
`;
  }
  list(e, t, n) {
    const l = t ? "ol" : "ul", o = t && n !== 1 ? ' start="' + n + '"' : "";
    return "<" + l + o + `>
` + e + "</" + l + `>
`;
  }
  listitem(e, t, n) {
    return `<li>${e}</li>
`;
  }
  checkbox(e) {
    return "<input " + (e ? 'checked="" ' : "") + 'disabled="" type="checkbox">';
  }
  paragraph(e) {
    return `<p>${e}</p>
`;
  }
  table(e, t) {
    return t && (t = `<tbody>${t}</tbody>`), `<table>
<thead>
` + e + `</thead>
` + t + `</table>
`;
  }
  tablerow(e) {
    return `<tr>
${e}</tr>
`;
  }
  tablecell(e, t) {
    const n = t.header ? "th" : "td";
    return (t.align ? `<${n} align="${t.align}">` : `<${n}>`) + e + `</${n}>
`;
  }
  /**
   * span level renderer
   */
  strong(e) {
    return `<strong>${e}</strong>`;
  }
  em(e) {
    return `<em>${e}</em>`;
  }
  codespan(e) {
    return `<code>${e}</code>`;
  }
  br() {
    return "<br>";
  }
  del(e) {
    return `<del>${e}</del>`;
  }
  link(e, t, n) {
    const l = qi(e);
    if (l === null)
      return n;
    e = l;
    let o = '<a href="' + e + '"';
    return t && (o += ' title="' + t + '"'), o += ">" + n + "</a>", o;
  }
  image(e, t, n) {
    const l = qi(e);
    if (l === null)
      return n;
    e = l;
    let o = `<img src="${e}" alt="${n}"`;
    return t && (o += ` title="${t}"`), o += ">", o;
  }
  text(e) {
    return e;
  }
}
class mi {
  // no need for block level renderers
  strong(e) {
    return e;
  }
  em(e) {
    return e;
  }
  codespan(e) {
    return e;
  }
  del(e) {
    return e;
  }
  html(e) {
    return e;
  }
  text(e) {
    return e;
  }
  link(e, t, n) {
    return "" + n;
  }
  image(e, t, n) {
    return "" + n;
  }
  br() {
    return "";
  }
}
class it {
  constructor(e) {
    te(this, "options");
    te(this, "renderer");
    te(this, "textRenderer");
    this.options = e || Tt, this.options.renderer = this.options.renderer || new Tn(), this.renderer = this.options.renderer, this.renderer.options = this.options, this.textRenderer = new mi();
  }
  /**
   * Static Parse Method
   */
  static parse(e, t) {
    return new it(t).parse(e);
  }
  /**
   * Static Parse Inline Method
   */
  static parseInline(e, t) {
    return new it(t).parseInline(e);
  }
  /**
   * Parse Loop
   */
  parse(e, t = !0) {
    let n = "";
    for (let l = 0; l < e.length; l++) {
      const o = e[l];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[o.type]) {
        const a = o, r = this.options.extensions.renderers[a.type].call({ parser: this }, a);
        if (r !== !1 || !["space", "hr", "heading", "code", "table", "blockquote", "list", "html", "paragraph", "text"].includes(a.type)) {
          n += r || "";
          continue;
        }
      }
      switch (o.type) {
        case "space":
          continue;
        case "hr": {
          n += this.renderer.hr();
          continue;
        }
        case "heading": {
          const a = o;
          n += this.renderer.heading(this.parseInline(a.tokens), a.depth, go(this.parseInline(a.tokens, this.textRenderer)));
          continue;
        }
        case "code": {
          const a = o;
          n += this.renderer.code(a.text, a.lang, !!a.escaped);
          continue;
        }
        case "table": {
          const a = o;
          let r = "", s = "";
          for (let c = 0; c < a.header.length; c++)
            s += this.renderer.tablecell(this.parseInline(a.header[c].tokens), { header: !0, align: a.align[c] });
          r += this.renderer.tablerow(s);
          let u = "";
          for (let c = 0; c < a.rows.length; c++) {
            const m = a.rows[c];
            s = "";
            for (let f = 0; f < m.length; f++)
              s += this.renderer.tablecell(this.parseInline(m[f].tokens), { header: !1, align: a.align[f] });
            u += this.renderer.tablerow(s);
          }
          n += this.renderer.table(r, u);
          continue;
        }
        case "blockquote": {
          const a = o, r = this.parse(a.tokens);
          n += this.renderer.blockquote(r);
          continue;
        }
        case "list": {
          const a = o, r = a.ordered, s = a.start, u = a.loose;
          let c = "";
          for (let m = 0; m < a.items.length; m++) {
            const f = a.items[m], d = f.checked, v = f.task;
            let y = "";
            if (f.task) {
              const w = this.renderer.checkbox(!!d);
              u ? f.tokens.length > 0 && f.tokens[0].type === "paragraph" ? (f.tokens[0].text = w + " " + f.tokens[0].text, f.tokens[0].tokens && f.tokens[0].tokens.length > 0 && f.tokens[0].tokens[0].type === "text" && (f.tokens[0].tokens[0].text = w + " " + f.tokens[0].tokens[0].text)) : f.tokens.unshift({
                type: "text",
                text: w + " "
              }) : y += w + " ";
            }
            y += this.parse(f.tokens, u), c += this.renderer.listitem(y, v, !!d);
          }
          n += this.renderer.list(c, r, s);
          continue;
        }
        case "html": {
          const a = o;
          n += this.renderer.html(a.text, a.block);
          continue;
        }
        case "paragraph": {
          const a = o;
          n += this.renderer.paragraph(this.parseInline(a.tokens));
          continue;
        }
        case "text": {
          let a = o, r = a.tokens ? this.parseInline(a.tokens) : a.text;
          for (; l + 1 < e.length && e[l + 1].type === "text"; )
            a = e[++l], r += `
` + (a.tokens ? this.parseInline(a.tokens) : a.text);
          n += t ? this.renderer.paragraph(r) : r;
          continue;
        }
        default: {
          const a = 'Token with "' + o.type + '" type was not found.';
          if (this.options.silent)
            return console.error(a), "";
          throw new Error(a);
        }
      }
    }
    return n;
  }
  /**
   * Parse Inline Tokens
   */
  parseInline(e, t) {
    t = t || this.renderer;
    let n = "";
    for (let l = 0; l < e.length; l++) {
      const o = e[l];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[o.type]) {
        const a = this.options.extensions.renderers[o.type].call({ parser: this }, o);
        if (a !== !1 || !["escape", "html", "link", "image", "strong", "em", "codespan", "br", "del", "text"].includes(o.type)) {
          n += a || "";
          continue;
        }
      }
      switch (o.type) {
        case "escape": {
          const a = o;
          n += t.text(a.text);
          break;
        }
        case "html": {
          const a = o;
          n += t.html(a.text);
          break;
        }
        case "link": {
          const a = o;
          n += t.link(a.href, a.title, this.parseInline(a.tokens, t));
          break;
        }
        case "image": {
          const a = o;
          n += t.image(a.href, a.title, a.text);
          break;
        }
        case "strong": {
          const a = o;
          n += t.strong(this.parseInline(a.tokens, t));
          break;
        }
        case "em": {
          const a = o;
          n += t.em(this.parseInline(a.tokens, t));
          break;
        }
        case "codespan": {
          const a = o;
          n += t.codespan(a.text);
          break;
        }
        case "br": {
          n += t.br();
          break;
        }
        case "del": {
          const a = o;
          n += t.del(this.parseInline(a.tokens, t));
          break;
        }
        case "text": {
          const a = o;
          n += t.text(a.text);
          break;
        }
        default: {
          const a = 'Token with "' + o.type + '" type was not found.';
          if (this.options.silent)
            return console.error(a), "";
          throw new Error(a);
        }
      }
    }
    return n;
  }
}
class tn {
  constructor(e) {
    te(this, "options");
    this.options = e || Tt;
  }
  /**
   * Process markdown before marked
   */
  preprocess(e) {
    return e;
  }
  /**
   * Process HTML after marked is finished
   */
  postprocess(e) {
    return e;
  }
  /**
   * Process all tokens before walk tokens
   */
  processAllTokens(e) {
    return e;
  }
}
te(tn, "passThroughHooks", /* @__PURE__ */ new Set([
  "preprocess",
  "postprocess",
  "processAllTokens"
]));
var St, Jn, _l;
class Wo {
  constructor(...e) {
    Ti(this, St);
    te(this, "defaults", ci());
    te(this, "options", this.setOptions);
    te(this, "parse", pn(this, St, Jn).call(this, nt.lex, it.parse));
    te(this, "parseInline", pn(this, St, Jn).call(this, nt.lexInline, it.parseInline));
    te(this, "Parser", it);
    te(this, "Renderer", Tn);
    te(this, "TextRenderer", mi);
    te(this, "Lexer", nt);
    te(this, "Tokenizer", Cn);
    te(this, "Hooks", tn);
    this.use(...e);
  }
  /**
   * Run callback for every token
   */
  walkTokens(e, t) {
    var l, o;
    let n = [];
    for (const a of e)
      switch (n = n.concat(t.call(this, a)), a.type) {
        case "table": {
          const r = a;
          for (const s of r.header)
            n = n.concat(this.walkTokens(s.tokens, t));
          for (const s of r.rows)
            for (const u of s)
              n = n.concat(this.walkTokens(u.tokens, t));
          break;
        }
        case "list": {
          const r = a;
          n = n.concat(this.walkTokens(r.items, t));
          break;
        }
        default: {
          const r = a;
          (o = (l = this.defaults.extensions) == null ? void 0 : l.childTokens) != null && o[r.type] ? this.defaults.extensions.childTokens[r.type].forEach((s) => {
            const u = r[s].flat(1 / 0);
            n = n.concat(this.walkTokens(u, t));
          }) : r.tokens && (n = n.concat(this.walkTokens(r.tokens, t)));
        }
      }
    return n;
  }
  use(...e) {
    const t = this.defaults.extensions || { renderers: {}, childTokens: {} };
    return e.forEach((n) => {
      const l = { ...n };
      if (l.async = this.defaults.async || l.async || !1, n.extensions && (n.extensions.forEach((o) => {
        if (!o.name)
          throw new Error("extension name required");
        if ("renderer" in o) {
          const a = t.renderers[o.name];
          a ? t.renderers[o.name] = function(...r) {
            let s = o.renderer.apply(this, r);
            return s === !1 && (s = a.apply(this, r)), s;
          } : t.renderers[o.name] = o.renderer;
        }
        if ("tokenizer" in o) {
          if (!o.level || o.level !== "block" && o.level !== "inline")
            throw new Error("extension level must be 'block' or 'inline'");
          const a = t[o.level];
          a ? a.unshift(o.tokenizer) : t[o.level] = [o.tokenizer], o.start && (o.level === "block" ? t.startBlock ? t.startBlock.push(o.start) : t.startBlock = [o.start] : o.level === "inline" && (t.startInline ? t.startInline.push(o.start) : t.startInline = [o.start]));
        }
        "childTokens" in o && o.childTokens && (t.childTokens[o.name] = o.childTokens);
      }), l.extensions = t), n.renderer) {
        const o = this.defaults.renderer || new Tn(this.defaults);
        for (const a in n.renderer) {
          if (!(a in o))
            throw new Error(`renderer '${a}' does not exist`);
          if (a === "options")
            continue;
          const r = a, s = n.renderer[r], u = o[r];
          o[r] = (...c) => {
            let m = s.apply(o, c);
            return m === !1 && (m = u.apply(o, c)), m || "";
          };
        }
        l.renderer = o;
      }
      if (n.tokenizer) {
        const o = this.defaults.tokenizer || new Cn(this.defaults);
        for (const a in n.tokenizer) {
          if (!(a in o))
            throw new Error(`tokenizer '${a}' does not exist`);
          if (["options", "rules", "lexer"].includes(a))
            continue;
          const r = a, s = n.tokenizer[r], u = o[r];
          o[r] = (...c) => {
            let m = s.apply(o, c);
            return m === !1 && (m = u.apply(o, c)), m;
          };
        }
        l.tokenizer = o;
      }
      if (n.hooks) {
        const o = this.defaults.hooks || new tn();
        for (const a in n.hooks) {
          if (!(a in o))
            throw new Error(`hook '${a}' does not exist`);
          if (a === "options")
            continue;
          const r = a, s = n.hooks[r], u = o[r];
          tn.passThroughHooks.has(a) ? o[r] = (c) => {
            if (this.defaults.async)
              return Promise.resolve(s.call(o, c)).then((f) => u.call(o, f));
            const m = s.call(o, c);
            return u.call(o, m);
          } : o[r] = (...c) => {
            let m = s.apply(o, c);
            return m === !1 && (m = u.apply(o, c)), m;
          };
        }
        l.hooks = o;
      }
      if (n.walkTokens) {
        const o = this.defaults.walkTokens, a = n.walkTokens;
        l.walkTokens = function(r) {
          let s = [];
          return s.push(a.call(this, r)), o && (s = s.concat(o.call(this, r))), s;
        };
      }
      this.defaults = { ...this.defaults, ...l };
    }), this;
  }
  setOptions(e) {
    return this.defaults = { ...this.defaults, ...e }, this;
  }
  lexer(e, t) {
    return nt.lex(e, t ?? this.defaults);
  }
  parser(e, t) {
    return it.parse(e, t ?? this.defaults);
  }
}
St = new WeakSet(), Jn = function(e, t) {
  return (n, l) => {
    const o = { ...l }, a = { ...this.defaults, ...o };
    this.defaults.async === !0 && o.async === !1 && (a.silent || console.warn("marked(): The async option was set to true by an extension. The async: false option sent to parse will be ignored."), a.async = !0);
    const r = pn(this, St, _l).call(this, !!a.silent, !!a.async);
    if (typeof n > "u" || n === null)
      return r(new Error("marked(): input parameter is undefined or null"));
    if (typeof n != "string")
      return r(new Error("marked(): input parameter is of type " + Object.prototype.toString.call(n) + ", string expected"));
    if (a.hooks && (a.hooks.options = a), a.async)
      return Promise.resolve(a.hooks ? a.hooks.preprocess(n) : n).then((s) => e(s, a)).then((s) => a.hooks ? a.hooks.processAllTokens(s) : s).then((s) => a.walkTokens ? Promise.all(this.walkTokens(s, a.walkTokens)).then(() => s) : s).then((s) => t(s, a)).then((s) => a.hooks ? a.hooks.postprocess(s) : s).catch(r);
    try {
      a.hooks && (n = a.hooks.preprocess(n));
      let s = e(n, a);
      a.hooks && (s = a.hooks.processAllTokens(s)), a.walkTokens && this.walkTokens(s, a.walkTokens);
      let u = t(s, a);
      return a.hooks && (u = a.hooks.postprocess(u)), u;
    } catch (s) {
      return r(s);
    }
  };
}, _l = function(e, t) {
  return (n) => {
    if (n.message += `
Please report this to https://github.com/markedjs/marked.`, e) {
      const l = "<p>An error occurred:</p><pre>" + Re(n.message + "", !0) + "</pre>";
      return t ? Promise.resolve(l) : l;
    }
    if (t)
      return Promise.reject(n);
    throw n;
  };
};
const Ct = new Wo();
function Y(i, e) {
  return Ct.parse(i, e);
}
Y.options = Y.setOptions = function(i) {
  return Ct.setOptions(i), Y.defaults = Ct.defaults, tl(Y.defaults), Y;
};
Y.getDefaults = ci;
Y.defaults = Tt;
Y.use = function(...i) {
  return Ct.use(...i), Y.defaults = Ct.defaults, tl(Y.defaults), Y;
};
Y.walkTokens = function(i, e) {
  return Ct.walkTokens(i, e);
};
Y.parseInline = Ct.parseInline;
Y.Parser = it;
Y.parser = it.parse;
Y.Renderer = Tn;
Y.TextRenderer = mi;
Y.Lexer = nt;
Y.lexer = nt.lex;
Y.Tokenizer = Cn;
Y.Hooks = tn;
Y.parse = Y;
Y.options;
Y.setOptions;
Y.use;
Y.walkTokens;
Y.parseInline;
it.parse;
nt.lex;
const Zo = /[\0-\x1F!-,\.\/:-@\[-\^`\{-\xA9\xAB-\xB4\xB6-\xB9\xBB-\xBF\xD7\xF7\u02C2-\u02C5\u02D2-\u02DF\u02E5-\u02EB\u02ED\u02EF-\u02FF\u0375\u0378\u0379\u037E\u0380-\u0385\u0387\u038B\u038D\u03A2\u03F6\u0482\u0530\u0557\u0558\u055A-\u055F\u0589-\u0590\u05BE\u05C0\u05C3\u05C6\u05C8-\u05CF\u05EB-\u05EE\u05F3-\u060F\u061B-\u061F\u066A-\u066D\u06D4\u06DD\u06DE\u06E9\u06FD\u06FE\u0700-\u070F\u074B\u074C\u07B2-\u07BF\u07F6-\u07F9\u07FB\u07FC\u07FE\u07FF\u082E-\u083F\u085C-\u085F\u086B-\u089F\u08B5\u08C8-\u08D2\u08E2\u0964\u0965\u0970\u0984\u098D\u098E\u0991\u0992\u09A9\u09B1\u09B3-\u09B5\u09BA\u09BB\u09C5\u09C6\u09C9\u09CA\u09CF-\u09D6\u09D8-\u09DB\u09DE\u09E4\u09E5\u09F2-\u09FB\u09FD\u09FF\u0A00\u0A04\u0A0B-\u0A0E\u0A11\u0A12\u0A29\u0A31\u0A34\u0A37\u0A3A\u0A3B\u0A3D\u0A43-\u0A46\u0A49\u0A4A\u0A4E-\u0A50\u0A52-\u0A58\u0A5D\u0A5F-\u0A65\u0A76-\u0A80\u0A84\u0A8E\u0A92\u0AA9\u0AB1\u0AB4\u0ABA\u0ABB\u0AC6\u0ACA\u0ACE\u0ACF\u0AD1-\u0ADF\u0AE4\u0AE5\u0AF0-\u0AF8\u0B00\u0B04\u0B0D\u0B0E\u0B11\u0B12\u0B29\u0B31\u0B34\u0B3A\u0B3B\u0B45\u0B46\u0B49\u0B4A\u0B4E-\u0B54\u0B58-\u0B5B\u0B5E\u0B64\u0B65\u0B70\u0B72-\u0B81\u0B84\u0B8B-\u0B8D\u0B91\u0B96-\u0B98\u0B9B\u0B9D\u0BA0-\u0BA2\u0BA5-\u0BA7\u0BAB-\u0BAD\u0BBA-\u0BBD\u0BC3-\u0BC5\u0BC9\u0BCE\u0BCF\u0BD1-\u0BD6\u0BD8-\u0BE5\u0BF0-\u0BFF\u0C0D\u0C11\u0C29\u0C3A-\u0C3C\u0C45\u0C49\u0C4E-\u0C54\u0C57\u0C5B-\u0C5F\u0C64\u0C65\u0C70-\u0C7F\u0C84\u0C8D\u0C91\u0CA9\u0CB4\u0CBA\u0CBB\u0CC5\u0CC9\u0CCE-\u0CD4\u0CD7-\u0CDD\u0CDF\u0CE4\u0CE5\u0CF0\u0CF3-\u0CFF\u0D0D\u0D11\u0D45\u0D49\u0D4F-\u0D53\u0D58-\u0D5E\u0D64\u0D65\u0D70-\u0D79\u0D80\u0D84\u0D97-\u0D99\u0DB2\u0DBC\u0DBE\u0DBF\u0DC7-\u0DC9\u0DCB-\u0DCE\u0DD5\u0DD7\u0DE0-\u0DE5\u0DF0\u0DF1\u0DF4-\u0E00\u0E3B-\u0E3F\u0E4F\u0E5A-\u0E80\u0E83\u0E85\u0E8B\u0EA4\u0EA6\u0EBE\u0EBF\u0EC5\u0EC7\u0ECE\u0ECF\u0EDA\u0EDB\u0EE0-\u0EFF\u0F01-\u0F17\u0F1A-\u0F1F\u0F2A-\u0F34\u0F36\u0F38\u0F3A-\u0F3D\u0F48\u0F6D-\u0F70\u0F85\u0F98\u0FBD-\u0FC5\u0FC7-\u0FFF\u104A-\u104F\u109E\u109F\u10C6\u10C8-\u10CC\u10CE\u10CF\u10FB\u1249\u124E\u124F\u1257\u1259\u125E\u125F\u1289\u128E\u128F\u12B1\u12B6\u12B7\u12BF\u12C1\u12C6\u12C7\u12D7\u1311\u1316\u1317\u135B\u135C\u1360-\u137F\u1390-\u139F\u13F6\u13F7\u13FE-\u1400\u166D\u166E\u1680\u169B-\u169F\u16EB-\u16ED\u16F9-\u16FF\u170D\u1715-\u171F\u1735-\u173F\u1754-\u175F\u176D\u1771\u1774-\u177F\u17D4-\u17D6\u17D8-\u17DB\u17DE\u17DF\u17EA-\u180A\u180E\u180F\u181A-\u181F\u1879-\u187F\u18AB-\u18AF\u18F6-\u18FF\u191F\u192C-\u192F\u193C-\u1945\u196E\u196F\u1975-\u197F\u19AC-\u19AF\u19CA-\u19CF\u19DA-\u19FF\u1A1C-\u1A1F\u1A5F\u1A7D\u1A7E\u1A8A-\u1A8F\u1A9A-\u1AA6\u1AA8-\u1AAF\u1AC1-\u1AFF\u1B4C-\u1B4F\u1B5A-\u1B6A\u1B74-\u1B7F\u1BF4-\u1BFF\u1C38-\u1C3F\u1C4A-\u1C4C\u1C7E\u1C7F\u1C89-\u1C8F\u1CBB\u1CBC\u1CC0-\u1CCF\u1CD3\u1CFB-\u1CFF\u1DFA\u1F16\u1F17\u1F1E\u1F1F\u1F46\u1F47\u1F4E\u1F4F\u1F58\u1F5A\u1F5C\u1F5E\u1F7E\u1F7F\u1FB5\u1FBD\u1FBF-\u1FC1\u1FC5\u1FCD-\u1FCF\u1FD4\u1FD5\u1FDC-\u1FDF\u1FED-\u1FF1\u1FF5\u1FFD-\u203E\u2041-\u2053\u2055-\u2070\u2072-\u207E\u2080-\u208F\u209D-\u20CF\u20F1-\u2101\u2103-\u2106\u2108\u2109\u2114\u2116-\u2118\u211E-\u2123\u2125\u2127\u2129\u212E\u213A\u213B\u2140-\u2144\u214A-\u214D\u214F-\u215F\u2189-\u24B5\u24EA-\u2BFF\u2C2F\u2C5F\u2CE5-\u2CEA\u2CF4-\u2CFF\u2D26\u2D28-\u2D2C\u2D2E\u2D2F\u2D68-\u2D6E\u2D70-\u2D7E\u2D97-\u2D9F\u2DA7\u2DAF\u2DB7\u2DBF\u2DC7\u2DCF\u2DD7\u2DDF\u2E00-\u2E2E\u2E30-\u3004\u3008-\u3020\u3030\u3036\u3037\u303D-\u3040\u3097\u3098\u309B\u309C\u30A0\u30FB\u3100-\u3104\u3130\u318F-\u319F\u31C0-\u31EF\u3200-\u33FF\u4DC0-\u4DFF\u9FFD-\u9FFF\uA48D-\uA4CF\uA4FE\uA4FF\uA60D-\uA60F\uA62C-\uA63F\uA673\uA67E\uA6F2-\uA716\uA720\uA721\uA789\uA78A\uA7C0\uA7C1\uA7CB-\uA7F4\uA828-\uA82B\uA82D-\uA83F\uA874-\uA87F\uA8C6-\uA8CF\uA8DA-\uA8DF\uA8F8-\uA8FA\uA8FC\uA92E\uA92F\uA954-\uA95F\uA97D-\uA97F\uA9C1-\uA9CE\uA9DA-\uA9DF\uA9FF\uAA37-\uAA3F\uAA4E\uAA4F\uAA5A-\uAA5F\uAA77-\uAA79\uAAC3-\uAADA\uAADE\uAADF\uAAF0\uAAF1\uAAF7-\uAB00\uAB07\uAB08\uAB0F\uAB10\uAB17-\uAB1F\uAB27\uAB2F\uAB5B\uAB6A-\uAB6F\uABEB\uABEE\uABEF\uABFA-\uABFF\uD7A4-\uD7AF\uD7C7-\uD7CA\uD7FC-\uD7FF\uE000-\uF8FF\uFA6E\uFA6F\uFADA-\uFAFF\uFB07-\uFB12\uFB18-\uFB1C\uFB29\uFB37\uFB3D\uFB3F\uFB42\uFB45\uFBB2-\uFBD2\uFD3E-\uFD4F\uFD90\uFD91\uFDC8-\uFDEF\uFDFC-\uFDFF\uFE10-\uFE1F\uFE30-\uFE32\uFE35-\uFE4C\uFE50-\uFE6F\uFE75\uFEFD-\uFF0F\uFF1A-\uFF20\uFF3B-\uFF3E\uFF40\uFF5B-\uFF65\uFFBF-\uFFC1\uFFC8\uFFC9\uFFD0\uFFD1\uFFD8\uFFD9\uFFDD-\uFFFF]|\uD800[\uDC0C\uDC27\uDC3B\uDC3E\uDC4E\uDC4F\uDC5E-\uDC7F\uDCFB-\uDD3F\uDD75-\uDDFC\uDDFE-\uDE7F\uDE9D-\uDE9F\uDED1-\uDEDF\uDEE1-\uDEFF\uDF20-\uDF2C\uDF4B-\uDF4F\uDF7B-\uDF7F\uDF9E\uDF9F\uDFC4-\uDFC7\uDFD0\uDFD6-\uDFFF]|\uD801[\uDC9E\uDC9F\uDCAA-\uDCAF\uDCD4-\uDCD7\uDCFC-\uDCFF\uDD28-\uDD2F\uDD64-\uDDFF\uDF37-\uDF3F\uDF56-\uDF5F\uDF68-\uDFFF]|\uD802[\uDC06\uDC07\uDC09\uDC36\uDC39-\uDC3B\uDC3D\uDC3E\uDC56-\uDC5F\uDC77-\uDC7F\uDC9F-\uDCDF\uDCF3\uDCF6-\uDCFF\uDD16-\uDD1F\uDD3A-\uDD7F\uDDB8-\uDDBD\uDDC0-\uDDFF\uDE04\uDE07-\uDE0B\uDE14\uDE18\uDE36\uDE37\uDE3B-\uDE3E\uDE40-\uDE5F\uDE7D-\uDE7F\uDE9D-\uDEBF\uDEC8\uDEE7-\uDEFF\uDF36-\uDF3F\uDF56-\uDF5F\uDF73-\uDF7F\uDF92-\uDFFF]|\uD803[\uDC49-\uDC7F\uDCB3-\uDCBF\uDCF3-\uDCFF\uDD28-\uDD2F\uDD3A-\uDE7F\uDEAA\uDEAD-\uDEAF\uDEB2-\uDEFF\uDF1D-\uDF26\uDF28-\uDF2F\uDF51-\uDFAF\uDFC5-\uDFDF\uDFF7-\uDFFF]|\uD804[\uDC47-\uDC65\uDC70-\uDC7E\uDCBB-\uDCCF\uDCE9-\uDCEF\uDCFA-\uDCFF\uDD35\uDD40-\uDD43\uDD48-\uDD4F\uDD74\uDD75\uDD77-\uDD7F\uDDC5-\uDDC8\uDDCD\uDDDB\uDDDD-\uDDFF\uDE12\uDE38-\uDE3D\uDE3F-\uDE7F\uDE87\uDE89\uDE8E\uDE9E\uDEA9-\uDEAF\uDEEB-\uDEEF\uDEFA-\uDEFF\uDF04\uDF0D\uDF0E\uDF11\uDF12\uDF29\uDF31\uDF34\uDF3A\uDF45\uDF46\uDF49\uDF4A\uDF4E\uDF4F\uDF51-\uDF56\uDF58-\uDF5C\uDF64\uDF65\uDF6D-\uDF6F\uDF75-\uDFFF]|\uD805[\uDC4B-\uDC4F\uDC5A-\uDC5D\uDC62-\uDC7F\uDCC6\uDCC8-\uDCCF\uDCDA-\uDD7F\uDDB6\uDDB7\uDDC1-\uDDD7\uDDDE-\uDDFF\uDE41-\uDE43\uDE45-\uDE4F\uDE5A-\uDE7F\uDEB9-\uDEBF\uDECA-\uDEFF\uDF1B\uDF1C\uDF2C-\uDF2F\uDF3A-\uDFFF]|\uD806[\uDC3B-\uDC9F\uDCEA-\uDCFE\uDD07\uDD08\uDD0A\uDD0B\uDD14\uDD17\uDD36\uDD39\uDD3A\uDD44-\uDD4F\uDD5A-\uDD9F\uDDA8\uDDA9\uDDD8\uDDD9\uDDE2\uDDE5-\uDDFF\uDE3F-\uDE46\uDE48-\uDE4F\uDE9A-\uDE9C\uDE9E-\uDEBF\uDEF9-\uDFFF]|\uD807[\uDC09\uDC37\uDC41-\uDC4F\uDC5A-\uDC71\uDC90\uDC91\uDCA8\uDCB7-\uDCFF\uDD07\uDD0A\uDD37-\uDD39\uDD3B\uDD3E\uDD48-\uDD4F\uDD5A-\uDD5F\uDD66\uDD69\uDD8F\uDD92\uDD99-\uDD9F\uDDAA-\uDEDF\uDEF7-\uDFAF\uDFB1-\uDFFF]|\uD808[\uDF9A-\uDFFF]|\uD809[\uDC6F-\uDC7F\uDD44-\uDFFF]|[\uD80A\uD80B\uD80E-\uD810\uD812-\uD819\uD824-\uD82B\uD82D\uD82E\uD830-\uD833\uD837\uD839\uD83D\uD83F\uD87B-\uD87D\uD87F\uD885-\uDB3F\uDB41-\uDBFF][\uDC00-\uDFFF]|\uD80D[\uDC2F-\uDFFF]|\uD811[\uDE47-\uDFFF]|\uD81A[\uDE39-\uDE3F\uDE5F\uDE6A-\uDECF\uDEEE\uDEEF\uDEF5-\uDEFF\uDF37-\uDF3F\uDF44-\uDF4F\uDF5A-\uDF62\uDF78-\uDF7C\uDF90-\uDFFF]|\uD81B[\uDC00-\uDE3F\uDE80-\uDEFF\uDF4B-\uDF4E\uDF88-\uDF8E\uDFA0-\uDFDF\uDFE2\uDFE5-\uDFEF\uDFF2-\uDFFF]|\uD821[\uDFF8-\uDFFF]|\uD823[\uDCD6-\uDCFF\uDD09-\uDFFF]|\uD82C[\uDD1F-\uDD4F\uDD53-\uDD63\uDD68-\uDD6F\uDEFC-\uDFFF]|\uD82F[\uDC6B-\uDC6F\uDC7D-\uDC7F\uDC89-\uDC8F\uDC9A-\uDC9C\uDC9F-\uDFFF]|\uD834[\uDC00-\uDD64\uDD6A-\uDD6C\uDD73-\uDD7A\uDD83\uDD84\uDD8C-\uDDA9\uDDAE-\uDE41\uDE45-\uDFFF]|\uD835[\uDC55\uDC9D\uDCA0\uDCA1\uDCA3\uDCA4\uDCA7\uDCA8\uDCAD\uDCBA\uDCBC\uDCC4\uDD06\uDD0B\uDD0C\uDD15\uDD1D\uDD3A\uDD3F\uDD45\uDD47-\uDD49\uDD51\uDEA6\uDEA7\uDEC1\uDEDB\uDEFB\uDF15\uDF35\uDF4F\uDF6F\uDF89\uDFA9\uDFC3\uDFCC\uDFCD]|\uD836[\uDC00-\uDDFF\uDE37-\uDE3A\uDE6D-\uDE74\uDE76-\uDE83\uDE85-\uDE9A\uDEA0\uDEB0-\uDFFF]|\uD838[\uDC07\uDC19\uDC1A\uDC22\uDC25\uDC2B-\uDCFF\uDD2D-\uDD2F\uDD3E\uDD3F\uDD4A-\uDD4D\uDD4F-\uDEBF\uDEFA-\uDFFF]|\uD83A[\uDCC5-\uDCCF\uDCD7-\uDCFF\uDD4C-\uDD4F\uDD5A-\uDFFF]|\uD83B[\uDC00-\uDDFF\uDE04\uDE20\uDE23\uDE25\uDE26\uDE28\uDE33\uDE38\uDE3A\uDE3C-\uDE41\uDE43-\uDE46\uDE48\uDE4A\uDE4C\uDE50\uDE53\uDE55\uDE56\uDE58\uDE5A\uDE5C\uDE5E\uDE60\uDE63\uDE65\uDE66\uDE6B\uDE73\uDE78\uDE7D\uDE7F\uDE8A\uDE9C-\uDEA0\uDEA4\uDEAA\uDEBC-\uDFFF]|\uD83C[\uDC00-\uDD2F\uDD4A-\uDD4F\uDD6A-\uDD6F\uDD8A-\uDFFF]|\uD83E[\uDC00-\uDFEF\uDFFA-\uDFFF]|\uD869[\uDEDE-\uDEFF]|\uD86D[\uDF35-\uDF3F]|\uD86E[\uDC1E\uDC1F]|\uD873[\uDEA2-\uDEAF]|\uD87A[\uDFE1-\uDFFF]|\uD87E[\uDE1E-\uDFFF]|\uD884[\uDF4B-\uDFFF]|\uDB40[\uDC00-\uDCFF\uDDF0-\uDFFF]/g, Yo = Object.hasOwnProperty;
class dl {
  /**
   * Create a new slug class.
   */
  constructor() {
    this.occurrences, this.reset();
  }
  /**
   * Generate a unique slug.
  *
  * Tracks previously generated slugs: repeated calls with the same value
  * will result in different slugs.
  * Use the `slug` function to get same slugs.
   *
   * @param  {string} value
   *   String of text to slugify
   * @param  {boolean} [maintainCase=false]
   *   Keep the current case, otherwise make all lowercase
   * @return {string}
   *   A unique slug string
   */
  slug(e, t) {
    const n = this;
    let l = Xo(e, t === !0);
    const o = l;
    for (; Yo.call(n.occurrences, l); )
      n.occurrences[o]++, l = o + "-" + n.occurrences[o];
    return n.occurrences[l] = 0, l;
  }
  /**
   * Reset - Forget all previous slugs
   *
   * @return void
   */
  reset() {
    this.occurrences = /* @__PURE__ */ Object.create(null);
  }
}
function Xo(i, e) {
  return typeof i != "string" ? "" : (e || (i = i.toLowerCase()), i.replace(Zo, "").replace(/ /g, "-"));
}
new dl();
var Pi = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {}, Ko = { exports: {} };
(function(i) {
  var e = typeof window < "u" ? window : typeof WorkerGlobalScope < "u" && self instanceof WorkerGlobalScope ? self : {};
  /**
   * Prism: Lightweight, robust, elegant syntax highlighting
   *
   * @license MIT <https://opensource.org/licenses/MIT>
   * @author Lea Verou <https://lea.verou.me>
   * @namespace
   * @public
   */
  var t = function(n) {
    var l = /(?:^|\s)lang(?:uage)?-([\w-]+)(?=\s|$)/i, o = 0, a = {}, r = {
      /**
       * By default, Prism will attempt to highlight all code elements (by calling {@link Prism.highlightAll}) on the
       * current page after the page finished loading. This might be a problem if e.g. you wanted to asynchronously load
       * additional languages or plugins yourself.
       *
       * By setting this value to `true`, Prism will not automatically highlight all code elements on the page.
       *
       * You obviously have to change this value before the automatic highlighting started. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.manual = true;
       * // add a new <script> to load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      manual: n.Prism && n.Prism.manual,
      /**
       * By default, if Prism is in a web worker, it assumes that it is in a worker it created itself, so it uses
       * `addEventListener` to communicate with its parent instance. However, if you're using Prism manually in your
       * own worker, you don't want it to do this.
       *
       * By setting this value to `true`, Prism will not add its own listeners to the worker.
       *
       * You obviously have to change this value before Prism executes. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.disableWorkerMessageHandler = true;
       * // Load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      disableWorkerMessageHandler: n.Prism && n.Prism.disableWorkerMessageHandler,
      /**
       * A namespace for utility methods.
       *
       * All function in this namespace that are not explicitly marked as _public_ are for __internal use only__ and may
       * change or disappear at any time.
       *
       * @namespace
       * @memberof Prism
       */
      util: {
        encode: function h(_) {
          return _ instanceof s ? new s(_.type, h(_.content), _.alias) : Array.isArray(_) ? _.map(h) : _.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/\u00a0/g, " ");
        },
        /**
         * Returns the name of the type of the given value.
         *
         * @param {any} o
         * @returns {string}
         * @example
         * type(null)      === 'Null'
         * type(undefined) === 'Undefined'
         * type(123)       === 'Number'
         * type('foo')     === 'String'
         * type(true)      === 'Boolean'
         * type([1, 2])    === 'Array'
         * type({})        === 'Object'
         * type(String)    === 'Function'
         * type(/abc+/)    === 'RegExp'
         */
        type: function(h) {
          return Object.prototype.toString.call(h).slice(8, -1);
        },
        /**
         * Returns a unique number for the given object. Later calls will still return the same number.
         *
         * @param {Object} obj
         * @returns {number}
         */
        objId: function(h) {
          return h.__id || Object.defineProperty(h, "__id", { value: ++o }), h.__id;
        },
        /**
         * Creates a deep clone of the given object.
         *
         * The main intended use of this function is to clone language definitions.
         *
         * @param {T} o
         * @param {Record<number, any>} [visited]
         * @returns {T}
         * @template T
         */
        clone: function h(_, g) {
          g = g || {};
          var b, F;
          switch (r.util.type(_)) {
            case "Object":
              if (F = r.util.objId(_), g[F])
                return g[F];
              b = /** @type {Record<string, any>} */
              {}, g[F] = b;
              for (var A in _)
                _.hasOwnProperty(A) && (b[A] = h(_[A], g));
              return (
                /** @type {any} */
                b
              );
            case "Array":
              return F = r.util.objId(_), g[F] ? g[F] : (b = [], g[F] = b, /** @type {Array} */
              /** @type {any} */
              _.forEach(function(T, S) {
                b[S] = h(T, g);
              }), /** @type {any} */
              b);
            default:
              return _;
          }
        },
        /**
         * Returns the Prism language of the given element set by a `language-xxxx` or `lang-xxxx` class.
         *
         * If no language is set for the element or the element is `null` or `undefined`, `none` will be returned.
         *
         * @param {Element} element
         * @returns {string}
         */
        getLanguage: function(h) {
          for (; h; ) {
            var _ = l.exec(h.className);
            if (_)
              return _[1].toLowerCase();
            h = h.parentElement;
          }
          return "none";
        },
        /**
         * Sets the Prism `language-xxxx` class of the given element.
         *
         * @param {Element} element
         * @param {string} language
         * @returns {void}
         */
        setLanguage: function(h, _) {
          h.className = h.className.replace(RegExp(l, "gi"), ""), h.classList.add("language-" + _);
        },
        /**
         * Returns the script element that is currently executing.
         *
         * This does __not__ work for line script element.
         *
         * @returns {HTMLScriptElement | null}
         */
        currentScript: function() {
          if (typeof document > "u")
            return null;
          if ("currentScript" in document)
            return (
              /** @type {any} */
              document.currentScript
            );
          try {
            throw new Error();
          } catch (b) {
            var h = (/at [^(\r\n]*\((.*):[^:]+:[^:]+\)$/i.exec(b.stack) || [])[1];
            if (h) {
              var _ = document.getElementsByTagName("script");
              for (var g in _)
                if (_[g].src == h)
                  return _[g];
            }
            return null;
          }
        },
        /**
         * Returns whether a given class is active for `element`.
         *
         * The class can be activated if `element` or one of its ancestors has the given class and it can be deactivated
         * if `element` or one of its ancestors has the negated version of the given class. The _negated version_ of the
         * given class is just the given class with a `no-` prefix.
         *
         * Whether the class is active is determined by the closest ancestor of `element` (where `element` itself is
         * closest ancestor) that has the given class or the negated version of it. If neither `element` nor any of its
         * ancestors have the given class or the negated version of it, then the default activation will be returned.
         *
         * In the paradoxical situation where the closest ancestor contains __both__ the given class and the negated
         * version of it, the class is considered active.
         *
         * @param {Element} element
         * @param {string} className
         * @param {boolean} [defaultActivation=false]
         * @returns {boolean}
         */
        isActive: function(h, _, g) {
          for (var b = "no-" + _; h; ) {
            var F = h.classList;
            if (F.contains(_))
              return !0;
            if (F.contains(b))
              return !1;
            h = h.parentElement;
          }
          return !!g;
        }
      },
      /**
       * This namespace contains all currently loaded languages and the some helper functions to create and modify languages.
       *
       * @namespace
       * @memberof Prism
       * @public
       */
      languages: {
        /**
         * The grammar for plain, unformatted text.
         */
        plain: a,
        plaintext: a,
        text: a,
        txt: a,
        /**
         * Creates a deep copy of the language with the given id and appends the given tokens.
         *
         * If a token in `redef` also appears in the copied language, then the existing token in the copied language
         * will be overwritten at its original position.
         *
         * ## Best practices
         *
         * Since the position of overwriting tokens (token in `redef` that overwrite tokens in the copied language)
         * doesn't matter, they can technically be in any order. However, this can be confusing to others that trying to
         * understand the language definition because, normally, the order of tokens matters in Prism grammars.
         *
         * Therefore, it is encouraged to order overwriting tokens according to the positions of the overwritten tokens.
         * Furthermore, all non-overwriting tokens should be placed after the overwriting ones.
         *
         * @param {string} id The id of the language to extend. This has to be a key in `Prism.languages`.
         * @param {Grammar} redef The new tokens to append.
         * @returns {Grammar} The new language created.
         * @public
         * @example
         * Prism.languages['css-with-colors'] = Prism.languages.extend('css', {
         *     // Prism.languages.css already has a 'comment' token, so this token will overwrite CSS' 'comment' token
         *     // at its original position
         *     'comment': { ... },
         *     // CSS doesn't have a 'color' token, so this token will be appended
         *     'color': /\b(?:red|green|blue)\b/
         * });
         */
        extend: function(h, _) {
          var g = r.util.clone(r.languages[h]);
          for (var b in _)
            g[b] = _[b];
          return g;
        },
        /**
         * Inserts tokens _before_ another token in a language definition or any other grammar.
         *
         * ## Usage
         *
         * This helper method makes it easy to modify existing languages. For example, the CSS language definition
         * not only defines CSS highlighting for CSS documents, but also needs to define highlighting for CSS embedded
         * in HTML through `<style>` elements. To do this, it needs to modify `Prism.languages.markup` and add the
         * appropriate tokens. However, `Prism.languages.markup` is a regular JavaScript object literal, so if you do
         * this:
         *
         * ```js
         * Prism.languages.markup.style = {
         *     // token
         * };
         * ```
         *
         * then the `style` token will be added (and processed) at the end. `insertBefore` allows you to insert tokens
         * before existing tokens. For the CSS example above, you would use it like this:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'cdata', {
         *     'style': {
         *         // token
         *     }
         * });
         * ```
         *
         * ## Special cases
         *
         * If the grammars of `inside` and `insert` have tokens with the same name, the tokens in `inside`'s grammar
         * will be ignored.
         *
         * This behavior can be used to insert tokens after `before`:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'comment', {
         *     'comment': Prism.languages.markup.comment,
         *     // tokens after 'comment'
         * });
         * ```
         *
         * ## Limitations
         *
         * The main problem `insertBefore` has to solve is iteration order. Since ES2015, the iteration order for object
         * properties is guaranteed to be the insertion order (except for integer keys) but some browsers behave
         * differently when keys are deleted and re-inserted. So `insertBefore` can't be implemented by temporarily
         * deleting properties which is necessary to insert at arbitrary positions.
         *
         * To solve this problem, `insertBefore` doesn't actually insert the given tokens into the target object.
         * Instead, it will create a new object and replace all references to the target object with the new one. This
         * can be done without temporarily deleting properties, so the iteration order is well-defined.
         *
         * However, only references that can be reached from `Prism.languages` or `insert` will be replaced. I.e. if
         * you hold the target object in a variable, then the value of the variable will not change.
         *
         * ```js
         * var oldMarkup = Prism.languages.markup;
         * var newMarkup = Prism.languages.insertBefore('markup', 'comment', { ... });
         *
         * assert(oldMarkup !== Prism.languages.markup);
         * assert(newMarkup === Prism.languages.markup);
         * ```
         *
         * @param {string} inside The property of `root` (e.g. a language id in `Prism.languages`) that contains the
         * object to be modified.
         * @param {string} before The key to insert before.
         * @param {Grammar} insert An object containing the key-value pairs to be inserted.
         * @param {Object<string, any>} [root] The object containing `inside`, i.e. the object that contains the
         * object to be modified.
         *
         * Defaults to `Prism.languages`.
         * @returns {Grammar} The new grammar object.
         * @public
         */
        insertBefore: function(h, _, g, b) {
          b = b || /** @type {any} */
          r.languages;
          var F = b[h], A = {};
          for (var T in F)
            if (F.hasOwnProperty(T)) {
              if (T == _)
                for (var S in g)
                  g.hasOwnProperty(S) && (A[S] = g[S]);
              g.hasOwnProperty(T) || (A[T] = F[T]);
            }
          var N = b[h];
          return b[h] = A, r.languages.DFS(r.languages, function(x, U) {
            U === N && x != h && (this[x] = A);
          }), A;
        },
        // Traverse a language definition with Depth First Search
        DFS: function h(_, g, b, F) {
          F = F || {};
          var A = r.util.objId;
          for (var T in _)
            if (_.hasOwnProperty(T)) {
              g.call(_, T, _[T], b || T);
              var S = _[T], N = r.util.type(S);
              N === "Object" && !F[A(S)] ? (F[A(S)] = !0, h(S, g, null, F)) : N === "Array" && !F[A(S)] && (F[A(S)] = !0, h(S, g, T, F));
            }
        }
      },
      plugins: {},
      /**
       * This is the most high-level function in Prism’s API.
       * It fetches all the elements that have a `.language-xxxx` class and then calls {@link Prism.highlightElement} on
       * each one of them.
       *
       * This is equivalent to `Prism.highlightAllUnder(document, async, callback)`.
       *
       * @param {boolean} [async=false] Same as in {@link Prism.highlightAllUnder}.
       * @param {HighlightCallback} [callback] Same as in {@link Prism.highlightAllUnder}.
       * @memberof Prism
       * @public
       */
      highlightAll: function(h, _) {
        r.highlightAllUnder(document, h, _);
      },
      /**
       * Fetches all the descendants of `container` that have a `.language-xxxx` class and then calls
       * {@link Prism.highlightElement} on each one of them.
       *
       * The following hooks will be run:
       * 1. `before-highlightall`
       * 2. `before-all-elements-highlight`
       * 3. All hooks of {@link Prism.highlightElement} for each element.
       *
       * @param {ParentNode} container The root element, whose descendants that have a `.language-xxxx` class will be highlighted.
       * @param {boolean} [async=false] Whether each element is to be highlighted asynchronously using Web Workers.
       * @param {HighlightCallback} [callback] An optional callback to be invoked on each element after its highlighting is done.
       * @memberof Prism
       * @public
       */
      highlightAllUnder: function(h, _, g) {
        var b = {
          callback: g,
          container: h,
          selector: 'code[class*="language-"], [class*="language-"] code, code[class*="lang-"], [class*="lang-"] code'
        };
        r.hooks.run("before-highlightall", b), b.elements = Array.prototype.slice.apply(b.container.querySelectorAll(b.selector)), r.hooks.run("before-all-elements-highlight", b);
        for (var F = 0, A; A = b.elements[F++]; )
          r.highlightElement(A, _ === !0, b.callback);
      },
      /**
       * Highlights the code inside a single element.
       *
       * The following hooks will be run:
       * 1. `before-sanity-check`
       * 2. `before-highlight`
       * 3. All hooks of {@link Prism.highlight}. These hooks will be run by an asynchronous worker if `async` is `true`.
       * 4. `before-insert`
       * 5. `after-highlight`
       * 6. `complete`
       *
       * Some the above hooks will be skipped if the element doesn't contain any text or there is no grammar loaded for
       * the element's language.
       *
       * @param {Element} element The element containing the code.
       * It must have a class of `language-xxxx` to be processed, where `xxxx` is a valid language identifier.
       * @param {boolean} [async=false] Whether the element is to be highlighted asynchronously using Web Workers
       * to improve performance and avoid blocking the UI when highlighting very large chunks of code. This option is
       * [disabled by default](https://prismjs.com/faq.html#why-is-asynchronous-highlighting-disabled-by-default).
       *
       * Note: All language definitions required to highlight the code must be included in the main `prism.js` file for
       * asynchronous highlighting to work. You can build your own bundle on the
       * [Download page](https://prismjs.com/download.html).
       * @param {HighlightCallback} [callback] An optional callback to be invoked after the highlighting is done.
       * Mostly useful when `async` is `true`, since in that case, the highlighting is done asynchronously.
       * @memberof Prism
       * @public
       */
      highlightElement: function(h, _, g) {
        var b = r.util.getLanguage(h), F = r.languages[b];
        r.util.setLanguage(h, b);
        var A = h.parentElement;
        A && A.nodeName.toLowerCase() === "pre" && r.util.setLanguage(A, b);
        var T = h.textContent, S = {
          element: h,
          language: b,
          grammar: F,
          code: T
        };
        function N(U) {
          S.highlightedCode = U, r.hooks.run("before-insert", S), S.element.innerHTML = S.highlightedCode, r.hooks.run("after-highlight", S), r.hooks.run("complete", S), g && g.call(S.element);
        }
        if (r.hooks.run("before-sanity-check", S), A = S.element.parentElement, A && A.nodeName.toLowerCase() === "pre" && !A.hasAttribute("tabindex") && A.setAttribute("tabindex", "0"), !S.code) {
          r.hooks.run("complete", S), g && g.call(S.element);
          return;
        }
        if (r.hooks.run("before-highlight", S), !S.grammar) {
          N(r.util.encode(S.code));
          return;
        }
        if (_ && n.Worker) {
          var x = new Worker(r.filename);
          x.onmessage = function(U) {
            N(U.data);
          }, x.postMessage(JSON.stringify({
            language: S.language,
            code: S.code,
            immediateClose: !0
          }));
        } else
          N(r.highlight(S.code, S.grammar, S.language));
      },
      /**
       * Low-level function, only use if you know what you’re doing. It accepts a string of text as input
       * and the language definitions to use, and returns a string with the HTML produced.
       *
       * The following hooks will be run:
       * 1. `before-tokenize`
       * 2. `after-tokenize`
       * 3. `wrap`: On each {@link Token}.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @param {string} language The name of the language definition passed to `grammar`.
       * @returns {string} The highlighted HTML.
       * @memberof Prism
       * @public
       * @example
       * Prism.highlight('var foo = true;', Prism.languages.javascript, 'javascript');
       */
      highlight: function(h, _, g) {
        var b = {
          code: h,
          grammar: _,
          language: g
        };
        if (r.hooks.run("before-tokenize", b), !b.grammar)
          throw new Error('The language "' + b.language + '" has no grammar.');
        return b.tokens = r.tokenize(b.code, b.grammar), r.hooks.run("after-tokenize", b), s.stringify(r.util.encode(b.tokens), b.language);
      },
      /**
       * This is the heart of Prism, and the most low-level function you can use. It accepts a string of text as input
       * and the language definitions to use, and returns an array with the tokenized code.
       *
       * When the language definition includes nested tokens, the function is called recursively on each of these tokens.
       *
       * This method could be useful in other contexts as well, as a very crude parser.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @returns {TokenStream} An array of strings and tokens, a token stream.
       * @memberof Prism
       * @public
       * @example
       * let code = `var foo = 0;`;
       * let tokens = Prism.tokenize(code, Prism.languages.javascript);
       * tokens.forEach(token => {
       *     if (token instanceof Prism.Token && token.type === 'number') {
       *         console.log(`Found numeric literal: ${token.content}`);
       *     }
       * });
       */
      tokenize: function(h, _) {
        var g = _.rest;
        if (g) {
          for (var b in g)
            _[b] = g[b];
          delete _.rest;
        }
        var F = new m();
        return f(F, F.head, h), c(h, F, _, F.head, 0), v(F);
      },
      /**
       * @namespace
       * @memberof Prism
       * @public
       */
      hooks: {
        all: {},
        /**
         * Adds the given callback to the list of callbacks for the given hook.
         *
         * The callback will be invoked when the hook it is registered for is run.
         * Hooks are usually directly run by a highlight function but you can also run hooks yourself.
         *
         * One callback function can be registered to multiple hooks and the same hook multiple times.
         *
         * @param {string} name The name of the hook.
         * @param {HookCallback} callback The callback function which is given environment variables.
         * @public
         */
        add: function(h, _) {
          var g = r.hooks.all;
          g[h] = g[h] || [], g[h].push(_);
        },
        /**
         * Runs a hook invoking all registered callbacks with the given environment variables.
         *
         * Callbacks will be invoked synchronously and in the order in which they were registered.
         *
         * @param {string} name The name of the hook.
         * @param {Object<string, any>} env The environment variables of the hook passed to all callbacks registered.
         * @public
         */
        run: function(h, _) {
          var g = r.hooks.all[h];
          if (!(!g || !g.length))
            for (var b = 0, F; F = g[b++]; )
              F(_);
        }
      },
      Token: s
    };
    n.Prism = r;
    function s(h, _, g, b) {
      this.type = h, this.content = _, this.alias = g, this.length = (b || "").length | 0;
    }
    s.stringify = function h(_, g) {
      if (typeof _ == "string")
        return _;
      if (Array.isArray(_)) {
        var b = "";
        return _.forEach(function(N) {
          b += h(N, g);
        }), b;
      }
      var F = {
        type: _.type,
        content: h(_.content, g),
        tag: "span",
        classes: ["token", _.type],
        attributes: {},
        language: g
      }, A = _.alias;
      A && (Array.isArray(A) ? Array.prototype.push.apply(F.classes, A) : F.classes.push(A)), r.hooks.run("wrap", F);
      var T = "";
      for (var S in F.attributes)
        T += " " + S + '="' + (F.attributes[S] || "").replace(/"/g, "&quot;") + '"';
      return "<" + F.tag + ' class="' + F.classes.join(" ") + '"' + T + ">" + F.content + "</" + F.tag + ">";
    };
    function u(h, _, g, b) {
      h.lastIndex = _;
      var F = h.exec(g);
      if (F && b && F[1]) {
        var A = F[1].length;
        F.index += A, F[0] = F[0].slice(A);
      }
      return F;
    }
    function c(h, _, g, b, F, A) {
      for (var T in g)
        if (!(!g.hasOwnProperty(T) || !g[T])) {
          var S = g[T];
          S = Array.isArray(S) ? S : [S];
          for (var N = 0; N < S.length; ++N) {
            if (A && A.cause == T + "," + N)
              return;
            var x = S[N], U = x.inside, $e = !!x.lookbehind, ue = !!x.greedy, ke = x.alias;
            if (ue && !x.pattern.global) {
              var _e = x.pattern.toString().match(/[imsuy]*$/)[0];
              x.pattern = RegExp(x.pattern.source, _e + "g");
            }
            for (var le = x.pattern || x, K = b.next, re = F; K !== _.tail && !(A && re >= A.reach); re += K.value.length, K = K.next) {
              var ge = K.value;
              if (_.length > h.length)
                return;
              if (!(ge instanceof s)) {
                var $ = 1, oe;
                if (ue) {
                  if (oe = u(le, re, h, $e), !oe || oe.index >= h.length)
                    break;
                  var Se = oe.index, Q = oe.index + oe[0].length, de = re;
                  for (de += K.value.length; Se >= de; )
                    K = K.next, de += K.value.length;
                  if (de -= K.value.length, re = de, K.value instanceof s)
                    continue;
                  for (var E = K; E !== _.tail && (de < Q || typeof E.value == "string"); E = E.next)
                    $++, de += E.value.length;
                  $--, ge = h.slice(re, de), oe.index -= re;
                } else if (oe = u(le, 0, ge, $e), !oe)
                  continue;
                var Se = oe.index, Xe = oe[0], vt = ge.slice(0, Se), Dt = ge.slice(Se + Xe.length), bt = re + ge.length;
                A && bt > A.reach && (A.reach = bt);
                var ct = K.prev;
                vt && (ct = f(_, ct, vt), re += vt.length), d(_, ct, $);
                var Ke = new s(T, U ? r.tokenize(Xe, U) : Xe, ke, Xe);
                if (K = f(_, ct, Ke), Dt && f(_, K, Dt), $ > 1) {
                  var Qe = {
                    cause: T + "," + N,
                    reach: bt
                  };
                  c(h, _, g, K.prev, re, Qe), A && Qe.reach > A.reach && (A.reach = Qe.reach);
                }
              }
            }
          }
        }
    }
    function m() {
      var h = { value: null, prev: null, next: null }, _ = { value: null, prev: h, next: null };
      h.next = _, this.head = h, this.tail = _, this.length = 0;
    }
    function f(h, _, g) {
      var b = _.next, F = { value: g, prev: _, next: b };
      return _.next = F, b.prev = F, h.length++, F;
    }
    function d(h, _, g) {
      for (var b = _.next, F = 0; F < g && b !== h.tail; F++)
        b = b.next;
      _.next = b, b.prev = _, h.length -= F;
    }
    function v(h) {
      for (var _ = [], g = h.head.next; g !== h.tail; )
        _.push(g.value), g = g.next;
      return _;
    }
    if (!n.document)
      return n.addEventListener && (r.disableWorkerMessageHandler || n.addEventListener("message", function(h) {
        var _ = JSON.parse(h.data), g = _.language, b = _.code, F = _.immediateClose;
        n.postMessage(r.highlight(b, r.languages[g], g)), F && n.close();
      }, !1)), r;
    var y = r.util.currentScript();
    y && (r.filename = y.src, y.hasAttribute("data-manual") && (r.manual = !0));
    function w() {
      r.manual || r.highlightAll();
    }
    if (!r.manual) {
      var C = document.readyState;
      C === "loading" || C === "interactive" && y && y.defer ? document.addEventListener("DOMContentLoaded", w) : window.requestAnimationFrame ? window.requestAnimationFrame(w) : window.setTimeout(w, 16);
    }
    return r;
  }(e);
  i.exports && (i.exports = t), typeof Pi < "u" && (Pi.Prism = t), t.languages.markup = {
    comment: {
      pattern: /<!--(?:(?!<!--)[\s\S])*?-->/,
      greedy: !0
    },
    prolog: {
      pattern: /<\?[\s\S]+?\?>/,
      greedy: !0
    },
    doctype: {
      // https://www.w3.org/TR/xml/#NT-doctypedecl
      pattern: /<!DOCTYPE(?:[^>"'[\]]|"[^"]*"|'[^']*')+(?:\[(?:[^<"'\]]|"[^"]*"|'[^']*'|<(?!!--)|<!--(?:[^-]|-(?!->))*-->)*\]\s*)?>/i,
      greedy: !0,
      inside: {
        "internal-subset": {
          pattern: /(^[^\[]*\[)[\s\S]+(?=\]>$)/,
          lookbehind: !0,
          greedy: !0,
          inside: null
          // see below
        },
        string: {
          pattern: /"[^"]*"|'[^']*'/,
          greedy: !0
        },
        punctuation: /^<!|>$|[[\]]/,
        "doctype-tag": /^DOCTYPE/i,
        name: /[^\s<>'"]+/
      }
    },
    cdata: {
      pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
      greedy: !0
    },
    tag: {
      pattern: /<\/?(?!\d)[^\s>\/=$<%]+(?:\s(?:\s*[^\s>\/=]+(?:\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))|(?=[\s/>])))+)?\s*\/?>/,
      greedy: !0,
      inside: {
        tag: {
          pattern: /^<\/?[^\s>\/]+/,
          inside: {
            punctuation: /^<\/?/,
            namespace: /^[^\s>\/:]+:/
          }
        },
        "special-attr": [],
        "attr-value": {
          pattern: /=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+)/,
          inside: {
            punctuation: [
              {
                pattern: /^=/,
                alias: "attr-equals"
              },
              {
                pattern: /^(\s*)["']|["']$/,
                lookbehind: !0
              }
            ]
          }
        },
        punctuation: /\/?>/,
        "attr-name": {
          pattern: /[^\s>\/]+/,
          inside: {
            namespace: /^[^\s>\/:]+:/
          }
        }
      }
    },
    entity: [
      {
        pattern: /&[\da-z]{1,8};/i,
        alias: "named-entity"
      },
      /&#x?[\da-f]{1,8};/i
    ]
  }, t.languages.markup.tag.inside["attr-value"].inside.entity = t.languages.markup.entity, t.languages.markup.doctype.inside["internal-subset"].inside = t.languages.markup, t.hooks.add("wrap", function(n) {
    n.type === "entity" && (n.attributes.title = n.content.replace(/&amp;/, "&"));
  }), Object.defineProperty(t.languages.markup.tag, "addInlined", {
    /**
     * Adds an inlined language to markup.
     *
     * An example of an inlined language is CSS with `<style>` tags.
     *
     * @param {string} tagName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addInlined('style', 'css');
     */
    value: function(l, o) {
      var a = {};
      a["language-" + o] = {
        pattern: /(^<!\[CDATA\[)[\s\S]+?(?=\]\]>$)/i,
        lookbehind: !0,
        inside: t.languages[o]
      }, a.cdata = /^<!\[CDATA\[|\]\]>$/i;
      var r = {
        "included-cdata": {
          pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
          inside: a
        }
      };
      r["language-" + o] = {
        pattern: /[\s\S]+/,
        inside: t.languages[o]
      };
      var s = {};
      s[l] = {
        pattern: RegExp(/(<__[^>]*>)(?:<!\[CDATA\[(?:[^\]]|\](?!\]>))*\]\]>|(?!<!\[CDATA\[)[\s\S])*?(?=<\/__>)/.source.replace(/__/g, function() {
          return l;
        }), "i"),
        lookbehind: !0,
        greedy: !0,
        inside: r
      }, t.languages.insertBefore("markup", "cdata", s);
    }
  }), Object.defineProperty(t.languages.markup.tag, "addAttribute", {
    /**
     * Adds an pattern to highlight languages embedded in HTML attributes.
     *
     * An example of an inlined language is CSS with `style` attributes.
     *
     * @param {string} attrName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addAttribute('style', 'css');
     */
    value: function(n, l) {
      t.languages.markup.tag.inside["special-attr"].push({
        pattern: RegExp(
          /(^|["'\s])/.source + "(?:" + n + ")" + /\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))/.source,
          "i"
        ),
        lookbehind: !0,
        inside: {
          "attr-name": /^[^\s=]+/,
          "attr-value": {
            pattern: /=[\s\S]+/,
            inside: {
              value: {
                pattern: /(^=\s*(["']|(?!["'])))\S[\s\S]*(?=\2$)/,
                lookbehind: !0,
                alias: [l, "language-" + l],
                inside: t.languages[l]
              },
              punctuation: [
                {
                  pattern: /^=/,
                  alias: "attr-equals"
                },
                /"|'/
              ]
            }
          }
        }
      });
    }
  }), t.languages.html = t.languages.markup, t.languages.mathml = t.languages.markup, t.languages.svg = t.languages.markup, t.languages.xml = t.languages.extend("markup", {}), t.languages.ssml = t.languages.xml, t.languages.atom = t.languages.xml, t.languages.rss = t.languages.xml, function(n) {
    var l = /(?:"(?:\\(?:\r\n|[\s\S])|[^"\\\r\n])*"|'(?:\\(?:\r\n|[\s\S])|[^'\\\r\n])*')/;
    n.languages.css = {
      comment: /\/\*[\s\S]*?\*\//,
      atrule: {
        pattern: RegExp("@[\\w-](?:" + /[^;{\s"']|\s+(?!\s)/.source + "|" + l.source + ")*?" + /(?:;|(?=\s*\{))/.source),
        inside: {
          rule: /^@[\w-]+/,
          "selector-function-argument": {
            pattern: /(\bselector\s*\(\s*(?![\s)]))(?:[^()\s]|\s+(?![\s)])|\((?:[^()]|\([^()]*\))*\))+(?=\s*\))/,
            lookbehind: !0,
            alias: "selector"
          },
          keyword: {
            pattern: /(^|[^\w-])(?:and|not|only|or)(?![\w-])/,
            lookbehind: !0
          }
          // See rest below
        }
      },
      url: {
        // https://drafts.csswg.org/css-values-3/#urls
        pattern: RegExp("\\burl\\((?:" + l.source + "|" + /(?:[^\\\r\n()"']|\\[\s\S])*/.source + ")\\)", "i"),
        greedy: !0,
        inside: {
          function: /^url/i,
          punctuation: /^\(|\)$/,
          string: {
            pattern: RegExp("^" + l.source + "$"),
            alias: "url"
          }
        }
      },
      selector: {
        pattern: RegExp(`(^|[{}\\s])[^{}\\s](?:[^{};"'\\s]|\\s+(?![\\s{])|` + l.source + ")*(?=\\s*\\{)"),
        lookbehind: !0
      },
      string: {
        pattern: l,
        greedy: !0
      },
      property: {
        pattern: /(^|[^-\w\xA0-\uFFFF])(?!\s)[-_a-z\xA0-\uFFFF](?:(?!\s)[-\w\xA0-\uFFFF])*(?=\s*:)/i,
        lookbehind: !0
      },
      important: /!important\b/i,
      function: {
        pattern: /(^|[^-a-z0-9])[-a-z0-9]+(?=\()/i,
        lookbehind: !0
      },
      punctuation: /[(){};:,]/
    }, n.languages.css.atrule.inside.rest = n.languages.css;
    var o = n.languages.markup;
    o && (o.tag.addInlined("style", "css"), o.tag.addAttribute("style", "css"));
  }(t), t.languages.clike = {
    comment: [
      {
        pattern: /(^|[^\\])\/\*[\s\S]*?(?:\*\/|$)/,
        lookbehind: !0,
        greedy: !0
      },
      {
        pattern: /(^|[^\\:])\/\/.*/,
        lookbehind: !0,
        greedy: !0
      }
    ],
    string: {
      pattern: /(["'])(?:\\(?:\r\n|[\s\S])|(?!\1)[^\\\r\n])*\1/,
      greedy: !0
    },
    "class-name": {
      pattern: /(\b(?:class|extends|implements|instanceof|interface|new|trait)\s+|\bcatch\s+\()[\w.\\]+/i,
      lookbehind: !0,
      inside: {
        punctuation: /[.\\]/
      }
    },
    keyword: /\b(?:break|catch|continue|do|else|finally|for|function|if|in|instanceof|new|null|return|throw|try|while)\b/,
    boolean: /\b(?:false|true)\b/,
    function: /\b\w+(?=\()/,
    number: /\b0x[\da-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:e[+-]?\d+)?/i,
    operator: /[<>]=?|[!=]=?=?|--?|\+\+?|&&?|\|\|?|[?*/~^%]/,
    punctuation: /[{}[\];(),.:]/
  }, t.languages.javascript = t.languages.extend("clike", {
    "class-name": [
      t.languages.clike["class-name"],
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$A-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\.(?:constructor|prototype))/,
        lookbehind: !0
      }
    ],
    keyword: [
      {
        pattern: /((?:^|\})\s*)catch\b/,
        lookbehind: !0
      },
      {
        pattern: /(^|[^.]|\.\.\.\s*)\b(?:as|assert(?=\s*\{)|async(?=\s*(?:function\b|\(|[$\w\xA0-\uFFFF]|$))|await|break|case|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally(?=\s*(?:\{|$))|for|from(?=\s*(?:['"]|$))|function|(?:get|set)(?=\s*(?:[#\[$\w\xA0-\uFFFF]|$))|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)\b/,
        lookbehind: !0
      }
    ],
    // Allow for all non-ASCII characters (See http://stackoverflow.com/a/2008444)
    function: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*(?:\.\s*(?:apply|bind|call)\s*)?\()/,
    number: {
      pattern: RegExp(
        /(^|[^\w$])/.source + "(?:" + // constant
        (/NaN|Infinity/.source + "|" + // binary integer
        /0[bB][01]+(?:_[01]+)*n?/.source + "|" + // octal integer
        /0[oO][0-7]+(?:_[0-7]+)*n?/.source + "|" + // hexadecimal integer
        /0[xX][\dA-Fa-f]+(?:_[\dA-Fa-f]+)*n?/.source + "|" + // decimal bigint
        /\d+(?:_\d+)*n/.source + "|" + // decimal number (integer or float) but no bigint
        /(?:\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\.\d+(?:_\d+)*)(?:[Ee][+-]?\d+(?:_\d+)*)?/.source) + ")" + /(?![\w$])/.source
      ),
      lookbehind: !0
    },
    operator: /--|\+\+|\*\*=?|=>|&&=?|\|\|=?|[!=]==|<<=?|>>>?=?|[-+*/%&|^!=<>]=?|\.{3}|\?\?=?|\?\.?|[~:]/
  }), t.languages.javascript["class-name"][0].pattern = /(\b(?:class|extends|implements|instanceof|interface|new)\s+)[\w.\\]+/, t.languages.insertBefore("javascript", "keyword", {
    regex: {
      pattern: RegExp(
        // lookbehind
        // eslint-disable-next-line regexp/no-dupe-characters-character-class
        /((?:^|[^$\w\xA0-\uFFFF."'\])\s]|\b(?:return|yield))\s*)/.source + // Regex pattern:
        // There are 2 regex patterns here. The RegExp set notation proposal added support for nested character
        // classes if the `v` flag is present. Unfortunately, nested CCs are both context-free and incompatible
        // with the only syntax, so we have to define 2 different regex patterns.
        /\//.source + "(?:" + /(?:\[(?:[^\]\\\r\n]|\\.)*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}/.source + "|" + // `v` flag syntax. This supports 3 levels of nested character classes.
        /(?:\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.)*\])*\])*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}v[dgimyus]{0,7}/.source + ")" + // lookahead
        /(?=(?:\s|\/\*(?:[^*]|\*(?!\/))*\*\/)*(?:$|[\r\n,.;:})\]]|\/\/))/.source
      ),
      lookbehind: !0,
      greedy: !0,
      inside: {
        "regex-source": {
          pattern: /^(\/)[\s\S]+(?=\/[a-z]*$)/,
          lookbehind: !0,
          alias: "language-regex",
          inside: t.languages.regex
        },
        "regex-delimiter": /^\/|\/$/,
        "regex-flags": /^[a-z]+$/
      }
    },
    // This must be declared before keyword because we use "function" inside the look-forward
    "function-variable": {
      pattern: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*[=:]\s*(?:async\s*)?(?:\bfunction\b|(?:\((?:[^()]|\([^()]*\))*\)|(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)\s*=>))/,
      alias: "function"
    },
    parameter: [
      {
        pattern: /(function(?:\s+(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)?\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\))/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$a-z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*=>)/i,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*=>)/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /((?:\b|\s|^)(?!(?:as|async|await|break|case|catch|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally|for|from|function|get|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|set|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)(?![$\w\xA0-\uFFFF]))(?:(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*\s*)\(\s*|\]\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*\{)/,
        lookbehind: !0,
        inside: t.languages.javascript
      }
    ],
    constant: /\b[A-Z](?:[A-Z_]|\dx?)*\b/
  }), t.languages.insertBefore("javascript", "string", {
    hashbang: {
      pattern: /^#!.*/,
      greedy: !0,
      alias: "comment"
    },
    "template-string": {
      pattern: /`(?:\\[\s\S]|\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}|(?!\$\{)[^\\`])*`/,
      greedy: !0,
      inside: {
        "template-punctuation": {
          pattern: /^`|`$/,
          alias: "string"
        },
        interpolation: {
          pattern: /((?:^|[^\\])(?:\\{2})*)\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}/,
          lookbehind: !0,
          inside: {
            "interpolation-punctuation": {
              pattern: /^\$\{|\}$/,
              alias: "punctuation"
            },
            rest: t.languages.javascript
          }
        },
        string: /[\s\S]+/
      }
    },
    "string-property": {
      pattern: /((?:^|[,{])[ \t]*)(["'])(?:\\(?:\r\n|[\s\S])|(?!\2)[^\\\r\n])*\2(?=\s*:)/m,
      lookbehind: !0,
      greedy: !0,
      alias: "property"
    }
  }), t.languages.insertBefore("javascript", "operator", {
    "literal-property": {
      pattern: /((?:^|[,{])[ \t]*)(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*:)/m,
      lookbehind: !0,
      alias: "property"
    }
  }), t.languages.markup && (t.languages.markup.tag.addInlined("script", "javascript"), t.languages.markup.tag.addAttribute(
    /on(?:abort|blur|change|click|composition(?:end|start|update)|dblclick|error|focus(?:in|out)?|key(?:down|up)|load|mouse(?:down|enter|leave|move|out|over|up)|reset|resize|scroll|select|slotchange|submit|unload|wheel)/.source,
    "javascript"
  )), t.languages.js = t.languages.javascript, function() {
    if (typeof t > "u" || typeof document > "u")
      return;
    Element.prototype.matches || (Element.prototype.matches = Element.prototype.msMatchesSelector || Element.prototype.webkitMatchesSelector);
    var n = "Loading…", l = function(y, w) {
      return "✖ Error " + y + " while fetching file: " + w;
    }, o = "✖ Error: File does not exist or is empty", a = {
      js: "javascript",
      py: "python",
      rb: "ruby",
      ps1: "powershell",
      psm1: "powershell",
      sh: "bash",
      bat: "batch",
      h: "c",
      tex: "latex"
    }, r = "data-src-status", s = "loading", u = "loaded", c = "failed", m = "pre[data-src]:not([" + r + '="' + u + '"]):not([' + r + '="' + s + '"])';
    function f(y, w, C) {
      var h = new XMLHttpRequest();
      h.open("GET", y, !0), h.onreadystatechange = function() {
        h.readyState == 4 && (h.status < 400 && h.responseText ? w(h.responseText) : h.status >= 400 ? C(l(h.status, h.statusText)) : C(o));
      }, h.send(null);
    }
    function d(y) {
      var w = /^\s*(\d+)\s*(?:(,)\s*(?:(\d+)\s*)?)?$/.exec(y || "");
      if (w) {
        var C = Number(w[1]), h = w[2], _ = w[3];
        return h ? _ ? [C, Number(_)] : [C, void 0] : [C, C];
      }
    }
    t.hooks.add("before-highlightall", function(y) {
      y.selector += ", " + m;
    }), t.hooks.add("before-sanity-check", function(y) {
      var w = (
        /** @type {HTMLPreElement} */
        y.element
      );
      if (w.matches(m)) {
        y.code = "", w.setAttribute(r, s);
        var C = w.appendChild(document.createElement("CODE"));
        C.textContent = n;
        var h = w.getAttribute("data-src"), _ = y.language;
        if (_ === "none") {
          var g = (/\.(\w+)$/.exec(h) || [, "none"])[1];
          _ = a[g] || g;
        }
        t.util.setLanguage(C, _), t.util.setLanguage(w, _);
        var b = t.plugins.autoloader;
        b && b.loadLanguages(_), f(
          h,
          function(F) {
            w.setAttribute(r, u);
            var A = d(w.getAttribute("data-range"));
            if (A) {
              var T = F.split(/\r\n?|\n/g), S = A[0], N = A[1] == null ? T.length : A[1];
              S < 0 && (S += T.length), S = Math.max(0, Math.min(S - 1, T.length)), N < 0 && (N += T.length), N = Math.max(0, Math.min(N, T.length)), F = T.slice(S, N).join(`
`), w.hasAttribute("data-start") || w.setAttribute("data-start", String(S + 1));
            }
            C.textContent = F, t.highlightElement(C);
          },
          function(F) {
            w.setAttribute(r, c), C.textContent = F;
          }
        );
      }
    }), t.plugins.fileHighlight = {
      /**
       * Executes the File Highlight plugin for all matching `pre` elements under the given container.
       *
       * Note: Elements which are already loaded or currently loading will not be touched by this method.
       *
       * @param {ParentNode} [container=document]
       */
      highlight: function(w) {
        for (var C = (w || document).querySelectorAll(m), h = 0, _; _ = C[h++]; )
          t.highlightElement(_);
      }
    };
    var v = !1;
    t.fileHighlight = function() {
      v || (console.warn("Prism.fileHighlight is deprecated. Use `Prism.plugins.fileHighlight.highlight` instead."), v = !0), t.plugins.fileHighlight.highlight.apply(this, arguments);
    };
  }();
})(Ko);
Prism.languages.python = {
  comment: {
    pattern: /(^|[^\\])#.*/,
    lookbehind: !0,
    greedy: !0
  },
  "string-interpolation": {
    pattern: /(?:f|fr|rf)(?:("""|''')[\s\S]*?\1|("|')(?:\\.|(?!\2)[^\\\r\n])*\2)/i,
    greedy: !0,
    inside: {
      interpolation: {
        // "{" <expression> <optional "!s", "!r", or "!a"> <optional ":" format specifier> "}"
        pattern: /((?:^|[^{])(?:\{\{)*)\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}])+\})+\})+\}/,
        lookbehind: !0,
        inside: {
          "format-spec": {
            pattern: /(:)[^:(){}]+(?=\}$)/,
            lookbehind: !0
          },
          "conversion-option": {
            pattern: /![sra](?=[:}]$)/,
            alias: "punctuation"
          },
          rest: null
        }
      },
      string: /[\s\S]+/
    }
  },
  "triple-quoted-string": {
    pattern: /(?:[rub]|br|rb)?("""|''')[\s\S]*?\1/i,
    greedy: !0,
    alias: "string"
  },
  string: {
    pattern: /(?:[rub]|br|rb)?("|')(?:\\.|(?!\1)[^\\\r\n])*\1/i,
    greedy: !0
  },
  function: {
    pattern: /((?:^|\s)def[ \t]+)[a-zA-Z_]\w*(?=\s*\()/g,
    lookbehind: !0
  },
  "class-name": {
    pattern: /(\bclass\s+)\w+/i,
    lookbehind: !0
  },
  decorator: {
    pattern: /(^[\t ]*)@\w+(?:\.\w+)*/m,
    lookbehind: !0,
    alias: ["annotation", "punctuation"],
    inside: {
      punctuation: /\./
    }
  },
  keyword: /\b(?:_(?=\s*:)|and|as|assert|async|await|break|case|class|continue|def|del|elif|else|except|exec|finally|for|from|global|if|import|in|is|lambda|match|nonlocal|not|or|pass|print|raise|return|try|while|with|yield)\b/,
  builtin: /\b(?:__import__|abs|all|any|apply|ascii|basestring|bin|bool|buffer|bytearray|bytes|callable|chr|classmethod|cmp|coerce|compile|complex|delattr|dict|dir|divmod|enumerate|eval|execfile|file|filter|float|format|frozenset|getattr|globals|hasattr|hash|help|hex|id|input|int|intern|isinstance|issubclass|iter|len|list|locals|long|map|max|memoryview|min|next|object|oct|open|ord|pow|property|range|raw_input|reduce|reload|repr|reversed|round|set|setattr|slice|sorted|staticmethod|str|sum|super|tuple|type|unichr|unicode|vars|xrange|zip)\b/,
  boolean: /\b(?:False|None|True)\b/,
  number: /\b0(?:b(?:_?[01])+|o(?:_?[0-7])+|x(?:_?[a-f0-9])+)\b|(?:\b\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\B\.\d+(?:_\d+)*)(?:e[+-]?\d+(?:_\d+)*)?j?(?!\w)/i,
  operator: /[-+%=]=?|!=|:=|\*\*?=?|\/\/?=?|<[<=>]?|>[=>]?|[&|^~]/,
  punctuation: /[{}[\];(),.:]/
};
Prism.languages.python["string-interpolation"].inside.interpolation.inside.rest = Prism.languages.python;
Prism.languages.py = Prism.languages.python;
(function(i) {
  var e = /\\(?:[^a-z()[\]]|[a-z*]+)/i, t = {
    "equation-command": {
      pattern: e,
      alias: "regex"
    }
  };
  i.languages.latex = {
    comment: /%.*/,
    // the verbatim environment prints whitespace to the document
    cdata: {
      pattern: /(\\begin\{((?:lstlisting|verbatim)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
      lookbehind: !0
    },
    /*
     * equations can be between $$ $$ or $ $ or \( \) or \[ \]
     * (all are multiline)
     */
    equation: [
      {
        pattern: /\$\$(?:\\[\s\S]|[^\\$])+\$\$|\$(?:\\[\s\S]|[^\\$])+\$|\\\([\s\S]*?\\\)|\\\[[\s\S]*?\\\]/,
        inside: t,
        alias: "string"
      },
      {
        pattern: /(\\begin\{((?:align|eqnarray|equation|gather|math|multline)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
        lookbehind: !0,
        inside: t,
        alias: "string"
      }
    ],
    /*
     * arguments which are keywords or references are highlighted
     * as keywords
     */
    keyword: {
      pattern: /(\\(?:begin|cite|documentclass|end|label|ref|usepackage)(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    url: {
      pattern: /(\\url\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    /*
     * section or chapter headlines are highlighted as bold so that
     * they stand out more
     */
    headline: {
      pattern: /(\\(?:chapter|frametitle|paragraph|part|section|subparagraph|subsection|subsubparagraph|subsubsection|subsubsubparagraph)\*?(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0,
      alias: "class-name"
    },
    function: {
      pattern: e,
      alias: "selector"
    },
    punctuation: /[[\]{}&]/
  }, i.languages.tex = i.languages.latex, i.languages.context = i.languages.latex;
})(Prism);
(function(i) {
  var e = "\\b(?:BASH|BASHOPTS|BASH_ALIASES|BASH_ARGC|BASH_ARGV|BASH_CMDS|BASH_COMPLETION_COMPAT_DIR|BASH_LINENO|BASH_REMATCH|BASH_SOURCE|BASH_VERSINFO|BASH_VERSION|COLORTERM|COLUMNS|COMP_WORDBREAKS|DBUS_SESSION_BUS_ADDRESS|DEFAULTS_PATH|DESKTOP_SESSION|DIRSTACK|DISPLAY|EUID|GDMSESSION|GDM_LANG|GNOME_KEYRING_CONTROL|GNOME_KEYRING_PID|GPG_AGENT_INFO|GROUPS|HISTCONTROL|HISTFILE|HISTFILESIZE|HISTSIZE|HOME|HOSTNAME|HOSTTYPE|IFS|INSTANCE|JOB|LANG|LANGUAGE|LC_ADDRESS|LC_ALL|LC_IDENTIFICATION|LC_MEASUREMENT|LC_MONETARY|LC_NAME|LC_NUMERIC|LC_PAPER|LC_TELEPHONE|LC_TIME|LESSCLOSE|LESSOPEN|LINES|LOGNAME|LS_COLORS|MACHTYPE|MAILCHECK|MANDATORY_PATH|NO_AT_BRIDGE|OLDPWD|OPTERR|OPTIND|ORBIT_SOCKETDIR|OSTYPE|PAPERSIZE|PATH|PIPESTATUS|PPID|PS1|PS2|PS3|PS4|PWD|RANDOM|REPLY|SECONDS|SELINUX_INIT|SESSION|SESSIONTYPE|SESSION_MANAGER|SHELL|SHELLOPTS|SHLVL|SSH_AUTH_SOCK|TERM|UID|UPSTART_EVENTS|UPSTART_INSTANCE|UPSTART_JOB|UPSTART_SESSION|USER|WINDOWID|XAUTHORITY|XDG_CONFIG_DIRS|XDG_CURRENT_DESKTOP|XDG_DATA_DIRS|XDG_GREETER_DATA_DIR|XDG_MENU_PREFIX|XDG_RUNTIME_DIR|XDG_SEAT|XDG_SEAT_PATH|XDG_SESSION_DESKTOP|XDG_SESSION_ID|XDG_SESSION_PATH|XDG_SESSION_TYPE|XDG_VTNR|XMODIFIERS)\\b", t = {
    pattern: /(^(["']?)\w+\2)[ \t]+\S.*/,
    lookbehind: !0,
    alias: "punctuation",
    // this looks reasonably well in all themes
    inside: null
    // see below
  }, n = {
    bash: t,
    environment: {
      pattern: RegExp("\\$" + e),
      alias: "constant"
    },
    variable: [
      // [0]: Arithmetic Environment
      {
        pattern: /\$?\(\([\s\S]+?\)\)/,
        greedy: !0,
        inside: {
          // If there is a $ sign at the beginning highlight $(( and )) as variable
          variable: [
            {
              pattern: /(^\$\(\([\s\S]+)\)\)/,
              lookbehind: !0
            },
            /^\$\(\(/
          ],
          number: /\b0x[\dA-Fa-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:[Ee]-?\d+)?/,
          // Operators according to https://www.gnu.org/software/bash/manual/bashref.html#Shell-Arithmetic
          operator: /--|\+\+|\*\*=?|<<=?|>>=?|&&|\|\||[=!+\-*/%<>^&|]=?|[?~:]/,
          // If there is no $ sign at the beginning highlight (( and )) as punctuation
          punctuation: /\(\(?|\)\)?|,|;/
        }
      },
      // [1]: Command Substitution
      {
        pattern: /\$\((?:\([^)]+\)|[^()])+\)|`[^`]+`/,
        greedy: !0,
        inside: {
          variable: /^\$\(|^`|\)$|`$/
        }
      },
      // [2]: Brace expansion
      {
        pattern: /\$\{[^}]+\}/,
        greedy: !0,
        inside: {
          operator: /:[-=?+]?|[!\/]|##?|%%?|\^\^?|,,?/,
          punctuation: /[\[\]]/,
          environment: {
            pattern: RegExp("(\\{)" + e),
            lookbehind: !0,
            alias: "constant"
          }
        }
      },
      /\$(?:\w+|[#?*!@$])/
    ],
    // Escape sequences from echo and printf's manuals, and escaped quotes.
    entity: /\\(?:[abceEfnrtv\\"]|O?[0-7]{1,3}|U[0-9a-fA-F]{8}|u[0-9a-fA-F]{4}|x[0-9a-fA-F]{1,2})/
  };
  i.languages.bash = {
    shebang: {
      pattern: /^#!\s*\/.*/,
      alias: "important"
    },
    comment: {
      pattern: /(^|[^"{\\$])#.*/,
      lookbehind: !0
    },
    "function-name": [
      // a) function foo {
      // b) foo() {
      // c) function foo() {
      // but not “foo {”
      {
        // a) and c)
        pattern: /(\bfunction\s+)[\w-]+(?=(?:\s*\(?:\s*\))?\s*\{)/,
        lookbehind: !0,
        alias: "function"
      },
      {
        // b)
        pattern: /\b[\w-]+(?=\s*\(\s*\)\s*\{)/,
        alias: "function"
      }
    ],
    // Highlight variable names as variables in for and select beginnings.
    "for-or-select": {
      pattern: /(\b(?:for|select)\s+)\w+(?=\s+in\s)/,
      alias: "variable",
      lookbehind: !0
    },
    // Highlight variable names as variables in the left-hand part
    // of assignments (“=” and “+=”).
    "assign-left": {
      pattern: /(^|[\s;|&]|[<>]\()\w+(?:\.\w+)*(?=\+?=)/,
      inside: {
        environment: {
          pattern: RegExp("(^|[\\s;|&]|[<>]\\()" + e),
          lookbehind: !0,
          alias: "constant"
        }
      },
      alias: "variable",
      lookbehind: !0
    },
    // Highlight parameter names as variables
    parameter: {
      pattern: /(^|\s)-{1,2}(?:\w+:[+-]?)?\w+(?:\.\w+)*(?=[=\s]|$)/,
      alias: "variable",
      lookbehind: !0
    },
    string: [
      // Support for Here-documents https://en.wikipedia.org/wiki/Here_document
      {
        pattern: /((?:^|[^<])<<-?\s*)(\w+)\s[\s\S]*?(?:\r?\n|\r)\2/,
        lookbehind: !0,
        greedy: !0,
        inside: n
      },
      // Here-document with quotes around the tag
      // → No expansion (so no “inside”).
      {
        pattern: /((?:^|[^<])<<-?\s*)(["'])(\w+)\2\s[\s\S]*?(?:\r?\n|\r)\3/,
        lookbehind: !0,
        greedy: !0,
        inside: {
          bash: t
        }
      },
      // “Normal” string
      {
        // https://www.gnu.org/software/bash/manual/html_node/Double-Quotes.html
        pattern: /(^|[^\\](?:\\\\)*)"(?:\\[\s\S]|\$\([^)]+\)|\$(?!\()|`[^`]+`|[^"\\`$])*"/,
        lookbehind: !0,
        greedy: !0,
        inside: n
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/Single-Quotes.html
        pattern: /(^|[^$\\])'[^']*'/,
        lookbehind: !0,
        greedy: !0
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/ANSI_002dC-Quoting.html
        pattern: /\$'(?:[^'\\]|\\[\s\S])*'/,
        greedy: !0,
        inside: {
          entity: n.entity
        }
      }
    ],
    environment: {
      pattern: RegExp("\\$?" + e),
      alias: "constant"
    },
    variable: n.variable,
    function: {
      pattern: /(^|[\s;|&]|[<>]\()(?:add|apropos|apt|apt-cache|apt-get|aptitude|aspell|automysqlbackup|awk|basename|bash|bc|bconsole|bg|bzip2|cal|cargo|cat|cfdisk|chgrp|chkconfig|chmod|chown|chroot|cksum|clear|cmp|column|comm|composer|cp|cron|crontab|csplit|curl|cut|date|dc|dd|ddrescue|debootstrap|df|diff|diff3|dig|dir|dircolors|dirname|dirs|dmesg|docker|docker-compose|du|egrep|eject|env|ethtool|expand|expect|expr|fdformat|fdisk|fg|fgrep|file|find|fmt|fold|format|free|fsck|ftp|fuser|gawk|git|gparted|grep|groupadd|groupdel|groupmod|groups|grub-mkconfig|gzip|halt|head|hg|history|host|hostname|htop|iconv|id|ifconfig|ifdown|ifup|import|install|ip|java|jobs|join|kill|killall|less|link|ln|locate|logname|logrotate|look|lpc|lpr|lprint|lprintd|lprintq|lprm|ls|lsof|lynx|make|man|mc|mdadm|mkconfig|mkdir|mke2fs|mkfifo|mkfs|mkisofs|mknod|mkswap|mmv|more|most|mount|mtools|mtr|mutt|mv|nano|nc|netstat|nice|nl|node|nohup|notify-send|npm|nslookup|op|open|parted|passwd|paste|pathchk|ping|pkill|pnpm|podman|podman-compose|popd|pr|printcap|printenv|ps|pushd|pv|quota|quotacheck|quotactl|ram|rar|rcp|reboot|remsync|rename|renice|rev|rm|rmdir|rpm|rsync|scp|screen|sdiff|sed|sendmail|seq|service|sftp|sh|shellcheck|shuf|shutdown|sleep|slocate|sort|split|ssh|stat|strace|su|sudo|sum|suspend|swapon|sync|sysctl|tac|tail|tar|tee|time|timeout|top|touch|tr|traceroute|tsort|tty|umount|uname|unexpand|uniq|units|unrar|unshar|unzip|update-grub|uptime|useradd|userdel|usermod|users|uudecode|uuencode|v|vcpkg|vdir|vi|vim|virsh|vmstat|wait|watch|wc|wget|whereis|which|who|whoami|write|xargs|xdg-open|yarn|yes|zenity|zip|zsh|zypper)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    keyword: {
      pattern: /(^|[\s;|&]|[<>]\()(?:case|do|done|elif|else|esac|fi|for|function|if|in|select|then|until|while)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    // https://www.gnu.org/software/bash/manual/html_node/Shell-Builtin-Commands.html
    builtin: {
      pattern: /(^|[\s;|&]|[<>]\()(?:\.|:|alias|bind|break|builtin|caller|cd|command|continue|declare|echo|enable|eval|exec|exit|export|getopts|hash|help|let|local|logout|mapfile|printf|pwd|read|readarray|readonly|return|set|shift|shopt|source|test|times|trap|type|typeset|ulimit|umask|unalias|unset)(?=$|[)\s;|&])/,
      lookbehind: !0,
      // Alias added to make those easier to distinguish from strings.
      alias: "class-name"
    },
    boolean: {
      pattern: /(^|[\s;|&]|[<>]\()(?:false|true)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    "file-descriptor": {
      pattern: /\B&\d\b/,
      alias: "important"
    },
    operator: {
      // Lots of redirections here, but not just that.
      pattern: /\d?<>|>\||\+=|=[=~]?|!=?|<<[<-]?|[&\d]?>>|\d[<>]&?|[<>][&=]?|&[>&]?|\|[&|]?/,
      inside: {
        "file-descriptor": {
          pattern: /^\d/,
          alias: "important"
        }
      }
    },
    punctuation: /\$?\(\(?|\)\)?|\.\.|[{}[\];\\]/,
    number: {
      pattern: /(^|\s)(?:[1-9]\d*|0)(?:[.,]\d+)?\b/,
      lookbehind: !0
    }
  }, t.inside = i.languages.bash;
  for (var l = [
    "comment",
    "function-name",
    "for-or-select",
    "assign-left",
    "parameter",
    "string",
    "environment",
    "function",
    "keyword",
    "builtin",
    "boolean",
    "file-descriptor",
    "operator",
    "punctuation",
    "number"
  ], o = n.variable[1].inside, a = 0; a < l.length; a++)
    o[l[a]] = i.languages.bash[l[a]];
  i.languages.sh = i.languages.bash, i.languages.shell = i.languages.bash;
})(Prism);
new dl();
const Qo = (i) => {
  const e = {};
  for (let t = 0, n = i.length; t < n; t++) {
    const l = i[t];
    for (const o in l)
      e[o] ? e[o] = e[o].concat(l[o]) : e[o] = l[o];
  }
  return e;
}, Jo = [
  "abbr",
  "accept",
  "accept-charset",
  "accesskey",
  "action",
  "align",
  "alink",
  "allow",
  "allowfullscreen",
  "alt",
  "anchor",
  "archive",
  "as",
  "async",
  "autocapitalize",
  "autocomplete",
  "autocorrect",
  "autofocus",
  "autopictureinpicture",
  "autoplay",
  "axis",
  "background",
  "behavior",
  "bgcolor",
  "border",
  "bordercolor",
  "capture",
  "cellpadding",
  "cellspacing",
  "challenge",
  "char",
  "charoff",
  "charset",
  "checked",
  "cite",
  "class",
  "classid",
  "clear",
  "code",
  "codebase",
  "codetype",
  "color",
  "cols",
  "colspan",
  "compact",
  "content",
  "contenteditable",
  "controls",
  "controlslist",
  "conversiondestination",
  "coords",
  "crossorigin",
  "csp",
  "data",
  "datetime",
  "declare",
  "decoding",
  "default",
  "defer",
  "dir",
  "direction",
  "dirname",
  "disabled",
  "disablepictureinpicture",
  "disableremoteplayback",
  "disallowdocumentaccess",
  "download",
  "draggable",
  "elementtiming",
  "enctype",
  "end",
  "enterkeyhint",
  "event",
  "exportparts",
  "face",
  "for",
  "form",
  "formaction",
  "formenctype",
  "formmethod",
  "formnovalidate",
  "formtarget",
  "frame",
  "frameborder",
  "headers",
  "height",
  "hidden",
  "high",
  "href",
  "hreflang",
  "hreftranslate",
  "hspace",
  "http-equiv",
  "id",
  "imagesizes",
  "imagesrcset",
  "importance",
  "impressiondata",
  "impressionexpiry",
  "incremental",
  "inert",
  "inputmode",
  "integrity",
  "invisible",
  "ismap",
  "keytype",
  "kind",
  "label",
  "lang",
  "language",
  "latencyhint",
  "leftmargin",
  "link",
  "list",
  "loading",
  "longdesc",
  "loop",
  "low",
  "lowsrc",
  "manifest",
  "marginheight",
  "marginwidth",
  "max",
  "maxlength",
  "mayscript",
  "media",
  "method",
  "min",
  "minlength",
  "multiple",
  "muted",
  "name",
  "nohref",
  "nomodule",
  "nonce",
  "noresize",
  "noshade",
  "novalidate",
  "nowrap",
  "object",
  "open",
  "optimum",
  "part",
  "pattern",
  "ping",
  "placeholder",
  "playsinline",
  "policy",
  "poster",
  "preload",
  "pseudo",
  "readonly",
  "referrerpolicy",
  "rel",
  "reportingorigin",
  "required",
  "resources",
  "rev",
  "reversed",
  "role",
  "rows",
  "rowspan",
  "rules",
  "sandbox",
  "scheme",
  "scope",
  "scopes",
  "scrollamount",
  "scrolldelay",
  "scrolling",
  "select",
  "selected",
  "shadowroot",
  "shadowrootdelegatesfocus",
  "shape",
  "size",
  "sizes",
  "slot",
  "span",
  "spellcheck",
  "src",
  "srclang",
  "srcset",
  "standby",
  "start",
  "step",
  "style",
  "summary",
  "tabindex",
  "target",
  "text",
  "title",
  "topmargin",
  "translate",
  "truespeed",
  "trusttoken",
  "type",
  "usemap",
  "valign",
  "value",
  "valuetype",
  "version",
  "virtualkeyboardpolicy",
  "vlink",
  "vspace",
  "webkitdirectory",
  "width",
  "wrap"
], er = [
  "accent-height",
  "accumulate",
  "additive",
  "alignment-baseline",
  "ascent",
  "attributename",
  "attributetype",
  "azimuth",
  "basefrequency",
  "baseline-shift",
  "begin",
  "bias",
  "by",
  "class",
  "clip",
  "clippathunits",
  "clip-path",
  "clip-rule",
  "color",
  "color-interpolation",
  "color-interpolation-filters",
  "color-profile",
  "color-rendering",
  "cx",
  "cy",
  "d",
  "dx",
  "dy",
  "diffuseconstant",
  "direction",
  "display",
  "divisor",
  "dominant-baseline",
  "dur",
  "edgemode",
  "elevation",
  "end",
  "fill",
  "fill-opacity",
  "fill-rule",
  "filter",
  "filterunits",
  "flood-color",
  "flood-opacity",
  "font-family",
  "font-size",
  "font-size-adjust",
  "font-stretch",
  "font-style",
  "font-variant",
  "font-weight",
  "fx",
  "fy",
  "g1",
  "g2",
  "glyph-name",
  "glyphref",
  "gradientunits",
  "gradienttransform",
  "height",
  "href",
  "id",
  "image-rendering",
  "in",
  "in2",
  "k",
  "k1",
  "k2",
  "k3",
  "k4",
  "kerning",
  "keypoints",
  "keysplines",
  "keytimes",
  "lang",
  "lengthadjust",
  "letter-spacing",
  "kernelmatrix",
  "kernelunitlength",
  "lighting-color",
  "local",
  "marker-end",
  "marker-mid",
  "marker-start",
  "markerheight",
  "markerunits",
  "markerwidth",
  "maskcontentunits",
  "maskunits",
  "max",
  "mask",
  "media",
  "method",
  "mode",
  "min",
  "name",
  "numoctaves",
  "offset",
  "operator",
  "opacity",
  "order",
  "orient",
  "orientation",
  "origin",
  "overflow",
  "paint-order",
  "path",
  "pathlength",
  "patterncontentunits",
  "patterntransform",
  "patternunits",
  "points",
  "preservealpha",
  "preserveaspectratio",
  "primitiveunits",
  "r",
  "rx",
  "ry",
  "radius",
  "refx",
  "refy",
  "repeatcount",
  "repeatdur",
  "restart",
  "result",
  "rotate",
  "scale",
  "seed",
  "shape-rendering",
  "specularconstant",
  "specularexponent",
  "spreadmethod",
  "startoffset",
  "stddeviation",
  "stitchtiles",
  "stop-color",
  "stop-opacity",
  "stroke-dasharray",
  "stroke-dashoffset",
  "stroke-linecap",
  "stroke-linejoin",
  "stroke-miterlimit",
  "stroke-opacity",
  "stroke",
  "stroke-width",
  "style",
  "surfacescale",
  "systemlanguage",
  "tabindex",
  "targetx",
  "targety",
  "transform",
  "transform-origin",
  "text-anchor",
  "text-decoration",
  "text-rendering",
  "textlength",
  "type",
  "u1",
  "u2",
  "unicode",
  "values",
  "viewbox",
  "visibility",
  "version",
  "vert-adv-y",
  "vert-origin-x",
  "vert-origin-y",
  "width",
  "word-spacing",
  "wrap",
  "writing-mode",
  "xchannelselector",
  "ychannelselector",
  "x",
  "x1",
  "x2",
  "xmlns",
  "y",
  "y1",
  "y2",
  "z",
  "zoomandpan"
], tr = [
  "accent",
  "accentunder",
  "align",
  "bevelled",
  "close",
  "columnsalign",
  "columnlines",
  "columnspan",
  "denomalign",
  "depth",
  "dir",
  "display",
  "displaystyle",
  "encoding",
  "fence",
  "frame",
  "height",
  "href",
  "id",
  "largeop",
  "length",
  "linethickness",
  "lspace",
  "lquote",
  "mathbackground",
  "mathcolor",
  "mathsize",
  "mathvariant",
  "maxsize",
  "minsize",
  "movablelimits",
  "notation",
  "numalign",
  "open",
  "rowalign",
  "rowlines",
  "rowspacing",
  "rowspan",
  "rspace",
  "rquote",
  "scriptlevel",
  "scriptminsize",
  "scriptsizemultiplier",
  "selection",
  "separator",
  "separators",
  "stretchy",
  "subscriptshift",
  "supscriptshift",
  "symmetric",
  "voffset",
  "width",
  "xmlns"
];
Qo([
  Object.fromEntries(Jo.map((i) => [i, ["*"]])),
  Object.fromEntries(er.map((i) => [i, ["svg:*"]])),
  Object.fromEntries(tr.map((i) => [i, ["math:*"]]))
]);
const {
  HtmlTagHydration: Js,
  SvelteComponent: eu,
  attr: tu,
  binding_callbacks: nu,
  children: iu,
  claim_element: au,
  claim_html_tag: lu,
  detach: ou,
  element: ru,
  init: su,
  insert_hydration: uu,
  noop: cu,
  safe_not_equal: _u,
  toggle_class: du
} = window.__gradio__svelte__internal, { afterUpdate: fu, tick: pu, onMount: hu } = window.__gradio__svelte__internal, {
  SvelteComponent: mu,
  attr: gu,
  children: vu,
  claim_component: Du,
  claim_element: bu,
  create_component: yu,
  destroy_component: wu,
  detach: Fu,
  element: $u,
  init: ku,
  insert_hydration: Eu,
  mount_component: Au,
  safe_not_equal: Cu,
  transition_in: Su,
  transition_out: Tu
} = window.__gradio__svelte__internal, {
  SvelteComponent: Bu,
  attr: Ru,
  check_outros: Iu,
  children: Lu,
  claim_component: Ou,
  claim_element: qu,
  claim_space: xu,
  create_component: Nu,
  create_slot: Mu,
  destroy_component: Pu,
  detach: zu,
  element: Uu,
  empty: Hu,
  get_all_dirty_from_scope: Gu,
  get_slot_changes: ju,
  group_outros: Vu,
  init: Wu,
  insert_hydration: Zu,
  mount_component: Yu,
  safe_not_equal: Xu,
  space: Ku,
  toggle_class: Qu,
  transition_in: Ju,
  transition_out: ec,
  update_slot_base: tc
} = window.__gradio__svelte__internal, {
  SvelteComponent: nc,
  append_hydration: ic,
  attr: ac,
  children: lc,
  claim_component: oc,
  claim_element: rc,
  claim_space: sc,
  claim_text: uc,
  create_component: cc,
  destroy_component: _c,
  detach: dc,
  element: fc,
  init: pc,
  insert_hydration: hc,
  mount_component: mc,
  safe_not_equal: gc,
  set_data: vc,
  space: Dc,
  text: bc,
  toggle_class: yc,
  transition_in: wc,
  transition_out: Fc
} = window.__gradio__svelte__internal, {
  SvelteComponent: nr,
  append_hydration: kn,
  attr: ht,
  bubble: ir,
  check_outros: ar,
  children: ei,
  claim_component: lr,
  claim_element: ti,
  claim_space: zi,
  claim_text: or,
  construct_svelte_component: Ui,
  create_component: Hi,
  create_slot: rr,
  destroy_component: Gi,
  detach: nn,
  element: ni,
  get_all_dirty_from_scope: sr,
  get_slot_changes: ur,
  group_outros: cr,
  init: _r,
  insert_hydration: fl,
  listen: dr,
  mount_component: ji,
  safe_not_equal: fr,
  set_data: pr,
  set_style: gn,
  space: Vi,
  text: hr,
  toggle_class: ye,
  transition_in: zn,
  transition_out: Un,
  update_slot_base: mr
} = window.__gradio__svelte__internal;
function Wi(i) {
  let e, t;
  return {
    c() {
      e = ni("span"), t = hr(
        /*label*/
        i[1]
      ), this.h();
    },
    l(n) {
      e = ti(n, "SPAN", { class: !0 });
      var l = ei(e);
      t = or(
        l,
        /*label*/
        i[1]
      ), l.forEach(nn), this.h();
    },
    h() {
      ht(e, "class", "svelte-qgco6m");
    },
    m(n, l) {
      fl(n, e, l), kn(e, t);
    },
    p(n, l) {
      l & /*label*/
      2 && pr(
        t,
        /*label*/
        n[1]
      );
    },
    d(n) {
      n && nn(e);
    }
  };
}
function gr(i) {
  let e, t, n, l, o, a, r, s, u = (
    /*show_label*/
    i[2] && Wi(i)
  );
  var c = (
    /*Icon*/
    i[0]
  );
  function m(v, y) {
    return {};
  }
  c && (l = Ui(c, m()));
  const f = (
    /*#slots*/
    i[14].default
  ), d = rr(
    f,
    i,
    /*$$scope*/
    i[13],
    null
  );
  return {
    c() {
      e = ni("button"), u && u.c(), t = Vi(), n = ni("div"), l && Hi(l.$$.fragment), o = Vi(), d && d.c(), this.h();
    },
    l(v) {
      e = ti(v, "BUTTON", {
        "aria-label": !0,
        "aria-haspopup": !0,
        title: !0,
        class: !0
      });
      var y = ei(e);
      u && u.l(y), t = zi(y), n = ti(y, "DIV", { class: !0 });
      var w = ei(n);
      l && lr(l.$$.fragment, w), o = zi(w), d && d.l(w), w.forEach(nn), y.forEach(nn), this.h();
    },
    h() {
      ht(n, "class", "svelte-qgco6m"), ye(
        n,
        "x-small",
        /*size*/
        i[4] === "x-small"
      ), ye(
        n,
        "small",
        /*size*/
        i[4] === "small"
      ), ye(
        n,
        "large",
        /*size*/
        i[4] === "large"
      ), ye(
        n,
        "medium",
        /*size*/
        i[4] === "medium"
      ), e.disabled = /*disabled*/
      i[7], ht(
        e,
        "aria-label",
        /*label*/
        i[1]
      ), ht(
        e,
        "aria-haspopup",
        /*hasPopup*/
        i[8]
      ), ht(
        e,
        "title",
        /*label*/
        i[1]
      ), ht(e, "class", "svelte-qgco6m"), ye(
        e,
        "pending",
        /*pending*/
        i[3]
      ), ye(
        e,
        "padded",
        /*padded*/
        i[5]
      ), ye(
        e,
        "highlight",
        /*highlight*/
        i[6]
      ), ye(
        e,
        "transparent",
        /*transparent*/
        i[9]
      ), gn(e, "color", !/*disabled*/
      i[7] && /*_color*/
      i[11] ? (
        /*_color*/
        i[11]
      ) : "var(--block-label-text-color)"), gn(e, "--bg-color", /*disabled*/
      i[7] ? "auto" : (
        /*background*/
        i[10]
      ));
    },
    m(v, y) {
      fl(v, e, y), u && u.m(e, null), kn(e, t), kn(e, n), l && ji(l, n, null), kn(n, o), d && d.m(n, null), a = !0, r || (s = dr(
        e,
        "click",
        /*click_handler*/
        i[15]
      ), r = !0);
    },
    p(v, [y]) {
      if (/*show_label*/
      v[2] ? u ? u.p(v, y) : (u = Wi(v), u.c(), u.m(e, t)) : u && (u.d(1), u = null), y & /*Icon*/
      1 && c !== (c = /*Icon*/
      v[0])) {
        if (l) {
          cr();
          const w = l;
          Un(w.$$.fragment, 1, 0, () => {
            Gi(w, 1);
          }), ar();
        }
        c ? (l = Ui(c, m()), Hi(l.$$.fragment), zn(l.$$.fragment, 1), ji(l, n, o)) : l = null;
      }
      d && d.p && (!a || y & /*$$scope*/
      8192) && mr(
        d,
        f,
        v,
        /*$$scope*/
        v[13],
        a ? ur(
          f,
          /*$$scope*/
          v[13],
          y,
          null
        ) : sr(
          /*$$scope*/
          v[13]
        ),
        null
      ), (!a || y & /*size*/
      16) && ye(
        n,
        "x-small",
        /*size*/
        v[4] === "x-small"
      ), (!a || y & /*size*/
      16) && ye(
        n,
        "small",
        /*size*/
        v[4] === "small"
      ), (!a || y & /*size*/
      16) && ye(
        n,
        "large",
        /*size*/
        v[4] === "large"
      ), (!a || y & /*size*/
      16) && ye(
        n,
        "medium",
        /*size*/
        v[4] === "medium"
      ), (!a || y & /*disabled*/
      128) && (e.disabled = /*disabled*/
      v[7]), (!a || y & /*label*/
      2) && ht(
        e,
        "aria-label",
        /*label*/
        v[1]
      ), (!a || y & /*hasPopup*/
      256) && ht(
        e,
        "aria-haspopup",
        /*hasPopup*/
        v[8]
      ), (!a || y & /*label*/
      2) && ht(
        e,
        "title",
        /*label*/
        v[1]
      ), (!a || y & /*pending*/
      8) && ye(
        e,
        "pending",
        /*pending*/
        v[3]
      ), (!a || y & /*padded*/
      32) && ye(
        e,
        "padded",
        /*padded*/
        v[5]
      ), (!a || y & /*highlight*/
      64) && ye(
        e,
        "highlight",
        /*highlight*/
        v[6]
      ), (!a || y & /*transparent*/
      512) && ye(
        e,
        "transparent",
        /*transparent*/
        v[9]
      ), y & /*disabled, _color*/
      2176 && gn(e, "color", !/*disabled*/
      v[7] && /*_color*/
      v[11] ? (
        /*_color*/
        v[11]
      ) : "var(--block-label-text-color)"), y & /*disabled, background*/
      1152 && gn(e, "--bg-color", /*disabled*/
      v[7] ? "auto" : (
        /*background*/
        v[10]
      ));
    },
    i(v) {
      a || (l && zn(l.$$.fragment, v), zn(d, v), a = !0);
    },
    o(v) {
      l && Un(l.$$.fragment, v), Un(d, v), a = !1;
    },
    d(v) {
      v && nn(e), u && u.d(), l && Gi(l), d && d.d(v), r = !1, s();
    }
  };
}
function vr(i, e, t) {
  let n, { $$slots: l = {}, $$scope: o } = e, { Icon: a } = e, { label: r = "" } = e, { show_label: s = !1 } = e, { pending: u = !1 } = e, { size: c = "small" } = e, { padded: m = !0 } = e, { highlight: f = !1 } = e, { disabled: d = !1 } = e, { hasPopup: v = !1 } = e, { color: y = "var(--block-label-text-color)" } = e, { transparent: w = !1 } = e, { background: C = "var(--block-background-fill)" } = e;
  function h(_) {
    ir.call(this, i, _);
  }
  return i.$$set = (_) => {
    "Icon" in _ && t(0, a = _.Icon), "label" in _ && t(1, r = _.label), "show_label" in _ && t(2, s = _.show_label), "pending" in _ && t(3, u = _.pending), "size" in _ && t(4, c = _.size), "padded" in _ && t(5, m = _.padded), "highlight" in _ && t(6, f = _.highlight), "disabled" in _ && t(7, d = _.disabled), "hasPopup" in _ && t(8, v = _.hasPopup), "color" in _ && t(12, y = _.color), "transparent" in _ && t(9, w = _.transparent), "background" in _ && t(10, C = _.background), "$$scope" in _ && t(13, o = _.$$scope);
  }, i.$$.update = () => {
    i.$$.dirty & /*highlight, color*/
    4160 && t(11, n = f ? "var(--color-accent)" : y);
  }, [
    a,
    r,
    s,
    u,
    c,
    m,
    f,
    d,
    v,
    w,
    C,
    n,
    y,
    o,
    l,
    h
  ];
}
class Dr extends nr {
  constructor(e) {
    super(), _r(this, e, vr, gr, fr, {
      Icon: 0,
      label: 1,
      show_label: 2,
      pending: 3,
      size: 4,
      padded: 5,
      highlight: 6,
      disabled: 7,
      hasPopup: 8,
      color: 12,
      transparent: 9,
      background: 10
    });
  }
}
const {
  SvelteComponent: $c,
  append_hydration: kc,
  attr: Ec,
  binding_callbacks: Ac,
  children: Cc,
  claim_element: Sc,
  create_slot: Tc,
  detach: Bc,
  element: Rc,
  get_all_dirty_from_scope: Ic,
  get_slot_changes: Lc,
  init: Oc,
  insert_hydration: qc,
  safe_not_equal: xc,
  toggle_class: Nc,
  transition_in: Mc,
  transition_out: Pc,
  update_slot_base: zc
} = window.__gradio__svelte__internal, {
  SvelteComponent: Uc,
  append_hydration: Hc,
  attr: Gc,
  children: jc,
  claim_svg_element: Vc,
  detach: Wc,
  init: Zc,
  insert_hydration: Yc,
  noop: Xc,
  safe_not_equal: Kc,
  svg_element: Qc
} = window.__gradio__svelte__internal, {
  SvelteComponent: Jc,
  append_hydration: e_,
  attr: t_,
  children: n_,
  claim_svg_element: i_,
  detach: a_,
  init: l_,
  insert_hydration: o_,
  noop: r_,
  safe_not_equal: s_,
  svg_element: u_
} = window.__gradio__svelte__internal, {
  SvelteComponent: c_,
  append_hydration: __,
  attr: d_,
  children: f_,
  claim_svg_element: p_,
  detach: h_,
  init: m_,
  insert_hydration: g_,
  noop: v_,
  safe_not_equal: D_,
  svg_element: b_
} = window.__gradio__svelte__internal, {
  SvelteComponent: y_,
  append_hydration: w_,
  attr: F_,
  children: $_,
  claim_svg_element: k_,
  detach: E_,
  init: A_,
  insert_hydration: C_,
  noop: S_,
  safe_not_equal: T_,
  svg_element: B_
} = window.__gradio__svelte__internal, {
  SvelteComponent: R_,
  append_hydration: I_,
  attr: L_,
  children: O_,
  claim_svg_element: q_,
  detach: x_,
  init: N_,
  insert_hydration: M_,
  noop: P_,
  safe_not_equal: z_,
  svg_element: U_
} = window.__gradio__svelte__internal, {
  SvelteComponent: H_,
  append_hydration: G_,
  attr: j_,
  children: V_,
  claim_svg_element: W_,
  detach: Z_,
  init: Y_,
  insert_hydration: X_,
  noop: K_,
  safe_not_equal: Q_,
  svg_element: J_
} = window.__gradio__svelte__internal, {
  SvelteComponent: ed,
  append_hydration: td,
  attr: nd,
  children: id,
  claim_svg_element: ad,
  detach: ld,
  init: od,
  insert_hydration: rd,
  noop: sd,
  safe_not_equal: ud,
  svg_element: cd
} = window.__gradio__svelte__internal, {
  SvelteComponent: _d,
  append_hydration: dd,
  attr: fd,
  children: pd,
  claim_svg_element: hd,
  detach: md,
  init: gd,
  insert_hydration: vd,
  noop: Dd,
  safe_not_equal: bd,
  svg_element: yd
} = window.__gradio__svelte__internal, {
  SvelteComponent: wd,
  append_hydration: Fd,
  attr: $d,
  children: kd,
  claim_svg_element: Ed,
  detach: Ad,
  init: Cd,
  insert_hydration: Sd,
  noop: Td,
  safe_not_equal: Bd,
  svg_element: Rd
} = window.__gradio__svelte__internal, {
  SvelteComponent: Id,
  append_hydration: Ld,
  attr: Od,
  children: qd,
  claim_svg_element: xd,
  detach: Nd,
  init: Md,
  insert_hydration: Pd,
  noop: zd,
  safe_not_equal: Ud,
  svg_element: Hd
} = window.__gradio__svelte__internal, {
  SvelteComponent: Gd,
  append_hydration: jd,
  attr: Vd,
  children: Wd,
  claim_svg_element: Zd,
  detach: Yd,
  init: Xd,
  insert_hydration: Kd,
  noop: Qd,
  safe_not_equal: Jd,
  svg_element: ef
} = window.__gradio__svelte__internal, {
  SvelteComponent: tf,
  append_hydration: nf,
  attr: af,
  children: lf,
  claim_svg_element: of,
  detach: rf,
  init: sf,
  insert_hydration: uf,
  noop: cf,
  safe_not_equal: _f,
  svg_element: df
} = window.__gradio__svelte__internal, {
  SvelteComponent: br,
  append_hydration: Hn,
  attr: He,
  children: vn,
  claim_svg_element: Dn,
  detach: Wt,
  init: yr,
  insert_hydration: wr,
  noop: Gn,
  safe_not_equal: Fr,
  set_style: et,
  svg_element: bn
} = window.__gradio__svelte__internal;
function $r(i) {
  let e, t, n, l;
  return {
    c() {
      e = bn("svg"), t = bn("g"), n = bn("path"), l = bn("path"), this.h();
    },
    l(o) {
      e = Dn(o, "svg", {
        width: !0,
        height: !0,
        viewBox: !0,
        version: !0,
        xmlns: !0,
        "xmlns:xlink": !0,
        "xml:space": !0,
        stroke: !0,
        style: !0
      });
      var a = vn(e);
      t = Dn(a, "g", { transform: !0 });
      var r = vn(t);
      n = Dn(r, "path", { d: !0, style: !0 }), vn(n).forEach(Wt), r.forEach(Wt), l = Dn(a, "path", { d: !0, style: !0 }), vn(l).forEach(Wt), a.forEach(Wt), this.h();
    },
    h() {
      He(n, "d", "M18,6L6.087,17.913"), et(n, "fill", "none"), et(n, "fill-rule", "nonzero"), et(n, "stroke-width", "2px"), He(t, "transform", "matrix(1.14096,-0.140958,-0.140958,1.14096,-0.0559523,0.0559523)"), He(l, "d", "M4.364,4.364L19.636,19.636"), et(l, "fill", "none"), et(l, "fill-rule", "nonzero"), et(l, "stroke-width", "2px"), He(e, "width", "100%"), He(e, "height", "100%"), He(e, "viewBox", "0 0 24 24"), He(e, "version", "1.1"), He(e, "xmlns", "http://www.w3.org/2000/svg"), He(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), He(e, "xml:space", "preserve"), He(e, "stroke", "currentColor"), et(e, "fill-rule", "evenodd"), et(e, "clip-rule", "evenodd"), et(e, "stroke-linecap", "round"), et(e, "stroke-linejoin", "round");
    },
    m(o, a) {
      wr(o, e, a), Hn(e, t), Hn(t, n), Hn(e, l);
    },
    p: Gn,
    i: Gn,
    o: Gn,
    d(o) {
      o && Wt(e);
    }
  };
}
class kr extends br {
  constructor(e) {
    super(), yr(this, e, null, $r, Fr, {});
  }
}
const {
  SvelteComponent: ff,
  append_hydration: pf,
  attr: hf,
  children: mf,
  claim_svg_element: gf,
  detach: vf,
  init: Df,
  insert_hydration: bf,
  noop: yf,
  safe_not_equal: wf,
  svg_element: Ff
} = window.__gradio__svelte__internal, {
  SvelteComponent: $f,
  append_hydration: kf,
  attr: Ef,
  children: Af,
  claim_svg_element: Cf,
  detach: Sf,
  init: Tf,
  insert_hydration: Bf,
  noop: Rf,
  safe_not_equal: If,
  svg_element: Lf
} = window.__gradio__svelte__internal, {
  SvelteComponent: Of,
  append_hydration: qf,
  attr: xf,
  children: Nf,
  claim_svg_element: Mf,
  detach: Pf,
  init: zf,
  insert_hydration: Uf,
  noop: Hf,
  safe_not_equal: Gf,
  svg_element: jf
} = window.__gradio__svelte__internal, {
  SvelteComponent: Vf,
  append_hydration: Wf,
  attr: Zf,
  children: Yf,
  claim_svg_element: Xf,
  detach: Kf,
  init: Qf,
  insert_hydration: Jf,
  noop: ep,
  safe_not_equal: tp,
  svg_element: np
} = window.__gradio__svelte__internal, {
  SvelteComponent: ip,
  append_hydration: ap,
  attr: lp,
  children: op,
  claim_svg_element: rp,
  detach: sp,
  init: up,
  insert_hydration: cp,
  noop: _p,
  safe_not_equal: dp,
  svg_element: fp
} = window.__gradio__svelte__internal, {
  SvelteComponent: pp,
  append_hydration: hp,
  attr: mp,
  children: gp,
  claim_svg_element: vp,
  detach: Dp,
  init: bp,
  insert_hydration: yp,
  noop: wp,
  safe_not_equal: Fp,
  svg_element: $p
} = window.__gradio__svelte__internal, {
  SvelteComponent: kp,
  append_hydration: Ep,
  attr: Ap,
  children: Cp,
  claim_svg_element: Sp,
  detach: Tp,
  init: Bp,
  insert_hydration: Rp,
  noop: Ip,
  safe_not_equal: Lp,
  svg_element: Op
} = window.__gradio__svelte__internal, {
  SvelteComponent: qp,
  append_hydration: xp,
  attr: Np,
  children: Mp,
  claim_svg_element: Pp,
  detach: zp,
  init: Up,
  insert_hydration: Hp,
  noop: Gp,
  safe_not_equal: jp,
  svg_element: Vp
} = window.__gradio__svelte__internal, {
  SvelteComponent: Wp,
  append_hydration: Zp,
  attr: Yp,
  children: Xp,
  claim_svg_element: Kp,
  detach: Qp,
  init: Jp,
  insert_hydration: eh,
  noop: th,
  safe_not_equal: nh,
  svg_element: ih
} = window.__gradio__svelte__internal, {
  SvelteComponent: ah,
  append_hydration: lh,
  attr: oh,
  children: rh,
  claim_svg_element: sh,
  detach: uh,
  init: ch,
  insert_hydration: _h,
  noop: dh,
  safe_not_equal: fh,
  svg_element: ph
} = window.__gradio__svelte__internal, {
  SvelteComponent: hh,
  append_hydration: mh,
  attr: gh,
  children: vh,
  claim_svg_element: Dh,
  detach: bh,
  init: yh,
  insert_hydration: wh,
  noop: Fh,
  safe_not_equal: $h,
  svg_element: kh
} = window.__gradio__svelte__internal, {
  SvelteComponent: Eh,
  append_hydration: Ah,
  attr: Ch,
  children: Sh,
  claim_svg_element: Th,
  detach: Bh,
  init: Rh,
  insert_hydration: Ih,
  noop: Lh,
  safe_not_equal: Oh,
  svg_element: qh
} = window.__gradio__svelte__internal, {
  SvelteComponent: xh,
  append_hydration: Nh,
  attr: Mh,
  children: Ph,
  claim_svg_element: zh,
  detach: Uh,
  init: Hh,
  insert_hydration: Gh,
  noop: jh,
  safe_not_equal: Vh,
  svg_element: Wh
} = window.__gradio__svelte__internal, {
  SvelteComponent: Zh,
  append_hydration: Yh,
  attr: Xh,
  children: Kh,
  claim_svg_element: Qh,
  detach: Jh,
  init: em,
  insert_hydration: tm,
  noop: nm,
  safe_not_equal: im,
  svg_element: am
} = window.__gradio__svelte__internal, {
  SvelteComponent: lm,
  append_hydration: om,
  attr: rm,
  children: sm,
  claim_svg_element: um,
  detach: cm,
  init: _m,
  insert_hydration: dm,
  noop: fm,
  safe_not_equal: pm,
  svg_element: hm
} = window.__gradio__svelte__internal, {
  SvelteComponent: mm,
  append_hydration: gm,
  attr: vm,
  children: Dm,
  claim_svg_element: bm,
  detach: ym,
  init: wm,
  insert_hydration: Fm,
  noop: $m,
  safe_not_equal: km,
  svg_element: Em
} = window.__gradio__svelte__internal, {
  SvelteComponent: Am,
  append_hydration: Cm,
  attr: Sm,
  children: Tm,
  claim_svg_element: Bm,
  detach: Rm,
  init: Im,
  insert_hydration: Lm,
  noop: Om,
  safe_not_equal: qm,
  svg_element: xm
} = window.__gradio__svelte__internal, {
  SvelteComponent: Nm,
  append_hydration: Mm,
  attr: Pm,
  children: zm,
  claim_svg_element: Um,
  detach: Hm,
  init: Gm,
  insert_hydration: jm,
  noop: Vm,
  safe_not_equal: Wm,
  svg_element: Zm
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ym,
  append_hydration: Xm,
  attr: Km,
  children: Qm,
  claim_svg_element: Jm,
  detach: eg,
  init: tg,
  insert_hydration: ng,
  noop: ig,
  safe_not_equal: ag,
  svg_element: lg
} = window.__gradio__svelte__internal, {
  SvelteComponent: og,
  append_hydration: rg,
  attr: sg,
  children: ug,
  claim_svg_element: cg,
  detach: _g,
  init: dg,
  insert_hydration: fg,
  noop: pg,
  safe_not_equal: hg,
  svg_element: mg
} = window.__gradio__svelte__internal, {
  SvelteComponent: gg,
  append_hydration: vg,
  attr: Dg,
  children: bg,
  claim_svg_element: yg,
  detach: wg,
  init: Fg,
  insert_hydration: $g,
  noop: kg,
  safe_not_equal: Eg,
  svg_element: Ag
} = window.__gradio__svelte__internal, {
  SvelteComponent: Cg,
  append_hydration: Sg,
  attr: Tg,
  children: Bg,
  claim_svg_element: Rg,
  detach: Ig,
  init: Lg,
  insert_hydration: Og,
  noop: qg,
  safe_not_equal: xg,
  svg_element: Ng
} = window.__gradio__svelte__internal, {
  SvelteComponent: Mg,
  append_hydration: Pg,
  attr: zg,
  children: Ug,
  claim_svg_element: Hg,
  detach: Gg,
  init: jg,
  insert_hydration: Vg,
  noop: Wg,
  safe_not_equal: Zg,
  svg_element: Yg
} = window.__gradio__svelte__internal, {
  SvelteComponent: Xg,
  append_hydration: Kg,
  attr: Qg,
  children: Jg,
  claim_svg_element: e0,
  detach: t0,
  init: n0,
  insert_hydration: i0,
  noop: a0,
  safe_not_equal: l0,
  svg_element: o0
} = window.__gradio__svelte__internal, {
  SvelteComponent: r0,
  append_hydration: s0,
  attr: u0,
  children: c0,
  claim_svg_element: _0,
  detach: d0,
  init: f0,
  insert_hydration: p0,
  noop: h0,
  safe_not_equal: m0,
  svg_element: g0
} = window.__gradio__svelte__internal, {
  SvelteComponent: v0,
  append_hydration: D0,
  attr: b0,
  children: y0,
  claim_svg_element: w0,
  detach: F0,
  init: $0,
  insert_hydration: k0,
  noop: E0,
  safe_not_equal: A0,
  svg_element: C0
} = window.__gradio__svelte__internal, {
  SvelteComponent: S0,
  append_hydration: T0,
  attr: B0,
  children: R0,
  claim_svg_element: I0,
  detach: L0,
  init: O0,
  insert_hydration: q0,
  noop: x0,
  safe_not_equal: N0,
  svg_element: M0
} = window.__gradio__svelte__internal, {
  SvelteComponent: P0,
  append_hydration: z0,
  attr: U0,
  children: H0,
  claim_svg_element: G0,
  detach: j0,
  init: V0,
  insert_hydration: W0,
  noop: Z0,
  safe_not_equal: Y0,
  svg_element: X0
} = window.__gradio__svelte__internal, {
  SvelteComponent: K0,
  append_hydration: Q0,
  attr: J0,
  children: e1,
  claim_svg_element: t1,
  detach: n1,
  init: i1,
  insert_hydration: a1,
  noop: l1,
  safe_not_equal: o1,
  svg_element: r1
} = window.__gradio__svelte__internal, {
  SvelteComponent: s1,
  append_hydration: u1,
  attr: c1,
  children: _1,
  claim_svg_element: d1,
  detach: f1,
  init: p1,
  insert_hydration: h1,
  noop: m1,
  safe_not_equal: g1,
  svg_element: v1
} = window.__gradio__svelte__internal, {
  SvelteComponent: D1,
  append_hydration: b1,
  attr: y1,
  children: w1,
  claim_svg_element: F1,
  detach: $1,
  init: k1,
  insert_hydration: E1,
  noop: A1,
  safe_not_equal: C1,
  svg_element: S1
} = window.__gradio__svelte__internal, {
  SvelteComponent: T1,
  append_hydration: B1,
  attr: R1,
  children: I1,
  claim_svg_element: L1,
  detach: O1,
  init: q1,
  insert_hydration: x1,
  noop: N1,
  safe_not_equal: M1,
  svg_element: P1
} = window.__gradio__svelte__internal, {
  SvelteComponent: z1,
  append_hydration: U1,
  attr: H1,
  children: G1,
  claim_svg_element: j1,
  detach: V1,
  init: W1,
  insert_hydration: Z1,
  noop: Y1,
  safe_not_equal: X1,
  svg_element: K1
} = window.__gradio__svelte__internal, {
  SvelteComponent: Q1,
  append_hydration: J1,
  attr: ev,
  children: tv,
  claim_svg_element: nv,
  detach: iv,
  init: av,
  insert_hydration: lv,
  noop: ov,
  safe_not_equal: rv,
  svg_element: sv
} = window.__gradio__svelte__internal, {
  SvelteComponent: uv,
  append_hydration: cv,
  attr: _v,
  children: dv,
  claim_svg_element: fv,
  detach: pv,
  init: hv,
  insert_hydration: mv,
  noop: gv,
  safe_not_equal: vv,
  set_style: Dv,
  svg_element: bv
} = window.__gradio__svelte__internal, {
  SvelteComponent: yv,
  append_hydration: wv,
  attr: Fv,
  children: $v,
  claim_svg_element: kv,
  detach: Ev,
  init: Av,
  insert_hydration: Cv,
  noop: Sv,
  safe_not_equal: Tv,
  svg_element: Bv
} = window.__gradio__svelte__internal, {
  SvelteComponent: Rv,
  append_hydration: Iv,
  attr: Lv,
  children: Ov,
  claim_svg_element: qv,
  detach: xv,
  init: Nv,
  insert_hydration: Mv,
  noop: Pv,
  safe_not_equal: zv,
  svg_element: Uv
} = window.__gradio__svelte__internal, {
  SvelteComponent: Hv,
  append_hydration: Gv,
  attr: jv,
  children: Vv,
  claim_svg_element: Wv,
  detach: Zv,
  init: Yv,
  insert_hydration: Xv,
  noop: Kv,
  safe_not_equal: Qv,
  svg_element: Jv
} = window.__gradio__svelte__internal, {
  SvelteComponent: eD,
  append_hydration: tD,
  attr: nD,
  children: iD,
  claim_svg_element: aD,
  detach: lD,
  init: oD,
  insert_hydration: rD,
  noop: sD,
  safe_not_equal: uD,
  svg_element: cD
} = window.__gradio__svelte__internal, {
  SvelteComponent: _D,
  append_hydration: dD,
  attr: fD,
  children: pD,
  claim_svg_element: hD,
  detach: mD,
  init: gD,
  insert_hydration: vD,
  noop: DD,
  safe_not_equal: bD,
  svg_element: yD
} = window.__gradio__svelte__internal, {
  SvelteComponent: wD,
  append_hydration: FD,
  attr: $D,
  children: kD,
  claim_svg_element: ED,
  detach: AD,
  init: CD,
  insert_hydration: SD,
  noop: TD,
  safe_not_equal: BD,
  svg_element: RD
} = window.__gradio__svelte__internal, {
  SvelteComponent: ID,
  append_hydration: LD,
  attr: OD,
  children: qD,
  claim_svg_element: xD,
  detach: ND,
  init: MD,
  insert_hydration: PD,
  noop: zD,
  safe_not_equal: UD,
  svg_element: HD
} = window.__gradio__svelte__internal, {
  SvelteComponent: GD,
  append_hydration: jD,
  attr: VD,
  children: WD,
  claim_svg_element: ZD,
  detach: YD,
  init: XD,
  insert_hydration: KD,
  noop: QD,
  safe_not_equal: JD,
  svg_element: eb
} = window.__gradio__svelte__internal, {
  SvelteComponent: tb,
  append_hydration: nb,
  attr: ib,
  children: ab,
  claim_svg_element: lb,
  claim_text: ob,
  detach: rb,
  init: sb,
  insert_hydration: ub,
  noop: cb,
  safe_not_equal: _b,
  svg_element: db,
  text: fb
} = window.__gradio__svelte__internal, {
  SvelteComponent: pb,
  append_hydration: hb,
  attr: mb,
  children: gb,
  claim_svg_element: vb,
  detach: Db,
  init: bb,
  insert_hydration: yb,
  noop: wb,
  safe_not_equal: Fb,
  svg_element: $b
} = window.__gradio__svelte__internal, {
  SvelteComponent: kb,
  append_hydration: Eb,
  attr: Ab,
  children: Cb,
  claim_svg_element: Sb,
  detach: Tb,
  init: Bb,
  insert_hydration: Rb,
  noop: Ib,
  safe_not_equal: Lb,
  svg_element: Ob
} = window.__gradio__svelte__internal, {
  SvelteComponent: qb,
  append_hydration: xb,
  attr: Nb,
  children: Mb,
  claim_svg_element: Pb,
  detach: zb,
  init: Ub,
  insert_hydration: Hb,
  noop: Gb,
  safe_not_equal: jb,
  svg_element: Vb
} = window.__gradio__svelte__internal, {
  SvelteComponent: Wb,
  append_hydration: Zb,
  attr: Yb,
  children: Xb,
  claim_svg_element: Kb,
  detach: Qb,
  init: Jb,
  insert_hydration: ey,
  noop: ty,
  safe_not_equal: ny,
  svg_element: iy
} = window.__gradio__svelte__internal, {
  SvelteComponent: ay,
  append_hydration: ly,
  attr: oy,
  children: ry,
  claim_svg_element: sy,
  detach: uy,
  init: cy,
  insert_hydration: _y,
  noop: dy,
  safe_not_equal: fy,
  svg_element: py
} = window.__gradio__svelte__internal, {
  SvelteComponent: hy,
  append_hydration: my,
  attr: gy,
  children: vy,
  claim_svg_element: Dy,
  detach: by,
  init: yy,
  insert_hydration: wy,
  noop: Fy,
  safe_not_equal: $y,
  svg_element: ky
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ey,
  append_hydration: Ay,
  attr: Cy,
  children: Sy,
  claim_svg_element: Ty,
  detach: By,
  init: Ry,
  insert_hydration: Iy,
  noop: Ly,
  safe_not_equal: Oy,
  svg_element: qy
} = window.__gradio__svelte__internal, {
  SvelteComponent: xy,
  append_hydration: Ny,
  attr: My,
  children: Py,
  claim_svg_element: zy,
  claim_text: Uy,
  detach: Hy,
  init: Gy,
  insert_hydration: jy,
  noop: Vy,
  safe_not_equal: Wy,
  svg_element: Zy,
  text: Yy
} = window.__gradio__svelte__internal, {
  SvelteComponent: Xy,
  append_hydration: Ky,
  attr: Qy,
  children: Jy,
  claim_svg_element: ew,
  claim_text: tw,
  detach: nw,
  init: iw,
  insert_hydration: aw,
  noop: lw,
  safe_not_equal: ow,
  svg_element: rw,
  text: sw
} = window.__gradio__svelte__internal, {
  SvelteComponent: uw,
  append_hydration: cw,
  attr: _w,
  children: dw,
  claim_svg_element: fw,
  claim_text: pw,
  detach: hw,
  init: mw,
  insert_hydration: gw,
  noop: vw,
  safe_not_equal: Dw,
  svg_element: bw,
  text: yw
} = window.__gradio__svelte__internal, {
  SvelteComponent: ww,
  append_hydration: Fw,
  attr: $w,
  children: kw,
  claim_svg_element: Ew,
  detach: Aw,
  init: Cw,
  insert_hydration: Sw,
  noop: Tw,
  safe_not_equal: Bw,
  svg_element: Rw
} = window.__gradio__svelte__internal, {
  SvelteComponent: Iw,
  append_hydration: Lw,
  attr: Ow,
  children: qw,
  claim_svg_element: xw,
  detach: Nw,
  init: Mw,
  insert_hydration: Pw,
  noop: zw,
  safe_not_equal: Uw,
  svg_element: Hw
} = window.__gradio__svelte__internal, {
  SvelteComponent: Gw,
  append_hydration: jw,
  attr: Vw,
  children: Ww,
  claim_svg_element: Zw,
  detach: Yw,
  init: Xw,
  insert_hydration: Kw,
  noop: Qw,
  safe_not_equal: Jw,
  svg_element: eF
} = window.__gradio__svelte__internal, {
  SvelteComponent: tF,
  append_hydration: nF,
  attr: iF,
  children: aF,
  claim_svg_element: lF,
  detach: oF,
  init: rF,
  insert_hydration: sF,
  noop: uF,
  safe_not_equal: cF,
  svg_element: _F
} = window.__gradio__svelte__internal, {
  SvelteComponent: dF,
  append_hydration: fF,
  attr: pF,
  children: hF,
  claim_svg_element: mF,
  detach: gF,
  init: vF,
  insert_hydration: DF,
  noop: bF,
  safe_not_equal: yF,
  svg_element: wF
} = window.__gradio__svelte__internal, {
  SvelteComponent: FF,
  append_hydration: $F,
  attr: kF,
  children: EF,
  claim_svg_element: AF,
  detach: CF,
  init: SF,
  insert_hydration: TF,
  noop: BF,
  safe_not_equal: RF,
  svg_element: IF
} = window.__gradio__svelte__internal, {
  SvelteComponent: LF,
  append_hydration: OF,
  attr: qF,
  children: xF,
  claim_svg_element: NF,
  detach: MF,
  init: PF,
  insert_hydration: zF,
  noop: UF,
  safe_not_equal: HF,
  svg_element: GF
} = window.__gradio__svelte__internal, {
  SvelteComponent: jF,
  append_hydration: VF,
  attr: WF,
  children: ZF,
  claim_svg_element: YF,
  detach: XF,
  init: KF,
  insert_hydration: QF,
  noop: JF,
  safe_not_equal: e$,
  svg_element: t$
} = window.__gradio__svelte__internal, Er = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], Zi = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
Er.reduce(
  (i, { color: e, primary: t, secondary: n }) => ({
    ...i,
    [e]: {
      primary: Zi[e][t],
      secondary: Zi[e][n]
    }
  }),
  {}
);
const {
  SvelteComponent: n$,
  claim_component: i$,
  create_component: a$,
  destroy_component: l$,
  init: o$,
  mount_component: r$,
  safe_not_equal: s$,
  transition_in: u$,
  transition_out: c$
} = window.__gradio__svelte__internal, { createEventDispatcher: _$ } = window.__gradio__svelte__internal, {
  SvelteComponent: d$,
  append_hydration: f$,
  attr: p$,
  check_outros: h$,
  children: m$,
  claim_component: g$,
  claim_element: v$,
  claim_space: D$,
  claim_text: b$,
  create_component: y$,
  destroy_component: w$,
  detach: F$,
  element: $$,
  empty: k$,
  group_outros: E$,
  init: A$,
  insert_hydration: C$,
  mount_component: S$,
  safe_not_equal: T$,
  set_data: B$,
  space: R$,
  text: I$,
  toggle_class: L$,
  transition_in: O$,
  transition_out: q$
} = window.__gradio__svelte__internal, {
  SvelteComponent: x$,
  attr: N$,
  children: M$,
  claim_element: P$,
  create_slot: z$,
  detach: U$,
  element: H$,
  get_all_dirty_from_scope: G$,
  get_slot_changes: j$,
  init: V$,
  insert_hydration: W$,
  safe_not_equal: Z$,
  toggle_class: Y$,
  transition_in: X$,
  transition_out: K$,
  update_slot_base: Q$
} = window.__gradio__svelte__internal, {
  SvelteComponent: J$,
  append_hydration: ek,
  attr: tk,
  check_outros: nk,
  children: ik,
  claim_component: ak,
  claim_element: lk,
  claim_space: ok,
  create_component: rk,
  destroy_component: sk,
  detach: uk,
  element: ck,
  empty: _k,
  group_outros: dk,
  init: fk,
  insert_hydration: pk,
  listen: hk,
  mount_component: mk,
  safe_not_equal: gk,
  space: vk,
  toggle_class: Dk,
  transition_in: bk,
  transition_out: yk
} = window.__gradio__svelte__internal, {
  SvelteComponent: wk,
  attr: Fk,
  children: $k,
  claim_element: kk,
  create_slot: Ek,
  detach: Ak,
  element: Ck,
  get_all_dirty_from_scope: Sk,
  get_slot_changes: Tk,
  init: Bk,
  insert_hydration: Rk,
  null_to_empty: Ik,
  safe_not_equal: Lk,
  transition_in: Ok,
  transition_out: qk,
  update_slot_base: xk
} = window.__gradio__svelte__internal, {
  SvelteComponent: Nk,
  check_outros: Mk,
  claim_component: Pk,
  create_component: zk,
  destroy_component: Uk,
  detach: Hk,
  empty: Gk,
  group_outros: jk,
  init: Vk,
  insert_hydration: Wk,
  mount_component: Zk,
  noop: Yk,
  safe_not_equal: Xk,
  transition_in: Kk,
  transition_out: Qk
} = window.__gradio__svelte__internal, { createEventDispatcher: Jk } = window.__gradio__svelte__internal;
function Nt(i) {
  let e = ["", "k", "M", "G", "T", "P", "E", "Z"], t = 0;
  for (; i > 1e3 && t < e.length - 1; )
    i /= 1e3, t++;
  let n = e[t];
  return (Number.isInteger(i) ? i : i.toFixed(1)) + n;
}
function En() {
}
const pl = typeof window < "u";
let Yi = pl ? () => window.performance.now() : () => Date.now(), hl = pl ? (i) => requestAnimationFrame(i) : En;
const Pt = /* @__PURE__ */ new Set();
function ml(i) {
  Pt.forEach((e) => {
    e.c(i) || (Pt.delete(e), e.f());
  }), Pt.size !== 0 && hl(ml);
}
function Ar(i) {
  let e;
  return Pt.size === 0 && hl(ml), { promise: new Promise((t) => {
    Pt.add(e = { c: i, f: t });
  }), abort() {
    Pt.delete(e);
  } };
}
const xt = [];
function Cr(i, e = En) {
  let t;
  const n = /* @__PURE__ */ new Set();
  function l(a) {
    if (s = a, ((r = i) != r ? s == s : r !== s || r && typeof r == "object" || typeof r == "function") && (i = a, t)) {
      const u = !xt.length;
      for (const c of n) c[1](), xt.push(c, i);
      if (u) {
        for (let c = 0; c < xt.length; c += 2) xt[c][0](xt[c + 1]);
        xt.length = 0;
      }
    }
    var r, s;
  }
  function o(a) {
    l(a(i));
  }
  return { set: l, update: o, subscribe: function(a, r = En) {
    const s = [a, r];
    return n.add(s), n.size === 1 && (t = e(l, o) || En), a(i), () => {
      n.delete(s), n.size === 0 && t && (t(), t = null);
    };
  } };
}
function Xi(i) {
  return Object.prototype.toString.call(i) === "[object Date]";
}
function ii(i, e, t, n) {
  if (typeof t == "number" || Xi(t)) {
    const l = n - t, o = (t - e) / (i.dt || 1 / 60), a = (o + (i.opts.stiffness * l - i.opts.damping * o) * i.inv_mass) * i.dt;
    return Math.abs(a) < i.opts.precision && Math.abs(l) < i.opts.precision ? n : (i.settled = !1, Xi(t) ? new Date(t.getTime() + a) : t + a);
  }
  if (Array.isArray(t)) return t.map((l, o) => ii(i, e[o], t[o], n[o]));
  if (typeof t == "object") {
    const l = {};
    for (const o in t) l[o] = ii(i, e[o], t[o], n[o]);
    return l;
  }
  throw new Error(`Cannot spring ${typeof t} values`);
}
function Ki(i, e = {}) {
  const t = Cr(i), { stiffness: n = 0.15, damping: l = 0.8, precision: o = 0.01 } = e;
  let a, r, s, u = i, c = i, m = 1, f = 0, d = !1;
  function v(w, C = {}) {
    c = w;
    const h = s = {};
    return i == null || C.hard || y.stiffness >= 1 && y.damping >= 1 ? (d = !0, a = Yi(), u = w, t.set(i = c), Promise.resolve()) : (C.soft && (f = 1 / (60 * (C.soft === !0 ? 0.5 : +C.soft)), m = 0), r || (a = Yi(), d = !1, r = Ar((_) => {
      if (d) return d = !1, r = null, !1;
      m = Math.min(m + f, 1);
      const g = { inv_mass: m, opts: y, settled: !0, dt: 60 * (_ - a) / 1e3 }, b = ii(g, u, i, c);
      return a = _, u = i, t.set(i = b), g.settled && (r = null), !g.settled;
    })), new Promise((_) => {
      r.promise.then(() => {
        h === s && _();
      });
    }));
  }
  const y = { set: v, update: (w, C) => v(w(c, i), C), subscribe: t.subscribe, stiffness: n, damping: l, precision: o };
  return y;
}
const {
  SvelteComponent: Sr,
  append_hydration: Ge,
  attr: j,
  children: Le,
  claim_element: Tr,
  claim_svg_element: je,
  component_subscribe: Qi,
  detach: Be,
  element: Br,
  init: Rr,
  insert_hydration: Ir,
  noop: Ji,
  safe_not_equal: Lr,
  set_style: yn,
  svg_element: Ve,
  toggle_class: ea
} = window.__gradio__svelte__internal, { onMount: Or } = window.__gradio__svelte__internal;
function qr(i) {
  let e, t, n, l, o, a, r, s, u, c, m, f;
  return {
    c() {
      e = Br("div"), t = Ve("svg"), n = Ve("g"), l = Ve("path"), o = Ve("path"), a = Ve("path"), r = Ve("path"), s = Ve("g"), u = Ve("path"), c = Ve("path"), m = Ve("path"), f = Ve("path"), this.h();
    },
    l(d) {
      e = Tr(d, "DIV", { class: !0 });
      var v = Le(e);
      t = je(v, "svg", {
        viewBox: !0,
        fill: !0,
        xmlns: !0,
        class: !0
      });
      var y = Le(t);
      n = je(y, "g", { style: !0 });
      var w = Le(n);
      l = je(w, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), Le(l).forEach(Be), o = je(w, "path", { d: !0, fill: !0, class: !0 }), Le(o).forEach(Be), a = je(w, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), Le(a).forEach(Be), r = je(w, "path", { d: !0, fill: !0, class: !0 }), Le(r).forEach(Be), w.forEach(Be), s = je(y, "g", { style: !0 });
      var C = Le(s);
      u = je(C, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), Le(u).forEach(Be), c = je(C, "path", { d: !0, fill: !0, class: !0 }), Le(c).forEach(Be), m = je(C, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), Le(m).forEach(Be), f = je(C, "path", { d: !0, fill: !0, class: !0 }), Le(f).forEach(Be), C.forEach(Be), y.forEach(Be), v.forEach(Be), this.h();
    },
    h() {
      j(l, "d", "M255.926 0.754768L509.702 139.936V221.027L255.926 81.8465V0.754768Z"), j(l, "fill", "#FF7C00"), j(l, "fill-opacity", "0.4"), j(l, "class", "svelte-43sxxs"), j(o, "d", "M509.69 139.936L254.981 279.641V361.255L509.69 221.55V139.936Z"), j(o, "fill", "#FF7C00"), j(o, "class", "svelte-43sxxs"), j(a, "d", "M0.250138 139.937L254.981 279.641V361.255L0.250138 221.55V139.937Z"), j(a, "fill", "#FF7C00"), j(a, "fill-opacity", "0.4"), j(a, "class", "svelte-43sxxs"), j(r, "d", "M255.923 0.232622L0.236328 139.936V221.55L255.923 81.8469V0.232622Z"), j(r, "fill", "#FF7C00"), j(r, "class", "svelte-43sxxs"), yn(n, "transform", "translate(" + /*$top*/
      i[1][0] + "px, " + /*$top*/
      i[1][1] + "px)"), j(u, "d", "M255.926 141.5L509.702 280.681V361.773L255.926 222.592V141.5Z"), j(u, "fill", "#FF7C00"), j(u, "fill-opacity", "0.4"), j(u, "class", "svelte-43sxxs"), j(c, "d", "M509.69 280.679L254.981 420.384V501.998L509.69 362.293V280.679Z"), j(c, "fill", "#FF7C00"), j(c, "class", "svelte-43sxxs"), j(m, "d", "M0.250138 280.681L254.981 420.386V502L0.250138 362.295V280.681Z"), j(m, "fill", "#FF7C00"), j(m, "fill-opacity", "0.4"), j(m, "class", "svelte-43sxxs"), j(f, "d", "M255.923 140.977L0.236328 280.68V362.294L255.923 222.591V140.977Z"), j(f, "fill", "#FF7C00"), j(f, "class", "svelte-43sxxs"), yn(s, "transform", "translate(" + /*$bottom*/
      i[2][0] + "px, " + /*$bottom*/
      i[2][1] + "px)"), j(t, "viewBox", "-1200 -1200 3000 3000"), j(t, "fill", "none"), j(t, "xmlns", "http://www.w3.org/2000/svg"), j(t, "class", "svelte-43sxxs"), j(e, "class", "svelte-43sxxs"), ea(
        e,
        "margin",
        /*margin*/
        i[0]
      );
    },
    m(d, v) {
      Ir(d, e, v), Ge(e, t), Ge(t, n), Ge(n, l), Ge(n, o), Ge(n, a), Ge(n, r), Ge(t, s), Ge(s, u), Ge(s, c), Ge(s, m), Ge(s, f);
    },
    p(d, [v]) {
      v & /*$top*/
      2 && yn(n, "transform", "translate(" + /*$top*/
      d[1][0] + "px, " + /*$top*/
      d[1][1] + "px)"), v & /*$bottom*/
      4 && yn(s, "transform", "translate(" + /*$bottom*/
      d[2][0] + "px, " + /*$bottom*/
      d[2][1] + "px)"), v & /*margin*/
      1 && ea(
        e,
        "margin",
        /*margin*/
        d[0]
      );
    },
    i: Ji,
    o: Ji,
    d(d) {
      d && Be(e);
    }
  };
}
function xr(i, e, t) {
  let n, l;
  var o = this && this.__awaiter || function(d, v, y, w) {
    function C(h) {
      return h instanceof y ? h : new y(function(_) {
        _(h);
      });
    }
    return new (y || (y = Promise))(function(h, _) {
      function g(A) {
        try {
          F(w.next(A));
        } catch (T) {
          _(T);
        }
      }
      function b(A) {
        try {
          F(w.throw(A));
        } catch (T) {
          _(T);
        }
      }
      function F(A) {
        A.done ? h(A.value) : C(A.value).then(g, b);
      }
      F((w = w.apply(d, v || [])).next());
    });
  };
  let { margin: a = !0 } = e;
  const r = Ki([0, 0]);
  Qi(i, r, (d) => t(1, n = d));
  const s = Ki([0, 0]);
  Qi(i, s, (d) => t(2, l = d));
  let u;
  function c() {
    return o(this, void 0, void 0, function* () {
      yield Promise.all([r.set([125, 140]), s.set([-125, -140])]), yield Promise.all([r.set([-125, 140]), s.set([125, -140])]), yield Promise.all([r.set([-125, 0]), s.set([125, -0])]), yield Promise.all([r.set([125, 0]), s.set([-125, 0])]);
    });
  }
  function m() {
    return o(this, void 0, void 0, function* () {
      yield c(), u || m();
    });
  }
  function f() {
    return o(this, void 0, void 0, function* () {
      yield Promise.all([r.set([125, 0]), s.set([-125, 0])]), m();
    });
  }
  return Or(() => (f(), () => u = !0)), i.$$set = (d) => {
    "margin" in d && t(0, a = d.margin);
  }, [a, n, l, r, s];
}
class Nr extends Sr {
  constructor(e) {
    super(), Rr(this, e, xr, qr, Lr, { margin: 0 });
  }
}
const {
  SvelteComponent: Mr,
  append_hydration: At,
  attr: Ye,
  binding_callbacks: ta,
  check_outros: ai,
  children: at,
  claim_component: gl,
  claim_element: lt,
  claim_space: qe,
  claim_text: ie,
  create_component: vl,
  create_slot: Dl,
  destroy_component: bl,
  destroy_each: yl,
  detach: O,
  element: ot,
  empty: Me,
  ensure_array_like: Bn,
  get_all_dirty_from_scope: wl,
  get_slot_changes: Fl,
  group_outros: li,
  init: Pr,
  insert_hydration: M,
  mount_component: $l,
  noop: oi,
  safe_not_equal: zr,
  set_data: Pe,
  set_style: $t,
  space: xe,
  text: ae,
  toggle_class: Oe,
  transition_in: Ze,
  transition_out: rt,
  update_slot_base: kl
} = window.__gradio__svelte__internal, { tick: Ur } = window.__gradio__svelte__internal, { onDestroy: Hr } = window.__gradio__svelte__internal, { createEventDispatcher: Gr } = window.__gradio__svelte__internal, jr = (i) => ({}), na = (i) => ({}), Vr = (i) => ({}), ia = (i) => ({});
function aa(i, e, t) {
  const n = i.slice();
  return n[40] = e[t], n[42] = t, n;
}
function la(i, e, t) {
  const n = i.slice();
  return n[40] = e[t], n;
}
function Wr(i) {
  let e, t, n, l, o = (
    /*i18n*/
    i[1]("common.error") + ""
  ), a, r, s;
  t = new Dr({
    props: {
      Icon: kr,
      label: (
        /*i18n*/
        i[1]("common.clear")
      ),
      disabled: !1
    }
  }), t.$on(
    "click",
    /*click_handler*/
    i[32]
  );
  const u = (
    /*#slots*/
    i[30].error
  ), c = Dl(
    u,
    i,
    /*$$scope*/
    i[29],
    na
  );
  return {
    c() {
      e = ot("div"), vl(t.$$.fragment), n = xe(), l = ot("span"), a = ae(o), r = xe(), c && c.c(), this.h();
    },
    l(m) {
      e = lt(m, "DIV", { class: !0 });
      var f = at(e);
      gl(t.$$.fragment, f), f.forEach(O), n = qe(m), l = lt(m, "SPAN", { class: !0 });
      var d = at(l);
      a = ie(d, o), d.forEach(O), r = qe(m), c && c.l(m), this.h();
    },
    h() {
      Ye(e, "class", "clear-status svelte-17v219f"), Ye(l, "class", "error svelte-17v219f");
    },
    m(m, f) {
      M(m, e, f), $l(t, e, null), M(m, n, f), M(m, l, f), At(l, a), M(m, r, f), c && c.m(m, f), s = !0;
    },
    p(m, f) {
      const d = {};
      f[0] & /*i18n*/
      2 && (d.label = /*i18n*/
      m[1]("common.clear")), t.$set(d), (!s || f[0] & /*i18n*/
      2) && o !== (o = /*i18n*/
      m[1]("common.error") + "") && Pe(a, o), c && c.p && (!s || f[0] & /*$$scope*/
      536870912) && kl(
        c,
        u,
        m,
        /*$$scope*/
        m[29],
        s ? Fl(
          u,
          /*$$scope*/
          m[29],
          f,
          jr
        ) : wl(
          /*$$scope*/
          m[29]
        ),
        na
      );
    },
    i(m) {
      s || (Ze(t.$$.fragment, m), Ze(c, m), s = !0);
    },
    o(m) {
      rt(t.$$.fragment, m), rt(c, m), s = !1;
    },
    d(m) {
      m && (O(e), O(n), O(l), O(r)), bl(t), c && c.d(m);
    }
  };
}
function Zr(i) {
  let e, t, n, l, o, a, r, s, u, c = (
    /*variant*/
    i[8] === "default" && /*show_eta_bar*/
    i[18] && /*show_progress*/
    i[6] === "full" && oa(i)
  );
  function m(_, g) {
    if (
      /*progress*/
      _[7]
    ) return Kr;
    if (
      /*queue_position*/
      _[2] !== null && /*queue_size*/
      _[3] !== void 0 && /*queue_position*/
      _[2] >= 0
    ) return Xr;
    if (
      /*queue_position*/
      _[2] === 0
    ) return Yr;
  }
  let f = m(i), d = f && f(i), v = (
    /*timer*/
    i[5] && ua(i)
  );
  const y = [ts, es], w = [];
  function C(_, g) {
    return (
      /*last_progress_level*/
      _[15] != null ? 0 : (
        /*show_progress*/
        _[6] === "full" ? 1 : -1
      )
    );
  }
  ~(o = C(i)) && (a = w[o] = y[o](i));
  let h = !/*timer*/
  i[5] && ma(i);
  return {
    c() {
      c && c.c(), e = xe(), t = ot("div"), d && d.c(), n = xe(), v && v.c(), l = xe(), a && a.c(), r = xe(), h && h.c(), s = Me(), this.h();
    },
    l(_) {
      c && c.l(_), e = qe(_), t = lt(_, "DIV", { class: !0 });
      var g = at(t);
      d && d.l(g), n = qe(g), v && v.l(g), g.forEach(O), l = qe(_), a && a.l(_), r = qe(_), h && h.l(_), s = Me(), this.h();
    },
    h() {
      Ye(t, "class", "progress-text svelte-17v219f"), Oe(
        t,
        "meta-text-center",
        /*variant*/
        i[8] === "center"
      ), Oe(
        t,
        "meta-text",
        /*variant*/
        i[8] === "default"
      );
    },
    m(_, g) {
      c && c.m(_, g), M(_, e, g), M(_, t, g), d && d.m(t, null), At(t, n), v && v.m(t, null), M(_, l, g), ~o && w[o].m(_, g), M(_, r, g), h && h.m(_, g), M(_, s, g), u = !0;
    },
    p(_, g) {
      /*variant*/
      _[8] === "default" && /*show_eta_bar*/
      _[18] && /*show_progress*/
      _[6] === "full" ? c ? c.p(_, g) : (c = oa(_), c.c(), c.m(e.parentNode, e)) : c && (c.d(1), c = null), f === (f = m(_)) && d ? d.p(_, g) : (d && d.d(1), d = f && f(_), d && (d.c(), d.m(t, n))), /*timer*/
      _[5] ? v ? v.p(_, g) : (v = ua(_), v.c(), v.m(t, null)) : v && (v.d(1), v = null), (!u || g[0] & /*variant*/
      256) && Oe(
        t,
        "meta-text-center",
        /*variant*/
        _[8] === "center"
      ), (!u || g[0] & /*variant*/
      256) && Oe(
        t,
        "meta-text",
        /*variant*/
        _[8] === "default"
      );
      let b = o;
      o = C(_), o === b ? ~o && w[o].p(_, g) : (a && (li(), rt(w[b], 1, 1, () => {
        w[b] = null;
      }), ai()), ~o ? (a = w[o], a ? a.p(_, g) : (a = w[o] = y[o](_), a.c()), Ze(a, 1), a.m(r.parentNode, r)) : a = null), /*timer*/
      _[5] ? h && (li(), rt(h, 1, 1, () => {
        h = null;
      }), ai()) : h ? (h.p(_, g), g[0] & /*timer*/
      32 && Ze(h, 1)) : (h = ma(_), h.c(), Ze(h, 1), h.m(s.parentNode, s));
    },
    i(_) {
      u || (Ze(a), Ze(h), u = !0);
    },
    o(_) {
      rt(a), rt(h), u = !1;
    },
    d(_) {
      _ && (O(e), O(t), O(l), O(r), O(s)), c && c.d(_), d && d.d(), v && v.d(), ~o && w[o].d(_), h && h.d(_);
    }
  };
}
function oa(i) {
  let e, t = `translateX(${/*eta_level*/
  (i[17] || 0) * 100 - 100}%)`;
  return {
    c() {
      e = ot("div"), this.h();
    },
    l(n) {
      e = lt(n, "DIV", { class: !0 }), at(e).forEach(O), this.h();
    },
    h() {
      Ye(e, "class", "eta-bar svelte-17v219f"), $t(e, "transform", t);
    },
    m(n, l) {
      M(n, e, l);
    },
    p(n, l) {
      l[0] & /*eta_level*/
      131072 && t !== (t = `translateX(${/*eta_level*/
      (n[17] || 0) * 100 - 100}%)`) && $t(e, "transform", t);
    },
    d(n) {
      n && O(e);
    }
  };
}
function Yr(i) {
  let e;
  return {
    c() {
      e = ae("processing |");
    },
    l(t) {
      e = ie(t, "processing |");
    },
    m(t, n) {
      M(t, e, n);
    },
    p: oi,
    d(t) {
      t && O(e);
    }
  };
}
function Xr(i) {
  let e, t = (
    /*queue_position*/
    i[2] + 1 + ""
  ), n, l, o, a;
  return {
    c() {
      e = ae("queue: "), n = ae(t), l = ae("/"), o = ae(
        /*queue_size*/
        i[3]
      ), a = ae(" |");
    },
    l(r) {
      e = ie(r, "queue: "), n = ie(r, t), l = ie(r, "/"), o = ie(
        r,
        /*queue_size*/
        i[3]
      ), a = ie(r, " |");
    },
    m(r, s) {
      M(r, e, s), M(r, n, s), M(r, l, s), M(r, o, s), M(r, a, s);
    },
    p(r, s) {
      s[0] & /*queue_position*/
      4 && t !== (t = /*queue_position*/
      r[2] + 1 + "") && Pe(n, t), s[0] & /*queue_size*/
      8 && Pe(
        o,
        /*queue_size*/
        r[3]
      );
    },
    d(r) {
      r && (O(e), O(n), O(l), O(o), O(a));
    }
  };
}
function Kr(i) {
  let e, t = Bn(
    /*progress*/
    i[7]
  ), n = [];
  for (let l = 0; l < t.length; l += 1)
    n[l] = sa(la(i, t, l));
  return {
    c() {
      for (let l = 0; l < n.length; l += 1)
        n[l].c();
      e = Me();
    },
    l(l) {
      for (let o = 0; o < n.length; o += 1)
        n[o].l(l);
      e = Me();
    },
    m(l, o) {
      for (let a = 0; a < n.length; a += 1)
        n[a] && n[a].m(l, o);
      M(l, e, o);
    },
    p(l, o) {
      if (o[0] & /*progress*/
      128) {
        t = Bn(
          /*progress*/
          l[7]
        );
        let a;
        for (a = 0; a < t.length; a += 1) {
          const r = la(l, t, a);
          n[a] ? n[a].p(r, o) : (n[a] = sa(r), n[a].c(), n[a].m(e.parentNode, e));
        }
        for (; a < n.length; a += 1)
          n[a].d(1);
        n.length = t.length;
      }
    },
    d(l) {
      l && O(e), yl(n, l);
    }
  };
}
function ra(i) {
  let e, t = (
    /*p*/
    i[40].unit + ""
  ), n, l, o = " ", a;
  function r(c, m) {
    return (
      /*p*/
      c[40].length != null ? Jr : Qr
    );
  }
  let s = r(i), u = s(i);
  return {
    c() {
      u.c(), e = xe(), n = ae(t), l = ae(" | "), a = ae(o);
    },
    l(c) {
      u.l(c), e = qe(c), n = ie(c, t), l = ie(c, " | "), a = ie(c, o);
    },
    m(c, m) {
      u.m(c, m), M(c, e, m), M(c, n, m), M(c, l, m), M(c, a, m);
    },
    p(c, m) {
      s === (s = r(c)) && u ? u.p(c, m) : (u.d(1), u = s(c), u && (u.c(), u.m(e.parentNode, e))), m[0] & /*progress*/
      128 && t !== (t = /*p*/
      c[40].unit + "") && Pe(n, t);
    },
    d(c) {
      c && (O(e), O(n), O(l), O(a)), u.d(c);
    }
  };
}
function Qr(i) {
  let e = Nt(
    /*p*/
    i[40].index || 0
  ) + "", t;
  return {
    c() {
      t = ae(e);
    },
    l(n) {
      t = ie(n, e);
    },
    m(n, l) {
      M(n, t, l);
    },
    p(n, l) {
      l[0] & /*progress*/
      128 && e !== (e = Nt(
        /*p*/
        n[40].index || 0
      ) + "") && Pe(t, e);
    },
    d(n) {
      n && O(t);
    }
  };
}
function Jr(i) {
  let e = Nt(
    /*p*/
    i[40].index || 0
  ) + "", t, n, l = Nt(
    /*p*/
    i[40].length
  ) + "", o;
  return {
    c() {
      t = ae(e), n = ae("/"), o = ae(l);
    },
    l(a) {
      t = ie(a, e), n = ie(a, "/"), o = ie(a, l);
    },
    m(a, r) {
      M(a, t, r), M(a, n, r), M(a, o, r);
    },
    p(a, r) {
      r[0] & /*progress*/
      128 && e !== (e = Nt(
        /*p*/
        a[40].index || 0
      ) + "") && Pe(t, e), r[0] & /*progress*/
      128 && l !== (l = Nt(
        /*p*/
        a[40].length
      ) + "") && Pe(o, l);
    },
    d(a) {
      a && (O(t), O(n), O(o));
    }
  };
}
function sa(i) {
  let e, t = (
    /*p*/
    i[40].index != null && ra(i)
  );
  return {
    c() {
      t && t.c(), e = Me();
    },
    l(n) {
      t && t.l(n), e = Me();
    },
    m(n, l) {
      t && t.m(n, l), M(n, e, l);
    },
    p(n, l) {
      /*p*/
      n[40].index != null ? t ? t.p(n, l) : (t = ra(n), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(n) {
      n && O(e), t && t.d(n);
    }
  };
}
function ua(i) {
  let e, t = (
    /*eta*/
    i[0] ? `/${/*formatted_eta*/
    i[19]}` : ""
  ), n, l;
  return {
    c() {
      e = ae(
        /*formatted_timer*/
        i[20]
      ), n = ae(t), l = ae("s");
    },
    l(o) {
      e = ie(
        o,
        /*formatted_timer*/
        i[20]
      ), n = ie(o, t), l = ie(o, "s");
    },
    m(o, a) {
      M(o, e, a), M(o, n, a), M(o, l, a);
    },
    p(o, a) {
      a[0] & /*formatted_timer*/
      1048576 && Pe(
        e,
        /*formatted_timer*/
        o[20]
      ), a[0] & /*eta, formatted_eta*/
      524289 && t !== (t = /*eta*/
      o[0] ? `/${/*formatted_eta*/
      o[19]}` : "") && Pe(n, t);
    },
    d(o) {
      o && (O(e), O(n), O(l));
    }
  };
}
function es(i) {
  let e, t;
  return e = new Nr({
    props: { margin: (
      /*variant*/
      i[8] === "default"
    ) }
  }), {
    c() {
      vl(e.$$.fragment);
    },
    l(n) {
      gl(e.$$.fragment, n);
    },
    m(n, l) {
      $l(e, n, l), t = !0;
    },
    p(n, l) {
      const o = {};
      l[0] & /*variant*/
      256 && (o.margin = /*variant*/
      n[8] === "default"), e.$set(o);
    },
    i(n) {
      t || (Ze(e.$$.fragment, n), t = !0);
    },
    o(n) {
      rt(e.$$.fragment, n), t = !1;
    },
    d(n) {
      bl(e, n);
    }
  };
}
function ts(i) {
  let e, t, n, l, o, a = `${/*last_progress_level*/
  i[15] * 100}%`, r = (
    /*progress*/
    i[7] != null && ca(i)
  );
  return {
    c() {
      e = ot("div"), t = ot("div"), r && r.c(), n = xe(), l = ot("div"), o = ot("div"), this.h();
    },
    l(s) {
      e = lt(s, "DIV", { class: !0 });
      var u = at(e);
      t = lt(u, "DIV", { class: !0 });
      var c = at(t);
      r && r.l(c), c.forEach(O), n = qe(u), l = lt(u, "DIV", { class: !0 });
      var m = at(l);
      o = lt(m, "DIV", { class: !0 }), at(o).forEach(O), m.forEach(O), u.forEach(O), this.h();
    },
    h() {
      Ye(t, "class", "progress-level-inner svelte-17v219f"), Ye(o, "class", "progress-bar svelte-17v219f"), $t(o, "width", a), Ye(l, "class", "progress-bar-wrap svelte-17v219f"), Ye(e, "class", "progress-level svelte-17v219f");
    },
    m(s, u) {
      M(s, e, u), At(e, t), r && r.m(t, null), At(e, n), At(e, l), At(l, o), i[31](o);
    },
    p(s, u) {
      /*progress*/
      s[7] != null ? r ? r.p(s, u) : (r = ca(s), r.c(), r.m(t, null)) : r && (r.d(1), r = null), u[0] & /*last_progress_level*/
      32768 && a !== (a = `${/*last_progress_level*/
      s[15] * 100}%`) && $t(o, "width", a);
    },
    i: oi,
    o: oi,
    d(s) {
      s && O(e), r && r.d(), i[31](null);
    }
  };
}
function ca(i) {
  let e, t = Bn(
    /*progress*/
    i[7]
  ), n = [];
  for (let l = 0; l < t.length; l += 1)
    n[l] = ha(aa(i, t, l));
  return {
    c() {
      for (let l = 0; l < n.length; l += 1)
        n[l].c();
      e = Me();
    },
    l(l) {
      for (let o = 0; o < n.length; o += 1)
        n[o].l(l);
      e = Me();
    },
    m(l, o) {
      for (let a = 0; a < n.length; a += 1)
        n[a] && n[a].m(l, o);
      M(l, e, o);
    },
    p(l, o) {
      if (o[0] & /*progress_level, progress*/
      16512) {
        t = Bn(
          /*progress*/
          l[7]
        );
        let a;
        for (a = 0; a < t.length; a += 1) {
          const r = aa(l, t, a);
          n[a] ? n[a].p(r, o) : (n[a] = ha(r), n[a].c(), n[a].m(e.parentNode, e));
        }
        for (; a < n.length; a += 1)
          n[a].d(1);
        n.length = t.length;
      }
    },
    d(l) {
      l && O(e), yl(n, l);
    }
  };
}
function _a(i) {
  let e, t, n, l, o = (
    /*i*/
    i[42] !== 0 && ns()
  ), a = (
    /*p*/
    i[40].desc != null && da(i)
  ), r = (
    /*p*/
    i[40].desc != null && /*progress_level*/
    i[14] && /*progress_level*/
    i[14][
      /*i*/
      i[42]
    ] != null && fa()
  ), s = (
    /*progress_level*/
    i[14] != null && pa(i)
  );
  return {
    c() {
      o && o.c(), e = xe(), a && a.c(), t = xe(), r && r.c(), n = xe(), s && s.c(), l = Me();
    },
    l(u) {
      o && o.l(u), e = qe(u), a && a.l(u), t = qe(u), r && r.l(u), n = qe(u), s && s.l(u), l = Me();
    },
    m(u, c) {
      o && o.m(u, c), M(u, e, c), a && a.m(u, c), M(u, t, c), r && r.m(u, c), M(u, n, c), s && s.m(u, c), M(u, l, c);
    },
    p(u, c) {
      /*p*/
      u[40].desc != null ? a ? a.p(u, c) : (a = da(u), a.c(), a.m(t.parentNode, t)) : a && (a.d(1), a = null), /*p*/
      u[40].desc != null && /*progress_level*/
      u[14] && /*progress_level*/
      u[14][
        /*i*/
        u[42]
      ] != null ? r || (r = fa(), r.c(), r.m(n.parentNode, n)) : r && (r.d(1), r = null), /*progress_level*/
      u[14] != null ? s ? s.p(u, c) : (s = pa(u), s.c(), s.m(l.parentNode, l)) : s && (s.d(1), s = null);
    },
    d(u) {
      u && (O(e), O(t), O(n), O(l)), o && o.d(u), a && a.d(u), r && r.d(u), s && s.d(u);
    }
  };
}
function ns(i) {
  let e;
  return {
    c() {
      e = ae(" /");
    },
    l(t) {
      e = ie(t, " /");
    },
    m(t, n) {
      M(t, e, n);
    },
    d(t) {
      t && O(e);
    }
  };
}
function da(i) {
  let e = (
    /*p*/
    i[40].desc + ""
  ), t;
  return {
    c() {
      t = ae(e);
    },
    l(n) {
      t = ie(n, e);
    },
    m(n, l) {
      M(n, t, l);
    },
    p(n, l) {
      l[0] & /*progress*/
      128 && e !== (e = /*p*/
      n[40].desc + "") && Pe(t, e);
    },
    d(n) {
      n && O(t);
    }
  };
}
function fa(i) {
  let e;
  return {
    c() {
      e = ae("-");
    },
    l(t) {
      e = ie(t, "-");
    },
    m(t, n) {
      M(t, e, n);
    },
    d(t) {
      t && O(e);
    }
  };
}
function pa(i) {
  let e = (100 * /*progress_level*/
  (i[14][
    /*i*/
    i[42]
  ] || 0)).toFixed(1) + "", t, n;
  return {
    c() {
      t = ae(e), n = ae("%");
    },
    l(l) {
      t = ie(l, e), n = ie(l, "%");
    },
    m(l, o) {
      M(l, t, o), M(l, n, o);
    },
    p(l, o) {
      o[0] & /*progress_level*/
      16384 && e !== (e = (100 * /*progress_level*/
      (l[14][
        /*i*/
        l[42]
      ] || 0)).toFixed(1) + "") && Pe(t, e);
    },
    d(l) {
      l && (O(t), O(n));
    }
  };
}
function ha(i) {
  let e, t = (
    /*p*/
    (i[40].desc != null || /*progress_level*/
    i[14] && /*progress_level*/
    i[14][
      /*i*/
      i[42]
    ] != null) && _a(i)
  );
  return {
    c() {
      t && t.c(), e = Me();
    },
    l(n) {
      t && t.l(n), e = Me();
    },
    m(n, l) {
      t && t.m(n, l), M(n, e, l);
    },
    p(n, l) {
      /*p*/
      n[40].desc != null || /*progress_level*/
      n[14] && /*progress_level*/
      n[14][
        /*i*/
        n[42]
      ] != null ? t ? t.p(n, l) : (t = _a(n), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(n) {
      n && O(e), t && t.d(n);
    }
  };
}
function ma(i) {
  let e, t, n, l;
  const o = (
    /*#slots*/
    i[30]["additional-loading-text"]
  ), a = Dl(
    o,
    i,
    /*$$scope*/
    i[29],
    ia
  );
  return {
    c() {
      e = ot("p"), t = ae(
        /*loading_text*/
        i[9]
      ), n = xe(), a && a.c(), this.h();
    },
    l(r) {
      e = lt(r, "P", { class: !0 });
      var s = at(e);
      t = ie(
        s,
        /*loading_text*/
        i[9]
      ), s.forEach(O), n = qe(r), a && a.l(r), this.h();
    },
    h() {
      Ye(e, "class", "loading svelte-17v219f");
    },
    m(r, s) {
      M(r, e, s), At(e, t), M(r, n, s), a && a.m(r, s), l = !0;
    },
    p(r, s) {
      (!l || s[0] & /*loading_text*/
      512) && Pe(
        t,
        /*loading_text*/
        r[9]
      ), a && a.p && (!l || s[0] & /*$$scope*/
      536870912) && kl(
        a,
        o,
        r,
        /*$$scope*/
        r[29],
        l ? Fl(
          o,
          /*$$scope*/
          r[29],
          s,
          Vr
        ) : wl(
          /*$$scope*/
          r[29]
        ),
        ia
      );
    },
    i(r) {
      l || (Ze(a, r), l = !0);
    },
    o(r) {
      rt(a, r), l = !1;
    },
    d(r) {
      r && (O(e), O(n)), a && a.d(r);
    }
  };
}
function is(i) {
  let e, t, n, l, o;
  const a = [Zr, Wr], r = [];
  function s(u, c) {
    return (
      /*status*/
      u[4] === "pending" ? 0 : (
        /*status*/
        u[4] === "error" ? 1 : -1
      )
    );
  }
  return ~(t = s(i)) && (n = r[t] = a[t](i)), {
    c() {
      e = ot("div"), n && n.c(), this.h();
    },
    l(u) {
      e = lt(u, "DIV", { class: !0 });
      var c = at(e);
      n && n.l(c), c.forEach(O), this.h();
    },
    h() {
      Ye(e, "class", l = "wrap " + /*variant*/
      i[8] + " " + /*show_progress*/
      i[6] + " svelte-17v219f"), Oe(e, "hide", !/*status*/
      i[4] || /*status*/
      i[4] === "complete" || /*show_progress*/
      i[6] === "hidden" || /*status*/
      i[4] == "streaming"), Oe(
        e,
        "translucent",
        /*variant*/
        i[8] === "center" && /*status*/
        (i[4] === "pending" || /*status*/
        i[4] === "error") || /*translucent*/
        i[11] || /*show_progress*/
        i[6] === "minimal"
      ), Oe(
        e,
        "generating",
        /*status*/
        i[4] === "generating" && /*show_progress*/
        i[6] === "full"
      ), Oe(
        e,
        "border",
        /*border*/
        i[12]
      ), $t(
        e,
        "position",
        /*absolute*/
        i[10] ? "absolute" : "static"
      ), $t(
        e,
        "padding",
        /*absolute*/
        i[10] ? "0" : "var(--size-8) 0"
      );
    },
    m(u, c) {
      M(u, e, c), ~t && r[t].m(e, null), i[33](e), o = !0;
    },
    p(u, c) {
      let m = t;
      t = s(u), t === m ? ~t && r[t].p(u, c) : (n && (li(), rt(r[m], 1, 1, () => {
        r[m] = null;
      }), ai()), ~t ? (n = r[t], n ? n.p(u, c) : (n = r[t] = a[t](u), n.c()), Ze(n, 1), n.m(e, null)) : n = null), (!o || c[0] & /*variant, show_progress*/
      320 && l !== (l = "wrap " + /*variant*/
      u[8] + " " + /*show_progress*/
      u[6] + " svelte-17v219f")) && Ye(e, "class", l), (!o || c[0] & /*variant, show_progress, status, show_progress*/
      336) && Oe(e, "hide", !/*status*/
      u[4] || /*status*/
      u[4] === "complete" || /*show_progress*/
      u[6] === "hidden" || /*status*/
      u[4] == "streaming"), (!o || c[0] & /*variant, show_progress, variant, status, translucent, show_progress*/
      2384) && Oe(
        e,
        "translucent",
        /*variant*/
        u[8] === "center" && /*status*/
        (u[4] === "pending" || /*status*/
        u[4] === "error") || /*translucent*/
        u[11] || /*show_progress*/
        u[6] === "minimal"
      ), (!o || c[0] & /*variant, show_progress, status, show_progress*/
      336) && Oe(
        e,
        "generating",
        /*status*/
        u[4] === "generating" && /*show_progress*/
        u[6] === "full"
      ), (!o || c[0] & /*variant, show_progress, border*/
      4416) && Oe(
        e,
        "border",
        /*border*/
        u[12]
      ), c[0] & /*absolute*/
      1024 && $t(
        e,
        "position",
        /*absolute*/
        u[10] ? "absolute" : "static"
      ), c[0] & /*absolute*/
      1024 && $t(
        e,
        "padding",
        /*absolute*/
        u[10] ? "0" : "var(--size-8) 0"
      );
    },
    i(u) {
      o || (Ze(n), o = !0);
    },
    o(u) {
      rt(n), o = !1;
    },
    d(u) {
      u && O(e), ~t && r[t].d(), i[33](null);
    }
  };
}
var as = function(i, e, t, n) {
  function l(o) {
    return o instanceof t ? o : new t(function(a) {
      a(o);
    });
  }
  return new (t || (t = Promise))(function(o, a) {
    function r(c) {
      try {
        u(n.next(c));
      } catch (m) {
        a(m);
      }
    }
    function s(c) {
      try {
        u(n.throw(c));
      } catch (m) {
        a(m);
      }
    }
    function u(c) {
      c.done ? o(c.value) : l(c.value).then(r, s);
    }
    u((n = n.apply(i, e || [])).next());
  });
};
let wn = [], jn = !1;
const ls = typeof window < "u", El = ls ? window.requestAnimationFrame : (i) => {
};
function os(i) {
  return as(this, arguments, void 0, function* (e, t = !0) {
    if (!(window.__gradio_mode__ === "website" || window.__gradio_mode__ !== "app" && t !== !0)) {
      if (wn.push(e), !jn) jn = !0;
      else return;
      yield Ur(), El(() => {
        let n = [0, 0];
        for (let l = 0; l < wn.length; l++) {
          const a = wn[l].getBoundingClientRect();
          (l === 0 || a.top + window.scrollY <= n[0]) && (n[0] = a.top + window.scrollY, n[1] = l);
        }
        window.scrollTo({ top: n[0] - 20, behavior: "smooth" }), jn = !1, wn = [];
      });
    }
  });
}
function rs(i, e, t) {
  let n, { $$slots: l = {}, $$scope: o } = e;
  const a = Gr();
  let { i18n: r } = e, { eta: s = null } = e, { queue_position: u } = e, { queue_size: c } = e, { status: m } = e, { scroll_to_output: f = !1 } = e, { timer: d = !0 } = e, { show_progress: v = "full" } = e, { message: y = null } = e, { progress: w = null } = e, { variant: C = "default" } = e, { loading_text: h = "Loading..." } = e, { absolute: _ = !0 } = e, { translucent: g = !1 } = e, { border: b = !1 } = e, { autoscroll: F } = e, A, T = !1, S = 0, N = 0, x = null, U = null, $e = 0, ue = null, ke, _e = null, le = !0;
  const K = () => {
    t(0, s = t(27, x = t(19, $ = null))), t(25, S = performance.now()), t(26, N = 0), T = !0, re();
  };
  function re() {
    El(() => {
      t(26, N = (performance.now() - S) / 1e3), T && re();
    });
  }
  function ge() {
    t(26, N = 0), t(0, s = t(27, x = t(19, $ = null))), T && (T = !1);
  }
  Hr(() => {
    T && ge();
  });
  let $ = null;
  function oe(E) {
    ta[E ? "unshift" : "push"](() => {
      _e = E, t(16, _e), t(7, w), t(14, ue), t(15, ke);
    });
  }
  const Q = () => {
    a("clear_status");
  };
  function de(E) {
    ta[E ? "unshift" : "push"](() => {
      A = E, t(13, A);
    });
  }
  return i.$$set = (E) => {
    "i18n" in E && t(1, r = E.i18n), "eta" in E && t(0, s = E.eta), "queue_position" in E && t(2, u = E.queue_position), "queue_size" in E && t(3, c = E.queue_size), "status" in E && t(4, m = E.status), "scroll_to_output" in E && t(22, f = E.scroll_to_output), "timer" in E && t(5, d = E.timer), "show_progress" in E && t(6, v = E.show_progress), "message" in E && t(23, y = E.message), "progress" in E && t(7, w = E.progress), "variant" in E && t(8, C = E.variant), "loading_text" in E && t(9, h = E.loading_text), "absolute" in E && t(10, _ = E.absolute), "translucent" in E && t(11, g = E.translucent), "border" in E && t(12, b = E.border), "autoscroll" in E && t(24, F = E.autoscroll), "$$scope" in E && t(29, o = E.$$scope);
  }, i.$$.update = () => {
    i.$$.dirty[0] & /*eta, old_eta, timer_start, eta_from_start*/
    436207617 && (s === null && t(0, s = x), s != null && x !== s && (t(28, U = (performance.now() - S) / 1e3 + s), t(19, $ = U.toFixed(1)), t(27, x = s))), i.$$.dirty[0] & /*eta_from_start, timer_diff*/
    335544320 && t(17, $e = U === null || U <= 0 || !N ? null : Math.min(N / U, 1)), i.$$.dirty[0] & /*progress*/
    128 && w != null && t(18, le = !1), i.$$.dirty[0] & /*progress, progress_level, progress_bar, last_progress_level*/
    114816 && (w != null ? t(14, ue = w.map((E) => {
      if (E.index != null && E.length != null)
        return E.index / E.length;
      if (E.progress != null)
        return E.progress;
    })) : t(14, ue = null), ue ? (t(15, ke = ue[ue.length - 1]), _e && (ke === 0 ? t(16, _e.style.transition = "0", _e) : t(16, _e.style.transition = "150ms", _e))) : t(15, ke = void 0)), i.$$.dirty[0] & /*status*/
    16 && (m === "pending" ? K() : ge()), i.$$.dirty[0] & /*el, scroll_to_output, status, autoscroll*/
    20979728 && A && f && (m === "pending" || m === "complete") && os(A, F), i.$$.dirty[0] & /*status, message*/
    8388624, i.$$.dirty[0] & /*timer_diff*/
    67108864 && t(20, n = N.toFixed(1));
  }, [
    s,
    r,
    u,
    c,
    m,
    d,
    v,
    w,
    C,
    h,
    _,
    g,
    b,
    A,
    ue,
    ke,
    _e,
    $e,
    le,
    $,
    n,
    a,
    f,
    y,
    F,
    S,
    N,
    x,
    U,
    o,
    l,
    oe,
    Q,
    de
  ];
}
class ss extends Mr {
  constructor(e) {
    super(), Pr(
      this,
      e,
      rs,
      is,
      zr,
      {
        i18n: 1,
        eta: 0,
        queue_position: 2,
        queue_size: 3,
        status: 4,
        scroll_to_output: 22,
        timer: 5,
        show_progress: 6,
        message: 23,
        progress: 7,
        variant: 8,
        loading_text: 9,
        absolute: 10,
        translucent: 11,
        border: 12,
        autoscroll: 24
      },
      null,
      [-1, -1]
    );
  }
}
/*! @license DOMPurify 3.2.6 | (c) Cure53 and other contributors | Released under the Apache license 2.0 and Mozilla Public License 2.0 | github.com/cure53/DOMPurify/blob/3.2.6/LICENSE */
const {
  entries: Al,
  setPrototypeOf: ga,
  isFrozen: us,
  getPrototypeOf: cs,
  getOwnPropertyDescriptor: _s
} = Object;
let {
  freeze: Ae,
  seal: ze,
  create: Cl
} = Object, {
  apply: ri,
  construct: si
} = typeof Reflect < "u" && Reflect;
Ae || (Ae = function(e) {
  return e;
});
ze || (ze = function(e) {
  return e;
});
ri || (ri = function(e, t, n) {
  return e.apply(t, n);
});
si || (si = function(e, t) {
  return new e(...t);
});
const Fn = Ce(Array.prototype.forEach), ds = Ce(Array.prototype.lastIndexOf), va = Ce(Array.prototype.pop), Zt = Ce(Array.prototype.push), fs = Ce(Array.prototype.splice), An = Ce(String.prototype.toLowerCase), Vn = Ce(String.prototype.toString), Da = Ce(String.prototype.match), Yt = Ce(String.prototype.replace), ps = Ce(String.prototype.indexOf), hs = Ce(String.prototype.trim), We = Ce(Object.prototype.hasOwnProperty), Ee = Ce(RegExp.prototype.test), Xt = ms(TypeError);
function Ce(i) {
  return function(e) {
    e instanceof RegExp && (e.lastIndex = 0);
    for (var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), l = 1; l < t; l++)
      n[l - 1] = arguments[l];
    return ri(i, e, n);
  };
}
function ms(i) {
  return function() {
    for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++)
      t[n] = arguments[n];
    return si(i, t);
  };
}
function P(i, e) {
  let t = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : An;
  ga && ga(i, null);
  let n = e.length;
  for (; n--; ) {
    let l = e[n];
    if (typeof l == "string") {
      const o = t(l);
      o !== l && (us(e) || (e[n] = o), l = o);
    }
    i[l] = !0;
  }
  return i;
}
function gs(i) {
  for (let e = 0; e < i.length; e++)
    We(i, e) || (i[e] = null);
  return i;
}
function mt(i) {
  const e = Cl(null);
  for (const [t, n] of Al(i))
    We(i, t) && (Array.isArray(n) ? e[t] = gs(n) : n && typeof n == "object" && n.constructor === Object ? e[t] = mt(n) : e[t] = n);
  return e;
}
function Kt(i, e) {
  for (; i !== null; ) {
    const n = _s(i, e);
    if (n) {
      if (n.get)
        return Ce(n.get);
      if (typeof n.value == "function")
        return Ce(n.value);
    }
    i = cs(i);
  }
  function t() {
    return null;
  }
  return t;
}
const ba = Ae(["a", "abbr", "acronym", "address", "area", "article", "aside", "audio", "b", "bdi", "bdo", "big", "blink", "blockquote", "body", "br", "button", "canvas", "caption", "center", "cite", "code", "col", "colgroup", "content", "data", "datalist", "dd", "decorator", "del", "details", "dfn", "dialog", "dir", "div", "dl", "dt", "element", "em", "fieldset", "figcaption", "figure", "font", "footer", "form", "h1", "h2", "h3", "h4", "h5", "h6", "head", "header", "hgroup", "hr", "html", "i", "img", "input", "ins", "kbd", "label", "legend", "li", "main", "map", "mark", "marquee", "menu", "menuitem", "meter", "nav", "nobr", "ol", "optgroup", "option", "output", "p", "picture", "pre", "progress", "q", "rp", "rt", "ruby", "s", "samp", "section", "select", "shadow", "small", "source", "spacer", "span", "strike", "strong", "style", "sub", "summary", "sup", "table", "tbody", "td", "template", "textarea", "tfoot", "th", "thead", "time", "tr", "track", "tt", "u", "ul", "var", "video", "wbr"]), Wn = Ae(["svg", "a", "altglyph", "altglyphdef", "altglyphitem", "animatecolor", "animatemotion", "animatetransform", "circle", "clippath", "defs", "desc", "ellipse", "filter", "font", "g", "glyph", "glyphref", "hkern", "image", "line", "lineargradient", "marker", "mask", "metadata", "mpath", "path", "pattern", "polygon", "polyline", "radialgradient", "rect", "stop", "style", "switch", "symbol", "text", "textpath", "title", "tref", "tspan", "view", "vkern"]), Zn = Ae(["feBlend", "feColorMatrix", "feComponentTransfer", "feComposite", "feConvolveMatrix", "feDiffuseLighting", "feDisplacementMap", "feDistantLight", "feDropShadow", "feFlood", "feFuncA", "feFuncB", "feFuncG", "feFuncR", "feGaussianBlur", "feImage", "feMerge", "feMergeNode", "feMorphology", "feOffset", "fePointLight", "feSpecularLighting", "feSpotLight", "feTile", "feTurbulence"]), vs = Ae(["animate", "color-profile", "cursor", "discard", "font-face", "font-face-format", "font-face-name", "font-face-src", "font-face-uri", "foreignobject", "hatch", "hatchpath", "mesh", "meshgradient", "meshpatch", "meshrow", "missing-glyph", "script", "set", "solidcolor", "unknown", "use"]), Yn = Ae(["math", "menclose", "merror", "mfenced", "mfrac", "mglyph", "mi", "mlabeledtr", "mmultiscripts", "mn", "mo", "mover", "mpadded", "mphantom", "mroot", "mrow", "ms", "mspace", "msqrt", "mstyle", "msub", "msup", "msubsup", "mtable", "mtd", "mtext", "mtr", "munder", "munderover", "mprescripts"]), Ds = Ae(["maction", "maligngroup", "malignmark", "mlongdiv", "mscarries", "mscarry", "msgroup", "mstack", "msline", "msrow", "semantics", "annotation", "annotation-xml", "mprescripts", "none"]), ya = Ae(["#text"]), wa = Ae(["accept", "action", "align", "alt", "autocapitalize", "autocomplete", "autopictureinpicture", "autoplay", "background", "bgcolor", "border", "capture", "cellpadding", "cellspacing", "checked", "cite", "class", "clear", "color", "cols", "colspan", "controls", "controlslist", "coords", "crossorigin", "datetime", "decoding", "default", "dir", "disabled", "disablepictureinpicture", "disableremoteplayback", "download", "draggable", "enctype", "enterkeyhint", "face", "for", "headers", "height", "hidden", "high", "href", "hreflang", "id", "inputmode", "integrity", "ismap", "kind", "label", "lang", "list", "loading", "loop", "low", "max", "maxlength", "media", "method", "min", "minlength", "multiple", "muted", "name", "nonce", "noshade", "novalidate", "nowrap", "open", "optimum", "pattern", "placeholder", "playsinline", "popover", "popovertarget", "popovertargetaction", "poster", "preload", "pubdate", "radiogroup", "readonly", "rel", "required", "rev", "reversed", "role", "rows", "rowspan", "spellcheck", "scope", "selected", "shape", "size", "sizes", "span", "srclang", "start", "src", "srcset", "step", "style", "summary", "tabindex", "title", "translate", "type", "usemap", "valign", "value", "width", "wrap", "xmlns", "slot"]), Xn = Ae(["accent-height", "accumulate", "additive", "alignment-baseline", "amplitude", "ascent", "attributename", "attributetype", "azimuth", "basefrequency", "baseline-shift", "begin", "bias", "by", "class", "clip", "clippathunits", "clip-path", "clip-rule", "color", "color-interpolation", "color-interpolation-filters", "color-profile", "color-rendering", "cx", "cy", "d", "dx", "dy", "diffuseconstant", "direction", "display", "divisor", "dur", "edgemode", "elevation", "end", "exponent", "fill", "fill-opacity", "fill-rule", "filter", "filterunits", "flood-color", "flood-opacity", "font-family", "font-size", "font-size-adjust", "font-stretch", "font-style", "font-variant", "font-weight", "fx", "fy", "g1", "g2", "glyph-name", "glyphref", "gradientunits", "gradienttransform", "height", "href", "id", "image-rendering", "in", "in2", "intercept", "k", "k1", "k2", "k3", "k4", "kerning", "keypoints", "keysplines", "keytimes", "lang", "lengthadjust", "letter-spacing", "kernelmatrix", "kernelunitlength", "lighting-color", "local", "marker-end", "marker-mid", "marker-start", "markerheight", "markerunits", "markerwidth", "maskcontentunits", "maskunits", "max", "mask", "media", "method", "mode", "min", "name", "numoctaves", "offset", "operator", "opacity", "order", "orient", "orientation", "origin", "overflow", "paint-order", "path", "pathlength", "patterncontentunits", "patterntransform", "patternunits", "points", "preservealpha", "preserveaspectratio", "primitiveunits", "r", "rx", "ry", "radius", "refx", "refy", "repeatcount", "repeatdur", "restart", "result", "rotate", "scale", "seed", "shape-rendering", "slope", "specularconstant", "specularexponent", "spreadmethod", "startoffset", "stddeviation", "stitchtiles", "stop-color", "stop-opacity", "stroke-dasharray", "stroke-dashoffset", "stroke-linecap", "stroke-linejoin", "stroke-miterlimit", "stroke-opacity", "stroke", "stroke-width", "style", "surfacescale", "systemlanguage", "tabindex", "tablevalues", "targetx", "targety", "transform", "transform-origin", "text-anchor", "text-decoration", "text-rendering", "textlength", "type", "u1", "u2", "unicode", "values", "viewbox", "visibility", "version", "vert-adv-y", "vert-origin-x", "vert-origin-y", "width", "word-spacing", "wrap", "writing-mode", "xchannelselector", "ychannelselector", "x", "x1", "x2", "xmlns", "y", "y1", "y2", "z", "zoomandpan"]), Fa = Ae(["accent", "accentunder", "align", "bevelled", "close", "columnsalign", "columnlines", "columnspan", "denomalign", "depth", "dir", "display", "displaystyle", "encoding", "fence", "frame", "height", "href", "id", "largeop", "length", "linethickness", "lspace", "lquote", "mathbackground", "mathcolor", "mathsize", "mathvariant", "maxsize", "minsize", "movablelimits", "notation", "numalign", "open", "rowalign", "rowlines", "rowspacing", "rowspan", "rspace", "rquote", "scriptlevel", "scriptminsize", "scriptsizemultiplier", "selection", "separator", "separators", "stretchy", "subscriptshift", "supscriptshift", "symmetric", "voffset", "width", "xmlns"]), $n = Ae(["xlink:href", "xml:id", "xlink:title", "xml:space", "xmlns:xlink"]), bs = ze(/\{\{[\w\W]*|[\w\W]*\}\}/gm), ys = ze(/<%[\w\W]*|[\w\W]*%>/gm), ws = ze(/\$\{[\w\W]*/gm), Fs = ze(/^data-[\-\w.\u00B7-\uFFFF]+$/), $s = ze(/^aria-[\-\w]+$/), Sl = ze(
  /^(?:(?:(?:f|ht)tps?|mailto|tel|callto|sms|cid|xmpp|matrix):|[^a-z]|[a-z+.\-]+(?:[^a-z+.\-:]|$))/i
  // eslint-disable-line no-useless-escape
), ks = ze(/^(?:\w+script|data):/i), Es = ze(
  /[\u0000-\u0020\u00A0\u1680\u180E\u2000-\u2029\u205F\u3000]/g
  // eslint-disable-line no-control-regex
), Tl = ze(/^html$/i), As = ze(/^[a-z][.\w]*(-[.\w]+)+$/i);
var $a = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  ARIA_ATTR: $s,
  ATTR_WHITESPACE: Es,
  CUSTOM_ELEMENT: As,
  DATA_ATTR: Fs,
  DOCTYPE_NAME: Tl,
  ERB_EXPR: ys,
  IS_ALLOWED_URI: Sl,
  IS_SCRIPT_OR_DATA: ks,
  MUSTACHE_EXPR: bs,
  TMPLIT_EXPR: ws
});
const Qt = {
  element: 1,
  text: 3,
  // Deprecated
  progressingInstruction: 7,
  comment: 8,
  document: 9
}, Cs = function() {
  return typeof window > "u" ? null : window;
}, Ss = function(e, t) {
  if (typeof e != "object" || typeof e.createPolicy != "function")
    return null;
  let n = null;
  const l = "data-tt-policy-suffix";
  t && t.hasAttribute(l) && (n = t.getAttribute(l));
  const o = "dompurify" + (n ? "#" + n : "");
  try {
    return e.createPolicy(o, {
      createHTML(a) {
        return a;
      },
      createScriptURL(a) {
        return a;
      }
    });
  } catch {
    return console.warn("TrustedTypes policy " + o + " could not be created."), null;
  }
}, ka = function() {
  return {
    afterSanitizeAttributes: [],
    afterSanitizeElements: [],
    afterSanitizeShadowDOM: [],
    beforeSanitizeAttributes: [],
    beforeSanitizeElements: [],
    beforeSanitizeShadowDOM: [],
    uponSanitizeAttribute: [],
    uponSanitizeElement: [],
    uponSanitizeShadowNode: []
  };
};
function Bl() {
  let i = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : Cs();
  const e = (L) => Bl(L);
  if (e.version = "3.2.6", e.removed = [], !i || !i.document || i.document.nodeType !== Qt.document || !i.Element)
    return e.isSupported = !1, e;
  let {
    document: t
  } = i;
  const n = t, l = n.currentScript, {
    DocumentFragment: o,
    HTMLTemplateElement: a,
    Node: r,
    Element: s,
    NodeFilter: u,
    NamedNodeMap: c = i.NamedNodeMap || i.MozNamedAttrMap,
    HTMLFormElement: m,
    DOMParser: f,
    trustedTypes: d
  } = i, v = s.prototype, y = Kt(v, "cloneNode"), w = Kt(v, "remove"), C = Kt(v, "nextSibling"), h = Kt(v, "childNodes"), _ = Kt(v, "parentNode");
  if (typeof a == "function") {
    const L = t.createElement("template");
    L.content && L.content.ownerDocument && (t = L.content.ownerDocument);
  }
  let g, b = "";
  const {
    implementation: F,
    createNodeIterator: A,
    createDocumentFragment: T,
    getElementsByTagName: S
  } = t, {
    importNode: N
  } = n;
  let x = ka();
  e.isSupported = typeof Al == "function" && typeof _ == "function" && F && F.createHTMLDocument !== void 0;
  const {
    MUSTACHE_EXPR: U,
    ERB_EXPR: $e,
    TMPLIT_EXPR: ue,
    DATA_ATTR: ke,
    ARIA_ATTR: _e,
    IS_SCRIPT_OR_DATA: le,
    ATTR_WHITESPACE: K,
    CUSTOM_ELEMENT: re
  } = $a;
  let {
    IS_ALLOWED_URI: ge
  } = $a, $ = null;
  const oe = P({}, [...ba, ...Wn, ...Zn, ...Yn, ...ya]);
  let Q = null;
  const de = P({}, [...wa, ...Xn, ...Fa, ...$n]);
  let E = Object.seal(Cl(null, {
    tagNameCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    attributeNameCheck: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: null
    },
    allowCustomizedBuiltInElements: {
      writable: !0,
      configurable: !1,
      enumerable: !0,
      value: !1
    }
  })), Se = null, Xe = null, vt = !0, Dt = !0, bt = !1, ct = !0, Ke = !1, Qe = !0, _t = !1, zt = !1, Ut = !1, yt = !1, Bt = !1, Rt = !1, un = !0, cn = !1;
  const D = "user-content-";
  let q = !0, W = !1, ee = {}, ve = null;
  const wt = P({}, ["annotation-xml", "audio", "colgroup", "desc", "foreignobject", "head", "iframe", "math", "mi", "mn", "mo", "ms", "mtext", "noembed", "noframes", "noscript", "plaintext", "script", "style", "svg", "template", "thead", "title", "video", "xmp"]);
  let Et = null;
  const _n = P({}, ["audio", "video", "img", "source", "image", "track"]);
  let Ht = null;
  const It = P({}, ["alt", "class", "for", "id", "label", "name", "pattern", "placeholder", "role", "summary", "title", "value", "style", "xmlns"]), Ie = "http://www.w3.org/1998/Math/MathML", Ft = "http://www.w3.org/2000/svg", dt = "http://www.w3.org/1999/xhtml";
  let Lt = dt, Ln = !1, On = null;
  const Pl = P({}, [Ie, Ft, dt], Vn);
  let dn = P({}, ["mi", "mo", "mn", "ms", "mtext"]), fn = P({}, ["annotation-xml"]);
  const zl = P({}, ["title", "style", "font", "a", "script"]);
  let Gt = null;
  const Ul = ["application/xhtml+xml", "text/html"], Hl = "text/html";
  let fe = null, Ot = null;
  const Gl = t.createElement("form"), gi = function(p) {
    return p instanceof RegExp || p instanceof Function;
  }, qn = function() {
    let p = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    if (!(Ot && Ot === p)) {
      if ((!p || typeof p != "object") && (p = {}), p = mt(p), Gt = // eslint-disable-next-line unicorn/prefer-includes
      Ul.indexOf(p.PARSER_MEDIA_TYPE) === -1 ? Hl : p.PARSER_MEDIA_TYPE, fe = Gt === "application/xhtml+xml" ? Vn : An, $ = We(p, "ALLOWED_TAGS") ? P({}, p.ALLOWED_TAGS, fe) : oe, Q = We(p, "ALLOWED_ATTR") ? P({}, p.ALLOWED_ATTR, fe) : de, On = We(p, "ALLOWED_NAMESPACES") ? P({}, p.ALLOWED_NAMESPACES, Vn) : Pl, Ht = We(p, "ADD_URI_SAFE_ATTR") ? P(mt(It), p.ADD_URI_SAFE_ATTR, fe) : It, Et = We(p, "ADD_DATA_URI_TAGS") ? P(mt(_n), p.ADD_DATA_URI_TAGS, fe) : _n, ve = We(p, "FORBID_CONTENTS") ? P({}, p.FORBID_CONTENTS, fe) : wt, Se = We(p, "FORBID_TAGS") ? P({}, p.FORBID_TAGS, fe) : mt({}), Xe = We(p, "FORBID_ATTR") ? P({}, p.FORBID_ATTR, fe) : mt({}), ee = We(p, "USE_PROFILES") ? p.USE_PROFILES : !1, vt = p.ALLOW_ARIA_ATTR !== !1, Dt = p.ALLOW_DATA_ATTR !== !1, bt = p.ALLOW_UNKNOWN_PROTOCOLS || !1, ct = p.ALLOW_SELF_CLOSE_IN_ATTR !== !1, Ke = p.SAFE_FOR_TEMPLATES || !1, Qe = p.SAFE_FOR_XML !== !1, _t = p.WHOLE_DOCUMENT || !1, yt = p.RETURN_DOM || !1, Bt = p.RETURN_DOM_FRAGMENT || !1, Rt = p.RETURN_TRUSTED_TYPE || !1, Ut = p.FORCE_BODY || !1, un = p.SANITIZE_DOM !== !1, cn = p.SANITIZE_NAMED_PROPS || !1, q = p.KEEP_CONTENT !== !1, W = p.IN_PLACE || !1, ge = p.ALLOWED_URI_REGEXP || Sl, Lt = p.NAMESPACE || dt, dn = p.MATHML_TEXT_INTEGRATION_POINTS || dn, fn = p.HTML_INTEGRATION_POINTS || fn, E = p.CUSTOM_ELEMENT_HANDLING || {}, p.CUSTOM_ELEMENT_HANDLING && gi(p.CUSTOM_ELEMENT_HANDLING.tagNameCheck) && (E.tagNameCheck = p.CUSTOM_ELEMENT_HANDLING.tagNameCheck), p.CUSTOM_ELEMENT_HANDLING && gi(p.CUSTOM_ELEMENT_HANDLING.attributeNameCheck) && (E.attributeNameCheck = p.CUSTOM_ELEMENT_HANDLING.attributeNameCheck), p.CUSTOM_ELEMENT_HANDLING && typeof p.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements == "boolean" && (E.allowCustomizedBuiltInElements = p.CUSTOM_ELEMENT_HANDLING.allowCustomizedBuiltInElements), Ke && (Dt = !1), Bt && (yt = !0), ee && ($ = P({}, ya), Q = [], ee.html === !0 && (P($, ba), P(Q, wa)), ee.svg === !0 && (P($, Wn), P(Q, Xn), P(Q, $n)), ee.svgFilters === !0 && (P($, Zn), P(Q, Xn), P(Q, $n)), ee.mathMl === !0 && (P($, Yn), P(Q, Fa), P(Q, $n))), p.ADD_TAGS && ($ === oe && ($ = mt($)), P($, p.ADD_TAGS, fe)), p.ADD_ATTR && (Q === de && (Q = mt(Q)), P(Q, p.ADD_ATTR, fe)), p.ADD_URI_SAFE_ATTR && P(Ht, p.ADD_URI_SAFE_ATTR, fe), p.FORBID_CONTENTS && (ve === wt && (ve = mt(ve)), P(ve, p.FORBID_CONTENTS, fe)), q && ($["#text"] = !0), _t && P($, ["html", "head", "body"]), $.table && (P($, ["tbody"]), delete Se.tbody), p.TRUSTED_TYPES_POLICY) {
        if (typeof p.TRUSTED_TYPES_POLICY.createHTML != "function")
          throw Xt('TRUSTED_TYPES_POLICY configuration option must provide a "createHTML" hook.');
        if (typeof p.TRUSTED_TYPES_POLICY.createScriptURL != "function")
          throw Xt('TRUSTED_TYPES_POLICY configuration option must provide a "createScriptURL" hook.');
        g = p.TRUSTED_TYPES_POLICY, b = g.createHTML("");
      } else
        g === void 0 && (g = Ss(d, l)), g !== null && typeof b == "string" && (b = g.createHTML(""));
      Ae && Ae(p), Ot = p;
    }
  }, vi = P({}, [...Wn, ...Zn, ...vs]), Di = P({}, [...Yn, ...Ds]), jl = function(p) {
    let k = _(p);
    (!k || !k.tagName) && (k = {
      namespaceURI: Lt,
      tagName: "template"
    });
    const B = An(p.tagName), ne = An(k.tagName);
    return On[p.namespaceURI] ? p.namespaceURI === Ft ? k.namespaceURI === dt ? B === "svg" : k.namespaceURI === Ie ? B === "svg" && (ne === "annotation-xml" || dn[ne]) : !!vi[B] : p.namespaceURI === Ie ? k.namespaceURI === dt ? B === "math" : k.namespaceURI === Ft ? B === "math" && fn[ne] : !!Di[B] : p.namespaceURI === dt ? k.namespaceURI === Ft && !fn[ne] || k.namespaceURI === Ie && !dn[ne] ? !1 : !Di[B] && (zl[B] || !vi[B]) : !!(Gt === "application/xhtml+xml" && On[p.namespaceURI]) : !1;
  }, Je = function(p) {
    Zt(e.removed, {
      element: p
    });
    try {
      _(p).removeChild(p);
    } catch {
      w(p);
    }
  }, qt = function(p, k) {
    try {
      Zt(e.removed, {
        attribute: k.getAttributeNode(p),
        from: k
      });
    } catch {
      Zt(e.removed, {
        attribute: null,
        from: k
      });
    }
    if (k.removeAttribute(p), p === "is")
      if (yt || Bt)
        try {
          Je(k);
        } catch {
        }
      else
        try {
          k.setAttribute(p, "");
        } catch {
        }
  }, bi = function(p) {
    let k = null, B = null;
    if (Ut)
      p = "<remove></remove>" + p;
    else {
      const ce = Da(p, /^[\r\n\t ]+/);
      B = ce && ce[0];
    }
    Gt === "application/xhtml+xml" && Lt === dt && (p = '<html xmlns="http://www.w3.org/1999/xhtml"><head></head><body>' + p + "</body></html>");
    const ne = g ? g.createHTML(p) : p;
    if (Lt === dt)
      try {
        k = new f().parseFromString(ne, Gt);
      } catch {
      }
    if (!k || !k.documentElement) {
      k = F.createDocument(Lt, "template", null);
      try {
        k.documentElement.innerHTML = Ln ? b : ne;
      } catch {
      }
    }
    const De = k.body || k.documentElement;
    return p && B && De.insertBefore(t.createTextNode(B), De.childNodes[0] || null), Lt === dt ? S.call(k, _t ? "html" : "body")[0] : _t ? k.documentElement : De;
  }, yi = function(p) {
    return A.call(
      p.ownerDocument || p,
      p,
      // eslint-disable-next-line no-bitwise
      u.SHOW_ELEMENT | u.SHOW_COMMENT | u.SHOW_TEXT | u.SHOW_PROCESSING_INSTRUCTION | u.SHOW_CDATA_SECTION,
      null
    );
  }, xn = function(p) {
    return p instanceof m && (typeof p.nodeName != "string" || typeof p.textContent != "string" || typeof p.removeChild != "function" || !(p.attributes instanceof c) || typeof p.removeAttribute != "function" || typeof p.setAttribute != "function" || typeof p.namespaceURI != "string" || typeof p.insertBefore != "function" || typeof p.hasChildNodes != "function");
  }, wi = function(p) {
    return typeof r == "function" && p instanceof r;
  };
  function ft(L, p, k) {
    Fn(L, (B) => {
      B.call(e, p, k, Ot);
    });
  }
  const Fi = function(p) {
    let k = null;
    if (ft(x.beforeSanitizeElements, p, null), xn(p))
      return Je(p), !0;
    const B = fe(p.nodeName);
    if (ft(x.uponSanitizeElement, p, {
      tagName: B,
      allowedTags: $
    }), Qe && p.hasChildNodes() && !wi(p.firstElementChild) && Ee(/<[/\w!]/g, p.innerHTML) && Ee(/<[/\w!]/g, p.textContent) || p.nodeType === Qt.progressingInstruction || Qe && p.nodeType === Qt.comment && Ee(/<[/\w]/g, p.data))
      return Je(p), !0;
    if (!$[B] || Se[B]) {
      if (!Se[B] && ki(B) && (E.tagNameCheck instanceof RegExp && Ee(E.tagNameCheck, B) || E.tagNameCheck instanceof Function && E.tagNameCheck(B)))
        return !1;
      if (q && !ve[B]) {
        const ne = _(p) || p.parentNode, De = h(p) || p.childNodes;
        if (De && ne) {
          const ce = De.length;
          for (let Te = ce - 1; Te >= 0; --Te) {
            const pt = y(De[Te], !0);
            pt.__removalCount = (p.__removalCount || 0) + 1, ne.insertBefore(pt, C(p));
          }
        }
      }
      return Je(p), !0;
    }
    return p instanceof s && !jl(p) || (B === "noscript" || B === "noembed" || B === "noframes") && Ee(/<\/no(script|embed|frames)/i, p.innerHTML) ? (Je(p), !0) : (Ke && p.nodeType === Qt.text && (k = p.textContent, Fn([U, $e, ue], (ne) => {
      k = Yt(k, ne, " ");
    }), p.textContent !== k && (Zt(e.removed, {
      element: p.cloneNode()
    }), p.textContent = k)), ft(x.afterSanitizeElements, p, null), !1);
  }, $i = function(p, k, B) {
    if (un && (k === "id" || k === "name") && (B in t || B in Gl))
      return !1;
    if (!(Dt && !Xe[k] && Ee(ke, k))) {
      if (!(vt && Ee(_e, k))) {
        if (!Q[k] || Xe[k]) {
          if (
            // First condition does a very basic check if a) it's basically a valid custom element tagname AND
            // b) if the tagName passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
            // and c) if the attribute name passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.attributeNameCheck
            !(ki(p) && (E.tagNameCheck instanceof RegExp && Ee(E.tagNameCheck, p) || E.tagNameCheck instanceof Function && E.tagNameCheck(p)) && (E.attributeNameCheck instanceof RegExp && Ee(E.attributeNameCheck, k) || E.attributeNameCheck instanceof Function && E.attributeNameCheck(k)) || // Alternative, second condition checks if it's an `is`-attribute, AND
            // the value passes whatever the user has configured for CUSTOM_ELEMENT_HANDLING.tagNameCheck
            k === "is" && E.allowCustomizedBuiltInElements && (E.tagNameCheck instanceof RegExp && Ee(E.tagNameCheck, B) || E.tagNameCheck instanceof Function && E.tagNameCheck(B)))
          ) return !1;
        } else if (!Ht[k]) {
          if (!Ee(ge, Yt(B, K, ""))) {
            if (!((k === "src" || k === "xlink:href" || k === "href") && p !== "script" && ps(B, "data:") === 0 && Et[p])) {
              if (!(bt && !Ee(le, Yt(B, K, "")))) {
                if (B)
                  return !1;
              }
            }
          }
        }
      }
    }
    return !0;
  }, ki = function(p) {
    return p !== "annotation-xml" && Da(p, re);
  }, Ei = function(p) {
    ft(x.beforeSanitizeAttributes, p, null);
    const {
      attributes: k
    } = p;
    if (!k || xn(p))
      return;
    const B = {
      attrName: "",
      attrValue: "",
      keepAttr: !0,
      allowedAttributes: Q,
      forceKeepAttr: void 0
    };
    let ne = k.length;
    for (; ne--; ) {
      const De = k[ne], {
        name: ce,
        namespaceURI: Te,
        value: pt
      } = De, jt = fe(ce), Nn = pt;
      let be = ce === "value" ? Nn : hs(Nn);
      if (B.attrName = jt, B.attrValue = be, B.keepAttr = !0, B.forceKeepAttr = void 0, ft(x.uponSanitizeAttribute, p, B), be = B.attrValue, cn && (jt === "id" || jt === "name") && (qt(ce, p), be = D + be), Qe && Ee(/((--!?|])>)|<\/(style|title)/i, be)) {
        qt(ce, p);
        continue;
      }
      if (B.forceKeepAttr)
        continue;
      if (!B.keepAttr) {
        qt(ce, p);
        continue;
      }
      if (!ct && Ee(/\/>/i, be)) {
        qt(ce, p);
        continue;
      }
      Ke && Fn([U, $e, ue], (Ci) => {
        be = Yt(be, Ci, " ");
      });
      const Ai = fe(p.nodeName);
      if (!$i(Ai, jt, be)) {
        qt(ce, p);
        continue;
      }
      if (g && typeof d == "object" && typeof d.getAttributeType == "function" && !Te)
        switch (d.getAttributeType(Ai, jt)) {
          case "TrustedHTML": {
            be = g.createHTML(be);
            break;
          }
          case "TrustedScriptURL": {
            be = g.createScriptURL(be);
            break;
          }
        }
      if (be !== Nn)
        try {
          Te ? p.setAttributeNS(Te, ce, be) : p.setAttribute(ce, be), xn(p) ? Je(p) : va(e.removed);
        } catch {
          qt(ce, p);
        }
    }
    ft(x.afterSanitizeAttributes, p, null);
  }, Vl = function L(p) {
    let k = null;
    const B = yi(p);
    for (ft(x.beforeSanitizeShadowDOM, p, null); k = B.nextNode(); )
      ft(x.uponSanitizeShadowNode, k, null), Fi(k), Ei(k), k.content instanceof o && L(k.content);
    ft(x.afterSanitizeShadowDOM, p, null);
  };
  return e.sanitize = function(L) {
    let p = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, k = null, B = null, ne = null, De = null;
    if (Ln = !L, Ln && (L = "<!-->"), typeof L != "string" && !wi(L))
      if (typeof L.toString == "function") {
        if (L = L.toString(), typeof L != "string")
          throw Xt("dirty is not a string, aborting");
      } else
        throw Xt("toString is not a function");
    if (!e.isSupported)
      return L;
    if (zt || qn(p), e.removed = [], typeof L == "string" && (W = !1), W) {
      if (L.nodeName) {
        const pt = fe(L.nodeName);
        if (!$[pt] || Se[pt])
          throw Xt("root node is forbidden and cannot be sanitized in-place");
      }
    } else if (L instanceof r)
      k = bi("<!---->"), B = k.ownerDocument.importNode(L, !0), B.nodeType === Qt.element && B.nodeName === "BODY" || B.nodeName === "HTML" ? k = B : k.appendChild(B);
    else {
      if (!yt && !Ke && !_t && // eslint-disable-next-line unicorn/prefer-includes
      L.indexOf("<") === -1)
        return g && Rt ? g.createHTML(L) : L;
      if (k = bi(L), !k)
        return yt ? null : Rt ? b : "";
    }
    k && Ut && Je(k.firstChild);
    const ce = yi(W ? L : k);
    for (; ne = ce.nextNode(); )
      Fi(ne), Ei(ne), ne.content instanceof o && Vl(ne.content);
    if (W)
      return L;
    if (yt) {
      if (Bt)
        for (De = T.call(k.ownerDocument); k.firstChild; )
          De.appendChild(k.firstChild);
      else
        De = k;
      return (Q.shadowroot || Q.shadowrootmode) && (De = N.call(n, De, !0)), De;
    }
    let Te = _t ? k.outerHTML : k.innerHTML;
    return _t && $["!doctype"] && k.ownerDocument && k.ownerDocument.doctype && k.ownerDocument.doctype.name && Ee(Tl, k.ownerDocument.doctype.name) && (Te = "<!DOCTYPE " + k.ownerDocument.doctype.name + `>
` + Te), Ke && Fn([U, $e, ue], (pt) => {
      Te = Yt(Te, pt, " ");
    }), g && Rt ? g.createHTML(Te) : Te;
  }, e.setConfig = function() {
    let L = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    qn(L), zt = !0;
  }, e.clearConfig = function() {
    Ot = null, zt = !1;
  }, e.isValidAttribute = function(L, p, k) {
    Ot || qn({});
    const B = fe(L), ne = fe(p);
    return $i(B, ne, k);
  }, e.addHook = function(L, p) {
    typeof p == "function" && Zt(x[L], p);
  }, e.removeHook = function(L, p) {
    if (p !== void 0) {
      const k = ds(x[L], p);
      return k === -1 ? void 0 : fs(x[L], k, 1)[0];
    }
    return va(x[L]);
  }, e.removeHooks = function(L) {
    x[L] = [];
  }, e.removeAllHooks = function() {
    x = ka();
  }, e;
}
Bl();
const {
  HtmlTagHydration: eE,
  SvelteComponent: tE,
  add_render_callback: nE,
  append_hydration: iE,
  attr: aE,
  bubble: lE,
  check_outros: oE,
  children: rE,
  claim_component: sE,
  claim_element: uE,
  claim_html_tag: cE,
  claim_space: _E,
  claim_text: dE,
  create_component: fE,
  create_in_transition: pE,
  create_out_transition: hE,
  destroy_component: mE,
  detach: gE,
  element: vE,
  get_svelte_dataset: DE,
  group_outros: bE,
  init: yE,
  insert_hydration: wE,
  listen: FE,
  mount_component: $E,
  run_all: kE,
  safe_not_equal: EE,
  set_data: AE,
  space: CE,
  stop_propagation: SE,
  text: TE,
  toggle_class: BE,
  transition_in: RE,
  transition_out: IE
} = window.__gradio__svelte__internal, { createEventDispatcher: LE, onMount: OE } = window.__gradio__svelte__internal, {
  SvelteComponent: qE,
  append_hydration: xE,
  attr: NE,
  bubble: ME,
  check_outros: PE,
  children: zE,
  claim_component: UE,
  claim_element: HE,
  claim_space: GE,
  create_animation: jE,
  create_component: VE,
  destroy_component: WE,
  detach: ZE,
  element: YE,
  ensure_array_like: XE,
  fix_and_outro_and_destroy_block: KE,
  fix_position: QE,
  group_outros: JE,
  init: eA,
  insert_hydration: tA,
  mount_component: nA,
  noop: iA,
  safe_not_equal: aA,
  set_style: lA,
  space: oA,
  transition_in: rA,
  transition_out: sA,
  update_keyed_each: uA
} = window.__gradio__svelte__internal, {
  SvelteComponent: cA,
  attr: _A,
  children: dA,
  claim_element: fA,
  detach: pA,
  element: hA,
  empty: mA,
  init: gA,
  insert_hydration: vA,
  noop: DA,
  safe_not_equal: bA,
  set_style: yA
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ts,
  append_hydration: z,
  assign: Bs,
  attr: R,
  binding_callbacks: Rs,
  check_outros: Is,
  children: J,
  claim_component: Rl,
  claim_element: H,
  claim_space: he,
  claim_text: st,
  create_component: Il,
  destroy_block: Ll,
  destroy_component: Ol,
  destroy_each: ql,
  detach: I,
  element: G,
  empty: Ne,
  ensure_array_like: kt,
  get_spread_object: Ls,
  get_spread_update: Os,
  get_svelte_dataset: xl,
  group_outros: qs,
  init: xs,
  init_binding_group_dynamic: Ns,
  insert_hydration: V,
  listen: se,
  mount_component: Nl,
  run_all: sn,
  safe_not_equal: Ms,
  select_option: Ea,
  set_data: gt,
  set_input_value: Ue,
  set_style: Mt,
  space: me,
  stop_propagation: Ps,
  text: ut,
  to_number: ui,
  toggle_class: Fe,
  transition_in: an,
  transition_out: Rn,
  update_keyed_each: Ml
} = window.__gradio__svelte__internal, { onMount: zs, tick: Aa } = window.__gradio__svelte__internal;
function Ca(i, e, t) {
  const n = i.slice();
  return n[56] = e[t], n[58] = t, n;
}
function Sa(i, e, t) {
  const n = i.slice();
  n[59] = e[t], n[61] = e, n[62] = t;
  const l = (
    /*interactive*/
    n[13] && /*prop*/
    (n[59].interactive_if ? (
      /*get_prop_value*/
      n[23](
        /*prop*/
        n[59].interactive_if.field
      ) === /*prop*/
      n[59].interactive_if.value
    ) : !0)
  );
  return n[60] = l, n;
}
function Ta(i, e, t) {
  const n = i.slice();
  return n[63] = e[t], n;
}
function Ba(i, e, t) {
  const n = i.slice();
  return n[63] = e[t], n;
}
function Ra(i) {
  let e, t;
  const n = [
    {
      autoscroll: (
        /*gradio*/
        i[14].autoscroll
      )
    },
    { i18n: (
      /*gradio*/
      i[14].i18n
    ) },
    /*loading_status*/
    i[12]
  ];
  let l = {};
  for (let o = 0; o < n.length; o += 1)
    l = Bs(l, n[o]);
  return e = new ss({ props: l }), e.$on(
    "clear_status",
    /*clear_status_handler*/
    i[30]
  ), {
    c() {
      Il(e.$$.fragment);
    },
    l(o) {
      Rl(e.$$.fragment, o);
    },
    m(o, a) {
      Nl(e, o, a), t = !0;
    },
    p(o, a) {
      const r = a[0] & /*gradio, loading_status*/
      20480 ? Os(n, [
        a[0] & /*gradio*/
        16384 && {
          autoscroll: (
            /*gradio*/
            o[14].autoscroll
          )
        },
        a[0] & /*gradio*/
        16384 && { i18n: (
          /*gradio*/
          o[14].i18n
        ) },
        a[0] & /*loading_status*/
        4096 && Ls(
          /*loading_status*/
          o[12]
        )
      ]) : {};
      e.$set(r);
    },
    i(o) {
      t || (an(e.$$.fragment, o), t = !0);
    },
    o(o) {
      Rn(e.$$.fragment, o), t = !1;
    },
    d(o) {
      Ol(e, o);
    }
  };
}
function Ia(i) {
  let e, t;
  return {
    c() {
      e = G("span"), t = ut(
        /*label*/
        i[2]
      ), this.h();
    },
    l(n) {
      e = H(n, "SPAN", { class: !0 });
      var l = J(e);
      t = st(
        l,
        /*label*/
        i[2]
      ), l.forEach(I), this.h();
    },
    h() {
      R(e, "class", "label");
    },
    m(n, l) {
      V(n, e, l), z(e, t);
    },
    p(n, l) {
      l[0] & /*label*/
      4 && gt(
        t,
        /*label*/
        n[2]
      );
    },
    d(n) {
      n && I(e);
    }
  };
}
function La(i) {
  let e, t = "▼";
  return {
    c() {
      e = G("span"), e.textContent = t, this.h();
    },
    l(n) {
      e = H(n, "SPAN", { class: !0, "data-svelte-h": !0 }), xl(e) !== "svelte-zp2qne" && (e.textContent = t), this.h();
    },
    h() {
      R(e, "class", "accordion-icon svelte-31cuxt"), Mt(
        e,
        "transform",
        /*open*/
        i[1] ? "rotate(0)" : "rotate(-90deg)"
      );
    },
    m(n, l) {
      V(n, e, l);
    },
    p(n, l) {
      l[0] & /*open*/
      2 && Mt(
        e,
        "transform",
        /*open*/
        n[1] ? "rotate(0)" : "rotate(-90deg)"
      );
    },
    d(n) {
      n && I(e);
    }
  };
}
function Oa(i) {
  let e, t = Array.isArray(
    /*value*/
    i[0]
  ), n = t && qa(i);
  return {
    c() {
      e = G("div"), n && n.c(), this.h();
    },
    l(l) {
      e = H(l, "DIV", { class: !0, style: !0 });
      var o = J(e);
      n && n.l(o), o.forEach(I), this.h();
    },
    h() {
      R(e, "class", "container svelte-31cuxt"), Mt(
        e,
        "--show-group-name",
        /*value*/
        i[0].length > 1 || /*show_group_name_only_one*/
        i[3] && /*value*/
        i[0].length === 1 ? "none" : "1px solid var(--border-color-primary)"
      ), Mt(
        e,
        "--sheet-max-height",
        /*height*/
        i[11] ? `${/*height*/
        i[11]}px` : "none"
      );
    },
    m(l, o) {
      V(l, e, o), n && n.m(e, null);
    },
    p(l, o) {
      o[0] & /*value*/
      1 && (t = Array.isArray(
        /*value*/
        l[0]
      )), t ? n ? n.p(l, o) : (n = qa(l), n.c(), n.m(e, null)) : n && (n.d(1), n = null), o[0] & /*value, show_group_name_only_one*/
      9 && Mt(
        e,
        "--show-group-name",
        /*value*/
        l[0].length > 1 || /*show_group_name_only_one*/
        l[3] && /*value*/
        l[0].length === 1 ? "none" : "1px solid var(--border-color-primary)"
      ), o[0] & /*height*/
      2048 && Mt(
        e,
        "--sheet-max-height",
        /*height*/
        l[11] ? `${/*height*/
        l[11]}px` : "none"
      );
    },
    d(l) {
      l && I(e), n && n.d();
    }
  };
}
function qa(i) {
  let e = [], t = /* @__PURE__ */ new Map(), n, l = kt(
    /*value*/
    i[0]
  );
  const o = (a) => (
    /*group*/
    a[56].group_name
  );
  for (let a = 0; a < l.length; a += 1) {
    let r = Ca(i, l, a), s = o(r);
    t.set(s, e[a] = Wa(s, r));
  }
  return {
    c() {
      for (let a = 0; a < e.length; a += 1)
        e[a].c();
      n = Ne();
    },
    l(a) {
      for (let r = 0; r < e.length; r += 1)
        e[r].l(a);
      n = Ne();
    },
    m(a, r) {
      for (let s = 0; s < e.length; s += 1)
        e[s] && e[s].m(a, r);
      V(a, n, r);
    },
    p(a, r) {
      r[0] & /*value, interactive, get_prop_value, initialValues, handle_reset_prop, dispatch_update, validationState, validate_prop, sliderElements, handle_dropdown_change, groupVisibility, toggleGroup, show_group_name_only_one*/
      131571721 && (l = kt(
        /*value*/
        a[0]
      ), e = Ml(e, r, o, 1, a, l, t, n.parentNode, Ll, Wa, n, Ca));
    },
    d(a) {
      a && I(n);
      for (let r = 0; r < e.length; r += 1)
        e[r].d(a);
    }
  };
}
function xa(i) {
  let e, t, n = (
    /*group*/
    i[56].group_name + ""
  ), l, o, a, r = (
    /*groupVisibility*/
    i[15][
      /*group*/
      i[56].group_name
    ] ? "−" : "+"
  ), s, u, c;
  function m() {
    return (
      /*click_handler*/
      i[31](
        /*group*/
        i[56]
      )
    );
  }
  return {
    c() {
      e = G("button"), t = G("span"), l = ut(n), o = me(), a = G("span"), s = ut(r), this.h();
    },
    l(f) {
      e = H(f, "BUTTON", { class: !0 });
      var d = J(e);
      t = H(d, "SPAN", { class: !0 });
      var v = J(t);
      l = st(v, n), v.forEach(I), o = he(d), a = H(d, "SPAN", { class: !0 });
      var y = J(a);
      s = st(y, r), y.forEach(I), d.forEach(I), this.h();
    },
    h() {
      R(t, "class", "group-title"), R(a, "class", "group-toggle-icon"), R(e, "class", "group-header svelte-31cuxt");
    },
    m(f, d) {
      V(f, e, d), z(e, t), z(t, l), z(e, o), z(e, a), z(a, s), u || (c = se(e, "click", m), u = !0);
    },
    p(f, d) {
      i = f, d[0] & /*value*/
      1 && n !== (n = /*group*/
      i[56].group_name + "") && gt(l, n), d[0] & /*groupVisibility, value*/
      32769 && r !== (r = /*groupVisibility*/
      i[15][
        /*group*/
        i[56].group_name
      ] ? "−" : "+") && gt(s, r);
    },
    d(f) {
      f && I(e), u = !1, c();
    }
  };
}
function Na(i) {
  let e, t = Array.isArray(
    /*group*/
    i[56].properties
  ), n, l = t && Ma(i);
  return {
    c() {
      e = G("div"), l && l.c(), n = me(), this.h();
    },
    l(o) {
      e = H(o, "DIV", { class: !0 });
      var a = J(e);
      l && l.l(a), n = he(a), a.forEach(I), this.h();
    },
    h() {
      R(e, "class", "properties-grid svelte-31cuxt");
    },
    m(o, a) {
      V(o, e, a), l && l.m(e, null), z(e, n);
    },
    p(o, a) {
      a[0] & /*value*/
      1 && (t = Array.isArray(
        /*group*/
        o[56].properties
      )), t ? l ? l.p(o, a) : (l = Ma(o), l.c(), l.m(e, n)) : l && (l.d(1), l = null);
    },
    d(o) {
      o && I(e), l && l.d();
    }
  };
}
function Ma(i) {
  let e = [], t = /* @__PURE__ */ new Map(), n, l = kt(
    /*group*/
    i[56].properties
  );
  const o = (a) => (
    /*prop*/
    a[59].name
  );
  for (let a = 0; a < l.length; a += 1) {
    let r = Sa(i, l, a), s = o(r);
    t.set(s, e[a] = Va(s, r));
  }
  return {
    c() {
      for (let a = 0; a < e.length; a += 1)
        e[a].c();
      n = Ne();
    },
    l(a) {
      for (let r = 0; r < e.length; r += 1)
        e[r].l(a);
      n = Ne();
    },
    m(a, r) {
      for (let s = 0; s < e.length; s += 1)
        e[s] && e[s].m(a, r);
      V(a, n, r);
    },
    p(a, r) {
      r[0] & /*interactive, value, get_prop_value, initialValues, handle_reset_prop, dispatch_update, validationState, validate_prop, sliderElements, handle_dropdown_change*/
      127344641 && (l = kt(
        /*group*/
        a[56].properties
      ), e = Ml(e, r, o, 1, a, l, t, n.parentNode, Ll, Va, n, Sa));
    },
    d(a) {
      a && I(n);
      for (let r = 0; r < e.length; r += 1)
        e[r].d(a);
    }
  };
}
function Pa(i) {
  let e, t, n = "?", l, o, a = (
    /*prop*/
    i[59].help + ""
  ), r;
  return {
    c() {
      e = G("div"), t = G("span"), t.textContent = n, l = me(), o = G("span"), r = ut(a), this.h();
    },
    l(s) {
      e = H(s, "DIV", { class: !0 });
      var u = J(e);
      t = H(u, "SPAN", { class: !0, "data-svelte-h": !0 }), xl(t) !== "svelte-fzek5l" && (t.textContent = n), l = he(u), o = H(u, "SPAN", { class: !0 });
      var c = J(o);
      r = st(c, a), c.forEach(I), u.forEach(I), this.h();
    },
    h() {
      R(t, "class", "tooltip-icon svelte-31cuxt"), R(o, "class", "tooltip-text svelte-31cuxt"), R(e, "class", "tooltip-container svelte-31cuxt");
    },
    m(s, u) {
      V(s, e, u), z(e, t), z(e, l), z(e, o), z(o, r);
    },
    p(s, u) {
      u[0] & /*value*/
      1 && a !== (a = /*prop*/
      s[59].help + "") && gt(r, a);
    },
    d(s) {
      s && I(e);
    }
  };
}
function Us(i) {
  let e, t = Array.isArray(
    /*prop*/
    i[59].choices
  ), n, l, o = t && za(i);
  function a() {
    return (
      /*change_handler_6*/
      i[49](
        /*prop*/
        i[59]
      )
    );
  }
  return {
    c() {
      e = G("div"), o && o.c(), this.h();
    },
    l(r) {
      e = H(r, "DIV", { class: !0 });
      var s = J(e);
      o && o.l(s), s.forEach(I), this.h();
    },
    h() {
      R(e, "class", "radio-group svelte-31cuxt"), Fe(e, "disabled", !/*is_interactive*/
      i[60]);
    },
    m(r, s) {
      V(r, e, s), o && o.m(e, null), n || (l = se(e, "change", a), n = !0);
    },
    p(r, s) {
      i = r, s[0] & /*value*/
      1 && (t = Array.isArray(
        /*prop*/
        i[59].choices
      )), t ? o ? o.p(i, s) : (o = za(i), o.c(), o.m(e, null)) : o && (o.d(1), o = null), s[0] & /*interactive, value, get_prop_value*/
      8396801 && Fe(e, "disabled", !/*is_interactive*/
      i[60]);
    },
    d(r) {
      r && I(e), o && o.d(), n = !1, l();
    }
  };
}
function Hs(i) {
  let e, t, n = Array.isArray(
    /*prop*/
    i[59].choices
  ), l, o, a, r, s, u, c = n && Ha(i);
  function m(...f) {
    return (
      /*change_handler_5*/
      i[46](
        /*prop*/
        i[59],
        ...f
      )
    );
  }
  return {
    c() {
      e = G("div"), t = G("select"), c && c.c(), a = me(), r = G("div"), this.h();
    },
    l(f) {
      e = H(f, "DIV", { class: !0 });
      var d = J(e);
      t = H(d, "SELECT", { class: !0 });
      var v = J(t);
      c && c.l(v), v.forEach(I), a = he(d), r = H(d, "DIV", { class: !0 }), J(r).forEach(I), d.forEach(I), this.h();
    },
    h() {
      t.disabled = l = !/*is_interactive*/
      i[60], R(t, "class", "svelte-31cuxt"), R(r, "class", "dropdown-arrow-icon svelte-31cuxt"), R(e, "class", "dropdown-wrapper svelte-31cuxt"), Fe(e, "disabled", !/*is_interactive*/
      i[60]);
    },
    m(f, d) {
      V(f, e, d), z(e, t), c && c.m(t, null), Ea(
        t,
        /*prop*/
        i[59].value
      ), z(e, a), z(e, r), s || (u = se(t, "change", m), s = !0);
    },
    p(f, d) {
      i = f, d[0] & /*value*/
      1 && (n = Array.isArray(
        /*prop*/
        i[59].choices
      )), n ? c ? c.p(i, d) : (c = Ha(i), c.c(), c.m(t, null)) : c && (c.d(1), c = null), d[0] & /*interactive, value*/
      8193 && l !== (l = !/*is_interactive*/
      i[60]) && (t.disabled = l), d[0] & /*value*/
      1 && o !== (o = /*prop*/
      i[59].value) && Ea(
        t,
        /*prop*/
        i[59].value
      ), d[0] & /*interactive, value, get_prop_value*/
      8396801 && Fe(e, "disabled", !/*is_interactive*/
      i[60]);
    },
    d(f) {
      f && I(e), c && c.d(), s = !1, u();
    }
  };
}
function Gs(i) {
  let e, t, n, l, o, a = (
    /*prop*/
    i[59].value + ""
  ), r, s, u;
  function c() {
    i[44].call(
      t,
      /*each_value_1*/
      i[61],
      /*prop_index*/
      i[62]
    );
  }
  function m() {
    return (
      /*change_handler_4*/
      i[45](
        /*prop*/
        i[59]
      )
    );
  }
  return {
    c() {
      e = G("div"), t = G("input"), l = me(), o = G("span"), r = ut(a), this.h();
    },
    l(f) {
      e = H(f, "DIV", { class: !0 });
      var d = J(e);
      t = H(d, "INPUT", { type: !0, class: !0 }), l = he(d), o = H(d, "SPAN", { class: !0 });
      var v = J(o);
      r = st(v, a), v.forEach(I), d.forEach(I), this.h();
    },
    h() {
      R(t, "type", "color"), R(t, "class", "color-picker-input svelte-31cuxt"), t.disabled = n = !/*is_interactive*/
      i[60], R(o, "class", "color-picker-value svelte-31cuxt"), R(e, "class", "color-picker-container svelte-31cuxt"), Fe(e, "disabled", !/*is_interactive*/
      i[60]);
    },
    m(f, d) {
      V(f, e, d), z(e, t), Ue(
        t,
        /*prop*/
        i[59].value
      ), z(e, l), z(e, o), z(o, r), s || (u = [
        se(t, "input", c),
        se(t, "change", m)
      ], s = !0);
    },
    p(f, d) {
      i = f, d[0] & /*interactive, value*/
      8193 && n !== (n = !/*is_interactive*/
      i[60]) && (t.disabled = n), d[0] & /*value*/
      1 && Ue(
        t,
        /*prop*/
        i[59].value
      ), d[0] & /*value*/
      1 && a !== (a = /*prop*/
      i[59].value + "") && gt(r, a), d[0] & /*interactive, value, get_prop_value*/
      8396801 && Fe(e, "disabled", !/*is_interactive*/
      i[60]);
    },
    d(f) {
      f && I(e), s = !1, sn(u);
    }
  };
}
function js(i) {
  let e, t, n, l, o, a, r = (
    /*prop*/
    i[59]
  ), s, u, c = (
    /*prop*/
    i[59].value + ""
  ), m, f, d;
  function v() {
    i[40].call(
      t,
      /*each_value_1*/
      i[61],
      /*prop_index*/
      i[62]
    );
  }
  const y = () => (
    /*input_binding*/
    i[41](t, r)
  ), w = () => (
    /*input_binding*/
    i[41](null, r)
  );
  function C() {
    return (
      /*input_handler_2*/
      i[42](
        /*prop*/
        i[59]
      )
    );
  }
  function h() {
    return (
      /*change_handler_3*/
      i[43](
        /*prop*/
        i[59]
      )
    );
  }
  return {
    c() {
      e = G("div"), t = G("input"), s = me(), u = G("span"), m = ut(c), this.h();
    },
    l(_) {
      e = H(_, "DIV", { class: !0 });
      var g = J(e);
      t = H(g, "INPUT", {
        type: !0,
        min: !0,
        max: !0,
        step: !0,
        class: !0
      }), s = he(g), u = H(g, "SPAN", { class: !0 });
      var b = J(u);
      m = st(b, c), b.forEach(I), g.forEach(I), this.h();
    },
    h() {
      R(t, "type", "range"), R(t, "min", n = /*prop*/
      i[59].minimum), R(t, "max", l = /*prop*/
      i[59].maximum), R(t, "step", o = /*prop*/
      i[59].step || 1), t.disabled = a = !/*is_interactive*/
      i[60], R(t, "class", "svelte-31cuxt"), R(u, "class", "slider-value svelte-31cuxt"), R(e, "class", "slider-container svelte-31cuxt"), Fe(e, "disabled", !/*is_interactive*/
      i[60]);
    },
    m(_, g) {
      V(_, e, g), z(e, t), Ue(
        t,
        /*prop*/
        i[59].value
      ), y(), z(e, s), z(e, u), z(u, m), f || (d = [
        se(t, "change", v),
        se(t, "input", v),
        se(t, "input", C),
        se(t, "change", h)
      ], f = !0);
    },
    p(_, g) {
      i = _, g[0] & /*value*/
      1 && n !== (n = /*prop*/
      i[59].minimum) && R(t, "min", n), g[0] & /*value*/
      1 && l !== (l = /*prop*/
      i[59].maximum) && R(t, "max", l), g[0] & /*value*/
      1 && o !== (o = /*prop*/
      i[59].step || 1) && R(t, "step", o), g[0] & /*interactive, value*/
      8193 && a !== (a = !/*is_interactive*/
      i[60]) && (t.disabled = a), g[0] & /*value*/
      1 && Ue(
        t,
        /*prop*/
        i[59].value
      ), r !== /*prop*/
      i[59] && (w(), r = /*prop*/
      i[59], y()), g[0] & /*value*/
      1 && c !== (c = /*prop*/
      i[59].value + "") && gt(m, c), g[0] & /*interactive, value, get_prop_value*/
      8396801 && Fe(e, "disabled", !/*is_interactive*/
      i[60]);
    },
    d(_) {
      _ && I(e), w(), f = !1, sn(d);
    }
  };
}
function Vs(i) {
  let e, t, n, l, o;
  function a() {
    i[37].call(
      e,
      /*each_value_1*/
      i[61],
      /*prop_index*/
      i[62]
    );
  }
  function r() {
    return (
      /*change_handler_2*/
      i[38](
        /*prop*/
        i[59]
      )
    );
  }
  function s() {
    return (
      /*input_handler_1*/
      i[39](
        /*prop*/
        i[59]
      )
    );
  }
  return {
    c() {
      e = G("input"), this.h();
    },
    l(u) {
      e = H(u, "INPUT", { type: !0, step: !0, class: !0 }), this.h();
    },
    h() {
      R(e, "type", "number"), R(e, "step", t = /*prop*/
      i[59].step || 1), e.disabled = n = !/*is_interactive*/
      i[60], R(e, "class", "svelte-31cuxt"), Fe(
        e,
        "invalid",
        /*validationState*/
        i[17][
          /*prop*/
          i[59].name
        ] === !1
      ), Fe(e, "disabled", !/*is_interactive*/
      i[60]);
    },
    m(u, c) {
      V(u, e, c), Ue(
        e,
        /*prop*/
        i[59].value
      ), l || (o = [
        se(e, "input", a),
        se(e, "change", r),
        se(e, "input", s)
      ], l = !0);
    },
    p(u, c) {
      i = u, c[0] & /*value*/
      1 && t !== (t = /*prop*/
      i[59].step || 1) && R(e, "step", t), c[0] & /*interactive, value*/
      8193 && n !== (n = !/*is_interactive*/
      i[60]) && (e.disabled = n), c[0] & /*value*/
      1 && ui(e.value) !== /*prop*/
      i[59].value && Ue(
        e,
        /*prop*/
        i[59].value
      ), c[0] & /*validationState, value*/
      131073 && Fe(
        e,
        "invalid",
        /*validationState*/
        i[17][
          /*prop*/
          i[59].name
        ] === !1
      ), c[0] & /*interactive, value, get_prop_value*/
      8396801 && Fe(e, "disabled", !/*is_interactive*/
      i[60]);
    },
    d(u) {
      u && I(e), l = !1, sn(o);
    }
  };
}
function Ws(i) {
  let e, t, n, l;
  function o() {
    i[35].call(
      e,
      /*each_value_1*/
      i[61],
      /*prop_index*/
      i[62]
    );
  }
  function a() {
    return (
      /*change_handler_1*/
      i[36](
        /*prop*/
        i[59]
      )
    );
  }
  return {
    c() {
      e = G("input"), this.h();
    },
    l(r) {
      e = H(r, "INPUT", { type: !0, class: !0 }), this.h();
    },
    h() {
      R(e, "type", "checkbox"), e.disabled = t = !/*is_interactive*/
      i[60], R(e, "class", "svelte-31cuxt");
    },
    m(r, s) {
      V(r, e, s), e.checked = /*prop*/
      i[59].value, n || (l = [
        se(e, "change", o),
        se(e, "change", a)
      ], n = !0);
    },
    p(r, s) {
      i = r, s[0] & /*interactive, value*/
      8193 && t !== (t = !/*is_interactive*/
      i[60]) && (e.disabled = t), s[0] & /*value*/
      1 && (e.checked = /*prop*/
      i[59].value);
    },
    d(r) {
      r && I(e), n = !1, sn(l);
    }
  };
}
function Zs(i) {
  let e, t, n, l;
  function o() {
    i[32].call(
      e,
      /*each_value_1*/
      i[61],
      /*prop_index*/
      i[62]
    );
  }
  function a() {
    return (
      /*change_handler*/
      i[33](
        /*prop*/
        i[59]
      )
    );
  }
  function r() {
    return (
      /*input_handler*/
      i[34](
        /*prop*/
        i[59]
      )
    );
  }
  return {
    c() {
      e = G("input"), this.h();
    },
    l(s) {
      e = H(s, "INPUT", { type: !0, class: !0 }), this.h();
    },
    h() {
      R(e, "type", "text"), e.disabled = t = !/*is_interactive*/
      i[60], R(e, "class", "svelte-31cuxt");
    },
    m(s, u) {
      V(s, e, u), Ue(
        e,
        /*prop*/
        i[59].value
      ), n || (l = [
        se(e, "input", o),
        se(e, "change", a),
        se(e, "input", r)
      ], n = !0);
    },
    p(s, u) {
      i = s, u[0] & /*interactive, value*/
      8193 && t !== (t = !/*is_interactive*/
      i[60]) && (e.disabled = t), u[0] & /*value*/
      1 && e.value !== /*prop*/
      i[59].value && Ue(
        e,
        /*prop*/
        i[59].value
      );
    },
    d(s) {
      s && I(e), n = !1, sn(l);
    }
  };
}
function za(i) {
  let e, t = kt(
    /*prop*/
    i[59].choices
  ), n = [];
  for (let l = 0; l < t.length; l += 1)
    n[l] = Ua(Ta(i, t, l));
  return {
    c() {
      for (let l = 0; l < n.length; l += 1)
        n[l].c();
      e = Ne();
    },
    l(l) {
      for (let o = 0; o < n.length; o += 1)
        n[o].l(l);
      e = Ne();
    },
    m(l, o) {
      for (let a = 0; a < n.length; a += 1)
        n[a] && n[a].m(l, o);
      V(l, e, o);
    },
    p(l, o) {
      if (o[0] & /*value, interactive, get_prop_value*/
      8396801) {
        t = kt(
          /*prop*/
          l[59].choices
        );
        let a;
        for (a = 0; a < t.length; a += 1) {
          const r = Ta(l, t, a);
          n[a] ? n[a].p(r, o) : (n[a] = Ua(r), n[a].c(), n[a].m(e.parentNode, e));
        }
        for (; a < n.length; a += 1)
          n[a].d(1);
        n.length = t.length;
      }
    },
    d(l) {
      l && I(e), ql(n, l);
    }
  };
}
function Ua(i) {
  let e, t, n, l, o, a = !1, r, s, u, c = (
    /*choice*/
    i[63] + ""
  ), m, f, d, v, y, w;
  function C() {
    i[47].call(
      t,
      /*each_value_1*/
      i[61],
      /*prop_index*/
      i[62]
    );
  }
  return v = Ns(
    /*$$binding_groups*/
    i[48][0],
    [
      /*prop_index*/
      i[62],
      /*group_index*/
      i[58]
    ]
  ), {
    c() {
      e = G("div"), t = G("input"), s = me(), u = G("label"), m = ut(c), d = me(), this.h();
    },
    l(h) {
      e = H(h, "DIV", { class: !0 });
      var _ = J(e);
      t = H(_, "INPUT", {
        type: !0,
        id: !0,
        name: !0,
        class: !0
      }), s = he(_), u = H(_, "LABEL", { for: !0, class: !0 });
      var g = J(u);
      m = st(g, c), g.forEach(I), d = he(_), _.forEach(I), this.h();
    },
    h() {
      R(t, "type", "radio"), R(t, "id", n = /*prop*/
      i[59].name + "-" + /*choice*/
      i[63]), R(t, "name", l = /*prop*/
      i[59].name), t.__value = o = /*choice*/
      i[63], Ue(t, t.__value), t.disabled = r = !/*is_interactive*/
      i[60], R(t, "class", "svelte-31cuxt"), R(u, "for", f = /*prop*/
      i[59].name + "-" + /*choice*/
      i[63]), R(u, "class", "svelte-31cuxt"), R(e, "class", "radio-item svelte-31cuxt"), v.p(t);
    },
    m(h, _) {
      V(h, e, _), z(e, t), t.checked = t.__value === /*prop*/
      i[59].value, z(e, s), z(e, u), z(u, m), z(e, d), y || (w = se(t, "change", C), y = !0);
    },
    p(h, _) {
      i = h, _[0] & /*value*/
      1 && n !== (n = /*prop*/
      i[59].name + "-" + /*choice*/
      i[63]) && R(t, "id", n), _[0] & /*value*/
      1 && l !== (l = /*prop*/
      i[59].name) && R(t, "name", l), _[0] & /*value*/
      1 && o !== (o = /*choice*/
      i[63]) && (t.__value = o, Ue(t, t.__value), a = !0), _[0] & /*interactive, value*/
      8193 && r !== (r = !/*is_interactive*/
      i[60]) && (t.disabled = r), (a || _[0] & /*value*/
      1) && (t.checked = t.__value === /*prop*/
      i[59].value), _[0] & /*value*/
      1 && c !== (c = /*choice*/
      i[63] + "") && gt(m, c), _[0] & /*value*/
      1 && f !== (f = /*prop*/
      i[59].name + "-" + /*choice*/
      i[63]) && R(u, "for", f), _[0] & /*value*/
      1 && v.u([
        /*prop_index*/
        i[62],
        /*group_index*/
        i[58]
      ]);
    },
    d(h) {
      h && I(e), v.r(), y = !1, w();
    }
  };
}
function Ha(i) {
  let e, t = kt(
    /*prop*/
    i[59].choices
  ), n = [];
  for (let l = 0; l < t.length; l += 1)
    n[l] = Ga(Ba(i, t, l));
  return {
    c() {
      for (let l = 0; l < n.length; l += 1)
        n[l].c();
      e = Ne();
    },
    l(l) {
      for (let o = 0; o < n.length; o += 1)
        n[o].l(l);
      e = Ne();
    },
    m(l, o) {
      for (let a = 0; a < n.length; a += 1)
        n[a] && n[a].m(l, o);
      V(l, e, o);
    },
    p(l, o) {
      if (o[0] & /*value*/
      1) {
        t = kt(
          /*prop*/
          l[59].choices
        );
        let a;
        for (a = 0; a < t.length; a += 1) {
          const r = Ba(l, t, a);
          n[a] ? n[a].p(r, o) : (n[a] = Ga(r), n[a].c(), n[a].m(e.parentNode, e));
        }
        for (; a < n.length; a += 1)
          n[a].d(1);
        n.length = t.length;
      }
    },
    d(l) {
      l && I(e), ql(n, l);
    }
  };
}
function Ga(i) {
  let e, t = (
    /*choice*/
    i[63] + ""
  ), n, l, o, a;
  return {
    c() {
      e = G("option"), n = ut(t), l = me(), this.h();
    },
    l(r) {
      e = H(r, "OPTION", { class: !0 });
      var s = J(e);
      n = st(s, t), l = he(s), s.forEach(I), this.h();
    },
    h() {
      e.__value = o = /*choice*/
      i[63], Ue(e, e.__value), e.selected = a = /*prop*/
      i[59].value === /*choice*/
      i[63], R(e, "class", "svelte-31cuxt");
    },
    m(r, s) {
      V(r, e, s), z(e, n), z(e, l);
    },
    p(r, s) {
      s[0] & /*value*/
      1 && t !== (t = /*choice*/
      r[63] + "") && gt(n, t), s[0] & /*value*/
      1 && o !== (o = /*choice*/
      r[63]) && (e.__value = o, Ue(e, e.__value)), s[0] & /*value*/
      1 && a !== (a = /*prop*/
      r[59].value === /*choice*/
      r[63]) && (e.selected = a);
    },
    d(r) {
      r && I(e);
    }
  };
}
function ja(i) {
  let e, t, n, l, o;
  function a() {
    return (
      /*click_handler_1*/
      i[50](
        /*prop*/
        i[59]
      )
    );
  }
  return {
    c() {
      e = G("button"), t = ut("↺"), this.h();
    },
    l(r) {
      e = H(r, "BUTTON", { class: !0, title: !0 });
      var s = J(e);
      t = st(s, "↺"), s.forEach(I), this.h();
    },
    h() {
      R(e, "class", "reset-button-prop svelte-31cuxt"), R(e, "title", "Reset to default"), e.disabled = n = !/*is_interactive*/
      i[60], Fe(
        e,
        "visible",
        /*initialValues*/
        i[18][
          /*prop*/
          i[59].name
        ] !== /*prop*/
        i[59].value
      );
    },
    m(r, s) {
      V(r, e, s), z(e, t), l || (o = se(e, "click", Ps(a)), l = !0);
    },
    p(r, s) {
      i = r, s[0] & /*interactive, value*/
      8193 && n !== (n = !/*is_interactive*/
      i[60]) && (e.disabled = n), s[0] & /*initialValues, value*/
      262145 && Fe(
        e,
        "visible",
        /*initialValues*/
        i[18][
          /*prop*/
          i[59].name
        ] !== /*prop*/
        i[59].value
      );
    },
    d(r) {
      r && I(e), l = !1, o();
    }
  };
}
function Va(i, e) {
  let t, n, l, o = (
    /*prop*/
    e[59].label + ""
  ), a, r, s, u, c, m, f, d = (
    /*prop*/
    e[59].help && Pa(e)
  );
  function v(h, _) {
    if (
      /*prop*/
      h[59].component === "string"
    ) return Zs;
    if (
      /*prop*/
      h[59].component === "checkbox"
    ) return Ws;
    if (
      /*prop*/
      h[59].component === "number_integer" || /*prop*/
      h[59].component === "number_float"
    ) return Vs;
    if (
      /*prop*/
      h[59].component === "slider"
    ) return js;
    if (
      /*prop*/
      h[59].component === "colorpicker"
    ) return Gs;
    if (
      /*prop*/
      h[59].component === "dropdown"
    ) return Hs;
    if (
      /*prop*/
      h[59].component === "radio"
    ) return Us;
  }
  let y = v(e), w = y && y(e), C = (
    /*prop*/
    e[59].component !== "checkbox" && ja(e)
  );
  return {
    key: i,
    first: null,
    c() {
      t = G("label"), n = G("div"), l = G("span"), a = ut(o), r = me(), d && d.c(), u = me(), c = G("div"), w && w.c(), m = me(), C && C.c(), f = me(), this.h();
    },
    l(h) {
      t = H(h, "LABEL", { class: !0, for: !0 });
      var _ = J(t);
      n = H(_, "DIV", { class: !0 });
      var g = J(n);
      l = H(g, "SPAN", {});
      var b = J(l);
      a = st(b, o), b.forEach(I), r = he(g), d && d.l(g), g.forEach(I), _.forEach(I), u = he(h), c = H(h, "DIV", { class: !0 });
      var F = J(c);
      w && w.l(F), m = he(F), C && C.l(F), f = he(F), F.forEach(I), this.h();
    },
    h() {
      R(n, "class", "prop-label-wrapper svelte-31cuxt"), R(t, "class", "prop-label svelte-31cuxt"), R(t, "for", s = /*prop*/
      e[59].name), R(c, "class", "prop-control svelte-31cuxt"), this.first = t;
    },
    m(h, _) {
      V(h, t, _), z(t, n), z(n, l), z(l, a), z(n, r), d && d.m(n, null), V(h, u, _), V(h, c, _), w && w.m(c, null), z(c, m), C && C.m(c, null), z(c, f);
    },
    p(h, _) {
      e = h, _[0] & /*value*/
      1 && o !== (o = /*prop*/
      e[59].label + "") && gt(a, o), /*prop*/
      e[59].help ? d ? d.p(e, _) : (d = Pa(e), d.c(), d.m(n, null)) : d && (d.d(1), d = null), _[0] & /*value*/
      1 && s !== (s = /*prop*/
      e[59].name) && R(t, "for", s), y === (y = v(e)) && w ? w.p(e, _) : (w && w.d(1), w = y && y(e), w && (w.c(), w.m(c, m))), /*prop*/
      e[59].component !== "checkbox" ? C ? C.p(e, _) : (C = ja(e), C.c(), C.m(c, f)) : C && (C.d(1), C = null);
    },
    d(h) {
      h && (I(t), I(u), I(c)), d && d.d(), w && w.d(), C && C.d();
    }
  };
}
function Wa(i, e) {
  let t, n, l, o = (
    /*value*/
    (e[0].length > 1 || /*show_group_name_only_one*/
    e[3] && /*value*/
    e[0].length === 1) && xa(e)
  ), a = (
    /*groupVisibility*/
    e[15][
      /*group*/
      e[56].group_name
    ] && Na(e)
  );
  return {
    key: i,
    first: null,
    c() {
      t = Ne(), o && o.c(), n = me(), a && a.c(), l = Ne(), this.h();
    },
    l(r) {
      t = Ne(), o && o.l(r), n = he(r), a && a.l(r), l = Ne(), this.h();
    },
    h() {
      this.first = t;
    },
    m(r, s) {
      V(r, t, s), o && o.m(r, s), V(r, n, s), a && a.m(r, s), V(r, l, s);
    },
    p(r, s) {
      e = r, /*value*/
      e[0].length > 1 || /*show_group_name_only_one*/
      e[3] && /*value*/
      e[0].length === 1 ? o ? o.p(e, s) : (o = xa(e), o.c(), o.m(n.parentNode, n)) : o && (o.d(1), o = null), /*groupVisibility*/
      e[15][
        /*group*/
        e[56].group_name
      ] ? a ? a.p(e, s) : (a = Na(e), a.c(), a.m(l.parentNode, l)) : a && (a.d(1), a = null);
    },
    d(r) {
      r && (I(t), I(n), I(l)), o && o.d(r), a && a.d(r);
    }
  };
}
function Ys(i) {
  let e, t, n, l, o, a, r, s, u = (
    /*loading_status*/
    i[12] && Ra(i)
  ), c = (
    /*label*/
    i[2] && Ia(i)
  ), m = !/*disable_accordion*/
  i[4] && La(i), f = (
    /*open*/
    i[1] && Oa(i)
  );
  return {
    c() {
      u && u.c(), e = me(), t = G("button"), c && c.c(), n = me(), m && m.c(), l = me(), o = G("div"), f && f.c(), this.h();
    },
    l(d) {
      u && u.l(d), e = he(d), t = H(d, "BUTTON", { class: !0 });
      var v = J(t);
      c && c.l(v), n = he(v), m && m.l(v), v.forEach(I), l = he(d), o = H(d, "DIV", { class: !0 });
      var y = J(o);
      f && f.l(y), y.forEach(I), this.h();
    },
    h() {
      R(t, "class", "accordion-header svelte-31cuxt"), t.disabled = /*disable_accordion*/
      i[4], R(o, "class", "content-wrapper svelte-31cuxt"), Fe(o, "closed", !/*open*/
      i[1]);
    },
    m(d, v) {
      u && u.m(d, v), V(d, e, v), V(d, t, v), c && c.m(t, null), z(t, n), m && m.m(t, null), V(d, l, v), V(d, o, v), f && f.m(o, null), a = !0, r || (s = se(
        t,
        "click",
        /*handle_toggle*/
        i[21]
      ), r = !0);
    },
    p(d, v) {
      /*loading_status*/
      d[12] ? u ? (u.p(d, v), v[0] & /*loading_status*/
      4096 && an(u, 1)) : (u = Ra(d), u.c(), an(u, 1), u.m(e.parentNode, e)) : u && (qs(), Rn(u, 1, 1, () => {
        u = null;
      }), Is()), /*label*/
      d[2] ? c ? c.p(d, v) : (c = Ia(d), c.c(), c.m(t, n)) : c && (c.d(1), c = null), /*disable_accordion*/
      d[4] ? m && (m.d(1), m = null) : m ? m.p(d, v) : (m = La(d), m.c(), m.m(t, null)), (!a || v[0] & /*disable_accordion*/
      16) && (t.disabled = /*disable_accordion*/
      d[4]), /*open*/
      d[1] ? f ? f.p(d, v) : (f = Oa(d), f.c(), f.m(o, null)) : f && (f.d(1), f = null), (!a || v[0] & /*open*/
      2) && Fe(o, "closed", !/*open*/
      d[1]);
    },
    i(d) {
      a || (an(u), a = !0);
    },
    o(d) {
      Rn(u), a = !1;
    },
    d(d) {
      d && (I(e), I(t), I(l), I(o)), u && u.d(d), c && c.d(), m && m.d(), f && f.d(), r = !1, s();
    }
  };
}
function Xs(i) {
  let e, t;
  return e = new _o({
    props: {
      visible: (
        /*visible*/
        i[5]
      ),
      elem_id: (
        /*elem_id*/
        i[6]
      ),
      elem_classes: (
        /*final_classes*/
        i[19]
      ),
      container: (
        /*container*/
        i[7]
      ),
      scale: (
        /*scale*/
        i[8]
      ),
      min_width: (
        /*min_width*/
        i[9]
      ),
      width: (
        /*width*/
        i[10]
      ),
      $$slots: { default: [Ys] },
      $$scope: { ctx: i }
    }
  }), {
    c() {
      Il(e.$$.fragment);
    },
    l(n) {
      Rl(e.$$.fragment, n);
    },
    m(n, l) {
      Nl(e, n, l), t = !0;
    },
    p(n, l) {
      const o = {};
      l[0] & /*visible*/
      32 && (o.visible = /*visible*/
      n[5]), l[0] & /*elem_id*/
      64 && (o.elem_id = /*elem_id*/
      n[6]), l[0] & /*final_classes*/
      524288 && (o.elem_classes = /*final_classes*/
      n[19]), l[0] & /*container*/
      128 && (o.container = /*container*/
      n[7]), l[0] & /*scale*/
      256 && (o.scale = /*scale*/
      n[8]), l[0] & /*min_width*/
      512 && (o.min_width = /*min_width*/
      n[9]), l[0] & /*width*/
      1024 && (o.width = /*width*/
      n[10]), l[0] & /*open, value, show_group_name_only_one, height, interactive, initialValues, validationState, sliderElements, groupVisibility, disable_accordion, label, gradio, loading_status*/
      522271 | l[2] & /*$$scope*/
      64 && (o.$$scope = { dirty: l, ctx: n }), e.$set(o);
    },
    i(n) {
      t || (an(e.$$.fragment, n), t = !0);
    },
    o(n) {
      Rn(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Ol(e, n);
    }
  };
}
function Za(i, e) {
  var t, n;
  if (!e) return;
  const l = (t = i.minimum) !== null && t !== void 0 ? t : 0, o = (n = i.maximum) !== null && n !== void 0 ? n : 100, a = Number(i.value), r = a <= l ? 0 : (a - l) * 100 / (o - l);
  e.style.setProperty("--slider-progress", `${r}%`);
}
function Ks(i, e, t) {
  let n;
  var l = this && this.__awaiter || function(D, q, W, ee) {
    function ve(wt) {
      return wt instanceof W ? wt : new W(function(Et) {
        Et(wt);
      });
    }
    return new (W || (W = Promise))(function(wt, Et) {
      function _n(Ie) {
        try {
          It(ee.next(Ie));
        } catch (Ft) {
          Et(Ft);
        }
      }
      function Ht(Ie) {
        try {
          It(ee.throw(Ie));
        } catch (Ft) {
          Et(Ft);
        }
      }
      function It(Ie) {
        Ie.done ? wt(Ie.value) : ve(Ie.value).then(_n, Ht);
      }
      It((ee = ee.apply(D, q || [])).next());
    });
  }, o;
  let { value: a = [] } = e, { label: r = void 0 } = e, { show_group_name_only_one: s = !0 } = e, { disable_accordion: u = !1 } = e, { visible: c = !0 } = e, { open: m = !0 } = e, { elem_id: f = "" } = e, { elem_classes: d = [] } = e, { container: v = !1 } = e, { scale: y = null } = e, { min_width: w = void 0 } = e, { width: C = void 0 } = e, { height: h = void 0 } = e, { loading_status: _ = void 0 } = e, { interactive: g = !0 } = e, { gradio: b } = e, F = {}, A = {}, T = {}, S = null, N = !1, x = {};
  function U(D) {
    if (D.minimum === void 0 && D.maximum === void 0) {
      T[D.name] !== !0 && (t(17, T[D.name] = !0, T), t(17, T = Object.assign({}, T)));
      return;
    }
    const q = Number(D.value);
    let W = !0;
    D.minimum !== void 0 && q < D.minimum && (W = !1), D.maximum !== void 0 && q > D.maximum && (W = !1), T[D.name] !== W && (t(17, T[D.name] = W, T), t(17, T = Object.assign({}, T)));
  }
  function $e() {
    if (Array.isArray(a)) {
      for (const D of a)
        if (Array.isArray(D.properties))
          for (const q of D.properties)
            q.component === "slider" && A[q.name] && Za(q, A[q.name]);
    }
  }
  function ue() {
    t(1, m = !m), m ? b.dispatch("expand") : b.dispatch("collapse");
  }
  function ke(D) {
    t(15, F[D] = !F[D], F);
  }
  function _e(D) {
    if (Array.isArray(a))
      for (const q of a) {
        if (!Array.isArray(q.properties)) continue;
        const W = q.properties.find((ee) => ee.name === D);
        if (W) return W.value;
      }
  }
  function le(D, q) {
    var W;
    if (T[q.name] === !1)
      return;
    const ee = {};
    let ve = q.value;
    !((W = q.component) === null || W === void 0) && W.startsWith("number") || q.component === "slider" ? ve = Number(q.value) : q.component === "checkbox" && (ve = q.value), ee[q.name] = ve, b.dispatch(D, ee);
  }
  function K(D, q) {
    return l(this, void 0, void 0, function* () {
      const W = D.target.value;
      t(0, a = a.map((ee) => ee.properties ? Object.assign(Object.assign({}, ee), {
        properties: ee.properties.map((ve) => ve.name === q.name ? Object.assign(Object.assign({}, ve), { value: W }) : ve)
      }) : ee)), yield Aa(), b.dispatch("change", a);
    });
  }
  function re(D) {
    if (N) return;
    if (N = !0, !(D in x)) {
      N = !1;
      return;
    }
    let q = a.map((W) => (W.properties && (W.properties = W.properties.map((ee) => ee.name === D ? Object.assign(Object.assign({}, ee), { value: x[D] }) : ee)), W));
    t(0, a = q), b.dispatch("undo", q), setTimeout(
      () => {
        N = !1;
      },
      100
    );
  }
  function ge() {
    t(29, S = JSON.stringify(a)), Array.isArray(a) && a.forEach((D) => {
      Array.isArray(D.properties) && D.properties.forEach((q) => {
        t(18, x[q.name] = q.value, x);
      });
    }), setTimeout($e, 50);
  }
  zs(() => {
    ge();
  });
  const $ = [[]], oe = () => b.dispatch("clear_status"), Q = (D) => ke(D.group_name);
  function de(D, q) {
    D[q].value = this.value, t(0, a);
  }
  const E = (D) => le("change", D), Se = (D) => le("input", D);
  function Xe(D, q) {
    D[q].value = this.checked, t(0, a);
  }
  const vt = (D) => le("change", D);
  function Dt(D, q) {
    D[q].value = ui(this.value), t(0, a);
  }
  const bt = (D) => le("change", D), ct = (D) => {
    U(D), le("input", D);
  };
  function Ke(D, q) {
    D[q].value = ui(this.value), t(0, a);
  }
  function Qe(D, q) {
    Rs[D ? "unshift" : "push"](() => {
      A[q.name] = D, t(16, A);
    });
  }
  const _t = (D) => {
    U(D), Za(D, A[D.name]), le("input", D);
  }, zt = (D) => le("change", D);
  function Ut(D, q) {
    D[q].value = this.value, t(0, a);
  }
  const yt = (D) => le("change", D), Bt = (D, q) => K(q, D);
  function Rt(D, q) {
    D[q].value = this.__value, t(0, a);
  }
  const un = (D) => le("change", D), cn = (D) => re(D.name);
  return i.$$set = (D) => {
    "value" in D && t(0, a = D.value), "label" in D && t(2, r = D.label), "show_group_name_only_one" in D && t(3, s = D.show_group_name_only_one), "disable_accordion" in D && t(4, u = D.disable_accordion), "visible" in D && t(5, c = D.visible), "open" in D && t(1, m = D.open), "elem_id" in D && t(6, f = D.elem_id), "elem_classes" in D && t(27, d = D.elem_classes), "container" in D && t(7, v = D.container), "scale" in D && t(8, y = D.scale), "min_width" in D && t(9, w = D.min_width), "width" in D && t(10, C = D.width), "height" in D && t(11, h = D.height), "loading_status" in D && t(12, _ = D.loading_status), "interactive" in D && t(13, g = D.interactive), "gradio" in D && t(14, b = D.gradio);
  }, i.$$.update = () => {
    if (i.$$.dirty[0] & /*elem_classes*/
    134217728 && t(19, n = ["propertysheet-wrapper", ...d]), i.$$.dirty[0] & /*open, height*/
    2050, i.$$.dirty[0] & /*value, lastValue, groupVisibility, _a*/
    805339137 && Array.isArray(a) && JSON.stringify(a) !== S) {
      t(29, S = JSON.stringify(a));
      for (const D of a)
        if (F[D.group_name] === void 0 && t(15, F[D.group_name] = !0, F), Array.isArray(D.properties))
          for (const q of D.properties)
            (!(t(28, o = q.component) === null || o === void 0) && o.startsWith("number") || q.component === "slider") && U(q);
      $e();
    }
    i.$$.dirty[0] & /*open, groupVisibility*/
    32770 && m && F && Aa().then($e);
  }, [
    a,
    m,
    r,
    s,
    u,
    c,
    f,
    v,
    y,
    w,
    C,
    h,
    _,
    g,
    b,
    F,
    A,
    T,
    x,
    n,
    U,
    ue,
    ke,
    _e,
    le,
    K,
    re,
    d,
    o,
    S,
    oe,
    Q,
    de,
    E,
    Se,
    Xe,
    vt,
    Dt,
    bt,
    ct,
    Ke,
    Qe,
    _t,
    zt,
    Ut,
    yt,
    Bt,
    Rt,
    $,
    un,
    cn
  ];
}
class wA extends Ts {
  constructor(e) {
    super(), xs(
      this,
      e,
      Ks,
      Xs,
      Ms,
      {
        value: 0,
        label: 2,
        show_group_name_only_one: 3,
        disable_accordion: 4,
        visible: 5,
        open: 1,
        elem_id: 6,
        elem_classes: 27,
        container: 7,
        scale: 8,
        min_width: 9,
        width: 10,
        height: 11,
        loading_status: 12,
        interactive: 13,
        gradio: 14
      },
      null,
      [-1, -1, -1]
    );
  }
}
export {
  wA as default
};
