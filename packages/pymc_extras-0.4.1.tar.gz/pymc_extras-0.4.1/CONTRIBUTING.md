# Contributing guide

Page in construction, for now go to https://github.com/pymc-devs/pymc-extras#questions.
