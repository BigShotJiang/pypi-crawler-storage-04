#!/usr/bin/env python

"""Tests for `netbox_sitemaps` package."""

from netbox_sitemaps import netbox_sitemaps
