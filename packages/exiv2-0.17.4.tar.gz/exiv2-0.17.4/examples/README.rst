Examples
========

These example files show some typical (and not so typical) ways to use the Python exiv2 interface.
Some of them are based on the `C++ examples`_ provided by the Exiv2 project.
It might be instructive to compare the C++ and Python ways of doing the same thing.

.. _C++ examples:      https://www.exiv2.org/doc/examples.html
