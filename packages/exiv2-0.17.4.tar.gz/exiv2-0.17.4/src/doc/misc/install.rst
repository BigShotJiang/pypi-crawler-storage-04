.. This is part of the python-exiv2 documentation.
   Copyright (C)  2024  Jim Easterbrook.

.. include:: ../../../INSTALL.rst
   :end-before: .. _README

.. _README.rst:   readme.html
