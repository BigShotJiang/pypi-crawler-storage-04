.. This is part of the python-exiv2 documentation.
   Copyright (C)  2024  Jim Easterbrook.

Project overview
================

.. include:: ../../../README.rst
   :start-line: 2
   :end-before: .. _INSTALL

.. _INSTALL.rst: install.html
.. _USAGE.rst:   usage.html
