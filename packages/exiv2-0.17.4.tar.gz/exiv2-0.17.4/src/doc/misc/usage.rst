.. This is part of the python-exiv2 documentation.
   Copyright (C)  2024  Jim Easterbrook.

.. include:: ../../../USAGE.rst
