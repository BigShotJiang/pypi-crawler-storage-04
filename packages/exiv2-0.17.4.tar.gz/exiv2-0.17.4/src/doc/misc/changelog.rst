.. This is part of the python-exiv2 documentation.
   Copyright (C)  2024  Jim Easterbrook.

Release history
===============

.. literalinclude:: ../../../CHANGELOG.txt
   :language: none
   :start-after: licenses/>
   :end-before: Changes in v0.4.0
