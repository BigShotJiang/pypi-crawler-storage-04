.. This is part of the python-exiv2 documentation.
   Copyright (C)  2024  Jim Easterbrook.

Python-exiv2 documentation
==========================


.. toctree::
   :maxdepth: 2

   misc/readme
   misc/install
   misc/usage
   misc/changelog
   misc/api

