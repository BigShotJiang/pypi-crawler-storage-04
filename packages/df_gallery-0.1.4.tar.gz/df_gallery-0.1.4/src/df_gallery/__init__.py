# src/df_gallery/__init__.py

"""df-gallery: dataframe-to-gallery toolkit."""

__all__ = ["__version__"]
