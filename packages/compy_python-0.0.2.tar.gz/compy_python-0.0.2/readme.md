# Compy Python
This library contains necessary python code for Compy projects.

Compy (Compiled Python) is a framework for writing Python code that can be transpiled to C++ and then compiled, which will soon release a version 1.0.0.