def tg(tup: tuple[any, ...], index: int) -> any:
    return tup[index]
