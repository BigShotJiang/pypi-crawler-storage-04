from typing import TypeVar

# TODO: remove these TypeVar things because there is a better way to that now.
T = TypeVar("T")


def list_reserve(arr: list[T], size: int) -> None:
    pass
