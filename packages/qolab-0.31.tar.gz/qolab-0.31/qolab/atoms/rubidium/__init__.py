from .rubidium import Rubidium

__all__ = [
    "Rubidium",
]
