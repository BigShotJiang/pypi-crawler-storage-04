def main():
    print("Hello from zpack!")


if __name__ == "__main__":
    main()
