# zpack

A fast, configurable module system that builds packages from source.

Build using Rust

