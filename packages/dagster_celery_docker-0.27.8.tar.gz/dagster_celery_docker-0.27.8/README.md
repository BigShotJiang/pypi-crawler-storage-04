# dagster-celery-docker

The docs for `dagster-celery-docker` can be found
[here](https://docs.dagster.io/api/python-api/libraries/dagster-celery_docker).
