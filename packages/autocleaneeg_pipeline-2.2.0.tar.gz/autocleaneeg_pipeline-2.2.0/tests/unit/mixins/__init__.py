"""Unit tests for AutoClean EEG mixins."""
