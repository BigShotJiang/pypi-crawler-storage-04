"""Unit tests for core AutoClean EEG modules."""
