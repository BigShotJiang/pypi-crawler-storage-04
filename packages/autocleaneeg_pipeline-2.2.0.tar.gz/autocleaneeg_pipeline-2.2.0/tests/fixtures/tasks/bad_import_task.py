
from autoclean.core.task import Task


class BadImportTask(Task):
    """This task has a bad import."""

    def run(self):
        pass
