"""Test fixtures and utilities for AutoClean EEG."""
