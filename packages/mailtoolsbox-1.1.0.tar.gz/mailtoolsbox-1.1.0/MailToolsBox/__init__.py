from MailToolsBox.mailSender import EmailSender, SendAgent
from MailToolsBox.imapClient import ImapAgent

__version__ = "1.0.1"

__all__ = ["EmailSender", "SendAgent", "ImapAgent", "__version__"]
