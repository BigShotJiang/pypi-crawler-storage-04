"""Subtitle Builder Module."""

from subtitle_alchemy.forger._srt import gen_srt

__all__ = [
    "gen_srt",
]
