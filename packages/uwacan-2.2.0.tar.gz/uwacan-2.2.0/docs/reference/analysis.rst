Analysis
========
.. automodule:: uwacan.analysis
