_linked_duplicate_label
=======================


.. solution:: ex-nonumber-notitle
	:label: sol-duplicate-label

	Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.

.. solution:: ex-nonumber-notitle
	:label: sol-duplicate-label

	Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
