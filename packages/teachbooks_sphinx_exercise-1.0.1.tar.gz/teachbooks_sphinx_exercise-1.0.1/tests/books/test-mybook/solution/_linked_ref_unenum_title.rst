_linked_ref_unenum_title
========================


referencing: :ref:`sol-nonumber-title`.

referencing: :ref:`exercise with nonumber but with title <sol-nonumber-title>`.
