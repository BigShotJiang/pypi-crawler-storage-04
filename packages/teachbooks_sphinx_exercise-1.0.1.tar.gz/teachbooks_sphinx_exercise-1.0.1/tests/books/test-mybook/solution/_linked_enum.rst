_linked_enum
============


.. exercise:: This is a title
	:label: ex-number

	Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.

	Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.

	Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.


.. solution:: ex-number
	:label: sol-number

	Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.

	.. math::

		P_t(x, y) = \mathbb 1\{x = y\} + t Q(x, y) + o(t)

	Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

	.. math::
		:label: ex-math

		P_t(x, y) = \mathbb 1\{x = y\} + t Q(x, y) + o(t)
