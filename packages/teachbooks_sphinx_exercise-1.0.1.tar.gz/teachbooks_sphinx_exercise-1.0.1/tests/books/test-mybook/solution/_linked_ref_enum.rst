_linked_ref_enum
================


referencing: :ref:`sol-number`.

referencing: :ref:`simple solution with number <sol-number>`.
