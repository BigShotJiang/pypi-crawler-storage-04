_linked_unenum_mathtitle2
=========================


.. exercise:: This is a title :math:`P_t(x, y) = \mathbb 1\{x = y\} + t Q(x, y) + o(t)`
	:label: ex-nonumber-title-math2
	:nonumber:

	Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.

	Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.

	Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.


.. solution:: ex-nonumber-title-math2
	:label: sol-nonumber-title-math2

	Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
