_linked_ref_unenum_mathtitle2
=============================


referencing: :ref:`sol-nonumber-title-math2`.

referencing: :ref:`exercise with nonumber but with inline math title ex2 <sol-nonumber-title-math2>`.
