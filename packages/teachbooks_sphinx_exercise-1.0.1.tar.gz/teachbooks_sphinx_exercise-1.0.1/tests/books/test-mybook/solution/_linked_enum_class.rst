_linked_enum_class
==================

.. solution:: ex-number
	:label: solution-label
	:class: test-solution

	Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
