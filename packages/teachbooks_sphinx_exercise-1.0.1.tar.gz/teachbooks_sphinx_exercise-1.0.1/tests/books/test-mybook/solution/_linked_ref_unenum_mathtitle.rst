_linked_ref_unenum_mathtitle
============================


referencing: :ref:`sol-nonumber-title-math`.

referencing: :ref:`exercise with nonumber but with inline math title <sol-nonumber-title-math>`.
