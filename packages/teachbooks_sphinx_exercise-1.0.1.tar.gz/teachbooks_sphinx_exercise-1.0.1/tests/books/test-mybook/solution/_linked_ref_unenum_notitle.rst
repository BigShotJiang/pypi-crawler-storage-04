_linked_ref_unenum_notitle
==========================


referencing: :ref:`sol-nonumber-notitle`.

referencing: :ref:`ex with nonumber and notitle <sol-nonumber-notitle>`.
