_enum_ref_mathtitle
===================

This is a reference :ref:`test-exc-label-math`.

This is a second reference :ref:`some text <test-exc-label-math>`.
