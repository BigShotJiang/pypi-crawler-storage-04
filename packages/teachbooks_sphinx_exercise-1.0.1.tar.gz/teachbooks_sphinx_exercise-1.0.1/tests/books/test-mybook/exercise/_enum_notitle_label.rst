_enum_notitle_label
===================

.. exercise::
	:label: text-exc-notitle

	Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
