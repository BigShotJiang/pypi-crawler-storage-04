_enum_numref_title
==================

This is a reference :numref:`test-exc-label`.

This is a second reference :numref:`some text %s <test-exc-label>`.

This is a third reference :numref:`some text {number} <test-exc-label>`.

This is a fourth reference :numref:`some text {name} <test-exc-label>`.
