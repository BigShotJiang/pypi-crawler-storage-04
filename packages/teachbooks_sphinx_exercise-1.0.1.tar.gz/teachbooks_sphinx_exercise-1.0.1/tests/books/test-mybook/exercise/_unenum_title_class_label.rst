_unenum_title_class_label
=========================

.. exercise:: Test exercise directive
	:class: unen-exc
	:label: unen-exc-label
	:nonumber:

	Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
