---
jupytext:
  text_representation:
    extension: .md
    format_name: myst
kernelspec:
  display_name: Python 3
  language: python
  name: python3
---

# Non-Gated Exercises

Some reference exercises

````{exercise}
:label: exercise-1

Replicate this figure using matplotlib

```{figure} sphx_glr_cohere_001_2_0x.png
```
````

and another version with a title embedded

````{exercise} Replicate Matplotlib Plot
:label: exercise-2

```{figure} sphx_glr_cohere_001_2_0x.png
```
````
