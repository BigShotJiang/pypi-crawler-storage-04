---
jupytext:
  text_representation:
    extension: .md
    format_name: myst
kernelspec:
  display_name: Python 3
  language: python
  name: python3
---

# Errors 3

## Incorrect Nesting of Gated Exercise Directives

```{exercise-start}
```

```{exercise-start}
```

```{exercise-end}
```

```{exercise-end}
```
