---
jupytext:
  text_representation:
    extension: .md
    format_name: myst
kernelspec:
  display_name: Python 3
  language: python
  name: python3
---

# Solution Errors 3

## Incorrect Nesting of Gated Directives

```{solution-start} solution1
```

```{solution-start} solution2
```

```{solution-end}
```

```{solution-end}
```
