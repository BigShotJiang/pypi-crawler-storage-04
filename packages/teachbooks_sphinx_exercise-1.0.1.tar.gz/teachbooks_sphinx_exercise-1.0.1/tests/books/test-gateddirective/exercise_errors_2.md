---
jupytext:
  text_representation:
    extension: .md
    format_name: myst
kernelspec:
  display_name: Python 3
  language: python
  name: python3
---

# Exercise Errors 2

Some malformed directives

## Missing `-start` directive

Replicate this figure using matplotlib

```{figure} sphx_glr_cohere_001_2_0x.png
```

```{exercise-end}
```
