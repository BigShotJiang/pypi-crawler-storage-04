---
jupytext:
  text_representation:
    extension: .md
    format_name: myst
kernelspec:
  display_name: Python 3
  language: python
  name: python3
---

# Gated Directives

```{toctree}
:hidden: true
:maxdepth: 1

exercise
solution-exercise
exercise-gated
solution-exercise-gated
```
