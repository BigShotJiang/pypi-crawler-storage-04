---
jupytext:
  text_representation:
    extension: .md
    format_name: myst
kernelspec:
  display_name: Python 3
  language: python
  name: python3
---

# Exercise Errors 1

Some malformed directives

## Missing `-end` directive

A solution using the gated directive

```{exercise-start}
:label: error-exercise-1
```

Replicate this figure using matplotlib

```{figure} sphx_glr_cohere_001_2_0x.png
```
