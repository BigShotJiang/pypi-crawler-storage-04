_linked_enum_hidden
===================


.. solution:: ex-hidden-number
	:label: solution-hidden-label
	:hidden:

	Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
