_linked_unenum_hidden
=====================


.. solution:: unenum-hidden
	:label: solution-unenum-label
	:hidden:

	Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
