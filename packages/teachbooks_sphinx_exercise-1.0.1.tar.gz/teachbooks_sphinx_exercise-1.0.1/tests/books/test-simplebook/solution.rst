Solution
========

A collection of solution directives

.. solution:: exercise-1
    :label: solution-1

    This is a solution to exercise 1

.. solution:: exercise-2
    :label: solution-2

    This is a solution to exercise 2

.. solution:: exercise-3
    :label: solution-3

    This is a solution to exercise 3

.. solution:: exercise-4
    :label: solution-4

    This is a solution to exercise 4


References
----------

Standard References
~~~~~~~~~~~~~~~~~~~

This is a link to :ref:`solution-1`

This is a link to :ref:`solution-2`

This is a link to :ref:`solution-3`

This is a link to :ref:`solution-4`

This ia another link to a different :ref:`custom label text to solution-1 <solution-1>`

Numbered References
~~~~~~~~~~~~~~~~~~~

Solution nodes are not enumerated nodes so these won't work

This is a link to :numref:`solution-1`
