"""
Fullscreen alert module.
"""

from .core import fullscreen


__version__ = "0.1.3"
__all__ = ["fullscreen"]