from nonebot.utils import logger_wrapper

ds_logger = logger_wrapper(logger_name="Plugin-DeepSeek")
tts_logger = logger_wrapper(logger_name="Plugin-DeepSeek-TTS")
