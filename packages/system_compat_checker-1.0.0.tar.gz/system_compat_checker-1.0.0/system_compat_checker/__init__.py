# System Compatibility Checker
# A cross-platform CLI tool for checking system compatibility

__version__ = "1.0.0"