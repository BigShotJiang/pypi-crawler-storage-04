This is a Pyodide-compatible slim implementation for the [actual Narada Python SDK](https://github.com/NaradaAI/narada-python-sdk/narada), intended for internal use only.
