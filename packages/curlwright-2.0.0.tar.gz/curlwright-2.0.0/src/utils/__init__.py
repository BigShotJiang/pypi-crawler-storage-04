"""
Utilities module for CurlWright
"""