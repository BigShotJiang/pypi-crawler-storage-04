"""
Core module for CurlWright
"""