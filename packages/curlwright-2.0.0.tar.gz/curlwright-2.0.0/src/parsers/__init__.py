"""
Parsers module for CurlWright
"""