There is a new field named Analytic Account in the Manufacturing Order.

You can also navigate from the Analytic Account to the related Manufacturing Orders.
