This module links the manufacturing area with analytic management.

The Manufacturing Order analytic account is carried to the
journal items created when the MO is marked as Done.
