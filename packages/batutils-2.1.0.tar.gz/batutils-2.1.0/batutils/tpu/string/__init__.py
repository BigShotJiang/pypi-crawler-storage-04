from ._string import *
