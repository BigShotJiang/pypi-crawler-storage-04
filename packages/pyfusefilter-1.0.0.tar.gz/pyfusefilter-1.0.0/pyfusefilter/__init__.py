from pyfusefilter.pyfusefilter import Xor8, Xor16, Fuse8, Fuse16

VERSION = "1.0.0"
__all__ = ["Xor8", "Xor16", "Fuse8", "Fuse16"]
