import json
from datetime import datetime
import re
import sys
from typing import List, Optional, Union

import click
from loguru import logger
from rich.pretty import Pretty
from rich.table import Table
from rich.prompt import Confirm

from .util import (
    console,
    check,
    click_group,
    _validate_queue_priority,
    apply_nodegroup_and_queue_config,
)

from leptonai.config import (
    VALID_SHAPES,
    DEFAULT_TIMEOUT,
    DEFAULT_RESOURCE_SHAPE,
    ENV_VAR_REQUIRED,
)
from ..api.v2.client import APIClient
from ..api.v1.deployment import make_token_vars_from_config
from ..api.v1.photon import make_mounts_from_strings, make_env_vars_from_strings
from ..api.v2.workspace_record import WorkspaceRecord
from ..api.v1.types.common import Metadata, LeptonVisibility
from ..api.v1.types.deployment import (
    AutoScaler,
    HealthCheck,
    HealthCheckLiveness,
    LeptonDeployment,
    LeptonDeploymentUserSpec,
    LeptonContainer,
    ResourceRequirement,
    ScaleDown,
    ContainerPort,
    AutoscalerTargetThroughput,
    LeptonLog,
    DeploymentSchedulingPolicy,
    SchedulingToggle,
)
from ..api.v1.types.photon import PhotonDeploymentTemplate
from ..api.v1.types.ingress import AuthConfig


def _same_major_version(version_str_list: List[str]) -> bool:
    if len(version_str_list) < 2:
        return True

    def validate(v: str) -> bool:
        return bool(re.match(r"^\d+\.\d+$", v))

    if not all(validate(version_str) for version_str in version_str_list):
        return False

    version_major_list = [version.split(".")[0] for version in version_str_list]

    if not all(
        version_major == version_major_list[0] for version_major in version_major_list
    ):
        return False

    return True


def autoscale_flag_deprecation_warning(ctx, param, value):
    if value is not None:
        click.echo(
            f"""Warning: The '{param.name}' option will be deprecated in a future release. 
        Please consider using the new options for replica number and autoscale policy management: 
        '-r'
        '--replicas-static <replica_number>' 
        
        '-ad'  
        '--autoscale-down <replica_number>,<timeout>' 
         
        '-agu'
        '--autoscale-gpu-util <min_replica>,<max_replica>,<gpu-util-threshold>' 
        
        '-aq'
        '--autoscale-qpm <min_replica>,<max_replica>,<qpm-threshold>'
        
        please use lep endpoint create -h for more information.
        """,
            err=True,
        )
    return value


def validate_autoscale_options(ctx, param, value):
    replicas_static = ctx.params.get("replicas_static")
    autoscale_down = ctx.params.get("autoscale_down")
    autoscale_gpu_util = ctx.params.get("autoscale_gpu_util")
    autoscale_qpm = ctx.params.get("autoscale_qpm")
    no_traffic_timeout = ctx.params.get("no_traffic_timeout")
    target_gpu_utilization = ctx.params.get("target_gpu_utilization")
    max_replicas = ctx.params.get("max_replicas")
    min_replicas = ctx.params.get("min_replicas")

    num_new_options = sum(
        option is not None
        for option in [
            replicas_static,
            autoscale_down,
            autoscale_gpu_util,
            autoscale_qpm,
        ]
    )
    if num_new_options > 1:
        raise click.UsageError(
            "You cannot use --replicas-static, --autoscale-down, --autoscale-gpu-util,"
            " and autoscale-qpm options together. Please specify only one."
        )

    num_old_options = sum(
        option is not None
        for option in [
            no_traffic_timeout,
            target_gpu_utilization,
            max_replicas,
        ]
    )

    if num_new_options > 0 and (
        num_old_options >= 1 or (min_replicas is not None and min_replicas > 1)
    ):
        raise click.UsageError(
            """You cannot use deprecating autoscale options with new autoscale options.
            Please specify only one of the following:
            
            '-r'
            '--replicas-static <replica_number>' 
            
            '-ad'  
            '--autoscale-down <replica_number>,<timeout>' 
             
            '-agu'
            '--autoscale-gpu-util <min_replica>,<max_replica>,<gpu-util-threshold>' 
            
            '-aq'
            '--autoscale-qpm <min_replica>,<max_replica>,<qpm-threshold>'
            """
        )

    if param.name == "autoscale_down" and value:
        parts = value.split(",")
        if (
            len(parts) != 2
            or not parts[0].isdigit()
            or not (parts[1].endswith("s") or parts[1].isdigit())
        ):
            raise click.BadParameter(
                "Invalid format for --autoscale-down. Expected format:"
                " <replicas>,<timeout>s or <replicas>,<timeout>"
            )
        try:
            replicas = int(parts[0])
            timeout = int(parts[1].rstrip("s"))
            if replicas < 0 or timeout < 60:
                raise ValueError
        except ValueError:
            raise click.BadParameter(
                "Replicas and timeout should be positive integers and timeout should be"
                " at least 60 seconds."
            )

    if param.name == "autoscale_gpu_util" and value:
        parts = value.split(",")
        if len(parts) != 3 or not (
            parts[0].isdigit()
            and parts[1].isdigit()
            and (parts[2].rstrip("%").isdigit())
        ):
            raise click.BadParameter(
                "Invalid format for --autoscale-gpu-util. Expected format:"
                " <min_replica>,<max_replica>,<threshold>% or"
                " <min_replica>,<max_replica>,<threshold>"
            )
        try:
            min_replica = int(parts[0])
            max_replica = int(parts[1])
            threshold = int(parts[2].rstrip("%"))
            if min_replica < 0 or max_replica < 0 or not (0 < threshold <= 99):
                raise ValueError
        except ValueError:
            raise click.BadParameter(
                "Min_replica, max_replica should be positive integers and threshold"
                " should be between 1 and 99."
            )

    if param.name == "autoscale_qpm" and value:
        parts = value.split(",")
        if len(parts) != 3 or not (
            parts[0].isdigit() and parts[1].isdigit() and is_positive_number(parts[2])
        ):
            raise click.BadParameter(
                "Invalid format for --autoscale-qpm. Expected format:"
                " <min_replica>,<max_replica>,<threshold>"
            )
        try:
            min_replica = int(parts[0])
            max_replica = int(parts[1])
            threshold = float(parts[2])
            if min_replica < 0 or max_replica < 0 or threshold <= 0:
                raise ValueError
        except ValueError:
            raise click.BadParameter(
                "Min_replica and max_replica should be positive integers and threshold"
                " should be a positive number. Threshold should be greater than 0."
            )

    return value


def is_positive_number(value):
    try:
        num = float(value)
        return num > 0
    except ValueError:
        return False


def _normalize_replica_spread(ctx, param, value):
    if value is None:
        return None
    if value.lower() in ["required", "r"]:
        return "required"
    elif value.lower() in ["preferred", "p"]:
        return "preferred"
    else:
        raise click.BadParameter(
            f"Invalid replica spread value: {value}. "
            "Use 'required'/'r' or 'preferred'/'p'."
        )


def _parse_ip_whitelist(ip_whitelist_values):
    """
    Parse IP whitelist values, handling both comma-separated and individual values.

    Args:
        ip_whitelist_values: List of strings, each potentially containing comma-separated IPs

    Returns:
        List of individual IP addresses/CIDR ranges
    """
    if not ip_whitelist_values:
        return []

    parsed_ips = []
    for value in ip_whitelist_values:
        # Split by comma and strip whitespace
        ips = [ip.strip() for ip in value.split(",")]
        # Filter out empty strings
        ips = [ip for ip in ips if ip]
        parsed_ips.extend(ips)

    return parsed_ips


@click_group(hidden=True)
def deployment():
    """
    Manage endpoints (formerly called deployments) on the DGX Cloud Lepton.

    An endpoint is a running instance (previously referred to as a
    deployment). Endpoints are created with the `lep endpoint create` command and
    typically expose one or more HTTP routes that users can call, either via a
    RESTful API or through the Python client provided by `leptonai.client`.

    The endpoint commands let you list, manage, and remove endpoints on the
    DGX Cloud Lepton.
    """
    pass


def _print_deployments_table(
    deployments, dashboard_base_url: Optional[str] = None
) -> None:
    table = Table(
        title="Endpoints",
        show_lines=True,
        show_header=True,
    )
    table.add_column("Name / ID")
    table.add_column("Created At")
    table.add_column("State")
    table.add_column("User ID")
    table.add_column("Node Group")
    table.add_column("Replicas")
    table.add_column("Shape")

    shape_totals = {}

    def _is_active_state(state_str: str) -> bool:
        return state_str in {"Ready", "Starting", "Updating", "Scaling", "Deleting"}

    count = 0
    for d in deployments:
        if d.spec and getattr(d.spec, "is_pod", False):
            continue

        name = d.metadata.name if d.metadata else "-"
        dep_id = d.metadata.id_ if d.metadata else "-"

        created_ts = (
            datetime.fromtimestamp((d.metadata.created_at or 0) / 1000).strftime(
                "%Y-%m-%d\n%H:%M:%S"
            )
            if d.metadata and d.metadata.created_at
            else "N/A"
        )
        state = d.status.state.value if d.status and d.status.state else "-"
        owner = d.metadata.owner if d.metadata and d.metadata.owner else ""

        ng_list = []
        rr = d.spec.resource_requirement if d.spec else None
        if rr and rr.affinity and rr.affinity.allowed_dedicated_node_groups:
            ng_list = rr.affinity.allowed_dedicated_node_groups
        ng_str = "\n".join(ng_list).lower() if ng_list else ""

        desired = (
            d.status.autoscaler_status.desired_replicas
            if d.status
            and d.status.autoscaler_status
            and d.status.autoscaler_status.desired_replicas is not None
            else None
        )
        desired_disp = str(desired if desired is not None else 0)

        shape = rr.resource_shape if rr and rr.resource_shape else "-"

        dep_url = None
        if dashboard_base_url:
            dep_url = f"{dashboard_base_url}/compute/deployments/detail/{dep_id}/demo"
        name_id_cell = f"[bold #76b900]{name}[/]\n" + (
            f"[link={dep_url}][bright_black]{dep_id}[/][/link]"
            if dep_url
            else f"[bright_black]{dep_id}[/]"
        )

        table.add_row(
            name_id_cell,
            created_ts,
            f"{state}",
            owner or "",
            ng_str,
            desired_disp,
            shape,
        )

        # Utilization summary uses desired only
        workers = desired if desired is not None else 0
        if _is_active_state(state):
            shape_totals[shape] = shape_totals.get(shape, 0) + workers

        count += 1

    if count == 0:
        console.print(
            "No endpoints found. Use `lep endpoint create` to create endpoints."
        )
        return

    console.print(table)

    console.print(
        f"[bold]Resource Utilization Summary for above [cyan]{count}[/]"
        f" endpoint{'s' if count!=1 else ''} (Ready / Starting / Updating / Scaling /"
        " Deleting only):[/]"
    )
    for shape, total in sorted(
        shape_totals.items(), key=lambda kv: kv[1], reverse=True
    ):
        console.print(f"  [bright_black]{shape}[/] : [bold cyan]{total}[/]")
    console.print("\n")


# Visible alias group for deployment commands
@click_group()
def endpoint():
    """Manage endpoints (formerly called deployments) on the DGX Cloud Lepton."""
    pass


def _timeout_must_be_larger_than_60(unused_ctx, unused_param, x):
    if x is not None:
        autoscale_flag_deprecation_warning(unused_ctx, unused_param, x)
    if x is None or x == 0 or x >= 60:
        return x
    else:
        raise click.BadParameter("Timeout value must be larger than 60 seconds.")


def _get_ordered_photon_ids_or_none(
    name: str, public_photon: bool
) -> Union[List[str], None]:
    """Returns a list of photon ids for a given name, in the order newest to
    oldest. If no photon of such name exists, returns None.
    """

    client = APIClient()

    photons = client.photon.list_all(public_photon=public_photon)

    target_photons = [p for p in photons if p.name == name]  # type: ignore
    if len(target_photons) == 0:
        return None
    target_photons.sort(key=lambda p: p.created_at, reverse=True)  # type: ignore
    return [p.id_ for p in target_photons]  # type: ignore


def _get_most_recent_photon_id_or_none(name: str, public_photon: bool) -> Optional[str]:
    """Returns the most recent photon id for a given name. If no photon of such
    name exists, returns None.
    """
    photon_ids = _get_ordered_photon_ids_or_none(name, public_photon)
    return photon_ids[0] if photon_ids else None


def _create_workspace_token_secret_var_if_not_existing(client: APIClient):
    """
    Adds the workspace token as a secret environment variable.
    """
    from ..api.v1.types.secret import SecretItem

    secrets = client.secret.list_all()
    existing_names = {s.name for s in secrets}
    if "LEPTON_WORKSPACE_TOKEN" not in existing_names:
        current_ws = WorkspaceRecord.current()
        if current_ws is None:
            console.print(
                "Error: you are not logged in yet. Log into your workspace before"
                " using --include-workspace-token."
            )
            sys.exit(1)
        else:
            token = current_ws.auth_token
            # TODO: there woudln't be a case when token is empty, but we will add a check
            # here just in case.
            if token:
                client.secret.create(
                    [SecretItem(name="LEPTON_WORKSPACE_TOKEN", value=token)]
                )


@deployment.command()
@click.option(
    "--name", "-n", type=str, help="Name of the endpoint being created.", required=True
)
@click.option(
    "--file",
    "-f",
    type=click.Path(
        exists=False,
        file_okay=True,
        dir_okay=False,
        readable=True,
        resolve_path=True,
    ),
    help=(
        "If provided, load the endpoint spec from this JSON file before applying CLI"
        " overrides. The file can be obtained from the dashboard's UI → CLI → 'Use spec"
        " file', or by running: `lep endpoint get -i <endpoint_id> --path"
        " <download_path>`."
    ),
    required=False,
)
@click.option(
    "--photon", "-p", "photon_name", type=str, help="Name of the photon to run."
)
@click.option(
    "--photon-id",
    "-i",
    type=str,
    help=(
        "Specific version id of the photon to run. If not specified, we will run the"
        " most recent version of the photon."
    ),
)
@click.option("--container-image", type=str, help="Container image to run.")
@click.option(
    "--container-port",
    type=int,
    help=(
        "Guest OS port to listen to in the container. If not specified, default to"
        " 8080."
    ),
)
@click.option(
    "--container-command",
    type=str,
    help=(
        "Command to run in the container. Your command should listen to the port"
        " specified by --container-port."
    ),
)
@click.option(
    "--resource-shape",
    type=str,
    help="Resource shape for the endpoint. Available types are: '"
    + "', '".join(VALID_SHAPES)
    + "'.",
    default=None,
)
@click.option(
    "--min-replicas",
    type=int,
    help="(Will be deprecated soon) Minimum number of replicas.",
    default=1,
)
@click.option(
    "--max-replicas",
    type=int,
    help="(Will be deprecated) Maximum number of replicas.",
    default=None,
    callback=autoscale_flag_deprecation_warning,
)
@click.option(
    "--mount",
    help=(
        "Persistent storage to be mounted to the endpoint, in the format"
        " `STORAGE_PATH:MOUNT_PATH` or `STORAGE_PATH:MOUNT_PATH:MOUNT_FROM`."
    ),
    multiple=True,
)
@click.option(
    "--env",
    "-e",
    help="Environment variables to pass to the endpoint, in the format `NAME=VALUE`.",
    multiple=True,
)
@click.option(
    "--secret",
    "-s",
    help=(
        "Secrets to pass to the endpoint, in the format `NAME=SECRET_NAME`. If"
        " secret name is also the environment variable name, you can"
        " omit it and simply pass `SECRET_NAME`."
    ),
    multiple=True,
)
@click.option(
    "--public",
    is_flag=True,
    help=(
        "If specified, the endpoint will be accessible from any IP address. "
        "This is equivalent to --ip-whitelist with an empty list. "
        "Mutually exclusive with --ip-whitelist."
    ),
)
@click.option(
    "--ip-whitelist",
    help=(
        "IP addresses or CIDR ranges that are allowed to access the endpoint. "
        "Can be specified multiple times or as comma-separated values. "
        "Examples: --ip-whitelist 192.168.1.1,10.0.0.0/8 or "
        "--ip-whitelist 192.168.1.1 --ip-whitelist 10.0.0.0/8. "
        "Mutually exclusive with --public. This sets the IP allowlist in the "
        "deployment's authentication configuration. "
        "Note: --tokens are completely independent of IP access control."
    ),
    multiple=True,
)
@click.option(
    "--tokens",
    help=(
        "Additional tokens that can be used to access the endpoint. See docs for"
        " details on access control. These are completely independent of IP access"
        " control (--public and --ip-whitelist)."
    ),
    multiple=True,
)
@click.option(
    "--no-traffic-timeout",
    type=int,
    help=(
        "(Will be deprecated soon)"
        "If specified, the endpoint will be scaled down to 0 replicas after the"
        " specified number of seconds without traffic. Minimum is 60 seconds if set."
        " Note that actual timeout may be up to 30 seconds longer than the specified"
        " value."
    ),
    callback=_timeout_must_be_larger_than_60,
)
@click.option(
    "--target-gpu-utilization",
    type=int,
    help=(
        "(Will be deprecated soon)"
        "If min and max replicas are set, if the gpu utilization is higher than the"
        " target gpu utilization, autoscaler will scale up the replicas. If the gpu"
        " utilization is lower than the target gpu utilization, autoscaler will scale"
        " down the replicas. The value should be between 0 and 99."
    ),
    default=None,
    callback=autoscale_flag_deprecation_warning,
)
@click.option(
    "--initial-delay-seconds",
    type=int,
    help=(
        "If specified, the endpoint will allow the specified amount of seconds for"
        " the photon to initialize before it starts the service. Usually you should"
        " not need this. If you have a endpoint that takes a long time to initialize,"
        " set it to a longer value."
    ),
    default=None,
)
@click.option(
    "--include-workspace-token",
    is_flag=True,
    help=(
        "If specified, the workspace token will be included as an environment"
        " variable. This is used when the photon code uses Lepton SDK capabilities such"
        " as queue, KV, objectstore etc. Note that you should trust the code in the"
        " photon, as it will have access to the workspace token."
    ),
    default=False,
)
@click.option(
    "--rerun",
    is_flag=True,
    help=(
        "If specified, shutdown the endpoint of the same endpoint name and"
        " rerun it. Note that this may cause downtime of the photon if it is for"
        " production use, so use with caution. In a production environment, you"
        " should do photon create, push, and `lep endpoint update` instead."
    ),
    default=False,
)
@click.option(
    "--public-photon",
    is_flag=True,
    help=(
        "If specified, get the photon from the public photon registry. This is only"
        " supported for remote execution."
    ),
    default=False,
)
@click.option(
    "--image-pull-secrets",
    type=str,
    help="Secrets to use for pulling images.",
    multiple=True,
)
@click.option(
    "--node-group",
    "-ng",
    "node_groups",
    help=(
        "Node group for the endpoint. If not set, use on-demand resources. You can"
        " repeat this flag multiple times to choose multiple node groups. Multiple node"
        " group option is currently not supported but coming soon for enterprise users."
        " Only the first node group will be set if you input multiple node groups at"
        " this time."
    ),
    type=str,
    multiple=True,
)
@click.option(
    "--visibility",
    type=str,
    help=(
        "Visibility of the endpoint. Can be 'public' or 'private'. If private, the"
        " endpoint will only be viewable by the creator and workspace admin."
    ),
)
@click.option(
    "--replicas-static",
    "-r",
    "-replicas",
    type=int,
    default=None,
    help="""
                Use this option if you want a fixed number of replicas and want to turn off autoscaling.
                For example, to set a fixed number of replicas to 2, you can use: 
                --replicas-static 2  or
                -r 2
            """,
    callback=validate_autoscale_options,
)
@click.option(
    "--autoscale-down",
    "-ad",
    type=str,
    default=None,
    help="""
                Use this option if you want to have replicas but scale down after a specified time of no traffic.
                For example, to set 2 replicas and scale down after 3600 seconds of no traffic,
                use: --autoscale-down 2,3600s or --autoscale-down 2,3600
                (Note: Do not include spaces around the comma.)
            """,
    callback=validate_autoscale_options,
)
@click.option(
    "--autoscale-gpu-util",
    "-agu",
    type=str,
    default=None,
    help="""
                Use this option to set a threshold for GPU utilization and enable the system to scale between
                a minimum and maximum number of replicas. For example,
                to scale between 1 (min_replica) and 3 (max_replica) with a 50% threshold,
                use: --autoscale-gpu-util 1,3,50% or --autoscale-gpu-util 1,3,50
                (Note: Do not include spaces around the comma.)

                If the GPU utilization is higher than the target GPU utilization,
                the autoscaler will scale up the replicas.
                If the GPU utilization is lower than the target GPU utilization,
                the autoscaler will scale down the replicas.
                The threshold value should be between 0 and 99.
                
            """,
    callback=validate_autoscale_options,
)
@click.option(
    "--autoscale-qpm",
    "-aq",
    type=str,
    default=None,
    help="""
                Use this option to set a threshold for QPM and enable the system to scale between
                a minimum and maximum number of replicas. For example,
                to scale between 1 (min_replica) and 3 (max_replica) with a 2.5 QPM,
                use: --autoscale-qpm 1,3,2.5
                (Note: Do not include spaces around the comma.)

                This sets up autoscaling based on queries per minute, 
                scaling between 1 and 3 replicas when QPM per replica exceeds 2.5.
            """,
    callback=validate_autoscale_options,
)
@click.option(
    "--log-collection",
    "-lg",
    type=bool,
    help=(
        "Enable or disable log collection (true/false). If not provided, the workspace"
        " setting will be used."
    ),
)
@click.option(
    "--node-id",
    "-ni",
    "node_ids",
    help=(
        "Node for the endpoint. You can repeat this flag multiple times to choose"
        " multiple nodes. Please specify the node group when you are using this option"
    ),
    type=str,
    multiple=True,
)
# queue / preempt options (matching job.py style)
@click.option(
    "--queue-priority",
    "-qp",
    "queue_priority",
    callback=_validate_queue_priority,
    default=None,
    help="Set the priority for this endpoint (dedicated node groups only).",
)
@click.option(
    "--can-be-preempted",
    "-cbp",
    is_flag=True,
    default=None,
    help="Allow this endpoint to be preempted by higher priority workloads.",
)
@click.option(
    "--can-preempt",
    "-cp",
    is_flag=True,
    default=None,
    help="Allow this endpoint to preempt lower priority workloads.",
)
@click.option(
    "--shared-memory-size",
    type=int,
    help="Specify the shared memory size for this endpoint, in MiB.",
)
@click.option(
    "--with-reservation",
    type=str,
    help=(
        "Assign the endpoint to a specific reserved compute resource using a"
        " reservation ID (only applicable to dedicated node groups)."
    ),
)
@click.option(
    "--allow-burst-to-other-reservation",
    is_flag=True,
    default=False,
    help=(
        "If set, the endpoint can temporarily use free resources from nodes reserved by"
        " other reservations. Be aware that when a new workload bound to those"
        " reservations starts, your endpoint may be evicted."
    ),
)
@click.option(
    "--replica-spread",
    callback=_normalize_replica_spread,
    help=(
        "Controls how endpoint replicas are distributed across different nodes to"
        " improve availability, but it may lead to resource fragmentation.\n\nPreferred"
        " (p): Attempts to spread replicas across different nodes when"
        " possible.\nRequired (r): Enforces strict replica spreading where each replica"
        " must be scheduled on a different node. Replicas cannot start if there are not"
        " enough nodes.\n\nUsage examples:\n  --replica-spread required/r   (strict)\n "
        " --replica-spread preferred/p  (soft)\n"
    ),
    default=None,
)
def create(
    name,
    file,
    photon_name,
    photon_id,
    container_image,
    container_port,
    container_command,
    resource_shape,
    min_replicas,
    max_replicas,
    mount,
    env,
    secret,
    public,
    ip_whitelist,
    tokens,
    no_traffic_timeout,
    target_gpu_utilization,
    initial_delay_seconds,
    include_workspace_token,
    rerun,
    public_photon,
    image_pull_secrets,
    node_groups,
    visibility,
    replicas_static,
    autoscale_down,
    autoscale_gpu_util,
    autoscale_qpm,
    log_collection,
    node_ids,
    queue_priority,
    can_be_preempted,
    can_preempt,
    shared_memory_size,
    with_reservation,
    allow_burst_to_other_reservation,
    replica_spread,
):
    """
    Creates an endpoint from either a photon or container image.
    """
    client = APIClient()

    # Validate that public and ip-whitelist are mutually exclusive
    if public and ip_whitelist:
        console.print(
            "[red]Error[/]: Cannot specify both --public and --ip-whitelist. "
            "Use --public for public access or --ip-whitelist for restricted access. "
            "Note that --tokens can be used with either option."
        )
        sys.exit(1)

    # Load spec from file if provided
    if file:
        try:
            with open(file, "r") as f:
                content = f.read()
                spec = LeptonDeploymentUserSpec.model_validate_json(content)
        except Exception as e:
            console.print(f"Cannot load endpoint spec from file [red]{file}[/]: {e}")
            sys.exit(1)
    else:
        spec = LeptonDeploymentUserSpec()

    existing_deployments = client.deployment.list_all()
    if name in [d.metadata.name for d in existing_deployments]:
        if rerun:
            console.print(
                f"Endpoint [green]{name}[/] already exists. Shutting down the"
                " existing endpoint and rerunning."
            )
            client.deployment.delete(name)
        else:
            console.print(
                f"Endpoint [green]{name}[/] already exists. Use `lep endpoint"
                f" update -n {name}` to update the endpoint, or add `--rerun` to"
                " shutdown the existing endpoint and rerun it."
            )
            sys.exit(1)

    if (
        file
        and spec.container is not None
        and (photon_name is not None or photon_id is not None)
    ):
        console.print(
            "[red]Error[/]: Container details are already present in the spec file; you"
            " cannot additionally specify --photon or --photon-id."
        )
        sys.exit(1)

    if (
        file
        and spec.photon_id is not None
        and (container_image is not None or container_command is not None)
    ):
        console.print(
            "[red]Error[/]: The spec file already references a photon; you cannot also"
            " provide --container-image or --container-command."
        )
        sys.exit(1)

    # First, check whether the input is photon or container. We will prioritize using
    # photon if both are specified.
    if photon_name is not None or photon_id is not None:
        # We will use photon.
        if container_image is not None or container_command is not None:
            console.print(
                "Warning: both photon and container image are specified. We will use"
                " the photon."
            )
        if photon_id is None:
            # look for the latest photon with the given name.
            photon_id = _get_most_recent_photon_id_or_none(photon_name, public_photon)
            if not photon_id:
                console.print(
                    f"Photon [red]{name}[/] does not exist in the workspace. Did"
                    " you forget to push the photon?",
                )
                sys.exit(1)
            console.print(
                f"Running the most recent version of [green]{name}[/]: {photon_id}"
            )
        else:
            console.print(f"Running the specified version: [green]{photon_id}[/]")
        spec.photon_id = photon_id
        spec.photon_namespace = "public" if public_photon else "private"

        # get deployment template
        photon = client.photon.get(photon_id, public_photon=public_photon)  # type: ignore
        deployment_template = photon.deployment_template
    elif container_image is not None or container_command is not None:
        # We will use container.
        if container_image is None:
            console.print(
                "Error: container image and command must be specified together."
            )
            sys.exit(1)

        wrapped_cmd = (
            ["/bin/bash", "-c", container_command] if container_command else None
        )
        spec.container = LeptonContainer(
            image=container_image,
            command=wrapped_cmd,
        )
        if container_port:
            spec.container.ports = [ContainerPort(container_port=container_port)]
        # container based deployment won't have the deployment template as photons do.
        # So we will simply create an empty one.
    elif spec.photon_id is None and spec.container is None:
        # No photon_id, photon_name, container_image, or container_command
        console.print("""
            You have not provided a photon_name, photon_id, or container image.
            Please use one of the following options:
            -p <photon_name>
            -i <photon_id>
            --container-image <container_image> and --container-command <container_command>
            to specify a photon or container image.
            """)
        sys.exit(1)

    if spec.container is not None:
        deployment_template = PhotonDeploymentTemplate()

    # Detect if the loaded spec already contains autoscaler settings
    spec_has_autoscale = spec.auto_scaler is not None and (
        spec.auto_scaler.target_gpu_utilization_percentage is not None
        or spec.auto_scaler.target_throughput is not None
        or (
            spec.auto_scaler.scale_down is not None
            and spec.auto_scaler.scale_down.no_traffic_timeout is not None
        )
    )

    # default timeout (only if user passed nothing AND spec has no autoscale)
    if (
        no_traffic_timeout is None
        and DEFAULT_TIMEOUT
        and target_gpu_utilization is None
        and replicas_static is None
        and autoscale_down is None
        and autoscale_gpu_util is None
        and autoscale_qpm is None
        and not spec_has_autoscale
    ):
        console.print(
            "\nLepton is currently set to use a default timeout of [green]1 hour[/]."
            " When there is no traffic for more than an hour, the endpoint will"
            " automatically scale down to zero. Use --no-traffic-timeout 0 to disable,"
            " or set LEPTON_DEFAULT_TIMEOUT=false to turn off this default.\n"
        )
        no_traffic_timeout = DEFAULT_TIMEOUT

    threshold = None

    if replicas_static:
        min_replicas = replicas_static
        max_replicas = replicas_static
        no_traffic_timeout = None

    if autoscale_down:
        parts = autoscale_down.split(",")
        replicas = int(parts[0])
        timeout = int(parts[1].rstrip("s"))
        min_replicas = replicas
        max_replicas = replicas
        no_traffic_timeout = timeout

    if autoscale_gpu_util:
        parts = autoscale_gpu_util.split(",")
        min_replicas = int(parts[0])
        max_replicas = int(parts[1])
        target_gpu_utilization = int(parts[2].rstrip("%"))

    if autoscale_qpm:
        parts = autoscale_qpm.split(",")
        min_replicas = int(parts[0])
        max_replicas = int(parts[1])
        threshold = float(parts[2])

    # resources

    # Ensure existing resource_requirement is preserved when loading from file.
    if spec.resource_requirement is None:
        spec.resource_requirement = ResourceRequirement(
            resource_shape=resource_shape
            or (deployment_template.resource_shape if deployment_template else None)
            or DEFAULT_RESOURCE_SHAPE,
            min_replicas=min_replicas,
            max_replicas=max_replicas,
        )
    else:
        # Only update fields that are explicitly overridden via CLI
        if resource_shape or (
            deployment_template.resource_shape if deployment_template else None
        ):
            spec.resource_requirement.resource_shape = (
                resource_shape
                or (deployment_template.resource_shape if deployment_template else None)
                or spec.resource_requirement.resource_shape
                or DEFAULT_RESOURCE_SHAPE
            )
        if min_replicas is not None:
            spec.resource_requirement.min_replicas = min_replicas
        if max_replicas is not None:
            spec.resource_requirement.max_replicas = max_replicas

    if shared_memory_size is not None:
        spec.resource_requirement.shared_memory_size = shared_memory_size

    # Apply shared node group / queue / reservation config
    try:
        apply_nodegroup_and_queue_config(
            spec=spec,
            node_groups=node_groups,
            node_ids=node_ids,
            queue_priority=queue_priority,
            can_be_preempted=can_be_preempted,
            can_preempt=can_preempt,
            with_reservation=with_reservation,
            allow_burst=allow_burst_to_other_reservation,
        )
    except ValueError as e:
        console.print(f"[red]{e}[/]")
        sys.exit(1)

    # include workspace token
    secret = list(secret)  # to convert secret from tuple to list
    if include_workspace_token:
        console.print("Including the workspace token for the photon execution.")
        _create_workspace_token_secret_var_if_not_existing(client)
        if "LEPTON_WORKSPACE_TOKEN" not in secret:
            secret += [
                "LEPTON_WORKSPACE_TOKEN",
            ]

    try:
        logger.trace(f"deployment_template:\n{deployment_template}")
        template_envs = deployment_template.env or {}
        env_list = list(env) or []
        secret_list = list(secret) or []
        mount_list = list(mount) or []
        for k, v in template_envs.items():
            if v == ENV_VAR_REQUIRED:
                if not any(s.startswith(k + "=") for s in (env or [])):
                    console.print(
                        f"This deployment requires env var {k}, but it's missing."
                        f" Please specify it with --env {k}=YOUR_VALUE. Otherwise,"
                        " the deployment may fail."
                    )
            else:
                if not any(s.startswith(k + "=") for s in env_list):
                    # Adding default env variable if not specified.
                    env_list.append(f"{k}={v}")
        template_secrets = deployment_template.secret or []
        for k in template_secrets:
            if k not in secret_list:
                console.print(
                    f"This deployment requires secret {k}, but it's missing. Please"
                    f" set the secret, and specify it with --secret {k}. Otherwise,"
                    " the deployment may fail."
                )

        if env_list or secret_list or not file:
            # CLI args provided or no file loaded - use CLI args
            spec.envs = make_env_vars_from_strings(env_list, secret_list)
        # else: preserve existing spec.envs from loaded file

        if mount_list or not file:
            # CLI args provided or no file loaded - use CLI args
            spec.mounts = make_mounts_from_strings(mount_list)
        # else: preserve existing spec.mounts from loaded file

        if tokens or not file:
            spec.api_tokens = make_token_vars_from_config(public, tokens)

        # Set IP access control in auth_config (independent of tokens)
        if public or ip_whitelist:
            if spec.auth_config is None:
                spec.auth_config = AuthConfig()

            if public:
                # Public means accessible from any IP (no IP restrictions)
                spec.auth_config.ip_allowlist = []
            elif ip_whitelist:
                # IP whitelist means only accessible from specified IPs
                parsed_ips = _parse_ip_whitelist(ip_whitelist)
                spec.auth_config.ip_allowlist = parsed_ips

        if image_pull_secrets or not file:
            spec.image_pull_secrets = list(image_pull_secrets)
        # Only overwrite auto_scaler if user provided any autoscale-related flag/arg
        if any([
            no_traffic_timeout is not None,
            target_gpu_utilization is not None,
            threshold is not None,
        ]):
            spec.auto_scaler = AutoScaler(
                scale_down=(
                    ScaleDown(no_traffic_timeout=no_traffic_timeout)
                    if no_traffic_timeout is not None
                    else None
                ),
                target_gpu_utilization_percentage=target_gpu_utilization,
                target_throughput=(
                    AutoscalerTargetThroughput(qpm=threshold) if threshold else None
                ),
            )

        if initial_delay_seconds is not None:
            spec.health = HealthCheck(
                liveness=(
                    HealthCheckLiveness(initial_delay_seconds=initial_delay_seconds)
                )
            )

        # Scheduling policy: replica spread
        if replica_spread is not None:
            toggle = (
                SchedulingToggle.Required
                if replica_spread.lower() == "required"
                else SchedulingToggle.Preferred
            )
            spec.scheduling_policy = DeploymentSchedulingPolicy(replica_spread=toggle)

        if log_collection is not None:
            spec.log = LeptonLog(enable_collection=log_collection)

    except ValueError as e:
        console.print(
            f"Error encountered while processing endpoint configs:\n[red]{e}[/]."
        )
        console.print("Failed to launch endpoint.")
        sys.exit(1)
    name = name if name else (photon_name or photon_id)
    lepton_deployment = LeptonDeployment(
        metadata=Metadata(
            id=name,
            name=name,
            visibility=LeptonVisibility(visibility) if visibility else None,
        ),
        spec=spec,
    )
    logger.trace(json.dumps(lepton_deployment.model_dump(), indent=2))
    client.deployment.create(lepton_deployment)
    console.print(
        "🎉 [green]Endpoint Created Successfully![/]\n"
        f"Name: [blue]{name}[/]\n"
        f"Use `lep endpoint status -n {name}` to check the status."
    )


@deployment.command(name="list")
@click.option(
    "--name",
    "-n",
    help=(
        "Filter endpoints by name (case-insensitive substring). Can be specified"
        " multiple times."
    ),
    type=str,
    required=False,
    multiple=True,
)
def list_command(name):
    """
    Lists all endpoints in the current workspace.
    """

    client = APIClient()
    deployments = client.deployment.list_all()
    if name:
        lowered = [x.lower() for x in name]
        deployments = [
            d
            for d in deployments
            if d.metadata
            and d.metadata.name
            and any(n in d.metadata.name.lower() for n in lowered)
        ]
    _print_deployments_table(
        deployments, dashboard_base_url=client.get_dashboard_base_url()
    )


@deployment.command()
@click.option("--name", "-n", help="The endpoint name to restart.", required=True)
def restart(name):
    """
    Restarts an endpoint.
    """
    client = APIClient()
    client.deployment.restart(name)
    console.print(f"Endpoint [green]{name}[/] restart triggered successfully.")


@deployment.command()
@click.option("--name", "-n", help="The endpoint name to remove.", required=True)
def remove(name):
    """
    Removes an endpoint.
    """
    client = APIClient()
    client.deployment.delete(name)
    console.print(f"Endpoint [green]{name}[/] deleted successfully.")


@deployment.command()
@click.option("--name", "-n", help="The endpoint name to get status.", required=True)
@click.option(
    "--show-tokens",
    "-t",
    is_flag=True,
    help=(
        "Show tokens for the endpoint. Use with caution as this displays the tokens"
        " in plain text, and may be visible to others if you log the output."
    ),
)
@click.option(
    "--detail", "-d", is_flag=True, default=False, help="Show the endpoint detail"
)
def status(name, show_tokens, detail):
    """
    Gets the status of an endpoint.
    """
    check(name, "Endpoint name not specified. Use `lep endpoint status -n <name>`.")

    client = APIClient()

    dep_info = client.deployment.get(name)

    # TODO: print a cleaner dep info.
    creation_time = datetime.fromtimestamp(
        dep_info.metadata.created_at / 1000  # type: ignore
    ).strftime("%Y-%m-%d %H:%M:%S")

    state = dep_info.status.state
    if state in ("Running", "Ready"):
        state = f"[green]{state}[/]"
    else:
        state = f"[yellow]{state}[/]"
    console.print(f"Time now:   {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    console.print(f"Created at: {creation_time}")

    if dep_info.spec.photon_id is not None:
        photon_id = dep_info.spec.photon_id
    else:
        photon_id = (
            (dep_info.spec.container.image or "unknow")
            if dep_info.spec.container
            else "unknow"
        )

    if dep_info.metadata.semantic_version:
        console.print("Version:   ", dep_info.metadata.semantic_version)

    console.print("Photon ID: ", photon_id)

    console.print(f"State:      {state}")

    resource_requirement = dep_info.spec.resource_requirement

    if resource_requirement and resource_requirement.max_replicas:
        console.print(
            f"Replicas:   {resource_requirement.min_replicas}-"
            f"{resource_requirement.max_replicas}"
        )

    autoscaler = dep_info.spec.auto_scaler

    if autoscaler:
        timeout = (
            autoscaler.scale_down.no_traffic_timeout if autoscaler.scale_down else None
        )
        if timeout:
            console.print(f"Timeout(s): {timeout}")
        target_gpu_utilization_percentage = autoscaler.target_gpu_utilization_percentage
        if target_gpu_utilization_percentage:
            console.print(f"Target GPU: {target_gpu_utilization_percentage}%")

    # Note: Web UI functionality is temporarily removed to reduce workspace URL dependency
    # This may be restored in the future if we implement a more flexible URL handling mechanism
    # if workspace_id:
    #     web_url = LEPTON_DEPLOYMENT_URL.format(
    #         workspace_id=workspace_id, deployment_name=name
    #     )
    #     console.print(f"Web UI:     {web_url}")

    # Note: endpoint is not quite often used right now, so we will hide it for now.
    # console.print(f"Endpoint:   {dep_info['status']['endpoint']['external_endpoint']}")
    console.print(f"Is Public:  {'No' if dep_info.spec.api_tokens else 'Yes'}")

    if show_tokens and dep_info.spec.api_tokens:

        def stringfy_token(x):
            return x.value or f"[{x.value_from.token_name_ref}]"

        console.print(f"Tokens:     {stringfy_token(dep_info.spec.api_tokens[0])}")
        for token in dep_info.spec.api_tokens[1:]:
            console.print(f"            {stringfy_token(token)}")

    console.print("Replicas List:")

    reading_issue_root = client.deployment.get_readiness(name).root
    # Print a table of readiness information.
    table = Table(show_lines=False)
    table.add_column("replica id")
    table.add_column("status")
    table.add_column("message")
    ready_count = 0
    for id, value in reading_issue_root.items():
        reason = value[0].reason
        message = value[0].message
        # Do we need to display red?
        if reason == "Ready":
            reason = f"[green]{reason}[/]"
            ready_count += 1
        else:
            reason = f"[yellow]{reason}[/]"
        if message == "":
            message = "(empty)"
        table.add_row(id, reason, message)
    console.print(table)
    console.print(
        f"[green]{ready_count}[/] out of {len(reading_issue_root)} replicas ready."
    )

    deployment_terminations_root = client.deployment.get_termination(name).root

    if len(deployment_terminations_root):
        console.print("There are earlier terminations. Detailed Info:")
        table = Table(show_lines=False)
        table.add_column("replica id")
        table.add_column("start/end time")
        table.add_column("reason (code)")
        table.add_column("message")
        for id, event_list in deployment_terminations_root.items():
            for event in event_list:
                start_time = datetime.fromtimestamp(event.started_at).strftime(
                    "%Y-%m-%d %H:%M:%S"
                )
                end_time = datetime.fromtimestamp(event.finished_at).strftime(
                    "%Y-%m-%d %H:%M:%S"
                )
                code = event.exit_code
                reason = event.reason
                message = event.message if event.message else "(empty)"
                table.add_row(
                    id,
                    f"{start_time}\n{end_time}",
                    f"[yellow]{reason} ({code})[/]",
                    message,
                )
        console.print(table)
    if detail:
        console.print(Pretty(dep_info.model_dump()))


@deployment.command()
@click.option("--name", "-n", help="The endpoint name to get log.", required=True)
@click.option("--replica", "-r", help="The replica name to get log.", default=None)
def log(name, replica):
    """
    Gets the log of an endpoint. If `replica` is not specified, the first replica
    is selected. Otherwise, the log of the specified replica is shown. To get the
    list of replicas, use `lep endpoint status`.
    """
    client = APIClient()

    if not replica:
        # obtain replica information, and then select the first one.
        console.print(
            f"Replica name not specified for [yellow]{name}[/]. Selecting the first"
            " replica."
        )

        replicas = client.deployment.get_replicas(name)
        check(len(replicas) > 0, f"No replicas found for [red]{name}[/].")
        replica = replicas[0].metadata.id_
        console.print(f"Selected replica [green]{replica}[/].")
    else:
        console.print(f"Showing log for replica [green]{replica}[/].")
    stream_or_err = client.deployment.get_log(name_or_deployment=name, replica=replica)  # type: ignore
    # Print the log as a continuous stream until the user presses Ctrl-C.
    try:
        for chunk in stream_or_err:
            console.print(chunk, end="")
    except KeyboardInterrupt:
        console.print("Disconnected.")
    except Exception:
        console.print("Connection stopped.")
        return
    else:
        console.print(
            "End of log. It seems that the endpoint has not started, or already"
            " finished."
        )
        console.print(
            f"Use `lep endpoint status -n {name}` to check the status of the endpoint."
        )


@deployment.command()
@click.option("--name", "-n", help="The endpoint name to update.", required=True)
@click.option(
    "--id",
    "-i",
    help="The new photon id to update to. Use `latest` for the latest id.",
    default=None,
)
@click.option(
    "--min-replicas",
    help=(
        "Number of replicas to update to. Pass `0` to scale the number"
        " of replicas to zero, in which case the deployment status page"
        " will show the endpoint to be `not ready` until you scale it"
        " back with a positive number of replicas."
    ),
    type=int,
    default=None,
)
@click.option(
    "--resource-shape",
    help="Resource shape for the pod. Available types are: '"
    + "', '".join(VALID_SHAPES)
    + "'.",
    default=None,
)
@click.option(
    "--public/--no-public",
    is_flag=True,
    default=None,
    help=(
        "If --public is specified, the endpoint will be made public. If --no-public"
        " is specified, the endpoint will be made non-public, with access tokens"
        " being the workspace token and the tokens specified by --tokens. If neither is"
        " specified, no change will be made to the access control of the endpoint."
    ),
)
@click.option(
    "--ip-whitelist",
    help=(
        "IP addresses or CIDR ranges that are allowed to access the endpoint. "
        "Can be specified multiple times or as comma-separated values. "
        "Examples: --ip-whitelist 192.168.1.1,10.0.0.0/8 or "
        "--ip-whitelist 192.168.1.1 --ip-whitelist 10.0.0.0/8. "
        "Mutually exclusive with --public. This sets the IP allowlist in the "
        "deployment's authentication configuration."
    ),
    multiple=True,
)
@click.option(
    "--tokens",
    help=(
        "Access tokens that can be used to access the endpoint. See docs for"
        " details on access control. If no tokens is specified, we will not change the"
        " tokens of the endpoint. If you want to remove all additional tokens, use"
        "--remove-tokens."
    ),
    multiple=True,
)
@click.option(
    "--remove-tokens",
    is_flag=True,
    default=False,
    help=(
        "If specified, all additional tokens will be removed, and the endpoint will"
        " be either public (if --public) is specified, or only accessible with the"
        " workspace token (if --public is not specified)."
    ),
)
@click.option(
    "--visibility",
    type=str,
    help=(
        "Visibility of the endpoint. Can be 'public' or 'private'. If private, the"
        " endpoint will only be viewable by the creator and workspace admin."
    ),
)
@click.option(
    "--replicas-static",
    "-r",
    "-replicas",
    type=int,
    default=None,
    help="""
                Use this option if you want a fixed number of replicas and want to turn off autoscaling.
                For example, to set a fixed number of replicas to 2, you can use: 
                --replicas-static 2  or
                -r 2
            """,
    callback=validate_autoscale_options,
)
@click.option(
    "--autoscale-down",
    "-ad",
    type=str,
    default=None,
    help="""
                Use this option if you want to have replicas but scale down after a specified time of no traffic.
                For example, to set 2 replicas and scale down after 3600 seconds of no traffic,
                use: --autoscale-down 2,3600s or --autoscale-down 2,3600
                (Note: Do not include spaces around the comma.)
            """,
    callback=validate_autoscale_options,
)
@click.option(
    "--autoscale-gpu-util",
    "-agu",
    type=str,
    default=None,
    help="""
                Use this option to set a threshold for GPU utilization and enable the system to scale between
                a minimum and maximum number of replicas. For example,
                to scale between 1 (min_replica) and 3 (max_replica) with a 50% threshold,
                use: --autoscale-gpu-util 1,3,50% or --autoscale-gpu-util 1,3,50
                (Note: Do not include spaces around the comma.)

                If the GPU utilization is higher than the target GPU utilization,
                the autoscaler will scale up the replicas.
                If the GPU utilization is lower than the target GPU utilization,
                the autoscaler will scale down the replicas.
                The threshold value should be between 0 and 99.

            """,
    callback=validate_autoscale_options,
)
@click.option(
    "--autoscale-qpm",
    "-aq",
    type=str,
    default=None,
    help="""
                Use this option to set a threshold for QPM and enable the system to scale between
                a minimum and maximum number of replicas. For example,
                to scale between 1 (min_replica) and 3 (max_replica) with a 2.5 QPM,
                use: --autoscale-qpm 1,3,2.5
                (Note: Do not include spaces around the comma.)

                This sets up autoscaling based on queries per minute,
                scaling between 1 and 3 replicas when QPM per replica exceeds 2.5. 
            """,
    callback=validate_autoscale_options,
)
@click.option(
    "--log-collection",
    "-lg",
    type=bool,
    help=(
        "Enable or disable log collection (true/false). If not provided, the workspace"
        " setting will be used."
    ),
)
@click.option(
    "--shared-memory-size",
    type=int,
    default=None,
    help="Update the shared memory size for this endpoint, in MiB.",
)
@click.option(
    "--replica-spread",
    callback=_normalize_replica_spread,
    help=(
        "Controls how endpoint replicas are distributed across different nodes to"
        " improve availability, but it may lead to resource fragmentation.\n\nPreferred"
        " (p): Attempts to spread replicas across different nodes when"
        " possible.\nRequired (r): Enforces strict replica spreading where each replica"
        " must be scheduled on a different node. Replicas cannot start if there are not"
        " enough nodes.\n\nUsage examples:\n  --replica-spread required/r   (strict)\n "
        " --replica-spread preferred/p  (soft)\n"
    ),
    default=None,
)
def update(
    name,
    id,
    min_replicas,
    resource_shape,
    public,
    ip_whitelist,
    tokens,
    remove_tokens,
    visibility,
    replicas_static,
    autoscale_down,
    autoscale_gpu_util,
    autoscale_qpm,
    log_collection,
    shared_memory_size,
    replica_spread,
):
    """
    Updates an endpoint. Note that for all the update options, changes are made
    as replacements, and not incrementals. For example, if you specify `--tokens`,
    old tokens are replaced by the new set of tokens.
    """

    client = APIClient()
    lepton_deployment = client.deployment.get(name)

    # Validate that public and ip-whitelist are mutually exclusive
    if public and ip_whitelist:
        console.print(
            "[red]Error[/]: Cannot specify both --public and --ip-whitelist. "
            "Use --public for public access or --ip-whitelist for restricted access. "
            "Note that --tokens can be used with either option."
        )
        sys.exit(1)

    if id == "latest":
        current_photon_id = lepton_deployment.spec.photon_id

        public_photon = (
            lepton_deployment.spec.photon_namespace or "private"
        ) == "public"

        photons = client.photon.list_all(public_photon)

        for photon in photons:
            if photon.id_ == current_photon_id:
                current_photon_name = photon.name
                break
        else:
            console.print(
                f"Cannot find current photon ([red]{current_photon_id}[/]) in workspace"
                f" [red]{WorkspaceRecord.get_current_workspace_id()}[/]."
            )
            sys.exit(1)
        records = [
            (photon.name, photon.model, photon.id_, photon.created_at)
            for photon in photons
            if photon.name == current_photon_name
        ]
        id = sorted(records, key=lambda x: x[3])[-1][2]  # type: ignore
        console.print(f"Updating to latest photon id [green]{id}[/].")
    if remove_tokens:
        # [] means removing all tokens
        tokens = []
    elif len(tokens) == 0:
        # None means no change
        tokens = None

    autoscaler_flag = (
        replicas_static is not None
        or autoscale_down is not None
        or autoscale_gpu_util is not None
        or autoscale_qpm is not None
    )

    temp_auto_scaler = None
    max_replicas = None
    if autoscaler_flag:
        target_gpu_utilization = 0
        no_traffic_timeout = 0
        threshold = 0
        if replicas_static is not None:
            min_replicas = replicas_static
            max_replicas = replicas_static

        if autoscale_down:
            parts = autoscale_down.split(",")
            replicas = int(parts[0])
            timeout = int(parts[1].rstrip("s"))
            min_replicas = replicas
            max_replicas = replicas
            no_traffic_timeout = timeout

        if autoscale_gpu_util:
            parts = autoscale_gpu_util.split(",")
            min_replicas = int(parts[0])
            max_replicas = int(parts[1])
            target_gpu_utilization = int(parts[2].rstrip("%"))

        if autoscale_qpm:
            parts = autoscale_qpm.split(",")
            min_replicas = int(parts[0])
            max_replicas = int(parts[1])
            threshold = float(parts[2])

        temp_auto_scaler = AutoScaler(
            scale_down=(
                ScaleDown(no_traffic_timeout=no_traffic_timeout)
                if no_traffic_timeout is not None
                else None
            ),
            target_gpu_utilization_percentage=(
                target_gpu_utilization if target_gpu_utilization is not None else None
            ),
            target_throughput=(
                AutoscalerTargetThroughput(qpm=threshold)
                if threshold is not None
                else None
            ),
        )

    update_resource_requirement_flag = any(
        x is not None
        for x in (min_replicas, max_replicas, resource_shape, shared_memory_size)
    )
    lepton_deployment_spec = LeptonDeploymentUserSpec(
        photon_id=id,
        resource_requirement=(
            ResourceRequirement(
                min_replicas=min_replicas,
                max_replicas=max_replicas,
                resource_shape=resource_shape,
                shared_memory_size=shared_memory_size,
            )
            if update_resource_requirement_flag
            else None
        ),
        api_tokens=make_token_vars_from_config(
            is_public=public,
            tokens=tokens,
        ),
        auto_scaler=temp_auto_scaler,
    )

    if replica_spread is not None:
        toggle = (
            SchedulingToggle.Required
            if replica_spread.lower() == "required"
            else SchedulingToggle.Preferred
        )
        lepton_deployment_spec.scheduling_policy = DeploymentSchedulingPolicy(
            replica_spread=toggle
        )

    if log_collection is not None:
        lepton_deployment_spec.log = LeptonLog(enable_collection=log_collection)

    # Set IP access control in auth_config (independent of tokens)
    if public is not None or ip_whitelist is not None:
        if lepton_deployment_spec.auth_config is None:
            lepton_deployment_spec.auth_config = AuthConfig()

        if public:
            # Public means accessible from any IP (no IP restrictions)
            lepton_deployment_spec.auth_config.ip_allowlist = []
        elif ip_whitelist is not None:
            # IP whitelist means only accessible from specified IPs
            parsed_ips = _parse_ip_whitelist(ip_whitelist)
            lepton_deployment_spec.auth_config.ip_allowlist = parsed_ips

    new_lepton_deployment = LeptonDeployment(
        metadata=Metadata(
            id=name,
            name=name,
            visibility=LeptonVisibility(visibility) if visibility else None,
        ),
        spec=lepton_deployment_spec,
    )

    logger.trace(json.dumps(new_lepton_deployment.model_dump(), indent=2))

    if lepton_deployment.metadata.semantic_version:
        dryrun_deployment = client.deployment.update(
            name_or_deployment=name,
            spec=new_lepton_deployment,
            dryrun=True,
        )

        will_restart = not _same_major_version([
            dryrun_deployment.metadata.semantic_version,
            lepton_deployment.metadata.semantic_version,
        ])
        if will_restart:

            confirmed = (not sys.stdin.isatty()) or Confirm.ask(
                "This update will trigger a rolling restart. Are you sure you want to"
                " continue?",
                default=True,
            )

            if not confirmed:
                sys.exit(1)

            replicas = client.deployment.get_replicas(lepton_deployment)

            version_str_list = [lepton_deployment.metadata.semantic_version] + [
                replica.metadata.semantic_version for replica in replicas
            ]

            updating_ongoing = not _same_major_version(version_str_list)
            if updating_ongoing:
                console.print(
                    "[red]An update is in progress. Please try again later.[/]"
                )
                sys.exit(1)

            console.print("Proceeding with the update...")

    client.deployment.update(
        name_or_deployment=name,
        spec=new_lepton_deployment,
    )
    console.print(f"Endpoint [green]{name}[/] updated.")


@deployment.command()
@click.option("--name", "-n", help="The endpoint name to get status.", required=True)
def events(name):
    """
    Lists events of the endpoint
    """
    client = APIClient()
    events = client.deployment.get_events(name)

    table = Table(title="Endpoint Events", show_header=True, show_lines=False)
    table.add_column("Endpoint Name")
    table.add_column("Type")
    table.add_column("Reason")
    table.add_column("Regarding")
    table.add_column("Count")
    table.add_column("Last Observed Time")
    for event in events:
        date_string = event.last_observed_time.strftime("%Y-%m-%d %H:%M:%S")
        table.add_row(
            name,
            event.type_,
            event.reason,
            str(event.regarding),
            str(event.count),
            date_string,
        )
    console.print(table)


def add_command(cli_group):
    # Clone commands from hidden `deployment` group to visible `endpoint` group.
    for _name, _cmd in deployment.commands.items():
        if _name not in endpoint.commands:
            endpoint.add_command(_cmd, name=_name)

    # Register groups: keep `deployment` for backward-compatibility (hidden), add visible `endpoint`.
    cli_group.add_command(deployment, name="deployment")
    cli_group.add_command(endpoint, name="endpoint")


@deployment.command()
@click.option("--name", "-n", help="Endpoint name", required=True, type=str)
@click.option(
    "--path",
    "-p",
    type=click.Path(
        exists=False,
        file_okay=True,
        dir_okay=True,
        writable=True,
        readable=True,
        resolve_path=True,
    ),
    help=(
        "Optional local path to save the endpoint spec JSON. Directory or full filename"
        " accepted.\nIf a directory is provided, the file will be saved as"
        " endpoint-spec-<name>.json."
    ),
    required=False,
)
def get(name, path):
    """Shows Endpoint detail and optionally saves its spec JSON."""

    client = APIClient()

    try:
        dep = client.deployment.get(name)
    except Exception as e:
        console.print(f"[red]Failed to fetch endpoint {name}: {e}[/]")
        sys.exit(1)

    console.print(json.dumps(client.deployment.safe_json(dep), indent=2))

    if path:
        import os

        spec_json = dep.spec.model_dump_json(indent=2)

        save_path = path
        if os.path.isdir(path) or path.endswith(os.sep):
            os.makedirs(path, exist_ok=True)
            save_path = os.path.join(path, f"endpoint-spec-{name}.json")
        else:
            parent = os.path.dirname(save_path)
            if parent:
                os.makedirs(parent, exist_ok=True)

        try:
            with open(save_path, "w") as f:
                f.write(spec_json)
            console.print(f"Endpoint spec saved to [green]{save_path}[/].")
        except Exception as e:
            console.print(f"[red]Failed to save spec: {e}[/]")
            sys.exit(1)
