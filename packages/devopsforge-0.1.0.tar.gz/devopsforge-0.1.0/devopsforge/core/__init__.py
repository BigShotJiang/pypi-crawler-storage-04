"""
Core functionality for DevOpsGenie
"""
