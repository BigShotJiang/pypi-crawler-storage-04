"""
Jinja2 templates for generating DevOps configurations
"""
