"""
Command-line interface for DevOpsGenie
"""
