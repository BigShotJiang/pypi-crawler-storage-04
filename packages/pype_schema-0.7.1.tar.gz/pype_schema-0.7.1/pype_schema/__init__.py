# -*- coding: utf-8 -*-
"""Main package for PyPES."""

__author__ = "Fletcher Chapin"
__email__ = "fchapin@stanford.edu"
# Do not edit this string manually, always use bumpversion
# Details in CONTRIBUTING.md
__version__ = "0.7.1"


def get_module_version():
    return __version__
