from .gpuBase import GPUDetect

__all__ = ['GPUDetect']
