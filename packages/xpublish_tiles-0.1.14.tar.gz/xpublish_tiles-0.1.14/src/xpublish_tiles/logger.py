"""
Logging setup and shared logger for the xpublish_tiles package.
"""

import logging

# Set up a shared logger for the xpublish_tiles package
logger = logging.getLogger("xpublish_tiles")
