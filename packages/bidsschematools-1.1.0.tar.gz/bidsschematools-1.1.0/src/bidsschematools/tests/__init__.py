"""Tests for bidsschematools."""
