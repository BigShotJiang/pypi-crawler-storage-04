# python-build-utils

[![Release](https://img.shields.io/github/v/release/eelcovv/python-build-utils)](https://img.shields.io/github/v/release/eelcovv/python-build-utils)
[![Build status](https://img.shields.io/github/actions/workflow/status/eelcovv/python-build-utils/main.yml?branch=main)](https://github.com/eelcovv/python-build-utils/actions/workflows/main.yml?query=branch%3Amain)
[![Commit activity](https://img.shields.io/github/commit-activity/m/eelcovv/python-build-utils)](https://img.shields.io/github/commit-activity/m/eelcovv/python-build-utils)
[![License](https://img.shields.io/github/license/eelcovv/python-build-utils)](https://img.shields.io/github/license/eelcovv/python-build-utils)

Small collection of command line utilities to assist with building your python wheels
