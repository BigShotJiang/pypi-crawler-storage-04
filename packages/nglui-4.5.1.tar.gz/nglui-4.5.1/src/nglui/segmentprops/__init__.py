from .base import (
    LabelProperty,
    NumberProperty,
    SegmentProperties,
    StringProperty,
    TagProperty,
)
