---
title: statebuilder.ngl_annotations
---

::: src.nglui.statebuilder.ngl_annotations
    options:
        show_source: false
        heading_level: 2
