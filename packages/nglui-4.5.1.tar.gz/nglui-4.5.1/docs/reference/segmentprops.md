---
title: segmentprops
---

!!! note

    Autogeneration of the function reference does not capture the full range of segment properties.
    Please see the documentation for the individual segment types if you want to build segment properties manually.

::: src.nglui.segmentprops.base
    options:
        show_source: false
        heading_level: 2
