---
title: statebuilder.shaders
---

::: src.nglui.statebuilder.shaders
    options:
        show_source: false
        heading_level: 2

