---
title: statebuilder.base
---

::: src.nglui.statebuilder.base
    options:
        show_source: false
        heading_level: 2
