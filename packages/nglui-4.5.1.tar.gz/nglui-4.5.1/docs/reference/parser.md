---
title: parser
---

::: src.nglui.parser
    options:
        show_source: false
        heading_level: 2