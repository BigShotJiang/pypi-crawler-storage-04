#!/bin/zsh
git push --tags