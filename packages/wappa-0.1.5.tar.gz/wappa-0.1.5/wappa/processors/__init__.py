"""
Webhook processor infrastructure for the Mimeia AI Agent Platform.

This module provides platform-agnostic webhook processing capabilities
with specialized processors for different messaging platforms.
"""
