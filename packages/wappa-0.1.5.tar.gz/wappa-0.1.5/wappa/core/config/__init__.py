"""Configuration module for Wappa framework."""

from .settings import settings

__all__ = ["settings"]
