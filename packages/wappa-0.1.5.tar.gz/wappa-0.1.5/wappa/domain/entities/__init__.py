"""
Domain entities.

Contains the core business entities and value objects.
"""
