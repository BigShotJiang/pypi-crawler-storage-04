"""
Wappa CLI module.

Provides command-line interface for Wappa development and deployment workflows.
"""

from .main import app

__all__ = ["app"]