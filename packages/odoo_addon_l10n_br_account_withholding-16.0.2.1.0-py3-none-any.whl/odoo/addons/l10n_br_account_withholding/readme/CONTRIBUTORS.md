* `Escodoo <https://www.escodoo.com.br>`_:

  * Marcel Savegnago <marcel.savegnago@escodoo.com.br>

* `Akretion <https://www.akretion.com.br>`_:

  * Renato Lima <renato.lima@akretion.com.br>
