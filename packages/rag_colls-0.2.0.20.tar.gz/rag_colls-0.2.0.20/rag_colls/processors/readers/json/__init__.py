from .json_reader import JSONReader

__all__ = ["JSONReader"]
