from .megaparse_reader import MegaParseReader

__all__ = ["MegaParseReader"]
