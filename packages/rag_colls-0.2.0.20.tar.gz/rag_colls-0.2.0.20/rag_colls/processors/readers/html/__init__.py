from .html_reader import HTMLReader

__all__ = ["HTMLReader"]
