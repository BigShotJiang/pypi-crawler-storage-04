class CurrencyConverter:
    """
    Self converter.
    Before converting he's downloading database of currencies.
    He's ensuring downloaded database of currencies.
    He's updating this database every hour(customizable).
    """

    def __init__(self) -> None: ...
