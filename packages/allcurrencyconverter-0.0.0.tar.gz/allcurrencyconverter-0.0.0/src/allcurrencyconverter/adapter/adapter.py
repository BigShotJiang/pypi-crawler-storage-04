class ExchangeRatesAPIAdapter:
    """Adapter to ExchangeRatesAPI API methods"""

    ...
