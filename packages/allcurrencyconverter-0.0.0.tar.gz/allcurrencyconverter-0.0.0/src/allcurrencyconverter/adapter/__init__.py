from .adapter import ExchangeRatesAPIAdapter


__all__ = ["ExchangeRatesAPIAdapter"]
