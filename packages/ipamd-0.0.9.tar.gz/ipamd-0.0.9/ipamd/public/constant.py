na = 6.02214076e23# Avogadro's number
kb = 1.380649e-23# Boltzmann constant, J/K
e = 1.6021766208e-19# Elementary charge, C
epsilon0 = 8.854187817e-12# Vacuum permittivity, F/m
