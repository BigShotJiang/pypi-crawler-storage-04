# Por Qué: pure-python parquet parsing

¿Por qué? ¿Por qué no?

Si, ¿pero por qué? ¡Porque, parquet, python!

This is a project for education, it is NOT suitable for any production uses.
