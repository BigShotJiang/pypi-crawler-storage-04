---
meta:
    title: Skeleton
    description:
layout: component
---

```html:preview
<terra-skeleton></terra-skeleton>
```

## Examples

### First Example

TODO

### Second Example

TODO

[component-metadata:terra-skeleton]
