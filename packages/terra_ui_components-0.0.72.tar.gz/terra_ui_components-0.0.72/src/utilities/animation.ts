// TODO: These need to reference internal functions, which we might have strippped out in the fork process.
export { getAnimationNames, getEasingNames } from '@shoelace-style/shoelace'
