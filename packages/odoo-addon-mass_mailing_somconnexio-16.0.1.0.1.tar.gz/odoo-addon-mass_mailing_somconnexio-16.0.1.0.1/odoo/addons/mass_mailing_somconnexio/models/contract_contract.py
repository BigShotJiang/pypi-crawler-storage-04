# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import models


class Contract(models.Model):
    _inherit = "contract.contract"
    _mailing_enabled = True
