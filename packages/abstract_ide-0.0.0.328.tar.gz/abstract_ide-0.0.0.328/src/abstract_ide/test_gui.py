from consoles import *
from abstract_gui import *
#startIdeConsole()
startConsole(ideTab)
