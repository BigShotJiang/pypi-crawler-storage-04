from .main import launcherWindowTab
from abstract_gui.QT6.utils.console_utils import startConsole
def startLauncherWindowConsole():
    startConsole(launcherWindowTab)
