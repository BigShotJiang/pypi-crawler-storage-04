from .main import windowManagerTab
from abstract_gui.QT6.utils.console_utils import startConsole

def startWindowManagerConsole():
    startConsole(windowManagerTab)
 
