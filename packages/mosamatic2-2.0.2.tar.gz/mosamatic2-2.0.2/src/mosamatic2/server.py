def main():
    print('Running mosamatic2 server...')