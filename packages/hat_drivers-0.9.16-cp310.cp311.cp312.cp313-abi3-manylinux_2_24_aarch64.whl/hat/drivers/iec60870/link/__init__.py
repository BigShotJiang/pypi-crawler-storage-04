"""IEC 60870-5 link layer"""

from hat.drivers.iec60870.link.common import Address, AddressSize


__all__ = ['Address',
           'AddressSize']
