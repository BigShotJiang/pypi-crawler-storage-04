## Related software

- [BigStitcher](https://imagej.net/plugins/bigstitcher/)
- [ashlar](https://github.com/labsyspharm/ashlar)
- [TeraStitcher](https://abria.github.io/TeraStitcher/)
- [m2stitch](https://github.com/yfukai/m2stitch)

## Other cool spaces

- [ndpyramid](https://github.com/carbonplan/ndpyramid)
- [affinder](https://www.napari-hub.org/plugins/affinder)
- [bigstream](https://github.com/GFleishman/bigstream)
- [SpatialData](https://github.com/scverse/spatialdata)
