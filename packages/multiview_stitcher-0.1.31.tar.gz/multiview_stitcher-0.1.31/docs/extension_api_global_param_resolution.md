# Global parameter resolution

WIP: Custom function API to be added.
