"""
The :mod:`~tsfresh.convenience` submodule contains methods that allow the user to extract and filter features
conveniently.
"""
