tsfresh.feature\_selection package
==================================

Submodules
----------

tsfresh.feature\_selection.relevance module
-------------------------------------------

.. automodule:: tsfresh.feature_selection.relevance
   :members:
   :undoc-members:
   :show-inheritance:

tsfresh.feature\_selection.selection module
-------------------------------------------

.. automodule:: tsfresh.feature_selection.selection
   :members:
   :undoc-members:
   :show-inheritance:

tsfresh.feature\_selection.significance\_tests module
-----------------------------------------------------

.. automodule:: tsfresh.feature_selection.significance_tests
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: tsfresh.feature_selection
   :members:
   :undoc-members:
   :show-inheritance:
