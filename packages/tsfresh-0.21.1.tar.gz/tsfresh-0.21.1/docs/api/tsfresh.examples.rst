tsfresh.examples package
========================

Submodules
----------

tsfresh.examples.driftbif\_simulation module
--------------------------------------------

.. automodule:: tsfresh.examples.driftbif_simulation
   :members:
   :undoc-members:
   :show-inheritance:

tsfresh.examples.har\_dataset module
------------------------------------

.. automodule:: tsfresh.examples.har_dataset
   :members:
   :undoc-members:
   :show-inheritance:

tsfresh.examples.robot\_execution\_failures module
--------------------------------------------------

.. automodule:: tsfresh.examples.robot_execution_failures
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: tsfresh.examples
   :members:
   :undoc-members:
   :show-inheritance:
