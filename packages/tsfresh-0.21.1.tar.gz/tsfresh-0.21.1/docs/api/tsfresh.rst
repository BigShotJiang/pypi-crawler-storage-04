tsfresh package
===============

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   tsfresh.convenience
   tsfresh.examples
   tsfresh.feature_extraction
   tsfresh.feature_selection
   tsfresh.scripts
   tsfresh.transformers
   tsfresh.utilities

Submodules
----------

tsfresh.defaults module
-----------------------

.. automodule:: tsfresh.defaults
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: tsfresh
   :members:
   :undoc-members:
   :show-inheritance:
