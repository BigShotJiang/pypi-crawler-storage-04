tsfresh.convenience package
===========================

Submodules
----------

tsfresh.convenience.bindings module
-----------------------------------

.. automodule:: tsfresh.convenience.bindings
   :members:
   :undoc-members:
   :show-inheritance:

tsfresh.convenience.relevant\_extraction module
-----------------------------------------------

.. automodule:: tsfresh.convenience.relevant_extraction
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: tsfresh.convenience
   :members:
   :undoc-members:
   :show-inheritance:
