Este módulo depende dos pacotes Python:

- [erpbrasil.base](https://github.com/erpbrasil/erpbrasil.base)
- num2words
- phonenumbers
- email_validator
