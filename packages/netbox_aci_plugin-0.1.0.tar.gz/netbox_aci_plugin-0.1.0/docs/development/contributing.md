{%
  include-markdown "../../CONTRIBUTING.md"
%}
