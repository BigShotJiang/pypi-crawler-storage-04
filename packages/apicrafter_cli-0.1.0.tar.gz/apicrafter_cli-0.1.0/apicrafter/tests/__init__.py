"""Test suite for apicrafter."""
