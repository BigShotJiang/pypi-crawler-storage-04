from django.test import TestCase


class SpireChildAppModelTestCase(TestCase):
    def setUp(self):
        super().setUp()
