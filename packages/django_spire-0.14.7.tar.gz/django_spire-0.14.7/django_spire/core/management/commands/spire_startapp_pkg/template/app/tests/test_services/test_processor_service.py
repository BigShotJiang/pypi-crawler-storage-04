from django.test import TestCase


class SpireChildAppProcessorServiceTestCase(TestCase):
    def setUp(self):
        super().setUp()
