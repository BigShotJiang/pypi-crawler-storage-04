from __future__ import annotations

from dandy.intel import BaseIntel


class PromptTuningIntel(BaseIntel):
    prompt: str
