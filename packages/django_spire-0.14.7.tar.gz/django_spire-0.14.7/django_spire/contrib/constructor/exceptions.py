from django_spire.exceptions import DjangoSpireException


class ConstructorException(DjangoSpireException):
    pass