# TODO add in the date picker from Battle Journal Pro
