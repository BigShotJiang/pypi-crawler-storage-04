# Copyright (c) Acconeer AB, 2022-2025
# All rights reserved

from __future__ import annotations

from pathlib import Path
from typing import Optional

from PySide6 import QtCore, QtGui
from PySide6.QtWidgets import QCheckBox, QFileDialog, QHBoxLayout, QPushButton, QWidget

from acconeer.exptool.app.new.app_model import AppModel
from acconeer.exptool.app.new.ui.icons import FOLDER_OPEN, SAVE


class RecordingWidget(QWidget):
    def __init__(self, app_model: AppModel, parent: QWidget) -> None:
        super().__init__(parent)

        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        layout.addWidget(LoadFileButton(app_model, self))
        layout.addWidget(SaveFileButton(app_model, self))
        layout.addWidget(RecordingCheckbox(app_model, self))

        self.setLayout(layout)


class RecordingCheckbox(QCheckBox):
    def __init__(
        self,
        app_model: AppModel,
        parent: QWidget,
    ) -> None:
        super().__init__("Enable recording", parent)

        self.app_model = app_model
        app_model.sig_notify.connect(self._on_app_model_update)

        self.setToolTip("Enables recording of session to file")
        self.setFocusPolicy(QtCore.Qt.FocusPolicy.NoFocus)

        self.stateChanged.connect(self._on_state_changed)

    def _on_state_changed(self) -> None:
        self.app_model.set_recording_enabled(self.isChecked())

    def _on_app_model_update(self, app_model: AppModel) -> None:
        self.setChecked(app_model.recording_enabled)
        self.setEnabled(app_model.plugin_state.is_steady)


class FileButton(QPushButton):
    """A practically abstract class (cannot be abstract due to meta class conflict)"""

    def __init__(
        self,
        app_model: AppModel,
        text: str,
        icon: QtGui.QIcon,
        shortcut: Optional[str],
        tooltip: Optional[str],
        parent: QWidget,
    ) -> None:
        super().__init__(parent)

        self.app_model = app_model

        self.setText(text)
        self.setIcon(icon)

        if shortcut is not None:
            self.setShortcut(shortcut)
            newline = "\n"
            tooltip = f"{tooltip or ''}{newline if tooltip else ''}Shortcut: {shortcut}"

        if tooltip is not None:
            self.setToolTip(tooltip)

        self.clicked.connect(self._on_click)

        self.setFocusPolicy(QtCore.Qt.FocusPolicy.NoFocus)

    def _on_click(self) -> None:
        raise NotImplementedError


class LoadFileButton(FileButton):
    def __init__(self, app_model: AppModel, parent: QWidget) -> None:
        super().__init__(
            app_model,
            "Load from file",
            FOLDER_OPEN(),
            "Ctrl+o",
            "Load a previously recorded and saved session and play it back",
            parent,
        )
        app_model.sig_notify.connect(self._on_app_model_update)

    def _on_app_model_update(self, app_model: AppModel) -> None:
        self.setEnabled(app_model.plugin_state.is_steady)

    def _on_click(self) -> None:
        filename, _ = QFileDialog.getOpenFileName(
            self,
            caption="Load from file",
            filter=_file_suffix_to_filter(".h5", ".npz"),
            options=QFileDialog.Option.DontUseNativeDialog,
        )

        if not filename:
            return

        self.app_model.load_from_file(Path(filename))


class SaveFileButton(FileButton):
    def __init__(self, app_model: AppModel, parent: QWidget) -> None:
        super().__init__(
            app_model,
            "Save to file",
            SAVE(),
            "Ctrl+s",
            "Save the current session",
            parent,
        )
        app_model.sig_notify.connect(self._on_app_model_update)

    def _on_app_model_update(self, app_model: AppModel) -> None:
        self.setEnabled(app_model.saveable_file is not None and app_model.plugin_state.is_steady)

    def _on_click(self) -> None:
        if self.app_model.saveable_file is None:
            raise RuntimeError

        filename, _ = QFileDialog.getSaveFileName(
            self,
            caption="Save to file",
            filter=_file_suffix_to_filter(self.app_model.saveable_file.suffix),
            options=QFileDialog.Option.DontUseNativeDialog,
        )

        if not filename:
            return

        path = Path(filename)

        if path.suffix != self.app_model.saveable_file.suffix:
            path = path.with_name(path.name + self.app_model.saveable_file.suffix)

        self.app_model.save_to_file(path)


def _file_suffix_to_filter(*exts: str) -> str:
    NAMES = {
        ".h5": "HDF5",
        ".npz": "NumPy",
    }
    return ";;".join([f"{NAMES.get(ext, '')} (*{ext})" for ext in exts])
