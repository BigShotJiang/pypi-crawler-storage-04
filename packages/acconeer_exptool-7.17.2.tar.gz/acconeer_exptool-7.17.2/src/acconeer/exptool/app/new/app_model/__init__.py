# Copyright (c) Acconeer AB, 2022-2023
# All rights reserved

from .app_model import AppModel, PluginPresetSpec, PluginSpec
from .plugin_protocols import PlotPluginInterface
