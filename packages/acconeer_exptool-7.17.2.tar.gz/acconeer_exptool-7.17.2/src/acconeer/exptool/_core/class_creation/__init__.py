# Copyright (c) Acconeer AB, 2023
# All rights reserved
"""
This package contains utility functions for class creation
"""
