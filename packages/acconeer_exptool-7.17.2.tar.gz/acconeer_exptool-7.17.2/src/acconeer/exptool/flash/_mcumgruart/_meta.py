# Copyright (c) Acconeer AB, 2023
# All rights reserved

ACCONEER_XB122_MODULE_VID = 0x0403
ACCONEER_XB122_MODULE_PID = 0x6015
