from . import _C

from .ops import swiglu

__all__ = ["__version__", "swiglu"]
