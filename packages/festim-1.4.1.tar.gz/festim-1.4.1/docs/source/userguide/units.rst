=====
Units
=====


In FESTIM, the choice was made to have all the units as SI.

- concentrations: atoms/m3
- temperature: Kelvin
- distances: metres
- time: seconds
- pressure: Pascals
- energy: electron-volts

