Initial condition
=================

.. currentmodule:: festim

.. autoclass:: InitialCondition
    :members:
    :show-inheritance: