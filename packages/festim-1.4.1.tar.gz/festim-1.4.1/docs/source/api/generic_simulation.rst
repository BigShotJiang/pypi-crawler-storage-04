Generic simulation
==================

.. currentmodule:: festim

.. autoclass:: Simulation
    :members:
    :show-inheritance:
