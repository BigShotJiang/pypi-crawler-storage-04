Concentration
=============

.. currentmodule:: festim

.. autoclass:: Concentration
    :members:
    :show-inheritance:

.. autoclass:: Mobile
    :members:
    :show-inheritance:

.. autoclass:: Theta
    :members:
    :show-inheritance:

.. autoclass:: Trap
    :members:
    :show-inheritance:

.. autoclass:: Traps
    :members:
    :show-inheritance:

.. autoclass:: ExtrinsicTrapBase
    :members:
    :show-inheritance:

.. autoclass:: ExtrinsicTrap
    :members:
    :show-inheritance:

.. autoclass:: NeutronInducedTrap
    :members:
    :show-inheritance: