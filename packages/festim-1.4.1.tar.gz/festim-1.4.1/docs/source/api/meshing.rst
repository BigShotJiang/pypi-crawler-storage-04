Meshing
=======

.. currentmodule:: festim

.. autoclass:: Mesh
    :members:
    :show-inheritance:

.. autoclass:: Mesh1D
    :members:
    :show-inheritance:

.. autoclass:: MeshFromVertices
    :members:
    :show-inheritance:

.. autoclass:: MeshFromXDMF
    :members:
    :show-inheritance: