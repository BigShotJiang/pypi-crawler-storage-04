# Placeholder for utils.py
