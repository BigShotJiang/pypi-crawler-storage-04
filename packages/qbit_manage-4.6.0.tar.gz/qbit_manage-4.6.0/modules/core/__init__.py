"""
modules.core contains all the core functions of qbit_manage such as updating categories/tags etc..
"""
