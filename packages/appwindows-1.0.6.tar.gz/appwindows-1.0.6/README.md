<img src="https://raw.githubusercontent.com/lexter0705/appwindows/refs/heads/master/appwindows.svg" alt="" width="40%" >

# Appwindows
The appwindows library solves the problem of working with a graphical shell on different operating systems.
# Install
```bash
pip install appwindows
```
# Docs
All documentation <a href="https://apparser.gitbook.io/appwindows">here</a>
# For Developers
1) If something doesn't work - open issue.
2) If you want something fixed - open issue.
3) If you can help with the library - email.

apparser.development@gmail.com

Any help in development is welcome)!
