This module is a 'glue' module for the modules stock_move_location and
stock_move_purchase_uom. If an operation type has the option "use
purchase uom" enabled, when creating a transfer for that operation using
the "Move to location" button, the uom of the products in the transfer
will be set to the purchase uom of the products.
