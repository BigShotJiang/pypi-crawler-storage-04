from enum import Enum


class ConnectorCustomRouteUiComponentDtoType(str, Enum):
    CUSTOM = "custom"

    def __str__(self) -> str:
        return str(self.value)
