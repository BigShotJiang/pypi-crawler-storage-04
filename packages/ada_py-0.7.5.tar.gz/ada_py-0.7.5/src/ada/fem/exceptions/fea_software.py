class FEASolverNotInstalled(Exception):
    pass
