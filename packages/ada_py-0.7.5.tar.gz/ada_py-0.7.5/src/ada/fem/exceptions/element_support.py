class IncompatibleElements(Exception):
    pass
