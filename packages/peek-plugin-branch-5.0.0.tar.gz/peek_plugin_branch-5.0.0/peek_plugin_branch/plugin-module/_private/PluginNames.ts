export let branchFilt = { plugin: "peek_plugin_branch" };
export let branchTuplePrefix = "peek_plugin_branch.";

export let branchObservableName = "peek_plugin_branch";
export let branchActionProcessorName = "peek_plugin_branch";
export let branchTupleOfflineServiceName = "peek_plugin_branch";

export let branchBaseUrl = "peek_plugin_branch";
