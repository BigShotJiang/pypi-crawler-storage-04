"""Constants for the Specsmith CLI."""

# Default API URL for Specsmith
DEFAULT_API_URL = "https://api.specsmith.ai"
