# To do

## Class folder
- [ ] Check what happens in case of other folder elements, such as a *static* method. 

## Local namespaces

- [ ] Fully collect contents of private folder in a local `pathsCollection` (optional)
- [ ] Add locally resolveable names of namespace members in local `pathsCollection`
- [ ] Prioritize name collisions based on current working directory

## Dependency analysis
- [ ] Add functionality for dependency analysis
- [ ] Import namespace `pathsCollection` during namespace imports
