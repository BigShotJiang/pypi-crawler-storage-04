from ._base import DataModelAnalysis

__all__ = ["DataModelAnalysis"]
