from autogen_kubernetes_mcp import main

main()
