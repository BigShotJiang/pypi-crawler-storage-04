"""
Main package for Fairness metrics toolbox for classification plugin.
"""
