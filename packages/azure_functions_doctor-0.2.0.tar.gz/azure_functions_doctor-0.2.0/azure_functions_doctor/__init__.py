"""Init for azure_function_doctor package.

This module initializes the Azure Functions Doctor package and defines the version string.
"""

__version__ = "0.2.0"
