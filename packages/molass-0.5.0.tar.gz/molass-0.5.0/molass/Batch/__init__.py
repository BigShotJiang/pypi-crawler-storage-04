"""
    Batch.__init__.py
"""