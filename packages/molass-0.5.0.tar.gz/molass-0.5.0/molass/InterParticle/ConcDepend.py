"""
    InterParticle.ConcDepend.py
"""

def compute_scd(ssd, debug=False):
    return 0