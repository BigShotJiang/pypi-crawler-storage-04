"""
    Peaks.__init__.py
"""