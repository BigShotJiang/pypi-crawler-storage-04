The images present in the project report have not been included in the github repo so as not to bloat its size.
Instead, a link to both images has been provided [here](https://imperiallondon-my.sharepoint.com/:f:/g/personal/bg721_ic_ac_uk/EoH7W7NPWXlOsDHadqT8tbEBbUE9t1VYGL1sISH0hah7kw?e=pMB351).
These images should be downloaded and placed in this folder to correctly compile main.tex.
