# yao

![Versions](https://img.shields.io/badge/python->3.9-blue)
[![Code style: black](https://img.shields.io/badge/code%20style-black-000000.svg)](https://github.com/psf/black)
[![Documentation Status](https://readthedocs.org/projects/lvmieb/badge/?version=latest)](https://sdss-yao.readthedocs.io/en/latest/?badge=latest)

BOSS spectrograph actor that uses an STA Archon controller.
