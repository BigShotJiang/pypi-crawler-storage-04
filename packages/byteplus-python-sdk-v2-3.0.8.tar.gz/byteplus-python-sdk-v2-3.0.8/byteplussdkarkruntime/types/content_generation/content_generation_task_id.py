from byteplussdkarkruntime._models import BaseModel


class ContentGenerationTaskID(BaseModel):
    id: str
    """A unique identifier for the task."""
