from ..types.py_object import PyObject


class Dict(PyObject, dict):
    pass
