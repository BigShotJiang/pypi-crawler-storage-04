class FileNotFound(RuntimeError):
    pass
