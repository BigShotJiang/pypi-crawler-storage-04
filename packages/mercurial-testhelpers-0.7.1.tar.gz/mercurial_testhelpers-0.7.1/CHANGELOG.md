## Changelog

### version 0.6.0 (2021-10-21)

- !11: new `RepoWrapper.reload()` method
- coverage plugin: support Mercurial versions 6.x

### version 0.5.0 (2021-02-17)

- #2: options for `datetime` and timezones in methods creating commits
- #3: generic helper to call commands, even without repository
- #4: helper method to create merge commits

### version 0.4.0 (2020-12-20)

- #5: keeping original path on `RepoWrapper`
- #6: helper methods for repository configuration (in-memory) and
  `.hg/hgrc` writer.
