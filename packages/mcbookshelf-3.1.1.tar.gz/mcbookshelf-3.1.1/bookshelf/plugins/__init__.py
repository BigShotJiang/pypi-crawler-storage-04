"""Beet plugins used by the Bookshelf Library."""
