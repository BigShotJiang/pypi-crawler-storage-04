=======
History
=======

0.0.1 (2024-12-20)
------------------

* First release on PyPI.
