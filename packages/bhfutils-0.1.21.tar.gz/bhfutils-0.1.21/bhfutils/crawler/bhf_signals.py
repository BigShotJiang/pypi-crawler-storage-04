"""
Behoof scrapy signals
"""

ip_changed = object()
