"""Test suite for AutoPurple."""

