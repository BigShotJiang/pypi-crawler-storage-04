"""Unit tests for AutoPurple."""

