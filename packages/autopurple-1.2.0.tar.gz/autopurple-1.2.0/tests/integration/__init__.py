"""Integration tests for AutoPurple."""

