# fluent-checks
A simple, lightweight library for creating fluent, readable, and chainable checks in Python.
