from sorrel.entities.basic_entities import EmptyEntity, Gem, Wall
from sorrel.entities.entity import Entity
