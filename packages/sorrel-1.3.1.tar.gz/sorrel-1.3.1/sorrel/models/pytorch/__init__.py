from sorrel.models.pytorch.iqn import iRainbowModel as PyTorchIQN
