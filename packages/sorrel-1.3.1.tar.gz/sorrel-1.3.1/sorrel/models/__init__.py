from sorrel.models.base_model import BaseModel
