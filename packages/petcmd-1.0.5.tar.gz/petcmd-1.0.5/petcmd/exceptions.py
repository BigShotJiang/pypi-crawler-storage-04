
class CommandException(Exception):
	"""Base class for all petcmd exceptions"""
	pass
