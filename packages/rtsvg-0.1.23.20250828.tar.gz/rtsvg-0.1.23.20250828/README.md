# RACETrack SVG Framework

Pandas & Polars DataFrames + SVG => \[Interactive?\] Visualizations
