from mcp_fofa import main

main()