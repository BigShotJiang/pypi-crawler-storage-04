"""Test snews_pt installation"""


def test_import():
    import snews_pt
