"""SSVC Plugins generated from YAML configurations."""
