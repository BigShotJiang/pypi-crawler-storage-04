__version__ = "0.1.8"

from .main import (
    FixedLossWeighter,
    PDLossWeighter,
    PLossWeighter,
    LinearTrajectoryTarget,
    ConstantTarget,
    RelativeTarget,
    Target,
)
