# coding=utf-8
from .._impl import (
    timeseries_logicalseries_LogicalSeriesService as LogicalSeriesService,
)

__all__ = [
    'LogicalSeriesService',
]

