.. automodapi:: pharmpy.modeling
