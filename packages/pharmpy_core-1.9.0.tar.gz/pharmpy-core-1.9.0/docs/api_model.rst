.. automodapi:: pharmpy.model
