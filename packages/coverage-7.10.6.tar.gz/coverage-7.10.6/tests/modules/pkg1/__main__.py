# Used in the tests for PyRunner
import sys

print("pkg1.__main__: passed %s" % sys.argv[1])
