.. Licensed under the Apache License: http://www.apache.org/licenses/LICENSE-2.0
.. For details: https://github.com/nedbat/coveragepy/blob/master/NOTICE.txt

.. _api_coverage:

The Coverage class
------------------

.. autoclass:: coverage.Coverage
    :members:
    :exclude-members: sys_info
    :special-members: __init__
