API
===

.. currentmodule:: extract_model


.. autosummary::
   :toctree: generated/
   :recursive:

   extract_model
   utils
   accessor
   sorting
   model_type
   grids.triangular_mesh
   xr.triangular_mesh_netcdf
