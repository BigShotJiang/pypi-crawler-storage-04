if __name__ == "__main__":
    from meshcore_cli.meshcore_cli import cli
    cli()
