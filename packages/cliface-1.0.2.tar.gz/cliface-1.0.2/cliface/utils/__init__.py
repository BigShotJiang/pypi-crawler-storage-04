from .clear_terminal import clear_terminal

__all__ = ["clear_terminal"]