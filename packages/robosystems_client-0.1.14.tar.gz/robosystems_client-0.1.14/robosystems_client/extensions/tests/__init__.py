"""Tests for RoboSystems Client Extensions"""
