Write some tests!
