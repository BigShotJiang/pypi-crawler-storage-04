

# Type alias for HTTP body which can be string, dictionary or None
HttpBody = str | dict | None
__itemList__ = "itemList"
