from .src import nonebot_plugin_sky as nonebot_plugin_sky

# 这是为了本地更好的开发和导入