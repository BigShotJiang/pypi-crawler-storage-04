class FormCollectionError(Exception):
    """Some kind of problem with a FormCollection."""
    pass
