Templates in this directory are exclusively used to transform JSON into HTML when rendered through
the template tag `render_richtext`. The staring point for any richtext is the template `doc.html`.
