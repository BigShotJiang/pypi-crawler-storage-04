#!/usr/bin/env python3
"""
SubPlz CLI Entry Point
Command-line interface for the SubPlz subtitle pipeline
"""

from .pipeline import main

if __name__ == "__main__":
    main()
