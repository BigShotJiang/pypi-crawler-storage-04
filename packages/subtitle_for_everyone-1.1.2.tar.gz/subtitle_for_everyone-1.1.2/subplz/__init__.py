"""
SubPlz - Subtitle Pipeline for Everyone
A powerful tool to download YouTube videos and burn Netflix-style subtitles
"""

__version__ = "1.0.1"
__author__ = "Sid & Kan"
__email__ = "sofiyasenthilkumar@gmail.com"
__description__ = "Download YouTube videos and burn Netflix-style subtitles automatically"
