######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.18.2.1+obcheckpoint(0.2.4);ob(v1)                                                    #
# Generated on 2025-09-03T10:45:51.784558                                                            #
######################################################################################################

from __future__ import annotations


from . import pytorch as pytorch

