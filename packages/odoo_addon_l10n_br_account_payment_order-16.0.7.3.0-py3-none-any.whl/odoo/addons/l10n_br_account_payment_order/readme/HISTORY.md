## 16.0.6.0.0 (2024-03-06)

- \[REF\] Alterado o Código de Protesto de Char para Objeto/l10n_br_cnab.code

## 16.0.5.0.0 (2024-12-16)

- \[REM\] "Foward Port" Removendo Campos, Visões e Objetos obsoletos.

## 16.0.4.0.0 (2024-12-16)

- [IMP] "Foward Port" Possibilidade de informar Códigos de Desconto além do 0 e 1.

## 16.0.3.0.0 (2024-12-16)

- \[REF\] "Foward-Port" Separando as Configurações do CNAB do Modo de Pagamento.

## 16.0.2.0.0 (2024-12-04)

- \[REF\] "Foward-Port" Unindo os Códigos CNAB em um mesmo objeto.

## 16.0.1.0.0 (2024-09-10)

- \[MIG\] Migração para a versão 16.0

## 15.0.1.0.0 (2024-07-25)

- \[MIG\] Migração para a versão 15.0

## 14.0.9.0.0 (2024-09-19)

- \[REM\] Removendo Campos, Visões e Objetos obsoletos.

## 14.0.8.0.0 (2024-09-18)

- \[IMP\] Possibilidade de informar Códigos de Desconto além do 0 e 1.

## 14.0.7.0.0 (2024-09-13)

- \[REF\] Separando as Configurações do CNAB do Modo de Pagamento.

## 14.0.6.0.0 (2024-09-10)

- \[REF\] Unindo os Códigos CNAB em um mesmo objeto.

## 14.0.1.0.0 (2022-04-29)

- \[MIG\] Migração para a versão 14.0.

## 13.0.1.0.0 (2022-01-28)

- \[MIG\] Migração para a versão 13.0.

## 12.0.3.0.0 (2021-05-13)

- \[MIG\] Migração para a versão 12.0.
- Incluído a possibilidade de parametrizar o CNAB 240 e 400, devido a
  falta de padrão cada Banco e CNAB podem ter e usar codigos diferentes.
- Incluído os metodos para fazer alterações em CNAB já enviados.
- Incluído dados de demo e testes.
- Separado o objeto que fazia o Retorno do arquivo e registrava as
  informações para ter um objeto especifico que registra o Log e assim
  os modulos que implementam a biblioteca escolhida podem ter um
  metodo/objeto especifico para essa função.

## 12.0.1.0.0 (2019-06-06)

- \[MIG\] Inicio da Migração para a versão 12.0.

## 10.0.2.0.0 (2018-05-17)

- \[REF\] Modulo unido com o l10n_br_account_payment_mode e renomeado
  para l10n_br_account_payment_order.

## 10.0.1.0.0 (2018-08-29)

- \[MIG\] Migração para a versão 10.

## 8.0.1.0.1 (2017-07-14)

- \[NEW\] Refatoração e melhorias para suportar a geração de boletos
  através do br-cobranca (ruby)

## 8.0.1.0.0 (2017-07-14)

- \[NEW\] Melhorias para suportar a geração de pagamento da folha de
  pagamento;

## 8.0.0.0.0 (2016-01-18)

- \[NEW\] Primeira versão
