#!/usr/bin/env bash

PY_PACKAGE="peek_plugin_eventdb"
PYPI_PUBLISH="1"

VER_FILES_TO_COMMIT=""

VER_FILES=""
