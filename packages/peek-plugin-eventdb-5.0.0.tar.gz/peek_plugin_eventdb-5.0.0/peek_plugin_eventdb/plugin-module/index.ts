export { EventDBService, EventDateTimeRangeI } from "./EventDBService";

export * from "./tuples";

export { EventDBModule } from "@_peek/peek_plugin_eventdb/eventdb.module";
export { EventDBEventListComponent } from "@_peek/peek_plugin_eventdb/components/event-list-component/event-list.component";
