==============
Administration
==============

EventDB stores historical and current Alarms and Events.

.. toctree::
    :maxdepth: 3
    :caption: Contents:

    overview
    admin_tasks
