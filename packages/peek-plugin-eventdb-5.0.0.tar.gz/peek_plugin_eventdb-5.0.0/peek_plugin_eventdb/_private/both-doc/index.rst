==========
User Guide
==========

The EventDB plugin allows users to view alarms and events either historically or as
they appear on the network.
