==============
EventDB Plugin
==============


EventDB stores the historical and current events and alarms.

This plugin does not provide APIs for the desktop/mobile, it's intended for server side
only.
