"""Init script for fast_fig to access class FFig more easily."""

from .class_ffig import FFig  # noqa: F401
