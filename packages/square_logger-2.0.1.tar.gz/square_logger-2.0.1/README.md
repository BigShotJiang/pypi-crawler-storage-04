# square_logger

> 📌 versioning: see [CHANGELOG.md](./CHANGELOG.md).

## about

python logger for my personal use.

## installation

```shell
pip install square_logger
```

## usage

(wip)

## env

- python>=3.12.0

> feedback is appreciated. thank you!