# -*- coding: UTF-8 -*-
"""
Author:  Jacek 'Szumak' Kotlarski --<szumak@virthost.pl>
Created: 04.12.2023

Purpose: interface classes for RouterBoard
"""

from abc import ABC, abstractmethod


class IElement(ABC):
    """"""

    # @abstractmethod
    # def load(self) -> bool:
    # """"""


# #[EOF]#######################################################################
