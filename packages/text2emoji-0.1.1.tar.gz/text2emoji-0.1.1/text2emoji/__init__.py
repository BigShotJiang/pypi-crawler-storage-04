from .converter import text_to_emoji

__all__ = ["text_to_emoji"]
