=============
Release notes
=============

The release notes will tell you what's new in each version and will also
describe any backwards-incompatible changes.

Below are release notes through Django MongoDB backend 5.2.x. Newer versions of
the documentation contain the release notes for any later releases.

.. toctree::
   :maxdepth: 1

   5.2.x
   5.1.x
   5.0.x
