======
Models
======

Model API reference.

.. toctree::
   :maxdepth: 1

   fields
   querysets
   models
   indexes
   search
