from mignonFramework import printDirectoryTree
from mignonFramework import DatabaseTransferRunner


DatabaseTransferRunner(eazy=True).run()