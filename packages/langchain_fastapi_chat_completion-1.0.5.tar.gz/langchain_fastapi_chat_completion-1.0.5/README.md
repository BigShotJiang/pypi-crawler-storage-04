# LangChain FastAPI Chat Completion API

Fork of https://github.com/samuelint/langchain-openai-api-bridge

Changes:
  - Several default values changed.
  - Changed to enable use of FastAPI features.
  - Drop assistant API