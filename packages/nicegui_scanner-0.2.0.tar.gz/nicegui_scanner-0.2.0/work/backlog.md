# Backlog

## Incremental Working Examples

- **Add manual trigger**
  - Single "Scan Once" button for one-time scans
  - Manual barcode detection without continuous scanning
  - *Result: Working app with on-demand scanning capability*
