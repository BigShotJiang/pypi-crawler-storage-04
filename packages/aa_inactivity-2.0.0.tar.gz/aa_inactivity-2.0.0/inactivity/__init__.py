"""Activity monitoring app for Alliance Auth."""

# pylint: disable = invalid-name
default_app_config = "inactivity.apps.InactivityConfig"

__version__ = "2.0.0"

__title__ = "Inactivity"
