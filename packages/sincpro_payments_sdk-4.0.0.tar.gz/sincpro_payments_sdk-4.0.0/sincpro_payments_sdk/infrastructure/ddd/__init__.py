"""Domain Driven Design (DDD) module."""

from .value_object import new_value_object
