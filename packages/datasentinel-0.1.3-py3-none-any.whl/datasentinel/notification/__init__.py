"""`datasentinel.notification` provides functionality for notification rendering and sending."""
