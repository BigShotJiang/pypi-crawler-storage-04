"""Core module for DataSentinel."""


class DataSentinelError(Exception):
    """Base exception for DataSentinel errors."""

    pass
