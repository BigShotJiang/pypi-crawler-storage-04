"""Core analysis functionality"""
