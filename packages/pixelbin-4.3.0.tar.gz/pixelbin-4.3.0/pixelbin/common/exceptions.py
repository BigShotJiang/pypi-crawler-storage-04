class PixelbinInvalidCredentialError(Exception):
    """Invalid credential exception."""

    def __init__(self, message="Invalid Credentials"):
        """Initialize function __init__."""
        super(PixelbinInvalidCredentialError, self).__init__(message)


class PixelbinServerResponseError(Exception):
    """Pixelbin Server Response Exception."""

    def __init__(self, message="", status_code=None):
        """Initialize function __init__."""
        super(PixelbinServerResponseError, self).__init__(message)
        self.status_code = status_code


class PixelbinInvalidUrlError(Exception):
    """Pixelbin Invalid Url Exception."""

    def __init__(self, message=""):
        """Initialize function __init__."""
        super(PixelbinInvalidUrlError, self).__init__(message)


class PixelbinIllegalArgumentError(Exception):
    """Pixelbin Illegal Argument Exception."""

    def __init__(self, message=""):
        """Initialize function __init__."""
        super(PixelbinIllegalArgumentError, self).__init__(message)


class PixelbinIllegalQueryParameterError(Exception):
    """Pixelbin Illegal Query Parameter Exception."""

    def __init__(self, message=""):
        """Initialize function __init__."""
        super(PixelbinIllegalQueryParameterError, self).__init__(message)
