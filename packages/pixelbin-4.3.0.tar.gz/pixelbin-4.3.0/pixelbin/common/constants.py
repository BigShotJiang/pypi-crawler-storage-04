"""Python pixelbin/common/constants.py."""

DEFAULT_DOMAIN = "https://api.pixelbin.io"
APPLICATION_MIN_TOKEN_LENGTH = 5
HTTP_TIMEOUT = 15
TIMEZONE = "Asia/Kolkata"
