
class Error(RuntimeError):
    pass
