"""
ZeroBuffer Serve - JSON-RPC server for Harmony testing
"""

__version__ = "0.1.0"