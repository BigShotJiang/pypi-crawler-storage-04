# notary-client

POC package for harmless beacon-only testing.
