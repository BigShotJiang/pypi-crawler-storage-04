"""The module for hooks that can be used to extend the functionality of the agent."""
