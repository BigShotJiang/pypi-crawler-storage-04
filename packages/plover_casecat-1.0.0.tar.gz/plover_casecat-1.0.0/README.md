# `plover-casecat`

This plugin allows Plover to read `.sgdct` files, which are in Stenograph's Case CATalyst dictionary format. Use this instead of [`plover_casecat_dictionary`](https://github.com/marnanel/plover_casecat_dictionary).
