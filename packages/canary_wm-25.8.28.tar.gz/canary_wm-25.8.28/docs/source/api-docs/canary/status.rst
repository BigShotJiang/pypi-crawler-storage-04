.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


status
======

.. automodule:: _canary.status
   :members:
   :undoc-members:
   :show-inheritance:
