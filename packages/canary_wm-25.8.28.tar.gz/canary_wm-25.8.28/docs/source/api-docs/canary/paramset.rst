.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


paramset
========

.. automodule:: _canary.paramset
   :members:
   :undoc-members:
   :show-inheritance:
