.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


sendmail
========

.. automodule:: _canary.util.sendmail
   :members:
   :undoc-members:
   :show-inheritance:
