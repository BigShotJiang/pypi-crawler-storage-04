.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


scalar
======

.. automodule:: _canary.util.scalar
   :members:
   :undoc-members:
   :show-inheritance:
