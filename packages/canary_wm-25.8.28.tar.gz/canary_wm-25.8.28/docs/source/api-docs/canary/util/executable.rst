.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


executable
==========

.. automodule:: _canary.util.executable
   :members:
   :undoc-members:
   :show-inheritance:
