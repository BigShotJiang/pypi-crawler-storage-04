.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


partitioning
============

.. automodule:: _canary.util.partitioning
   :members:
   :undoc-members:
   :show-inheritance:
