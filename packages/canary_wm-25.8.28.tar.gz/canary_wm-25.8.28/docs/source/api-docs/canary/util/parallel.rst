.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


parallel
========

.. automodule:: _canary.util.parallel
   :members:
   :undoc-members:
   :show-inheritance:
