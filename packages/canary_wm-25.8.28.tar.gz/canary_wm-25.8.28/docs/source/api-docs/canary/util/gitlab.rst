.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


gitlab
======

.. automodule:: _canary.util.gitlab
   :members:
   :undoc-members:
   :show-inheritance:
