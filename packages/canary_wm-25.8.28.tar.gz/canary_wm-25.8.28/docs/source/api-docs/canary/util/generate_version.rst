.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


generate_version
================

.. automodule:: _canary.util.generate_version
   :members:
   :undoc-members:
   :show-inheritance:
