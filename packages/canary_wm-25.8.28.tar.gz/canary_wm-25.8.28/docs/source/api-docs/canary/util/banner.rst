.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


banner
======

.. automodule:: _canary.util.banner
   :members:
   :undoc-members:
   :show-inheritance:
