.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


enums
=====

.. automodule:: _canary.enums
   :members:
   :undoc-members:
   :show-inheritance:
