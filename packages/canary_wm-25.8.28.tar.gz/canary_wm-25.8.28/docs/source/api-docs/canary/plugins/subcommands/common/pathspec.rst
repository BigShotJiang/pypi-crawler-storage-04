.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


pathspec
========

.. automodule:: _canary.plugins.subcommands.common.pathspec
   :members:
   :undoc-members:
   :show-inheritance:
