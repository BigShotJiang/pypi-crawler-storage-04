.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


manager
=======

.. automodule:: _canary.plugins.manager
   :members:
   :undoc-members:
   :show-inheritance:
