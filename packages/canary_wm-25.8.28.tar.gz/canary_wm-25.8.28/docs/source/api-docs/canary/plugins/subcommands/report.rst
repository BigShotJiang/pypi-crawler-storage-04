.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


report
======

.. automodule:: _canary.plugins.subcommands.report
   :members:
   :undoc-members:
   :show-inheritance:
