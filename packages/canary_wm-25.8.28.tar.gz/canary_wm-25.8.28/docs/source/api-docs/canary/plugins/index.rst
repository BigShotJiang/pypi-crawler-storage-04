.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT

plugins
=======

.. toctree::
   :maxdepth: 1

   builtin/index
   hookspec
   manager
   subcommands/index
   types
