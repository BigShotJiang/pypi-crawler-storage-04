.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


help
====

.. automodule:: _canary.plugins.subcommands.help
   :members:
   :undoc-members:
   :show-inheritance:
