.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


email
=====

.. automodule:: _canary.plugins.builtin.email
   :members:
   :undoc-members:
   :show-inheritance:
