.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


ctest
=====

.. automodule:: _canary.plugins.builtin.ctest
   :members:
   :undoc-members:
   :show-inheritance:
