.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


html
====

.. automodule:: _canary.plugins.builtin.html
   :members:
   :undoc-members:
   :show-inheritance:
