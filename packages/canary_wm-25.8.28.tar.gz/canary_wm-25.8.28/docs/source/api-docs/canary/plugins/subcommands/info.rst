.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


info
====

.. automodule:: _canary.plugins.subcommands.info
   :members:
   :undoc-members:
   :show-inheritance:
