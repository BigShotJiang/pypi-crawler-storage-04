.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT

plugins.builtin.cdash
=====================

.. toctree::
   :maxdepth: 1

   cdash_html_summary
   gitlab_issue_generator
   xml_generator
