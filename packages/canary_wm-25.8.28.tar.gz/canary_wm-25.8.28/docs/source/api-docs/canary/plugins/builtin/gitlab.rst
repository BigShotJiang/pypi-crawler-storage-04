.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


gitlab
======

.. automodule:: _canary.plugins.builtin.gitlab
   :members:
   :undoc-members:
   :show-inheritance:
