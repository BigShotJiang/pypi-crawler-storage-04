.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT

plugins.builtin
===============

.. toctree::
   :maxdepth: 1

   batch_protocol
   cdash/index
   ctest
   discover
   email
   gitlab
   html
   json
   junit
   markdown
   mask
   partitioning
   post_clean
   pyt
   repeat
   reporting
   runtest_protocol
   runtests
   vvtest
