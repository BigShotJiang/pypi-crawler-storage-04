.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


run
===

.. automodule:: _canary.plugins.subcommands.run
   :members:
   :undoc-members:
   :show-inheritance:
