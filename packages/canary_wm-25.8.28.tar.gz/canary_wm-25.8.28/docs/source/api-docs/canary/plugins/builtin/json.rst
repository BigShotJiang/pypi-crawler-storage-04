.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


json
====

.. automodule:: _canary.plugins.builtin.json
   :members:
   :undoc-members:
   :show-inheritance:
