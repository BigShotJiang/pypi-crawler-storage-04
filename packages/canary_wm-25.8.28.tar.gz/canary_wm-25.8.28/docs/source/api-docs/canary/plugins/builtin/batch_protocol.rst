.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


batch_protocol
==============

.. automodule:: _canary.plugins.builtin.batch_protocol
   :members:
   :undoc-members:
   :show-inheritance:
