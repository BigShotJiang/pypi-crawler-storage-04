.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


pyt
===

.. automodule:: _canary.plugins.builtin.pyt
   :members:
   :undoc-members:
   :show-inheritance:
