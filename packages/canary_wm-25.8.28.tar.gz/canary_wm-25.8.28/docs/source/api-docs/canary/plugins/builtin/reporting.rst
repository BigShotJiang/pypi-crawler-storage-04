.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


reporting
=========

.. automodule:: _canary.plugins.builtin.reporting
   :members:
   :undoc-members:
   :show-inheritance:
