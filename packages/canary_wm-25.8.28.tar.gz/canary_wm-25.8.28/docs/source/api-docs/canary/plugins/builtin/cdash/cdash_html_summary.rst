.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


cdash_html_summary
==================

.. automodule:: _canary.plugins.builtin.cdash.cdash_html_summary
   :members:
   :undoc-members:
   :show-inheritance:
