.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


post_clean
==========

.. automodule:: _canary.plugins.builtin.post_clean
   :members:
   :undoc-members:
   :show-inheritance:
