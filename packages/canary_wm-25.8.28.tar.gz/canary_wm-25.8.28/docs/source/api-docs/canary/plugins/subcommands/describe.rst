.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


describe
========

.. automodule:: _canary.plugins.subcommands.describe
   :members:
   :undoc-members:
   :show-inheritance:
