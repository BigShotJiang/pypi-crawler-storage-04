.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT

config
======

.. toctree::
   :maxdepth: 1

   _machine
   argparsing
   config
   linux
   macos
   rpool
   schemas
