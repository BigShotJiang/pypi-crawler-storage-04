.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


expression
==========

.. automodule:: _canary.expression
   :members:
   :undoc-members:
   :show-inheritance:
