.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


shell
=====

.. automodule:: hpc_connect.submit.shell
   :members:
   :undoc-members:
   :show-inheritance:
