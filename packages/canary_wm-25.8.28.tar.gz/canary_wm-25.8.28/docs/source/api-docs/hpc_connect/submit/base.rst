.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


base
====

.. automodule:: hpc_connect.submit.base
   :members:
   :undoc-members:
   :show-inheritance:
