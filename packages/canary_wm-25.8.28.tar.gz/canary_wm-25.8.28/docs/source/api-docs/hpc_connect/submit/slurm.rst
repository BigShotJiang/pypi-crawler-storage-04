.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


slurm
=====

.. automodule:: hpc_connect.submit.slurm
   :members:
   :undoc-members:
   :show-inheritance:
