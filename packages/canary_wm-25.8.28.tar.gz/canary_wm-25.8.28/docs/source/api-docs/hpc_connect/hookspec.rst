.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


hookspec
========

.. automodule:: hpc_connect.hookspec
   :members:
   :undoc-members:
   :show-inheritance:
