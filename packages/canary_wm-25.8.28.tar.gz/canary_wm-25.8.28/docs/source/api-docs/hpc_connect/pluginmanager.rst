.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT


pluginmanager
=============

.. automodule:: hpc_connect.pluginmanager
   :members:
   :undoc-members:
   :show-inheritance:
