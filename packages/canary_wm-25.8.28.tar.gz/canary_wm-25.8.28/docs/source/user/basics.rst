.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT

.. _basics:

canary basics
=============

.. toctree::
   :maxdepth: 1

   basics.session
   basics.testfile
   basics.testcase
   basics.status
   basics.resource
   basics.runtime
