.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT

.. _configuration-overview:

Overview
========

Additional configuration is not required to run ``canary``.  To see the current configuration, issue

.. command-output:: canary config show

Configuration variables can be set on the command line or read from a
configuration file.
