.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT

.. _extending:

Extending canary
================

.. toctree::
   :maxdepth: 1

   extending.plugins
   extending.report
   extending.command
   extending.generator
