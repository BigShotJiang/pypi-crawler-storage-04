.. Copyright NTESS. See COPYRIGHT file for details.

   SPDX-License-Identifier: MIT

.. _presentation-technical-hpc:

HPC integration
===============

- Architecture diagram showcasing interaction with HPC schedulers and resource management.
