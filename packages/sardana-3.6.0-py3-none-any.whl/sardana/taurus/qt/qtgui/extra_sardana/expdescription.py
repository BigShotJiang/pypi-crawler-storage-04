#!/usr/bin/env python

##############################################################################
##
# This file is part of Sardana
##
# http://www.sardana-controls.org/
##
# Copyright 2011 CELLS / ALBA Synchrotron, Bellaterra, Spain
##
# Sardana is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
##
# Sardana is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Lesser General Public License for more details.
##
# You should have received a copy of the GNU Lesser General Public License
# along with Sardana.  If not, see <http://www.gnu.org/licenses/>.
# along with Sardana.  If not, see <http://www.gnu.org/licenses/>.
##
##############################################################################

"""This module provides widget for configuring the data acquisition and display of an experiment"""

__all__ = ["ExpDescriptionEditor"]


import json

import click

from taurus.qt.qtgui.base.taurusbase import _DEFAULT

try:
    # import QtWebEngineWidgets before QApplication is instantiated
    from taurus.external.qt import QtWebEngineWidgets  # noqa
except ImportError:
    pass
from taurus.external.qt import Qt, QtCore, QtGui, compat
import copy
import taurus
import taurus.core
from taurus.qt.qtgui.base import TaurusBaseWidget

import sardana
from sardana.taurus.qt.qtcore.tango.sardana.model import SardanaBaseProxyModel, SardanaTypeTreeItem
from sardana.sardanadefs import ElementType, TYPE_ACQUIRABLE_ELEMENTS
from taurus.qt.qtgui.util.ui import UILoadable

# Using a plain model and filtering and checking
# 'Acquirable' in item.itemData().interfaces is more elegant,
# but things don't get properly sorted...

# from taurus.qt.qtcore.tango.sardana.model import SardanaElementPlainModel


def _to_fqdn(name, logger=None):
    """Helper to convert name into a FQDN URI reference. Works for devices
    and attributes.
    Prior to sardana 2.4.0 Pool element references were using not unique full
    names e.g. pc255:10000/motor/motctrl20/1. This helper converts them into
    FQDN URI references e.g. tango://pc255.cells.es:10000/motor/motctrl20/1.
    It is similarly solved for attribute names.
    """
    full_name = name
    # try to use Taurus 4 to retrieve FQDN URI name
    try:
        from taurus.core.tango.tangovalidator import TangoDeviceNameValidator
        validated_name = TangoDeviceNameValidator().getNames(name)
        # it is not a device try as an attribute
        if not validated_name:
            from taurus.core.tango.tangovalidator import \
                TangoAttributeNameValidator
            validated_name = TangoAttributeNameValidator().getNames(name)
        if validated_name and validated_name[0]:
            full_name, _, _ = validated_name
    # if Taurus3 in use just continue
    except ImportError:
        pass
    if full_name != name and logger:
        msg = ("PQDN full name is deprecated in favor of FQDN full name. "
               "Re-apply pre-scan snapshot configuration in order to "
               "upgrade.")
        logger.warning(msg)
    return full_name


class SardanaAcquirableProxyModel(SardanaBaseProxyModel):
    #    ALLOWED_TYPES = 'Acquirable'
    #
    #    def filterAcceptsRow(self, sourceRow, sourceParent):
    #        sourceModel = self.sourceModel()
    #        idx = sourceModel.index(sourceRow, 0, sourceParent)
    #        item = idx.internalPointer()
    #        return 'Acquirable' in item.itemData().interfaces

    #    ALLOWED_TYPES = ['Motor', 'CTExpChannel', 'ZeroDExpChannel', 'OneDExpChannel',
    #                     'TwoDExpChannel', 'ComChannel', 'IORegister', 'PseudoMotor',
    #                     'PseudoCounter']

    ALLOWED_TYPES = [ElementType[t] for t in TYPE_ACQUIRABLE_ELEMENTS]

    def filterAcceptsRow(self, sourceRow, sourceParent):
        sourceModel = self.sourceModel()
        idx = sourceModel.index(sourceRow, 0, sourceParent)
        treeItem = idx.internalPointer()
        if isinstance(treeItem, SardanaTypeTreeItem):
            return treeItem.itemData() in self.ALLOWED_TYPES
        return True


def find_diff(first, second):
    """
    Return a dict of keys that differ with another config object.  If a value
    is not found in one fo the configs, it will be represented by KEYNOTFOUND.
    :param first: Fist configuration to diff.
    :param second: Second configuration to diff.
    :return: Dict of Key => (first.val, second.val)
    """

    KEYNOTFOUNDIN1 = 'KeyNotFoundInRemote'
    KEYNOTFOUNDIN2 = 'KeyNotFoundInLocal'

    # The GUI can not change these keys. They are changed by the server.
    SKIPKEYS = ['_controller_name', 'description', 'timer', 'monitor', 'ndim',
                'source']

    # These keys can have a list as value.
    SKIPLIST = ['scanfile', 'plot_axes', 'prescansnapshot', 'shape']

    DICT_TYPES = [taurus.core.util.containers.CaselessDict, dict]
    diff = {}
    sd1 = set(first)
    sd2 = set(second)

    # Keys missing in the second dict
    for key in sd1.difference(sd2):
        if key in SKIPKEYS:
            continue
        diff[key] = (first[key], KEYNOTFOUNDIN2)
    # Keys missing in the first dict
    for key in sd2.difference(sd1):
        if key in SKIPKEYS:
            continue
        diff[key] = (KEYNOTFOUNDIN1, second[key])

    # Check for differences
    for key in sd1.intersection(sd2):
        if key in SKIPKEYS:
            continue
        value1 = first[key]
        value2 = second[key]
        if type(value1) in DICT_TYPES:
            try:
                idiff = find_diff(value1, value2)
            except Exception:
                idiff = 'Error on processing'
            if len(idiff) > 0:
                diff[key] = idiff
        elif isinstance(value1, list) and key.lower() not in SKIPLIST:
            ldiff = []
            for v1, v2 in zip(value1, value2):
                try:
                    idiff = find_diff(v1, v2)
                except Exception:
                    idiff = 'Error on processing'
                ldiff.append(idiff)
            if len(ldiff) > 0:
                diff[key] = ldiff
        else:
            if value1 != value2:
                diff[key] = (first[key], second[key])
    return diff


@UILoadable(with_ui='ui')
class ExpDescriptionEditor(Qt.QWidget, TaurusBaseWidget):
    '''
    A widget for editing the configuration of a experiment (measurement groups,
    plot and storage parameters, etc).

    It receives a Sardana Door name as its model and gets/sets the configuration
    using the `ExperimentConfiguration` environmental variable for that Door.
    '''

    createExpConfChangedDialog = Qt.pyqtSignal()
    experimentConfigurationChanged = Qt.pyqtSignal(compat.PY_OBJECT)

    def __init__(self, parent=None, door=None):
        Qt.QWidget.__init__(self, parent)
        TaurusBaseWidget.__init__(self, 'ExpDescriptionEditor')
        self.loadUi()
        self.setMinimumWidth(320)
        self.ui.buttonBox.setStandardButtons(
            Qt.QDialogButtonBox.Reset | Qt.QDialogButtonBox.Apply)
        self.ui.buttonBox.button(Qt.QDialogButtonBox.Reset).setText('Reload')
        self.keep_editing = Qt.QCheckBox("Keep editing")
        self.ui.buttonBox.layout().insertWidget(2, self.keep_editing)
        
        newperspectivesDict = copy.deepcopy(
            self.ui.sardanaElementTree.KnownPerspectives)
        #newperspectivesDict[self.ui.sardanaElementTree.DftPerspective]['model'] = [SardanaAcquirableProxyModel, SardanaElementPlainModel]
        newperspectivesDict[self.ui.sardanaElementTree.DftPerspective][
            'model'][0] = SardanaAcquirableProxyModel
        # assign a copy because if just a key of this class memberwas modified,
        # all instances of this class would be affected
        self.ui.sardanaElementTree.KnownPerspectives = newperspectivesDict
        self.ui.sardanaElementTree._setPerspective(
            self.ui.sardanaElementTree.DftPerspective)

        self._localConfig = None
        self._originalConfiguration = None
        self._dirty = False
        self._dirtyMntGrps = set()

        self._warningWidget = self._getWarningWidget("")
        self.setContextMenuPolicy(Qt.Qt.ActionsContextMenu)

        self.mode = None
        self.edit_mode = Qt.QRadioButton("Edit mode")
        self.view_mode = Qt.QRadioButton("View mode")
        self.ui.verticalLayout_4.insertWidget(0, self.edit_mode)
        self.ui.verticalLayout_4.insertWidget(0, self.view_mode)
        self.edit_mode.toggled.connect(lambda: self.setMode(self.edit_mode))
        self.view_mode.toggled.connect(lambda: self.setMode(self.view_mode))
        self.view_mode.setChecked(True)
        # Pending event variables
        self._expConfChangedDialog = None

        self.createExpConfChangedDialog.connect(
            self._createExpConfChangedDialog)
        self.ui.activeMntGrpCB.activated['QString'].connect(
            self.changeActiveMntGrp)
        self.ui.createMntGrpBT.clicked.connect(
            self.createMntGrp)
        self.ui.deleteMntGrpBT.clicked.connect(
            self.deleteMntGrp)
        self.ui.compressionCB.currentIndexChanged['int'].connect(
            self.onCompressionCBChanged)
        self.ui.pathLE.textEdited.connect(
            self.onPathLEEdited)
        self.ui.filenameLE.textEdited.connect(
            self.onFilenameLEEdited)
        self.ui.scanIdReset.toggled.connect(self.scanIdReset_)
        self.ui.scanIdSet.toggled.connect(self.scanIdSet_)
        self.ui.scanIdLE.textEdited.connect(self.onScanIdEdited_)
        self.ui.channelEditor.getQModel().dataChanged.connect(
            self._updateButtonBox)
        self.ui.channelEditor.getQModel().modelReset.connect(
            self._updateButtonBox)
        preScanList = self.ui.preScanList
        preScanList.dataChangedSignal.connect(self.onPreScanSnapshotChanged)
        self.ui.choosePathBT.clicked.connect(
            self.onChooseScanDirButtonClicked)

        if door is not None:
            self.setModel(door)

        self.ui.buttonBox.clicked.connect(self.onDialogButtonClicked)

        # Taurus Configuration properties and delegates
        self.registerConfigDelegate(self.ui.channelEditor)
    
        
    def _setEnabledChannelEditor(self, enabled):
        # disable possibility to edit widget content
        # but maintain the widget itself enabled in order
        # to allow scrolling
        # https://www.qtcentre.org/threads/24614-Enabling-scroll-bars-in-disabled-QTableView
        channelEditor = self.ui.channelEditor
        table_view = channelEditor.tableView()
        for bar in channelEditor._toolBars:
            bar.setEnabled(enabled)
        if enabled:
            table_view.setSelectionMode(Qt.QAbstractItemView.ExtendedSelection)
            table_view.setFocusPolicy(Qt.Qt.StrongFocus)
            table_view.setEditTriggers(Qt.QAbstractItemView.DoubleClicked 
                                        | Qt.QAbstractItemView.EditKeyPressed 
                                        | Qt.QAbstractItemView.AnyKeyPressed)
        else:
            table_view.setSelectionMode(Qt.QAbstractItemView.NoSelection)
            table_view.setFocusPolicy(Qt.Qt.NoFocus)
            table_view.setEditTriggers(Qt.QTableWidget.NoEditTriggers)

    
    def _setEnabledPreScanList(self, enabled):
        # disable possibility to edit widget content
        # but maintain the widget itself enabled in order
        # to allow scrolling
        # https://www.qtcentre.org/threads/24614-Enabling-scroll-bars-in-disabled-QTableView
        preScanList = self.ui.preScanList
        if enabled:
            preScanList.setSelectionMode(Qt.QAbstractItemView.ExtendedSelection)
            preScanList.setFocusPolicy(Qt.Qt.StrongFocus)
            preScanList.setEditTriggers(Qt.QAbstractItemView.DoubleClicked 
                                        | Qt.QAbstractItemView.EditKeyPressed)
        else:
            preScanList.setSelectionMode(Qt.QAbstractItemView.NoSelection)
            preScanList.setFocusPolicy(Qt.Qt.NoFocus)
            preScanList.setEditTriggers(Qt.QTableWidget.NoEditTriggers)

    def setMode(self, mode):
        ignore_list = [
            "verticalLayout_3",  # radio buttons with mode control
            "tabWidget",  # tabWidget = widget for switching tabs
            "mntGrpTab",  # measurement group tab
            "verticalLayout",  # layout in measurement group tab
            "channelEditor",  # channelEditor in measurement group tab
            "tab_2",  # snapshot group tab
            "verticalLayout_6",  # layout in snapshot group tab
            "splitter",  # splitter in snapshot group tab
            "verticalLayout_2",  # drag and drop in snapshot group tab
            "layoutWidget",  # layout with preScanList in snapshot group tab
            "preScanList",  # preScanList in snapshot group tab
            "horizontalLayout_2",  # path widget in storage tab
            "formLayout",  # storage tab
            "scanIdLE", # ScanID Line Edit
        ]

        if mode == self.edit_mode and self.edit_mode.isChecked():
            enabled = True
            warning_msg = "You started editing experiment configuration. External changes will show a pop-up dialog."
        elif mode == self.view_mode and self.view_mode.isChecked():
            enabled = False
            warning_msg = ("This experiment configuration widget is in view mode. "
                           "Change mode to enable editing.")
        else:
            return
        [obj.setEnabled(enabled) for obj in {k: v for k, v in vars(self.ui).items() if k not in ignore_list}.values()]
        self._setEnabledChannelEditor(enabled)
        self._setEnabledPreScanList(enabled)
        self._updateWarningWidget(warning_msg)
        self.mode = mode


    def _updateWarningWidget(self, text):
        self.ui.horizontalLayout_3.removeWidget(self._warningWidget)
        self._warningWidget.deleteLater()
        self._warningWidget = None
        self._warningWidget = self._getWarningWidget(text)
        self.ui.horizontalLayout_3.insertWidget(2, self._warningWidget)

    def _getWarningWidget(self, text):
        w = Qt.QWidget()
        layout = QtGui.QHBoxLayout()
        w.setLayout(layout)
        icon = QtGui.QIcon.fromTheme('dialog-warning')
        pixmap = QtGui.QPixmap(icon.pixmap(QtCore.QSize(32, 32)))
        label_icon = QtGui.QLabel()
        label_icon.setPixmap(pixmap)
        label_icon.setMaximumSize(32, 32)
        label = QtGui.QLabel(text)
        label.setWordWrap(True)
        layout.addWidget(label_icon, 1)
        layout.addWidget(label, 5)
        return w

    def _getResumeText(self):
        msg_resume = '<p> Summary of differences: <ul>'
        mnt_grps = ''
        envs = ''
        for key in self._diff:
            if key == 'MntGrpConfigs':
                for names in self._diff['MntGrpConfigs']:
                    if mnt_grps != '':
                        mnt_grps += ', '
                    mnt_grps += '<b>{0}</b>'.format(names)
            else:
                if envs != '':
                    envs += ', '
                envs += '<b>{0}</b>'.format(key)
        values = ''
        if mnt_grps != '':
            values += '<li> Measurement Groups: {0}</li>'.format(mnt_grps)
        if envs != '':
            values += '<li> Enviroment variables: {0}</li>'.format(envs)

        msg_resume += values
        msg_resume += ' </ul> </p>'
        return msg_resume

    def _getDetialsText(self):
        msg_detials = 'Changes {key: [external, local], ...}\n'
        msg_detials += json.dumps(self._diff, sort_keys=True)
        return msg_detials

    def _createExpConfChangedDialog(self):
        msg_details = self._getDetialsText()
        msg_info = self._getResumeText()
        self._expConfChangedDialog = Qt.QMessageBox()
        self._expConfChangedDialog.setIcon(Qt.QMessageBox.Warning)
        self._expConfChangedDialog.setWindowTitle('External Changes')
        # text = '''
        # <p align='justify'>
        # The experiment configuration has been modified externally.<br/>
        # You can either:<br/> <l1><b>Load</b> the new configuration from the
        # door
        # (discarding local changes) or <b>Keep</b> your local configuration
        # (would eventually overwrite the external changes when applying).
        # </p>'''
        text = '''
        <p>The experiment configuration has been modified externally.<br>
        You can either:
        <ul>
        <li><strong>Load </strong>the new external configuration</li>
        <li><strong>Keep </strong>your local expconf configuration<br>
        (It can be eventually applied)</li>
        <li><strong>Switch to view mode </strong> to not be bothered by
        pop-ups (will discard eventual changes in you local
        expconf configuration)</li>
        </ul></p>
        '''
        self._expConfChangedDialog.setText(text)
        self._expConfChangedDialog.setTextFormat(QtCore.Qt.RichText)
        self._expConfChangedDialog.setInformativeText(msg_info)
        self._expConfChangedDialog.setDetailedText(msg_details)
        self._expConfChangedDialog.setStandardButtons(Qt.QMessageBox.Ok | Qt.QMessageBox.Ignore |
                                                      Qt.QMessageBox.Cancel)
        btn_ok = self._expConfChangedDialog.button(Qt.QMessageBox.Ok)
        btn_ok.setText('Load')
        btn_cancel = self._expConfChangedDialog.button(Qt.QMessageBox.Cancel)
        btn_cancel.setText('Keep')
        btn_cancel = self._expConfChangedDialog.button(Qt.QMessageBox.Ignore)
        btn_cancel.setText('Switch to view mode')
        result = self._expConfChangedDialog.exec_()
        self._expConfChangedDialog = None
        if result == Qt.QMessageBox.Ok:
            self._reloadConf(force=True)
        elif result == Qt.QMessageBox.Cancel:
            self.ui.buttonBox.setEnabled(True)
        elif result == Qt.QMessageBox.Ignore:
            self._reloadConf(force=True)
            self.setMode(self.view_mode)
            self.view_mode.setChecked(True)

    @QtCore.pyqtSlot()
    def _experimentConfigurationChanged(self):
        self._diff = ''
        try:
            self._diff = self._getDiff()
        except Exception as e:
            raise RuntimeError('Error on processing! {0}'.format(e))

        if len(self._diff) > 0:
            if self.mode == self.view_mode:
                self._reloadConf(force=True)
            else:
                if self._expConfChangedDialog is None:
                    if hasattr(self, 'createExpConfChangedDialog'):
                        self.createExpConfChangedDialog.emit()
                else:
                    msg_details = self._getDetialsText()
                    msg_info = self._getResumeText()
                    self._expConfChangedDialog.setInformativeText(msg_info)
                    self._expConfChangedDialog.setDetailedText(msg_details)

    def _getDiff(self):
        door = self.getModelObj()
        if door is None:
            return []

        new_conf = door.getExperimentConfiguration()
        old_conf = self._localConfig
        return find_diff(new_conf, old_conf)

    def getModelClass(self, *, key=_DEFAULT):
        '''reimplemented from :class:`TaurusBaseWidget`'''
        return taurus.core.taurusdevice.TaurusDevice

    def onChooseScanDirButtonClicked(self):
        ret = Qt.QFileDialog.getExistingDirectory(
            self, 'Choose directory for saving files', self.ui.pathLE.text())
        if ret:
            self.ui.pathLE.setText(ret)
            self.ui.pathLE.textEdited.emit(ret)

    def onDialogButtonClicked(self, button):
        role = self.ui.buttonBox.buttonRole(button)
        if role == Qt.QDialogButtonBox.ApplyRole:
            if not self.keep_editing.checkState():
                self.mode = self.view_mode
                self.view_mode.setChecked(True)
            if not self.writeExperimentConfiguration(ask=False):
                self._reloadConf(force=True)
            self.ui.scanIdReset.setChecked(False)
            self.ui.scanIdSet.setChecked(False)
        elif role == Qt.QDialogButtonBox.ResetRole:
            self._reloadConf()
            self.ui.scanIdReset.setChecked(False)
            self.ui.scanIdSet.setChecked(False)

    def closeEvent(self, event):
        '''This event handler receives widget close events'''
        if self.isDataChanged():
            self.writeExperimentConfiguration(ask=True)
        Qt.QWidget.closeEvent(self, event)

    def setModel(self, model):
        '''reimplemented from :class:`TaurusBaseWidget`'''
        TaurusBaseWidget.setModel(self, model)
        self._reloadConf(force=True)
        # set the model of some child widgets
        door = self.getModelObj()
        if door is None:
            return
        # @todo: get the tghost from the door model instead
        tghost = taurus.Authority().getNormalName()
        msname = door.macro_server.getFullName()
        self.ui.taurusModelTree.setModel(tghost)
        self.ui.sardanaElementTree.setModel(msname)
        door.experimentConfigurationChanged.connect(
            self._experimentConfigurationChanged)

    def _reloadConf(self, force=False):
        if not force and self.isDataChanged():
            op = Qt.QMessageBox.question(self, "Reload info from door",
                                         "If you reload, all current experiment configuration changes will be lost. Reload?",
                                         Qt.QMessageBox.Yes | Qt.QMessageBox.Cancel)
            if op != Qt.QMessageBox.Yes:
                return
        door = self.getModelObj()
        if door is None:
            return
        conf = door.getExperimentConfiguration()
        self._originalConfiguration = copy.deepcopy(conf)
        self.setLocalConfig(conf)
        # Flag as "dirty" if some config was changed during the set-up
        self._setDirty(self._localConfig != self._originalConfiguration)
        self._dirtyMntGrps = set()
        # set a list of available channels
        avail_channels = {}
        for ch_info in \
                list(door.macro_server.getExpChannelElements().values()):
            avail_channels[ch_info.full_name] = ch_info.getData()
        self.ui.channelEditor.getQModel().setAvailableChannels(avail_channels)
        # set a list of available triggers
        avail_triggers = {'software': {"name": "software"}}
        tg_elements = door.macro_server.getElementsOfType('TriggerGate')
        for tg_info in list(tg_elements.values()):
            avail_triggers[tg_info.full_name] = tg_info.getData()
        self.ui.channelEditor.getQModel().setAvailableTriggers(avail_triggers)
        self.experimentConfigurationChanged.emit(copy.deepcopy(conf))

    def _setDirty(self, dirty):
        self._dirty = dirty
        self._updateButtonBox()

    def isDataChanged(self):
        """Tells if the local data has been modified since it was last refreshed

        :return: (bool) True if he local data has been modified since it was last refreshed
        """
        return bool(self._dirty or self.ui.channelEditor.getQModel().isDataChanged() or self._dirtyMntGrps)

    def _updateButtonBox(self, *args, **kwargs):
        self.ui.buttonBox.setEnabled(self.isDataChanged())

    def getLocalConfig(self):
        return self._localConfig

    def setLocalConfig(self, conf):
        '''gets a ExpDescription dictionary and sets up the widget'''

        self._localConfig = conf

        # set the Channel Editor
        activeMntGrpName = self._localConfig['ActiveMntGrp'] or ''
        if activeMntGrpName in self._localConfig['MntGrpConfigs']:
            mgconfig = self._localConfig['MntGrpConfigs'][activeMntGrpName]
            self.ui.channelEditor.getQModel().setDataSource(mgconfig)
        else:
            self.ui.channelEditor.getQModel().setDataSource({})

        # set the measurement group ComboBox
        self.ui.activeMntGrpCB.clear()
        mntGrpLabels = []
        for _, mntGrpConf in list(self._localConfig['MntGrpConfigs'].items()):
            # get labels to visualize names with lower and upper case
            mntGrpLabels.append(mntGrpConf['label'])
        self.ui.activeMntGrpCB.addItems(sorted(mntGrpLabels))
        idx = self.ui.activeMntGrpCB.findText(activeMntGrpName,
                                              # case insensitive find
                                              Qt.Qt.MatchFixedString)
        self.ui.activeMntGrpCB.setCurrentIndex(idx)

        # set the system snapshot list
        # I get it before clearing because clear() changes the _localConfig
        psl = self._localConfig.get('PreScanSnapshot')
        # TODO: For Taurus 4 compatibility
        psl_fullname = []
        for name, display in psl:
            name = _to_fqdn(name, self)
            psl_fullname.append((name, display))

        self.ui.preScanList.clear()
        self.ui.preScanList.addModels(psl_fullname)

        # other settings
        self.ui.filenameLE.setText(", ".join(self._localConfig['ScanFile']))
        self.ui.pathLE.setText(self._localConfig['ScanDir'] or '')
        self.ui.compressionCB.setCurrentIndex(
            self._localConfig['DataCompressionRank'] + 1)
        self.ui.scanIdLE.setText(str(self._localConfig['ScanID'] + 1))

    def writeExperimentConfiguration(self, ask=True):
        '''sends the current local configuration to the door

        :param ask: (bool) If True (default) prompts the user before saving.
        '''

        if ask:
            op = Qt.QMessageBox.question(self, "Save configuration?",
                                         'Do you want to save the current configuration?\n(if not, any changes will be lost)',
                                         Qt.QMessageBox.Yes | Qt.QMessageBox.No)
            if op != Qt.QMessageBox.Yes:
                return False

        conf = self.getLocalConfig()

        # make sure that no empty measurement groups are written
        for mgname, mgconfig in list(conf.get('MntGrpConfigs', {}).items()):
            if mgconfig is not None and not mgconfig.get('controllers'):
                mglabel = mgconfig['label']
                Qt.QMessageBox.information(self, "Empty Measurement group",
                                           "The measurement group '%s' is empty. Fill it (or delete it) before applying" % mglabel,
                                           Qt.QMessageBox.Ok)
                self.changeActiveMntGrp(mgname)
                return False

        # check if the currently displayed mntgrp is changed
        if self.ui.channelEditor.getQModel().isDataChanged():
            self._dirtyMntGrps.add(self._localConfig['ActiveMntGrp'])

        mgconfs = conf.get('MntGrpConfigs', {})
        
        for mgname in self._dirtyMntGrps:
            mgconf = mgconfs[mgname]
            
        door = self.getModelObj()
        try:
            door.setExperimentConfiguration(conf, mnt_grps=self._dirtyMntGrps)
        except Exception as e:
            Qt.QMessageBox.critical(self, 'Wrong configuration',
                                    '{0}'.format(e))
            return False
        self._originalConfiguration = copy.deepcopy(conf)
        self._dirtyMntGrps = set()
        self.ui.channelEditor.getQModel().setDataChanged(False)
        self._setDirty(False)
        self.experimentConfigurationChanged.emit(copy.deepcopy(conf))
        return True

    @Qt.pyqtSlot('QString')
    def changeActiveMntGrp(self, activeMntGrpName):
        if self._localConfig is None:
            return
        if activeMntGrpName == self._localConfig['ActiveMntGrp']:
            return  # nothing changed
        if activeMntGrpName not in self._localConfig['MntGrpConfigs']:
            raise KeyError('Unknown measurement group "%s"' % activeMntGrpName)

        # add the previous measurement group to the list of "dirty" groups if
        # something was changed
        if self.ui.channelEditor.getQModel().isDataChanged():
            self._dirtyMntGrps.add(self._localConfig['ActiveMntGrp'])

        self._localConfig['ActiveMntGrp'] = activeMntGrpName

        i = self.ui.activeMntGrpCB.findText(activeMntGrpName,
                                            # case insensitive find
                                            Qt.Qt.MatchFixedString)
        self.ui.activeMntGrpCB.setCurrentIndex(i)
        mgconfig = self._localConfig['MntGrpConfigs'][activeMntGrpName]
        self.ui.channelEditor.getQModel().setDataSource(mgconfig)
        self._setDirty(True)

    def createMntGrp(self):
        '''creates a new Measurement Group'''

        if self._localConfig is None:
            return

        mntGrpName, ok = Qt.QInputDialog.getText(self, "New Measurement Group",
                                                 "Enter a name for the new measurement Group")
        if not ok:
            return
        mntGrpName = str(mntGrpName)

        # check that the given name is not an existing pool element
        ms = self.getModelObj().macro_server
        poolElementNames = [
            v.name for v in
            list(ms.getElementsWithInterface("PoolElement").values())]
        while mntGrpName in poolElementNames:
            msg = ("The name '%s' already is used for another pool element. "
                   "Please Choose a different one." % mntGrpName)
            Qt.QMessageBox.warning(self, "Cannot create Measurement group",
                                   msg, Qt.QMessageBox.Ok)
            msg = "Enter a name for the new measurement Group"
            mntGrpName, ok = Qt.QInputDialog.getText(self,
                                                     "New Measurement Group",
                                                     msg,
                                                     Qt.QLineEdit.Normal,
                                                     mntGrpName)
            if not ok:
                return
            mntGrpName = str(mntGrpName)

        # check that the measurement group is not already in the localConfig
        msg = ('A measurement group named "%s" already exists. A new one '
               'will not be created' % mntGrpName)
        if mntGrpName in self._localConfig['MntGrpConfigs']:
            Qt.QMessageBox.warning(self, "%s already exists" % mntGrpName,
                                   msg)
            return

        # add an empty configuration dictionary to the local config
        mgconfig = {'label': mntGrpName, 'controllers': {}}
        self._localConfig['MntGrpConfigs'][mntGrpName] = mgconfig
        # add the new measurement group to the list of "dirty" groups
        self._dirtyMntGrps.add(mntGrpName)
        # add the name to the combobox
        self.ui.activeMntGrpCB.addItem(mntGrpName)
        # make it the Active MntGrp
        self.changeActiveMntGrp(mntGrpName)

    def deleteMntGrp(self):
        '''creates a new Measurement Group'''
        activeMntGrpName = str(self.ui.activeMntGrpCB.currentText())
        op = Qt.QMessageBox.question(self, "Delete Measurement Group",
                                     "Remove the measurement group '%s'?" % activeMntGrpName,
                                     Qt.QMessageBox.Yes | Qt.QMessageBox.Cancel)
        if op != Qt.QMessageBox.Yes:
            return
        currentIndex = self.ui.activeMntGrpCB.currentIndex()
        if self._localConfig is None:
            return
        if activeMntGrpName not in self._localConfig['MntGrpConfigs']:
            raise KeyError('Unknown measurement group "%s"' % activeMntGrpName)

        # add the current measurement group to the list of "dirty" groups
        self._dirtyMntGrps.add(activeMntGrpName)

        self._localConfig['MntGrpConfigs'][activeMntGrpName] = None
        self.ui.activeMntGrpCB.setCurrentIndex(-1)
        self.ui.activeMntGrpCB.removeItem(currentIndex)
        self.ui.channelEditor.getQModel().setDataSource({})
        self._setDirty(True)

    @Qt.pyqtSlot('int')
    def onCompressionCBChanged(self, idx):
        if self._localConfig is None:
            return
        self._localConfig['DataCompressionRank'] = idx - 1
        self._setDirty(True)

    def onPathLEEdited(self, text):
        self._localConfig['ScanDir'] = str(text)
        self._setDirty(True)

    def onFilenameLEEdited(self, text):
        self._localConfig['ScanFile'] = [v.strip()
                                         for v in str(text).split(',')]
        self._setDirty(True)

    def scanIdReset_(self, value):
        if self.ui.scanIdSet.isChecked(): self.ui.scanIdSet.setChecked(not value)
        if value:
            self._localConfig['ScanID'] = 0
            self.ui.scanIdLE.setText("1")
            self._setDirty(True)
        else:
            self._reloadConf(force=True)

    def scanIdSet_(self, value):
        if self.ui.scanIdReset.isChecked(): self.ui.scanIdReset.setChecked(not value)
        self.ui.scanIdLE.setEnabled(value)
    
    def onScanIdEdited_(self, id):
        self._localConfig['ScanID'] = int(id) - 1
        self._setDirty(True)

    def onPreScanSnapshotChanged(self, items):
        door = self.getModelObj()
        ms = door.macro_server
        preScanList = []
        for e in items:
            nfo = ms.getElementInfo(e.src)
            if nfo is None:
                full_name = e.src
                display = e.display
            else:
                full_name = nfo.full_name
                display = nfo.name
            if full_name in [fn for fn, _ in preScanList]:
                msg = ("'{}' defined more than once in snapshot.\n"
                       + "Only one entry will be kept").format(display)
                Qt.QMessageBox.warning(
                    self, "Duplicated entry", msg, Qt.QMessageBox.Ok
                )
                continue
            preScanList.append((full_name, display))
        if len(preScanList) != len(items):
            # refresh the preScanList removing duplicated entries (if any)
            self.ui.preScanList.clear()
            self.ui.preScanList.addModels(preScanList)
        self._localConfig['PreScanSnapshot'] = preScanList
        self._setDirty(True)


def demo(model=None):
    """Experiment configuration"""
    #w = main_ChannelEditor()
    w = ExpDescriptionEditor()
    if model is None:
        from sardana.taurus.qt.qtgui.extra_macroexecutor import \
            TaurusMacroConfigurationDialog
        dialog = TaurusMacroConfigurationDialog(w)
        accept = dialog.exec_()
        if accept:
            model = str(dialog.doorComboBox.currentText())
    if model is not None:
        w.setModel(model)
    return w


@click.command("expconf")
@click.argument("door", required=False)
def expconf_cmd(door):
    """GUI for configuring experiments.
    
    Allows configuration of measurement groups, snapshot group
    and data storage.
    """
    import sys
    import taurus.qt.qtgui.application
    Application = taurus.qt.qtgui.application.TaurusApplication

    app = Application.instance()
    owns_app = app is None
    if owns_app:
        app = Application(app_name="expconf",
                          app_version=sardana.__version__,
                          org_name="sardana",
                          org_domain="sardana-controls.org",
        )

    if door is None:
        w = demo()
    else:
        w = demo(model=door)
    w.show()

    if owns_app:
        sys.exit(app.exec_())
    else:
        return w


def main():
    return expconf_cmd()


if __name__ == "__main__":
    main()
