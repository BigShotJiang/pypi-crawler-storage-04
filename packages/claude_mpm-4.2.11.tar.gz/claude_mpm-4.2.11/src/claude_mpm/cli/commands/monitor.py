"""
Monitor command implementation for claude-mpm.

WHY: This module provides CLI commands for managing the unified monitoring daemon,
providing a single stable way to launch all monitoring functionality including
HTTP dashboard, Socket.IO events, real AST analysis, and Claude Code hook ingestion.

DESIGN DECISIONS:
- Use UnifiedMonitorDaemon for single stable monitoring service
- Single port (8765) for all functionality
- Support both foreground and daemon modes
- Real AST analysis using CodeTreeAnalyzer
- Integrated dashboard and Socket.IO server
"""

from typing import Optional

from ...constants import MonitorCommands
from ...services.monitor.daemon import UnifiedMonitorDaemon
from ..shared import BaseCommand, CommandResult


class MonitorCommand(BaseCommand):
    """Monitor command for managing the unified monitoring daemon."""

    def __init__(self):
        super().__init__("monitor")
        self.daemon = None

    def validate_args(self, args) -> Optional[str]:
        """Validate command arguments."""
        # Monitor command allows no subcommand (defaults to status)
        if hasattr(args, "monitor_command") and args.monitor_command:
            valid_commands = [cmd.value for cmd in MonitorCommands]
            if args.monitor_command not in valid_commands:
                return f"Unknown monitor command: {args.monitor_command}. Valid commands: {', '.join(valid_commands)}"

        return None

    def run(self, args) -> CommandResult:
        """Execute the monitor command using unified monitoring daemon."""
        try:
            self.logger.info("Monitor command using unified monitoring daemon")

            # Handle default case (no subcommand) - default to status
            if not hasattr(args, "monitor_command") or not args.monitor_command:
                return self._status_monitor(args)

            # Route to specific monitor commands
            if args.monitor_command == MonitorCommands.START.value:
                return self._start_monitor(args)
            if args.monitor_command == MonitorCommands.STOP.value:
                return self._stop_monitor(args)
            if args.monitor_command == MonitorCommands.RESTART.value:
                return self._restart_monitor(args)
            if args.monitor_command == MonitorCommands.STATUS.value:
                return self._status_monitor(args)

            return CommandResult.error_result(
                f"Unknown monitor command: {args.monitor_command}"
            )

        except Exception as e:
            self.logger.error(f"Error executing monitor command: {e}", exc_info=True)
            return CommandResult.error_result(f"Error executing monitor command: {e}")

    def _start_monitor(self, args) -> CommandResult:
        """Start the unified monitor daemon."""
        port = getattr(args, "port", None)
        if port is None:
            port = 8765  # Default to 8765 for unified monitor
        host = getattr(args, "host", "localhost")
        daemon_mode = getattr(args, "daemon", False)  # Default to foreground

        self.logger.info(
            f"Starting unified monitor daemon on {host}:{port} (daemon: {daemon_mode})"
        )

        # Create unified monitor daemon
        self.daemon = UnifiedMonitorDaemon(
            host=host, port=port, daemon_mode=daemon_mode
        )

        # Check if already running
        if self.daemon.lifecycle.is_running():
            existing_pid = self.daemon.lifecycle.get_pid()
            return CommandResult.success_result(
                f"Unified monitor daemon already running with PID {existing_pid}",
                data={
                    "url": f"http://{host}:{port}",
                    "port": port,
                    "pid": existing_pid,
                },
            )

        # Start the daemon
        if self.daemon.start():
            return CommandResult.success_result(
                f"Unified monitor daemon started on {host}:{port}",
                data={"url": f"http://{host}:{port}", "port": port},
            )
        return CommandResult.error_result("Failed to start unified monitor daemon")

    def _stop_monitor(self, args) -> CommandResult:
        """Stop the unified monitor daemon."""
        self.logger.info("Stopping unified monitor daemon")

        # Create daemon instance to check status and stop
        daemon = UnifiedMonitorDaemon()

        if not daemon.lifecycle.is_running():
            return CommandResult.success_result("No unified monitor daemon running")

        # Stop the daemon
        if daemon.stop():
            return CommandResult.success_result("Unified monitor daemon stopped")
        return CommandResult.error_result("Failed to stop unified monitor daemon")

    def _restart_monitor(self, args) -> CommandResult:
        """Restart the unified monitor daemon."""
        self.logger.info("Restarting unified monitor daemon")

        # Create daemon instance
        daemon = UnifiedMonitorDaemon()

        # Restart the daemon
        if daemon.restart():
            return CommandResult.success_result("Unified monitor daemon restarted")
        return CommandResult.error_result("Failed to restart unified monitor daemon")

    def _status_monitor(self, args) -> CommandResult:
        """Get unified monitor daemon status."""
        verbose = getattr(args, "verbose", False)

        # Create daemon instance to check status
        daemon = UnifiedMonitorDaemon()
        status_data = daemon.status()

        # Format output message
        if status_data["running"]:
            message = f"Unified monitor daemon is running at http://{status_data['host']}:{status_data['port']}"
            if status_data.get("pid"):
                message += f" (PID: {status_data['pid']})"
        else:
            message = "Unified monitor daemon is not running"

        return CommandResult.success_result(message, data=status_data)


def manage_monitor(args):
    """
    Main entry point for monitor command.

    The monitor command manages the unified monitoring daemon that provides
    a single stable way to launch all monitoring functionality including
    HTTP dashboard, Socket.IO events, real AST analysis, and Claude Code hooks.
    """
    command = MonitorCommand()
    error = command.validate_args(args)

    if error:
        command.logger.error(error)
        print(f"Error: {error}")
        return 1

    result = command.run(args)

    if result.success:
        if result.message:
            print(result.message)
        if result.data and getattr(args, "verbose", False):
            import json

            print(json.dumps(result.data, indent=2))
        return 0
    if result.message:
        print(f"Error: {result.message}")
    return 1
