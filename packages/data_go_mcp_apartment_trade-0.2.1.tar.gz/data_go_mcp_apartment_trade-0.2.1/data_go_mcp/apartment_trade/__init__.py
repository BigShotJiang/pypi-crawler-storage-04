"""MCP server for Korea apartment trade data from data.go.kr"""

__version__ = "0.1.2"