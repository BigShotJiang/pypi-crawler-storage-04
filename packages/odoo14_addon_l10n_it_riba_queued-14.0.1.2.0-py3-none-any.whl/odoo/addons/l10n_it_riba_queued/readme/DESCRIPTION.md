**Italiano**

Pagare righe RiBa in modo asincrono.

Ogni riga verrà pagata in un job dedicato, così eventuali errori non bloccheranno il pagamento di altre righe.

**English**

Pay multiple C/O lines asynchronously.

Each C/O line will be paid in a dedicated job, this way any error won't prevent other lines' payment.
