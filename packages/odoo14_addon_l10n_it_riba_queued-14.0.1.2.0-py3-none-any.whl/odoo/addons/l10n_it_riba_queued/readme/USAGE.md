**Italiano**

Nella procedura di pagamento di righe multiple, premere "Pagamento asincrono".

**English**

In the multiple lines payment wizard, click "Pay Async".
