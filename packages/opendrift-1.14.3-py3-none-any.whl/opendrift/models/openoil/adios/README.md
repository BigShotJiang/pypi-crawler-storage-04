The oils in oils.xz are downloaded from https://github.com/OpenDrift/noaa-oil-data using harvest_oils.py. Re-run to update list.
