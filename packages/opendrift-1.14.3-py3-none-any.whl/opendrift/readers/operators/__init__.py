"""
Readers may be combined by using operators and the helper functions.
"""
