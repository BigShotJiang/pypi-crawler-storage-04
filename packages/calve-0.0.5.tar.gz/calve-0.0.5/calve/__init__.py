__version__ = "0.0.5"
__author__ = "Caleb Grant"
__email__ = "grantcaleb22@gmail.com"
__description__ = "Data management and processing tools for Iceberg tables."
