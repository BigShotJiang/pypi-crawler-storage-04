import sys


def hello_world():
    sys.stdout.write("Hello, world!")
