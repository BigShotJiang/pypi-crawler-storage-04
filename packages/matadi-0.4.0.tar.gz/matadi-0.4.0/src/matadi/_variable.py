import casadi

Variable = casadi.SX.sym
