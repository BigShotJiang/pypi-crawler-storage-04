<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ru_RU">
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="../views/components/about_dialog.py" line="42"/>
        <source>About Momovu</source>
        <translation type="unfinished">О Momovu</translation>
    </message>
    <message>
        <location filename="../views/components/about_dialog.py" line="54"/>
        <source>&lt;h2&gt;Momovu&lt;/h2&gt;</source>
        <translation type="unfinished">&lt;h2&gt;Momovu&lt;/h2&gt;</translation>
    </message>
    <message>
        <location filename="../views/components/about_dialog.py" line="62"/>
        <source>Version {version}</source>
        <translation type="unfinished">Версия {version}</translation>
    </message>
    <message>
        <location filename="../views/components/about_dialog.py" line="77"/>
        <source>A PDF viewer for book publishing workflows.

Preview and validate book layouts with precise margin visualization, trim lines, and specialized viewing modes for interior pages, covers, and dust jackets.</source>
        <translation type="unfinished">Просмотр PDF-файлов для издательских процессов.

Предварительный просмотр и проверка макетов книг с точной визуализацией полей, линий обрезки и специальными режимами просмотра для внутренних страниц, обложек и суперобложек.</translation>
    </message>
    <message>
        <location filename="../views/components/about_dialog.py" line="93"/>
        <source>&lt;p&gt;&lt;b&gt;Features:&lt;/b&gt;&lt;/p&gt;
        &lt;ul&gt;
        &lt;li&gt;Interior, Cover, and Dustjacket viewing modes&lt;/li&gt;
        &lt;li&gt;Margin and trim line visualization&lt;/li&gt;
        &lt;li&gt;Side-by-side page viewing&lt;/li&gt;
        &lt;li&gt;Presentation mode&lt;/li&gt;
        &lt;li&gt;Barcode area display&lt;/li&gt;
        &lt;li&gt;Fold line indicators&lt;/li&gt;
        &lt;/ul&gt;</source>
        <translation type="unfinished">&lt;p&gt;&lt;b&gt;Особенности:&lt;/b&gt;&lt;/p&gt;
&lt;ul&gt;
&lt;li&gt;Режимы просмотра внутреннего блока, обложки и суперобложки&lt;/li&gt;
&lt;li&gt;Визуализация поля и линии обрезки&lt;/li&gt;
&lt;li&gt;Просмотр страниц рядом&lt;/li&gt;
&lt;li&gt;Режим презентации&lt;/li&gt;
&lt;li&gt;Отображение области штрих-кода&lt;/li&gt;
&lt;li&gt;Индикаторы линий сгиба&lt;/li&gt;
&lt;/ul&gt;</translation>
    </message>
    <message>
        <location filename="../views/components/about_dialog.py" line="103"/>
        <source>&lt;p&gt;&lt;b&gt;Links:&lt;/b&gt;&lt;/p&gt;
        &lt;p&gt;• Main page: &lt;a href=&quot;https://momovu.org&quot;&gt;https://momovu.org&lt;/a&gt;&lt;/p&gt;
        &lt;p&gt;• Source code: &lt;a href=&quot;https://spacecruft.org/books/momovu&quot;&gt;https://spacecruft.org/books/momovu&lt;/a&gt;&lt;/p&gt;</source>
        <translation type="unfinished">&lt;p&gt;&lt;b&gt;Ссылки:&lt;/b&gt;&lt;/p&gt;
        &lt;p&gt;• Главная страница: &lt;a href=&quot;https://momovu.org&quot;&gt;https://momovu.org&lt;/a&gt;&lt;/p&gt;
        &lt;p&gt;• Исходный код: &lt;a href=&quot;https://spacecruft.org/books/momovu&quot;&gt;https://spacecruft.org/books/momovu&lt;/a&gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../views/components/about_dialog.py" line="113"/>
        <source>&lt;p&gt;&lt;b&gt;System Information:&lt;/b&gt;&lt;/p&gt;
        &lt;p&gt;• Python version: {python_version}&lt;/p&gt;
        &lt;p&gt;• PySide6 version: {pyside_version}&lt;/p&gt;</source>
        <translation type="unfinished">&lt;p&gt;&lt;b&gt;Системная информация:&lt;/b&gt;&lt;/p&gt;
        &lt;p&gt;• Версия Python: {python_version}&lt;/p&gt;
        &lt;p&gt;• Версия PySide6: {pyside_version}&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../views/components/about_dialog.py" line="124"/>
        <source>&lt;p&gt;&lt;b&gt;Legal:&lt;/b&gt;&lt;/p&gt;
        &lt;p&gt;Copyright © 2025 Jeff Moe&lt;br&gt;
        Licensed under the Apache License, Version 2.0&lt;/p&gt;</source>
        <translation type="unfinished">&lt;p&gt;&lt;b&gt;Правовая информация:&lt;/b&gt;&lt;/p&gt;
        &lt;p&gt;Авторское право © 2025 Jeff Moe&lt;br&gt;
        Лицензировано по лицензии Apache, версия 2.0&lt;/p&gt;</translation>
    </message>
</context>
<context>
    <name>DialogManager</name>
    <message>
        <location filename="../views/components/dialog_manager.py" line="62"/>
        <source>Open PDF</source>
        <translation type="unfinished">Открыть PDF</translation>
    </message>
    <message>
        <location filename="../views/components/dialog_manager.py" line="64"/>
        <source>PDF Files (*.pdf)</source>
        <translation type="unfinished">Файлы PDF (*.pdf)</translation>
    </message>
    <message>
        <location filename="../views/components/dialog_manager.py" line="109"/>
        <source>Go to Page</source>
        <translation type="unfinished">Перейти к странице</translation>
    </message>
    <message>
        <location filename="../views/components/dialog_manager.py" line="112"/>
        <source>Enter page number (1-{total_pages}):</source>
        <translation type="unfinished">Введите номер страницы (1-{total_pages}):</translation>
    </message>
</context>
<context>
    <name>FindBar</name>
    <message>
        <location filename="../views/components/find_bar.py" line="62"/>
        <source>Close find bar (Escape)</source>
        <translation>Закрыть панель поиска (Escape)</translation>
    </message>
    <message>
        <location filename="../views/components/find_bar.py" line="66"/>
        <source>Find:</source>
        <translation>Найти:</translation>
    </message>
    <message>
        <location filename="../views/components/find_bar.py" line="71"/>
        <source>Enter search text...</source>
        <translation>Введите текст для поиска...</translation>
    </message>
    <message>
        <location filename="../views/components/find_bar.py" line="79"/>
        <source>Previous result (Shift+F3)</source>
        <translation>Предыдущий результат (Shift+F3)</translation>
    </message>
    <message>
        <location filename="../views/components/find_bar.py" line="86"/>
        <source>Next result (F3)</source>
        <translation>Следующий результат (F3)</translation>
    </message>
    <message>
        <location filename="../views/components/find_bar.py" line="91"/>
        <location filename="../views/components/find_bar.py" line="188"/>
        <location filename="../views/components/find_bar.py" line="237"/>
        <location filename="../views/components/find_bar.py" line="271"/>
        <location filename="../views/components/find_bar.py" line="337"/>
        <source>No results</source>
        <translation>Нет результатов</translation>
    </message>
    <message>
        <location filename="../views/components/find_bar.py" line="101"/>
        <source>Case sensitive</source>
        <translation>С учетом регистра</translation>
    </message>
    <message>
        <location filename="../views/components/find_bar.py" line="105"/>
        <source>Whole words</source>
        <translation>Целые слова</translation>
    </message>
    <message>
        <location filename="../views/components/find_bar.py" line="109"/>
        <source>Regular expression</source>
        <translation>Регулярное выражение</translation>
    </message>
    <message numerus="yes">
        <location filename="../views/components/find_bar.py" line="277"/>
        <source>%n result</source>
        <translation>
            <numerusform>%n результат</numerusform>
            <numerusform>%n результата</numerusform>
            <numerusform>%n результатов</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="../views/components/find_bar.py" line="279"/>
        <source>%n results</source>
        <translation>
            <numerusform>%n результат</numerusform>
            <numerusform>%n результата</numerusform>
            <numerusform>%n результатов</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../views/components/find_bar.py" line="286"/>
        <source>%1 of %2</source>
        <translation>%1 из %2</translation>
    </message>
</context>
<context>
    <name>FontInfoDialog</name>
    <message>
        <location filename="../views/dialogs/font_info_dialog.py" line="39"/>
        <source>Font Information</source>
        <translation type="unfinished">Информация о шрифтах</translation>
    </message>
    <message>
        <location filename="../views/dialogs/font_info_dialog.py" line="67"/>
        <source>Font Name</source>
        <translation type="unfinished">Название шрифта</translation>
    </message>
    <message>
        <location filename="../views/dialogs/font_info_dialog.py" line="68"/>
        <source>Type</source>
        <translation type="unfinished">Тип</translation>
    </message>
    <message>
        <location filename="../views/dialogs/font_info_dialog.py" line="69"/>
        <source>Embedded</source>
        <translation type="unfinished">Встроенный</translation>
    </message>
    <message>
        <location filename="../views/dialogs/font_info_dialog.py" line="70"/>
        <source>Subset</source>
        <translation type="unfinished">Подмножество</translation>
    </message>
    <message>
        <location filename="../views/dialogs/font_info_dialog.py" line="71"/>
        <source>Encoding</source>
        <translation type="unfinished">Кодировка</translation>
    </message>
    <message>
        <location filename="../views/dialogs/font_info_dialog.py" line="115"/>
        <source>PyMuPDF is not installed. Please install it to view font information.</source>
        <translation type="unfinished">PyMuPDF не установлен. Пожалуйста, установите его для просмотра информации о шрифтах.</translation>
    </message>
    <message>
        <location filename="../views/dialogs/font_info_dialog.py" line="126"/>
        <source>Failed to open PDF: {error}</source>
        <translation type="unfinished">Не удалось открыть PDF: {error}</translation>
    </message>
    <message>
        <location filename="../views/dialogs/font_info_dialog.py" line="194"/>
        <source>Error extracting font information: {error}</source>
        <translation type="unfinished">Ошибка извлечения информации о шрифтах: {error}</translation>
    </message>
    <message>
        <location filename="../views/dialogs/font_info_dialog.py" line="203"/>
        <source>No fonts found in this PDF</source>
        <translation type="unfinished">В этом PDF не найдено шрифтов</translation>
    </message>
    <message>
        <location filename="../views/dialogs/font_info_dialog.py" line="211"/>
        <source>1 font found</source>
        <translation type="unfinished">Найден 1 шрифт</translation>
    </message>
    <message>
        <location filename="../views/dialogs/font_info_dialog.py" line="214"/>
        <source>{count} fonts found</source>
        <translation type="unfinished">Найдено {count} шрифтов</translation>
    </message>
    <message>
        <location filename="../views/dialogs/font_info_dialog.py" line="222"/>
        <source>Unexpected error: {error}</source>
        <translation type="unfinished">Неожиданная ошибка: {error}</translation>
    </message>
    <message>
        <location filename="../views/dialogs/font_info_dialog.py" line="252"/>
        <location filename="../views/dialogs/font_info_dialog.py" line="260"/>
        <source>Yes</source>
        <translation type="unfinished">Да</translation>
    </message>
    <message>
        <location filename="../views/dialogs/font_info_dialog.py" line="253"/>
        <location filename="../views/dialogs/font_info_dialog.py" line="261"/>
        <source>No</source>
        <translation type="unfinished">Нет</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Page: 0/0</source>
        <translation type="obsolete">Страница: 0/0</translation>
    </message>
    <message>
        <location filename="../views/main_window.py" line="314"/>
        <location filename="../views/main_window.py" line="1075"/>
        <source>Momovu</source>
        <translation type="unfinished">Momovu</translation>
    </message>
    <message>
        <location filename="../views/main_window.py" line="465"/>
        <source>Load Error</source>
        <translation type="unfinished">Ошибка загрузки</translation>
    </message>
    <message>
        <location filename="../views/main_window.py" line="511"/>
        <source>Rendering Error</source>
        <translation type="unfinished">Ошибка отображения</translation>
    </message>
    <message>
        <location filename="../views/main_window.py" line="512"/>
        <source>Failed to render page:
{error}</source>
        <translation type="unfinished">Не удалось отобразить страницу:
{error}</translation>
    </message>
    <message>
        <source>Page: {current}/{total}</source>
        <translation type="obsolete">Страница: {current}/{total}</translation>
    </message>
    <message>
        <location filename="../views/main_window.py" line="577"/>
        <source>File Dialog Error</source>
        <translation type="unfinished">Ошибка диалога файлов</translation>
    </message>
    <message>
        <location filename="../views/main_window.py" line="578"/>
        <source>Failed to open file dialog:
{error}</source>
        <translation type="unfinished">Не удалось открыть диалоговое окно:
{error}</translation>
    </message>
    <message>
        <location filename="../views/main_window.py" line="757"/>
        <source>No Document</source>
        <translation type="unfinished">Нет документа</translation>
    </message>
    <message>
        <location filename="../views/main_window.py" line="758"/>
        <source>Please open a PDF document first to view font information.</source>
        <translation type="unfinished">Пожалуйста, сначала откройте PDF-документ для просмотра информации о шрифтах.</translation>
    </message>
    <message>
        <location filename="../views/main_window.py" line="774"/>
        <source>Error</source>
        <translation type="unfinished">Ошибка</translation>
    </message>
    <message>
        <location filename="../views/main_window.py" line="775"/>
        <source>Could not determine the PDF file path.</source>
        <translation type="unfinished">Не удалось определить путь к файлу PDF.</translation>
    </message>
    <message>
        <location filename="../views/main_window.py" line="1546"/>
        <source>File Not Found</source>
        <translation type="unfinished">Файл не найден</translation>
    </message>
    <message>
        <location filename="../views/main_window.py" line="1547"/>
        <source>The file could not be found:
{path}</source>
        <translation type="unfinished">Файл не найден:
{path}</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="42"/>
        <source>&amp;File</source>
        <translation type="unfinished">&amp;Файл</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="46"/>
        <source>&amp;Open...</source>
        <translation type="unfinished">&amp;Открыть...</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="74"/>
        <source>Open a PDF file (Ctrl+O)</source>
        <translation type="unfinished">Открыть PDF-файл (Ctrl+O)</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="81"/>
        <source>Open &amp;Recent</source>
        <translation type="unfinished">О&amp;ткрыть недавние</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="84"/>
        <source>Open recently used files</source>
        <translation type="unfinished">Открыть недавно использованные файлы</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="91"/>
        <source>&amp;Close</source>
        <translation type="unfinished">&amp;Закрыть</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="97"/>
        <source>Close the current document (Ctrl+W)</source>
        <translation type="unfinished">Закрыть текущий документ (Ctrl+W)</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="108"/>
        <source>&amp;Preferences...</source>
        <translation type="unfinished">&amp;Настройки...</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="113"/>
        <source>Open preferences dialog</source>
        <translation type="unfinished">Открыть диалог настроек</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="120"/>
        <source>E&amp;xit</source>
        <translation type="unfinished">Вы&amp;йти</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="129"/>
        <source>&amp;Edit</source>
        <translation>&amp;Правка</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="133"/>
        <source>&amp;Copy</source>
        <translation>&amp;Копировать</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="138"/>
        <source>Copy selected text (Ctrl+C)</source>
        <translation>Копировать выделенный текст (Ctrl+C)</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="154"/>
        <source>&amp;Find...</source>
        <translation>&amp;Найти...</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="159"/>
        <source>Find text in document (Ctrl+F)</source>
        <translation>Найти текст в документе (Ctrl+F)</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="172"/>
        <source>&amp;View</source>
        <translation type="unfinished">П&amp;росмотр</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="175"/>
        <source>&amp;Fullscreen</source>
        <translation type="unfinished">По&amp;лный экран</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="182"/>
        <source>&amp;Presentation Mode</source>
        <translation type="unfinished">Р&amp;ежим презентации</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="192"/>
        <source>&amp;Side by Side</source>
        <translation type="unfinished">&amp;Бок о бок</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="201"/>
        <source>Show &amp;Margins</source>
        <translation type="unfinished">По&amp;казать поля</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="209"/>
        <source>Show &amp;Trim Lines</source>
        <translation type="unfinished">Пок&amp;азать линии обрезки</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="218"/>
        <source>Show &amp;Barcode</source>
        <translation type="unfinished">Показат&amp;ь штрих-код</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="226"/>
        <source>Show Fo&amp;ld Lines</source>
        <translation type="unfinished">Показать л&amp;инии сгиба</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="235"/>
        <source>Show Bl&amp;eed Lines</source>
        <translation type="unfinished">Показать ли&amp;нии выпуска под обрез</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="245"/>
        <source>Show bleed lines at page edges (Ctrl+R)</source>
        <translation type="unfinished">Показывать линии выпуска под обрез на краях страниц (Ctrl+R)</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="249"/>
        <source>Show G&amp;utter</source>
        <translation type="unfinished">Показать &amp;корешковое поле</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="259"/>
        <source>Show gutter margin for interior documents (Ctrl+U)</source>
        <translation type="unfinished">Показать корешковое поле для внутренних документов (Ctrl+U)</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="264"/>
        <source>&amp;Go to Page...</source>
        <translation>Перейти к &amp;странице...</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="270"/>
        <source>Go to a specific page (Ctrl+G)</source>
        <translation>Перейти к определенной странице (Ctrl+G)</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="279"/>
        <source>&amp;Document</source>
        <translation type="unfinished">&amp;Документ</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="282"/>
        <source>&amp;Interior</source>
        <translation type="unfinished">&amp;Внутренний блок</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="288"/>
        <source>&amp;Cover</source>
        <translation type="unfinished">Обло&amp;жка</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="294"/>
        <source>&amp;Dustjacket</source>
        <translation type="unfinished">&amp;Суперобложка</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="302"/>
        <source>&amp;Calculator...</source>
        <translation>&amp;Калькулятор...</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="309"/>
        <source>Calculate spine width and document dimensions</source>
        <translation>Рассчитать ширину корешка и размеры документа</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="314"/>
        <source>&amp;Font Information...</source>
        <translation type="unfinished">Ин&amp;формация о шрифтах...</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="321"/>
        <source>Show font information for the current PDF</source>
        <translation type="unfinished">Показать информацию о шрифтах для текущего PDF</translation>
    </message>
    <message>
        <source>&amp;Spine Width Calculator...</source>
        <translation type="obsolete">Кальк&amp;улятор ширины корешка...</translation>
    </message>
    <message>
        <source>Calculate spine width based on page count</source>
        <translation type="obsolete">Рассчитайте ширину корешка на основе количества страниц</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="332"/>
        <source>&amp;Help</source>
        <translation type="unfinished">По&amp;мощь</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="335"/>
        <source>&amp;About</source>
        <translation type="unfinished">&amp;О программе</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="340"/>
        <source>&amp;Keyboard Shortcuts</source>
        <translation type="unfinished">&amp;Горячие клавиши</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="439"/>
        <location filename="../views/components/menu_builder.py" line="477"/>
        <source>No Recent Files</source>
        <translation type="unfinished">Недавние файлы отсутствуют</translation>
    </message>
    <message>
        <location filename="../views/components/menu_builder.py" line="472"/>
        <source>&amp;Clear Recent Files</source>
        <translation type="unfinished">О&amp;чистить недавние файлы</translation>
    </message>
    <message>
        <location filename="../views/components/toolbar_builder.py" line="106"/>
        <source>First</source>
        <translation type="unfinished">Первый</translation>
    </message>
    <message>
        <location filename="../views/components/toolbar_builder.py" line="124"/>
        <source>Go to first page (Home)</source>
        <translation type="unfinished">Перейти на первую страницу (Home)</translation>
    </message>
    <message>
        <location filename="../views/components/toolbar_builder.py" line="129"/>
        <source>Previous</source>
        <translation type="unfinished">Предыдущий</translation>
    </message>
    <message>
        <location filename="../views/components/toolbar_builder.py" line="149"/>
        <source>Go to previous page</source>
        <translation type="unfinished">Вернуться на предыдущую страницу</translation>
    </message>
    <message>
        <location filename="../views/components/toolbar_builder.py" line="154"/>
        <source>Next</source>
        <translation type="unfinished">Далее</translation>
    </message>
    <message>
        <location filename="../views/components/toolbar_builder.py" line="172"/>
        <source>Go to next page</source>
        <translation type="unfinished">Перейти на следующую страницу</translation>
    </message>
    <message>
        <location filename="../views/components/toolbar_builder.py" line="177"/>
        <source>Last</source>
        <translation type="unfinished">Последний</translation>
    </message>
    <message>
        <location filename="../views/components/toolbar_builder.py" line="195"/>
        <source>Go to last page (End)</source>
        <translation type="unfinished">Перейти на последнюю страницу (Конец)</translation>
    </message>
    <message>
        <location filename="../views/components/toolbar_builder.py" line="202"/>
        <source>Page:</source>
        <translation type="unfinished">Страница:</translation>
    </message>
    <message>
        <location filename="../views/components/toolbar_builder.py" line="211"/>
        <source>Current page number</source>
        <translation type="unfinished">Номер текущей страницы</translation>
    </message>
    <message>
        <location filename="../views/components/toolbar_builder.py" line="221"/>
        <source>Pages:</source>
        <translation type="unfinished">Страницы:</translation>
    </message>
    <message>
        <location filename="../views/components/toolbar_builder.py" line="232"/>
        <source>Number of pages for spine width calculation</source>
        <translation type="unfinished">Количество страниц для расчёта ширины корешка</translation>
    </message>
    <message>
        <location filename="../views/components/toolbar_builder.py" line="242"/>
        <source>Zoom In</source>
        <translation type="unfinished">Увеличить</translation>
    </message>
    <message>
        <location filename="../views/components/toolbar_builder.py" line="251"/>
        <source>Zoom in (Ctrl++)</source>
        <translation type="unfinished">Увеличить (Ctrl++)</translation>
    </message>
    <message>
        <location filename="../views/components/toolbar_builder.py" line="256"/>
        <source>Zoom Out</source>
        <translation type="unfinished">Уменьшить</translation>
    </message>
    <message>
        <location filename="../views/components/toolbar_builder.py" line="265"/>
        <source>Zoom out (Ctrl+-)</source>
        <translation type="unfinished">Уменьшить (Ctrl+-)</translation>
    </message>
    <message>
        <location filename="../views/components/toolbar_builder.py" line="270"/>
        <source>Fit Page</source>
        <translation type="unfinished">Подогнать страницу</translation>
    </message>
    <message>
        <location filename="../views/components/toolbar_builder.py" line="288"/>
        <source>Fit page to window (Ctrl+0)</source>
        <translation type="unfinished">Подогнать страницу под окно (Ctrl+0)</translation>
    </message>
</context>
<context>
    <name>PreferencesDialog</name>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="79"/>
        <source>Preferences</source>
        <translation type="unfinished">Настройки</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="98"/>
        <source>General</source>
        <translation type="unfinished">Общие</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="99"/>
        <source>Language</source>
        <translation type="unfinished">Язык</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="100"/>
        <source>Colors</source>
        <translation type="unfinished">Цвета</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="101"/>
        <source>Formulas</source>
        <translation>Формулы</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="102"/>
        <source>Dimensions</source>
        <translation type="unfinished">Размеры</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="103"/>
        <source>Recent Files</source>
        <translation type="unfinished">Недавние файлы</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="119"/>
        <source>Reset all settings to default values</source>
        <translation type="unfinished">Сбросить все настройки на значения по умолчанию</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="134"/>
        <source>Auto-fit on document load</source>
        <translation type="unfinished">Автоматическая подгонка при загрузке документа</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="135"/>
        <source>Fit Options:</source>
        <translation type="unfinished">Параметры подбора:</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="137"/>
        <source>Auto-fit on window resize</source>
        <translation type="unfinished">Автоматическая подгонка при изменении размера окна</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="146"/>
        <source>Zoom Increment:</source>
        <translation type="unfinished">Шаг масштабирования:</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="149"/>
        <source>Enable smooth scrolling</source>
        <translation type="unfinished">Включить плавную прокрутку</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="150"/>
        <source>Scrolling:</source>
        <translation type="unfinished">Прокрутка:</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="154"/>
        <source> pixels</source>
        <translation type="unfinished"> пикселей</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="155"/>
        <source>Scroll Speed:</source>
        <translation type="unfinished">Скорость прокрутки:</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="158"/>
        <source>&lt;b&gt;Performance&lt;/b&gt;</source>
        <translation type="unfinished">&lt;b&gt;Производительность&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="162"/>
        <source> pages</source>
        <translation type="unfinished"> страниц</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="163"/>
        <source>Max Cached Pages:</source>
        <translation type="unfinished">Максимальное количество кэшированных страниц:</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="168"/>
        <source>Max Cache Memory:</source>
        <translation type="unfinished">Максимальный объем кэш-памяти:</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="186"/>
        <source>Margin Overlay</source>
        <translation type="unfinished">Наложение полей</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="187"/>
        <source>Barcode Area</source>
        <translation type="unfinished">Область штрих-кода</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="188"/>
        <location filename="../views/components/preferences_dialog.py" line="221"/>
        <source>Fold Lines</source>
        <translation type="unfinished">Линии сгиба</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="189"/>
        <location filename="../views/components/preferences_dialog.py" line="222"/>
        <source>Trim Lines</source>
        <translation type="unfinished">Линии обрезки</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="190"/>
        <location filename="../views/components/preferences_dialog.py" line="223"/>
        <source>Bleed Lines</source>
        <translation type="unfinished">Линии выпуска под обрез</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="191"/>
        <source>Gutter</source>
        <translation type="unfinished">Корешковое поле</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="210"/>
        <source>Opacity:</source>
        <translation type="unfinished">Непрозрачность:</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="214"/>
        <location filename="../views/components/preferences_dialog.py" line="231"/>
        <source>{label}:</source>
        <translation type="unfinished">{label}:</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="217"/>
        <source>&lt;b&gt;Line Widths&lt;/b&gt;</source>
        <translation type="unfinished">&lt;b&gt;Ширина линий&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="240"/>
        <source>Protanopia</source>
        <translation type="unfinished">Протанопия</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="243"/>
        <source>Apply colors optimized for red-blind vision</source>
        <translation type="unfinished">Применить цвета, оптимизированные для протанопии</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="249"/>
        <source>Deuteranopia</source>
        <translation type="unfinished">Дейтеранопия</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="252"/>
        <source>Apply colors optimized for green-blind vision</source>
        <translation type="unfinished">Применить цвета, оптимизированные для дейтеранопии</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="258"/>
        <source>Tritanopia</source>
        <translation type="unfinished">Тританопия</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="261"/>
        <source>Apply colors optimized for blue-blind vision</source>
        <translation type="unfinished">Применить цвета, оптимизированные для тританопии</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="282"/>
        <source>Recently opened PDF files:</source>
        <translation type="unfinished">Недавно открытые PDF-файлы:</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="293"/>
        <source>Remove Selected</source>
        <translation type="unfinished">Удалить выбранные</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="301"/>
        <source>Clear All Recent Files</source>
        <translation type="unfinished">Очистить все недавние файлы</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="337"/>
        <source>Interface Language:</source>
        <translation type="unfinished">Язык интерфейса:</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="344"/>
        <source>&lt;i&gt;Note: Changing the language requires restarting the application.&lt;/i&gt;</source>
        <translation type="unfinished">&lt;i&gt;Примечание: Изменение языка требует перезапуска приложения.&lt;/i&gt;</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="356"/>
        <source>&lt;b&gt;Supported Languages:&lt;/b&gt;&lt;br&gt;• Right-to-left languages (Arabic) are fully supported&lt;br&gt;• CJK languages (Chinese, Japanese, Korean) use system fonts&lt;br&gt;• All number and date formatting follows the selected locale</source>
        <translation type="unfinished">&lt;b&gt;Поддерживаемые языки:&lt;/b&gt;&lt;br&gt;• Языки с написанием справа налево (арабский) полностью поддерживаются&lt;br&gt;• Языки CJK (китайский, японский, корейский) используют системные шрифты&lt;br&gt;• Форматирование всех чисел и дат соответствует выбранной локали</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="378"/>
        <source>&lt;i&gt;&lt;b&gt;Disclaimer:&lt;/b&gt; These formulas are approximations based on publicly available information. This application is not affiliated with or endorsed by Lulu, Lightning Source, or any printing service. Always verify calculations with your printer&apos;s official tools before submitting files for production.&lt;/i&gt;</source>
        <translation>&lt;i&gt;&lt;b&gt;Отказ от ответственности:&lt;/b&gt; Эти формулы являются приближениями, основанными на общедоступной информации. Это приложение не связано и не одобрено Lulu, Lightning Source или любой службой печати. Всегда проверяйте расчеты с помощью официальных инструментов вашей типографии перед отправкой файлов в производство.&lt;/i&gt;</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="395"/>
        <source>&lt;b&gt;Printer Formula Selection&lt;/b&gt;</source>
        <translation>&lt;b&gt;Выбор формулы принтера&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="403"/>
        <source>Select the printer formula to use for calculating spine width. Different printers use different formulas based on their paper and binding methods.</source>
        <translation>Выберите формулу принтера для расчета ширины корешка. Разные принтеры используют разные формулы в зависимости от бумаги и методов переплета.</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="411"/>
        <source>Printer Formula</source>
        <translation>Формула принтера</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="415"/>
        <source>Lulu</source>
        <translation>Lulu</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="421"/>
        <source>Standard Lulu formula: (pages / 17.48) + 1.524mm
Works for all Lulu paper types</source>
        <translation>Стандартная формула Lulu: (страницы / 17.48) + 1.524мм
Работает для всех типов бумаги Lulu</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="425"/>
        <source>Lightning Source</source>
        <translation>Lightning Source</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="431"/>
        <source>Lightning Source formula with variable paper weights.
Requires selecting paper weight for accurate calculation.</source>
        <translation>Формула Lightning Source с переменной плотностью бумаги.
Требует выбора плотности бумаги для точного расчета.</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="439"/>
        <source>Paper Weight (Lightning Source)</source>
        <translation>Плотность бумаги (Lightning Source)</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="443"/>
        <source>38 lb (Groundwood)</source>
        <translation>38 фунтов (Древесная масса)</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="444"/>
        <source>50 lb (Standard White/Creme)</source>
        <translation>50 фунтов (Стандартная белая/кремовая)</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="445"/>
        <source>70 lb (Thick White)</source>
        <translation>70 фунтов (Толстая белая)</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="447"/>
        <source>Paper Weight:</source>
        <translation>Плотность бумаги:</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="457"/>
        <source>&lt;b&gt;Paper Weight Guide:&lt;/b&gt;&lt;br&gt;• &lt;b&gt;38 lb:&lt;/b&gt; Thinner groundwood paper (~550 pages/inch)&lt;br&gt;• &lt;b&gt;50 lb:&lt;/b&gt; Standard white or creme paper (~472 pages/inch)&lt;br&gt;• &lt;b&gt;70 lb:&lt;/b&gt; Thicker white paper (~340 pages/inch)</source>
        <translation>&lt;b&gt;Руководство по плотности бумаги:&lt;/b&gt;&lt;br&gt;• &lt;b&gt;38 фунтов:&lt;/b&gt; Более тонкая бумага из древесной массы (~550 страниц/дюйм)&lt;br&gt;• &lt;b&gt;50 фунтов:&lt;/b&gt; Стандартная белая или кремовая бумага (~472 страницы/дюйм)&lt;br&gt;• &lt;b&gt;70 фунтов:&lt;/b&gt; Более толстая белая бумага (~340 страниц/дюйм)</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="487"/>
        <source>Configure dimension settings for margins, bleeds, and other measurements. All values are in millimeters (mm).</source>
        <translation type="unfinished">Настроить параметры размеров для создания документов</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="501"/>
        <source>&lt;b&gt;Safety Margins&lt;/b&gt;</source>
        <translation type="unfinished">&lt;b&gt;Поля безопасности&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="510"/>
        <source>Minimum distance from trim edge for safe content placement</source>
        <translation type="unfinished">Минимальное расстояние от края обреза для безопасного размещения контента</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="511"/>
        <source>Safety Margin:</source>
        <translation type="unfinished">Поле безопасности (мм):</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="515"/>
        <source>&lt;b&gt;Bleed Areas&lt;/b&gt;</source>
        <translation type="unfinished">&lt;b&gt;Области выпуска под обрез&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="524"/>
        <source>Bleed area for paperback covers (extends beyond trim edge)</source>
        <translation type="unfinished">Область выпуска под обрез для мягких обложек (выходит за край обреза)</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="525"/>
        <source>Cover Bleed:</source>
        <translation type="unfinished">Выпуск под обрез обложки (мм):</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="534"/>
        <source>Bleed area for hardcover dustjackets (extends beyond trim edge)</source>
        <translation type="unfinished">Область выпуска под обрез для суперобложек твердого переплета (выходит за край обреза)</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="535"/>
        <source>Dustjacket Bleed:</source>
        <translation type="unfinished">Выпуск под обрез суперобложки (мм):</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="539"/>
        <source>&lt;b&gt;Barcode Dimensions&lt;/b&gt;</source>
        <translation type="unfinished">&lt;b&gt;Размеры штрих-кода&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="546"/>
        <source>Width of the ISBN barcode area</source>
        <translation type="unfinished">Ширина области штрих-кода ISBN</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="547"/>
        <source>Barcode Width:</source>
        <translation type="unfinished">Ширина штрих-кода (мм):</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="554"/>
        <source>Height of the ISBN barcode area</source>
        <translation type="unfinished">Высота области штрих-кода ISBN</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="555"/>
        <source>Barcode Height:</source>
        <translation type="unfinished">Высота штрих-кода (мм):</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="559"/>
        <source>&lt;b&gt;Dustjacket Settings&lt;/b&gt;</source>
        <translation type="unfinished">&lt;b&gt;Настройки суперобложки&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="568"/>
        <source>Width of front and back dustjacket flaps</source>
        <translation type="unfinished">Ширина передних и задних клапанов суперобложки</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="569"/>
        <source>Flap Width:</source>
        <translation type="unfinished">Ширина клапана суперобложки (мм):</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="578"/>
        <source>Safety margin at dustjacket fold lines</source>
        <translation type="unfinished">Поле безопасности на линиях сгиба суперобложки</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="579"/>
        <source>Fold Safety Margin:</source>
        <translation type="unfinished">Поле безопасности сгиба суперобложки (мм):</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="645"/>
        <source>Choose {type} Color</source>
        <translation type="unfinished">Выберите {type} цвет</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="716"/>
        <source>Clear Recent Files</source>
        <translation type="unfinished">Очистить недавние файлы</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="717"/>
        <source>Are you sure you want to clear all recent files?</source>
        <translation type="unfinished">Вы действительно хотите очистить все недавние файлы?</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="730"/>
        <source>Reset to Defaults</source>
        <translation type="unfinished">Сбросить настройки на значения по умолчанию</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="733"/>
        <source>Are you sure you want to reset all settings to their default values?

This action cannot be undone.</source>
        <translation type="unfinished">Вы уверены, что хотите сбросить все настройки до значений по умолчанию?

Это действие нельзя отменить.</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="745"/>
        <source>Settings Reset</source>
        <translation type="unfinished">Сброс настроек</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="746"/>
        <source>All settings have been reset to their default values.</source>
        <translation type="unfinished">Все настройки были сброшены на значения по умолчанию.</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="969"/>
        <source>Restart Required</source>
        <translation type="unfinished">Требуется перезапуск</translation>
    </message>
    <message>
        <location filename="../views/components/preferences_dialog.py" line="972"/>
        <source>The language change will take effect after restarting the application.</source>
        <translation type="unfinished">Изменение языка вступит в силу после перезапуска приложения.</translation>
    </message>
</context>
<context>
    <name>ShortcutsDialog</name>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="38"/>
        <location filename="../lib/shortcuts_dialog.py" line="50"/>
        <source>Keyboard Shortcuts</source>
        <translation type="unfinished">Горячие клавиши</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="58"/>
        <source>Category</source>
        <translation type="unfinished">Категория</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="58"/>
        <source>Action</source>
        <translation type="unfinished">Действие</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="59"/>
        <source>Shortcut</source>
        <translation type="unfinished">Сочетание клавиш</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="90"/>
        <location filename="../lib/shortcuts_dialog.py" line="91"/>
        <location filename="../lib/shortcuts_dialog.py" line="92"/>
        <source>File</source>
        <translation type="unfinished">Файл</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="90"/>
        <source>Open Document</source>
        <translation type="unfinished">Открыть документ</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="91"/>
        <source>Close Document</source>
        <translation type="unfinished">Закрыть документ</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="92"/>
        <source>Exit Application</source>
        <translation type="unfinished">Выход из приложения</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="94"/>
        <location filename="../lib/shortcuts_dialog.py" line="95"/>
        <location filename="../lib/shortcuts_dialog.py" line="96"/>
        <location filename="../lib/shortcuts_dialog.py" line="97"/>
        <source>Edit</source>
        <translation type="unfinished">Правка</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="94"/>
        <source>Copy selected text</source>
        <translation>Копировать выделенный текст</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="95"/>
        <source>Find text in document</source>
        <translation>Найти текст в документе</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="96"/>
        <source>Find next result</source>
        <translation>Найти следующий результат</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="97"/>
        <source>Find previous result</source>
        <translation>Найти предыдущий результат</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="99"/>
        <location filename="../lib/shortcuts_dialog.py" line="100"/>
        <location filename="../lib/shortcuts_dialog.py" line="101"/>
        <location filename="../lib/shortcuts_dialog.py" line="103"/>
        <location filename="../lib/shortcuts_dialog.py" line="107"/>
        <location filename="../lib/shortcuts_dialog.py" line="108"/>
        <location filename="../lib/shortcuts_dialog.py" line="109"/>
        <location filename="../lib/shortcuts_dialog.py" line="110"/>
        <location filename="../lib/shortcuts_dialog.py" line="112"/>
        <location filename="../lib/shortcuts_dialog.py" line="117"/>
        <location filename="../lib/shortcuts_dialog.py" line="122"/>
        <location filename="../lib/shortcuts_dialog.py" line="126"/>
        <source>Navigation</source>
        <translation type="unfinished">Навигация</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="99"/>
        <source>Next Page</source>
        <translation type="unfinished">Следующая страница</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="100"/>
        <source>Next Page (alternative)</source>
        <translation type="unfinished">Следующая страница (альтернативный вариант)</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="101"/>
        <source>Previous Page</source>
        <translation type="unfinished">Предыдущая страница</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="104"/>
        <source>Previous Page (alternative)</source>
        <translation type="unfinished">Предыдущая страница (альтернатива)</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="107"/>
        <source>First Page</source>
        <translation type="unfinished">Первая страница</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="108"/>
        <source>Last Page</source>
        <translation type="unfinished">Последняя страница</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="109"/>
        <source>Go to Page (Interior only)</source>
        <translation type="unfinished">Перейти на страницу (только внутренняя)</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="110"/>
        <source>Navigate with Arrow Keys</source>
        <translation type="unfinished">Перемещение с помощью клавиш со стрелками</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="113"/>
        <source>  • When zoomed</source>
        <translation type="unfinished">  • При увеличении масштаба</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="114"/>
        <source>Arrow Keys = Pan document</source>
        <translation type="unfinished">Стрелки = Перемещение документа</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="118"/>
        <source>  • Interior (not zoomed)</source>
        <translation type="unfinished">  • Внутренний блок (без увеличения)</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="119"/>
        <source>Left/Right = Previous/Next page</source>
        <translation type="unfinished">Слева/Справа = Предыдущая/Следующая страница</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="123"/>
        <source>  • Cover/Dustjacket</source>
        <translation type="unfinished">  • Обложка/Суперобложка</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="124"/>
        <source>Arrow Keys = No action</source>
        <translation type="unfinished">Стрелки = Нет действия</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="126"/>
        <source>Navigate Pages</source>
        <translation type="unfinished">Перейти к страницам</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="128"/>
        <location filename="../lib/shortcuts_dialog.py" line="129"/>
        <location filename="../lib/shortcuts_dialog.py" line="130"/>
        <location filename="../lib/shortcuts_dialog.py" line="131"/>
        <source>View</source>
        <translation type="unfinished">Просмотр</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="128"/>
        <source>Fullscreen</source>
        <translation type="unfinished">Полный экран</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="129"/>
        <source>Presentation Mode</source>
        <translation type="unfinished">Режим презентации</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="130"/>
        <source>Exit Presentation/Fullscreen</source>
        <translation type="unfinished">Выйти из презентации/полноэкранного режима</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="131"/>
        <source>Side by Side View</source>
        <translation type="unfinished">Просмотр рядом</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="133"/>
        <location filename="../lib/shortcuts_dialog.py" line="134"/>
        <source>Document</source>
        <translation type="unfinished">Документ</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="133"/>
        <source>Spine Width Calculator</source>
        <translation type="unfinished">Калькулятор ширины корешка</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="134"/>
        <source>Font Information</source>
        <translation type="unfinished">Информация о шрифтах</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="136"/>
        <location filename="../lib/shortcuts_dialog.py" line="137"/>
        <location filename="../lib/shortcuts_dialog.py" line="139"/>
        <location filename="../lib/shortcuts_dialog.py" line="143"/>
        <location filename="../lib/shortcuts_dialog.py" line="145"/>
        <location filename="../lib/shortcuts_dialog.py" line="150"/>
        <source>Display</source>
        <translation type="unfinished">Отображение</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="136"/>
        <source>Show/Hide Margins</source>
        <translation type="unfinished">Показать/скрыть поля</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="137"/>
        <source>Show/Hide Trim Lines</source>
        <translation type="unfinished">Показать/Скрыть линии обрезки</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="140"/>
        <source>Show/Hide Barcode</source>
        <translation type="unfinished">Показать/Скрыть штрих-код</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="141"/>
        <source>Ctrl+B (Cover/Dustjacket only)</source>
        <translation type="unfinished">Ctrl+B (только обложка/суперобложка)</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="143"/>
        <source>Show/Hide Fold Lines</source>
        <translation type="unfinished">Показать/Скрыть линии сгиба</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="146"/>
        <source>Show/Hide Bleed Lines</source>
        <translation type="unfinished">Показать/Скрыть линии выпуска под обрез</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="147"/>
        <source>Ctrl+R (Cover/Dustjacket only)</source>
        <translation type="unfinished">Ctrl+R (только обложка/суперобложка)</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="151"/>
        <source>Show/Hide Gutter</source>
        <translation type="unfinished">Показать/Скрыть корешковое поле</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="152"/>
        <source>Ctrl+U (Interior only)</source>
        <translation type="unfinished">Ctrl+U (только внутренний блок)</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="155"/>
        <location filename="../lib/shortcuts_dialog.py" line="156"/>
        <location filename="../lib/shortcuts_dialog.py" line="157"/>
        <location filename="../lib/shortcuts_dialog.py" line="158"/>
        <source>Zoom</source>
        <translation type="unfinished">Масштаб</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="155"/>
        <source>Zoom In</source>
        <translation type="unfinished">Увеличить</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="156"/>
        <source>Zoom Out</source>
        <translation type="unfinished">Уменьшить</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="157"/>
        <source>Fit to Page</source>
        <translation type="unfinished">Подогнать под страницу</translation>
    </message>
    <message>
        <source>Fit to Page (alternative)</source>
        <translation type="obsolete">Подогнать по странице (альтернатива)</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="158"/>
        <source>Zoom with Mouse</source>
        <translation type="unfinished">Масштабирование с помощью мыши</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="160"/>
        <location filename="../lib/shortcuts_dialog.py" line="161"/>
        <source>Help</source>
        <translation type="unfinished">Помощь</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="160"/>
        <source>Show Keyboard Shortcuts</source>
        <translation type="unfinished">Показать сочетания клавиш</translation>
    </message>
    <message>
        <location filename="../lib/shortcuts_dialog.py" line="161"/>
        <source>About</source>
        <translation type="unfinished">О программе</translation>
    </message>
</context>
<context>
    <name>SpineWidthCalculatorDialog</name>
    <message>
        <source>Spine Width Calculator</source>
        <translation type="obsolete">Калькулятор ширины корешка</translation>
    </message>
    <message>
        <location filename="../views/components/calculator_dialog.py" line="82"/>
        <source>Calculator</source>
        <translation>Калькулятор</translation>
    </message>
    <message>
        <source>Calculate spine width based on page count and document type.
Enter the number of pages and select the document type.</source>
        <translation type="obsolete">Рассчитайте ширину корешка на основе количества страниц и типа документа.
Введите количество страниц и выберите тип документа.</translation>
    </message>
    <message>
        <location filename="../views/components/calculator_dialog.py" line="110"/>
        <source>Number of Pages:</source>
        <translation type="unfinished">Количество страниц:</translation>
    </message>
    <message>
        <location filename="../views/components/calculator_dialog.py" line="116"/>
        <source>Enter the total number of pages (1-999)</source>
        <translation type="unfinished">Введите общее количество страниц (1-999)</translation>
    </message>
    <message>
        <location filename="../views/components/calculator_dialog.py" line="123"/>
        <source>Document Type</source>
        <translation type="unfinished">Тип документа</translation>
    </message>
    <message>
        <location filename="../views/components/calculator_dialog.py" line="129"/>
        <source>Cover</source>
        <translation type="unfinished">Обложка</translation>
    </message>
    <message>
        <location filename="../views/components/calculator_dialog.py" line="133"/>
        <source>Dustjacket</source>
        <translation type="unfinished">Суперобложка</translation>
    </message>
    <message>
        <location filename="../views/components/calculator_dialog.py" line="207"/>
        <source>Minimum {pages} pages required for dustjackets</source>
        <translation type="unfinished">Минимум {pages} страниц требуется для суперобложек</translation>
    </message>
    <message>
        <location filename="../views/components/calculator_dialog.py" line="390"/>
        <source>Dimension</source>
        <translation type="unfinished">Размер</translation>
    </message>
    <message>
        <location filename="../views/components/calculator_dialog.py" line="391"/>
        <source>Value</source>
        <translation type="unfinished">Значение</translation>
    </message>
    <message>
        <location filename="../views/components/calculator_dialog.py" line="392"/>
        <source>Notes</source>
        <translation type="unfinished">Примечания</translation>
    </message>
    <message>
        <location filename="../views/components/calculator_dialog.py" line="471"/>
        <location filename="../views/components/calculator_dialog.py" line="512"/>
        <source>Barcode Area</source>
        <translation type="unfinished">Область штрих-кода</translation>
    </message>
    <message>
        <location filename="../views/components/calculator_dialog.py" line="473"/>
        <location filename="../views/components/calculator_dialog.py" line="514"/>
        <source>ISBN barcode placement area</source>
        <translation type="unfinished">Область размещения штрих-кода ISBN</translation>
    </message>
    <message>
        <location filename="../views/components/calculator_dialog.py" line="477"/>
        <location filename="../views/components/calculator_dialog.py" line="518"/>
        <source>Bleed Area</source>
        <translation type="unfinished">Область выпуска под обрез</translation>
    </message>
    <message>
        <location filename="../views/components/calculator_dialog.py" line="479"/>
        <location filename="../views/components/calculator_dialog.py" line="520"/>
        <source>Extends beyond trim edge</source>
        <translation type="unfinished">Выходит за край обреза</translation>
    </message>
    <message>
        <location filename="../views/components/calculator_dialog.py" line="483"/>
        <location filename="../views/components/calculator_dialog.py" line="536"/>
        <source>Gutter Width (per page)</source>
        <translation type="unfinished">Ширина корешкового поля (на страницу)</translation>
    </message>
    <message>
        <location filename="../views/components/calculator_dialog.py" line="485"/>
        <location filename="../views/components/calculator_dialog.py" line="538"/>
        <source>Added to safety margin for binding</source>
        <translation type="unfinished">Добавлено к полю безопасности для переплета</translation>
    </message>
    <message>
        <location filename="../views/components/calculator_dialog.py" line="489"/>
        <location filename="../views/components/calculator_dialog.py" line="542"/>
        <source>Safety Margin</source>
        <translation type="unfinished">Поле безопасности</translation>
    </message>
    <message>
        <location filename="../views/components/calculator_dialog.py" line="491"/>
        <location filename="../views/components/calculator_dialog.py" line="544"/>
        <source>Minimum distance from trim edge</source>
        <translation type="unfinished">Минимальное расстояние от края обреза</translation>
    </message>
    <message>
        <location filename="../views/components/calculator_dialog.py" line="495"/>
        <location filename="../views/components/calculator_dialog.py" line="548"/>
        <source>Spine Width</source>
        <translation type="unfinished">Ширина корешка</translation>
    </message>
    <message>
        <location filename="../views/components/calculator_dialog.py" line="497"/>
        <location filename="../views/components/calculator_dialog.py" line="550"/>
        <source>Calculated based on {pages} pages</source>
        <translation type="unfinished">Рассчитано на основе {pages} страниц</translation>
    </message>
    <message>
        <location filename="../views/components/calculator_dialog.py" line="524"/>
        <source>Flap Width</source>
        <translation type="unfinished">Ширина клапана</translation>
    </message>
    <message>
        <location filename="../views/components/calculator_dialog.py" line="526"/>
        <source>Width of front and back flaps</source>
        <translation type="unfinished">Ширина передних и задних клапанов</translation>
    </message>
    <message>
        <location filename="../views/components/calculator_dialog.py" line="530"/>
        <source>Fold Safety Margin</source>
        <translation type="unfinished">Поле безопасности сгиба</translation>
    </message>
    <message>
        <location filename="../views/components/calculator_dialog.py" line="532"/>
        <source>Safety margin at fold lines</source>
        <translation type="unfinished">Поле безопасности на линиях сгиба</translation>
    </message>
    <message>
        <source>Calculated Spine Width</source>
        <translation type="obsolete">Рассчитанная ширина корешка</translation>
    </message>
    <message>
        <source>Spine Width: {width}mm</source>
        <translation type="obsolete">Ширина корешка: {width}мм</translation>
    </message>
    <message>
        <location filename="../views/components/calculator_dialog.py" line="146"/>
        <source>Document Dimensions</source>
        <translation>Размеры документа</translation>
    </message>
    <message>
        <location filename="../views/components/calculator_dialog.py" line="156"/>
        <source>Production Details</source>
        <translation type="unfinished">Детали производства</translation>
    </message>
    <message>
        <location filename="../views/components/calculator_dialog.py" line="200"/>
        <source>Minimum {pages} pages required for covers</source>
        <translation type="unfinished">Минимальное количество {pages} страниц, необходимое для обложки</translation>
    </message>
    <message>
        <source>Spine Width: --</source>
        <translation type="obsolete">Ширина корешка: --</translation>
    </message>
    <message>
        <location filename="../views/components/calculator_dialog.py" line="243"/>
        <source>Error calculating spine width</source>
        <translation>Ошибка расчета ширины корешка</translation>
    </message>
    <message>
        <source>Note: Page count outside standard range</source>
        <translation type="obsolete">Примечание: количество страниц вне стандартного диапазона</translation>
    </message>
    <message>
        <location filename="../views/components/calculator_dialog.py" line="255"/>
        <source>Book Format</source>
        <translation>Формат книги</translation>
    </message>
    <message>
        <location filename="../views/components/calculator_dialog.py" line="256"/>
        <source>Trim Size</source>
        <translation>Размер обрезки</translation>
    </message>
    <message>
        <location filename="../views/components/calculator_dialog.py" line="257"/>
        <source>Total Document Size</source>
        <translation>Общий размер документа</translation>
    </message>
</context>
</TS>
