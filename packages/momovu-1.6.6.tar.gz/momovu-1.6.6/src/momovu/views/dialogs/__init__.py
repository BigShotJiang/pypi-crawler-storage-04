"""Dialog components for the momovu application."""

from momovu.views.dialogs.font_info_dialog import FontInfoDialog

__all__ = ["FontInfoDialog"]
