.. mdinclude:: ../../README.md


.. toctree::
   :hidden:
   :maxdepth: 2

   Home <self>
   api_ref
   changelog
   contributing
