import os

test_dir = os.path.abspath(os.path.dirname(__file__))
