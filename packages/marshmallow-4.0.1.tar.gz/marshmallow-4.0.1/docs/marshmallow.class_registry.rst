Class registry
==============

.. automodule:: marshmallow.class_registry
    :members:
