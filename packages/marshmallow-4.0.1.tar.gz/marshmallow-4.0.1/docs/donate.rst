******
Donate
******

If you find marshmallow useful, please consider supporting the team with a donation:

.. image:: https://opencollective.com/marshmallow/donate/button@2x.png
   :target: https://opencollective.com/marshmallow
   :alt: Donate to our Open Collective
   :height: 50px
   
Your donation keeps marshmallow healthy and maintained.
