Extending schemas
=================

The guides below demonstrate how to extend schemas in various ways.

.. toctree::
  :maxdepth: 1

  pre_and_post_processing_methods
  schema_validation
  using_original_input_data
  overriding_attribute_access
  custom_error_handling
  custom_options
  custom_error_messages
