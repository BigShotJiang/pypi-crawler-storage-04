"""
Main package for aiverify blur corruptions plugin.
"""
