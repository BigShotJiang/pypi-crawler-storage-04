"""The pyang library for parsing, validating, and converting YANG modules"""

__version__ = '2.7.1'
__date__ = '2025-08-29'
