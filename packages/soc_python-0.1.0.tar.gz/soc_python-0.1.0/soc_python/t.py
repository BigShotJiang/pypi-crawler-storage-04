def main():
    print("hello world")
    print("hello world")
    print("hello world")
    return {"code": 0}