# kolox

**kolox is provided by the [kolo](https://pypi.org/project/kolo/) package. There is no need to install it separately, this is just a dummy package to prevent confusion.**
