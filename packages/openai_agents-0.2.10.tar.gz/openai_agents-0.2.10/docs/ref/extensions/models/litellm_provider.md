# `LiteLLM Provider`

::: agents.extensions.models.litellm_provider
