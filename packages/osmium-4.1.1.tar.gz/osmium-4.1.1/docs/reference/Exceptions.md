# Exceptions

::: osmium.InvalidLocationError
