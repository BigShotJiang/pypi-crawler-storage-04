#!/usr/bin/env python

# This has only been added to allow editable dev installs, pyproject.toml replaces setup.py
# e.g. pip install -e .

import setuptools

if __name__ == "__main__":
    setuptools.setup()
