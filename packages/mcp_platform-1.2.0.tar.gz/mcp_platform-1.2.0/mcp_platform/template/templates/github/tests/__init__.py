"""
Tests for Github template.
"""
