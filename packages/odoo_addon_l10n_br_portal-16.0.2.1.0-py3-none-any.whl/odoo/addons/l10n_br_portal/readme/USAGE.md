To use this module, you need go to portal and edit your contact info:

![](../static/description/screenshot1.png)
