"""유틸리티 모듈에서 사용하는 공통 상수들을 정의합니다."""

# Git diff 관련 상수
GIT_DIFF_UNIFIED_CONTEXT_LINES = 5
