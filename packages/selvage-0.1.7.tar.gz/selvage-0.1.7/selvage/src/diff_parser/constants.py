"""상수 정의 모듈

diff_parser 모듈에서 사용하는 공통 상수들을 정의합니다.
"""

# 삭제된 파일을 나타내는 플레이스홀더
DELETED_FILE_PLACEHOLDER = "Deleted file"
