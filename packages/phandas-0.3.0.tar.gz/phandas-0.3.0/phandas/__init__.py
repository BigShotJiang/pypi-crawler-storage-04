"""
Phandas: Professional quantitative analysis framework for cryptocurrency markets.

Clean, efficient factor analysis with pandas-like API.
"""

__author__ = "Phantom Management"
__version__ = "0.3.0"

# Core components
from .core import (
    Factor, load_factor
)
from .operators import (
    rank, ts_rank, ts_mean, ts_median, ts_corr, ts_delay, ts_delta, ts_arg_max, ts_arg_min, ts_av_diff, ts_backfill, ts_decay_exp_window, ts_decay_linear, 
    log, s_log_1p, sign, sqrt, maximum, minimum, multiply, power, reverse, 
    signed_power, subtract, divide, inverse, add
)
from .data import fetch_data, check_data_quality
from .backtest import Backtester, backtest
from .utils import save_factor, load_saved_factor, factor_info

__all__ = [
    # Core factor class
    'Factor',
    'load_factor',
    
    # Data management
    'fetch_data',
    'check_data_quality',
    
    # Backtesting
    'Backtester',
    'backtest',
    
    # Functional API (WQ style) - tested and stable
    'rank', 'ts_rank', 'ts_mean', 'ts_median', 'ts_corr', 'ts_delay', 'ts_delta', 'ts_arg_max', 'ts_arg_min', 'ts_av_diff', 'ts_backfill', 'ts_decay_exp_window', 'ts_decay_linear',
    'log', 's_log_1p', 'sign', 'sqrt', 'maximum', 'minimum', 'multiply', 'power', 'reverse',
    'signed_power', 'subtract', 'divide', 'inverse', 'add',
    
    # Utilities
    'save_factor',
    'load_saved_factor',
    'factor_info'
]