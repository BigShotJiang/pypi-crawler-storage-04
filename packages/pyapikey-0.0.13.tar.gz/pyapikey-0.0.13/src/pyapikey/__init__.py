""" initalizing of the pyapikey package """

from pyapikey.core import get_key  # noqa F401
