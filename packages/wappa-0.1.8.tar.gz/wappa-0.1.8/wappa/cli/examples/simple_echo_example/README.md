# Simple Echo Example

A clean and simple WhatsApp echo bot built with the Wappa framework. This example demonstrates basic Wappa functionality with minimal complexity.

## Features

-  **Simple Echo**: Echoes back all text messages
-  **Media Support**: Acknowledges media messages (images, videos, audio, documents)
-  **Location & Contacts**: Handles location and contact sharing
-  **Clean Architecture**: Follows the `/app` folder pattern for organized code
-  **Professional Logging**: Structured logging with proper error handling
-  **Message Counting**: Tracks and displays message counts

## Project Structure

```
simple_echo_example/
   .env                    # Environment configuration (create this)
   .gitignore             # Git ignore patterns
   README.md              # This file
   pyproject.toml         # Project dependencies and metadata
   app/                   # Application code
       __init__.py        # Package initialization
       main.py            # Main application entry point
       master_event.py    # Simple echo event handler
```

## Setup

### 1. Prerequisites

- Python 3.12+
- WhatsApp Business API access token
- `uv` package manager installed

### 2. Install Dependencies

```bash
# From the project root
uv sync
```

### 3. Configure Environment

Create a `.env` file in the project root:

```env
# WhatsApp Business API Credentials
WP_ACCESS_TOKEN=your_access_token_here
WP_PHONE_ID=your_phone_number_id_here
WP_BID=your_business_id_here
```

### 4. Run the Application

You have three ways to run the application:

#### Option A: Using Python Module (Recommended)
```bash
# From project root
python -m app.main
```

#### Option B: Using uvicorn directly
```bash
# From project root
uv run uvicorn app.main:app --reload
```

#### Option C: Using Wappa CLI (when available)
```bash
# From project root
wappa run app/main.py
```

## Testing

Send messages to your WhatsApp Business number and observe:

1. **Text Messages**: Get echoed back with "= Echo: [your message]"
2. **Media Files**: Get acknowledgment that media was received
3. **Location**: Get confirmation that location was shared
4. **Contacts**: Get acknowledgment that contact was received
5. **Message Counting**: Each response shows total message count

## Code Structure

### `app/main.py`
- Application initialization and configuration
- Startup information display
- Configuration validation
- Module-level app instance for uvicorn compatibility

### `app/master_event.py`
- `SimpleEchoHandler` class implementing `WappaEventHandler`
- Message processing logic for different message types
- Error handling and logging

## Key Features Demonstrated

- **Clean Architecture**: Clear separation of concerns with organized code structure
- **Dependency Injection**: Proper Wappa dependency injection pattern
- **Multi-Message Support**: Handles text, media, location, and contact messages
- **Professional Logging**: Structured logging with appropriate log levels
- **Error Handling**: Comprehensive error handling with graceful fallbacks

## Comparison with Redis Cache Example

This simple echo example demonstrates the same architectural patterns as the more complex Redis cache example, but without:
- Redis caching
- Score module system
- Complex business logic
- Database models
- Advanced caching strategies

It's perfect for learning the basics of Wappa development before moving to more complex examples.

## Next Steps

After mastering this simple example, consider exploring:

1. **Redis Cache Example**: For caching, user management, and state handling
2. **Custom Commands**: Add slash commands like `/help` or `/about`
3. **Media Processing**: Download and process media files
4. **Database Integration**: Store conversation history
5. **AI Integration**: Add AI-powered responses

## Troubleshooting

### Common Issues

1. **Missing Environment Variables**: Ensure all required variables are set in `.env`
2. **Import Errors**: Make sure you're running from the project root
3. **Port Already in Use**: Kill existing processes using port 8000
4. **Webhook URL**: Ensure your WhatsApp webhook URL points to your server

### Getting Help

- Check the logs for detailed error messages
- Verify your WhatsApp Business API credentials
- Ensure your server is accessible from the internet
- Review the Wappa documentation for additional guidance

## License

This example is part of the Wappa framework examples and follows the same license terms.