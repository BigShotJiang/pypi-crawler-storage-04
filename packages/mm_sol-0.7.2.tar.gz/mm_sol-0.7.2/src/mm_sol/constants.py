UNIT_DECIMALS = {"sol": 9}
