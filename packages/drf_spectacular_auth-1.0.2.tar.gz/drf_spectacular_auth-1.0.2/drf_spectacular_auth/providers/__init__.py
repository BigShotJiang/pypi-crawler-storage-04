"""
Authentication providers for DRF Spectacular Auth
"""