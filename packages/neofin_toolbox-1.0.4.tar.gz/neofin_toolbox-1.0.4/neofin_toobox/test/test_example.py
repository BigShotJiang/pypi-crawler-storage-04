# test_example.py
def test_soma():
    assert 1 + 1 == 2
