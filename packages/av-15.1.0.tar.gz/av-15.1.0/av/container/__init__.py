from .core import Container, Flags, open
from .input import InputContainer
from .output import OutputContainer
