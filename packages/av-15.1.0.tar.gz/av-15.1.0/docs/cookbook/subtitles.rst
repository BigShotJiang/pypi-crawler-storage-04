Subtitles
=========


Remuxing
--------

Remuxing is copying stream(s) from one container to the other without transcoding it. By doing so, the data does not suffer any generational loss, and is the full quality that it was in the source container.

.. literalinclude:: ../../examples/subtitles/remux.py
