Audio
=====


Filters
-------

Increase the audio speed by applying the atempo filter. The speed is increased by 2.

.. literalinclude:: ../../examples/audio/atempo.py
