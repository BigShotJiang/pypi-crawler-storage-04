
.. It is all in the other file (that we want at the top-level of the repo).

.. _changelog:

.. include:: ../../CHANGELOG.rst
