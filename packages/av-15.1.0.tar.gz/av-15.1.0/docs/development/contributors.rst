

.. include:: ../../AUTHORS.rst
