
Side Data
=========

.. automodule:: av.sidedata.sidedata

    .. autoclass:: SideData
        :members:

.. autoclass:: av.sidedata.sidedata.Type
.. enumtable:: av.sidedata.sidedata.Type


Motion Vectors
--------------

.. automodule:: av.sidedata.motionvectors

    .. autoclass:: MotionVectors
        :members:
