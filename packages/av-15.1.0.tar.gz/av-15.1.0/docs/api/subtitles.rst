
Subtitles
===========

.. automodule:: av.subtitles.stream

    .. autoclass:: SubtitleStream
        :members:

.. automodule:: av.subtitles.subtitle

    .. autoclass:: SubtitleSet
        :members:

    .. autoclass:: Subtitle
        :members:

    .. autoclass:: AssSubtitle
        :members:

    .. autoclass:: BitmapSubtitle
        :members:

    .. autoclass:: BitmapSubtitlePlane
        :members:
