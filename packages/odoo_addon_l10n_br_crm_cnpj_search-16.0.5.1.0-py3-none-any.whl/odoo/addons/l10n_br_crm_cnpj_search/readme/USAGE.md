1.  Acesse Configurações
2.  Escolha um provedor para a busca
3.  Habilite o Lead nas configurações do CRM
4.  Acesse CRM \> Lead \> Criar
5.  Preencha o nome do Lead, insira no campo de CNPJ o CNPJ que deseja
    buscar e clique na lupa ao lado do campo para buscar
