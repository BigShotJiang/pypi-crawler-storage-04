class Render:
    pass


async def render_paper(paper_id):
    pass
