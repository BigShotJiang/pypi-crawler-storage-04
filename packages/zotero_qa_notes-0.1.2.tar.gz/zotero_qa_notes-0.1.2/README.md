# zotero-qa-notes

[![CI](https://github.com/innoxmind/zotero-qa-notes/actions/workflows/ci.yml/badge.svg)](https://github.com/innoxmind/zotero-qa-notes/actions/workflows/ci.yml)

Convert Zotero export (JSON) into clean Markdown notes with optional **Q&A prompts** for study.
...