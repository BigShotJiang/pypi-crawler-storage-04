# -*- coding: utf-8 -*-
"""
Created on Sat Aug 30 20:37:19 2025

@author: balazs
"""

from mandelbrot_viewer.mandelbrot_viewer_main import main