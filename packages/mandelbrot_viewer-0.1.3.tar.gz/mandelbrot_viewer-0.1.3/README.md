# mandelbrot-set-viewer
An interactive arbitrary precision Mandelbrot set viewer using my [taichi_big_float](https://github.com/balazs-szalai/taichi-bigfloat) package.

## Usage
You just have to install it using pip:
	
	pip install mandelbrot-viewer
And you can run it from the commandline using:
	
	mandelbrot-viewer
This will execute the main function from mandelbrot_viewer.mandelbrot_viewer.main.py.