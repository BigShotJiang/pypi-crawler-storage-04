# The B-value calculator: tractable calculation of expected nucleotide diversity under background selection

See documentation for details: https://JohriLab.github.io/Bvalcalc/

Jacob Marsh and Parul Johri
UNC Chapel Hill, NC
