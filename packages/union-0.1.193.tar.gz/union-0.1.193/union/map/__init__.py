from ._map import map

__all__ = ["map"]
