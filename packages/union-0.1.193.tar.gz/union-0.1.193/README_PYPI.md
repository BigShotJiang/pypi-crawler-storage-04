# UnionAI

The SDK for [Union.ai](https://www.union.ai/).

## Installation

Install `union`:

```bash
pip install union
```
