# -*- coding: utf-8 -*-

PAD = '<pad>'
UNK = '<unk>'
BOS = '<bos>'
EOS = '<eos>'

MIN = -1e32
