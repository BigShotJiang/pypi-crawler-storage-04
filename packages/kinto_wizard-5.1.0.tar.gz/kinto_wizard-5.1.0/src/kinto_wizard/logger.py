import logging


logger = logging.getLogger("kinto-wizard")
