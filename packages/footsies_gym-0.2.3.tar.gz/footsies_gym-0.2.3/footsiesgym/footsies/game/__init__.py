"""
Game module for FootsiesGym.
"""

from . import constants, footsies_game

__all__ = ["constants", "footsies_game"]
