from enum import Enum


class WorkstationStatus(Enum):
    IN_SERVICE = 'IN_SERVICE'
    OUT_OF_SERVICE = 'OUT_OF_SERVICE'
