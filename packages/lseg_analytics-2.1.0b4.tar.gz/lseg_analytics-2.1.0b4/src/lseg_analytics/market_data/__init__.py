"""market_data namespace"""
