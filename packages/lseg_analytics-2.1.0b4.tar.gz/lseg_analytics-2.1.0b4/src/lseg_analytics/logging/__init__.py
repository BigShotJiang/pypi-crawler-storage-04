from ._config import LoggingOutput

__all__ = ["LoggingOutput"]
