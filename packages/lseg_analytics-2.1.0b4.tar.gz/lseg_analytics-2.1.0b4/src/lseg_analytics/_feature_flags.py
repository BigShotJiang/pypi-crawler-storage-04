"""Dev-oriented configuration. Mostly feature-flags"""

REPR_SHOW_ON_SERVER_STATUS = True
REPR_SHOW_JOINED_SPACE_NAME = False
REPR_SHOW_ID_HEX = False
REPR_SHORTEN_SERVER_ID = True
