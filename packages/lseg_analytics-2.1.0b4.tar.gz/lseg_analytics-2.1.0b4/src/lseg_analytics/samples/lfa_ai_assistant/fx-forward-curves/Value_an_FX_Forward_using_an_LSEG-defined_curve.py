#Load the "EUR_GBP_FxForward" curve from the LSEG storage space

#Create an FX Forward instrument with 500000 deal amount, with EURCAD 0.86 rate with 1M and 3M tenors

#Value it using the LSEG curve

# Print the market values