#Generate valuation dates from a month ago to today

#Calculate the curve points of 'EUR_GBP_FxForward' LSEG curve for each valuation_dates and save it in a df

#Plot the bid points for 6M tenor on a time series chart where the x axis is the valuation date