#Load the "AUD_CHF_FxForward" curve from the LSEG storage space

#Calculate the curve points on 22nd of January 2023

#Display the curve points in a table form