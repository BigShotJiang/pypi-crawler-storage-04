"""Client SDK for London Stock Exchange Group Analytics-as-a-Service."""

__version__ = "2.1.0b4"
