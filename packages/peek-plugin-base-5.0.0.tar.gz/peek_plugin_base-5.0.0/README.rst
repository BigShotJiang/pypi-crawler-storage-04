======================
README - Peek App Base
======================

This package is intended to be the only dependency that an Peek App developer needs
to run on and interact with the Peek Platform.

