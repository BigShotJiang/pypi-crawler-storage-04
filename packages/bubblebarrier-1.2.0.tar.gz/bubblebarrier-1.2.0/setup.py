from setuptools import setup

# All configuration is now in pyproject.toml.
# This file is only for legacy compatibility.
setup()