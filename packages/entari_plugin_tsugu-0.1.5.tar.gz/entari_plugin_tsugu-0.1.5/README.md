# entari-plugin-tsugu

一个用于 Entari 框架的 Tsugu BanGDream Bot 插件。

## 功能

- 支持 BanGDream 相关查询功能
- 集成 Tsugu 命令处理
- 支持多平台消息发送

## 安装

```bash
pip install entari-plugin-tsugu
```
