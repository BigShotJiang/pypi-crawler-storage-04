# szn-advertising-research-pyspark-statlog-schema

This is a security placeholder package created to prevent dependency confusion attacks.