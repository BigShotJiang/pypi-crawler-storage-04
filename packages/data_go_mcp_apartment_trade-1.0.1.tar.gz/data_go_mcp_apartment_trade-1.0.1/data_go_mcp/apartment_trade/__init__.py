"""MCP server for Korea apartment trade data from data.go.kr"""

__version__ = "1.0.1"