version = "0.0.1"

#def show_version():
  #print("\nYou are using h5 version %s\n"%version)
#
#def show_git_hash():
  #print("\nYou are using h5 git hash %s\n"%("af9681a67dcbc7121b363e43f60b5e2cbad73dcb"))
