from llama_index.embeddings.ibm.base import WatsonxEmbeddings


__all__ = ["WatsonxEmbeddings"]
