######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.18.1.1+obcheckpoint(0.2.4);ob(v1)                                                    #
# Generated on 2025-09-02T19:19:25.154892                                                            #
######################################################################################################

from __future__ import annotations


from . import pytorch as pytorch

