######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.18.1.1+obcheckpoint(0.2.4);ob(v1)                                                    #
# Generated on 2025-09-02T19:19:25.187749                                                            #
######################################################################################################

from __future__ import annotations



class GcpDefaultClientProvider(object, metaclass=type):
    @staticmethod
    def get_gs_storage_client(*args, **kwargs):
        ...
    @staticmethod
    def get_credentials(scopes, *args, **kwargs):
        ...
    ...

cached_provider_class: None

def get_gs_storage_client():
    ...

def get_credentials(scopes, *args, **kwargs):
    ...

