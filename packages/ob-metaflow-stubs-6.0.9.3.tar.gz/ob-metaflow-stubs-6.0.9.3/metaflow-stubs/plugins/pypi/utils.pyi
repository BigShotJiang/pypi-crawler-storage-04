######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.18.1.1+obcheckpoint(0.2.4);ob(v1)                                                    #
# Generated on 2025-09-02T19:19:25.178204                                                            #
######################################################################################################

from __future__ import annotations


from ..._vendor.packaging import tags as tags
from ...exception import MetaflowException as MetaflowException

MICROMAMBA_URL: str

MICROMAMBA_MIRROR_URL: str

def conda_platform():
    ...

def wheel_tags(wheel):
    ...

def pip_tags(python_version, mamba_platform):
    ...

def parse_filename_from_url(url):
    ...

