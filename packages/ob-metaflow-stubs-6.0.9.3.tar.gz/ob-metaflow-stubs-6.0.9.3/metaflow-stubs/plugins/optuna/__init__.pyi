######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.18.1.1+obcheckpoint(0.2.4);ob(v1)                                                    #
# Generated on 2025-09-02T19:19:25.096437                                                            #
######################################################################################################

from __future__ import annotations



def auth():
    ...

def get_deployment_db_access_endpoint(name: str):
    ...

def get_db_url(app_name: str):
    """
    Example usage:
        >>> from metaflow.plugins.optuna import get_db_url
        >>> s = optuna.create_study(..., storage=get_db_url("optuna-dashboard"))
    """
    ...

