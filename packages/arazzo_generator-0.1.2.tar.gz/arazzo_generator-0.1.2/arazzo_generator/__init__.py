"""OpenAPI to Arazzo workflow generator."""

import logging

logging.getLogger(__name__).addHandler(logging.NullHandler())

__version__ = "0.1.0"
