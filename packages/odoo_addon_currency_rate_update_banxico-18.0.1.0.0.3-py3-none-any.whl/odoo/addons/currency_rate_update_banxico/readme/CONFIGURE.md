Now you can choose the 'Bank of Mexico' service when configuring a currency
rates providers.

1. Go to Banxico to [generate a token](https://www.banxico.org.mx/SieAPIRest/service/v1/token).
2.  Go to *Invoicing \> Configuration \> Currency Rates Providers*.
3.  Create a new 'Currency Rates Providers' or edit an existing one and
    you will see 'Bank of Mexico' among the available 'Source Services' to
    choose and set the token generated in step 1.
4.  If you choose 'Bank of Mexico' as a 'Source Service', the exchange rates
    will be updated from that provider.
