This module adds [Banxico](https://www.banxico.org.mx/) currency exchange rate
web services.
