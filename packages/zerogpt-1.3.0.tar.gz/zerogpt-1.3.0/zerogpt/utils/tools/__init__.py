from .image_to_prompt import image_to_prompt

__version__ = {
    'image_to_prompt': image_to_prompt.__version__
}