"""Subpackage for CellDesigner maps"""
