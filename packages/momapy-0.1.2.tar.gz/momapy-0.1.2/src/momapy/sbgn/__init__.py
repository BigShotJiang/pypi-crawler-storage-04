"""Subpackage for SBGN maps"""
