"""Library for working with molecular maps programmatically"""
