from __future__ import annotations

import ckan.plugins.toolkit as tk

_a_doc = """
"""
a = tk.signals.ckanext.signal("files:smth", _a_doc)
