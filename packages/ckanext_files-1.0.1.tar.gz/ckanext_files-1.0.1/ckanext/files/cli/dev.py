from __future__ import annotations

import click


@click.group(hidden=True)
def group():
    """Tools for extension developers."""
