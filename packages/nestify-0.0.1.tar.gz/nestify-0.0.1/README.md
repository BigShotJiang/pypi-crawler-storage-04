# nestify

**nestify** is a tiny utility that transforms *flat dictionaries with path-like keys* into proper **nested structures**.  
Think of it as the inverse of `flatten`:  

```python
from nestify import nestify

data = {
    "a.b.c": 1,
    "a.d": 2,
    "x": 3
}

print(nestify(data))
# => {"a": {"b": {"c": 1}, "d": 2}, "x": 3}
```

## ✨ Features

- **Custom separators**  
  Not limited to dots (`.`) — use `/`, `:`, `::`, or any string as a separator.

- **Conflict resolution policies**  
  Choose how to handle conflicts: 
  - `forbid_mixed`: strict mode, disallow mixing dict/non-dict (default).
  - `merge_dicts`: merge dictionaries recursively, warn on key overlaps.
  - `overwrite`: always overwrite existing values, with a warning.

- **Recursive processing**  
  Values that are dictionaries themselves are also expanded.

- **Safe & predictable**  
  Warnings and errors make conflicts explicit, avoiding silent data corruption.

## 🔧 Usage Examples

### Basic Expansion

```python
from nestify import nestify

nestify({"a.b": 1, "a.c": 2})
# => {"a": {"b": 1, "c": 2}}
```

### Custom Separator

```python
from nestify import nestify

nestify({"root/child": 42}, separator="/")
# => {"root": {"child": 42}}
```

### Conflict Resolution

```python
from nestify import nestify

# Overwrite mode
nestify({"a.b": 1, "a.b": 2}, conflict_policy="overwrite")
# => {"a": {"b": 2}}
```

## 💡 Why nestify?

When working with **configs**, **JSON/YAML**, or **flattened exports** (from APIs, databases, etc.),
you often get keys like "user.profile.name". nestify makes it effortless to convert them into proper nested dicts.

## 📦 Installation

```bash
pip install nestify
```

## 🧾 License

MIT License. See [LICENSE](LICENSE) for details.
