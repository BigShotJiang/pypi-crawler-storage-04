import { Component } from "@angular/core";

@Component({
    selector: "plugin-graphdb",
    templateUrl: "graphdb.component.web.html",
})
export class DocdbComponent {
    constructor() {}
}
