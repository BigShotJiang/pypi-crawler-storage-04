
import { Component, ChangeDetectionStrategy } from "@angular/core";

@Component({
    selector: "graphdb-admin",
    templateUrl: "graphdb-admin-page.component.html",
    styleUrls: ["graphdb-admin-page.component.scss"],
    changeDetection: ChangeDetectionStrategy.OnPush,
})
export class GraphdbAdminPageComponent {}