export let graphDbFilt = { plugin: "peek_plugin_graphdb" };
export let graphDbTuplePrefix = "peek_plugin_graphdb.";

export let graphDbObservableName = "peek_plugin_graphdb";
export let graphDbActionProcessorName = "peek_plugin_graphdb";
export let graphDbTupleOfflineServiceName = "peek_plugin_graphdb";

export let graphDbBaseUrl = "peek_plugin_graphdb";

export let graphDbCacheStorageName = "peek_plugin_graphdb.cache";
