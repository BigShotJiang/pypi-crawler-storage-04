===============
Graph DB Plugin
===============

The GraphDB plugin stores a graph model with vertices and edges.
This is ideal for representing an IT network, Power network, Gas network, etc.

`See Graph Theory at Wikipedia <https://en.wikipedia.org/wiki/Graph_(discrete_mathematics)>`_
