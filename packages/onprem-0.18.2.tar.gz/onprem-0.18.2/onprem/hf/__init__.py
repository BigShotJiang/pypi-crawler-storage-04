# Note: The HFTrainer is a wrapper around Hugging Face Trainer and was adapted from txtai.

from .train.hftrainer import HFTrainer
