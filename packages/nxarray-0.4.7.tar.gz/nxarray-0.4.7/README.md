# nxarray

xarray extension for NeXus input/output.

See the [documentation](https://nxarray.readthedocs.io/en/latest/) for detailed information on installation and usage of ``nxarray``.
