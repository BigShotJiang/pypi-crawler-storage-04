"""This module simply keeps track of version numbers.

The variable is manually increased,
committed and pushed when a version bump is required.
"""

__version__ = "0.4.7"
