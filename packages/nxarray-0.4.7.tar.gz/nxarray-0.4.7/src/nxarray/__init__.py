from ._core import load

from ._accessors import _nxrDataArray, _nxrDataset

from ._version import __version__
