"""Git infrastructure module."""
