"""BM25 infrastructure module."""
