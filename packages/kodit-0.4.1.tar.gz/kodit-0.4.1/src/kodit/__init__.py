"""kodit - Code indexing for better AI code generation."""
