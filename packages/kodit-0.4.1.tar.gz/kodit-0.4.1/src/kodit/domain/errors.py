"""Domain errors."""


class EmptySourceError(ValueError):
    """Error raised when a source is empty."""
