"""Domain layer containing models, services, and repositories."""
