"""Tests for domain services."""
