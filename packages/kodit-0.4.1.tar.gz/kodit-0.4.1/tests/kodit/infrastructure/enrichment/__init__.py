"""Tests for the enrichment module."""
