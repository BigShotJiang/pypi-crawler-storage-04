"""Tests for application layer."""
