"""Git cloning infrastructure."""
