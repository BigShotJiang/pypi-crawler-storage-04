from typing import Optional

from binance.websocket.websocket_client import BinanceWebsocketClient


class SpotWebsocketStreamClient(BinanceWebsocketClient):
    def __init__(
        self,
        stream_url="wss://stream.binance.com:9443",
        on_message=None,
        on_open=None,
        on_close=None,
        on_error=None,
        on_ping=None,
        on_pong=None,
        is_combined=False,
        timeout=None,
        time_unit=None,
        logger=None,
        proxies: Optional[dict] = None,
    ):
        if is_combined:
            stream_url = stream_url + "/stream"
        else:
            stream_url = stream_url + "/ws"
        super().__init__(
            stream_url,
            on_message=on_message,
            on_open=on_open,
            on_close=on_close,
            on_error=on_error,
            on_ping=on_ping,
            on_pong=on_pong,
            timeout=timeout,
            time_unit=time_unit,
            logger=logger,
            proxies=proxies,
        )

    def agg_trade(self, symbol: str, id=None, action=None, **kwargs):
        """Aggregate Trade Streams

        The Aggregate Trade Streams push trade information that is aggregated for a single taker order.

        Stream Name: <symbol>@aggTrade

        Update Speed: Real-time
        """
        stream_name = f"{symbol.lower()}@aggTrade"

        self.send_message_to_server(stream_name, action=action, id=id)

    def trade(self, symbol: str, id=None, action=None, **kwargs):
        """Trade Streams

        The Trade Streams push raw trade information; each trade has a unique buyer and seller.

        Stream Name: <symbol>@trade

        Update Speed: Real-time
        """

        stream_name = f"{symbol.lower()}@trade"

        self.send_message_to_server(stream_name, action=action, id=id)

    def kline(self, symbol: str, interval: str, id=None, action=None):
        """Kline/Candlestick Streams

        The Kline/Candlestick Stream push updates to the current klines/candlestick every second.

        Stream Name: <symbol>@kline_<interval>

        interval:
        m -> minutes; h -> hours; d -> days; w -> weeks; M -> months

        - 1m
        - 3m
        - 5m
        - 15m
        - 30m
        - 1h
        - 2h
        - 4h
        - 6h
        - 8h
        - 12h
        - 1d
        - 3d
        - 1w
        - 1M

        Update Speed: 1000ms for 1s, 2000ms for the other intervals
        """
        stream_name = f"{symbol.lower()}@kline_{interval}"

        self.send_message_to_server(stream_name, action=action, id=id)

    def kline_timezone_offset(self, symbol: str, interval: str, id=None, action=None):
        """Kline/Candlestick Streams with timezone offset

        The Kline/Candlestick Stream push updates to the current klines/candlestick every second in UTC+8 timezone

        <symbol>@kline_<interval>@+08:00

        interval:
        m -> minutes; h -> hours; d -> days; w -> weeks; M -> months

        - 1m
        - 3m
        - 5m
        - 15m
        - 30m
        - 1h
        - 2h
        - 4h
        - 6h
        - 8h
        - 12h
        - 1d
        - 3d
        - 1w
        - 1M

        Update Speed: 1000ms for 1s, 2000ms for the other intervals
        """
        stream_name = f"{symbol.lower()}@kline_{interval}@+08:00"

        self.send_message_to_server(stream_name, action=action, id=id)

    def mini_ticker(self, symbol=None, id=None, action=None, **kwargs):
        """Individual symbol or all symbols mini ticker

        24hr rolling window mini-ticker statistics.
        These are NOT the statistics of the UTC day, but a 24hr rolling window for the previous 24hrs

        Stream Name: <symbol>@miniTicker or
        Stream Name: !miniTicker@arr

        Update Speed: 1000ms
        """

        if symbol is None:
            stream_name = "!miniTicker@arr"
        else:
            stream_name = f"{symbol.lower()}@miniTicker"

        self.send_message_to_server(stream_name, action=action, id=id)

    def ticker(self, symbol=None, id=None, action=None, **kwargs):
        """Individual symbol or all symbols ticker

        24hr rolling window ticker statistics for a single symbol.
        These are NOT the statistics of the UTC day, but a 24hr rolling window for the previous 24hrs.

        Stream Name: <symbol>@ticker or
        Stream Name: !ticker@arr

        Update Speed: 1000ms
        """

        if symbol is None:
            stream_name = "!ticker@arr"
        else:
            stream_name = f"{symbol.lower()}@ticker"
        self.send_message_to_server(stream_name, action=action, id=id)

    def book_ticker(self, symbol, id=None, action=None, **kwargs):
        """Individual symbol book ticker

        Pushes any update to the best bid or ask's price or quantity in real-time for a specified symbol.

        Stream Name: <symbol>@bookTicker

        Update Speed: realtime
        """

        self.send_message_to_server(
            f"{symbol.lower()}@bookTicker", action=action, id=id
        )

    def partial_book_depth(
        self, symbol: str, level=5, speed=1000, id=None, action=None, **kwargs
    ):
        """Partial Book Depth Streams

        Top bids and asks, Valid are 5, 10, or 20.

        Stream Names: <symbol>@depth<levels> OR <symbol>@depth<levels>@100ms.

        Update Speed: 1000ms or 100ms
        """
        self.send_message_to_server(
            f"{symbol.lower()}@depth{level}@{speed}ms", id=id, action=action
        )

    def rolling_window_ticker(self, symbol: str, windowSize: str, id=None, action=None):
        """Rolling window ticker statistics for a single symbol, computed over multiple windows.

        Stream Name: <symbol>@ticker_<window_size>

        Window Sizes: 1h, 4h, 1d

        Update Speed: 1000ms

        Note: This stream is different from the <symbol>@ticker stream. The open time "O" always starts on a minute, while the closing time "C" is the current time of the update. As such, the effective window might be up to 59999ms wider that <window_size>.
        """
        self.send_message_to_server(
            f"{symbol.lower()}@ticker_{windowSize}", id=id, action=action
        )

    def rolling_window_ticker_all_symbols(self, windowSize: str, id=None, action=None):
        """All Market Rolling Window Statistics Streams

        Rolling window ticker statistics for all market symbols, computed over multiple windows. Note that only tickers that have changed will be present in the array.

        Stream Name: !ticker_<window-size>@arr

        Window Size: 1h, 4h, 1d

        Update Speed: 1000ms
        """
        self.send_message_to_server(f"!ticker_{windowSize}@arr", id=id, action=action)

    def diff_book_depth(self, symbol: str, speed=1000, id=None, action=None, **kwargs):
        """Diff. Depth Stream

        Stream Name: <symbol>@depth OR <symbol>@depth@100ms

        Update Speed: 1000ms or 100ms

        Order book price and quantity depth updates used to locally manage an order book.
        """

        self.send_message_to_server(
            f"{symbol.lower()}@depth@{speed}ms", action=action, id=id
        )

    def user_data(self, listen_key: str, id=None, action=None, **kwargs):
        """Listen to user data by using the provided listen_key"""
        self.send_message_to_server(listen_key, action=action, id=id)
