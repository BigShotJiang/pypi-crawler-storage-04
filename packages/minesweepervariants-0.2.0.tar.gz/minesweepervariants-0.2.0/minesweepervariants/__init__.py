from .scripts.generate_puzzle import main as puzzle
from .scripts.generate_game import main as puzzle_query
from .scripts.generate_test import main as test
