from .rectangular_area_selector import RectangularAreaSelector

__all__ = ["RectangularAreaSelector"]
