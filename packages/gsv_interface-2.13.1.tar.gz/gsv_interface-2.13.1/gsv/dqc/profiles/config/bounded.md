

## Temperatures

| Variable         | ParamId | Min  | Max  | Units |
|-------------|--------------|-------------|--------------|
| name        | bounded      |
| type        | integer      |
| min_value   | 0            |
| max_value   | 100          |
| description | Bounded value|