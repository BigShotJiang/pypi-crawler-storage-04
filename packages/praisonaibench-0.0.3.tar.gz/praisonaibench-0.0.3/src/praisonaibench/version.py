"""Version information for PraisonAI Bench."""

__version__ = "0.0.3"
