from symbol_generator.symbol_generator import main

if __name__ == '__main__':
  main()
