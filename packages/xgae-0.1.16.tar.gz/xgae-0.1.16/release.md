# Release Changelog
## [0.1.16] - 2025-9-1
### Target
- Saved for XGATaskEngine base version
### Changed
- Delete StreamTaskResponser tool_exec_on_stream model code


## [0.1.15] - 2025-9-1
### Target
- Saved for StreamResponser tool_exec_on_stream mode, next release will be abolished
### Changed
- Refact TaskResponseProcessor, XGATaskEngine
### Fixed
- Fix finish_reason judge logic


## [0.1.14] - 2025-8-31
### Target
- First complete version 
