#!/usr/bin/python3
import viz3dvideo.about as about

def main():
    """Entry point for the ``viz3dvideo-info`` console script. This shows the current version of the module."""
    print(about.__version__)

if __name__ == "__main__":
    main()
