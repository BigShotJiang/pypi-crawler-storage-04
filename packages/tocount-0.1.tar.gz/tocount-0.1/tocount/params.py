# -*- coding: utf-8 -*-
"""tocount parameters and constants."""

TOCOUNT_VERSION = "0.1"

INVALID_TEXT_ESTIMATOR_MESSAGE = "Invalid value. `estimator` must be an instance of TextEstimator enum."
INVALID_TEXT_MESSAGE = "Invalid value. `text` must be a string."
