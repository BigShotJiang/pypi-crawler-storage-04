### MRP Areas

- Go to *Manufacturing \> Configuration \> MRP Areas* and define or edit
  any existing area. You can specify the working hours for every area.

### Product MRP Area Parameters

- Go to *Manufacturing \> Products \> Product MRP Area Parameters*
  and set the MRP parameters for a given product and area.
