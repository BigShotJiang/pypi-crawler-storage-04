from typing import Union
from collections import defaultdict
import re
import uuid
import asyncio
import importlib
from pathlib import Path
from aiohttp import web
from asyncdb.exceptions.exceptions import NoDataFound  # pylint: disable=E0611  # noqa
from datamodel.exceptions import ValidationError  # pylint: disable=E0611  # noqa
from navigator_auth.decorators import (
    is_authenticated,
    user_session,
    allowed_organizations
)
from navigator.views import BaseView
from ..bots.abstract import AbstractBot
from ..loaders import AbstractLoader, AVAILABLE_LOADERS
from ..loaders.markdown import MarkdownLoader
from .models import BotModel


@is_authenticated()
@user_session()
class ChatHandler(BaseView):
    """
    ChatHandler.
    description: Chat Handler for Parrot Application.
    """

    async def get(self, **kwargs):
        """
        get.
        description: Get method for ChatHandler.
        """
        name = self.request.match_info.get('chatbot_name', None)
        if not name:
            return self.json_response({
                "message": "Welcome to Parrot Chatbot Service."
            })
        else:
            # retrieve chatbof information:
            manager = self.request.app['bot_manager']
            chatbot = manager.get_bot(name)
            if not chatbot:
                return self.error(
                    f"Chatbot {name} not found.",
                    status=404
                )
            config_file = getattr(chatbot, 'config_file', None)
            return self.json_response({
                "chatbot": chatbot.name,
                "description": chatbot.description,
                "role": chatbot.role,
                "embedding_model": chatbot.embedding_model,
                "llm": f"{chatbot.llm!r}",
                "temperature": chatbot.llm.temperature,
                "config_file": config_file
            })

    async def post(self, *args, **kwargs):
        """
        post.
        description: Post method for ChatHandler.

        Use this method to interact with a Chatbot.
        """
        app = self.request.app
        name = self.request.match_info.get('chatbot_name', None)
        qs = self.query_parameters(self.request)
        data = await self.request.json()
        if not 'query' in data:
            return self.json_response(
                {
                "message": "No query was found."
                },
                status=400
            )
        if 'llm' in qs:
            # passing another LLM to the Chatbot:
            llm = data.pop('llm')
            model = data.pop('model', None)
        else:
            llm = None
            model = None
        try:
            manager = app['bot_manager']
        except KeyError:
            return self.json_response(
                {
                "message": "Chatbot Manager is not installed."
                },
                status=404
            )
        try:
            chatbot: AbstractBot = manager.get_bot(name)
            if not chatbot:
                raise KeyError(
                    f"Chatbot {name} not found."
                )
        except (TypeError, KeyError):
            return self.json_response(
                {
                "message": f"Chatbot {name} not found."
                },
                status=404
            )
        # getting the question:
        question = data.pop('query')
        search_type = data.pop('search_type', 'similarity')
        return_sources = data.pop('return_sources', True)
        try:
            session = self.request.session
        except AttributeError:
            session = None
        if not session:
            return self.json_response(
                {
                "message": "User Session is required to interact with a Chatbot."
                },
                status=400
            )
        try:
            async with chatbot.retrieval(self.request) as bot:
                session_id = session.get('session_id', None)
                user_id = session.get('user_id', None)
                if not session_id:
                    session_id = str(uuid.uuid4())
                result = await bot.conversation(
                    question=question,
                    session_id=session_id,
                    user_id=user_id,
                    search_type=search_type,
                    llm=llm,
                    model=model,
                    return_sources=return_sources,
                    **data
                )
                return self.json_response(
                    response=result.model_dump()
                )
        except ValueError as exc:
            return self.error(
                f"{exc}",
                exception=exc,
                status=400
            )
        except web.HTTPException as exc:
            return self.error(
                f"{exc}",
                exception=exc,
                status=400
            )
        except Exception as exc:
            return self.error(
                f"Error invoking chatbot {name}: {exc}",
                exception=exc,
                status=400
            )


@is_authenticated()
@user_session()
class BotHandler(BaseView):
    """BotHandler.
    description: Bot Handler for Parrot Application.
    Use this handler to interact with a brand new chatbot, consuming a configuration.
    """
    async def _create_bot(self, name: str, data: dict):
        """Create a New Bot (passing a configuration).
        """
        db = self.request.app['database']
        async with await db.acquire() as conn:
            BotModel.Meta.connection = conn
            # check first if chatbot already exists:
            exists = None
            try:
                exists = await BotModel.get(name=name)
            except NoDataFound:
                exists = False
            if exists:
                return self.json_response(
                    {
                        "message": f"Chatbot {name} already exists with id {exists.chatbot_id}"
                    },
                    status=202
                )
            try:
                chatbot_model = BotModel(
                    name=name,
                    **data
                )
                print('Chatbot Model: ', chatbot_model)
                chatbot_model = await chatbot_model.insert()
                return chatbot_model
            except ValidationError:
                raise
            except Exception:
                raise

    async def put(self):
        """Create a New Bot (passing a configuration).
        """
        try:
            manager = self.request.app['bot_manager']
        except KeyError:
            return self.json_response(
                {
                "message": "Chatbot Manager is not installed."
                },
                status=404
            )
        # TODO: Making a Validation of data
        data = await self.request.json()
        name = data.pop('name', None)
        if not name:
            return self.json_response(
                {
                "message": "Name for Bot Creation is required."
                },
                status=400
            )
        try:
            bot = manager.create_bot(name=name, **data)
        except Exception as exc:
            print(exc.__traceback__)
            return self.error(
                response={
                    "message": f"Error creating chatbot {name}.",
                    "exception": str(exc),
                    "stacktrace": str(exc.__traceback__)
                },
                exception=exc,
                status=400
            )
        try:
            # if bot is created:
            await self._create_bot(name=name, data=data)
        except ValidationError as exc:
            return self.error(
                f"Validation Error for {name}: {exc}",
                exception=exc.payload,
                status=400
            )
        except Exception as exc:
            print(exc.__traceback__)
            return self.error(
                response={
                    "message": f"Error creating chatbot {name}.",
                    "exception": str(exc),
                    "stacktrace": str(exc.__traceback__)
                },
                exception=exc,
                status=400
            )
        try:
            # Then Configure the bot:
            await bot.configure(app=self.request.app)
            return self.json_response(
                {
                    "message": f"Chatbot {name} created successfully."
                }
            )
        except Exception as exc:
            return self.error(
                f"Error on chatbot configuration: {name}: {exc}",
                exception=exc,
                status=400
            )


@is_authenticated()
@user_session()
class BotManagement(BaseView):
    """BotManagement.
    description: Bot Management Handler for Parrot Application.
    Use this handler to list all available chatbots, upload files, and delete chatbots.
    """
    async def get(self):
        """List all available chatbots.
        """
        try:
            manager = self.request.app['bot_manager']
        except KeyError:
            return self.json_response(
                {
                "message": "Chatbot Manager is not installed."
                },
                status=404
            )
        try:
            all_bots = manager.get_bots()
            bots = []
            for bot_name, bot in all_bots.items():
                bots.append({
                    "name": bot_name,
                    "chatbot_id": bot.chatbot_id,
                    "bot_class": str(bot.__class__.__name__),
                    "description": bot.description,
                    "backstory": bot.backstory,
                    "role": bot.role,
                    "embedding_model": bot.embedding_model,
                    "llm": f"{bot.llm!r}",
                    "temperature": bot.llm.temperature,
                    "documents": bot.get_vector_store()
                })
        except Exception as exc:
            return self.error(
                response={
                    "message": f"Error retrieving chatbots.",
                    "exception": str(exc),
                    "stacktrace": str(exc.__traceback__)
                },
                exception=exc,
                status=400
            )
        return self.json_response(
            {
                "bots": bots
            }
        )

    def _get_loader(self, loader_name: Union[str, type]) -> type:
        """Get the loader class by name."""
        if isinstance(loader_name, type) and issubclass(loader_name, AbstractLoader):
            return loader_name
        if not loader_name:
            return None
        try:
            module = importlib.import_module('parrot.loaders', package=None)
            loader_cls = getattr(module, loader_name, None)
            if not loader_cls:
                raise ValueError(f"Loader not found: {loader_name}")
            if isinstance(loader_cls, type) and issubclass(loader_cls, AbstractLoader):
                return loader_cls
        except Exception:
            pass
        # try submodule guess
        base = loader_name[:-6] if loader_name.endswith("Loader") else loader_name
        candidates = [
            f"parrot.loaders.{base.lower()}",
            f"parrot.loaders.{re.sub(r'(?<!^)(?=[A-Z])','_',base).lower()}",
        ]
        for mod_name in candidates:
            try:
                mod = importlib.import_module(mod_name)
                loader_cls = getattr(mod, loader_name, None)
                if isinstance(loader_cls, type) and issubclass(loader_cls, AbstractLoader):
                    return loader_cls
            except Exception:
                continue
        return None

    def _group_attachments_by_loader(self, attachments, default_loader_cls=None):
        """
        Returns dict[LoaderClass, list[Path]]
        If default_loader_cls is provided, all files go to that loader.
        Otherwise, choose per-file from AVAILABLE_LOADERS by extension, fallback to MarkdownLoader.
        """
        by_loader = defaultdict(list)
        files = []
        for a in attachments or []:
            p = a.get("file_path")
            if p is None:
                continue
            files.append(Path(p))

        if default_loader_cls:
            if not issubclass(default_loader_cls, AbstractLoader):
                raise TypeError(
                    f"Default loader must subclass AbstractLoader, got {default_loader_cls}"
                )
            if files:
                by_loader[default_loader_cls].extend(files)
            return by_loader

        # No default → pick by extension
        for p in files:
            ext = p.suffix.lower()
            loader_cls = AVAILABLE_LOADERS.get(ext, MarkdownLoader)
            by_loader[loader_cls].append(p)

        return by_loader

    async def put(self):
        """Upload a file to a chatbot.
        """
        try:
            attachments, form_data = await self.handle_upload()
        except web.HTTPUnsupportedMediaType:
            # if no file is provided, then is a JSON request:
            form_data = await self.request.json()
            attachments = []
        try:
            manager = self.request.app['bot_manager']
        except KeyError:
            return self.json_response(
                {
                "message": "Chatbot Manager is not installed."
                },
                status=404
            )
        params = self.get_arguments(self.request)
        chatbot_name = params.get('bot', None)
        if not chatbot_name:
            return self.json_response(
                {
                    "message": "Chatbot name is required."
                },
                status=400
            )
        try:
            manager = self.request.app['bot_manager']
        except KeyError:
            return self.json_response(
                {
                "message": "Chatbot Manager is not installed."
                },
                status=404
            )
        try:
            chatbot: AbstractBot = manager.get_bot(chatbot_name)
            if not chatbot:
                raise KeyError(
                    f"Chatbot {chatbot_name} not found."
                )
        except (TypeError, KeyError):
            return self.json_response(
                {
                "message": f"Chatbot {chatbot_name} not found."
                },
                status=404
            )
        # Check if Store is loaded, if not, return error:
        if not chatbot.get_vector_store():
            return self.json_response(
                {
                    "message": f"Chatbot {chatbot_name} has no Vector Store configured."
                },
                status=400
            )
        # Check if chatbot.store is available:
        if chatbot.store is None:
            # Load the store:
            try:
                store = chatbot.get_vector_store()
                # change "name" to "vector_vector_store"
                if 'name' in store:
                    store['vector_store'] = store.pop('name')
                chatbot.define_store(
                    **store
                )
                chatbot.configure_store()
            except Exception as e:
                return self.json_response(
                    {
                        "message": f"Failed to configure store for chatbot {chatbot_name}: {e}"
                    },
                    status=500
                )
        default_loader = form_data.pop('loader', 'MarkdownLoader')
        source_type = form_data.pop('source_type', 'file')
        # Any extra kwargs for loaders (excluding 'loader' key)
        loader_kwargs = {k: v for k, v in (form_data or {}).items() if k != "loader"}
        loader_cls = self._get_loader(default_loader)
        # --- Group all attachments by loader ---
        by_loader = self._group_attachments_by_loader(
            attachments,
            default_loader_cls=loader_cls
        )
        files_list = []
        loaders_used = []
        if not by_loader and not attachments:
            # if no files were uploaded, using the form_data as a source:
            source = form_data.pop('source', None)
            # Any extra kwargs for loaders (excluding control keys)
            loader_kwargs = {k: v for k, v in (form_data or {}).items()
                if k not in {'loader', 'source_type', 'source'}}
            if not source:
                return self.json_response(
                    {"message": "No files/URLs were uploaded and no source provided."},
                    status=400
                )
            # If loader not resolved, try to infer: YouTube vs Web
            if loader_cls is None:
                if any('youtu' in u for u in source):
                    loader_cls = self._get_loader('YoutubeLoader')
                else:
                    loader_cls = self._get_loader('WebLoader')
            documents: list = []
            errors: list = []
            if loader_cls is None:
                return self.json_response(
                    {"message": "Loader not found or not specified for URL sources."},
                    status=400
                )
            try:
                loader = loader_cls(
                    source=source,
                    source_type=source_type,
                    **loader_kwargs
                )
                docs = await loader.load()
                if isinstance(docs, list):
                    documents.extend(docs)
            except Exception as exc:
                errors.append(str(exc))
            loaders_used = [loader_cls.__name__]
            files_list = source
        if attachments:
            if not by_loader:
                return self.json_response(
                    {"message": "No supported files found."},
                    status=400
                )
            tasks = []
            for loader_cls, files in by_loader.items():
                print(
                    f"Loading {len(files)} files with {loader_cls.__name__}"
                )
                try:
                    # Each loader receives the full list for that type (avoid per-file loops)
                    loader = loader_cls(
                        source=files,
                        source_type=source_type,
                        **loader_kwargs
                    )
                    tasks.append(loader.load())
                except Exception as exc:
                    return self.error(
                        f"Error initializing {loader_cls} for chatbot {chatbot_name}: {exc}",
                        exception=exc,
                        status=400
                    )
                results = await asyncio.gather(*tasks, return_exceptions=True)
                # Flatten and handle errors without aborting the whole batch
                documents = []
                errors = []
                try:
                    for res in results:
                        if isinstance(res, Exception):
                            errors.append(str(res))
                        elif isinstance(res, list):
                            documents.extend(res)
                except Exception as exc:
                    return self.error(
                        f"Error adding documents to chatbot {chatbot_name}: {exc}",
                        exception=exc,
                        status=400
                    )
            files_list = [str(a["file_path"]) for a in attachments]
            loaders_used = [cls.__name__ for cls in by_loader.keys()]
        # Load documents into the chatbot
        try:
            if documents:
                await chatbot.store.add_documents(documents)
        except Exception as exc:
            return self.error(
                f"Error adding documents to chatbot {chatbot_name}: {exc}",
                exception=exc,
                status=400
            )
        payload = {
            "bot": chatbot_name,
            "files": files_list,
            "loaders": loaders_used,
            "documents": len(documents),
            "errors": errors,
        }
        return self.json_response(
            payload,
            status=200 if not errors else 207
        )
