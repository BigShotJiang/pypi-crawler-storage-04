-- drop old migrations table

DROP TABLE IF EXISTS migrations;
