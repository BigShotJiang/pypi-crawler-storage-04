#!moo verb test-async-verb-callback --on "player class" --dspec this

print(args[1])  # pylint: disable=undefined-variable  # type: ignore
