######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.18.2                                                                                 #
# Generated on 2025-09-03T10:37:45.800427                                                            #
######################################################################################################

from __future__ import annotations


from . import base_sensor as base_sensor
from . import external_task_sensor as external_task_sensor
from .external_task_sensor import ExternalTaskSensorDecorator as ExternalTaskSensorDecorator
from . import s3_sensor as s3_sensor
from .s3_sensor import S3KeySensorDecorator as S3KeySensorDecorator

SUPPORTED_SENSORS: list

