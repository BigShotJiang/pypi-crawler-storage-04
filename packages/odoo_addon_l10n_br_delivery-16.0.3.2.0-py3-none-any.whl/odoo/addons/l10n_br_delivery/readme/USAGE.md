Para usar esse modulo você precisa:

- Criar um Pedido de Venda informar o Método de Entrega e o valor do
  Frete, se necessário os valores de Seguro e Outros Custos.
