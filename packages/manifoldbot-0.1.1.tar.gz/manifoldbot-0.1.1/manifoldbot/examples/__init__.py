"""Examples for using ManifoldBot."""
