from .trainer import TrainerSupervised
from .explainer import Explainer
from .analyzer import Analyzer
from .utils import *

from importlib.metadata import version
__version__ = "0.20.0"