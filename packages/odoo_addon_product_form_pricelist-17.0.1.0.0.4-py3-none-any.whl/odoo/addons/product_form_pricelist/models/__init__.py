from . import product_template
from . import product_pricelist_item
from . import res_config_settings
