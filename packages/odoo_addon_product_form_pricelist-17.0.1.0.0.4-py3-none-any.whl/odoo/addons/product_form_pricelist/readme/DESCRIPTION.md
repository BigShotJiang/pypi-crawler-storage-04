This module allow to fill directly from the product form the pricelist
item for the product. The type of pricelist item is always "fixed"
