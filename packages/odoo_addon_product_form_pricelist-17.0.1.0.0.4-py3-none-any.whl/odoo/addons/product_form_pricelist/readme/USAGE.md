To use this module:

1.  Go to Product Template view
2.  Edit the fixed pricelist item
