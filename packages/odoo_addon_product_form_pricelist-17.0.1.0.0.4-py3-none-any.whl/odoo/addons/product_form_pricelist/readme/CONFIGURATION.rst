If you only want to use fixed price on product and hide the "Sales price" field
You can tick the option in the sale config menu
