from __future__ import annotations

from mteb.leaderboard.app import get_leaderboard_app

__all__ = ["get_leaderboard_app"]
