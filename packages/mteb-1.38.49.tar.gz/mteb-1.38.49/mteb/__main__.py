from __future__ import annotations

from mteb.cli import main

main()
