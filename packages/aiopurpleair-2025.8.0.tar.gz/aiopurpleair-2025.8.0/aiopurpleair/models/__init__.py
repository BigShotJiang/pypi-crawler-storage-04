"""Define data models."""
