class MLOpsDeploymentError(Exception):
    pass
