from ._Compare import *
