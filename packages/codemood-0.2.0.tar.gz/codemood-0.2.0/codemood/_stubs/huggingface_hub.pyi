from typing import Any, Dict, List

class InferenceClient:
    def __init__(self, api_key: str | None = None, *args: Any, **kwargs: Any): ...
    def text_classification(
        self, text: str, model: str, *args: Any, **kwargs: Any
    ) -> List[Dict[str, Any]]: ...
