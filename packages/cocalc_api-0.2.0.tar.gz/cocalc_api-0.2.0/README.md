https://pypi.org/project/cocalc-api/

This is a Python package that provides an API client for https://cocalc.com