from .client import tell_the_server, secretly_tell_the_server, RedPandaClient
from .server import start_floofy_server, ParanoidPanda












