# VideoSDK Turn Detector Plugin

Agent Framework plugin for Turn Detection.

## Installation

```bash
pip install videosdk-plugins-turn-detector
```