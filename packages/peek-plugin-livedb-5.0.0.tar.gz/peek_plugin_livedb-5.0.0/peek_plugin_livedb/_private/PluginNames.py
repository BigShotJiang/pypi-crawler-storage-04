livedbFilt = {"plugin": "peek_plugin_livedb"}
livedbTuplePrefix = "peek_plugin_livedb."
livedbObservableName = "peek_plugin_livedb"
livedbActionProcessorName = "peek_plugin_livedb"
livedbTupleOfflineServiceName = "peek_plugin_livedb"
