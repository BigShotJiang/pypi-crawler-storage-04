=============
LiveDB Plugin
=============


LiveDB stores the SCADA + calculated "live" values.

This plugin does not provide APIs for the desktop/mobile, it's intended for server side
only.

At present these values are only used to update peek-plugin-display Disp attributes.

TODO:

#.  Cache DB in memory
#.  Add calculations support.
