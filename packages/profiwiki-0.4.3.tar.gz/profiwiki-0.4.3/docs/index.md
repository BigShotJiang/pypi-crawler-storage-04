# ProfiWiki API Documentation

::: profiwiki
    options:
      show_submodules: true
