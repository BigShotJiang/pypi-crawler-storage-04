"""
Core business logic modules
"""
