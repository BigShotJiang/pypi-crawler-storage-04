# 0.1.0

- Initial release

# 0.2.0

- Add uniffi bindings
