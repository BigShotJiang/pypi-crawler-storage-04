import SunsetCalculator from './components/SunsetCalculator'
import './App.css'

function App() {
  return (
    <div className="App">
      <SunsetCalculator />
    </div>
  )
}

export default App
