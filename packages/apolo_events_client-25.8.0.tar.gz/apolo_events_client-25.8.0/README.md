# platform-events-client
Client library for platform-events service
