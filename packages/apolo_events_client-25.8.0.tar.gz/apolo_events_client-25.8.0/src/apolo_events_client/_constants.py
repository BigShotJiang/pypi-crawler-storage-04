PING_DELAY: float = 60.0
RESP_TIMEOUT: float = 30.0
