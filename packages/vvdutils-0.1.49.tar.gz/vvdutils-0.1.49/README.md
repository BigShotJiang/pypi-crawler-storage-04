# vvdutils
自 2024.5.10 起， mtutils 正式更名为 vvdutils，原 mtutils 锁定在版本 2.1.88 不再更新维护

vvdutils 在 mtutils 2.1.88 版本基础上进行更新

#### TODO

1. 代码梳理重构
2. 说明文档同步更新
3. 单元测试
