from django.apps import AppConfig


class MorestConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "morest"
