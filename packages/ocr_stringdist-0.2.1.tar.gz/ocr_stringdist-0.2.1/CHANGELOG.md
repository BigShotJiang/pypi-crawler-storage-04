# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.2.0] - 2025-08-31

### Added

- `WeightedLevenshtein` class for reusable configuration.
- Explanation of edit operations via `WeightedLevenshtein.explain` and `explain_weighted_levenshtein`.

## [0.1.0] - 2025-04-26

### Added

- Custom insertion and deletion costs for weighted Levenshtein distance.

### Changed

- Breaking changes to Levenshtein distance functions signatures.
