"""
User interface components.

Contains Textual-based chat interface and other UI elements.
"""