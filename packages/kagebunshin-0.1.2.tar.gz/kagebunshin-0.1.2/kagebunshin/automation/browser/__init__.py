"""
Browser-specific utilities.

Contains JavaScript utilities and browser interaction helpers.
"""