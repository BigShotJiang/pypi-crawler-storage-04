"""Tests for :mod:`curies`."""
