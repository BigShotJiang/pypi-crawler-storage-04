# LiveKit Server APIs

Access LiveKit server APIs and generate access tokens.

See https://docs.livekit.io/reference/server/server-apis for more information.

