# DeltaCAT Compactor GCP Examples
