# sage_setup: distribution = sagemath-latte-4ti2
# delvewheel: patch

from sage.all__sagemath_polyhedra import *
