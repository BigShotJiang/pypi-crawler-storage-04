# Numpydoc style

## :warning: Work in Progress!

NOTE: As Numpy-style is partially supported by the underlying parser,
you may experience problems in the building process if your docstring
has a `Methods` section in the class docstring
(see [#366](https://github.com/mkdocstrings/mkdocstrings/issues/366)).

See [Numpydoc's documentation](https://numpydoc.readthedocs.io/en/latest/format.html).
See the supported docstring sections on [Griffe's documentation](https://mkdocstrings.github.io/griffe/docstrings/).
