from mcp_juypter import main

main()
