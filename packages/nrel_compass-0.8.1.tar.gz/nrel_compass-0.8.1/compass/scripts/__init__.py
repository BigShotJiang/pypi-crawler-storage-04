"""COMPASS scripts"""
