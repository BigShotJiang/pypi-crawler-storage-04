from typing import Any

PartialObj = dict[str, Any]
