# Public folder

The files in this folder will be in the same folder as the html output of pandoc when mdfusion is in presentation mode.

Put files here that are referenced in the presentation, such as CSS files, JavaScript files, images, etc.

This folder will be bundled into the final html output.
