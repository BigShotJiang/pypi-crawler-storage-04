var qo = Object.defineProperty;
var mr = (t) => {
  throw TypeError(t);
};
var Uo = (t, e, n) => e in t ? qo(t, e, { enumerable: !0, configurable: !0, writable: !0, value: n }) : t[e] = n;
var Y = (t, e, n) => Uo(t, typeof e != "symbol" ? e + "" : e, n), Go = (t, e, n) => e.has(t) || mr("Cannot " + n);
var pr = (t, e, n) => e.has(t) ? mr("Cannot add the same private member more than once") : e instanceof WeakSet ? e.add(t) : e.set(t, n);
var hn = (t, e, n) => (Go(t, e, "access private method"), n);
function ht() {
}
function zo(t) {
  return t();
}
function jo(t) {
  return typeof t == "function";
}
function Vo(t, ...e) {
  if (t == null) {
    for (const i of e) i(void 0);
    return ht;
  }
  const n = t.subscribe(...e);
  return n.unsubscribe ? () => n.unsubscribe() : n;
}
function gr(t) {
  const e = typeof t == "string" && t.match(/^\s*(-?[\d.]+)([^\s]*)\s*$/);
  return e ? [parseFloat(e[1]), e[2] || "px"] : [t, "px"];
}
const _l = typeof window < "u";
let br = _l ? () => window.performance.now() : () => Date.now(), dl = _l ? (t) => requestAnimationFrame(t) : ht;
const Ct = /* @__PURE__ */ new Set();
function ml(t) {
  Ct.forEach((e) => {
    e.c(t) || (Ct.delete(e), e.f());
  }), Ct.size !== 0 && dl(ml);
}
function Xo(t) {
  let e;
  return Ct.size === 0 && dl(ml), { promise: new Promise((n) => {
    Ct.add(e = { c: t, f: n });
  }), abort() {
    Ct.delete(e);
  } };
}
function Zo(t) {
  const e = t - 1;
  return e * e * e + 1;
}
function vr(t, { delay: e = 0, duration: n = 400, easing: i = Zo, x: r = 0, y: l = 0, opacity: a = 0 } = {}) {
  const o = getComputedStyle(t), s = +o.opacity, u = o.transform === "none" ? "" : o.transform, c = s * (1 - a), [_, h] = gr(r), [d, D] = gr(l);
  return { delay: e, duration: n, easing: i, css: (E, F) => `
			transform: ${u} translate(${(1 - E) * _}${h}, ${(1 - E) * d}${D});
			opacity: ${s - c * F}` };
}
const gt = [];
function Wo(t, e) {
  return { subscribe: tn(t, e).subscribe };
}
function tn(t, e = ht) {
  let n;
  const i = /* @__PURE__ */ new Set();
  function r(a) {
    if (s = a, ((o = t) != o ? s == s : o !== s || o && typeof o == "object" || typeof o == "function") && (t = a, n)) {
      const u = !gt.length;
      for (const c of i) c[1](), gt.push(c, t);
      if (u) {
        for (let c = 0; c < gt.length; c += 2) gt[c][0](gt[c + 1]);
        gt.length = 0;
      }
    }
    var o, s;
  }
  function l(a) {
    r(a(t));
  }
  return { set: r, update: l, subscribe: function(a, o = ht) {
    const s = [a, o];
    return i.add(s), i.size === 1 && (n = e(r, l) || ht), a(t), () => {
      i.delete(s), i.size === 0 && n && (n(), n = null);
    };
  } };
}
function Lt(t, e, n) {
  const i = !Array.isArray(t), r = i ? [t] : t;
  if (!r.every(Boolean)) throw new Error("derived() expects stores as input, got a falsy value");
  const l = e.length < 2;
  return Wo(n, (a, o) => {
    let s = !1;
    const u = [];
    let c = 0, _ = ht;
    const h = () => {
      if (c) return;
      _();
      const D = e(i ? u[0] : u, a, o);
      l ? a(D) : _ = jo(D) ? D : ht;
    }, d = r.map((D, E) => Vo(D, (F) => {
      u[E] = F, c &= ~(1 << E), s && h();
    }, () => {
      c |= 1 << E;
    }));
    return s = !0, h(), function() {
      d.forEach(zo), _(), s = !1;
    };
  });
}
function yr(t) {
  return Object.prototype.toString.call(t) === "[object Date]";
}
function Ci(t, e, n, i) {
  if (typeof n == "number" || yr(n)) {
    const r = i - n, l = (n - e) / (t.dt || 1 / 60), a = (l + (t.opts.stiffness * r - t.opts.damping * l) * t.inv_mass) * t.dt;
    return Math.abs(a) < t.opts.precision && Math.abs(r) < t.opts.precision ? i : (t.settled = !1, yr(n) ? new Date(n.getTime() + a) : n + a);
  }
  if (Array.isArray(n)) return n.map((r, l) => Ci(t, e[l], n[l], i[l]));
  if (typeof n == "object") {
    const r = {};
    for (const l in n) r[l] = Ci(t, e[l], n[l], i[l]);
    return r;
  }
  throw new Error(`Cannot spring ${typeof n} values`);
}
function wr(t, e = {}) {
  const n = tn(t), { stiffness: i = 0.15, damping: r = 0.8, precision: l = 0.01 } = e;
  let a, o, s, u = t, c = t, _ = 1, h = 0, d = !1;
  function D(F, C = {}) {
    c = F;
    const g = s = {};
    return t == null || C.hard || E.stiffness >= 1 && E.damping >= 1 ? (d = !0, a = br(), u = F, n.set(t = c), Promise.resolve()) : (C.soft && (h = 1 / (60 * (C.soft === !0 ? 0.5 : +C.soft)), _ = 0), o || (a = br(), d = !1, o = Xo((f) => {
      if (d) return d = !1, o = null, !1;
      _ = Math.min(_ + h, 1);
      const m = { inv_mass: _, opts: E, settled: !0, dt: 60 * (f - a) / 1e3 }, v = Ci(m, u, t, c);
      return a = f, u = t, n.set(t = v), m.settled && (o = null), !m.settled;
    })), new Promise((f) => {
      o.promise.then(() => {
        g === s && f();
      });
    }));
  }
  const E = { set: D, update: (F, C) => D(F(c, t), C), subscribe: n.subscribe, stiffness: i, damping: r, precision: l };
  return E;
}
function Qo(t) {
  return Yo(t) && !Jo(t);
}
function Yo(t) {
  return !!t && typeof t == "object";
}
function Jo(t) {
  var e = Object.prototype.toString.call(t);
  return e === "[object RegExp]" || e === "[object Date]" || ts(t);
}
var Ko = typeof Symbol == "function" && Symbol.for, es = Ko ? Symbol.for("react.element") : 60103;
function ts(t) {
  return t.$$typeof === es;
}
var ns = Qo;
function is(t) {
  return Array.isArray(t) ? [] : {};
}
function Zt(t, e) {
  return e.clone !== !1 && e.isMergeableObject(t) ? Bt(is(t), t, e) : t;
}
function rs(t, e, n) {
  return t.concat(e).map(function(i) {
    return Zt(i, n);
  });
}
function as(t, e) {
  if (!e.customMerge)
    return Bt;
  var n = e.customMerge(t);
  return typeof n == "function" ? n : Bt;
}
function ls(t) {
  return Object.getOwnPropertySymbols ? Object.getOwnPropertySymbols(t).filter(function(e) {
    return Object.propertyIsEnumerable.call(t, e);
  }) : [];
}
function Dr(t) {
  return Object.keys(t).concat(ls(t));
}
function pl(t, e) {
  try {
    return e in t;
  } catch {
    return !1;
  }
}
function os(t, e) {
  return pl(t, e) && !(Object.hasOwnProperty.call(t, e) && Object.propertyIsEnumerable.call(t, e));
}
function ss(t, e, n) {
  var i = {};
  return n.isMergeableObject(t) && Dr(t).forEach(function(r) {
    i[r] = Zt(t[r], n);
  }), Dr(e).forEach(function(r) {
    os(t, r) || (pl(t, r) && n.isMergeableObject(e[r]) ? i[r] = as(r, n)(t[r], e[r], n) : i[r] = Zt(e[r], n));
  }), i;
}
function Bt(t, e, n) {
  n = n || {}, n.arrayMerge = n.arrayMerge || rs, n.isMergeableObject = n.isMergeableObject || ns, n.cloneUnlessOtherwiseSpecified = Zt;
  var i = Array.isArray(e), r = Array.isArray(t), l = i === r;
  return l ? i ? n.arrayMerge(t, e, n) : ss(t, e, n) : Zt(e, n);
}
Bt.all = function(e, n) {
  if (!Array.isArray(e))
    throw new Error("first argument should be an array");
  return e.reduce(function(i, r) {
    return Bt(i, r, n);
  }, {});
};
var Si = function(t, e) {
  return Si = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(n, i) {
    n.__proto__ = i;
  } || function(n, i) {
    for (var r in i) Object.prototype.hasOwnProperty.call(i, r) && (n[r] = i[r]);
  }, Si(t, e);
};
function Vn(t, e) {
  if (typeof e != "function" && e !== null)
    throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
  Si(t, e);
  function n() {
    this.constructor = t;
  }
  t.prototype = e === null ? Object.create(e) : (n.prototype = e.prototype, new n());
}
var z = function() {
  return z = Object.assign || function(e) {
    for (var n, i = 1, r = arguments.length; i < r; i++) {
      n = arguments[i];
      for (var l in n) Object.prototype.hasOwnProperty.call(n, l) && (e[l] = n[l]);
    }
    return e;
  }, z.apply(this, arguments);
};
function ii(t, e, n) {
  if (n || arguments.length === 2) for (var i = 0, r = e.length, l; i < r; i++)
    (l || !(i in e)) && (l || (l = Array.prototype.slice.call(e, 0, i)), l[i] = e[i]);
  return t.concat(l || Array.prototype.slice.call(e));
}
var q;
(function(t) {
  t[t.EXPECT_ARGUMENT_CLOSING_BRACE = 1] = "EXPECT_ARGUMENT_CLOSING_BRACE", t[t.EMPTY_ARGUMENT = 2] = "EMPTY_ARGUMENT", t[t.MALFORMED_ARGUMENT = 3] = "MALFORMED_ARGUMENT", t[t.EXPECT_ARGUMENT_TYPE = 4] = "EXPECT_ARGUMENT_TYPE", t[t.INVALID_ARGUMENT_TYPE = 5] = "INVALID_ARGUMENT_TYPE", t[t.EXPECT_ARGUMENT_STYLE = 6] = "EXPECT_ARGUMENT_STYLE", t[t.INVALID_NUMBER_SKELETON = 7] = "INVALID_NUMBER_SKELETON", t[t.INVALID_DATE_TIME_SKELETON = 8] = "INVALID_DATE_TIME_SKELETON", t[t.EXPECT_NUMBER_SKELETON = 9] = "EXPECT_NUMBER_SKELETON", t[t.EXPECT_DATE_TIME_SKELETON = 10] = "EXPECT_DATE_TIME_SKELETON", t[t.UNCLOSED_QUOTE_IN_ARGUMENT_STYLE = 11] = "UNCLOSED_QUOTE_IN_ARGUMENT_STYLE", t[t.EXPECT_SELECT_ARGUMENT_OPTIONS = 12] = "EXPECT_SELECT_ARGUMENT_OPTIONS", t[t.EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE = 13] = "EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE", t[t.INVALID_PLURAL_ARGUMENT_OFFSET_VALUE = 14] = "INVALID_PLURAL_ARGUMENT_OFFSET_VALUE", t[t.EXPECT_SELECT_ARGUMENT_SELECTOR = 15] = "EXPECT_SELECT_ARGUMENT_SELECTOR", t[t.EXPECT_PLURAL_ARGUMENT_SELECTOR = 16] = "EXPECT_PLURAL_ARGUMENT_SELECTOR", t[t.EXPECT_SELECT_ARGUMENT_SELECTOR_FRAGMENT = 17] = "EXPECT_SELECT_ARGUMENT_SELECTOR_FRAGMENT", t[t.EXPECT_PLURAL_ARGUMENT_SELECTOR_FRAGMENT = 18] = "EXPECT_PLURAL_ARGUMENT_SELECTOR_FRAGMENT", t[t.INVALID_PLURAL_ARGUMENT_SELECTOR = 19] = "INVALID_PLURAL_ARGUMENT_SELECTOR", t[t.DUPLICATE_PLURAL_ARGUMENT_SELECTOR = 20] = "DUPLICATE_PLURAL_ARGUMENT_SELECTOR", t[t.DUPLICATE_SELECT_ARGUMENT_SELECTOR = 21] = "DUPLICATE_SELECT_ARGUMENT_SELECTOR", t[t.MISSING_OTHER_CLAUSE = 22] = "MISSING_OTHER_CLAUSE", t[t.INVALID_TAG = 23] = "INVALID_TAG", t[t.INVALID_TAG_NAME = 25] = "INVALID_TAG_NAME", t[t.UNMATCHED_CLOSING_TAG = 26] = "UNMATCHED_CLOSING_TAG", t[t.UNCLOSED_TAG = 27] = "UNCLOSED_TAG";
})(q || (q = {}));
var K;
(function(t) {
  t[t.literal = 0] = "literal", t[t.argument = 1] = "argument", t[t.number = 2] = "number", t[t.date = 3] = "date", t[t.time = 4] = "time", t[t.select = 5] = "select", t[t.plural = 6] = "plural", t[t.pound = 7] = "pound", t[t.tag = 8] = "tag";
})(K || (K = {}));
var $t;
(function(t) {
  t[t.number = 0] = "number", t[t.dateTime = 1] = "dateTime";
})($t || ($t = {}));
function Er(t) {
  return t.type === K.literal;
}
function us(t) {
  return t.type === K.argument;
}
function gl(t) {
  return t.type === K.number;
}
function bl(t) {
  return t.type === K.date;
}
function vl(t) {
  return t.type === K.time;
}
function yl(t) {
  return t.type === K.select;
}
function wl(t) {
  return t.type === K.plural;
}
function cs(t) {
  return t.type === K.pound;
}
function Dl(t) {
  return t.type === K.tag;
}
function El(t) {
  return !!(t && typeof t == "object" && t.type === $t.number);
}
function xi(t) {
  return !!(t && typeof t == "object" && t.type === $t.dateTime);
}
var Fl = /[ \xA0\u1680\u2000-\u200A\u202F\u205F\u3000]/, hs = /(?:[Eec]{1,6}|G{1,5}|[Qq]{1,5}|(?:[yYur]+|U{1,5})|[ML]{1,5}|d{1,2}|D{1,3}|F{1}|[abB]{1,5}|[hkHK]{1,2}|w{1,2}|W{1}|m{1,2}|s{1,2}|[zZOvVxX]{1,4})(?=([^']*'[^']*')*[^']*$)/g;
function fs(t) {
  var e = {};
  return t.replace(hs, function(n) {
    var i = n.length;
    switch (n[0]) {
      case "G":
        e.era = i === 4 ? "long" : i === 5 ? "narrow" : "short";
        break;
      case "y":
        e.year = i === 2 ? "2-digit" : "numeric";
        break;
      case "Y":
      case "u":
      case "U":
      case "r":
        throw new RangeError("`Y/u/U/r` (year) patterns are not supported, use `y` instead");
      case "q":
      case "Q":
        throw new RangeError("`q/Q` (quarter) patterns are not supported");
      case "M":
      case "L":
        e.month = ["numeric", "2-digit", "short", "long", "narrow"][i - 1];
        break;
      case "w":
      case "W":
        throw new RangeError("`w/W` (week) patterns are not supported");
      case "d":
        e.day = ["numeric", "2-digit"][i - 1];
        break;
      case "D":
      case "F":
      case "g":
        throw new RangeError("`D/F/g` (day) patterns are not supported, use `d` instead");
      case "E":
        e.weekday = i === 4 ? "short" : i === 5 ? "narrow" : "short";
        break;
      case "e":
        if (i < 4)
          throw new RangeError("`e..eee` (weekday) patterns are not supported");
        e.weekday = ["short", "long", "narrow", "short"][i - 4];
        break;
      case "c":
        if (i < 4)
          throw new RangeError("`c..ccc` (weekday) patterns are not supported");
        e.weekday = ["short", "long", "narrow", "short"][i - 4];
        break;
      case "a":
        e.hour12 = !0;
        break;
      case "b":
      case "B":
        throw new RangeError("`b/B` (period) patterns are not supported, use `a` instead");
      case "h":
        e.hourCycle = "h12", e.hour = ["numeric", "2-digit"][i - 1];
        break;
      case "H":
        e.hourCycle = "h23", e.hour = ["numeric", "2-digit"][i - 1];
        break;
      case "K":
        e.hourCycle = "h11", e.hour = ["numeric", "2-digit"][i - 1];
        break;
      case "k":
        e.hourCycle = "h24", e.hour = ["numeric", "2-digit"][i - 1];
        break;
      case "j":
      case "J":
      case "C":
        throw new RangeError("`j/J/C` (hour) patterns are not supported, use `h/H/K/k` instead");
      case "m":
        e.minute = ["numeric", "2-digit"][i - 1];
        break;
      case "s":
        e.second = ["numeric", "2-digit"][i - 1];
        break;
      case "S":
      case "A":
        throw new RangeError("`S/A` (second) patterns are not supported, use `s` instead");
      case "z":
        e.timeZoneName = i < 4 ? "short" : "long";
        break;
      case "Z":
      case "O":
      case "v":
      case "V":
      case "X":
      case "x":
        throw new RangeError("`Z/O/v/V/X/x` (timeZone) patterns are not supported, use `z` instead");
    }
    return "";
  }), e;
}
var _s = /[\t-\r \x85\u200E\u200F\u2028\u2029]/i;
function ds(t) {
  if (t.length === 0)
    throw new Error("Number skeleton cannot be empty");
  for (var e = t.split(_s).filter(function(h) {
    return h.length > 0;
  }), n = [], i = 0, r = e; i < r.length; i++) {
    var l = r[i], a = l.split("/");
    if (a.length === 0)
      throw new Error("Invalid number skeleton");
    for (var o = a[0], s = a.slice(1), u = 0, c = s; u < c.length; u++) {
      var _ = c[u];
      if (_.length === 0)
        throw new Error("Invalid number skeleton");
    }
    n.push({ stem: o, options: s });
  }
  return n;
}
function ms(t) {
  return t.replace(/^(.*?)-/, "");
}
var Fr = /^\.(?:(0+)(\*)?|(#+)|(0+)(#+))$/g, kl = /^(@+)?(\+|#+)?[rs]?$/g, ps = /(\*)(0+)|(#+)(0+)|(0+)/g, Al = /^(0+)$/;
function kr(t) {
  var e = {};
  return t[t.length - 1] === "r" ? e.roundingPriority = "morePrecision" : t[t.length - 1] === "s" && (e.roundingPriority = "lessPrecision"), t.replace(kl, function(n, i, r) {
    return typeof r != "string" ? (e.minimumSignificantDigits = i.length, e.maximumSignificantDigits = i.length) : r === "+" ? e.minimumSignificantDigits = i.length : i[0] === "#" ? e.maximumSignificantDigits = i.length : (e.minimumSignificantDigits = i.length, e.maximumSignificantDigits = i.length + (typeof r == "string" ? r.length : 0)), "";
  }), e;
}
function Cl(t) {
  switch (t) {
    case "sign-auto":
      return {
        signDisplay: "auto"
      };
    case "sign-accounting":
    case "()":
      return {
        currencySign: "accounting"
      };
    case "sign-always":
    case "+!":
      return {
        signDisplay: "always"
      };
    case "sign-accounting-always":
    case "()!":
      return {
        signDisplay: "always",
        currencySign: "accounting"
      };
    case "sign-except-zero":
    case "+?":
      return {
        signDisplay: "exceptZero"
      };
    case "sign-accounting-except-zero":
    case "()?":
      return {
        signDisplay: "exceptZero",
        currencySign: "accounting"
      };
    case "sign-never":
    case "+_":
      return {
        signDisplay: "never"
      };
  }
}
function gs(t) {
  var e;
  if (t[0] === "E" && t[1] === "E" ? (e = {
    notation: "engineering"
  }, t = t.slice(2)) : t[0] === "E" && (e = {
    notation: "scientific"
  }, t = t.slice(1)), e) {
    var n = t.slice(0, 2);
    if (n === "+!" ? (e.signDisplay = "always", t = t.slice(2)) : n === "+?" && (e.signDisplay = "exceptZero", t = t.slice(2)), !Al.test(t))
      throw new Error("Malformed concise eng/scientific notation");
    e.minimumIntegerDigits = t.length;
  }
  return e;
}
function Ar(t) {
  var e = {}, n = Cl(t);
  return n || e;
}
function bs(t) {
  for (var e = {}, n = 0, i = t; n < i.length; n++) {
    var r = i[n];
    switch (r.stem) {
      case "percent":
      case "%":
        e.style = "percent";
        continue;
      case "%x100":
        e.style = "percent", e.scale = 100;
        continue;
      case "currency":
        e.style = "currency", e.currency = r.options[0];
        continue;
      case "group-off":
      case ",_":
        e.useGrouping = !1;
        continue;
      case "precision-integer":
      case ".":
        e.maximumFractionDigits = 0;
        continue;
      case "measure-unit":
      case "unit":
        e.style = "unit", e.unit = ms(r.options[0]);
        continue;
      case "compact-short":
      case "K":
        e.notation = "compact", e.compactDisplay = "short";
        continue;
      case "compact-long":
      case "KK":
        e.notation = "compact", e.compactDisplay = "long";
        continue;
      case "scientific":
        e = z(z(z({}, e), { notation: "scientific" }), r.options.reduce(function(s, u) {
          return z(z({}, s), Ar(u));
        }, {}));
        continue;
      case "engineering":
        e = z(z(z({}, e), { notation: "engineering" }), r.options.reduce(function(s, u) {
          return z(z({}, s), Ar(u));
        }, {}));
        continue;
      case "notation-simple":
        e.notation = "standard";
        continue;
      case "unit-width-narrow":
        e.currencyDisplay = "narrowSymbol", e.unitDisplay = "narrow";
        continue;
      case "unit-width-short":
        e.currencyDisplay = "code", e.unitDisplay = "short";
        continue;
      case "unit-width-full-name":
        e.currencyDisplay = "name", e.unitDisplay = "long";
        continue;
      case "unit-width-iso-code":
        e.currencyDisplay = "symbol";
        continue;
      case "scale":
        e.scale = parseFloat(r.options[0]);
        continue;
      case "integer-width":
        if (r.options.length > 1)
          throw new RangeError("integer-width stems only accept a single optional option");
        r.options[0].replace(ps, function(s, u, c, _, h, d) {
          if (u)
            e.minimumIntegerDigits = c.length;
          else {
            if (_ && h)
              throw new Error("We currently do not support maximum integer digits");
            if (d)
              throw new Error("We currently do not support exact integer digits");
          }
          return "";
        });
        continue;
    }
    if (Al.test(r.stem)) {
      e.minimumIntegerDigits = r.stem.length;
      continue;
    }
    if (Fr.test(r.stem)) {
      if (r.options.length > 1)
        throw new RangeError("Fraction-precision stems only accept a single optional option");
      r.stem.replace(Fr, function(s, u, c, _, h, d) {
        return c === "*" ? e.minimumFractionDigits = u.length : _ && _[0] === "#" ? e.maximumFractionDigits = _.length : h && d ? (e.minimumFractionDigits = h.length, e.maximumFractionDigits = h.length + d.length) : (e.minimumFractionDigits = u.length, e.maximumFractionDigits = u.length), "";
      });
      var l = r.options[0];
      l === "w" ? e = z(z({}, e), { trailingZeroDisplay: "stripIfInteger" }) : l && (e = z(z({}, e), kr(l)));
      continue;
    }
    if (kl.test(r.stem)) {
      e = z(z({}, e), kr(r.stem));
      continue;
    }
    var a = Cl(r.stem);
    a && (e = z(z({}, e), a));
    var o = gs(r.stem);
    o && (e = z(z({}, e), o));
  }
  return e;
}
var fn = {
  AX: [
    "H"
  ],
  BQ: [
    "H"
  ],
  CP: [
    "H"
  ],
  CZ: [
    "H"
  ],
  DK: [
    "H"
  ],
  FI: [
    "H"
  ],
  ID: [
    "H"
  ],
  IS: [
    "H"
  ],
  ML: [
    "H"
  ],
  NE: [
    "H"
  ],
  RU: [
    "H"
  ],
  SE: [
    "H"
  ],
  SJ: [
    "H"
  ],
  SK: [
    "H"
  ],
  AS: [
    "h",
    "H"
  ],
  BT: [
    "h",
    "H"
  ],
  DJ: [
    "h",
    "H"
  ],
  ER: [
    "h",
    "H"
  ],
  GH: [
    "h",
    "H"
  ],
  IN: [
    "h",
    "H"
  ],
  LS: [
    "h",
    "H"
  ],
  PG: [
    "h",
    "H"
  ],
  PW: [
    "h",
    "H"
  ],
  SO: [
    "h",
    "H"
  ],
  TO: [
    "h",
    "H"
  ],
  VU: [
    "h",
    "H"
  ],
  WS: [
    "h",
    "H"
  ],
  "001": [
    "H",
    "h"
  ],
  AL: [
    "h",
    "H",
    "hB"
  ],
  TD: [
    "h",
    "H",
    "hB"
  ],
  "ca-ES": [
    "H",
    "h",
    "hB"
  ],
  CF: [
    "H",
    "h",
    "hB"
  ],
  CM: [
    "H",
    "h",
    "hB"
  ],
  "fr-CA": [
    "H",
    "h",
    "hB"
  ],
  "gl-ES": [
    "H",
    "h",
    "hB"
  ],
  "it-CH": [
    "H",
    "h",
    "hB"
  ],
  "it-IT": [
    "H",
    "h",
    "hB"
  ],
  LU: [
    "H",
    "h",
    "hB"
  ],
  NP: [
    "H",
    "h",
    "hB"
  ],
  PF: [
    "H",
    "h",
    "hB"
  ],
  SC: [
    "H",
    "h",
    "hB"
  ],
  SM: [
    "H",
    "h",
    "hB"
  ],
  SN: [
    "H",
    "h",
    "hB"
  ],
  TF: [
    "H",
    "h",
    "hB"
  ],
  VA: [
    "H",
    "h",
    "hB"
  ],
  CY: [
    "h",
    "H",
    "hb",
    "hB"
  ],
  GR: [
    "h",
    "H",
    "hb",
    "hB"
  ],
  CO: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  DO: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  KP: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  KR: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  NA: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  PA: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  PR: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  VE: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  AC: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  AI: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  BW: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  BZ: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  CC: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  CK: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  CX: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  DG: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  FK: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  GB: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  GG: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  GI: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  IE: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  IM: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  IO: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  JE: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  LT: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  MK: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  MN: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  MS: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  NF: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  NG: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  NR: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  NU: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  PN: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  SH: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  SX: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  TA: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  ZA: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  "af-ZA": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  AR: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  CL: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  CR: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  CU: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  EA: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-BO": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-BR": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-EC": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-ES": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-GQ": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-PE": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  GT: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  HN: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  IC: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  KG: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  KM: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  LK: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  MA: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  MX: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  NI: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  PY: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  SV: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  UY: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  JP: [
    "H",
    "h",
    "K"
  ],
  AD: [
    "H",
    "hB"
  ],
  AM: [
    "H",
    "hB"
  ],
  AO: [
    "H",
    "hB"
  ],
  AT: [
    "H",
    "hB"
  ],
  AW: [
    "H",
    "hB"
  ],
  BE: [
    "H",
    "hB"
  ],
  BF: [
    "H",
    "hB"
  ],
  BJ: [
    "H",
    "hB"
  ],
  BL: [
    "H",
    "hB"
  ],
  BR: [
    "H",
    "hB"
  ],
  CG: [
    "H",
    "hB"
  ],
  CI: [
    "H",
    "hB"
  ],
  CV: [
    "H",
    "hB"
  ],
  DE: [
    "H",
    "hB"
  ],
  EE: [
    "H",
    "hB"
  ],
  FR: [
    "H",
    "hB"
  ],
  GA: [
    "H",
    "hB"
  ],
  GF: [
    "H",
    "hB"
  ],
  GN: [
    "H",
    "hB"
  ],
  GP: [
    "H",
    "hB"
  ],
  GW: [
    "H",
    "hB"
  ],
  HR: [
    "H",
    "hB"
  ],
  IL: [
    "H",
    "hB"
  ],
  IT: [
    "H",
    "hB"
  ],
  KZ: [
    "H",
    "hB"
  ],
  MC: [
    "H",
    "hB"
  ],
  MD: [
    "H",
    "hB"
  ],
  MF: [
    "H",
    "hB"
  ],
  MQ: [
    "H",
    "hB"
  ],
  MZ: [
    "H",
    "hB"
  ],
  NC: [
    "H",
    "hB"
  ],
  NL: [
    "H",
    "hB"
  ],
  PM: [
    "H",
    "hB"
  ],
  PT: [
    "H",
    "hB"
  ],
  RE: [
    "H",
    "hB"
  ],
  RO: [
    "H",
    "hB"
  ],
  SI: [
    "H",
    "hB"
  ],
  SR: [
    "H",
    "hB"
  ],
  ST: [
    "H",
    "hB"
  ],
  TG: [
    "H",
    "hB"
  ],
  TR: [
    "H",
    "hB"
  ],
  WF: [
    "H",
    "hB"
  ],
  YT: [
    "H",
    "hB"
  ],
  BD: [
    "h",
    "hB",
    "H"
  ],
  PK: [
    "h",
    "hB",
    "H"
  ],
  AZ: [
    "H",
    "hB",
    "h"
  ],
  BA: [
    "H",
    "hB",
    "h"
  ],
  BG: [
    "H",
    "hB",
    "h"
  ],
  CH: [
    "H",
    "hB",
    "h"
  ],
  GE: [
    "H",
    "hB",
    "h"
  ],
  LI: [
    "H",
    "hB",
    "h"
  ],
  ME: [
    "H",
    "hB",
    "h"
  ],
  RS: [
    "H",
    "hB",
    "h"
  ],
  UA: [
    "H",
    "hB",
    "h"
  ],
  UZ: [
    "H",
    "hB",
    "h"
  ],
  XK: [
    "H",
    "hB",
    "h"
  ],
  AG: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  AU: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  BB: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  BM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  BS: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  CA: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  DM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  "en-001": [
    "h",
    "hb",
    "H",
    "hB"
  ],
  FJ: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  FM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  GD: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  GM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  GU: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  GY: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  JM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  KI: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  KN: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  KY: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  LC: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  LR: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  MH: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  MP: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  MW: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  NZ: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  SB: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  SG: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  SL: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  SS: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  SZ: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  TC: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  TT: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  UM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  US: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  VC: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  VG: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  VI: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  ZM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  BO: [
    "H",
    "hB",
    "h",
    "hb"
  ],
  EC: [
    "H",
    "hB",
    "h",
    "hb"
  ],
  ES: [
    "H",
    "hB",
    "h",
    "hb"
  ],
  GQ: [
    "H",
    "hB",
    "h",
    "hb"
  ],
  PE: [
    "H",
    "hB",
    "h",
    "hb"
  ],
  AE: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  "ar-001": [
    "h",
    "hB",
    "hb",
    "H"
  ],
  BH: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  DZ: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  EG: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  EH: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  HK: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  IQ: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  JO: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  KW: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  LB: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  LY: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  MO: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  MR: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  OM: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  PH: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  PS: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  QA: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  SA: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  SD: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  SY: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  TN: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  YE: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  AF: [
    "H",
    "hb",
    "hB",
    "h"
  ],
  LA: [
    "H",
    "hb",
    "hB",
    "h"
  ],
  CN: [
    "H",
    "hB",
    "hb",
    "h"
  ],
  LV: [
    "H",
    "hB",
    "hb",
    "h"
  ],
  TL: [
    "H",
    "hB",
    "hb",
    "h"
  ],
  "zu-ZA": [
    "H",
    "hB",
    "hb",
    "h"
  ],
  CD: [
    "hB",
    "H"
  ],
  IR: [
    "hB",
    "H"
  ],
  "hi-IN": [
    "hB",
    "h",
    "H"
  ],
  "kn-IN": [
    "hB",
    "h",
    "H"
  ],
  "ml-IN": [
    "hB",
    "h",
    "H"
  ],
  "te-IN": [
    "hB",
    "h",
    "H"
  ],
  KH: [
    "hB",
    "h",
    "H",
    "hb"
  ],
  "ta-IN": [
    "hB",
    "h",
    "hb",
    "H"
  ],
  BN: [
    "hb",
    "hB",
    "h",
    "H"
  ],
  MY: [
    "hb",
    "hB",
    "h",
    "H"
  ],
  ET: [
    "hB",
    "hb",
    "h",
    "H"
  ],
  "gu-IN": [
    "hB",
    "hb",
    "h",
    "H"
  ],
  "mr-IN": [
    "hB",
    "hb",
    "h",
    "H"
  ],
  "pa-IN": [
    "hB",
    "hb",
    "h",
    "H"
  ],
  TW: [
    "hB",
    "hb",
    "h",
    "H"
  ],
  KE: [
    "hB",
    "hb",
    "H",
    "h"
  ],
  MM: [
    "hB",
    "hb",
    "H",
    "h"
  ],
  TZ: [
    "hB",
    "hb",
    "H",
    "h"
  ],
  UG: [
    "hB",
    "hb",
    "H",
    "h"
  ]
};
function vs(t, e) {
  for (var n = "", i = 0; i < t.length; i++) {
    var r = t.charAt(i);
    if (r === "j") {
      for (var l = 0; i + 1 < t.length && t.charAt(i + 1) === r; )
        l++, i++;
      var a = 1 + (l & 1), o = l < 2 ? 1 : 3 + (l >> 1), s = "a", u = ys(e);
      for ((u == "H" || u == "k") && (o = 0); o-- > 0; )
        n += s;
      for (; a-- > 0; )
        n = u + n;
    } else r === "J" ? n += "H" : n += r;
  }
  return n;
}
function ys(t) {
  var e = t.hourCycle;
  if (e === void 0 && // @ts-ignore hourCycle(s) is not identified yet
  t.hourCycles && // @ts-ignore
  t.hourCycles.length && (e = t.hourCycles[0]), e)
    switch (e) {
      case "h24":
        return "k";
      case "h23":
        return "H";
      case "h12":
        return "h";
      case "h11":
        return "K";
      default:
        throw new Error("Invalid hourCycle");
    }
  var n = t.language, i;
  n !== "root" && (i = t.maximize().region);
  var r = fn[i || ""] || fn[n || ""] || fn["".concat(n, "-001")] || fn["001"];
  return r[0];
}
var ri, ws = new RegExp("^".concat(Fl.source, "*")), Ds = new RegExp("".concat(Fl.source, "*$"));
function U(t, e) {
  return { start: t, end: e };
}
var Es = !!String.prototype.startsWith, Fs = !!String.fromCodePoint, ks = !!Object.fromEntries, As = !!String.prototype.codePointAt, Cs = !!String.prototype.trimStart, Ss = !!String.prototype.trimEnd, xs = !!Number.isSafeInteger, Bs = xs ? Number.isSafeInteger : function(t) {
  return typeof t == "number" && isFinite(t) && Math.floor(t) === t && Math.abs(t) <= 9007199254740991;
}, Bi = !0;
try {
  var $s = xl("([^\\p{White_Space}\\p{Pattern_Syntax}]*)", "yu");
  Bi = ((ri = $s.exec("a")) === null || ri === void 0 ? void 0 : ri[0]) === "a";
} catch {
  Bi = !1;
}
var Cr = Es ? (
  // Native
  function(e, n, i) {
    return e.startsWith(n, i);
  }
) : (
  // For IE11
  function(e, n, i) {
    return e.slice(i, i + n.length) === n;
  }
), $i = Fs ? String.fromCodePoint : (
  // IE11
  function() {
    for (var e = [], n = 0; n < arguments.length; n++)
      e[n] = arguments[n];
    for (var i = "", r = e.length, l = 0, a; r > l; ) {
      if (a = e[l++], a > 1114111)
        throw RangeError(a + " is not a valid code point");
      i += a < 65536 ? String.fromCharCode(a) : String.fromCharCode(((a -= 65536) >> 10) + 55296, a % 1024 + 56320);
    }
    return i;
  }
), Sr = (
  // native
  ks ? Object.fromEntries : (
    // Ponyfill
    function(e) {
      for (var n = {}, i = 0, r = e; i < r.length; i++) {
        var l = r[i], a = l[0], o = l[1];
        n[a] = o;
      }
      return n;
    }
  )
), Sl = As ? (
  // Native
  function(e, n) {
    return e.codePointAt(n);
  }
) : (
  // IE 11
  function(e, n) {
    var i = e.length;
    if (!(n < 0 || n >= i)) {
      var r = e.charCodeAt(n), l;
      return r < 55296 || r > 56319 || n + 1 === i || (l = e.charCodeAt(n + 1)) < 56320 || l > 57343 ? r : (r - 55296 << 10) + (l - 56320) + 65536;
    }
  }
), Ts = Cs ? (
  // Native
  function(e) {
    return e.trimStart();
  }
) : (
  // Ponyfill
  function(e) {
    return e.replace(ws, "");
  }
), Is = Ss ? (
  // Native
  function(e) {
    return e.trimEnd();
  }
) : (
  // Ponyfill
  function(e) {
    return e.replace(Ds, "");
  }
);
function xl(t, e) {
  return new RegExp(t, e);
}
var Ti;
if (Bi) {
  var xr = xl("([^\\p{White_Space}\\p{Pattern_Syntax}]*)", "yu");
  Ti = function(e, n) {
    var i;
    xr.lastIndex = n;
    var r = xr.exec(e);
    return (i = r[1]) !== null && i !== void 0 ? i : "";
  };
} else
  Ti = function(e, n) {
    for (var i = []; ; ) {
      var r = Sl(e, n);
      if (r === void 0 || Bl(r) || Ns(r))
        break;
      i.push(r), n += r >= 65536 ? 2 : 1;
    }
    return $i.apply(void 0, i);
  };
var Ls = (
  /** @class */
  function() {
    function t(e, n) {
      n === void 0 && (n = {}), this.message = e, this.position = { offset: 0, line: 1, column: 1 }, this.ignoreTag = !!n.ignoreTag, this.locale = n.locale, this.requiresOtherClause = !!n.requiresOtherClause, this.shouldParseSkeletons = !!n.shouldParseSkeletons;
    }
    return t.prototype.parse = function() {
      if (this.offset() !== 0)
        throw Error("parser can only be used once");
      return this.parseMessage(0, "", !1);
    }, t.prototype.parseMessage = function(e, n, i) {
      for (var r = []; !this.isEOF(); ) {
        var l = this.char();
        if (l === 123) {
          var a = this.parseArgument(e, i);
          if (a.err)
            return a;
          r.push(a.val);
        } else {
          if (l === 125 && e > 0)
            break;
          if (l === 35 && (n === "plural" || n === "selectordinal")) {
            var o = this.clonePosition();
            this.bump(), r.push({
              type: K.pound,
              location: U(o, this.clonePosition())
            });
          } else if (l === 60 && !this.ignoreTag && this.peek() === 47) {
            if (i)
              break;
            return this.error(q.UNMATCHED_CLOSING_TAG, U(this.clonePosition(), this.clonePosition()));
          } else if (l === 60 && !this.ignoreTag && Ii(this.peek() || 0)) {
            var a = this.parseTag(e, n);
            if (a.err)
              return a;
            r.push(a.val);
          } else {
            var a = this.parseLiteral(e, n);
            if (a.err)
              return a;
            r.push(a.val);
          }
        }
      }
      return { val: r, err: null };
    }, t.prototype.parseTag = function(e, n) {
      var i = this.clonePosition();
      this.bump();
      var r = this.parseTagName();
      if (this.bumpSpace(), this.bumpIf("/>"))
        return {
          val: {
            type: K.literal,
            value: "<".concat(r, "/>"),
            location: U(i, this.clonePosition())
          },
          err: null
        };
      if (this.bumpIf(">")) {
        var l = this.parseMessage(e + 1, n, !0);
        if (l.err)
          return l;
        var a = l.val, o = this.clonePosition();
        if (this.bumpIf("</")) {
          if (this.isEOF() || !Ii(this.char()))
            return this.error(q.INVALID_TAG, U(o, this.clonePosition()));
          var s = this.clonePosition(), u = this.parseTagName();
          return r !== u ? this.error(q.UNMATCHED_CLOSING_TAG, U(s, this.clonePosition())) : (this.bumpSpace(), this.bumpIf(">") ? {
            val: {
              type: K.tag,
              value: r,
              children: a,
              location: U(i, this.clonePosition())
            },
            err: null
          } : this.error(q.INVALID_TAG, U(o, this.clonePosition())));
        } else
          return this.error(q.UNCLOSED_TAG, U(i, this.clonePosition()));
      } else
        return this.error(q.INVALID_TAG, U(i, this.clonePosition()));
    }, t.prototype.parseTagName = function() {
      var e = this.offset();
      for (this.bump(); !this.isEOF() && Ps(this.char()); )
        this.bump();
      return this.message.slice(e, this.offset());
    }, t.prototype.parseLiteral = function(e, n) {
      for (var i = this.clonePosition(), r = ""; ; ) {
        var l = this.tryParseQuote(n);
        if (l) {
          r += l;
          continue;
        }
        var a = this.tryParseUnquoted(e, n);
        if (a) {
          r += a;
          continue;
        }
        var o = this.tryParseLeftAngleBracket();
        if (o) {
          r += o;
          continue;
        }
        break;
      }
      var s = U(i, this.clonePosition());
      return {
        val: { type: K.literal, value: r, location: s },
        err: null
      };
    }, t.prototype.tryParseLeftAngleBracket = function() {
      return !this.isEOF() && this.char() === 60 && (this.ignoreTag || // If at the opening tag or closing tag position, bail.
      !Hs(this.peek() || 0)) ? (this.bump(), "<") : null;
    }, t.prototype.tryParseQuote = function(e) {
      if (this.isEOF() || this.char() !== 39)
        return null;
      switch (this.peek()) {
        case 39:
          return this.bump(), this.bump(), "'";
        case 123:
        case 60:
        case 62:
        case 125:
          break;
        case 35:
          if (e === "plural" || e === "selectordinal")
            break;
          return null;
        default:
          return null;
      }
      this.bump();
      var n = [this.char()];
      for (this.bump(); !this.isEOF(); ) {
        var i = this.char();
        if (i === 39)
          if (this.peek() === 39)
            n.push(39), this.bump();
          else {
            this.bump();
            break;
          }
        else
          n.push(i);
        this.bump();
      }
      return $i.apply(void 0, n);
    }, t.prototype.tryParseUnquoted = function(e, n) {
      if (this.isEOF())
        return null;
      var i = this.char();
      return i === 60 || i === 123 || i === 35 && (n === "plural" || n === "selectordinal") || i === 125 && e > 0 ? null : (this.bump(), $i(i));
    }, t.prototype.parseArgument = function(e, n) {
      var i = this.clonePosition();
      if (this.bump(), this.bumpSpace(), this.isEOF())
        return this.error(q.EXPECT_ARGUMENT_CLOSING_BRACE, U(i, this.clonePosition()));
      if (this.char() === 125)
        return this.bump(), this.error(q.EMPTY_ARGUMENT, U(i, this.clonePosition()));
      var r = this.parseIdentifierIfPossible().value;
      if (!r)
        return this.error(q.MALFORMED_ARGUMENT, U(i, this.clonePosition()));
      if (this.bumpSpace(), this.isEOF())
        return this.error(q.EXPECT_ARGUMENT_CLOSING_BRACE, U(i, this.clonePosition()));
      switch (this.char()) {
        case 125:
          return this.bump(), {
            val: {
              type: K.argument,
              // value does not include the opening and closing braces.
              value: r,
              location: U(i, this.clonePosition())
            },
            err: null
          };
        case 44:
          return this.bump(), this.bumpSpace(), this.isEOF() ? this.error(q.EXPECT_ARGUMENT_CLOSING_BRACE, U(i, this.clonePosition())) : this.parseArgumentOptions(e, n, r, i);
        default:
          return this.error(q.MALFORMED_ARGUMENT, U(i, this.clonePosition()));
      }
    }, t.prototype.parseIdentifierIfPossible = function() {
      var e = this.clonePosition(), n = this.offset(), i = Ti(this.message, n), r = n + i.length;
      this.bumpTo(r);
      var l = this.clonePosition(), a = U(e, l);
      return { value: i, location: a };
    }, t.prototype.parseArgumentOptions = function(e, n, i, r) {
      var l, a = this.clonePosition(), o = this.parseIdentifierIfPossible().value, s = this.clonePosition();
      switch (o) {
        case "":
          return this.error(q.EXPECT_ARGUMENT_TYPE, U(a, s));
        case "number":
        case "date":
        case "time": {
          this.bumpSpace();
          var u = null;
          if (this.bumpIf(",")) {
            this.bumpSpace();
            var c = this.clonePosition(), _ = this.parseSimpleArgStyleIfPossible();
            if (_.err)
              return _;
            var h = Is(_.val);
            if (h.length === 0)
              return this.error(q.EXPECT_ARGUMENT_STYLE, U(this.clonePosition(), this.clonePosition()));
            var d = U(c, this.clonePosition());
            u = { style: h, styleLocation: d };
          }
          var D = this.tryParseArgumentClose(r);
          if (D.err)
            return D;
          var E = U(r, this.clonePosition());
          if (u && Cr(u == null ? void 0 : u.style, "::", 0)) {
            var F = Ts(u.style.slice(2));
            if (o === "number") {
              var _ = this.parseNumberSkeletonFromString(F, u.styleLocation);
              return _.err ? _ : {
                val: { type: K.number, value: i, location: E, style: _.val },
                err: null
              };
            } else {
              if (F.length === 0)
                return this.error(q.EXPECT_DATE_TIME_SKELETON, E);
              var C = F;
              this.locale && (C = vs(F, this.locale));
              var h = {
                type: $t.dateTime,
                pattern: C,
                location: u.styleLocation,
                parsedOptions: this.shouldParseSkeletons ? fs(C) : {}
              }, g = o === "date" ? K.date : K.time;
              return {
                val: { type: g, value: i, location: E, style: h },
                err: null
              };
            }
          }
          return {
            val: {
              type: o === "number" ? K.number : o === "date" ? K.date : K.time,
              value: i,
              location: E,
              style: (l = u == null ? void 0 : u.style) !== null && l !== void 0 ? l : null
            },
            err: null
          };
        }
        case "plural":
        case "selectordinal":
        case "select": {
          var f = this.clonePosition();
          if (this.bumpSpace(), !this.bumpIf(","))
            return this.error(q.EXPECT_SELECT_ARGUMENT_OPTIONS, U(f, z({}, f)));
          this.bumpSpace();
          var m = this.parseIdentifierIfPossible(), v = 0;
          if (o !== "select" && m.value === "offset") {
            if (!this.bumpIf(":"))
              return this.error(q.EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE, U(this.clonePosition(), this.clonePosition()));
            this.bumpSpace();
            var _ = this.tryParseDecimalInteger(q.EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE, q.INVALID_PLURAL_ARGUMENT_OFFSET_VALUE);
            if (_.err)
              return _;
            this.bumpSpace(), m = this.parseIdentifierIfPossible(), v = _.val;
          }
          var p = this.tryParsePluralOrSelectOptions(e, o, n, m);
          if (p.err)
            return p;
          var D = this.tryParseArgumentClose(r);
          if (D.err)
            return D;
          var b = U(r, this.clonePosition());
          return o === "select" ? {
            val: {
              type: K.select,
              value: i,
              options: Sr(p.val),
              location: b
            },
            err: null
          } : {
            val: {
              type: K.plural,
              value: i,
              options: Sr(p.val),
              offset: v,
              pluralType: o === "plural" ? "cardinal" : "ordinal",
              location: b
            },
            err: null
          };
        }
        default:
          return this.error(q.INVALID_ARGUMENT_TYPE, U(a, s));
      }
    }, t.prototype.tryParseArgumentClose = function(e) {
      return this.isEOF() || this.char() !== 125 ? this.error(q.EXPECT_ARGUMENT_CLOSING_BRACE, U(e, this.clonePosition())) : (this.bump(), { val: !0, err: null });
    }, t.prototype.parseSimpleArgStyleIfPossible = function() {
      for (var e = 0, n = this.clonePosition(); !this.isEOF(); ) {
        var i = this.char();
        switch (i) {
          case 39: {
            this.bump();
            var r = this.clonePosition();
            if (!this.bumpUntil("'"))
              return this.error(q.UNCLOSED_QUOTE_IN_ARGUMENT_STYLE, U(r, this.clonePosition()));
            this.bump();
            break;
          }
          case 123: {
            e += 1, this.bump();
            break;
          }
          case 125: {
            if (e > 0)
              e -= 1;
            else
              return {
                val: this.message.slice(n.offset, this.offset()),
                err: null
              };
            break;
          }
          default:
            this.bump();
            break;
        }
      }
      return {
        val: this.message.slice(n.offset, this.offset()),
        err: null
      };
    }, t.prototype.parseNumberSkeletonFromString = function(e, n) {
      var i = [];
      try {
        i = ds(e);
      } catch {
        return this.error(q.INVALID_NUMBER_SKELETON, n);
      }
      return {
        val: {
          type: $t.number,
          tokens: i,
          location: n,
          parsedOptions: this.shouldParseSkeletons ? bs(i) : {}
        },
        err: null
      };
    }, t.prototype.tryParsePluralOrSelectOptions = function(e, n, i, r) {
      for (var l, a = !1, o = [], s = /* @__PURE__ */ new Set(), u = r.value, c = r.location; ; ) {
        if (u.length === 0) {
          var _ = this.clonePosition();
          if (n !== "select" && this.bumpIf("=")) {
            var h = this.tryParseDecimalInteger(q.EXPECT_PLURAL_ARGUMENT_SELECTOR, q.INVALID_PLURAL_ARGUMENT_SELECTOR);
            if (h.err)
              return h;
            c = U(_, this.clonePosition()), u = this.message.slice(_.offset, this.offset());
          } else
            break;
        }
        if (s.has(u))
          return this.error(n === "select" ? q.DUPLICATE_SELECT_ARGUMENT_SELECTOR : q.DUPLICATE_PLURAL_ARGUMENT_SELECTOR, c);
        u === "other" && (a = !0), this.bumpSpace();
        var d = this.clonePosition();
        if (!this.bumpIf("{"))
          return this.error(n === "select" ? q.EXPECT_SELECT_ARGUMENT_SELECTOR_FRAGMENT : q.EXPECT_PLURAL_ARGUMENT_SELECTOR_FRAGMENT, U(this.clonePosition(), this.clonePosition()));
        var D = this.parseMessage(e + 1, n, i);
        if (D.err)
          return D;
        var E = this.tryParseArgumentClose(d);
        if (E.err)
          return E;
        o.push([
          u,
          {
            value: D.val,
            location: U(d, this.clonePosition())
          }
        ]), s.add(u), this.bumpSpace(), l = this.parseIdentifierIfPossible(), u = l.value, c = l.location;
      }
      return o.length === 0 ? this.error(n === "select" ? q.EXPECT_SELECT_ARGUMENT_SELECTOR : q.EXPECT_PLURAL_ARGUMENT_SELECTOR, U(this.clonePosition(), this.clonePosition())) : this.requiresOtherClause && !a ? this.error(q.MISSING_OTHER_CLAUSE, U(this.clonePosition(), this.clonePosition())) : { val: o, err: null };
    }, t.prototype.tryParseDecimalInteger = function(e, n) {
      var i = 1, r = this.clonePosition();
      this.bumpIf("+") || this.bumpIf("-") && (i = -1);
      for (var l = !1, a = 0; !this.isEOF(); ) {
        var o = this.char();
        if (o >= 48 && o <= 57)
          l = !0, a = a * 10 + (o - 48), this.bump();
        else
          break;
      }
      var s = U(r, this.clonePosition());
      return l ? (a *= i, Bs(a) ? { val: a, err: null } : this.error(n, s)) : this.error(e, s);
    }, t.prototype.offset = function() {
      return this.position.offset;
    }, t.prototype.isEOF = function() {
      return this.offset() === this.message.length;
    }, t.prototype.clonePosition = function() {
      return {
        offset: this.position.offset,
        line: this.position.line,
        column: this.position.column
      };
    }, t.prototype.char = function() {
      var e = this.position.offset;
      if (e >= this.message.length)
        throw Error("out of bound");
      var n = Sl(this.message, e);
      if (n === void 0)
        throw Error("Offset ".concat(e, " is at invalid UTF-16 code unit boundary"));
      return n;
    }, t.prototype.error = function(e, n) {
      return {
        val: null,
        err: {
          kind: e,
          message: this.message,
          location: n
        }
      };
    }, t.prototype.bump = function() {
      if (!this.isEOF()) {
        var e = this.char();
        e === 10 ? (this.position.line += 1, this.position.column = 1, this.position.offset += 1) : (this.position.column += 1, this.position.offset += e < 65536 ? 1 : 2);
      }
    }, t.prototype.bumpIf = function(e) {
      if (Cr(this.message, e, this.offset())) {
        for (var n = 0; n < e.length; n++)
          this.bump();
        return !0;
      }
      return !1;
    }, t.prototype.bumpUntil = function(e) {
      var n = this.offset(), i = this.message.indexOf(e, n);
      return i >= 0 ? (this.bumpTo(i), !0) : (this.bumpTo(this.message.length), !1);
    }, t.prototype.bumpTo = function(e) {
      if (this.offset() > e)
        throw Error("targetOffset ".concat(e, " must be greater than or equal to the current offset ").concat(this.offset()));
      for (e = Math.min(e, this.message.length); ; ) {
        var n = this.offset();
        if (n === e)
          break;
        if (n > e)
          throw Error("targetOffset ".concat(e, " is at invalid UTF-16 code unit boundary"));
        if (this.bump(), this.isEOF())
          break;
      }
    }, t.prototype.bumpSpace = function() {
      for (; !this.isEOF() && Bl(this.char()); )
        this.bump();
    }, t.prototype.peek = function() {
      if (this.isEOF())
        return null;
      var e = this.char(), n = this.offset(), i = this.message.charCodeAt(n + (e >= 65536 ? 2 : 1));
      return i ?? null;
    }, t;
  }()
);
function Ii(t) {
  return t >= 97 && t <= 122 || t >= 65 && t <= 90;
}
function Hs(t) {
  return Ii(t) || t === 47;
}
function Ps(t) {
  return t === 45 || t === 46 || t >= 48 && t <= 57 || t === 95 || t >= 97 && t <= 122 || t >= 65 && t <= 90 || t == 183 || t >= 192 && t <= 214 || t >= 216 && t <= 246 || t >= 248 && t <= 893 || t >= 895 && t <= 8191 || t >= 8204 && t <= 8205 || t >= 8255 && t <= 8256 || t >= 8304 && t <= 8591 || t >= 11264 && t <= 12271 || t >= 12289 && t <= 55295 || t >= 63744 && t <= 64975 || t >= 65008 && t <= 65533 || t >= 65536 && t <= 983039;
}
function Bl(t) {
  return t >= 9 && t <= 13 || t === 32 || t === 133 || t >= 8206 && t <= 8207 || t === 8232 || t === 8233;
}
function Ns(t) {
  return t >= 33 && t <= 35 || t === 36 || t >= 37 && t <= 39 || t === 40 || t === 41 || t === 42 || t === 43 || t === 44 || t === 45 || t >= 46 && t <= 47 || t >= 58 && t <= 59 || t >= 60 && t <= 62 || t >= 63 && t <= 64 || t === 91 || t === 92 || t === 93 || t === 94 || t === 96 || t === 123 || t === 124 || t === 125 || t === 126 || t === 161 || t >= 162 && t <= 165 || t === 166 || t === 167 || t === 169 || t === 171 || t === 172 || t === 174 || t === 176 || t === 177 || t === 182 || t === 187 || t === 191 || t === 215 || t === 247 || t >= 8208 && t <= 8213 || t >= 8214 && t <= 8215 || t === 8216 || t === 8217 || t === 8218 || t >= 8219 && t <= 8220 || t === 8221 || t === 8222 || t === 8223 || t >= 8224 && t <= 8231 || t >= 8240 && t <= 8248 || t === 8249 || t === 8250 || t >= 8251 && t <= 8254 || t >= 8257 && t <= 8259 || t === 8260 || t === 8261 || t === 8262 || t >= 8263 && t <= 8273 || t === 8274 || t === 8275 || t >= 8277 && t <= 8286 || t >= 8592 && t <= 8596 || t >= 8597 && t <= 8601 || t >= 8602 && t <= 8603 || t >= 8604 && t <= 8607 || t === 8608 || t >= 8609 && t <= 8610 || t === 8611 || t >= 8612 && t <= 8613 || t === 8614 || t >= 8615 && t <= 8621 || t === 8622 || t >= 8623 && t <= 8653 || t >= 8654 && t <= 8655 || t >= 8656 && t <= 8657 || t === 8658 || t === 8659 || t === 8660 || t >= 8661 && t <= 8691 || t >= 8692 && t <= 8959 || t >= 8960 && t <= 8967 || t === 8968 || t === 8969 || t === 8970 || t === 8971 || t >= 8972 && t <= 8991 || t >= 8992 && t <= 8993 || t >= 8994 && t <= 9e3 || t === 9001 || t === 9002 || t >= 9003 && t <= 9083 || t === 9084 || t >= 9085 && t <= 9114 || t >= 9115 && t <= 9139 || t >= 9140 && t <= 9179 || t >= 9180 && t <= 9185 || t >= 9186 && t <= 9254 || t >= 9255 && t <= 9279 || t >= 9280 && t <= 9290 || t >= 9291 && t <= 9311 || t >= 9472 && t <= 9654 || t === 9655 || t >= 9656 && t <= 9664 || t === 9665 || t >= 9666 && t <= 9719 || t >= 9720 && t <= 9727 || t >= 9728 && t <= 9838 || t === 9839 || t >= 9840 && t <= 10087 || t === 10088 || t === 10089 || t === 10090 || t === 10091 || t === 10092 || t === 10093 || t === 10094 || t === 10095 || t === 10096 || t === 10097 || t === 10098 || t === 10099 || t === 10100 || t === 10101 || t >= 10132 && t <= 10175 || t >= 10176 && t <= 10180 || t === 10181 || t === 10182 || t >= 10183 && t <= 10213 || t === 10214 || t === 10215 || t === 10216 || t === 10217 || t === 10218 || t === 10219 || t === 10220 || t === 10221 || t === 10222 || t === 10223 || t >= 10224 && t <= 10239 || t >= 10240 && t <= 10495 || t >= 10496 && t <= 10626 || t === 10627 || t === 10628 || t === 10629 || t === 10630 || t === 10631 || t === 10632 || t === 10633 || t === 10634 || t === 10635 || t === 10636 || t === 10637 || t === 10638 || t === 10639 || t === 10640 || t === 10641 || t === 10642 || t === 10643 || t === 10644 || t === 10645 || t === 10646 || t === 10647 || t === 10648 || t >= 10649 && t <= 10711 || t === 10712 || t === 10713 || t === 10714 || t === 10715 || t >= 10716 && t <= 10747 || t === 10748 || t === 10749 || t >= 10750 && t <= 11007 || t >= 11008 && t <= 11055 || t >= 11056 && t <= 11076 || t >= 11077 && t <= 11078 || t >= 11079 && t <= 11084 || t >= 11085 && t <= 11123 || t >= 11124 && t <= 11125 || t >= 11126 && t <= 11157 || t === 11158 || t >= 11159 && t <= 11263 || t >= 11776 && t <= 11777 || t === 11778 || t === 11779 || t === 11780 || t === 11781 || t >= 11782 && t <= 11784 || t === 11785 || t === 11786 || t === 11787 || t === 11788 || t === 11789 || t >= 11790 && t <= 11798 || t === 11799 || t >= 11800 && t <= 11801 || t === 11802 || t === 11803 || t === 11804 || t === 11805 || t >= 11806 && t <= 11807 || t === 11808 || t === 11809 || t === 11810 || t === 11811 || t === 11812 || t === 11813 || t === 11814 || t === 11815 || t === 11816 || t === 11817 || t >= 11818 && t <= 11822 || t === 11823 || t >= 11824 && t <= 11833 || t >= 11834 && t <= 11835 || t >= 11836 && t <= 11839 || t === 11840 || t === 11841 || t === 11842 || t >= 11843 && t <= 11855 || t >= 11856 && t <= 11857 || t === 11858 || t >= 11859 && t <= 11903 || t >= 12289 && t <= 12291 || t === 12296 || t === 12297 || t === 12298 || t === 12299 || t === 12300 || t === 12301 || t === 12302 || t === 12303 || t === 12304 || t === 12305 || t >= 12306 && t <= 12307 || t === 12308 || t === 12309 || t === 12310 || t === 12311 || t === 12312 || t === 12313 || t === 12314 || t === 12315 || t === 12316 || t === 12317 || t >= 12318 && t <= 12319 || t === 12320 || t === 12336 || t === 64830 || t === 64831 || t >= 65093 && t <= 65094;
}
function Li(t) {
  t.forEach(function(e) {
    if (delete e.location, yl(e) || wl(e))
      for (var n in e.options)
        delete e.options[n].location, Li(e.options[n].value);
    else gl(e) && El(e.style) || (bl(e) || vl(e)) && xi(e.style) ? delete e.style.location : Dl(e) && Li(e.children);
  });
}
function Os(t, e) {
  e === void 0 && (e = {}), e = z({ shouldParseSkeletons: !0, requiresOtherClause: !0 }, e);
  var n = new Ls(t, e).parse();
  if (n.err) {
    var i = SyntaxError(q[n.err.kind]);
    throw i.location = n.err.location, i.originalMessage = n.err.message, i;
  }
  return e != null && e.captureLocation || Li(n.val), n.val;
}
function ai(t, e) {
  var n = e && e.cache ? e.cache : zs, i = e && e.serializer ? e.serializer : Gs, r = e && e.strategy ? e.strategy : qs;
  return r(t, {
    cache: n,
    serializer: i
  });
}
function Rs(t) {
  return t == null || typeof t == "number" || typeof t == "boolean";
}
function Ms(t, e, n, i) {
  var r = Rs(i) ? i : n(i), l = e.get(r);
  return typeof l > "u" && (l = t.call(this, i), e.set(r, l)), l;
}
function $l(t, e, n) {
  var i = Array.prototype.slice.call(arguments, 3), r = n(i), l = e.get(r);
  return typeof l > "u" && (l = t.apply(this, i), e.set(r, l)), l;
}
function Tl(t, e, n, i, r) {
  return n.bind(e, t, i, r);
}
function qs(t, e) {
  var n = t.length === 1 ? Ms : $l;
  return Tl(t, this, n, e.cache.create(), e.serializer);
}
function Us(t, e) {
  return Tl(t, this, $l, e.cache.create(), e.serializer);
}
var Gs = function() {
  return JSON.stringify(arguments);
};
function er() {
  this.cache = /* @__PURE__ */ Object.create(null);
}
er.prototype.get = function(t) {
  return this.cache[t];
};
er.prototype.set = function(t, e) {
  this.cache[t] = e;
};
var zs = {
  create: function() {
    return new er();
  }
}, li = {
  variadic: Us
}, Tt;
(function(t) {
  t.MISSING_VALUE = "MISSING_VALUE", t.INVALID_VALUE = "INVALID_VALUE", t.MISSING_INTL_API = "MISSING_INTL_API";
})(Tt || (Tt = {}));
var Xn = (
  /** @class */
  function(t) {
    Vn(e, t);
    function e(n, i, r) {
      var l = t.call(this, n) || this;
      return l.code = i, l.originalMessage = r, l;
    }
    return e.prototype.toString = function() {
      return "[formatjs Error: ".concat(this.code, "] ").concat(this.message);
    }, e;
  }(Error)
), Br = (
  /** @class */
  function(t) {
    Vn(e, t);
    function e(n, i, r, l) {
      return t.call(this, 'Invalid values for "'.concat(n, '": "').concat(i, '". Options are "').concat(Object.keys(r).join('", "'), '"'), Tt.INVALID_VALUE, l) || this;
    }
    return e;
  }(Xn)
), js = (
  /** @class */
  function(t) {
    Vn(e, t);
    function e(n, i, r) {
      return t.call(this, 'Value for "'.concat(n, '" must be of type ').concat(i), Tt.INVALID_VALUE, r) || this;
    }
    return e;
  }(Xn)
), Vs = (
  /** @class */
  function(t) {
    Vn(e, t);
    function e(n, i) {
      return t.call(this, 'The intl string context variable "'.concat(n, '" was not provided to the string "').concat(i, '"'), Tt.MISSING_VALUE, i) || this;
    }
    return e;
  }(Xn)
), de;
(function(t) {
  t[t.literal = 0] = "literal", t[t.object = 1] = "object";
})(de || (de = {}));
function Xs(t) {
  return t.length < 2 ? t : t.reduce(function(e, n) {
    var i = e[e.length - 1];
    return !i || i.type !== de.literal || n.type !== de.literal ? e.push(n) : i.value += n.value, e;
  }, []);
}
function Zs(t) {
  return typeof t == "function";
}
function An(t, e, n, i, r, l, a) {
  if (t.length === 1 && Er(t[0]))
    return [
      {
        type: de.literal,
        value: t[0].value
      }
    ];
  for (var o = [], s = 0, u = t; s < u.length; s++) {
    var c = u[s];
    if (Er(c)) {
      o.push({
        type: de.literal,
        value: c.value
      });
      continue;
    }
    if (cs(c)) {
      typeof l == "number" && o.push({
        type: de.literal,
        value: n.getNumberFormat(e).format(l)
      });
      continue;
    }
    var _ = c.value;
    if (!(r && _ in r))
      throw new Vs(_, a);
    var h = r[_];
    if (us(c)) {
      (!h || typeof h == "string" || typeof h == "number") && (h = typeof h == "string" || typeof h == "number" ? String(h) : ""), o.push({
        type: typeof h == "string" ? de.literal : de.object,
        value: h
      });
      continue;
    }
    if (bl(c)) {
      var d = typeof c.style == "string" ? i.date[c.style] : xi(c.style) ? c.style.parsedOptions : void 0;
      o.push({
        type: de.literal,
        value: n.getDateTimeFormat(e, d).format(h)
      });
      continue;
    }
    if (vl(c)) {
      var d = typeof c.style == "string" ? i.time[c.style] : xi(c.style) ? c.style.parsedOptions : i.time.medium;
      o.push({
        type: de.literal,
        value: n.getDateTimeFormat(e, d).format(h)
      });
      continue;
    }
    if (gl(c)) {
      var d = typeof c.style == "string" ? i.number[c.style] : El(c.style) ? c.style.parsedOptions : void 0;
      d && d.scale && (h = h * (d.scale || 1)), o.push({
        type: de.literal,
        value: n.getNumberFormat(e, d).format(h)
      });
      continue;
    }
    if (Dl(c)) {
      var D = c.children, E = c.value, F = r[E];
      if (!Zs(F))
        throw new js(E, "function", a);
      var C = An(D, e, n, i, r, l), g = F(C.map(function(v) {
        return v.value;
      }));
      Array.isArray(g) || (g = [g]), o.push.apply(o, g.map(function(v) {
        return {
          type: typeof v == "string" ? de.literal : de.object,
          value: v
        };
      }));
    }
    if (yl(c)) {
      var f = c.options[h] || c.options.other;
      if (!f)
        throw new Br(c.value, h, Object.keys(c.options), a);
      o.push.apply(o, An(f.value, e, n, i, r));
      continue;
    }
    if (wl(c)) {
      var f = c.options["=".concat(h)];
      if (!f) {
        if (!Intl.PluralRules)
          throw new Xn(`Intl.PluralRules is not available in this environment.
Try polyfilling it using "@formatjs/intl-pluralrules"
`, Tt.MISSING_INTL_API, a);
        var m = n.getPluralRules(e, { type: c.pluralType }).select(h - (c.offset || 0));
        f = c.options[m] || c.options.other;
      }
      if (!f)
        throw new Br(c.value, h, Object.keys(c.options), a);
      o.push.apply(o, An(f.value, e, n, i, r, h - (c.offset || 0)));
      continue;
    }
  }
  return Xs(o);
}
function Ws(t, e) {
  return e ? z(z(z({}, t || {}), e || {}), Object.keys(t).reduce(function(n, i) {
    return n[i] = z(z({}, t[i]), e[i] || {}), n;
  }, {})) : t;
}
function Qs(t, e) {
  return e ? Object.keys(t).reduce(function(n, i) {
    return n[i] = Ws(t[i], e[i]), n;
  }, z({}, t)) : t;
}
function oi(t) {
  return {
    create: function() {
      return {
        get: function(e) {
          return t[e];
        },
        set: function(e, n) {
          t[e] = n;
        }
      };
    }
  };
}
function Ys(t) {
  return t === void 0 && (t = {
    number: {},
    dateTime: {},
    pluralRules: {}
  }), {
    getNumberFormat: ai(function() {
      for (var e, n = [], i = 0; i < arguments.length; i++)
        n[i] = arguments[i];
      return new ((e = Intl.NumberFormat).bind.apply(e, ii([void 0], n, !1)))();
    }, {
      cache: oi(t.number),
      strategy: li.variadic
    }),
    getDateTimeFormat: ai(function() {
      for (var e, n = [], i = 0; i < arguments.length; i++)
        n[i] = arguments[i];
      return new ((e = Intl.DateTimeFormat).bind.apply(e, ii([void 0], n, !1)))();
    }, {
      cache: oi(t.dateTime),
      strategy: li.variadic
    }),
    getPluralRules: ai(function() {
      for (var e, n = [], i = 0; i < arguments.length; i++)
        n[i] = arguments[i];
      return new ((e = Intl.PluralRules).bind.apply(e, ii([void 0], n, !1)))();
    }, {
      cache: oi(t.pluralRules),
      strategy: li.variadic
    })
  };
}
var Js = (
  /** @class */
  function() {
    function t(e, n, i, r) {
      var l = this;
      if (n === void 0 && (n = t.defaultLocale), this.formatterCache = {
        number: {},
        dateTime: {},
        pluralRules: {}
      }, this.format = function(a) {
        var o = l.formatToParts(a);
        if (o.length === 1)
          return o[0].value;
        var s = o.reduce(function(u, c) {
          return !u.length || c.type !== de.literal || typeof u[u.length - 1] != "string" ? u.push(c.value) : u[u.length - 1] += c.value, u;
        }, []);
        return s.length <= 1 ? s[0] || "" : s;
      }, this.formatToParts = function(a) {
        return An(l.ast, l.locales, l.formatters, l.formats, a, void 0, l.message);
      }, this.resolvedOptions = function() {
        return {
          locale: l.resolvedLocale.toString()
        };
      }, this.getAst = function() {
        return l.ast;
      }, this.locales = n, this.resolvedLocale = t.resolveLocale(n), typeof e == "string") {
        if (this.message = e, !t.__parse)
          throw new TypeError("IntlMessageFormat.__parse must be set to process `message` of type `string`");
        this.ast = t.__parse(e, {
          ignoreTag: r == null ? void 0 : r.ignoreTag,
          locale: this.resolvedLocale
        });
      } else
        this.ast = e;
      if (!Array.isArray(this.ast))
        throw new TypeError("A message must be provided as a String or AST.");
      this.formats = Qs(t.formats, i), this.formatters = r && r.formatters || Ys(this.formatterCache);
    }
    return Object.defineProperty(t, "defaultLocale", {
      get: function() {
        return t.memoizedDefaultLocale || (t.memoizedDefaultLocale = new Intl.NumberFormat().resolvedOptions().locale), t.memoizedDefaultLocale;
      },
      enumerable: !1,
      configurable: !0
    }), t.memoizedDefaultLocale = null, t.resolveLocale = function(e) {
      var n = Intl.NumberFormat.supportedLocalesOf(e);
      return n.length > 0 ? new Intl.Locale(n[0]) : new Intl.Locale(typeof e == "string" ? e : e[0]);
    }, t.__parse = Os, t.formats = {
      number: {
        integer: {
          maximumFractionDigits: 0
        },
        currency: {
          style: "currency"
        },
        percent: {
          style: "percent"
        }
      },
      date: {
        short: {
          month: "numeric",
          day: "numeric",
          year: "2-digit"
        },
        medium: {
          month: "short",
          day: "numeric",
          year: "numeric"
        },
        long: {
          month: "long",
          day: "numeric",
          year: "numeric"
        },
        full: {
          weekday: "long",
          month: "long",
          day: "numeric",
          year: "numeric"
        }
      },
      time: {
        short: {
          hour: "numeric",
          minute: "numeric"
        },
        medium: {
          hour: "numeric",
          minute: "numeric",
          second: "numeric"
        },
        long: {
          hour: "numeric",
          minute: "numeric",
          second: "numeric",
          timeZoneName: "short"
        },
        full: {
          hour: "numeric",
          minute: "numeric",
          second: "numeric",
          timeZoneName: "short"
        }
      }
    }, t;
  }()
);
function Ks(t, e) {
  if (e == null)
    return;
  if (e in t)
    return t[e];
  const n = e.split(".");
  let i = t;
  for (let r = 0; r < n.length; r++)
    if (typeof i == "object") {
      if (r > 0) {
        const l = n.slice(r, n.length).join(".");
        if (l in i) {
          i = i[l];
          break;
        }
      }
      i = i[n[r]];
    } else
      i = void 0;
  return i;
}
const it = {}, eu = (t, e, n) => n && (e in it || (it[e] = {}), t in it[e] || (it[e][t] = n), n), Il = (t, e) => {
  if (e == null)
    return;
  if (e in it && t in it[e])
    return it[e][t];
  const n = Zn(e);
  for (let i = 0; i < n.length; i++) {
    const r = n[i], l = nu(r, t);
    if (l)
      return eu(t, e, l);
  }
};
let tr;
const nn = tn({});
function tu(t) {
  return tr[t] || null;
}
function Ll(t) {
  return t in tr;
}
function nu(t, e) {
  if (!Ll(t))
    return null;
  const n = tu(t);
  return Ks(n, e);
}
function iu(t) {
  if (t == null)
    return;
  const e = Zn(t);
  for (let n = 0; n < e.length; n++) {
    const i = e[n];
    if (Ll(i))
      return i;
  }
}
function ru(t, ...e) {
  delete it[t], nn.update((n) => (n[t] = Bt.all([n[t] || {}, ...e]), n));
}
Lt(
  [nn],
  ([t]) => Object.keys(t)
);
nn.subscribe((t) => tr = t);
const Cn = {};
function au(t, e) {
  Cn[t].delete(e), Cn[t].size === 0 && delete Cn[t];
}
function Hl(t) {
  return Cn[t];
}
function lu(t) {
  return Zn(t).map((e) => {
    const n = Hl(e);
    return [e, n ? [...n] : []];
  }).filter(([, e]) => e.length > 0);
}
function Hi(t) {
  return t == null ? !1 : Zn(t).some(
    (e) => {
      var n;
      return (n = Hl(e)) == null ? void 0 : n.size;
    }
  );
}
function ou(t, e) {
  return Promise.all(
    e.map((i) => (au(t, i), i().then((r) => r.default || r)))
  ).then((i) => ru(t, ...i));
}
const Nt = {};
function Pl(t) {
  if (!Hi(t))
    return t in Nt ? Nt[t] : Promise.resolve();
  const e = lu(t);
  return Nt[t] = Promise.all(
    e.map(
      ([n, i]) => ou(n, i)
    )
  ).then(() => {
    if (Hi(t))
      return Pl(t);
    delete Nt[t];
  }), Nt[t];
}
const su = {
  number: {
    scientific: { notation: "scientific" },
    engineering: { notation: "engineering" },
    compactLong: { notation: "compact", compactDisplay: "long" },
    compactShort: { notation: "compact", compactDisplay: "short" }
  },
  date: {
    short: { month: "numeric", day: "numeric", year: "2-digit" },
    medium: { month: "short", day: "numeric", year: "numeric" },
    long: { month: "long", day: "numeric", year: "numeric" },
    full: { weekday: "long", month: "long", day: "numeric", year: "numeric" }
  },
  time: {
    short: { hour: "numeric", minute: "numeric" },
    medium: { hour: "numeric", minute: "numeric", second: "numeric" },
    long: {
      hour: "numeric",
      minute: "numeric",
      second: "numeric",
      timeZoneName: "short"
    },
    full: {
      hour: "numeric",
      minute: "numeric",
      second: "numeric",
      timeZoneName: "short"
    }
  }
}, uu = {
  fallbackLocale: null,
  loadingDelay: 200,
  formats: su,
  warnOnMissingMessages: !0,
  handleMissingMessage: void 0,
  ignoreTag: !0
}, cu = uu;
function It() {
  return cu;
}
const si = tn(!1);
var hu = Object.defineProperty, fu = Object.defineProperties, _u = Object.getOwnPropertyDescriptors, $r = Object.getOwnPropertySymbols, du = Object.prototype.hasOwnProperty, mu = Object.prototype.propertyIsEnumerable, Tr = (t, e, n) => e in t ? hu(t, e, { enumerable: !0, configurable: !0, writable: !0, value: n }) : t[e] = n, pu = (t, e) => {
  for (var n in e || (e = {}))
    du.call(e, n) && Tr(t, n, e[n]);
  if ($r)
    for (var n of $r(e))
      mu.call(e, n) && Tr(t, n, e[n]);
  return t;
}, gu = (t, e) => fu(t, _u(e));
let Pi;
const Tn = tn(null);
function Ir(t) {
  return t.split("-").map((e, n, i) => i.slice(0, n + 1).join("-")).reverse();
}
function Zn(t, e = It().fallbackLocale) {
  const n = Ir(t);
  return e ? [.../* @__PURE__ */ new Set([...n, ...Ir(e)])] : n;
}
function dt() {
  return Pi ?? void 0;
}
Tn.subscribe((t) => {
  Pi = t ?? void 0, typeof window < "u" && t != null && document.documentElement.setAttribute("lang", t);
});
const bu = (t) => {
  if (t && iu(t) && Hi(t)) {
    const { loadingDelay: e } = It();
    let n;
    return typeof window < "u" && dt() != null && e ? n = window.setTimeout(
      () => si.set(!0),
      e
    ) : si.set(!0), Pl(t).then(() => {
      Tn.set(t);
    }).finally(() => {
      clearTimeout(n), si.set(!1);
    });
  }
  return Tn.set(t);
}, rn = gu(pu({}, Tn), {
  set: bu
}), Wn = (t) => {
  const e = /* @__PURE__ */ Object.create(null);
  return (i) => {
    const r = JSON.stringify(i);
    return r in e ? e[r] : e[r] = t(i);
  };
};
var vu = Object.defineProperty, In = Object.getOwnPropertySymbols, Nl = Object.prototype.hasOwnProperty, Ol = Object.prototype.propertyIsEnumerable, Lr = (t, e, n) => e in t ? vu(t, e, { enumerable: !0, configurable: !0, writable: !0, value: n }) : t[e] = n, nr = (t, e) => {
  for (var n in e || (e = {}))
    Nl.call(e, n) && Lr(t, n, e[n]);
  if (In)
    for (var n of In(e))
      Ol.call(e, n) && Lr(t, n, e[n]);
  return t;
}, Ht = (t, e) => {
  var n = {};
  for (var i in t)
    Nl.call(t, i) && e.indexOf(i) < 0 && (n[i] = t[i]);
  if (t != null && In)
    for (var i of In(t))
      e.indexOf(i) < 0 && Ol.call(t, i) && (n[i] = t[i]);
  return n;
};
const Wt = (t, e) => {
  const { formats: n } = It();
  if (t in n && e in n[t])
    return n[t][e];
  throw new Error(`[svelte-i18n] Unknown "${e}" ${t} format.`);
}, yu = Wn(
  (t) => {
    var e = t, { locale: n, format: i } = e, r = Ht(e, ["locale", "format"]);
    if (n == null)
      throw new Error('[svelte-i18n] A "locale" must be set to format numbers');
    return i && (r = Wt("number", i)), new Intl.NumberFormat(n, r);
  }
), wu = Wn(
  (t) => {
    var e = t, { locale: n, format: i } = e, r = Ht(e, ["locale", "format"]);
    if (n == null)
      throw new Error('[svelte-i18n] A "locale" must be set to format dates');
    return i ? r = Wt("date", i) : Object.keys(r).length === 0 && (r = Wt("date", "short")), new Intl.DateTimeFormat(n, r);
  }
), Du = Wn(
  (t) => {
    var e = t, { locale: n, format: i } = e, r = Ht(e, ["locale", "format"]);
    if (n == null)
      throw new Error(
        '[svelte-i18n] A "locale" must be set to format time values'
      );
    return i ? r = Wt("time", i) : Object.keys(r).length === 0 && (r = Wt("time", "short")), new Intl.DateTimeFormat(n, r);
  }
), Eu = (t = {}) => {
  var e = t, {
    locale: n = dt()
  } = e, i = Ht(e, [
    "locale"
  ]);
  return yu(nr({ locale: n }, i));
}, Fu = (t = {}) => {
  var e = t, {
    locale: n = dt()
  } = e, i = Ht(e, [
    "locale"
  ]);
  return wu(nr({ locale: n }, i));
}, ku = (t = {}) => {
  var e = t, {
    locale: n = dt()
  } = e, i = Ht(e, [
    "locale"
  ]);
  return Du(nr({ locale: n }, i));
}, Au = Wn(
  // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
  (t, e = dt()) => new Js(t, e, It().formats, {
    ignoreTag: It().ignoreTag
  })
), Cu = (t, e = {}) => {
  var n, i, r, l;
  let a = e;
  typeof t == "object" && (a = t, t = a.id);
  const {
    values: o,
    locale: s = dt(),
    default: u
  } = a;
  if (s == null)
    throw new Error(
      "[svelte-i18n] Cannot format a message without first setting the initial locale."
    );
  let c = Il(t, s);
  if (!c)
    c = (l = (r = (i = (n = It()).handleMissingMessage) == null ? void 0 : i.call(n, { locale: s, id: t, defaultValue: u })) != null ? r : u) != null ? l : t;
  else if (typeof c != "string")
    return console.warn(
      `[svelte-i18n] Message with id "${t}" must be of type "string", found: "${typeof c}". Gettin its value through the "$format" method is deprecated; use the "json" method instead.`
    ), c;
  if (!o)
    return c;
  let _ = c;
  try {
    _ = Au(c, s).format(o);
  } catch (h) {
    h instanceof Error && console.warn(
      `[svelte-i18n] Message "${t}" has syntax error:`,
      h.message
    );
  }
  return _;
}, Su = (t, e) => ku(e).format(t), xu = (t, e) => Fu(e).format(t), Bu = (t, e) => Eu(e).format(t), $u = (t, e = dt()) => Il(t, e);
Lt([rn, nn], () => Cu);
Lt([rn], () => Su);
Lt([rn], () => xu);
Lt([rn], () => Bu);
Lt([rn, nn], () => $u);
const {
  SvelteComponent: Tu,
  append_hydration: Ni,
  assign: Iu,
  attr: ue,
  binding_callbacks: Lu,
  children: Gt,
  claim_element: Rl,
  claim_space: Ml,
  claim_svg_element: ui,
  create_slot: Hu,
  detach: ze,
  element: ql,
  empty: Hr,
  get_all_dirty_from_scope: Pu,
  get_slot_changes: Nu,
  get_spread_update: Ou,
  init: Ru,
  insert_hydration: Qt,
  listen: Mu,
  noop: qu,
  safe_not_equal: Uu,
  set_dynamic_element_data: Pr,
  set_style: j,
  space: Ul,
  svg_element: ci,
  toggle_class: ae,
  transition_in: Gl,
  transition_out: zl,
  update_slot_base: Gu
} = window.__gradio__svelte__internal;
function Nr(t) {
  let e, n, i, r, l;
  return {
    c() {
      e = ci("svg"), n = ci("line"), i = ci("line"), this.h();
    },
    l(a) {
      e = ui(a, "svg", { class: !0, xmlns: !0, viewBox: !0 });
      var o = Gt(e);
      n = ui(o, "line", {
        x1: !0,
        y1: !0,
        x2: !0,
        y2: !0,
        stroke: !0,
        "stroke-width": !0
      }), Gt(n).forEach(ze), i = ui(o, "line", {
        x1: !0,
        y1: !0,
        x2: !0,
        y2: !0,
        stroke: !0,
        "stroke-width": !0
      }), Gt(i).forEach(ze), o.forEach(ze), this.h();
    },
    h() {
      ue(n, "x1", "1"), ue(n, "y1", "9"), ue(n, "x2", "9"), ue(n, "y2", "1"), ue(n, "stroke", "gray"), ue(n, "stroke-width", "0.5"), ue(i, "x1", "5"), ue(i, "y1", "9"), ue(i, "x2", "9"), ue(i, "y2", "5"), ue(i, "stroke", "gray"), ue(i, "stroke-width", "0.5"), ue(e, "class", "resize-handle svelte-239wnu"), ue(e, "xmlns", "http://www.w3.org/2000/svg"), ue(e, "viewBox", "0 0 10 10");
    },
    m(a, o) {
      Qt(a, e, o), Ni(e, n), Ni(e, i), r || (l = Mu(
        e,
        "mousedown",
        /*resize*/
        t[27]
      ), r = !0);
    },
    p: qu,
    d(a) {
      a && ze(e), r = !1, l();
    }
  };
}
function zu(t) {
  var _;
  let e, n, i, r, l;
  const a = (
    /*#slots*/
    t[31].default
  ), o = Hu(
    a,
    t,
    /*$$scope*/
    t[30],
    null
  );
  let s = (
    /*resizable*/
    t[19] && Nr(t)
  ), u = [
    { "data-testid": (
      /*test_id*/
      t[11]
    ) },
    { id: (
      /*elem_id*/
      t[6]
    ) },
    {
      class: i = "block " + /*elem_classes*/
      (((_ = t[7]) == null ? void 0 : _.join(" ")) || "") + " svelte-239wnu"
    },
    {
      dir: r = /*rtl*/
      t[20] ? "rtl" : "ltr"
    }
  ], c = {};
  for (let h = 0; h < u.length; h += 1)
    c = Iu(c, u[h]);
  return {
    c() {
      e = ql(
        /*tag*/
        t[25]
      ), o && o.c(), n = Ul(), s && s.c(), this.h();
    },
    l(h) {
      e = Rl(
        h,
        /*tag*/
        (t[25] || "null").toUpperCase(),
        {
          "data-testid": !0,
          id: !0,
          class: !0,
          dir: !0
        }
      );
      var d = Gt(e);
      o && o.l(d), n = Ml(d), s && s.l(d), d.forEach(ze), this.h();
    },
    h() {
      Pr(
        /*tag*/
        t[25]
      )(e, c), ae(
        e,
        "hidden",
        /*visible*/
        t[14] === !1
      ), ae(
        e,
        "padded",
        /*padding*/
        t[10]
      ), ae(
        e,
        "flex",
        /*flex*/
        t[1]
      ), ae(
        e,
        "border_focus",
        /*border_mode*/
        t[9] === "focus"
      ), ae(
        e,
        "border_contrast",
        /*border_mode*/
        t[9] === "contrast"
      ), ae(e, "hide-container", !/*explicit_call*/
      t[12] && !/*container*/
      t[13]), ae(
        e,
        "fullscreen",
        /*fullscreen*/
        t[0]
      ), ae(
        e,
        "animating",
        /*fullscreen*/
        t[0] && /*preexpansionBoundingRect*/
        t[24] !== null
      ), ae(
        e,
        "auto-margin",
        /*scale*/
        t[17] === null
      ), j(
        e,
        "height",
        /*fullscreen*/
        t[0] ? void 0 : (
          /*get_dimension*/
          t[26](
            /*height*/
            t[2]
          )
        )
      ), j(
        e,
        "min-height",
        /*fullscreen*/
        t[0] ? void 0 : (
          /*get_dimension*/
          t[26](
            /*min_height*/
            t[3]
          )
        )
      ), j(
        e,
        "max-height",
        /*fullscreen*/
        t[0] ? void 0 : (
          /*get_dimension*/
          t[26](
            /*max_height*/
            t[4]
          )
        )
      ), j(
        e,
        "--start-top",
        /*preexpansionBoundingRect*/
        t[24] ? `${/*preexpansionBoundingRect*/
        t[24].top}px` : "0px"
      ), j(
        e,
        "--start-left",
        /*preexpansionBoundingRect*/
        t[24] ? `${/*preexpansionBoundingRect*/
        t[24].left}px` : "0px"
      ), j(
        e,
        "--start-width",
        /*preexpansionBoundingRect*/
        t[24] ? `${/*preexpansionBoundingRect*/
        t[24].width}px` : "0px"
      ), j(
        e,
        "--start-height",
        /*preexpansionBoundingRect*/
        t[24] ? `${/*preexpansionBoundingRect*/
        t[24].height}px` : "0px"
      ), j(
        e,
        "width",
        /*fullscreen*/
        t[0] ? void 0 : typeof /*width*/
        t[5] == "number" ? `calc(min(${/*width*/
        t[5]}px, 100%))` : (
          /*get_dimension*/
          t[26](
            /*width*/
            t[5]
          )
        )
      ), j(
        e,
        "border-style",
        /*variant*/
        t[8]
      ), j(
        e,
        "overflow",
        /*allow_overflow*/
        t[15] ? (
          /*overflow_behavior*/
          t[16]
        ) : "hidden"
      ), j(
        e,
        "flex-grow",
        /*scale*/
        t[17]
      ), j(e, "min-width", `calc(min(${/*min_width*/
      t[18]}px, 100%))`), j(e, "border-width", "var(--block-border-width)");
    },
    m(h, d) {
      Qt(h, e, d), o && o.m(e, null), Ni(e, n), s && s.m(e, null), t[32](e), l = !0;
    },
    p(h, d) {
      var D;
      o && o.p && (!l || d[0] & /*$$scope*/
      1073741824) && Gu(
        o,
        a,
        h,
        /*$$scope*/
        h[30],
        l ? Nu(
          a,
          /*$$scope*/
          h[30],
          d,
          null
        ) : Pu(
          /*$$scope*/
          h[30]
        ),
        null
      ), /*resizable*/
      h[19] ? s ? s.p(h, d) : (s = Nr(h), s.c(), s.m(e, null)) : s && (s.d(1), s = null), Pr(
        /*tag*/
        h[25]
      )(e, c = Ou(u, [
        (!l || d[0] & /*test_id*/
        2048) && { "data-testid": (
          /*test_id*/
          h[11]
        ) },
        (!l || d[0] & /*elem_id*/
        64) && { id: (
          /*elem_id*/
          h[6]
        ) },
        (!l || d[0] & /*elem_classes*/
        128 && i !== (i = "block " + /*elem_classes*/
        (((D = h[7]) == null ? void 0 : D.join(" ")) || "") + " svelte-239wnu")) && { class: i },
        (!l || d[0] & /*rtl*/
        1048576 && r !== (r = /*rtl*/
        h[20] ? "rtl" : "ltr")) && { dir: r }
      ])), ae(
        e,
        "hidden",
        /*visible*/
        h[14] === !1
      ), ae(
        e,
        "padded",
        /*padding*/
        h[10]
      ), ae(
        e,
        "flex",
        /*flex*/
        h[1]
      ), ae(
        e,
        "border_focus",
        /*border_mode*/
        h[9] === "focus"
      ), ae(
        e,
        "border_contrast",
        /*border_mode*/
        h[9] === "contrast"
      ), ae(e, "hide-container", !/*explicit_call*/
      h[12] && !/*container*/
      h[13]), ae(
        e,
        "fullscreen",
        /*fullscreen*/
        h[0]
      ), ae(
        e,
        "animating",
        /*fullscreen*/
        h[0] && /*preexpansionBoundingRect*/
        h[24] !== null
      ), ae(
        e,
        "auto-margin",
        /*scale*/
        h[17] === null
      ), d[0] & /*fullscreen, height*/
      5 && j(
        e,
        "height",
        /*fullscreen*/
        h[0] ? void 0 : (
          /*get_dimension*/
          h[26](
            /*height*/
            h[2]
          )
        )
      ), d[0] & /*fullscreen, min_height*/
      9 && j(
        e,
        "min-height",
        /*fullscreen*/
        h[0] ? void 0 : (
          /*get_dimension*/
          h[26](
            /*min_height*/
            h[3]
          )
        )
      ), d[0] & /*fullscreen, max_height*/
      17 && j(
        e,
        "max-height",
        /*fullscreen*/
        h[0] ? void 0 : (
          /*get_dimension*/
          h[26](
            /*max_height*/
            h[4]
          )
        )
      ), d[0] & /*preexpansionBoundingRect*/
      16777216 && j(
        e,
        "--start-top",
        /*preexpansionBoundingRect*/
        h[24] ? `${/*preexpansionBoundingRect*/
        h[24].top}px` : "0px"
      ), d[0] & /*preexpansionBoundingRect*/
      16777216 && j(
        e,
        "--start-left",
        /*preexpansionBoundingRect*/
        h[24] ? `${/*preexpansionBoundingRect*/
        h[24].left}px` : "0px"
      ), d[0] & /*preexpansionBoundingRect*/
      16777216 && j(
        e,
        "--start-width",
        /*preexpansionBoundingRect*/
        h[24] ? `${/*preexpansionBoundingRect*/
        h[24].width}px` : "0px"
      ), d[0] & /*preexpansionBoundingRect*/
      16777216 && j(
        e,
        "--start-height",
        /*preexpansionBoundingRect*/
        h[24] ? `${/*preexpansionBoundingRect*/
        h[24].height}px` : "0px"
      ), d[0] & /*fullscreen, width*/
      33 && j(
        e,
        "width",
        /*fullscreen*/
        h[0] ? void 0 : typeof /*width*/
        h[5] == "number" ? `calc(min(${/*width*/
        h[5]}px, 100%))` : (
          /*get_dimension*/
          h[26](
            /*width*/
            h[5]
          )
        )
      ), d[0] & /*variant*/
      256 && j(
        e,
        "border-style",
        /*variant*/
        h[8]
      ), d[0] & /*allow_overflow, overflow_behavior*/
      98304 && j(
        e,
        "overflow",
        /*allow_overflow*/
        h[15] ? (
          /*overflow_behavior*/
          h[16]
        ) : "hidden"
      ), d[0] & /*scale*/
      131072 && j(
        e,
        "flex-grow",
        /*scale*/
        h[17]
      ), d[0] & /*min_width*/
      262144 && j(e, "min-width", `calc(min(${/*min_width*/
      h[18]}px, 100%))`);
    },
    i(h) {
      l || (Gl(o, h), l = !0);
    },
    o(h) {
      zl(o, h), l = !1;
    },
    d(h) {
      h && ze(e), o && o.d(h), s && s.d(), t[32](null);
    }
  };
}
function Or(t) {
  let e;
  return {
    c() {
      e = ql("div"), this.h();
    },
    l(n) {
      e = Rl(n, "DIV", { class: !0 }), Gt(e).forEach(ze), this.h();
    },
    h() {
      ue(e, "class", "placeholder svelte-239wnu"), j(
        e,
        "height",
        /*placeholder_height*/
        t[22] + "px"
      ), j(
        e,
        "width",
        /*placeholder_width*/
        t[23] + "px"
      );
    },
    m(n, i) {
      Qt(n, e, i);
    },
    p(n, i) {
      i[0] & /*placeholder_height*/
      4194304 && j(
        e,
        "height",
        /*placeholder_height*/
        n[22] + "px"
      ), i[0] & /*placeholder_width*/
      8388608 && j(
        e,
        "width",
        /*placeholder_width*/
        n[23] + "px"
      );
    },
    d(n) {
      n && ze(e);
    }
  };
}
function ju(t) {
  let e, n, i, r = (
    /*tag*/
    t[25] && zu(t)
  ), l = (
    /*fullscreen*/
    t[0] && Or(t)
  );
  return {
    c() {
      r && r.c(), e = Ul(), l && l.c(), n = Hr();
    },
    l(a) {
      r && r.l(a), e = Ml(a), l && l.l(a), n = Hr();
    },
    m(a, o) {
      r && r.m(a, o), Qt(a, e, o), l && l.m(a, o), Qt(a, n, o), i = !0;
    },
    p(a, o) {
      /*tag*/
      a[25] && r.p(a, o), /*fullscreen*/
      a[0] ? l ? l.p(a, o) : (l = Or(a), l.c(), l.m(n.parentNode, n)) : l && (l.d(1), l = null);
    },
    i(a) {
      i || (Gl(r, a), i = !0);
    },
    o(a) {
      zl(r, a), i = !1;
    },
    d(a) {
      a && (ze(e), ze(n)), r && r.d(a), l && l.d(a);
    }
  };
}
function Vu(t, e, n) {
  let { $$slots: i = {}, $$scope: r } = e, { height: l = void 0 } = e, { min_height: a = void 0 } = e, { max_height: o = void 0 } = e, { width: s = void 0 } = e, { elem_id: u = "" } = e, { elem_classes: c = [] } = e, { variant: _ = "solid" } = e, { border_mode: h = "base" } = e, { padding: d = !0 } = e, { type: D = "normal" } = e, { test_id: E = void 0 } = e, { explicit_call: F = !1 } = e, { container: C = !0 } = e, { visible: g = !0 } = e, { allow_overflow: f = !0 } = e, { overflow_behavior: m = "auto" } = e, { scale: v = null } = e, { min_width: p = 0 } = e, { flex: b = !1 } = e, { resizable: k = !1 } = e, { rtl: y = !1 } = e, { fullscreen: w = !1 } = e, A = w, B, N = D === "fieldset" ? "fieldset" : "div", L = 0, R = 0, M = null;
  function J(x) {
    w && x.key === "Escape" && n(0, w = !1);
  }
  const V = (x) => {
    if (x !== void 0) {
      if (typeof x == "number")
        return x + "px";
      if (typeof x == "string")
        return x;
    }
  }, T = (x) => {
    let te = x.clientY;
    const pe = (I) => {
      const Re = I.clientY - te;
      te = I.clientY, n(21, B.style.height = `${B.offsetHeight + Re}px`, B);
    }, $ = () => {
      window.removeEventListener("mousemove", pe), window.removeEventListener("mouseup", $);
    };
    window.addEventListener("mousemove", pe), window.addEventListener("mouseup", $);
  };
  function ee(x) {
    Lu[x ? "unshift" : "push"](() => {
      B = x, n(21, B);
    });
  }
  return t.$$set = (x) => {
    "height" in x && n(2, l = x.height), "min_height" in x && n(3, a = x.min_height), "max_height" in x && n(4, o = x.max_height), "width" in x && n(5, s = x.width), "elem_id" in x && n(6, u = x.elem_id), "elem_classes" in x && n(7, c = x.elem_classes), "variant" in x && n(8, _ = x.variant), "border_mode" in x && n(9, h = x.border_mode), "padding" in x && n(10, d = x.padding), "type" in x && n(28, D = x.type), "test_id" in x && n(11, E = x.test_id), "explicit_call" in x && n(12, F = x.explicit_call), "container" in x && n(13, C = x.container), "visible" in x && n(14, g = x.visible), "allow_overflow" in x && n(15, f = x.allow_overflow), "overflow_behavior" in x && n(16, m = x.overflow_behavior), "scale" in x && n(17, v = x.scale), "min_width" in x && n(18, p = x.min_width), "flex" in x && n(1, b = x.flex), "resizable" in x && n(19, k = x.resizable), "rtl" in x && n(20, y = x.rtl), "fullscreen" in x && n(0, w = x.fullscreen), "$$scope" in x && n(30, r = x.$$scope);
  }, t.$$.update = () => {
    t.$$.dirty[0] & /*fullscreen, old_fullscreen, element*/
    538968065 && w !== A && (n(29, A = w), w ? (n(24, M = B.getBoundingClientRect()), n(22, L = B.offsetHeight), n(23, R = B.offsetWidth), window.addEventListener("keydown", J)) : (n(24, M = null), window.removeEventListener("keydown", J))), t.$$.dirty[0] & /*visible*/
    16384 && (g || n(1, b = !1));
  }, [
    w,
    b,
    l,
    a,
    o,
    s,
    u,
    c,
    _,
    h,
    d,
    E,
    F,
    C,
    g,
    f,
    m,
    v,
    p,
    k,
    y,
    B,
    L,
    R,
    M,
    N,
    V,
    T,
    D,
    A,
    r,
    i,
    ee
  ];
}
class Xu extends Tu {
  constructor(e) {
    super(), Ru(
      this,
      e,
      Vu,
      ju,
      Uu,
      {
        height: 2,
        min_height: 3,
        max_height: 4,
        width: 5,
        elem_id: 6,
        elem_classes: 7,
        variant: 8,
        border_mode: 9,
        padding: 10,
        type: 28,
        test_id: 11,
        explicit_call: 12,
        container: 13,
        visible: 14,
        allow_overflow: 15,
        overflow_behavior: 16,
        scale: 17,
        min_width: 18,
        flex: 1,
        resizable: 19,
        rtl: 20,
        fullscreen: 0
      },
      null,
      [-1, -1]
    );
  }
}
function ir() {
  return {
    async: !1,
    breaks: !1,
    extensions: null,
    gfm: !0,
    hooks: null,
    pedantic: !1,
    renderer: null,
    silent: !1,
    tokenizer: null,
    walkTokens: null
  };
}
let mt = ir();
function jl(t) {
  mt = t;
}
const Vl = /[&<>"']/, Zu = new RegExp(Vl.source, "g"), Xl = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, Wu = new RegExp(Xl.source, "g"), Qu = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, Rr = (t) => Qu[t];
function ve(t, e) {
  if (e) {
    if (Vl.test(t))
      return t.replace(Zu, Rr);
  } else if (Xl.test(t))
    return t.replace(Wu, Rr);
  return t;
}
const Yu = /&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/ig;
function Ju(t) {
  return t.replace(Yu, (e, n) => (n = n.toLowerCase(), n === "colon" ? ":" : n.charAt(0) === "#" ? n.charAt(1) === "x" ? String.fromCharCode(parseInt(n.substring(2), 16)) : String.fromCharCode(+n.substring(1)) : ""));
}
const Ku = /(^|[^\[])\^/g;
function W(t, e) {
  let n = typeof t == "string" ? t : t.source;
  e = e || "";
  const i = {
    replace: (r, l) => {
      let a = typeof l == "string" ? l : l.source;
      return a = a.replace(Ku, "$1"), n = n.replace(r, a), i;
    },
    getRegex: () => new RegExp(n, e)
  };
  return i;
}
function Mr(t) {
  try {
    t = encodeURI(t).replace(/%25/g, "%");
  } catch {
    return null;
  }
  return t;
}
const zt = { exec: () => null };
function qr(t, e) {
  const n = t.replace(/\|/g, (l, a, o) => {
    let s = !1, u = a;
    for (; --u >= 0 && o[u] === "\\"; )
      s = !s;
    return s ? "|" : " |";
  }), i = n.split(/ \|/);
  let r = 0;
  if (i[0].trim() || i.shift(), i.length > 0 && !i[i.length - 1].trim() && i.pop(), e)
    if (i.length > e)
      i.splice(e);
    else
      for (; i.length < e; )
        i.push("");
  for (; r < i.length; r++)
    i[r] = i[r].trim().replace(/\\\|/g, "|");
  return i;
}
function _n(t, e, n) {
  const i = t.length;
  if (i === 0)
    return "";
  let r = 0;
  for (; r < i && t.charAt(i - r - 1) === e; )
    r++;
  return t.slice(0, i - r);
}
function ec(t, e) {
  if (t.indexOf(e[1]) === -1)
    return -1;
  let n = 0;
  for (let i = 0; i < t.length; i++)
    if (t[i] === "\\")
      i++;
    else if (t[i] === e[0])
      n++;
    else if (t[i] === e[1] && (n--, n < 0))
      return i;
  return -1;
}
function Ur(t, e, n, i) {
  const r = e.href, l = e.title ? ve(e.title) : null, a = t[1].replace(/\\([\[\]])/g, "$1");
  if (t[0].charAt(0) !== "!") {
    i.state.inLink = !0;
    const o = {
      type: "link",
      raw: n,
      href: r,
      title: l,
      text: a,
      tokens: i.inlineTokens(a)
    };
    return i.state.inLink = !1, o;
  }
  return {
    type: "image",
    raw: n,
    href: r,
    title: l,
    text: ve(a)
  };
}
function tc(t, e) {
  const n = t.match(/^(\s+)(?:```)/);
  if (n === null)
    return e;
  const i = n[1];
  return e.split(`
`).map((r) => {
    const l = r.match(/^\s+/);
    if (l === null)
      return r;
    const [a] = l;
    return a.length >= i.length ? r.slice(i.length) : r;
  }).join(`
`);
}
class Ln {
  // set by the lexer
  constructor(e) {
    Y(this, "options");
    Y(this, "rules");
    // set by the lexer
    Y(this, "lexer");
    this.options = e || mt;
  }
  space(e) {
    const n = this.rules.block.newline.exec(e);
    if (n && n[0].length > 0)
      return {
        type: "space",
        raw: n[0]
      };
  }
  code(e) {
    const n = this.rules.block.code.exec(e);
    if (n) {
      const i = n[0].replace(/^ {1,4}/gm, "");
      return {
        type: "code",
        raw: n[0],
        codeBlockStyle: "indented",
        text: this.options.pedantic ? i : _n(i, `
`)
      };
    }
  }
  fences(e) {
    const n = this.rules.block.fences.exec(e);
    if (n) {
      const i = n[0], r = tc(i, n[3] || "");
      return {
        type: "code",
        raw: i,
        lang: n[2] ? n[2].trim().replace(this.rules.inline.anyPunctuation, "$1") : n[2],
        text: r
      };
    }
  }
  heading(e) {
    const n = this.rules.block.heading.exec(e);
    if (n) {
      let i = n[2].trim();
      if (/#$/.test(i)) {
        const r = _n(i, "#");
        (this.options.pedantic || !r || / $/.test(r)) && (i = r.trim());
      }
      return {
        type: "heading",
        raw: n[0],
        depth: n[1].length,
        text: i,
        tokens: this.lexer.inline(i)
      };
    }
  }
  hr(e) {
    const n = this.rules.block.hr.exec(e);
    if (n)
      return {
        type: "hr",
        raw: n[0]
      };
  }
  blockquote(e) {
    const n = this.rules.block.blockquote.exec(e);
    if (n) {
      let i = n[0].replace(/\n {0,3}((?:=+|-+) *)(?=\n|$)/g, `
    $1`);
      i = _n(i.replace(/^ *>[ \t]?/gm, ""), `
`);
      const r = this.lexer.state.top;
      this.lexer.state.top = !0;
      const l = this.lexer.blockTokens(i);
      return this.lexer.state.top = r, {
        type: "blockquote",
        raw: n[0],
        tokens: l,
        text: i
      };
    }
  }
  list(e) {
    let n = this.rules.block.list.exec(e);
    if (n) {
      let i = n[1].trim();
      const r = i.length > 1, l = {
        type: "list",
        raw: "",
        ordered: r,
        start: r ? +i.slice(0, -1) : "",
        loose: !1,
        items: []
      };
      i = r ? `\\d{1,9}\\${i.slice(-1)}` : `\\${i}`, this.options.pedantic && (i = r ? i : "[*+-]");
      const a = new RegExp(`^( {0,3}${i})((?:[	 ][^\\n]*)?(?:\\n|$))`);
      let o = "", s = "", u = !1;
      for (; e; ) {
        let c = !1;
        if (!(n = a.exec(e)) || this.rules.block.hr.test(e))
          break;
        o = n[0], e = e.substring(o.length);
        let _ = n[2].split(`
`, 1)[0].replace(/^\t+/, (C) => " ".repeat(3 * C.length)), h = e.split(`
`, 1)[0], d = 0;
        this.options.pedantic ? (d = 2, s = _.trimStart()) : (d = n[2].search(/[^ ]/), d = d > 4 ? 1 : d, s = _.slice(d), d += n[1].length);
        let D = !1;
        if (!_ && /^ *$/.test(h) && (o += h + `
`, e = e.substring(h.length + 1), c = !0), !c) {
          const C = new RegExp(`^ {0,${Math.min(3, d - 1)}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`), g = new RegExp(`^ {0,${Math.min(3, d - 1)}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)`), f = new RegExp(`^ {0,${Math.min(3, d - 1)}}(?:\`\`\`|~~~)`), m = new RegExp(`^ {0,${Math.min(3, d - 1)}}#`);
          for (; e; ) {
            const v = e.split(`
`, 1)[0];
            if (h = v, this.options.pedantic && (h = h.replace(/^ {1,4}(?=( {4})*[^ ])/g, "  ")), f.test(h) || m.test(h) || C.test(h) || g.test(e))
              break;
            if (h.search(/[^ ]/) >= d || !h.trim())
              s += `
` + h.slice(d);
            else {
              if (D || _.search(/[^ ]/) >= 4 || f.test(_) || m.test(_) || g.test(_))
                break;
              s += `
` + h;
            }
            !D && !h.trim() && (D = !0), o += v + `
`, e = e.substring(v.length + 1), _ = h.slice(d);
          }
        }
        l.loose || (u ? l.loose = !0 : /\n *\n *$/.test(o) && (u = !0));
        let E = null, F;
        this.options.gfm && (E = /^\[[ xX]\] /.exec(s), E && (F = E[0] !== "[ ] ", s = s.replace(/^\[[ xX]\] +/, ""))), l.items.push({
          type: "list_item",
          raw: o,
          task: !!E,
          checked: F,
          loose: !1,
          text: s,
          tokens: []
        }), l.raw += o;
      }
      l.items[l.items.length - 1].raw = o.trimEnd(), l.items[l.items.length - 1].text = s.trimEnd(), l.raw = l.raw.trimEnd();
      for (let c = 0; c < l.items.length; c++)
        if (this.lexer.state.top = !1, l.items[c].tokens = this.lexer.blockTokens(l.items[c].text, []), !l.loose) {
          const _ = l.items[c].tokens.filter((d) => d.type === "space"), h = _.length > 0 && _.some((d) => /\n.*\n/.test(d.raw));
          l.loose = h;
        }
      if (l.loose)
        for (let c = 0; c < l.items.length; c++)
          l.items[c].loose = !0;
      return l;
    }
  }
  html(e) {
    const n = this.rules.block.html.exec(e);
    if (n)
      return {
        type: "html",
        block: !0,
        raw: n[0],
        pre: n[1] === "pre" || n[1] === "script" || n[1] === "style",
        text: n[0]
      };
  }
  def(e) {
    const n = this.rules.block.def.exec(e);
    if (n) {
      const i = n[1].toLowerCase().replace(/\s+/g, " "), r = n[2] ? n[2].replace(/^<(.*)>$/, "$1").replace(this.rules.inline.anyPunctuation, "$1") : "", l = n[3] ? n[3].substring(1, n[3].length - 1).replace(this.rules.inline.anyPunctuation, "$1") : n[3];
      return {
        type: "def",
        tag: i,
        raw: n[0],
        href: r,
        title: l
      };
    }
  }
  table(e) {
    const n = this.rules.block.table.exec(e);
    if (!n || !/[:|]/.test(n[2]))
      return;
    const i = qr(n[1]), r = n[2].replace(/^\||\| *$/g, "").split("|"), l = n[3] && n[3].trim() ? n[3].replace(/\n[ \t]*$/, "").split(`
`) : [], a = {
      type: "table",
      raw: n[0],
      header: [],
      align: [],
      rows: []
    };
    if (i.length === r.length) {
      for (const o of r)
        /^ *-+: *$/.test(o) ? a.align.push("right") : /^ *:-+: *$/.test(o) ? a.align.push("center") : /^ *:-+ *$/.test(o) ? a.align.push("left") : a.align.push(null);
      for (const o of i)
        a.header.push({
          text: o,
          tokens: this.lexer.inline(o)
        });
      for (const o of l)
        a.rows.push(qr(o, a.header.length).map((s) => ({
          text: s,
          tokens: this.lexer.inline(s)
        })));
      return a;
    }
  }
  lheading(e) {
    const n = this.rules.block.lheading.exec(e);
    if (n)
      return {
        type: "heading",
        raw: n[0],
        depth: n[2].charAt(0) === "=" ? 1 : 2,
        text: n[1],
        tokens: this.lexer.inline(n[1])
      };
  }
  paragraph(e) {
    const n = this.rules.block.paragraph.exec(e);
    if (n) {
      const i = n[1].charAt(n[1].length - 1) === `
` ? n[1].slice(0, -1) : n[1];
      return {
        type: "paragraph",
        raw: n[0],
        text: i,
        tokens: this.lexer.inline(i)
      };
    }
  }
  text(e) {
    const n = this.rules.block.text.exec(e);
    if (n)
      return {
        type: "text",
        raw: n[0],
        text: n[0],
        tokens: this.lexer.inline(n[0])
      };
  }
  escape(e) {
    const n = this.rules.inline.escape.exec(e);
    if (n)
      return {
        type: "escape",
        raw: n[0],
        text: ve(n[1])
      };
  }
  tag(e) {
    const n = this.rules.inline.tag.exec(e);
    if (n)
      return !this.lexer.state.inLink && /^<a /i.test(n[0]) ? this.lexer.state.inLink = !0 : this.lexer.state.inLink && /^<\/a>/i.test(n[0]) && (this.lexer.state.inLink = !1), !this.lexer.state.inRawBlock && /^<(pre|code|kbd|script)(\s|>)/i.test(n[0]) ? this.lexer.state.inRawBlock = !0 : this.lexer.state.inRawBlock && /^<\/(pre|code|kbd|script)(\s|>)/i.test(n[0]) && (this.lexer.state.inRawBlock = !1), {
        type: "html",
        raw: n[0],
        inLink: this.lexer.state.inLink,
        inRawBlock: this.lexer.state.inRawBlock,
        block: !1,
        text: n[0]
      };
  }
  link(e) {
    const n = this.rules.inline.link.exec(e);
    if (n) {
      const i = n[2].trim();
      if (!this.options.pedantic && /^</.test(i)) {
        if (!/>$/.test(i))
          return;
        const a = _n(i.slice(0, -1), "\\");
        if ((i.length - a.length) % 2 === 0)
          return;
      } else {
        const a = ec(n[2], "()");
        if (a > -1) {
          const s = (n[0].indexOf("!") === 0 ? 5 : 4) + n[1].length + a;
          n[2] = n[2].substring(0, a), n[0] = n[0].substring(0, s).trim(), n[3] = "";
        }
      }
      let r = n[2], l = "";
      if (this.options.pedantic) {
        const a = /^([^'"]*[^\s])\s+(['"])(.*)\2/.exec(r);
        a && (r = a[1], l = a[3]);
      } else
        l = n[3] ? n[3].slice(1, -1) : "";
      return r = r.trim(), /^</.test(r) && (this.options.pedantic && !/>$/.test(i) ? r = r.slice(1) : r = r.slice(1, -1)), Ur(n, {
        href: r && r.replace(this.rules.inline.anyPunctuation, "$1"),
        title: l && l.replace(this.rules.inline.anyPunctuation, "$1")
      }, n[0], this.lexer);
    }
  }
  reflink(e, n) {
    let i;
    if ((i = this.rules.inline.reflink.exec(e)) || (i = this.rules.inline.nolink.exec(e))) {
      const r = (i[2] || i[1]).replace(/\s+/g, " "), l = n[r.toLowerCase()];
      if (!l) {
        const a = i[0].charAt(0);
        return {
          type: "text",
          raw: a,
          text: a
        };
      }
      return Ur(i, l, i[0], this.lexer);
    }
  }
  emStrong(e, n, i = "") {
    let r = this.rules.inline.emStrongLDelim.exec(e);
    if (!r || r[3] && i.match(/[\p{L}\p{N}]/u))
      return;
    if (!(r[1] || r[2] || "") || !i || this.rules.inline.punctuation.exec(i)) {
      const a = [...r[0]].length - 1;
      let o, s, u = a, c = 0;
      const _ = r[0][0] === "*" ? this.rules.inline.emStrongRDelimAst : this.rules.inline.emStrongRDelimUnd;
      for (_.lastIndex = 0, n = n.slice(-1 * e.length + a); (r = _.exec(n)) != null; ) {
        if (o = r[1] || r[2] || r[3] || r[4] || r[5] || r[6], !o)
          continue;
        if (s = [...o].length, r[3] || r[4]) {
          u += s;
          continue;
        } else if ((r[5] || r[6]) && a % 3 && !((a + s) % 3)) {
          c += s;
          continue;
        }
        if (u -= s, u > 0)
          continue;
        s = Math.min(s, s + u + c);
        const h = [...r[0]][0].length, d = e.slice(0, a + r.index + h + s);
        if (Math.min(a, s) % 2) {
          const E = d.slice(1, -1);
          return {
            type: "em",
            raw: d,
            text: E,
            tokens: this.lexer.inlineTokens(E)
          };
        }
        const D = d.slice(2, -2);
        return {
          type: "strong",
          raw: d,
          text: D,
          tokens: this.lexer.inlineTokens(D)
        };
      }
    }
  }
  codespan(e) {
    const n = this.rules.inline.code.exec(e);
    if (n) {
      let i = n[2].replace(/\n/g, " ");
      const r = /[^ ]/.test(i), l = /^ /.test(i) && / $/.test(i);
      return r && l && (i = i.substring(1, i.length - 1)), i = ve(i, !0), {
        type: "codespan",
        raw: n[0],
        text: i
      };
    }
  }
  br(e) {
    const n = this.rules.inline.br.exec(e);
    if (n)
      return {
        type: "br",
        raw: n[0]
      };
  }
  del(e) {
    const n = this.rules.inline.del.exec(e);
    if (n)
      return {
        type: "del",
        raw: n[0],
        text: n[2],
        tokens: this.lexer.inlineTokens(n[2])
      };
  }
  autolink(e) {
    const n = this.rules.inline.autolink.exec(e);
    if (n) {
      let i, r;
      return n[2] === "@" ? (i = ve(n[1]), r = "mailto:" + i) : (i = ve(n[1]), r = i), {
        type: "link",
        raw: n[0],
        text: i,
        href: r,
        tokens: [
          {
            type: "text",
            raw: i,
            text: i
          }
        ]
      };
    }
  }
  url(e) {
    var i;
    let n;
    if (n = this.rules.inline.url.exec(e)) {
      let r, l;
      if (n[2] === "@")
        r = ve(n[0]), l = "mailto:" + r;
      else {
        let a;
        do
          a = n[0], n[0] = ((i = this.rules.inline._backpedal.exec(n[0])) == null ? void 0 : i[0]) ?? "";
        while (a !== n[0]);
        r = ve(n[0]), n[1] === "www." ? l = "http://" + n[0] : l = n[0];
      }
      return {
        type: "link",
        raw: n[0],
        text: r,
        href: l,
        tokens: [
          {
            type: "text",
            raw: r,
            text: r
          }
        ]
      };
    }
  }
  inlineText(e) {
    const n = this.rules.inline.text.exec(e);
    if (n) {
      let i;
      return this.lexer.state.inRawBlock ? i = n[0] : i = ve(n[0]), {
        type: "text",
        raw: n[0],
        text: i
      };
    }
  }
}
const nc = /^(?: *(?:\n|$))+/, ic = /^( {4}[^\n]+(?:\n(?: *(?:\n|$))*)?)+/, rc = /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/, an = /^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/, ac = /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/, Zl = /(?:[*+-]|\d{1,9}[.)])/, Wl = W(/^(?!bull |blockCode|fences|blockquote|heading|html)((?:.|\n(?!\s*?\n|bull |blockCode|fences|blockquote|heading|html))+?)\n {0,3}(=+|-+) *(?:\n+|$)/).replace(/bull/g, Zl).replace(/blockCode/g, / {4}/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).getRegex(), rr = /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/, lc = /^[^\n]+/, ar = /(?!\s*\])(?:\\.|[^\[\]\\])+/, oc = W(/^ {0,3}\[(label)\]: *(?:\n *)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n *)?| *\n *)(title))? *(?:\n+|$)/).replace("label", ar).replace("title", /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/).getRegex(), sc = W(/^( {0,3}bull)([ \t][^\n]+?)?(?:\n|$)/).replace(/bull/g, Zl).getRegex(), Qn = "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul", lr = /<!--(?:-?>|[\s\S]*?(?:-->|$))/, uc = W("^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>\\n*|$)|<![A-Z][\\s\\S]*?(?:>\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n *)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$))", "i").replace("comment", lr).replace("tag", Qn).replace("attribute", / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex(), Ql = W(rr).replace("hr", an).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("|table", "").replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Qn).getRegex(), cc = W(/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/).replace("paragraph", Ql).getRegex(), or = {
  blockquote: cc,
  code: ic,
  def: oc,
  fences: rc,
  heading: ac,
  hr: an,
  html: uc,
  lheading: Wl,
  list: sc,
  newline: nc,
  paragraph: Ql,
  table: zt,
  text: lc
}, Gr = W("^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)").replace("hr", an).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("blockquote", " {0,3}>").replace("code", " {4}[^\\n]").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Qn).getRegex(), hc = {
  ...or,
  table: Gr,
  paragraph: W(rr).replace("hr", an).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("table", Gr).replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Qn).getRegex()
}, fc = {
  ...or,
  html: W(`^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`).replace("comment", lr).replace(/tag/g, "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(),
  def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/,
  heading: /^(#{1,6})(.*)(?:\n+|$)/,
  fences: zt,
  // fences not supported
  lheading: /^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/,
  paragraph: W(rr).replace("hr", an).replace("heading", ` *#{1,6} *[^
]`).replace("lheading", Wl).replace("|table", "").replace("blockquote", " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html", "").replace("|tag", "").getRegex()
}, Yl = /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/, _c = /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/, Jl = /^( {2,}|\\)\n(?!\s*$)/, dc = /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/, ln = "\\p{P}\\p{S}", mc = W(/^((?![*_])[\spunctuation])/, "u").replace(/punctuation/g, ln).getRegex(), pc = /\[[^[\]]*?\]\([^\(\)]*?\)|`[^`]*?`|<[^<>]*?>/g, gc = W(/^(?:\*+(?:((?!\*)[punct])|[^\s*]))|^_+(?:((?!_)[punct])|([^\s_]))/, "u").replace(/punct/g, ln).getRegex(), bc = W("^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)[punct](\\*+)(?=[\\s]|$)|[^punct\\s](\\*+)(?!\\*)(?=[punct\\s]|$)|(?!\\*)[punct\\s](\\*+)(?=[^punct\\s])|[\\s](\\*+)(?!\\*)(?=[punct])|(?!\\*)[punct](\\*+)(?!\\*)(?=[punct])|[^punct\\s](\\*+)(?=[^punct\\s])", "gu").replace(/punct/g, ln).getRegex(), vc = W("^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)[punct](_+)(?=[\\s]|$)|[^punct\\s](_+)(?!_)(?=[punct\\s]|$)|(?!_)[punct\\s](_+)(?=[^punct\\s])|[\\s](_+)(?!_)(?=[punct])|(?!_)[punct](_+)(?!_)(?=[punct])", "gu").replace(/punct/g, ln).getRegex(), yc = W(/\\([punct])/, "gu").replace(/punct/g, ln).getRegex(), wc = W(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/).replace("scheme", /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/).replace("email", /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/).getRegex(), Dc = W(lr).replace("(?:-->|$)", "-->").getRegex(), Ec = W("^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>").replace("comment", Dc).replace("attribute", /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/).getRegex(), Hn = /(?:\[(?:\\.|[^\[\]\\])*\]|\\.|`[^`]*`|[^\[\]\\`])*?/, Fc = W(/^!?\[(label)\]\(\s*(href)(?:\s+(title))?\s*\)/).replace("label", Hn).replace("href", /<(?:\\.|[^\n<>\\])+>|[^\s\x00-\x1f]*/).replace("title", /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/).getRegex(), Kl = W(/^!?\[(label)\]\[(ref)\]/).replace("label", Hn).replace("ref", ar).getRegex(), eo = W(/^!?\[(ref)\](?:\[\])?/).replace("ref", ar).getRegex(), kc = W("reflink|nolink(?!\\()", "g").replace("reflink", Kl).replace("nolink", eo).getRegex(), sr = {
  _backpedal: zt,
  // only used for GFM url
  anyPunctuation: yc,
  autolink: wc,
  blockSkip: pc,
  br: Jl,
  code: _c,
  del: zt,
  emStrongLDelim: gc,
  emStrongRDelimAst: bc,
  emStrongRDelimUnd: vc,
  escape: Yl,
  link: Fc,
  nolink: eo,
  punctuation: mc,
  reflink: Kl,
  reflinkSearch: kc,
  tag: Ec,
  text: dc,
  url: zt
}, Ac = {
  ...sr,
  link: W(/^!?\[(label)\]\((.*?)\)/).replace("label", Hn).getRegex(),
  reflink: W(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", Hn).getRegex()
}, Oi = {
  ...sr,
  escape: W(Yl).replace("])", "~|])").getRegex(),
  url: W(/^((?:ftp|https?):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/, "i").replace("email", /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/).getRegex(),
  _backpedal: /(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/,
  del: /^(~~?)(?=[^\s~])([\s\S]*?[^\s~])\1(?=[^~]|$)/,
  text: /^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|https?:\/\/|ftp:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/
}, Cc = {
  ...Oi,
  br: W(Jl).replace("{2,}", "*").getRegex(),
  text: W(Oi.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex()
}, dn = {
  normal: or,
  gfm: hc,
  pedantic: fc
}, Ot = {
  normal: sr,
  gfm: Oi,
  breaks: Cc,
  pedantic: Ac
};
class je {
  constructor(e) {
    Y(this, "tokens");
    Y(this, "options");
    Y(this, "state");
    Y(this, "tokenizer");
    Y(this, "inlineQueue");
    this.tokens = [], this.tokens.links = /* @__PURE__ */ Object.create(null), this.options = e || mt, this.options.tokenizer = this.options.tokenizer || new Ln(), this.tokenizer = this.options.tokenizer, this.tokenizer.options = this.options, this.tokenizer.lexer = this, this.inlineQueue = [], this.state = {
      inLink: !1,
      inRawBlock: !1,
      top: !0
    };
    const n = {
      block: dn.normal,
      inline: Ot.normal
    };
    this.options.pedantic ? (n.block = dn.pedantic, n.inline = Ot.pedantic) : this.options.gfm && (n.block = dn.gfm, this.options.breaks ? n.inline = Ot.breaks : n.inline = Ot.gfm), this.tokenizer.rules = n;
  }
  /**
   * Expose Rules
   */
  static get rules() {
    return {
      block: dn,
      inline: Ot
    };
  }
  /**
   * Static Lex Method
   */
  static lex(e, n) {
    return new je(n).lex(e);
  }
  /**
   * Static Lex Inline Method
   */
  static lexInline(e, n) {
    return new je(n).inlineTokens(e);
  }
  /**
   * Preprocessing
   */
  lex(e) {
    e = e.replace(/\r\n|\r/g, `
`), this.blockTokens(e, this.tokens);
    for (let n = 0; n < this.inlineQueue.length; n++) {
      const i = this.inlineQueue[n];
      this.inlineTokens(i.src, i.tokens);
    }
    return this.inlineQueue = [], this.tokens;
  }
  blockTokens(e, n = []) {
    this.options.pedantic ? e = e.replace(/\t/g, "    ").replace(/^ +$/gm, "") : e = e.replace(/^( *)(\t+)/gm, (o, s, u) => s + "    ".repeat(u.length));
    let i, r, l, a;
    for (; e; )
      if (!(this.options.extensions && this.options.extensions.block && this.options.extensions.block.some((o) => (i = o.call({ lexer: this }, e, n)) ? (e = e.substring(i.raw.length), n.push(i), !0) : !1))) {
        if (i = this.tokenizer.space(e)) {
          e = e.substring(i.raw.length), i.raw.length === 1 && n.length > 0 ? n[n.length - 1].raw += `
` : n.push(i);
          continue;
        }
        if (i = this.tokenizer.code(e)) {
          e = e.substring(i.raw.length), r = n[n.length - 1], r && (r.type === "paragraph" || r.type === "text") ? (r.raw += `
` + i.raw, r.text += `
` + i.text, this.inlineQueue[this.inlineQueue.length - 1].src = r.text) : n.push(i);
          continue;
        }
        if (i = this.tokenizer.fences(e)) {
          e = e.substring(i.raw.length), n.push(i);
          continue;
        }
        if (i = this.tokenizer.heading(e)) {
          e = e.substring(i.raw.length), n.push(i);
          continue;
        }
        if (i = this.tokenizer.hr(e)) {
          e = e.substring(i.raw.length), n.push(i);
          continue;
        }
        if (i = this.tokenizer.blockquote(e)) {
          e = e.substring(i.raw.length), n.push(i);
          continue;
        }
        if (i = this.tokenizer.list(e)) {
          e = e.substring(i.raw.length), n.push(i);
          continue;
        }
        if (i = this.tokenizer.html(e)) {
          e = e.substring(i.raw.length), n.push(i);
          continue;
        }
        if (i = this.tokenizer.def(e)) {
          e = e.substring(i.raw.length), r = n[n.length - 1], r && (r.type === "paragraph" || r.type === "text") ? (r.raw += `
` + i.raw, r.text += `
` + i.raw, this.inlineQueue[this.inlineQueue.length - 1].src = r.text) : this.tokens.links[i.tag] || (this.tokens.links[i.tag] = {
            href: i.href,
            title: i.title
          });
          continue;
        }
        if (i = this.tokenizer.table(e)) {
          e = e.substring(i.raw.length), n.push(i);
          continue;
        }
        if (i = this.tokenizer.lheading(e)) {
          e = e.substring(i.raw.length), n.push(i);
          continue;
        }
        if (l = e, this.options.extensions && this.options.extensions.startBlock) {
          let o = 1 / 0;
          const s = e.slice(1);
          let u;
          this.options.extensions.startBlock.forEach((c) => {
            u = c.call({ lexer: this }, s), typeof u == "number" && u >= 0 && (o = Math.min(o, u));
          }), o < 1 / 0 && o >= 0 && (l = e.substring(0, o + 1));
        }
        if (this.state.top && (i = this.tokenizer.paragraph(l))) {
          r = n[n.length - 1], a && r.type === "paragraph" ? (r.raw += `
` + i.raw, r.text += `
` + i.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = r.text) : n.push(i), a = l.length !== e.length, e = e.substring(i.raw.length);
          continue;
        }
        if (i = this.tokenizer.text(e)) {
          e = e.substring(i.raw.length), r = n[n.length - 1], r && r.type === "text" ? (r.raw += `
` + i.raw, r.text += `
` + i.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = r.text) : n.push(i);
          continue;
        }
        if (e) {
          const o = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(o);
            break;
          } else
            throw new Error(o);
        }
      }
    return this.state.top = !0, n;
  }
  inline(e, n = []) {
    return this.inlineQueue.push({ src: e, tokens: n }), n;
  }
  /**
   * Lexing/Compiling
   */
  inlineTokens(e, n = []) {
    let i, r, l, a = e, o, s, u;
    if (this.tokens.links) {
      const c = Object.keys(this.tokens.links);
      if (c.length > 0)
        for (; (o = this.tokenizer.rules.inline.reflinkSearch.exec(a)) != null; )
          c.includes(o[0].slice(o[0].lastIndexOf("[") + 1, -1)) && (a = a.slice(0, o.index) + "[" + "a".repeat(o[0].length - 2) + "]" + a.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex));
    }
    for (; (o = this.tokenizer.rules.inline.blockSkip.exec(a)) != null; )
      a = a.slice(0, o.index) + "[" + "a".repeat(o[0].length - 2) + "]" + a.slice(this.tokenizer.rules.inline.blockSkip.lastIndex);
    for (; (o = this.tokenizer.rules.inline.anyPunctuation.exec(a)) != null; )
      a = a.slice(0, o.index) + "++" + a.slice(this.tokenizer.rules.inline.anyPunctuation.lastIndex);
    for (; e; )
      if (s || (u = ""), s = !1, !(this.options.extensions && this.options.extensions.inline && this.options.extensions.inline.some((c) => (i = c.call({ lexer: this }, e, n)) ? (e = e.substring(i.raw.length), n.push(i), !0) : !1))) {
        if (i = this.tokenizer.escape(e)) {
          e = e.substring(i.raw.length), n.push(i);
          continue;
        }
        if (i = this.tokenizer.tag(e)) {
          e = e.substring(i.raw.length), r = n[n.length - 1], r && i.type === "text" && r.type === "text" ? (r.raw += i.raw, r.text += i.text) : n.push(i);
          continue;
        }
        if (i = this.tokenizer.link(e)) {
          e = e.substring(i.raw.length), n.push(i);
          continue;
        }
        if (i = this.tokenizer.reflink(e, this.tokens.links)) {
          e = e.substring(i.raw.length), r = n[n.length - 1], r && i.type === "text" && r.type === "text" ? (r.raw += i.raw, r.text += i.text) : n.push(i);
          continue;
        }
        if (i = this.tokenizer.emStrong(e, a, u)) {
          e = e.substring(i.raw.length), n.push(i);
          continue;
        }
        if (i = this.tokenizer.codespan(e)) {
          e = e.substring(i.raw.length), n.push(i);
          continue;
        }
        if (i = this.tokenizer.br(e)) {
          e = e.substring(i.raw.length), n.push(i);
          continue;
        }
        if (i = this.tokenizer.del(e)) {
          e = e.substring(i.raw.length), n.push(i);
          continue;
        }
        if (i = this.tokenizer.autolink(e)) {
          e = e.substring(i.raw.length), n.push(i);
          continue;
        }
        if (!this.state.inLink && (i = this.tokenizer.url(e))) {
          e = e.substring(i.raw.length), n.push(i);
          continue;
        }
        if (l = e, this.options.extensions && this.options.extensions.startInline) {
          let c = 1 / 0;
          const _ = e.slice(1);
          let h;
          this.options.extensions.startInline.forEach((d) => {
            h = d.call({ lexer: this }, _), typeof h == "number" && h >= 0 && (c = Math.min(c, h));
          }), c < 1 / 0 && c >= 0 && (l = e.substring(0, c + 1));
        }
        if (i = this.tokenizer.inlineText(l)) {
          e = e.substring(i.raw.length), i.raw.slice(-1) !== "_" && (u = i.raw.slice(-1)), s = !0, r = n[n.length - 1], r && r.type === "text" ? (r.raw += i.raw, r.text += i.text) : n.push(i);
          continue;
        }
        if (e) {
          const c = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(c);
            break;
          } else
            throw new Error(c);
        }
      }
    return n;
  }
}
class Pn {
  constructor(e) {
    Y(this, "options");
    this.options = e || mt;
  }
  code(e, n, i) {
    var l;
    const r = (l = (n || "").match(/^\S*/)) == null ? void 0 : l[0];
    return e = e.replace(/\n$/, "") + `
`, r ? '<pre><code class="language-' + ve(r) + '">' + (i ? e : ve(e, !0)) + `</code></pre>
` : "<pre><code>" + (i ? e : ve(e, !0)) + `</code></pre>
`;
  }
  blockquote(e) {
    return `<blockquote>
${e}</blockquote>
`;
  }
  html(e, n) {
    return e;
  }
  heading(e, n, i) {
    return `<h${n}>${e}</h${n}>
`;
  }
  hr() {
    return `<hr>
`;
  }
  list(e, n, i) {
    const r = n ? "ol" : "ul", l = n && i !== 1 ? ' start="' + i + '"' : "";
    return "<" + r + l + `>
` + e + "</" + r + `>
`;
  }
  listitem(e, n, i) {
    return `<li>${e}</li>
`;
  }
  checkbox(e) {
    return "<input " + (e ? 'checked="" ' : "") + 'disabled="" type="checkbox">';
  }
  paragraph(e) {
    return `<p>${e}</p>
`;
  }
  table(e, n) {
    return n && (n = `<tbody>${n}</tbody>`), `<table>
<thead>
` + e + `</thead>
` + n + `</table>
`;
  }
  tablerow(e) {
    return `<tr>
${e}</tr>
`;
  }
  tablecell(e, n) {
    const i = n.header ? "th" : "td";
    return (n.align ? `<${i} align="${n.align}">` : `<${i}>`) + e + `</${i}>
`;
  }
  /**
   * span level renderer
   */
  strong(e) {
    return `<strong>${e}</strong>`;
  }
  em(e) {
    return `<em>${e}</em>`;
  }
  codespan(e) {
    return `<code>${e}</code>`;
  }
  br() {
    return "<br>";
  }
  del(e) {
    return `<del>${e}</del>`;
  }
  link(e, n, i) {
    const r = Mr(e);
    if (r === null)
      return i;
    e = r;
    let l = '<a href="' + e + '"';
    return n && (l += ' title="' + n + '"'), l += ">" + i + "</a>", l;
  }
  image(e, n, i) {
    const r = Mr(e);
    if (r === null)
      return i;
    e = r;
    let l = `<img src="${e}" alt="${i}"`;
    return n && (l += ` title="${n}"`), l += ">", l;
  }
  text(e) {
    return e;
  }
}
class ur {
  // no need for block level renderers
  strong(e) {
    return e;
  }
  em(e) {
    return e;
  }
  codespan(e) {
    return e;
  }
  del(e) {
    return e;
  }
  html(e) {
    return e;
  }
  text(e) {
    return e;
  }
  link(e, n, i) {
    return "" + i;
  }
  image(e, n, i) {
    return "" + i;
  }
  br() {
    return "";
  }
}
class Ve {
  constructor(e) {
    Y(this, "options");
    Y(this, "renderer");
    Y(this, "textRenderer");
    this.options = e || mt, this.options.renderer = this.options.renderer || new Pn(), this.renderer = this.options.renderer, this.renderer.options = this.options, this.textRenderer = new ur();
  }
  /**
   * Static Parse Method
   */
  static parse(e, n) {
    return new Ve(n).parse(e);
  }
  /**
   * Static Parse Inline Method
   */
  static parseInline(e, n) {
    return new Ve(n).parseInline(e);
  }
  /**
   * Parse Loop
   */
  parse(e, n = !0) {
    let i = "";
    for (let r = 0; r < e.length; r++) {
      const l = e[r];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[l.type]) {
        const a = l, o = this.options.extensions.renderers[a.type].call({ parser: this }, a);
        if (o !== !1 || !["space", "hr", "heading", "code", "table", "blockquote", "list", "html", "paragraph", "text"].includes(a.type)) {
          i += o || "";
          continue;
        }
      }
      switch (l.type) {
        case "space":
          continue;
        case "hr": {
          i += this.renderer.hr();
          continue;
        }
        case "heading": {
          const a = l;
          i += this.renderer.heading(this.parseInline(a.tokens), a.depth, Ju(this.parseInline(a.tokens, this.textRenderer)));
          continue;
        }
        case "code": {
          const a = l;
          i += this.renderer.code(a.text, a.lang, !!a.escaped);
          continue;
        }
        case "table": {
          const a = l;
          let o = "", s = "";
          for (let c = 0; c < a.header.length; c++)
            s += this.renderer.tablecell(this.parseInline(a.header[c].tokens), { header: !0, align: a.align[c] });
          o += this.renderer.tablerow(s);
          let u = "";
          for (let c = 0; c < a.rows.length; c++) {
            const _ = a.rows[c];
            s = "";
            for (let h = 0; h < _.length; h++)
              s += this.renderer.tablecell(this.parseInline(_[h].tokens), { header: !1, align: a.align[h] });
            u += this.renderer.tablerow(s);
          }
          i += this.renderer.table(o, u);
          continue;
        }
        case "blockquote": {
          const a = l, o = this.parse(a.tokens);
          i += this.renderer.blockquote(o);
          continue;
        }
        case "list": {
          const a = l, o = a.ordered, s = a.start, u = a.loose;
          let c = "";
          for (let _ = 0; _ < a.items.length; _++) {
            const h = a.items[_], d = h.checked, D = h.task;
            let E = "";
            if (h.task) {
              const F = this.renderer.checkbox(!!d);
              u ? h.tokens.length > 0 && h.tokens[0].type === "paragraph" ? (h.tokens[0].text = F + " " + h.tokens[0].text, h.tokens[0].tokens && h.tokens[0].tokens.length > 0 && h.tokens[0].tokens[0].type === "text" && (h.tokens[0].tokens[0].text = F + " " + h.tokens[0].tokens[0].text)) : h.tokens.unshift({
                type: "text",
                text: F + " "
              }) : E += F + " ";
            }
            E += this.parse(h.tokens, u), c += this.renderer.listitem(E, D, !!d);
          }
          i += this.renderer.list(c, o, s);
          continue;
        }
        case "html": {
          const a = l;
          i += this.renderer.html(a.text, a.block);
          continue;
        }
        case "paragraph": {
          const a = l;
          i += this.renderer.paragraph(this.parseInline(a.tokens));
          continue;
        }
        case "text": {
          let a = l, o = a.tokens ? this.parseInline(a.tokens) : a.text;
          for (; r + 1 < e.length && e[r + 1].type === "text"; )
            a = e[++r], o += `
` + (a.tokens ? this.parseInline(a.tokens) : a.text);
          i += n ? this.renderer.paragraph(o) : o;
          continue;
        }
        default: {
          const a = 'Token with "' + l.type + '" type was not found.';
          if (this.options.silent)
            return console.error(a), "";
          throw new Error(a);
        }
      }
    }
    return i;
  }
  /**
   * Parse Inline Tokens
   */
  parseInline(e, n) {
    n = n || this.renderer;
    let i = "";
    for (let r = 0; r < e.length; r++) {
      const l = e[r];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[l.type]) {
        const a = this.options.extensions.renderers[l.type].call({ parser: this }, l);
        if (a !== !1 || !["escape", "html", "link", "image", "strong", "em", "codespan", "br", "del", "text"].includes(l.type)) {
          i += a || "";
          continue;
        }
      }
      switch (l.type) {
        case "escape": {
          const a = l;
          i += n.text(a.text);
          break;
        }
        case "html": {
          const a = l;
          i += n.html(a.text);
          break;
        }
        case "link": {
          const a = l;
          i += n.link(a.href, a.title, this.parseInline(a.tokens, n));
          break;
        }
        case "image": {
          const a = l;
          i += n.image(a.href, a.title, a.text);
          break;
        }
        case "strong": {
          const a = l;
          i += n.strong(this.parseInline(a.tokens, n));
          break;
        }
        case "em": {
          const a = l;
          i += n.em(this.parseInline(a.tokens, n));
          break;
        }
        case "codespan": {
          const a = l;
          i += n.codespan(a.text);
          break;
        }
        case "br": {
          i += n.br();
          break;
        }
        case "del": {
          const a = l;
          i += n.del(this.parseInline(a.tokens, n));
          break;
        }
        case "text": {
          const a = l;
          i += n.text(a.text);
          break;
        }
        default: {
          const a = 'Token with "' + l.type + '" type was not found.';
          if (this.options.silent)
            return console.error(a), "";
          throw new Error(a);
        }
      }
    }
    return i;
  }
}
class jt {
  constructor(e) {
    Y(this, "options");
    this.options = e || mt;
  }
  /**
   * Process markdown before marked
   */
  preprocess(e) {
    return e;
  }
  /**
   * Process HTML after marked is finished
   */
  postprocess(e) {
    return e;
  }
  /**
   * Process all tokens before walk tokens
   */
  processAllTokens(e) {
    return e;
  }
}
Y(jt, "passThroughHooks", /* @__PURE__ */ new Set([
  "preprocess",
  "postprocess",
  "processAllTokens"
]));
var _t, Ri, no;
class to {
  constructor(...e) {
    pr(this, _t);
    Y(this, "defaults", ir());
    Y(this, "options", this.setOptions);
    Y(this, "parse", hn(this, _t, Ri).call(this, je.lex, Ve.parse));
    Y(this, "parseInline", hn(this, _t, Ri).call(this, je.lexInline, Ve.parseInline));
    Y(this, "Parser", Ve);
    Y(this, "Renderer", Pn);
    Y(this, "TextRenderer", ur);
    Y(this, "Lexer", je);
    Y(this, "Tokenizer", Ln);
    Y(this, "Hooks", jt);
    this.use(...e);
  }
  /**
   * Run callback for every token
   */
  walkTokens(e, n) {
    var r, l;
    let i = [];
    for (const a of e)
      switch (i = i.concat(n.call(this, a)), a.type) {
        case "table": {
          const o = a;
          for (const s of o.header)
            i = i.concat(this.walkTokens(s.tokens, n));
          for (const s of o.rows)
            for (const u of s)
              i = i.concat(this.walkTokens(u.tokens, n));
          break;
        }
        case "list": {
          const o = a;
          i = i.concat(this.walkTokens(o.items, n));
          break;
        }
        default: {
          const o = a;
          (l = (r = this.defaults.extensions) == null ? void 0 : r.childTokens) != null && l[o.type] ? this.defaults.extensions.childTokens[o.type].forEach((s) => {
            const u = o[s].flat(1 / 0);
            i = i.concat(this.walkTokens(u, n));
          }) : o.tokens && (i = i.concat(this.walkTokens(o.tokens, n)));
        }
      }
    return i;
  }
  use(...e) {
    const n = this.defaults.extensions || { renderers: {}, childTokens: {} };
    return e.forEach((i) => {
      const r = { ...i };
      if (r.async = this.defaults.async || r.async || !1, i.extensions && (i.extensions.forEach((l) => {
        if (!l.name)
          throw new Error("extension name required");
        if ("renderer" in l) {
          const a = n.renderers[l.name];
          a ? n.renderers[l.name] = function(...o) {
            let s = l.renderer.apply(this, o);
            return s === !1 && (s = a.apply(this, o)), s;
          } : n.renderers[l.name] = l.renderer;
        }
        if ("tokenizer" in l) {
          if (!l.level || l.level !== "block" && l.level !== "inline")
            throw new Error("extension level must be 'block' or 'inline'");
          const a = n[l.level];
          a ? a.unshift(l.tokenizer) : n[l.level] = [l.tokenizer], l.start && (l.level === "block" ? n.startBlock ? n.startBlock.push(l.start) : n.startBlock = [l.start] : l.level === "inline" && (n.startInline ? n.startInline.push(l.start) : n.startInline = [l.start]));
        }
        "childTokens" in l && l.childTokens && (n.childTokens[l.name] = l.childTokens);
      }), r.extensions = n), i.renderer) {
        const l = this.defaults.renderer || new Pn(this.defaults);
        for (const a in i.renderer) {
          if (!(a in l))
            throw new Error(`renderer '${a}' does not exist`);
          if (a === "options")
            continue;
          const o = a, s = i.renderer[o], u = l[o];
          l[o] = (...c) => {
            let _ = s.apply(l, c);
            return _ === !1 && (_ = u.apply(l, c)), _ || "";
          };
        }
        r.renderer = l;
      }
      if (i.tokenizer) {
        const l = this.defaults.tokenizer || new Ln(this.defaults);
        for (const a in i.tokenizer) {
          if (!(a in l))
            throw new Error(`tokenizer '${a}' does not exist`);
          if (["options", "rules", "lexer"].includes(a))
            continue;
          const o = a, s = i.tokenizer[o], u = l[o];
          l[o] = (...c) => {
            let _ = s.apply(l, c);
            return _ === !1 && (_ = u.apply(l, c)), _;
          };
        }
        r.tokenizer = l;
      }
      if (i.hooks) {
        const l = this.defaults.hooks || new jt();
        for (const a in i.hooks) {
          if (!(a in l))
            throw new Error(`hook '${a}' does not exist`);
          if (a === "options")
            continue;
          const o = a, s = i.hooks[o], u = l[o];
          jt.passThroughHooks.has(a) ? l[o] = (c) => {
            if (this.defaults.async)
              return Promise.resolve(s.call(l, c)).then((h) => u.call(l, h));
            const _ = s.call(l, c);
            return u.call(l, _);
          } : l[o] = (...c) => {
            let _ = s.apply(l, c);
            return _ === !1 && (_ = u.apply(l, c)), _;
          };
        }
        r.hooks = l;
      }
      if (i.walkTokens) {
        const l = this.defaults.walkTokens, a = i.walkTokens;
        r.walkTokens = function(o) {
          let s = [];
          return s.push(a.call(this, o)), l && (s = s.concat(l.call(this, o))), s;
        };
      }
      this.defaults = { ...this.defaults, ...r };
    }), this;
  }
  setOptions(e) {
    return this.defaults = { ...this.defaults, ...e }, this;
  }
  lexer(e, n) {
    return je.lex(e, n ?? this.defaults);
  }
  parser(e, n) {
    return Ve.parse(e, n ?? this.defaults);
  }
}
_t = new WeakSet(), Ri = function(e, n) {
  return (i, r) => {
    const l = { ...r }, a = { ...this.defaults, ...l };
    this.defaults.async === !0 && l.async === !1 && (a.silent || console.warn("marked(): The async option was set to true by an extension. The async: false option sent to parse will be ignored."), a.async = !0);
    const o = hn(this, _t, no).call(this, !!a.silent, !!a.async);
    if (typeof i > "u" || i === null)
      return o(new Error("marked(): input parameter is undefined or null"));
    if (typeof i != "string")
      return o(new Error("marked(): input parameter is of type " + Object.prototype.toString.call(i) + ", string expected"));
    if (a.hooks && (a.hooks.options = a), a.async)
      return Promise.resolve(a.hooks ? a.hooks.preprocess(i) : i).then((s) => e(s, a)).then((s) => a.hooks ? a.hooks.processAllTokens(s) : s).then((s) => a.walkTokens ? Promise.all(this.walkTokens(s, a.walkTokens)).then(() => s) : s).then((s) => n(s, a)).then((s) => a.hooks ? a.hooks.postprocess(s) : s).catch(o);
    try {
      a.hooks && (i = a.hooks.preprocess(i));
      let s = e(i, a);
      a.hooks && (s = a.hooks.processAllTokens(s)), a.walkTokens && this.walkTokens(s, a.walkTokens);
      let u = n(s, a);
      return a.hooks && (u = a.hooks.postprocess(u)), u;
    } catch (s) {
      return o(s);
    }
  };
}, no = function(e, n) {
  return (i) => {
    if (i.message += `
Please report this to https://github.com/markedjs/marked.`, e) {
      const r = "<p>An error occurred:</p><pre>" + ve(i.message + "", !0) + "</pre>";
      return n ? Promise.resolve(r) : r;
    }
    if (n)
      return Promise.reject(i);
    throw i;
  };
};
const ft = new to();
function Z(t, e) {
  return ft.parse(t, e);
}
Z.options = Z.setOptions = function(t) {
  return ft.setOptions(t), Z.defaults = ft.defaults, jl(Z.defaults), Z;
};
Z.getDefaults = ir;
Z.defaults = mt;
Z.use = function(...t) {
  return ft.use(...t), Z.defaults = ft.defaults, jl(Z.defaults), Z;
};
Z.walkTokens = function(t, e) {
  return ft.walkTokens(t, e);
};
Z.parseInline = ft.parseInline;
Z.Parser = Ve;
Z.parser = Ve.parse;
Z.Renderer = Pn;
Z.TextRenderer = ur;
Z.Lexer = je;
Z.lexer = je.lex;
Z.Tokenizer = Ln;
Z.Hooks = jt;
Z.parse = Z;
Z.options;
Z.setOptions;
Z.use;
Z.walkTokens;
Z.parseInline;
Ve.parse;
je.lex;
function Sc(t) {
  if (typeof t == "function" && (t = {
    highlight: t
  }), !t || typeof t.highlight != "function")
    throw new Error("Must provide highlight function");
  return typeof t.langPrefix != "string" && (t.langPrefix = "language-"), typeof t.emptyLangClass != "string" && (t.emptyLangClass = ""), {
    async: !!t.async,
    walkTokens(e) {
      if (e.type !== "code")
        return;
      const n = zr(e.lang);
      if (t.async)
        return Promise.resolve(t.highlight(e.text, n, e.lang || "")).then(jr(e));
      const i = t.highlight(e.text, n, e.lang || "");
      if (i instanceof Promise)
        throw new Error("markedHighlight is not set to async but the highlight function is async. Set the async option to true on markedHighlight to await the async highlight function.");
      jr(e)(i);
    },
    useNewRenderer: !0,
    renderer: {
      code(e, n, i) {
        typeof e == "object" && (i = e.escaped, n = e.lang, e = e.text);
        const r = zr(n), l = r ? t.langPrefix + Xr(r) : t.emptyLangClass, a = l ? ` class="${l}"` : "";
        return e = e.replace(/\n$/, ""), `<pre><code${a}>${i ? e : Xr(e, !0)}
</code></pre>`;
      }
    }
  };
}
function zr(t) {
  return (t || "").match(/\S*/)[0];
}
function jr(t) {
  return (e) => {
    typeof e == "string" && e !== t.text && (t.escaped = !0, t.text = e);
  };
}
const io = /[&<>"']/, xc = new RegExp(io.source, "g"), ro = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, Bc = new RegExp(ro.source, "g"), $c = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, Vr = (t) => $c[t];
function Xr(t, e) {
  if (e) {
    if (io.test(t))
      return t.replace(xc, Vr);
  } else if (ro.test(t))
    return t.replace(Bc, Vr);
  return t;
}
const Tc = /[\0-\x1F!-,\.\/:-@\[-\^`\{-\xA9\xAB-\xB4\xB6-\xB9\xBB-\xBF\xD7\xF7\u02C2-\u02C5\u02D2-\u02DF\u02E5-\u02EB\u02ED\u02EF-\u02FF\u0375\u0378\u0379\u037E\u0380-\u0385\u0387\u038B\u038D\u03A2\u03F6\u0482\u0530\u0557\u0558\u055A-\u055F\u0589-\u0590\u05BE\u05C0\u05C3\u05C6\u05C8-\u05CF\u05EB-\u05EE\u05F3-\u060F\u061B-\u061F\u066A-\u066D\u06D4\u06DD\u06DE\u06E9\u06FD\u06FE\u0700-\u070F\u074B\u074C\u07B2-\u07BF\u07F6-\u07F9\u07FB\u07FC\u07FE\u07FF\u082E-\u083F\u085C-\u085F\u086B-\u089F\u08B5\u08C8-\u08D2\u08E2\u0964\u0965\u0970\u0984\u098D\u098E\u0991\u0992\u09A9\u09B1\u09B3-\u09B5\u09BA\u09BB\u09C5\u09C6\u09C9\u09CA\u09CF-\u09D6\u09D8-\u09DB\u09DE\u09E4\u09E5\u09F2-\u09FB\u09FD\u09FF\u0A00\u0A04\u0A0B-\u0A0E\u0A11\u0A12\u0A29\u0A31\u0A34\u0A37\u0A3A\u0A3B\u0A3D\u0A43-\u0A46\u0A49\u0A4A\u0A4E-\u0A50\u0A52-\u0A58\u0A5D\u0A5F-\u0A65\u0A76-\u0A80\u0A84\u0A8E\u0A92\u0AA9\u0AB1\u0AB4\u0ABA\u0ABB\u0AC6\u0ACA\u0ACE\u0ACF\u0AD1-\u0ADF\u0AE4\u0AE5\u0AF0-\u0AF8\u0B00\u0B04\u0B0D\u0B0E\u0B11\u0B12\u0B29\u0B31\u0B34\u0B3A\u0B3B\u0B45\u0B46\u0B49\u0B4A\u0B4E-\u0B54\u0B58-\u0B5B\u0B5E\u0B64\u0B65\u0B70\u0B72-\u0B81\u0B84\u0B8B-\u0B8D\u0B91\u0B96-\u0B98\u0B9B\u0B9D\u0BA0-\u0BA2\u0BA5-\u0BA7\u0BAB-\u0BAD\u0BBA-\u0BBD\u0BC3-\u0BC5\u0BC9\u0BCE\u0BCF\u0BD1-\u0BD6\u0BD8-\u0BE5\u0BF0-\u0BFF\u0C0D\u0C11\u0C29\u0C3A-\u0C3C\u0C45\u0C49\u0C4E-\u0C54\u0C57\u0C5B-\u0C5F\u0C64\u0C65\u0C70-\u0C7F\u0C84\u0C8D\u0C91\u0CA9\u0CB4\u0CBA\u0CBB\u0CC5\u0CC9\u0CCE-\u0CD4\u0CD7-\u0CDD\u0CDF\u0CE4\u0CE5\u0CF0\u0CF3-\u0CFF\u0D0D\u0D11\u0D45\u0D49\u0D4F-\u0D53\u0D58-\u0D5E\u0D64\u0D65\u0D70-\u0D79\u0D80\u0D84\u0D97-\u0D99\u0DB2\u0DBC\u0DBE\u0DBF\u0DC7-\u0DC9\u0DCB-\u0DCE\u0DD5\u0DD7\u0DE0-\u0DE5\u0DF0\u0DF1\u0DF4-\u0E00\u0E3B-\u0E3F\u0E4F\u0E5A-\u0E80\u0E83\u0E85\u0E8B\u0EA4\u0EA6\u0EBE\u0EBF\u0EC5\u0EC7\u0ECE\u0ECF\u0EDA\u0EDB\u0EE0-\u0EFF\u0F01-\u0F17\u0F1A-\u0F1F\u0F2A-\u0F34\u0F36\u0F38\u0F3A-\u0F3D\u0F48\u0F6D-\u0F70\u0F85\u0F98\u0FBD-\u0FC5\u0FC7-\u0FFF\u104A-\u104F\u109E\u109F\u10C6\u10C8-\u10CC\u10CE\u10CF\u10FB\u1249\u124E\u124F\u1257\u1259\u125E\u125F\u1289\u128E\u128F\u12B1\u12B6\u12B7\u12BF\u12C1\u12C6\u12C7\u12D7\u1311\u1316\u1317\u135B\u135C\u1360-\u137F\u1390-\u139F\u13F6\u13F7\u13FE-\u1400\u166D\u166E\u1680\u169B-\u169F\u16EB-\u16ED\u16F9-\u16FF\u170D\u1715-\u171F\u1735-\u173F\u1754-\u175F\u176D\u1771\u1774-\u177F\u17D4-\u17D6\u17D8-\u17DB\u17DE\u17DF\u17EA-\u180A\u180E\u180F\u181A-\u181F\u1879-\u187F\u18AB-\u18AF\u18F6-\u18FF\u191F\u192C-\u192F\u193C-\u1945\u196E\u196F\u1975-\u197F\u19AC-\u19AF\u19CA-\u19CF\u19DA-\u19FF\u1A1C-\u1A1F\u1A5F\u1A7D\u1A7E\u1A8A-\u1A8F\u1A9A-\u1AA6\u1AA8-\u1AAF\u1AC1-\u1AFF\u1B4C-\u1B4F\u1B5A-\u1B6A\u1B74-\u1B7F\u1BF4-\u1BFF\u1C38-\u1C3F\u1C4A-\u1C4C\u1C7E\u1C7F\u1C89-\u1C8F\u1CBB\u1CBC\u1CC0-\u1CCF\u1CD3\u1CFB-\u1CFF\u1DFA\u1F16\u1F17\u1F1E\u1F1F\u1F46\u1F47\u1F4E\u1F4F\u1F58\u1F5A\u1F5C\u1F5E\u1F7E\u1F7F\u1FB5\u1FBD\u1FBF-\u1FC1\u1FC5\u1FCD-\u1FCF\u1FD4\u1FD5\u1FDC-\u1FDF\u1FED-\u1FF1\u1FF5\u1FFD-\u203E\u2041-\u2053\u2055-\u2070\u2072-\u207E\u2080-\u208F\u209D-\u20CF\u20F1-\u2101\u2103-\u2106\u2108\u2109\u2114\u2116-\u2118\u211E-\u2123\u2125\u2127\u2129\u212E\u213A\u213B\u2140-\u2144\u214A-\u214D\u214F-\u215F\u2189-\u24B5\u24EA-\u2BFF\u2C2F\u2C5F\u2CE5-\u2CEA\u2CF4-\u2CFF\u2D26\u2D28-\u2D2C\u2D2E\u2D2F\u2D68-\u2D6E\u2D70-\u2D7E\u2D97-\u2D9F\u2DA7\u2DAF\u2DB7\u2DBF\u2DC7\u2DCF\u2DD7\u2DDF\u2E00-\u2E2E\u2E30-\u3004\u3008-\u3020\u3030\u3036\u3037\u303D-\u3040\u3097\u3098\u309B\u309C\u30A0\u30FB\u3100-\u3104\u3130\u318F-\u319F\u31C0-\u31EF\u3200-\u33FF\u4DC0-\u4DFF\u9FFD-\u9FFF\uA48D-\uA4CF\uA4FE\uA4FF\uA60D-\uA60F\uA62C-\uA63F\uA673\uA67E\uA6F2-\uA716\uA720\uA721\uA789\uA78A\uA7C0\uA7C1\uA7CB-\uA7F4\uA828-\uA82B\uA82D-\uA83F\uA874-\uA87F\uA8C6-\uA8CF\uA8DA-\uA8DF\uA8F8-\uA8FA\uA8FC\uA92E\uA92F\uA954-\uA95F\uA97D-\uA97F\uA9C1-\uA9CE\uA9DA-\uA9DF\uA9FF\uAA37-\uAA3F\uAA4E\uAA4F\uAA5A-\uAA5F\uAA77-\uAA79\uAAC3-\uAADA\uAADE\uAADF\uAAF0\uAAF1\uAAF7-\uAB00\uAB07\uAB08\uAB0F\uAB10\uAB17-\uAB1F\uAB27\uAB2F\uAB5B\uAB6A-\uAB6F\uABEB\uABEE\uABEF\uABFA-\uABFF\uD7A4-\uD7AF\uD7C7-\uD7CA\uD7FC-\uD7FF\uE000-\uF8FF\uFA6E\uFA6F\uFADA-\uFAFF\uFB07-\uFB12\uFB18-\uFB1C\uFB29\uFB37\uFB3D\uFB3F\uFB42\uFB45\uFBB2-\uFBD2\uFD3E-\uFD4F\uFD90\uFD91\uFDC8-\uFDEF\uFDFC-\uFDFF\uFE10-\uFE1F\uFE30-\uFE32\uFE35-\uFE4C\uFE50-\uFE6F\uFE75\uFEFD-\uFF0F\uFF1A-\uFF20\uFF3B-\uFF3E\uFF40\uFF5B-\uFF65\uFFBF-\uFFC1\uFFC8\uFFC9\uFFD0\uFFD1\uFFD8\uFFD9\uFFDD-\uFFFF]|\uD800[\uDC0C\uDC27\uDC3B\uDC3E\uDC4E\uDC4F\uDC5E-\uDC7F\uDCFB-\uDD3F\uDD75-\uDDFC\uDDFE-\uDE7F\uDE9D-\uDE9F\uDED1-\uDEDF\uDEE1-\uDEFF\uDF20-\uDF2C\uDF4B-\uDF4F\uDF7B-\uDF7F\uDF9E\uDF9F\uDFC4-\uDFC7\uDFD0\uDFD6-\uDFFF]|\uD801[\uDC9E\uDC9F\uDCAA-\uDCAF\uDCD4-\uDCD7\uDCFC-\uDCFF\uDD28-\uDD2F\uDD64-\uDDFF\uDF37-\uDF3F\uDF56-\uDF5F\uDF68-\uDFFF]|\uD802[\uDC06\uDC07\uDC09\uDC36\uDC39-\uDC3B\uDC3D\uDC3E\uDC56-\uDC5F\uDC77-\uDC7F\uDC9F-\uDCDF\uDCF3\uDCF6-\uDCFF\uDD16-\uDD1F\uDD3A-\uDD7F\uDDB8-\uDDBD\uDDC0-\uDDFF\uDE04\uDE07-\uDE0B\uDE14\uDE18\uDE36\uDE37\uDE3B-\uDE3E\uDE40-\uDE5F\uDE7D-\uDE7F\uDE9D-\uDEBF\uDEC8\uDEE7-\uDEFF\uDF36-\uDF3F\uDF56-\uDF5F\uDF73-\uDF7F\uDF92-\uDFFF]|\uD803[\uDC49-\uDC7F\uDCB3-\uDCBF\uDCF3-\uDCFF\uDD28-\uDD2F\uDD3A-\uDE7F\uDEAA\uDEAD-\uDEAF\uDEB2-\uDEFF\uDF1D-\uDF26\uDF28-\uDF2F\uDF51-\uDFAF\uDFC5-\uDFDF\uDFF7-\uDFFF]|\uD804[\uDC47-\uDC65\uDC70-\uDC7E\uDCBB-\uDCCF\uDCE9-\uDCEF\uDCFA-\uDCFF\uDD35\uDD40-\uDD43\uDD48-\uDD4F\uDD74\uDD75\uDD77-\uDD7F\uDDC5-\uDDC8\uDDCD\uDDDB\uDDDD-\uDDFF\uDE12\uDE38-\uDE3D\uDE3F-\uDE7F\uDE87\uDE89\uDE8E\uDE9E\uDEA9-\uDEAF\uDEEB-\uDEEF\uDEFA-\uDEFF\uDF04\uDF0D\uDF0E\uDF11\uDF12\uDF29\uDF31\uDF34\uDF3A\uDF45\uDF46\uDF49\uDF4A\uDF4E\uDF4F\uDF51-\uDF56\uDF58-\uDF5C\uDF64\uDF65\uDF6D-\uDF6F\uDF75-\uDFFF]|\uD805[\uDC4B-\uDC4F\uDC5A-\uDC5D\uDC62-\uDC7F\uDCC6\uDCC8-\uDCCF\uDCDA-\uDD7F\uDDB6\uDDB7\uDDC1-\uDDD7\uDDDE-\uDDFF\uDE41-\uDE43\uDE45-\uDE4F\uDE5A-\uDE7F\uDEB9-\uDEBF\uDECA-\uDEFF\uDF1B\uDF1C\uDF2C-\uDF2F\uDF3A-\uDFFF]|\uD806[\uDC3B-\uDC9F\uDCEA-\uDCFE\uDD07\uDD08\uDD0A\uDD0B\uDD14\uDD17\uDD36\uDD39\uDD3A\uDD44-\uDD4F\uDD5A-\uDD9F\uDDA8\uDDA9\uDDD8\uDDD9\uDDE2\uDDE5-\uDDFF\uDE3F-\uDE46\uDE48-\uDE4F\uDE9A-\uDE9C\uDE9E-\uDEBF\uDEF9-\uDFFF]|\uD807[\uDC09\uDC37\uDC41-\uDC4F\uDC5A-\uDC71\uDC90\uDC91\uDCA8\uDCB7-\uDCFF\uDD07\uDD0A\uDD37-\uDD39\uDD3B\uDD3E\uDD48-\uDD4F\uDD5A-\uDD5F\uDD66\uDD69\uDD8F\uDD92\uDD99-\uDD9F\uDDAA-\uDEDF\uDEF7-\uDFAF\uDFB1-\uDFFF]|\uD808[\uDF9A-\uDFFF]|\uD809[\uDC6F-\uDC7F\uDD44-\uDFFF]|[\uD80A\uD80B\uD80E-\uD810\uD812-\uD819\uD824-\uD82B\uD82D\uD82E\uD830-\uD833\uD837\uD839\uD83D\uD83F\uD87B-\uD87D\uD87F\uD885-\uDB3F\uDB41-\uDBFF][\uDC00-\uDFFF]|\uD80D[\uDC2F-\uDFFF]|\uD811[\uDE47-\uDFFF]|\uD81A[\uDE39-\uDE3F\uDE5F\uDE6A-\uDECF\uDEEE\uDEEF\uDEF5-\uDEFF\uDF37-\uDF3F\uDF44-\uDF4F\uDF5A-\uDF62\uDF78-\uDF7C\uDF90-\uDFFF]|\uD81B[\uDC00-\uDE3F\uDE80-\uDEFF\uDF4B-\uDF4E\uDF88-\uDF8E\uDFA0-\uDFDF\uDFE2\uDFE5-\uDFEF\uDFF2-\uDFFF]|\uD821[\uDFF8-\uDFFF]|\uD823[\uDCD6-\uDCFF\uDD09-\uDFFF]|\uD82C[\uDD1F-\uDD4F\uDD53-\uDD63\uDD68-\uDD6F\uDEFC-\uDFFF]|\uD82F[\uDC6B-\uDC6F\uDC7D-\uDC7F\uDC89-\uDC8F\uDC9A-\uDC9C\uDC9F-\uDFFF]|\uD834[\uDC00-\uDD64\uDD6A-\uDD6C\uDD73-\uDD7A\uDD83\uDD84\uDD8C-\uDDA9\uDDAE-\uDE41\uDE45-\uDFFF]|\uD835[\uDC55\uDC9D\uDCA0\uDCA1\uDCA3\uDCA4\uDCA7\uDCA8\uDCAD\uDCBA\uDCBC\uDCC4\uDD06\uDD0B\uDD0C\uDD15\uDD1D\uDD3A\uDD3F\uDD45\uDD47-\uDD49\uDD51\uDEA6\uDEA7\uDEC1\uDEDB\uDEFB\uDF15\uDF35\uDF4F\uDF6F\uDF89\uDFA9\uDFC3\uDFCC\uDFCD]|\uD836[\uDC00-\uDDFF\uDE37-\uDE3A\uDE6D-\uDE74\uDE76-\uDE83\uDE85-\uDE9A\uDEA0\uDEB0-\uDFFF]|\uD838[\uDC07\uDC19\uDC1A\uDC22\uDC25\uDC2B-\uDCFF\uDD2D-\uDD2F\uDD3E\uDD3F\uDD4A-\uDD4D\uDD4F-\uDEBF\uDEFA-\uDFFF]|\uD83A[\uDCC5-\uDCCF\uDCD7-\uDCFF\uDD4C-\uDD4F\uDD5A-\uDFFF]|\uD83B[\uDC00-\uDDFF\uDE04\uDE20\uDE23\uDE25\uDE26\uDE28\uDE33\uDE38\uDE3A\uDE3C-\uDE41\uDE43-\uDE46\uDE48\uDE4A\uDE4C\uDE50\uDE53\uDE55\uDE56\uDE58\uDE5A\uDE5C\uDE5E\uDE60\uDE63\uDE65\uDE66\uDE6B\uDE73\uDE78\uDE7D\uDE7F\uDE8A\uDE9C-\uDEA0\uDEA4\uDEAA\uDEBC-\uDFFF]|\uD83C[\uDC00-\uDD2F\uDD4A-\uDD4F\uDD6A-\uDD6F\uDD8A-\uDFFF]|\uD83E[\uDC00-\uDFEF\uDFFA-\uDFFF]|\uD869[\uDEDE-\uDEFF]|\uD86D[\uDF35-\uDF3F]|\uD86E[\uDC1E\uDC1F]|\uD873[\uDEA2-\uDEAF]|\uD87A[\uDFE1-\uDFFF]|\uD87E[\uDE1E-\uDFFF]|\uD884[\uDF4B-\uDFFF]|\uDB40[\uDC00-\uDCFF\uDDF0-\uDFFF]/g, Ic = Object.hasOwnProperty;
class cr {
  /**
   * Create a new slug class.
   */
  constructor() {
    this.occurrences, this.reset();
  }
  /**
   * Generate a unique slug.
  *
  * Tracks previously generated slugs: repeated calls with the same value
  * will result in different slugs.
  * Use the `slug` function to get same slugs.
   *
   * @param  {string} value
   *   String of text to slugify
   * @param  {boolean} [maintainCase=false]
   *   Keep the current case, otherwise make all lowercase
   * @return {string}
   *   A unique slug string
   */
  slug(e, n) {
    const i = this;
    let r = Lc(e, n === !0);
    const l = r;
    for (; Ic.call(i.occurrences, r); )
      i.occurrences[l]++, r = l + "-" + i.occurrences[l];
    return i.occurrences[r] = 0, r;
  }
  /**
   * Reset - Forget all previous slugs
   *
   * @return void
   */
  reset() {
    this.occurrences = /* @__PURE__ */ Object.create(null);
  }
}
function Lc(t, e) {
  return typeof t != "string" ? "" : (e || (t = t.toLowerCase()), t.replace(Tc, "").replace(/ /g, "-"));
}
let ao = new cr(), lo = [];
function Hc({ prefix: t = "", globalSlugs: e = !1 } = {}) {
  return {
    headerIds: !1,
    // prevent deprecation warning; remove this once headerIds option is removed
    hooks: {
      preprocess(n) {
        return e || Pc(), n;
      }
    },
    renderer: {
      heading(n, i, r) {
        r = r.toLowerCase().trim().replace(/<[!\/a-z].*?>/gi, "");
        const l = `${t}${ao.slug(r)}`, a = { level: i, text: n, id: l };
        return lo.push(a), `<h${i} id="${l}">${n}</h${i}>
`;
      }
    }
  };
}
function Pc() {
  lo = [], ao = new cr();
}
var Zr = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {};
function rm(t) {
  return t && t.__esModule && Object.prototype.hasOwnProperty.call(t, "default") ? t.default : t;
}
var oo = { exports: {} };
(function(t) {
  var e = typeof window < "u" ? window : typeof WorkerGlobalScope < "u" && self instanceof WorkerGlobalScope ? self : {};
  /**
   * Prism: Lightweight, robust, elegant syntax highlighting
   *
   * @license MIT <https://opensource.org/licenses/MIT>
   * @author Lea Verou <https://lea.verou.me>
   * @namespace
   * @public
   */
  var n = function(i) {
    var r = /(?:^|\s)lang(?:uage)?-([\w-]+)(?=\s|$)/i, l = 0, a = {}, o = {
      /**
       * By default, Prism will attempt to highlight all code elements (by calling {@link Prism.highlightAll}) on the
       * current page after the page finished loading. This might be a problem if e.g. you wanted to asynchronously load
       * additional languages or plugins yourself.
       *
       * By setting this value to `true`, Prism will not automatically highlight all code elements on the page.
       *
       * You obviously have to change this value before the automatic highlighting started. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.manual = true;
       * // add a new <script> to load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      manual: i.Prism && i.Prism.manual,
      /**
       * By default, if Prism is in a web worker, it assumes that it is in a worker it created itself, so it uses
       * `addEventListener` to communicate with its parent instance. However, if you're using Prism manually in your
       * own worker, you don't want it to do this.
       *
       * By setting this value to `true`, Prism will not add its own listeners to the worker.
       *
       * You obviously have to change this value before Prism executes. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.disableWorkerMessageHandler = true;
       * // Load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      disableWorkerMessageHandler: i.Prism && i.Prism.disableWorkerMessageHandler,
      /**
       * A namespace for utility methods.
       *
       * All function in this namespace that are not explicitly marked as _public_ are for __internal use only__ and may
       * change or disappear at any time.
       *
       * @namespace
       * @memberof Prism
       */
      util: {
        encode: function g(f) {
          return f instanceof s ? new s(f.type, g(f.content), f.alias) : Array.isArray(f) ? f.map(g) : f.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/\u00a0/g, " ");
        },
        /**
         * Returns the name of the type of the given value.
         *
         * @param {any} o
         * @returns {string}
         * @example
         * type(null)      === 'Null'
         * type(undefined) === 'Undefined'
         * type(123)       === 'Number'
         * type('foo')     === 'String'
         * type(true)      === 'Boolean'
         * type([1, 2])    === 'Array'
         * type({})        === 'Object'
         * type(String)    === 'Function'
         * type(/abc+/)    === 'RegExp'
         */
        type: function(g) {
          return Object.prototype.toString.call(g).slice(8, -1);
        },
        /**
         * Returns a unique number for the given object. Later calls will still return the same number.
         *
         * @param {Object} obj
         * @returns {number}
         */
        objId: function(g) {
          return g.__id || Object.defineProperty(g, "__id", { value: ++l }), g.__id;
        },
        /**
         * Creates a deep clone of the given object.
         *
         * The main intended use of this function is to clone language definitions.
         *
         * @param {T} o
         * @param {Record<number, any>} [visited]
         * @returns {T}
         * @template T
         */
        clone: function g(f, m) {
          m = m || {};
          var v, p;
          switch (o.util.type(f)) {
            case "Object":
              if (p = o.util.objId(f), m[p])
                return m[p];
              v = /** @type {Record<string, any>} */
              {}, m[p] = v;
              for (var b in f)
                f.hasOwnProperty(b) && (v[b] = g(f[b], m));
              return (
                /** @type {any} */
                v
              );
            case "Array":
              return p = o.util.objId(f), m[p] ? m[p] : (v = [], m[p] = v, /** @type {Array} */
              /** @type {any} */
              f.forEach(function(k, y) {
                v[y] = g(k, m);
              }), /** @type {any} */
              v);
            default:
              return f;
          }
        },
        /**
         * Returns the Prism language of the given element set by a `language-xxxx` or `lang-xxxx` class.
         *
         * If no language is set for the element or the element is `null` or `undefined`, `none` will be returned.
         *
         * @param {Element} element
         * @returns {string}
         */
        getLanguage: function(g) {
          for (; g; ) {
            var f = r.exec(g.className);
            if (f)
              return f[1].toLowerCase();
            g = g.parentElement;
          }
          return "none";
        },
        /**
         * Sets the Prism `language-xxxx` class of the given element.
         *
         * @param {Element} element
         * @param {string} language
         * @returns {void}
         */
        setLanguage: function(g, f) {
          g.className = g.className.replace(RegExp(r, "gi"), ""), g.classList.add("language-" + f);
        },
        /**
         * Returns the script element that is currently executing.
         *
         * This does __not__ work for line script element.
         *
         * @returns {HTMLScriptElement | null}
         */
        currentScript: function() {
          if (typeof document > "u")
            return null;
          if ("currentScript" in document)
            return (
              /** @type {any} */
              document.currentScript
            );
          try {
            throw new Error();
          } catch (v) {
            var g = (/at [^(\r\n]*\((.*):[^:]+:[^:]+\)$/i.exec(v.stack) || [])[1];
            if (g) {
              var f = document.getElementsByTagName("script");
              for (var m in f)
                if (f[m].src == g)
                  return f[m];
            }
            return null;
          }
        },
        /**
         * Returns whether a given class is active for `element`.
         *
         * The class can be activated if `element` or one of its ancestors has the given class and it can be deactivated
         * if `element` or one of its ancestors has the negated version of the given class. The _negated version_ of the
         * given class is just the given class with a `no-` prefix.
         *
         * Whether the class is active is determined by the closest ancestor of `element` (where `element` itself is
         * closest ancestor) that has the given class or the negated version of it. If neither `element` nor any of its
         * ancestors have the given class or the negated version of it, then the default activation will be returned.
         *
         * In the paradoxical situation where the closest ancestor contains __both__ the given class and the negated
         * version of it, the class is considered active.
         *
         * @param {Element} element
         * @param {string} className
         * @param {boolean} [defaultActivation=false]
         * @returns {boolean}
         */
        isActive: function(g, f, m) {
          for (var v = "no-" + f; g; ) {
            var p = g.classList;
            if (p.contains(f))
              return !0;
            if (p.contains(v))
              return !1;
            g = g.parentElement;
          }
          return !!m;
        }
      },
      /**
       * This namespace contains all currently loaded languages and the some helper functions to create and modify languages.
       *
       * @namespace
       * @memberof Prism
       * @public
       */
      languages: {
        /**
         * The grammar for plain, unformatted text.
         */
        plain: a,
        plaintext: a,
        text: a,
        txt: a,
        /**
         * Creates a deep copy of the language with the given id and appends the given tokens.
         *
         * If a token in `redef` also appears in the copied language, then the existing token in the copied language
         * will be overwritten at its original position.
         *
         * ## Best practices
         *
         * Since the position of overwriting tokens (token in `redef` that overwrite tokens in the copied language)
         * doesn't matter, they can technically be in any order. However, this can be confusing to others that trying to
         * understand the language definition because, normally, the order of tokens matters in Prism grammars.
         *
         * Therefore, it is encouraged to order overwriting tokens according to the positions of the overwritten tokens.
         * Furthermore, all non-overwriting tokens should be placed after the overwriting ones.
         *
         * @param {string} id The id of the language to extend. This has to be a key in `Prism.languages`.
         * @param {Grammar} redef The new tokens to append.
         * @returns {Grammar} The new language created.
         * @public
         * @example
         * Prism.languages['css-with-colors'] = Prism.languages.extend('css', {
         *     // Prism.languages.css already has a 'comment' token, so this token will overwrite CSS' 'comment' token
         *     // at its original position
         *     'comment': { ... },
         *     // CSS doesn't have a 'color' token, so this token will be appended
         *     'color': /\b(?:red|green|blue)\b/
         * });
         */
        extend: function(g, f) {
          var m = o.util.clone(o.languages[g]);
          for (var v in f)
            m[v] = f[v];
          return m;
        },
        /**
         * Inserts tokens _before_ another token in a language definition or any other grammar.
         *
         * ## Usage
         *
         * This helper method makes it easy to modify existing languages. For example, the CSS language definition
         * not only defines CSS highlighting for CSS documents, but also needs to define highlighting for CSS embedded
         * in HTML through `<style>` elements. To do this, it needs to modify `Prism.languages.markup` and add the
         * appropriate tokens. However, `Prism.languages.markup` is a regular JavaScript object literal, so if you do
         * this:
         *
         * ```js
         * Prism.languages.markup.style = {
         *     // token
         * };
         * ```
         *
         * then the `style` token will be added (and processed) at the end. `insertBefore` allows you to insert tokens
         * before existing tokens. For the CSS example above, you would use it like this:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'cdata', {
         *     'style': {
         *         // token
         *     }
         * });
         * ```
         *
         * ## Special cases
         *
         * If the grammars of `inside` and `insert` have tokens with the same name, the tokens in `inside`'s grammar
         * will be ignored.
         *
         * This behavior can be used to insert tokens after `before`:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'comment', {
         *     'comment': Prism.languages.markup.comment,
         *     // tokens after 'comment'
         * });
         * ```
         *
         * ## Limitations
         *
         * The main problem `insertBefore` has to solve is iteration order. Since ES2015, the iteration order for object
         * properties is guaranteed to be the insertion order (except for integer keys) but some browsers behave
         * differently when keys are deleted and re-inserted. So `insertBefore` can't be implemented by temporarily
         * deleting properties which is necessary to insert at arbitrary positions.
         *
         * To solve this problem, `insertBefore` doesn't actually insert the given tokens into the target object.
         * Instead, it will create a new object and replace all references to the target object with the new one. This
         * can be done without temporarily deleting properties, so the iteration order is well-defined.
         *
         * However, only references that can be reached from `Prism.languages` or `insert` will be replaced. I.e. if
         * you hold the target object in a variable, then the value of the variable will not change.
         *
         * ```js
         * var oldMarkup = Prism.languages.markup;
         * var newMarkup = Prism.languages.insertBefore('markup', 'comment', { ... });
         *
         * assert(oldMarkup !== Prism.languages.markup);
         * assert(newMarkup === Prism.languages.markup);
         * ```
         *
         * @param {string} inside The property of `root` (e.g. a language id in `Prism.languages`) that contains the
         * object to be modified.
         * @param {string} before The key to insert before.
         * @param {Grammar} insert An object containing the key-value pairs to be inserted.
         * @param {Object<string, any>} [root] The object containing `inside`, i.e. the object that contains the
         * object to be modified.
         *
         * Defaults to `Prism.languages`.
         * @returns {Grammar} The new grammar object.
         * @public
         */
        insertBefore: function(g, f, m, v) {
          v = v || /** @type {any} */
          o.languages;
          var p = v[g], b = {};
          for (var k in p)
            if (p.hasOwnProperty(k)) {
              if (k == f)
                for (var y in m)
                  m.hasOwnProperty(y) && (b[y] = m[y]);
              m.hasOwnProperty(k) || (b[k] = p[k]);
            }
          var w = v[g];
          return v[g] = b, o.languages.DFS(o.languages, function(A, B) {
            B === w && A != g && (this[A] = b);
          }), b;
        },
        // Traverse a language definition with Depth First Search
        DFS: function g(f, m, v, p) {
          p = p || {};
          var b = o.util.objId;
          for (var k in f)
            if (f.hasOwnProperty(k)) {
              m.call(f, k, f[k], v || k);
              var y = f[k], w = o.util.type(y);
              w === "Object" && !p[b(y)] ? (p[b(y)] = !0, g(y, m, null, p)) : w === "Array" && !p[b(y)] && (p[b(y)] = !0, g(y, m, k, p));
            }
        }
      },
      plugins: {},
      /**
       * This is the most high-level function in Prism’s API.
       * It fetches all the elements that have a `.language-xxxx` class and then calls {@link Prism.highlightElement} on
       * each one of them.
       *
       * This is equivalent to `Prism.highlightAllUnder(document, async, callback)`.
       *
       * @param {boolean} [async=false] Same as in {@link Prism.highlightAllUnder}.
       * @param {HighlightCallback} [callback] Same as in {@link Prism.highlightAllUnder}.
       * @memberof Prism
       * @public
       */
      highlightAll: function(g, f) {
        o.highlightAllUnder(document, g, f);
      },
      /**
       * Fetches all the descendants of `container` that have a `.language-xxxx` class and then calls
       * {@link Prism.highlightElement} on each one of them.
       *
       * The following hooks will be run:
       * 1. `before-highlightall`
       * 2. `before-all-elements-highlight`
       * 3. All hooks of {@link Prism.highlightElement} for each element.
       *
       * @param {ParentNode} container The root element, whose descendants that have a `.language-xxxx` class will be highlighted.
       * @param {boolean} [async=false] Whether each element is to be highlighted asynchronously using Web Workers.
       * @param {HighlightCallback} [callback] An optional callback to be invoked on each element after its highlighting is done.
       * @memberof Prism
       * @public
       */
      highlightAllUnder: function(g, f, m) {
        var v = {
          callback: m,
          container: g,
          selector: 'code[class*="language-"], [class*="language-"] code, code[class*="lang-"], [class*="lang-"] code'
        };
        o.hooks.run("before-highlightall", v), v.elements = Array.prototype.slice.apply(v.container.querySelectorAll(v.selector)), o.hooks.run("before-all-elements-highlight", v);
        for (var p = 0, b; b = v.elements[p++]; )
          o.highlightElement(b, f === !0, v.callback);
      },
      /**
       * Highlights the code inside a single element.
       *
       * The following hooks will be run:
       * 1. `before-sanity-check`
       * 2. `before-highlight`
       * 3. All hooks of {@link Prism.highlight}. These hooks will be run by an asynchronous worker if `async` is `true`.
       * 4. `before-insert`
       * 5. `after-highlight`
       * 6. `complete`
       *
       * Some the above hooks will be skipped if the element doesn't contain any text or there is no grammar loaded for
       * the element's language.
       *
       * @param {Element} element The element containing the code.
       * It must have a class of `language-xxxx` to be processed, where `xxxx` is a valid language identifier.
       * @param {boolean} [async=false] Whether the element is to be highlighted asynchronously using Web Workers
       * to improve performance and avoid blocking the UI when highlighting very large chunks of code. This option is
       * [disabled by default](https://prismjs.com/faq.html#why-is-asynchronous-highlighting-disabled-by-default).
       *
       * Note: All language definitions required to highlight the code must be included in the main `prism.js` file for
       * asynchronous highlighting to work. You can build your own bundle on the
       * [Download page](https://prismjs.com/download.html).
       * @param {HighlightCallback} [callback] An optional callback to be invoked after the highlighting is done.
       * Mostly useful when `async` is `true`, since in that case, the highlighting is done asynchronously.
       * @memberof Prism
       * @public
       */
      highlightElement: function(g, f, m) {
        var v = o.util.getLanguage(g), p = o.languages[v];
        o.util.setLanguage(g, v);
        var b = g.parentElement;
        b && b.nodeName.toLowerCase() === "pre" && o.util.setLanguage(b, v);
        var k = g.textContent, y = {
          element: g,
          language: v,
          grammar: p,
          code: k
        };
        function w(B) {
          y.highlightedCode = B, o.hooks.run("before-insert", y), y.element.innerHTML = y.highlightedCode, o.hooks.run("after-highlight", y), o.hooks.run("complete", y), m && m.call(y.element);
        }
        if (o.hooks.run("before-sanity-check", y), b = y.element.parentElement, b && b.nodeName.toLowerCase() === "pre" && !b.hasAttribute("tabindex") && b.setAttribute("tabindex", "0"), !y.code) {
          o.hooks.run("complete", y), m && m.call(y.element);
          return;
        }
        if (o.hooks.run("before-highlight", y), !y.grammar) {
          w(o.util.encode(y.code));
          return;
        }
        if (f && i.Worker) {
          var A = new Worker(o.filename);
          A.onmessage = function(B) {
            w(B.data);
          }, A.postMessage(JSON.stringify({
            language: y.language,
            code: y.code,
            immediateClose: !0
          }));
        } else
          w(o.highlight(y.code, y.grammar, y.language));
      },
      /**
       * Low-level function, only use if you know what you’re doing. It accepts a string of text as input
       * and the language definitions to use, and returns a string with the HTML produced.
       *
       * The following hooks will be run:
       * 1. `before-tokenize`
       * 2. `after-tokenize`
       * 3. `wrap`: On each {@link Token}.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @param {string} language The name of the language definition passed to `grammar`.
       * @returns {string} The highlighted HTML.
       * @memberof Prism
       * @public
       * @example
       * Prism.highlight('var foo = true;', Prism.languages.javascript, 'javascript');
       */
      highlight: function(g, f, m) {
        var v = {
          code: g,
          grammar: f,
          language: m
        };
        if (o.hooks.run("before-tokenize", v), !v.grammar)
          throw new Error('The language "' + v.language + '" has no grammar.');
        return v.tokens = o.tokenize(v.code, v.grammar), o.hooks.run("after-tokenize", v), s.stringify(o.util.encode(v.tokens), v.language);
      },
      /**
       * This is the heart of Prism, and the most low-level function you can use. It accepts a string of text as input
       * and the language definitions to use, and returns an array with the tokenized code.
       *
       * When the language definition includes nested tokens, the function is called recursively on each of these tokens.
       *
       * This method could be useful in other contexts as well, as a very crude parser.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @returns {TokenStream} An array of strings and tokens, a token stream.
       * @memberof Prism
       * @public
       * @example
       * let code = `var foo = 0;`;
       * let tokens = Prism.tokenize(code, Prism.languages.javascript);
       * tokens.forEach(token => {
       *     if (token instanceof Prism.Token && token.type === 'number') {
       *         console.log(`Found numeric literal: ${token.content}`);
       *     }
       * });
       */
      tokenize: function(g, f) {
        var m = f.rest;
        if (m) {
          for (var v in m)
            f[v] = m[v];
          delete f.rest;
        }
        var p = new _();
        return h(p, p.head, g), c(g, p, f, p.head, 0), D(p);
      },
      /**
       * @namespace
       * @memberof Prism
       * @public
       */
      hooks: {
        all: {},
        /**
         * Adds the given callback to the list of callbacks for the given hook.
         *
         * The callback will be invoked when the hook it is registered for is run.
         * Hooks are usually directly run by a highlight function but you can also run hooks yourself.
         *
         * One callback function can be registered to multiple hooks and the same hook multiple times.
         *
         * @param {string} name The name of the hook.
         * @param {HookCallback} callback The callback function which is given environment variables.
         * @public
         */
        add: function(g, f) {
          var m = o.hooks.all;
          m[g] = m[g] || [], m[g].push(f);
        },
        /**
         * Runs a hook invoking all registered callbacks with the given environment variables.
         *
         * Callbacks will be invoked synchronously and in the order in which they were registered.
         *
         * @param {string} name The name of the hook.
         * @param {Object<string, any>} env The environment variables of the hook passed to all callbacks registered.
         * @public
         */
        run: function(g, f) {
          var m = o.hooks.all[g];
          if (!(!m || !m.length))
            for (var v = 0, p; p = m[v++]; )
              p(f);
        }
      },
      Token: s
    };
    i.Prism = o;
    function s(g, f, m, v) {
      this.type = g, this.content = f, this.alias = m, this.length = (v || "").length | 0;
    }
    s.stringify = function g(f, m) {
      if (typeof f == "string")
        return f;
      if (Array.isArray(f)) {
        var v = "";
        return f.forEach(function(w) {
          v += g(w, m);
        }), v;
      }
      var p = {
        type: f.type,
        content: g(f.content, m),
        tag: "span",
        classes: ["token", f.type],
        attributes: {},
        language: m
      }, b = f.alias;
      b && (Array.isArray(b) ? Array.prototype.push.apply(p.classes, b) : p.classes.push(b)), o.hooks.run("wrap", p);
      var k = "";
      for (var y in p.attributes)
        k += " " + y + '="' + (p.attributes[y] || "").replace(/"/g, "&quot;") + '"';
      return "<" + p.tag + ' class="' + p.classes.join(" ") + '"' + k + ">" + p.content + "</" + p.tag + ">";
    };
    function u(g, f, m, v) {
      g.lastIndex = f;
      var p = g.exec(m);
      if (p && v && p[1]) {
        var b = p[1].length;
        p.index += b, p[0] = p[0].slice(b);
      }
      return p;
    }
    function c(g, f, m, v, p, b) {
      for (var k in m)
        if (!(!m.hasOwnProperty(k) || !m[k])) {
          var y = m[k];
          y = Array.isArray(y) ? y : [y];
          for (var w = 0; w < y.length; ++w) {
            if (b && b.cause == k + "," + w)
              return;
            var A = y[w], B = A.inside, N = !!A.lookbehind, L = !!A.greedy, R = A.alias;
            if (L && !A.pattern.global) {
              var M = A.pattern.toString().match(/[imsuy]*$/)[0];
              A.pattern = RegExp(A.pattern.source, M + "g");
            }
            for (var J = A.pattern || A, V = v.next, T = p; V !== f.tail && !(b && T >= b.reach); T += V.value.length, V = V.next) {
              var ee = V.value;
              if (f.length > g.length)
                return;
              if (!(ee instanceof s)) {
                var x = 1, te;
                if (L) {
                  if (te = u(J, T, g, N), !te || te.index >= g.length)
                    break;
                  var Re = te.index, pe = te.index + te[0].length, $ = T;
                  for ($ += V.value.length; Re >= $; )
                    V = V.next, $ += V.value.length;
                  if ($ -= V.value.length, T = $, V.value instanceof s)
                    continue;
                  for (var I = V; I !== f.tail && ($ < pe || typeof I.value == "string"); I = I.next)
                    x++, $ += I.value.length;
                  x--, ee = g.slice(T, $), te.index -= T;
                } else if (te = u(J, 0, ee, N), !te)
                  continue;
                var Re = te.index, tt = te[0], lt = ee.slice(0, Re), pt = ee.slice(Re + tt.length), ot = T + ee.length;
                b && ot > b.reach && (b.reach = ot);
                var H = V.prev;
                lt && (H = h(f, H, lt), T += lt.length), d(f, H, x);
                var cn = new s(k, B ? o.tokenize(tt, B) : tt, R, tt);
                if (V = h(f, H, cn), pt && h(f, V, pt), x > 1) {
                  var st = {
                    cause: k + "," + w,
                    reach: ot
                  };
                  c(g, f, m, V.prev, T, st), b && st.reach > b.reach && (b.reach = st.reach);
                }
              }
            }
          }
        }
    }
    function _() {
      var g = { value: null, prev: null, next: null }, f = { value: null, prev: g, next: null };
      g.next = f, this.head = g, this.tail = f, this.length = 0;
    }
    function h(g, f, m) {
      var v = f.next, p = { value: m, prev: f, next: v };
      return f.next = p, v.prev = p, g.length++, p;
    }
    function d(g, f, m) {
      for (var v = f.next, p = 0; p < m && v !== g.tail; p++)
        v = v.next;
      f.next = v, v.prev = f, g.length -= p;
    }
    function D(g) {
      for (var f = [], m = g.head.next; m !== g.tail; )
        f.push(m.value), m = m.next;
      return f;
    }
    if (!i.document)
      return i.addEventListener && (o.disableWorkerMessageHandler || i.addEventListener("message", function(g) {
        var f = JSON.parse(g.data), m = f.language, v = f.code, p = f.immediateClose;
        i.postMessage(o.highlight(v, o.languages[m], m)), p && i.close();
      }, !1)), o;
    var E = o.util.currentScript();
    E && (o.filename = E.src, E.hasAttribute("data-manual") && (o.manual = !0));
    function F() {
      o.manual || o.highlightAll();
    }
    if (!o.manual) {
      var C = document.readyState;
      C === "loading" || C === "interactive" && E && E.defer ? document.addEventListener("DOMContentLoaded", F) : window.requestAnimationFrame ? window.requestAnimationFrame(F) : window.setTimeout(F, 16);
    }
    return o;
  }(e);
  t.exports && (t.exports = n), typeof Zr < "u" && (Zr.Prism = n), n.languages.markup = {
    comment: {
      pattern: /<!--(?:(?!<!--)[\s\S])*?-->/,
      greedy: !0
    },
    prolog: {
      pattern: /<\?[\s\S]+?\?>/,
      greedy: !0
    },
    doctype: {
      // https://www.w3.org/TR/xml/#NT-doctypedecl
      pattern: /<!DOCTYPE(?:[^>"'[\]]|"[^"]*"|'[^']*')+(?:\[(?:[^<"'\]]|"[^"]*"|'[^']*'|<(?!!--)|<!--(?:[^-]|-(?!->))*-->)*\]\s*)?>/i,
      greedy: !0,
      inside: {
        "internal-subset": {
          pattern: /(^[^\[]*\[)[\s\S]+(?=\]>$)/,
          lookbehind: !0,
          greedy: !0,
          inside: null
          // see below
        },
        string: {
          pattern: /"[^"]*"|'[^']*'/,
          greedy: !0
        },
        punctuation: /^<!|>$|[[\]]/,
        "doctype-tag": /^DOCTYPE/i,
        name: /[^\s<>'"]+/
      }
    },
    cdata: {
      pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
      greedy: !0
    },
    tag: {
      pattern: /<\/?(?!\d)[^\s>\/=$<%]+(?:\s(?:\s*[^\s>\/=]+(?:\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))|(?=[\s/>])))+)?\s*\/?>/,
      greedy: !0,
      inside: {
        tag: {
          pattern: /^<\/?[^\s>\/]+/,
          inside: {
            punctuation: /^<\/?/,
            namespace: /^[^\s>\/:]+:/
          }
        },
        "special-attr": [],
        "attr-value": {
          pattern: /=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+)/,
          inside: {
            punctuation: [
              {
                pattern: /^=/,
                alias: "attr-equals"
              },
              {
                pattern: /^(\s*)["']|["']$/,
                lookbehind: !0
              }
            ]
          }
        },
        punctuation: /\/?>/,
        "attr-name": {
          pattern: /[^\s>\/]+/,
          inside: {
            namespace: /^[^\s>\/:]+:/
          }
        }
      }
    },
    entity: [
      {
        pattern: /&[\da-z]{1,8};/i,
        alias: "named-entity"
      },
      /&#x?[\da-f]{1,8};/i
    ]
  }, n.languages.markup.tag.inside["attr-value"].inside.entity = n.languages.markup.entity, n.languages.markup.doctype.inside["internal-subset"].inside = n.languages.markup, n.hooks.add("wrap", function(i) {
    i.type === "entity" && (i.attributes.title = i.content.replace(/&amp;/, "&"));
  }), Object.defineProperty(n.languages.markup.tag, "addInlined", {
    /**
     * Adds an inlined language to markup.
     *
     * An example of an inlined language is CSS with `<style>` tags.
     *
     * @param {string} tagName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addInlined('style', 'css');
     */
    value: function(r, l) {
      var a = {};
      a["language-" + l] = {
        pattern: /(^<!\[CDATA\[)[\s\S]+?(?=\]\]>$)/i,
        lookbehind: !0,
        inside: n.languages[l]
      }, a.cdata = /^<!\[CDATA\[|\]\]>$/i;
      var o = {
        "included-cdata": {
          pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
          inside: a
        }
      };
      o["language-" + l] = {
        pattern: /[\s\S]+/,
        inside: n.languages[l]
      };
      var s = {};
      s[r] = {
        pattern: RegExp(/(<__[^>]*>)(?:<!\[CDATA\[(?:[^\]]|\](?!\]>))*\]\]>|(?!<!\[CDATA\[)[\s\S])*?(?=<\/__>)/.source.replace(/__/g, function() {
          return r;
        }), "i"),
        lookbehind: !0,
        greedy: !0,
        inside: o
      }, n.languages.insertBefore("markup", "cdata", s);
    }
  }), Object.defineProperty(n.languages.markup.tag, "addAttribute", {
    /**
     * Adds an pattern to highlight languages embedded in HTML attributes.
     *
     * An example of an inlined language is CSS with `style` attributes.
     *
     * @param {string} attrName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addAttribute('style', 'css');
     */
    value: function(i, r) {
      n.languages.markup.tag.inside["special-attr"].push({
        pattern: RegExp(
          /(^|["'\s])/.source + "(?:" + i + ")" + /\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))/.source,
          "i"
        ),
        lookbehind: !0,
        inside: {
          "attr-name": /^[^\s=]+/,
          "attr-value": {
            pattern: /=[\s\S]+/,
            inside: {
              value: {
                pattern: /(^=\s*(["']|(?!["'])))\S[\s\S]*(?=\2$)/,
                lookbehind: !0,
                alias: [r, "language-" + r],
                inside: n.languages[r]
              },
              punctuation: [
                {
                  pattern: /^=/,
                  alias: "attr-equals"
                },
                /"|'/
              ]
            }
          }
        }
      });
    }
  }), n.languages.html = n.languages.markup, n.languages.mathml = n.languages.markup, n.languages.svg = n.languages.markup, n.languages.xml = n.languages.extend("markup", {}), n.languages.ssml = n.languages.xml, n.languages.atom = n.languages.xml, n.languages.rss = n.languages.xml, function(i) {
    var r = /(?:"(?:\\(?:\r\n|[\s\S])|[^"\\\r\n])*"|'(?:\\(?:\r\n|[\s\S])|[^'\\\r\n])*')/;
    i.languages.css = {
      comment: /\/\*[\s\S]*?\*\//,
      atrule: {
        pattern: RegExp("@[\\w-](?:" + /[^;{\s"']|\s+(?!\s)/.source + "|" + r.source + ")*?" + /(?:;|(?=\s*\{))/.source),
        inside: {
          rule: /^@[\w-]+/,
          "selector-function-argument": {
            pattern: /(\bselector\s*\(\s*(?![\s)]))(?:[^()\s]|\s+(?![\s)])|\((?:[^()]|\([^()]*\))*\))+(?=\s*\))/,
            lookbehind: !0,
            alias: "selector"
          },
          keyword: {
            pattern: /(^|[^\w-])(?:and|not|only|or)(?![\w-])/,
            lookbehind: !0
          }
          // See rest below
        }
      },
      url: {
        // https://drafts.csswg.org/css-values-3/#urls
        pattern: RegExp("\\burl\\((?:" + r.source + "|" + /(?:[^\\\r\n()"']|\\[\s\S])*/.source + ")\\)", "i"),
        greedy: !0,
        inside: {
          function: /^url/i,
          punctuation: /^\(|\)$/,
          string: {
            pattern: RegExp("^" + r.source + "$"),
            alias: "url"
          }
        }
      },
      selector: {
        pattern: RegExp(`(^|[{}\\s])[^{}\\s](?:[^{};"'\\s]|\\s+(?![\\s{])|` + r.source + ")*(?=\\s*\\{)"),
        lookbehind: !0
      },
      string: {
        pattern: r,
        greedy: !0
      },
      property: {
        pattern: /(^|[^-\w\xA0-\uFFFF])(?!\s)[-_a-z\xA0-\uFFFF](?:(?!\s)[-\w\xA0-\uFFFF])*(?=\s*:)/i,
        lookbehind: !0
      },
      important: /!important\b/i,
      function: {
        pattern: /(^|[^-a-z0-9])[-a-z0-9]+(?=\()/i,
        lookbehind: !0
      },
      punctuation: /[(){};:,]/
    }, i.languages.css.atrule.inside.rest = i.languages.css;
    var l = i.languages.markup;
    l && (l.tag.addInlined("style", "css"), l.tag.addAttribute("style", "css"));
  }(n), n.languages.clike = {
    comment: [
      {
        pattern: /(^|[^\\])\/\*[\s\S]*?(?:\*\/|$)/,
        lookbehind: !0,
        greedy: !0
      },
      {
        pattern: /(^|[^\\:])\/\/.*/,
        lookbehind: !0,
        greedy: !0
      }
    ],
    string: {
      pattern: /(["'])(?:\\(?:\r\n|[\s\S])|(?!\1)[^\\\r\n])*\1/,
      greedy: !0
    },
    "class-name": {
      pattern: /(\b(?:class|extends|implements|instanceof|interface|new|trait)\s+|\bcatch\s+\()[\w.\\]+/i,
      lookbehind: !0,
      inside: {
        punctuation: /[.\\]/
      }
    },
    keyword: /\b(?:break|catch|continue|do|else|finally|for|function|if|in|instanceof|new|null|return|throw|try|while)\b/,
    boolean: /\b(?:false|true)\b/,
    function: /\b\w+(?=\()/,
    number: /\b0x[\da-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:e[+-]?\d+)?/i,
    operator: /[<>]=?|[!=]=?=?|--?|\+\+?|&&?|\|\|?|[?*/~^%]/,
    punctuation: /[{}[\];(),.:]/
  }, n.languages.javascript = n.languages.extend("clike", {
    "class-name": [
      n.languages.clike["class-name"],
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$A-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\.(?:constructor|prototype))/,
        lookbehind: !0
      }
    ],
    keyword: [
      {
        pattern: /((?:^|\})\s*)catch\b/,
        lookbehind: !0
      },
      {
        pattern: /(^|[^.]|\.\.\.\s*)\b(?:as|assert(?=\s*\{)|async(?=\s*(?:function\b|\(|[$\w\xA0-\uFFFF]|$))|await|break|case|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally(?=\s*(?:\{|$))|for|from(?=\s*(?:['"]|$))|function|(?:get|set)(?=\s*(?:[#\[$\w\xA0-\uFFFF]|$))|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)\b/,
        lookbehind: !0
      }
    ],
    // Allow for all non-ASCII characters (See http://stackoverflow.com/a/2008444)
    function: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*(?:\.\s*(?:apply|bind|call)\s*)?\()/,
    number: {
      pattern: RegExp(
        /(^|[^\w$])/.source + "(?:" + // constant
        (/NaN|Infinity/.source + "|" + // binary integer
        /0[bB][01]+(?:_[01]+)*n?/.source + "|" + // octal integer
        /0[oO][0-7]+(?:_[0-7]+)*n?/.source + "|" + // hexadecimal integer
        /0[xX][\dA-Fa-f]+(?:_[\dA-Fa-f]+)*n?/.source + "|" + // decimal bigint
        /\d+(?:_\d+)*n/.source + "|" + // decimal number (integer or float) but no bigint
        /(?:\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\.\d+(?:_\d+)*)(?:[Ee][+-]?\d+(?:_\d+)*)?/.source) + ")" + /(?![\w$])/.source
      ),
      lookbehind: !0
    },
    operator: /--|\+\+|\*\*=?|=>|&&=?|\|\|=?|[!=]==|<<=?|>>>?=?|[-+*/%&|^!=<>]=?|\.{3}|\?\?=?|\?\.?|[~:]/
  }), n.languages.javascript["class-name"][0].pattern = /(\b(?:class|extends|implements|instanceof|interface|new)\s+)[\w.\\]+/, n.languages.insertBefore("javascript", "keyword", {
    regex: {
      pattern: RegExp(
        // lookbehind
        // eslint-disable-next-line regexp/no-dupe-characters-character-class
        /((?:^|[^$\w\xA0-\uFFFF."'\])\s]|\b(?:return|yield))\s*)/.source + // Regex pattern:
        // There are 2 regex patterns here. The RegExp set notation proposal added support for nested character
        // classes if the `v` flag is present. Unfortunately, nested CCs are both context-free and incompatible
        // with the only syntax, so we have to define 2 different regex patterns.
        /\//.source + "(?:" + /(?:\[(?:[^\]\\\r\n]|\\.)*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}/.source + "|" + // `v` flag syntax. This supports 3 levels of nested character classes.
        /(?:\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.)*\])*\])*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}v[dgimyus]{0,7}/.source + ")" + // lookahead
        /(?=(?:\s|\/\*(?:[^*]|\*(?!\/))*\*\/)*(?:$|[\r\n,.;:})\]]|\/\/))/.source
      ),
      lookbehind: !0,
      greedy: !0,
      inside: {
        "regex-source": {
          pattern: /^(\/)[\s\S]+(?=\/[a-z]*$)/,
          lookbehind: !0,
          alias: "language-regex",
          inside: n.languages.regex
        },
        "regex-delimiter": /^\/|\/$/,
        "regex-flags": /^[a-z]+$/
      }
    },
    // This must be declared before keyword because we use "function" inside the look-forward
    "function-variable": {
      pattern: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*[=:]\s*(?:async\s*)?(?:\bfunction\b|(?:\((?:[^()]|\([^()]*\))*\)|(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)\s*=>))/,
      alias: "function"
    },
    parameter: [
      {
        pattern: /(function(?:\s+(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)?\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\))/,
        lookbehind: !0,
        inside: n.languages.javascript
      },
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$a-z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*=>)/i,
        lookbehind: !0,
        inside: n.languages.javascript
      },
      {
        pattern: /(\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*=>)/,
        lookbehind: !0,
        inside: n.languages.javascript
      },
      {
        pattern: /((?:\b|\s|^)(?!(?:as|async|await|break|case|catch|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally|for|from|function|get|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|set|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)(?![$\w\xA0-\uFFFF]))(?:(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*\s*)\(\s*|\]\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*\{)/,
        lookbehind: !0,
        inside: n.languages.javascript
      }
    ],
    constant: /\b[A-Z](?:[A-Z_]|\dx?)*\b/
  }), n.languages.insertBefore("javascript", "string", {
    hashbang: {
      pattern: /^#!.*/,
      greedy: !0,
      alias: "comment"
    },
    "template-string": {
      pattern: /`(?:\\[\s\S]|\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}|(?!\$\{)[^\\`])*`/,
      greedy: !0,
      inside: {
        "template-punctuation": {
          pattern: /^`|`$/,
          alias: "string"
        },
        interpolation: {
          pattern: /((?:^|[^\\])(?:\\{2})*)\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}/,
          lookbehind: !0,
          inside: {
            "interpolation-punctuation": {
              pattern: /^\$\{|\}$/,
              alias: "punctuation"
            },
            rest: n.languages.javascript
          }
        },
        string: /[\s\S]+/
      }
    },
    "string-property": {
      pattern: /((?:^|[,{])[ \t]*)(["'])(?:\\(?:\r\n|[\s\S])|(?!\2)[^\\\r\n])*\2(?=\s*:)/m,
      lookbehind: !0,
      greedy: !0,
      alias: "property"
    }
  }), n.languages.insertBefore("javascript", "operator", {
    "literal-property": {
      pattern: /((?:^|[,{])[ \t]*)(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*:)/m,
      lookbehind: !0,
      alias: "property"
    }
  }), n.languages.markup && (n.languages.markup.tag.addInlined("script", "javascript"), n.languages.markup.tag.addAttribute(
    /on(?:abort|blur|change|click|composition(?:end|start|update)|dblclick|error|focus(?:in|out)?|key(?:down|up)|load|mouse(?:down|enter|leave|move|out|over|up)|reset|resize|scroll|select|slotchange|submit|unload|wheel)/.source,
    "javascript"
  )), n.languages.js = n.languages.javascript, function() {
    if (typeof n > "u" || typeof document > "u")
      return;
    Element.prototype.matches || (Element.prototype.matches = Element.prototype.msMatchesSelector || Element.prototype.webkitMatchesSelector);
    var i = "Loading…", r = function(E, F) {
      return "✖ Error " + E + " while fetching file: " + F;
    }, l = "✖ Error: File does not exist or is empty", a = {
      js: "javascript",
      py: "python",
      rb: "ruby",
      ps1: "powershell",
      psm1: "powershell",
      sh: "bash",
      bat: "batch",
      h: "c",
      tex: "latex"
    }, o = "data-src-status", s = "loading", u = "loaded", c = "failed", _ = "pre[data-src]:not([" + o + '="' + u + '"]):not([' + o + '="' + s + '"])';
    function h(E, F, C) {
      var g = new XMLHttpRequest();
      g.open("GET", E, !0), g.onreadystatechange = function() {
        g.readyState == 4 && (g.status < 400 && g.responseText ? F(g.responseText) : g.status >= 400 ? C(r(g.status, g.statusText)) : C(l));
      }, g.send(null);
    }
    function d(E) {
      var F = /^\s*(\d+)\s*(?:(,)\s*(?:(\d+)\s*)?)?$/.exec(E || "");
      if (F) {
        var C = Number(F[1]), g = F[2], f = F[3];
        return g ? f ? [C, Number(f)] : [C, void 0] : [C, C];
      }
    }
    n.hooks.add("before-highlightall", function(E) {
      E.selector += ", " + _;
    }), n.hooks.add("before-sanity-check", function(E) {
      var F = (
        /** @type {HTMLPreElement} */
        E.element
      );
      if (F.matches(_)) {
        E.code = "", F.setAttribute(o, s);
        var C = F.appendChild(document.createElement("CODE"));
        C.textContent = i;
        var g = F.getAttribute("data-src"), f = E.language;
        if (f === "none") {
          var m = (/\.(\w+)$/.exec(g) || [, "none"])[1];
          f = a[m] || m;
        }
        n.util.setLanguage(C, f), n.util.setLanguage(F, f);
        var v = n.plugins.autoloader;
        v && v.loadLanguages(f), h(
          g,
          function(p) {
            F.setAttribute(o, u);
            var b = d(F.getAttribute("data-range"));
            if (b) {
              var k = p.split(/\r\n?|\n/g), y = b[0], w = b[1] == null ? k.length : b[1];
              y < 0 && (y += k.length), y = Math.max(0, Math.min(y - 1, k.length)), w < 0 && (w += k.length), w = Math.max(0, Math.min(w, k.length)), p = k.slice(y, w).join(`
`), F.hasAttribute("data-start") || F.setAttribute("data-start", String(y + 1));
            }
            C.textContent = p, n.highlightElement(C);
          },
          function(p) {
            F.setAttribute(o, c), C.textContent = p;
          }
        );
      }
    }), n.plugins.fileHighlight = {
      /**
       * Executes the File Highlight plugin for all matching `pre` elements under the given container.
       *
       * Note: Elements which are already loaded or currently loading will not be touched by this method.
       *
       * @param {ParentNode} [container=document]
       */
      highlight: function(F) {
        for (var C = (F || document).querySelectorAll(_), g = 0, f; f = C[g++]; )
          n.highlightElement(f);
      }
    };
    var D = !1;
    n.fileHighlight = function() {
      D || (console.warn("Prism.fileHighlight is deprecated. Use `Prism.plugins.fileHighlight.highlight` instead."), D = !0), n.plugins.fileHighlight.highlight.apply(this, arguments);
    };
  }();
})(oo);
var hi = oo.exports;
Prism.languages.python = {
  comment: {
    pattern: /(^|[^\\])#.*/,
    lookbehind: !0,
    greedy: !0
  },
  "string-interpolation": {
    pattern: /(?:f|fr|rf)(?:("""|''')[\s\S]*?\1|("|')(?:\\.|(?!\2)[^\\\r\n])*\2)/i,
    greedy: !0,
    inside: {
      interpolation: {
        // "{" <expression> <optional "!s", "!r", or "!a"> <optional ":" format specifier> "}"
        pattern: /((?:^|[^{])(?:\{\{)*)\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}])+\})+\})+\}/,
        lookbehind: !0,
        inside: {
          "format-spec": {
            pattern: /(:)[^:(){}]+(?=\}$)/,
            lookbehind: !0
          },
          "conversion-option": {
            pattern: /![sra](?=[:}]$)/,
            alias: "punctuation"
          },
          rest: null
        }
      },
      string: /[\s\S]+/
    }
  },
  "triple-quoted-string": {
    pattern: /(?:[rub]|br|rb)?("""|''')[\s\S]*?\1/i,
    greedy: !0,
    alias: "string"
  },
  string: {
    pattern: /(?:[rub]|br|rb)?("|')(?:\\.|(?!\1)[^\\\r\n])*\1/i,
    greedy: !0
  },
  function: {
    pattern: /((?:^|\s)def[ \t]+)[a-zA-Z_]\w*(?=\s*\()/g,
    lookbehind: !0
  },
  "class-name": {
    pattern: /(\bclass\s+)\w+/i,
    lookbehind: !0
  },
  decorator: {
    pattern: /(^[\t ]*)@\w+(?:\.\w+)*/m,
    lookbehind: !0,
    alias: ["annotation", "punctuation"],
    inside: {
      punctuation: /\./
    }
  },
  keyword: /\b(?:_(?=\s*:)|and|as|assert|async|await|break|case|class|continue|def|del|elif|else|except|exec|finally|for|from|global|if|import|in|is|lambda|match|nonlocal|not|or|pass|print|raise|return|try|while|with|yield)\b/,
  builtin: /\b(?:__import__|abs|all|any|apply|ascii|basestring|bin|bool|buffer|bytearray|bytes|callable|chr|classmethod|cmp|coerce|compile|complex|delattr|dict|dir|divmod|enumerate|eval|execfile|file|filter|float|format|frozenset|getattr|globals|hasattr|hash|help|hex|id|input|int|intern|isinstance|issubclass|iter|len|list|locals|long|map|max|memoryview|min|next|object|oct|open|ord|pow|property|range|raw_input|reduce|reload|repr|reversed|round|set|setattr|slice|sorted|staticmethod|str|sum|super|tuple|type|unichr|unicode|vars|xrange|zip)\b/,
  boolean: /\b(?:False|None|True)\b/,
  number: /\b0(?:b(?:_?[01])+|o(?:_?[0-7])+|x(?:_?[a-f0-9])+)\b|(?:\b\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\B\.\d+(?:_\d+)*)(?:e[+-]?\d+(?:_\d+)*)?j?(?!\w)/i,
  operator: /[-+%=]=?|!=|:=|\*\*?=?|\/\/?=?|<[<=>]?|>[=>]?|[&|^~]/,
  punctuation: /[{}[\];(),.:]/
};
Prism.languages.python["string-interpolation"].inside.interpolation.inside.rest = Prism.languages.python;
Prism.languages.py = Prism.languages.python;
(function(t) {
  var e = /\\(?:[^a-z()[\]]|[a-z*]+)/i, n = {
    "equation-command": {
      pattern: e,
      alias: "regex"
    }
  };
  t.languages.latex = {
    comment: /%.*/,
    // the verbatim environment prints whitespace to the document
    cdata: {
      pattern: /(\\begin\{((?:lstlisting|verbatim)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
      lookbehind: !0
    },
    /*
     * equations can be between $$ $$ or $ $ or \( \) or \[ \]
     * (all are multiline)
     */
    equation: [
      {
        pattern: /\$\$(?:\\[\s\S]|[^\\$])+\$\$|\$(?:\\[\s\S]|[^\\$])+\$|\\\([\s\S]*?\\\)|\\\[[\s\S]*?\\\]/,
        inside: n,
        alias: "string"
      },
      {
        pattern: /(\\begin\{((?:align|eqnarray|equation|gather|math|multline)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
        lookbehind: !0,
        inside: n,
        alias: "string"
      }
    ],
    /*
     * arguments which are keywords or references are highlighted
     * as keywords
     */
    keyword: {
      pattern: /(\\(?:begin|cite|documentclass|end|label|ref|usepackage)(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    url: {
      pattern: /(\\url\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    /*
     * section or chapter headlines are highlighted as bold so that
     * they stand out more
     */
    headline: {
      pattern: /(\\(?:chapter|frametitle|paragraph|part|section|subparagraph|subsection|subsubparagraph|subsubsection|subsubsubparagraph)\*?(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0,
      alias: "class-name"
    },
    function: {
      pattern: e,
      alias: "selector"
    },
    punctuation: /[[\]{}&]/
  }, t.languages.tex = t.languages.latex, t.languages.context = t.languages.latex;
})(Prism);
(function(t) {
  var e = "\\b(?:BASH|BASHOPTS|BASH_ALIASES|BASH_ARGC|BASH_ARGV|BASH_CMDS|BASH_COMPLETION_COMPAT_DIR|BASH_LINENO|BASH_REMATCH|BASH_SOURCE|BASH_VERSINFO|BASH_VERSION|COLORTERM|COLUMNS|COMP_WORDBREAKS|DBUS_SESSION_BUS_ADDRESS|DEFAULTS_PATH|DESKTOP_SESSION|DIRSTACK|DISPLAY|EUID|GDMSESSION|GDM_LANG|GNOME_KEYRING_CONTROL|GNOME_KEYRING_PID|GPG_AGENT_INFO|GROUPS|HISTCONTROL|HISTFILE|HISTFILESIZE|HISTSIZE|HOME|HOSTNAME|HOSTTYPE|IFS|INSTANCE|JOB|LANG|LANGUAGE|LC_ADDRESS|LC_ALL|LC_IDENTIFICATION|LC_MEASUREMENT|LC_MONETARY|LC_NAME|LC_NUMERIC|LC_PAPER|LC_TELEPHONE|LC_TIME|LESSCLOSE|LESSOPEN|LINES|LOGNAME|LS_COLORS|MACHTYPE|MAILCHECK|MANDATORY_PATH|NO_AT_BRIDGE|OLDPWD|OPTERR|OPTIND|ORBIT_SOCKETDIR|OSTYPE|PAPERSIZE|PATH|PIPESTATUS|PPID|PS1|PS2|PS3|PS4|PWD|RANDOM|REPLY|SECONDS|SELINUX_INIT|SESSION|SESSIONTYPE|SESSION_MANAGER|SHELL|SHELLOPTS|SHLVL|SSH_AUTH_SOCK|TERM|UID|UPSTART_EVENTS|UPSTART_INSTANCE|UPSTART_JOB|UPSTART_SESSION|USER|WINDOWID|XAUTHORITY|XDG_CONFIG_DIRS|XDG_CURRENT_DESKTOP|XDG_DATA_DIRS|XDG_GREETER_DATA_DIR|XDG_MENU_PREFIX|XDG_RUNTIME_DIR|XDG_SEAT|XDG_SEAT_PATH|XDG_SESSION_DESKTOP|XDG_SESSION_ID|XDG_SESSION_PATH|XDG_SESSION_TYPE|XDG_VTNR|XMODIFIERS)\\b", n = {
    pattern: /(^(["']?)\w+\2)[ \t]+\S.*/,
    lookbehind: !0,
    alias: "punctuation",
    // this looks reasonably well in all themes
    inside: null
    // see below
  }, i = {
    bash: n,
    environment: {
      pattern: RegExp("\\$" + e),
      alias: "constant"
    },
    variable: [
      // [0]: Arithmetic Environment
      {
        pattern: /\$?\(\([\s\S]+?\)\)/,
        greedy: !0,
        inside: {
          // If there is a $ sign at the beginning highlight $(( and )) as variable
          variable: [
            {
              pattern: /(^\$\(\([\s\S]+)\)\)/,
              lookbehind: !0
            },
            /^\$\(\(/
          ],
          number: /\b0x[\dA-Fa-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:[Ee]-?\d+)?/,
          // Operators according to https://www.gnu.org/software/bash/manual/bashref.html#Shell-Arithmetic
          operator: /--|\+\+|\*\*=?|<<=?|>>=?|&&|\|\||[=!+\-*/%<>^&|]=?|[?~:]/,
          // If there is no $ sign at the beginning highlight (( and )) as punctuation
          punctuation: /\(\(?|\)\)?|,|;/
        }
      },
      // [1]: Command Substitution
      {
        pattern: /\$\((?:\([^)]+\)|[^()])+\)|`[^`]+`/,
        greedy: !0,
        inside: {
          variable: /^\$\(|^`|\)$|`$/
        }
      },
      // [2]: Brace expansion
      {
        pattern: /\$\{[^}]+\}/,
        greedy: !0,
        inside: {
          operator: /:[-=?+]?|[!\/]|##?|%%?|\^\^?|,,?/,
          punctuation: /[\[\]]/,
          environment: {
            pattern: RegExp("(\\{)" + e),
            lookbehind: !0,
            alias: "constant"
          }
        }
      },
      /\$(?:\w+|[#?*!@$])/
    ],
    // Escape sequences from echo and printf's manuals, and escaped quotes.
    entity: /\\(?:[abceEfnrtv\\"]|O?[0-7]{1,3}|U[0-9a-fA-F]{8}|u[0-9a-fA-F]{4}|x[0-9a-fA-F]{1,2})/
  };
  t.languages.bash = {
    shebang: {
      pattern: /^#!\s*\/.*/,
      alias: "important"
    },
    comment: {
      pattern: /(^|[^"{\\$])#.*/,
      lookbehind: !0
    },
    "function-name": [
      // a) function foo {
      // b) foo() {
      // c) function foo() {
      // but not “foo {”
      {
        // a) and c)
        pattern: /(\bfunction\s+)[\w-]+(?=(?:\s*\(?:\s*\))?\s*\{)/,
        lookbehind: !0,
        alias: "function"
      },
      {
        // b)
        pattern: /\b[\w-]+(?=\s*\(\s*\)\s*\{)/,
        alias: "function"
      }
    ],
    // Highlight variable names as variables in for and select beginnings.
    "for-or-select": {
      pattern: /(\b(?:for|select)\s+)\w+(?=\s+in\s)/,
      alias: "variable",
      lookbehind: !0
    },
    // Highlight variable names as variables in the left-hand part
    // of assignments (“=” and “+=”).
    "assign-left": {
      pattern: /(^|[\s;|&]|[<>]\()\w+(?:\.\w+)*(?=\+?=)/,
      inside: {
        environment: {
          pattern: RegExp("(^|[\\s;|&]|[<>]\\()" + e),
          lookbehind: !0,
          alias: "constant"
        }
      },
      alias: "variable",
      lookbehind: !0
    },
    // Highlight parameter names as variables
    parameter: {
      pattern: /(^|\s)-{1,2}(?:\w+:[+-]?)?\w+(?:\.\w+)*(?=[=\s]|$)/,
      alias: "variable",
      lookbehind: !0
    },
    string: [
      // Support for Here-documents https://en.wikipedia.org/wiki/Here_document
      {
        pattern: /((?:^|[^<])<<-?\s*)(\w+)\s[\s\S]*?(?:\r?\n|\r)\2/,
        lookbehind: !0,
        greedy: !0,
        inside: i
      },
      // Here-document with quotes around the tag
      // → No expansion (so no “inside”).
      {
        pattern: /((?:^|[^<])<<-?\s*)(["'])(\w+)\2\s[\s\S]*?(?:\r?\n|\r)\3/,
        lookbehind: !0,
        greedy: !0,
        inside: {
          bash: n
        }
      },
      // “Normal” string
      {
        // https://www.gnu.org/software/bash/manual/html_node/Double-Quotes.html
        pattern: /(^|[^\\](?:\\\\)*)"(?:\\[\s\S]|\$\([^)]+\)|\$(?!\()|`[^`]+`|[^"\\`$])*"/,
        lookbehind: !0,
        greedy: !0,
        inside: i
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/Single-Quotes.html
        pattern: /(^|[^$\\])'[^']*'/,
        lookbehind: !0,
        greedy: !0
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/ANSI_002dC-Quoting.html
        pattern: /\$'(?:[^'\\]|\\[\s\S])*'/,
        greedy: !0,
        inside: {
          entity: i.entity
        }
      }
    ],
    environment: {
      pattern: RegExp("\\$?" + e),
      alias: "constant"
    },
    variable: i.variable,
    function: {
      pattern: /(^|[\s;|&]|[<>]\()(?:add|apropos|apt|apt-cache|apt-get|aptitude|aspell|automysqlbackup|awk|basename|bash|bc|bconsole|bg|bzip2|cal|cargo|cat|cfdisk|chgrp|chkconfig|chmod|chown|chroot|cksum|clear|cmp|column|comm|composer|cp|cron|crontab|csplit|curl|cut|date|dc|dd|ddrescue|debootstrap|df|diff|diff3|dig|dir|dircolors|dirname|dirs|dmesg|docker|docker-compose|du|egrep|eject|env|ethtool|expand|expect|expr|fdformat|fdisk|fg|fgrep|file|find|fmt|fold|format|free|fsck|ftp|fuser|gawk|git|gparted|grep|groupadd|groupdel|groupmod|groups|grub-mkconfig|gzip|halt|head|hg|history|host|hostname|htop|iconv|id|ifconfig|ifdown|ifup|import|install|ip|java|jobs|join|kill|killall|less|link|ln|locate|logname|logrotate|look|lpc|lpr|lprint|lprintd|lprintq|lprm|ls|lsof|lynx|make|man|mc|mdadm|mkconfig|mkdir|mke2fs|mkfifo|mkfs|mkisofs|mknod|mkswap|mmv|more|most|mount|mtools|mtr|mutt|mv|nano|nc|netstat|nice|nl|node|nohup|notify-send|npm|nslookup|op|open|parted|passwd|paste|pathchk|ping|pkill|pnpm|podman|podman-compose|popd|pr|printcap|printenv|ps|pushd|pv|quota|quotacheck|quotactl|ram|rar|rcp|reboot|remsync|rename|renice|rev|rm|rmdir|rpm|rsync|scp|screen|sdiff|sed|sendmail|seq|service|sftp|sh|shellcheck|shuf|shutdown|sleep|slocate|sort|split|ssh|stat|strace|su|sudo|sum|suspend|swapon|sync|sysctl|tac|tail|tar|tee|time|timeout|top|touch|tr|traceroute|tsort|tty|umount|uname|unexpand|uniq|units|unrar|unshar|unzip|update-grub|uptime|useradd|userdel|usermod|users|uudecode|uuencode|v|vcpkg|vdir|vi|vim|virsh|vmstat|wait|watch|wc|wget|whereis|which|who|whoami|write|xargs|xdg-open|yarn|yes|zenity|zip|zsh|zypper)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    keyword: {
      pattern: /(^|[\s;|&]|[<>]\()(?:case|do|done|elif|else|esac|fi|for|function|if|in|select|then|until|while)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    // https://www.gnu.org/software/bash/manual/html_node/Shell-Builtin-Commands.html
    builtin: {
      pattern: /(^|[\s;|&]|[<>]\()(?:\.|:|alias|bind|break|builtin|caller|cd|command|continue|declare|echo|enable|eval|exec|exit|export|getopts|hash|help|let|local|logout|mapfile|printf|pwd|read|readarray|readonly|return|set|shift|shopt|source|test|times|trap|type|typeset|ulimit|umask|unalias|unset)(?=$|[)\s;|&])/,
      lookbehind: !0,
      // Alias added to make those easier to distinguish from strings.
      alias: "class-name"
    },
    boolean: {
      pattern: /(^|[\s;|&]|[<>]\()(?:false|true)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    "file-descriptor": {
      pattern: /\B&\d\b/,
      alias: "important"
    },
    operator: {
      // Lots of redirections here, but not just that.
      pattern: /\d?<>|>\||\+=|=[=~]?|!=?|<<[<-]?|[&\d]?>>|\d[<>]&?|[<>][&=]?|&[>&]?|\|[&|]?/,
      inside: {
        "file-descriptor": {
          pattern: /^\d/,
          alias: "important"
        }
      }
    },
    punctuation: /\$?\(\(?|\)\)?|\.\.|[{}[\];\\]/,
    number: {
      pattern: /(^|\s)(?:[1-9]\d*|0)(?:[.,]\d+)?\b/,
      lookbehind: !0
    }
  }, n.inside = t.languages.bash;
  for (var r = [
    "comment",
    "function-name",
    "for-or-select",
    "assign-left",
    "parameter",
    "string",
    "environment",
    "function",
    "keyword",
    "builtin",
    "boolean",
    "file-descriptor",
    "operator",
    "punctuation",
    "number"
  ], l = i.variable[1].inside, a = 0; a < r.length; a++)
    l[r[a]] = t.languages.bash[r[a]];
  t.languages.sh = t.languages.bash, t.languages.shell = t.languages.bash;
})(Prism);
const Nc = '<svg class="md-link-icon" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true" fill="currentColor"><path d="m7.775 3.275 1.25-1.25a3.5 3.5 0 1 1 4.95 4.95l-2.5 2.5a3.5 3.5 0 0 1-4.95 0 .751.751 0 0 1 .018-1.042.751.751 0 0 1 1.042-.018 1.998 1.998 0 0 0 2.83 0l2.5-2.5a2.002 2.002 0 0 0-2.83-2.83l-1.25 1.25a.751.751 0 0 1-1.042-.018.751.751 0 0 1-.018-1.042Zm-4.69 9.64a1.998 1.998 0 0 0 2.83 0l1.25-1.25a.751.751 0 0 1 1.042.018.751.751 0 0 1 .018 1.042l-1.25 1.25a3.5 3.5 0 1 1-4.95-4.95l2.5-2.5a3.5 3.5 0 0 1 4.95 0 .751.751 0 0 1-.018 1.042.751.751 0 0 1-1.042.018 1.998 1.998 0 0 0-2.83 0l-2.5 2.5a1.998 1.998 0 0 0 0 2.83Z"></path></svg>', Oc = `
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 15 15" color="currentColor" aria-hidden="true" aria-label="Copy" stroke-width="1.3" width="15" height="15">
  <path fill="currentColor" d="M12.728 4.545v8.182H4.545V4.545zm0 -0.909H4.545a0.909 0.909 0 0 0 -0.909 0.909v8.182a0.909 0.909 0 0 0 0.909 0.909h8.182a0.909 0.909 0 0 0 0.909 -0.909V4.545a0.909 0.909 0 0 0 -0.909 -0.909"/>
  <path fill="currentColor" d="M1.818 8.182H0.909V1.818a0.909 0.909 0 0 1 0.909 -0.909h6.364v0.909H1.818Z"/>
</svg>

`, Rc = `<svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 17 17" aria-hidden="true" aria-label="Copied" fill="none" stroke="currentColor" stroke-width="1.3">
  <path d="m13.813 4.781 -7.438 7.438 -3.188 -3.188"/>
</svg>
`, Wr = `<button title="copy" class="copy_code_button">
  <span class="copy-text">${Oc}</span>
  <span class="check">${Rc}</span>
</button>`, so = /[&<>"']/, Mc = new RegExp(so.source, "g"), uo = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, qc = new RegExp(uo.source, "g"), Uc = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, Qr = (t) => Uc[t] || "";
function fi(t, e) {
  if (e) {
    if (so.test(t))
      return t.replace(Mc, Qr);
  } else if (uo.test(t))
    return t.replace(qc, Qr);
  return t;
}
function Gc(t) {
  const e = t.map((n) => ({
    start: new RegExp(n.left.replace(/[-\/\\^$*+?.()|[\]{}]/g, "\\$&")),
    end: new RegExp(n.right.replace(/[-\/\\^$*+?.()|[\]{}]/g, "\\$&"))
  }));
  return {
    name: "latex",
    level: "block",
    start(n) {
      for (const i of e) {
        const r = n.match(i.start);
        if (r)
          return r.index;
      }
      return -1;
    },
    tokenizer(n, i) {
      for (const r of e) {
        const l = new RegExp(
          `${r.start.source}([\\s\\S]+?)${r.end.source}`
        ).exec(n);
        if (l)
          return {
            type: "latex",
            raw: l[0],
            text: l[1].trim()
          };
      }
    },
    renderer(n) {
      return `<div class="latex-block">${n.text}</div>`;
    }
  };
}
function zc() {
  return {
    name: "mermaid",
    level: "block",
    start(t) {
      var e;
      return (e = t.match(/^```mermaid\s*\n/)) == null ? void 0 : e.index;
    },
    tokenizer(t) {
      const e = /^```mermaid\s*\n([\s\S]*?)```\s*(?:\n|$)/.exec(t);
      if (e)
        return {
          type: "mermaid",
          raw: e[0],
          text: e[1].trim()
        };
    },
    renderer(t) {
      return `<div class="mermaid">${t.text}</div>
`;
    }
  };
}
const jc = {
  code(t, e, n) {
    var r;
    const i = ((r = (e ?? "").match(/\S*/)) == null ? void 0 : r[0]) ?? "";
    return t = t.replace(/\n$/, "") + `
`, !i || i === "mermaid" ? '<div class="code_wrap">' + Wr + "<pre><code>" + (n ? t : fi(t, !0)) + `</code></pre></div>
` : '<div class="code_wrap">' + Wr + '<pre><code class="language-' + fi(i) + '">' + (n ? t : fi(t, !0)) + `</code></pre></div>
`;
  }
}, Vc = new cr();
function Xc({
  header_links: t,
  line_breaks: e,
  latex_delimiters: n
}) {
  const i = new to();
  i.use(
    {
      gfm: !0,
      pedantic: !1,
      breaks: e
    },
    Sc({
      highlight: (a, o) => {
        var s;
        return (s = hi.languages) != null && s[o] ? hi.highlight(a, hi.languages[o], o) : a;
      }
    }),
    { renderer: jc }
  ), t && (i.use(Hc()), i.use({
    extensions: [
      {
        name: "heading",
        level: "block",
        renderer(a) {
          const o = a.raw.toLowerCase().trim().replace(/<[!\/a-z].*?>/gi, ""), s = "h" + Vc.slug(o), u = a.depth, c = this.parser.parseInline(a.tokens);
          return `<h${u} id="${s}"><a class="md-header-anchor" href="#${s}">${Nc}</a>${c}</h${u}>
`;
        }
      }
    ]
  }));
  const r = zc(), l = Gc(n);
  return i.use({
    extensions: [r, l]
  }), i;
}
const Mi = (t) => JSON.parse(JSON.stringify(t)), Zc = (t) => t.nodeType === 1, Wc = (t) => ph.has(t.tagName), Qc = (t) => "action" in t, Yc = (t) => t.tagName === "IFRAME", Jc = (t) => "formAction" in t, Kc = (t) => "protocol" in t, mn = /* @__PURE__ */ (() => {
  const t = /^(?:\w+script|data):/i;
  return (e) => t.test(e);
})(), eh = /* @__PURE__ */ (() => {
  const t = /(?:script|data):/i;
  return (e) => t.test(e);
})(), th = (t) => {
  const e = {};
  for (let n = 0, i = t.length; n < i; n++) {
    const r = t[n];
    for (const l in r)
      e[l] ? e[l] = e[l].concat(r[l]) : e[l] = r[l];
  }
  return e;
}, co = (t, e) => {
  let n = t.firstChild;
  for (; n; ) {
    const i = n.nextSibling;
    Zc(n) && (e(n, t), n.parentNode && co(n, e)), n = i;
  }
}, nh = (t, e) => {
  const n = document.createNodeIterator(t, NodeFilter.SHOW_ELEMENT);
  let i;
  for (; i = n.nextNode(); ) {
    const r = i.parentNode;
    r && e(i, r);
  }
}, ih = (t, e) => !!globalThis.document && !!globalThis.document.createNodeIterator ? nh(t, e) : co(t, e), ho = [
  "a",
  "abbr",
  "acronym",
  "address",
  "area",
  "article",
  "aside",
  "audio",
  "b",
  "bdi",
  "bdo",
  "bgsound",
  "big",
  "blockquote",
  "body",
  "br",
  "button",
  "canvas",
  "caption",
  "center",
  "cite",
  "code",
  "col",
  "colgroup",
  "datalist",
  "dd",
  "del",
  "details",
  "dfn",
  "dialog",
  "dir",
  "div",
  "dl",
  "dt",
  "em",
  "fieldset",
  "figcaption",
  "figure",
  "font",
  "footer",
  "form",
  "h1",
  "h2",
  "h3",
  "h4",
  "h5",
  "h6",
  "head",
  "header",
  "hgroup",
  "hr",
  "html",
  "i",
  "img",
  "input",
  "ins",
  "kbd",
  "keygen",
  "label",
  "layer",
  "legend",
  "li",
  "link",
  "listing",
  "main",
  "map",
  "mark",
  "marquee",
  "menu",
  "meta",
  "meter",
  "nav",
  "nobr",
  "ol",
  "optgroup",
  "option",
  "output",
  "p",
  "picture",
  "popup",
  "pre",
  "progress",
  "q",
  "rb",
  "rp",
  "rt",
  "rtc",
  "ruby",
  "s",
  "samp",
  "section",
  "select",
  "selectmenu",
  "small",
  "source",
  "span",
  "strike",
  "strong",
  "style",
  "sub",
  "summary",
  "sup",
  "table",
  "tbody",
  "td",
  "tfoot",
  "th",
  "thead",
  "time",
  "tr",
  "track",
  "tt",
  "u",
  "ul",
  "var",
  "video",
  "wbr"
], rh = [
  "basefont",
  "command",
  "data",
  "iframe",
  "image",
  "plaintext",
  "portal",
  "slot",
  // 'template', //TODO: Not exactly correct to never allow this, too strict
  "textarea",
  "title",
  "xmp"
], ah = /* @__PURE__ */ new Set([
  ...ho,
  ...rh
]), fo = [
  "svg",
  "a",
  "altglyph",
  "altglyphdef",
  "altglyphitem",
  "animatecolor",
  "animatemotion",
  "animatetransform",
  "circle",
  "clippath",
  "defs",
  "desc",
  "ellipse",
  "filter",
  "font",
  "g",
  "glyph",
  "glyphref",
  "hkern",
  "image",
  "line",
  "lineargradient",
  "marker",
  "mask",
  "metadata",
  "mpath",
  "path",
  "pattern",
  "polygon",
  "polyline",
  "radialgradient",
  "rect",
  "stop",
  "style",
  "switch",
  "symbol",
  "text",
  "textpath",
  "title",
  "tref",
  "tspan",
  "view",
  "vkern",
  /* FILTERS */
  "feBlend",
  "feColorMatrix",
  "feComponentTransfer",
  "feComposite",
  "feConvolveMatrix",
  "feDiffuseLighting",
  "feDisplacementMap",
  "feDistantLight",
  "feFlood",
  "feFuncA",
  "feFuncB",
  "feFuncG",
  "feFuncR",
  "feGaussianBlur",
  "feImage",
  "feMerge",
  "feMergeNode",
  "feMorphology",
  "feOffset",
  "fePointLight",
  "feSpecularLighting",
  "feSpotLight",
  "feTile",
  "feTurbulence"
], lh = [
  "animate",
  "color-profile",
  "cursor",
  "discard",
  "fedropshadow",
  "font-face",
  "font-face-format",
  "font-face-name",
  "font-face-src",
  "font-face-uri",
  "foreignobject",
  "hatch",
  "hatchpath",
  "mesh",
  "meshgradient",
  "meshpatch",
  "meshrow",
  "missing-glyph",
  "script",
  "set",
  "solidcolor",
  "unknown",
  "use"
], oh = /* @__PURE__ */ new Set([
  ...fo,
  ...lh
]), _o = [
  "math",
  "menclose",
  "merror",
  "mfenced",
  "mfrac",
  "mglyph",
  "mi",
  "mlabeledtr",
  "mmultiscripts",
  "mn",
  "mo",
  "mover",
  "mpadded",
  "mphantom",
  "mroot",
  "mrow",
  "ms",
  "mspace",
  "msqrt",
  "mstyle",
  "msub",
  "msup",
  "msubsup",
  "mtable",
  "mtd",
  "mtext",
  "mtr",
  "munder",
  "munderover"
], sh = [
  "maction",
  "maligngroup",
  "malignmark",
  "mlongdiv",
  "mscarries",
  "mscarry",
  "msgroup",
  "mstack",
  "msline",
  "msrow",
  "semantics",
  "annotation",
  "annotation-xml",
  "mprescripts",
  "none"
], uh = /* @__PURE__ */ new Set([
  ..._o,
  ...sh
]), ch = [
  "abbr",
  "accept",
  "accept-charset",
  "accesskey",
  "action",
  "align",
  "alink",
  "allow",
  "allowfullscreen",
  "alt",
  "anchor",
  "archive",
  "as",
  "async",
  "autocapitalize",
  "autocomplete",
  "autocorrect",
  "autofocus",
  "autopictureinpicture",
  "autoplay",
  "axis",
  "background",
  "behavior",
  "bgcolor",
  "border",
  "bordercolor",
  "capture",
  "cellpadding",
  "cellspacing",
  "challenge",
  "char",
  "charoff",
  "charset",
  "checked",
  "cite",
  "class",
  "classid",
  "clear",
  "code",
  "codebase",
  "codetype",
  "color",
  "cols",
  "colspan",
  "compact",
  "content",
  "contenteditable",
  "controls",
  "controlslist",
  "conversiondestination",
  "coords",
  "crossorigin",
  "csp",
  "data",
  "datetime",
  "declare",
  "decoding",
  "default",
  "defer",
  "dir",
  "direction",
  "dirname",
  "disabled",
  "disablepictureinpicture",
  "disableremoteplayback",
  "disallowdocumentaccess",
  "download",
  "draggable",
  "elementtiming",
  "enctype",
  "end",
  "enterkeyhint",
  "event",
  "exportparts",
  "face",
  "for",
  "form",
  "formaction",
  "formenctype",
  "formmethod",
  "formnovalidate",
  "formtarget",
  "frame",
  "frameborder",
  "headers",
  "height",
  "hidden",
  "high",
  "href",
  "hreflang",
  "hreftranslate",
  "hspace",
  "http-equiv",
  "id",
  "imagesizes",
  "imagesrcset",
  "importance",
  "impressiondata",
  "impressionexpiry",
  "incremental",
  "inert",
  "inputmode",
  "integrity",
  "invisible",
  "ismap",
  "keytype",
  "kind",
  "label",
  "lang",
  "language",
  "latencyhint",
  "leftmargin",
  "link",
  "list",
  "loading",
  "longdesc",
  "loop",
  "low",
  "lowsrc",
  "manifest",
  "marginheight",
  "marginwidth",
  "max",
  "maxlength",
  "mayscript",
  "media",
  "method",
  "min",
  "minlength",
  "multiple",
  "muted",
  "name",
  "nohref",
  "nomodule",
  "nonce",
  "noresize",
  "noshade",
  "novalidate",
  "nowrap",
  "object",
  "open",
  "optimum",
  "part",
  "pattern",
  "ping",
  "placeholder",
  "playsinline",
  "policy",
  "poster",
  "preload",
  "pseudo",
  "readonly",
  "referrerpolicy",
  "rel",
  "reportingorigin",
  "required",
  "resources",
  "rev",
  "reversed",
  "role",
  "rows",
  "rowspan",
  "rules",
  "sandbox",
  "scheme",
  "scope",
  "scopes",
  "scrollamount",
  "scrolldelay",
  "scrolling",
  "select",
  "selected",
  "shadowroot",
  "shadowrootdelegatesfocus",
  "shape",
  "size",
  "sizes",
  "slot",
  "span",
  "spellcheck",
  "src",
  "srclang",
  "srcset",
  "standby",
  "start",
  "step",
  "style",
  "summary",
  "tabindex",
  "target",
  "text",
  "title",
  "topmargin",
  "translate",
  "truespeed",
  "trusttoken",
  "type",
  "usemap",
  "valign",
  "value",
  "valuetype",
  "version",
  "virtualkeyboardpolicy",
  "vlink",
  "vspace",
  "webkitdirectory",
  "width",
  "wrap"
], hh = [
  "accent-height",
  "accumulate",
  "additive",
  "alignment-baseline",
  "ascent",
  "attributename",
  "attributetype",
  "azimuth",
  "basefrequency",
  "baseline-shift",
  "begin",
  "bias",
  "by",
  "class",
  "clip",
  "clippathunits",
  "clip-path",
  "clip-rule",
  "color",
  "color-interpolation",
  "color-interpolation-filters",
  "color-profile",
  "color-rendering",
  "cx",
  "cy",
  "d",
  "dx",
  "dy",
  "diffuseconstant",
  "direction",
  "display",
  "divisor",
  "dominant-baseline",
  "dur",
  "edgemode",
  "elevation",
  "end",
  "fill",
  "fill-opacity",
  "fill-rule",
  "filter",
  "filterunits",
  "flood-color",
  "flood-opacity",
  "font-family",
  "font-size",
  "font-size-adjust",
  "font-stretch",
  "font-style",
  "font-variant",
  "font-weight",
  "fx",
  "fy",
  "g1",
  "g2",
  "glyph-name",
  "glyphref",
  "gradientunits",
  "gradienttransform",
  "height",
  "href",
  "id",
  "image-rendering",
  "in",
  "in2",
  "k",
  "k1",
  "k2",
  "k3",
  "k4",
  "kerning",
  "keypoints",
  "keysplines",
  "keytimes",
  "lang",
  "lengthadjust",
  "letter-spacing",
  "kernelmatrix",
  "kernelunitlength",
  "lighting-color",
  "local",
  "marker-end",
  "marker-mid",
  "marker-start",
  "markerheight",
  "markerunits",
  "markerwidth",
  "maskcontentunits",
  "maskunits",
  "max",
  "mask",
  "media",
  "method",
  "mode",
  "min",
  "name",
  "numoctaves",
  "offset",
  "operator",
  "opacity",
  "order",
  "orient",
  "orientation",
  "origin",
  "overflow",
  "paint-order",
  "path",
  "pathlength",
  "patterncontentunits",
  "patterntransform",
  "patternunits",
  "points",
  "preservealpha",
  "preserveaspectratio",
  "primitiveunits",
  "r",
  "rx",
  "ry",
  "radius",
  "refx",
  "refy",
  "repeatcount",
  "repeatdur",
  "restart",
  "result",
  "rotate",
  "scale",
  "seed",
  "shape-rendering",
  "specularconstant",
  "specularexponent",
  "spreadmethod",
  "startoffset",
  "stddeviation",
  "stitchtiles",
  "stop-color",
  "stop-opacity",
  "stroke-dasharray",
  "stroke-dashoffset",
  "stroke-linecap",
  "stroke-linejoin",
  "stroke-miterlimit",
  "stroke-opacity",
  "stroke",
  "stroke-width",
  "style",
  "surfacescale",
  "systemlanguage",
  "tabindex",
  "targetx",
  "targety",
  "transform",
  "transform-origin",
  "text-anchor",
  "text-decoration",
  "text-rendering",
  "textlength",
  "type",
  "u1",
  "u2",
  "unicode",
  "values",
  "viewbox",
  "visibility",
  "version",
  "vert-adv-y",
  "vert-origin-x",
  "vert-origin-y",
  "width",
  "word-spacing",
  "wrap",
  "writing-mode",
  "xchannelselector",
  "ychannelselector",
  "x",
  "x1",
  "x2",
  "xmlns",
  "y",
  "y1",
  "y2",
  "z",
  "zoomandpan"
], fh = [
  "accent",
  "accentunder",
  "align",
  "bevelled",
  "close",
  "columnsalign",
  "columnlines",
  "columnspan",
  "denomalign",
  "depth",
  "dir",
  "display",
  "displaystyle",
  "encoding",
  "fence",
  "frame",
  "height",
  "href",
  "id",
  "largeop",
  "length",
  "linethickness",
  "lspace",
  "lquote",
  "mathbackground",
  "mathcolor",
  "mathsize",
  "mathvariant",
  "maxsize",
  "minsize",
  "movablelimits",
  "notation",
  "numalign",
  "open",
  "rowalign",
  "rowlines",
  "rowspacing",
  "rowspan",
  "rspace",
  "rquote",
  "scriptlevel",
  "scriptminsize",
  "scriptsizemultiplier",
  "selection",
  "separator",
  "separators",
  "stretchy",
  "subscriptshift",
  "supscriptshift",
  "symmetric",
  "voffset",
  "width",
  "xmlns"
], Oe = {
  HTML: "http://www.w3.org/1999/xhtml",
  SVG: "http://www.w3.org/2000/svg",
  MATH: "http://www.w3.org/1998/Math/MathML"
}, _h = {
  [Oe.HTML]: ah,
  [Oe.SVG]: oh,
  [Oe.MATH]: uh
}, dh = {
  [Oe.HTML]: "html",
  [Oe.SVG]: "svg",
  [Oe.MATH]: "math"
}, mh = {
  [Oe.HTML]: "",
  [Oe.SVG]: "svg:",
  [Oe.MATH]: "math:"
}, ph = /* @__PURE__ */ new Set([
  "A",
  "AREA",
  "BUTTON",
  "FORM",
  "IFRAME",
  "INPUT"
]), mo = {
  allowComments: !0,
  allowCustomElements: !1,
  allowUnknownMarkup: !1,
  allowElements: [
    ...ho,
    ...fo.map((t) => `svg:${t}`),
    ..._o.map((t) => `math:${t}`)
  ],
  allowAttributes: th([
    Object.fromEntries(ch.map((t) => [t, ["*"]])),
    Object.fromEntries(hh.map((t) => [t, ["svg:*"]])),
    Object.fromEntries(fh.map((t) => [t, ["math:*"]]))
  ])
};
var _i = function(t, e, n, i, r) {
  if (i === "m") throw new TypeError("Private method is not writable");
  if (i === "a" && !r) throw new TypeError("Private accessor was defined without a setter");
  if (typeof e == "function" ? t !== e || !r : !e.has(t)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return i === "a" ? r.call(t, n) : r ? r.value = n : e.set(t, n), n;
}, ut = function(t, e, n, i) {
  if (n === "a" && !i) throw new TypeError("Private accessor was defined without a getter");
  if (typeof e == "function" ? t !== e || !i : !e.has(t)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return n === "m" ? i : n === "a" ? i.call(t) : i ? i.value : e.get(t);
}, nt, Sn, xn;
class po {
  /* CONSTRUCTOR */
  constructor(e = {}) {
    nt.set(this, void 0), Sn.set(this, void 0), xn.set(this, void 0), this.getConfiguration = () => Mi(ut(this, nt, "f")), this.sanitize = (c) => {
      const _ = ut(this, Sn, "f"), h = ut(this, xn, "f");
      return ih(c, (d, D) => {
        const E = d.namespaceURI || Oe.HTML, F = D.namespaceURI || Oe.HTML, C = _h[E], g = dh[E], f = mh[E], m = d.tagName.toLowerCase(), v = `${f}${m}`, b = `${f}*`;
        if (!C.has(m) || !_.has(v) || E !== F && m !== g)
          D.removeChild(d);
        else {
          const k = d.getAttributeNames(), y = k.length;
          if (y) {
            for (let w = 0; w < y; w++) {
              const A = k[w], B = h[A];
              (!B || !B.has(b) && !B.has(v)) && d.removeAttribute(A);
            }
            if (Wc(d))
              if (Kc(d)) {
                const w = d.getAttribute("href");
                w && eh(w) && mn(d.protocol) && d.removeAttribute("href");
              } else Qc(d) ? mn(d.action) && d.removeAttribute("action") : Jc(d) ? mn(d.formAction) && d.removeAttribute("formaction") : Yc(d) && (mn(d.src) && d.removeAttribute("formaction"), d.setAttribute("sandbox", "allow-scripts"));
          }
        }
      }), c;
    }, this.sanitizeFor = (c, _) => {
      throw new Error('"sanitizeFor" is not implemented yet');
    };
    const { allowComments: n, allowCustomElements: i, allowUnknownMarkup: r, blockElements: l, dropElements: a, dropAttributes: o } = e;
    if (n === !1)
      throw new Error('A false "allowComments" is not supported yet');
    if (i)
      throw new Error('A true "allowCustomElements" is not supported yet');
    if (r)
      throw new Error('A true "allowUnknownMarkup" is not supported yet');
    if (l)
      throw new Error('"blockElements" is not supported yet, use "allowElements" instead');
    if (a)
      throw new Error('"dropElements" is not supported yet, use "allowElements" instead');
    if (o)
      throw new Error('"dropAttributes" is not supported yet, use "allowAttributes" instead');
    _i(this, nt, Mi(mo), "f");
    const { allowElements: s, allowAttributes: u } = e;
    s && (ut(this, nt, "f").allowElements = e.allowElements), u && (ut(this, nt, "f").allowAttributes = e.allowAttributes), _i(this, Sn, new Set(ut(this, nt, "f").allowElements), "f"), _i(this, xn, Object.fromEntries(Object.entries(ut(this, nt, "f").allowAttributes || {}).map(([c, _]) => [c, new Set(_)])), "f");
  }
}
nt = /* @__PURE__ */ new WeakMap(), Sn = /* @__PURE__ */ new WeakMap(), xn = /* @__PURE__ */ new WeakMap();
po.getDefaultConfiguration = () => Mi(mo);
const gh = (t, e = location.href) => {
  try {
    return !!t && new URL(t).origin !== new URL(e).origin;
  } catch {
    return !1;
  }
};
function Yr(t) {
  const e = new po(), n = new DOMParser().parseFromString(t, "text/html");
  return go(n.body, "A", (i) => {
    i instanceof HTMLElement && "target" in i && gh(i.getAttribute("href"), location.href) && (i.setAttribute("target", "_blank"), i.setAttribute("rel", "noopener noreferrer"));
  }), e.sanitize(n).body.innerHTML;
}
function go(t, e, n) {
  t && (t.nodeName === e || typeof e == "function") && n(t);
  const i = (t == null ? void 0 : t.childNodes) || [];
  for (let r = 0; r < i.length; r++)
    go(i[r], e, n);
}
const Jr = [
  "!--",
  "!doctype",
  "a",
  "abbr",
  "acronym",
  "address",
  "applet",
  "area",
  "article",
  "aside",
  "audio",
  "b",
  "base",
  "basefont",
  "bdi",
  "bdo",
  "big",
  "blockquote",
  "body",
  "br",
  "button",
  "canvas",
  "caption",
  "center",
  "cite",
  "code",
  "col",
  "colgroup",
  "data",
  "datalist",
  "dd",
  "del",
  "details",
  "dfn",
  "dialog",
  "dir",
  "div",
  "dl",
  "dt",
  "em",
  "embed",
  "fieldset",
  "figcaption",
  "figure",
  "font",
  "footer",
  "form",
  "frame",
  "frameset",
  "h1",
  "h2",
  "h3",
  "h4",
  "h5",
  "h6",
  "head",
  "header",
  "hgroup",
  "hr",
  "html",
  "i",
  "iframe",
  "img",
  "input",
  "ins",
  "kbd",
  "label",
  "legend",
  "li",
  "link",
  "main",
  "map",
  "mark",
  "menu",
  "meta",
  "meter",
  "nav",
  "noframes",
  "noscript",
  "object",
  "ol",
  "optgroup",
  "option",
  "output",
  "p",
  "param",
  "picture",
  "pre",
  "progress",
  "q",
  "rp",
  "rt",
  "ruby",
  "s",
  "samp",
  "script",
  "search",
  "section",
  "select",
  "small",
  "source",
  "span",
  "strike",
  "strong",
  "style",
  "sub",
  "summary",
  "sup",
  "svg",
  "table",
  "tbody",
  "td",
  "template",
  "textarea",
  "tfoot",
  "th",
  "thead",
  "time",
  "title",
  "tr",
  "track",
  "tt",
  "u",
  "ul",
  "var",
  "video",
  "wbr"
], bh = [
  // Base structural elements
  "g",
  "defs",
  "use",
  "symbol",
  // Shape elements
  "rect",
  "circle",
  "ellipse",
  "line",
  "polyline",
  "polygon",
  "path",
  "image",
  // Text elements
  "text",
  "tspan",
  "textPath",
  // Gradient and effects
  "linearGradient",
  "radialGradient",
  "stop",
  "pattern",
  "clipPath",
  "mask",
  "filter",
  // Filter effects
  "feBlend",
  "feColorMatrix",
  "feComponentTransfer",
  "feComposite",
  "feConvolveMatrix",
  "feDiffuseLighting",
  "feDisplacementMap",
  "feGaussianBlur",
  "feMerge",
  "feMorphology",
  "feOffset",
  "feSpecularLighting",
  "feTurbulence",
  "feMergeNode",
  "feFuncR",
  "feFuncG",
  "feFuncB",
  "feFuncA",
  "feDistantLight",
  "fePointLight",
  "feSpotLight",
  "feFlood",
  "feTile",
  // Animation elements
  "animate",
  "animateTransform",
  "animateMotion",
  "mpath",
  "set",
  // Interactive and other elements
  "view",
  "cursor",
  "foreignObject",
  "desc",
  "title",
  "metadata",
  "switch"
], vh = [
  ...Jr,
  ...bh.filter((t) => !Jr.includes(t))
], {
  HtmlTagHydration: yh,
  SvelteComponent: wh,
  attr: Dh,
  binding_callbacks: Eh,
  children: Fh,
  claim_element: kh,
  claim_html_tag: Ah,
  detach: Kr,
  element: Ch,
  init: Sh,
  insert_hydration: xh,
  noop: ea,
  safe_not_equal: Bh,
  toggle_class: pn
} = window.__gradio__svelte__internal, { afterUpdate: $h, tick: Th, onMount: am } = window.__gradio__svelte__internal;
function Ih(t) {
  let e, n;
  return {
    c() {
      e = Ch("span"), n = new yh(!1), this.h();
    },
    l(i) {
      e = kh(i, "SPAN", { class: !0 });
      var r = Fh(e);
      n = Ah(r, !1), r.forEach(Kr), this.h();
    },
    h() {
      n.a = null, Dh(e, "class", "md svelte-1m32c2s"), pn(
        e,
        "chatbot",
        /*chatbot*/
        t[0]
      ), pn(
        e,
        "prose",
        /*render_markdown*/
        t[1]
      );
    },
    m(i, r) {
      xh(i, e, r), n.m(
        /*html*/
        t[3],
        e
      ), t[11](e);
    },
    p(i, [r]) {
      r & /*html*/
      8 && n.p(
        /*html*/
        i[3]
      ), r & /*chatbot*/
      1 && pn(
        e,
        "chatbot",
        /*chatbot*/
        i[0]
      ), r & /*render_markdown*/
      2 && pn(
        e,
        "prose",
        /*render_markdown*/
        i[1]
      );
    },
    i: ea,
    o: ea,
    d(i) {
      i && Kr(e), t[11](null);
    }
  };
}
function ta(t) {
  return t.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function Lh(t, e, n) {
  var i = this && this.__awaiter || function(p, b, k, y) {
    function w(A) {
      return A instanceof k ? A : new k(function(B) {
        B(A);
      });
    }
    return new (k || (k = Promise))(function(A, B) {
      function N(M) {
        try {
          R(y.next(M));
        } catch (J) {
          B(J);
        }
      }
      function L(M) {
        try {
          R(y.throw(M));
        } catch (J) {
          B(J);
        }
      }
      function R(M) {
        M.done ? A(M.value) : w(M.value).then(N, L);
      }
      R((y = y.apply(p, b || [])).next());
    });
  };
  let { chatbot: r = !0 } = e, { message: l } = e, { sanitize_html: a = !0 } = e, { latex_delimiters: o = [] } = e, { render_markdown: s = !0 } = e, { line_breaks: u = !0 } = e, { header_links: c = !1 } = e, { allow_tags: _ = !1 } = e, { theme_mode: h = "system" } = e, d, D, E = !1;
  const F = Xc({
    header_links: c,
    line_breaks: u,
    latex_delimiters: o || []
  });
  function C(p) {
    return !o || o.length === 0 ? !1 : o.some((b) => p.includes(b.left) && p.includes(b.right));
  }
  function g(p, b) {
    if (b === !0) {
      const k = /<\/?([a-zA-Z][a-zA-Z0-9-]*)([\s>])/g;
      return p.replace(k, (y, w, A) => vh.includes(w.toLowerCase()) ? y : y.replace(/</g, "&lt;").replace(/>/g, "&gt;"));
    }
    if (Array.isArray(b)) {
      const k = b.map((w) => ({
        open: new RegExp(`<(${w})(\\s+[^>]*)?>`, "gi"),
        close: new RegExp(`</(${w})>`, "gi")
      }));
      let y = p;
      return k.forEach((w) => {
        y = y.replace(w.open, (A) => A.replace(/</g, "&lt;").replace(/>/g, "&gt;")), y = y.replace(w.close, (A) => A.replace(/</g, "&lt;").replace(/>/g, "&gt;"));
      }), y;
    }
    return p;
  }
  function f(p) {
    let b = p;
    if (s) {
      const k = [];
      o.forEach((y, w) => {
        const A = ta(y.left), B = ta(y.right), N = new RegExp(`${A}([\\s\\S]+?)${B}`, "g");
        b = b.replace(N, (L, R) => (k.push(L), `%%%LATEX_BLOCK_${k.length - 1}%%%`));
      }), b = F.parse(b), b = b.replace(/%%%LATEX_BLOCK_(\d+)%%%/g, (y, w) => k[parseInt(w, 10)]);
    }
    return _ && (b = g(b, _)), a && Yr && (b = Yr(b)), b;
  }
  function m(p) {
    return i(this, void 0, void 0, function* () {
      if (o.length > 0 && p && C(p))
        if (!E)
          yield Promise.all([
            Promise.resolve({              }),
            import("./auto-render-BwaQGe8P.js")
          ]).then(([, { default: b }]) => {
            E = !0, b(d, {
              delimiters: o,
              throwOnError: !1
            });
          });
        else {
          const { default: b } = yield import("./auto-render-BwaQGe8P.js");
          b(d, {
            delimiters: o,
            throwOnError: !1
          });
        }
      if (d) {
        const b = d.querySelectorAll(".mermaid");
        if (b.length > 0) {
          yield Th();
          const { default: k } = yield import("./mermaid.core-Dc4CY52J.js").then((y) => y.bB);
          k.initialize({
            startOnLoad: !1,
            theme: h === "dark" ? "dark" : "default",
            securityLevel: "antiscript"
          }), yield k.run({
            nodes: Array.from(b).map((y) => y)
          });
        }
      }
    });
  }
  $h(() => i(void 0, void 0, void 0, function* () {
    d && document.body.contains(d) ? yield m(l) : console.error("Element is not in the DOM");
  }));
  function v(p) {
    Eh[p ? "unshift" : "push"](() => {
      d = p, n(2, d);
    });
  }
  return t.$$set = (p) => {
    "chatbot" in p && n(0, r = p.chatbot), "message" in p && n(4, l = p.message), "sanitize_html" in p && n(5, a = p.sanitize_html), "latex_delimiters" in p && n(6, o = p.latex_delimiters), "render_markdown" in p && n(1, s = p.render_markdown), "line_breaks" in p && n(7, u = p.line_breaks), "header_links" in p && n(8, c = p.header_links), "allow_tags" in p && n(9, _ = p.allow_tags), "theme_mode" in p && n(10, h = p.theme_mode);
  }, t.$$.update = () => {
    t.$$.dirty & /*message*/
    16 && (l && l.trim() ? n(3, D = f(l)) : n(3, D = ""));
  }, [
    r,
    s,
    d,
    D,
    l,
    a,
    o,
    u,
    c,
    _,
    h,
    v
  ];
}
class Hh extends wh {
  constructor(e) {
    super(), Sh(this, e, Lh, Ih, Bh, {
      chatbot: 0,
      message: 4,
      sanitize_html: 5,
      latex_delimiters: 6,
      render_markdown: 1,
      line_breaks: 7,
      header_links: 8,
      allow_tags: 9,
      theme_mode: 10
    });
  }
}
const {
  SvelteComponent: Ph,
  attr: Nh,
  children: Oh,
  claim_component: Rh,
  claim_element: Mh,
  create_component: qh,
  destroy_component: Uh,
  detach: na,
  element: Gh,
  init: zh,
  insert_hydration: jh,
  mount_component: Vh,
  safe_not_equal: Xh,
  transition_in: Zh,
  transition_out: Wh
} = window.__gradio__svelte__internal;
function Qh(t) {
  let e, n, i;
  return n = new Hh({
    props: {
      message: (
        /*info*/
        t[0]
      ),
      sanitize_html: !0
    }
  }), {
    c() {
      e = Gh("div"), qh(n.$$.fragment), this.h();
    },
    l(r) {
      e = Mh(r, "DIV", { class: !0 });
      var l = Oh(e);
      Rh(n.$$.fragment, l), l.forEach(na), this.h();
    },
    h() {
      Nh(e, "class", "svelte-17qq50w");
    },
    m(r, l) {
      jh(r, e, l), Vh(n, e, null), i = !0;
    },
    p(r, [l]) {
      const a = {};
      l & /*info*/
      1 && (a.message = /*info*/
      r[0]), n.$set(a);
    },
    i(r) {
      i || (Zh(n.$$.fragment, r), i = !0);
    },
    o(r) {
      Wh(n.$$.fragment, r), i = !1;
    },
    d(r) {
      r && na(e), Uh(n);
    }
  };
}
function Yh(t, e, n) {
  let { info: i } = e;
  return t.$$set = (r) => {
    "info" in r && n(0, i = r.info);
  }, [i];
}
class Jh extends Ph {
  constructor(e) {
    super(), zh(this, e, Yh, Qh, Xh, { info: 0 });
  }
}
const {
  SvelteComponent: Kh,
  attr: gn,
  check_outros: ef,
  children: tf,
  claim_component: nf,
  claim_element: rf,
  claim_space: af,
  create_component: lf,
  create_slot: of,
  destroy_component: sf,
  detach: bn,
  element: uf,
  empty: ia,
  get_all_dirty_from_scope: cf,
  get_slot_changes: hf,
  group_outros: ff,
  init: _f,
  insert_hydration: di,
  mount_component: df,
  safe_not_equal: mf,
  space: pf,
  toggle_class: bt,
  transition_in: qt,
  transition_out: Bn,
  update_slot_base: gf
} = window.__gradio__svelte__internal;
function ra(t) {
  let e, n;
  return e = new Jh({ props: { info: (
    /*info*/
    t[1]
  ) } }), {
    c() {
      lf(e.$$.fragment);
    },
    l(i) {
      nf(e.$$.fragment, i);
    },
    m(i, r) {
      df(e, i, r), n = !0;
    },
    p(i, r) {
      const l = {};
      r & /*info*/
      2 && (l.info = /*info*/
      i[1]), e.$set(l);
    },
    i(i) {
      n || (qt(e.$$.fragment, i), n = !0);
    },
    o(i) {
      Bn(e.$$.fragment, i), n = !1;
    },
    d(i) {
      sf(e, i);
    }
  };
}
function bf(t) {
  let e, n, i, r, l;
  const a = (
    /*#slots*/
    t[4].default
  ), o = of(
    a,
    t,
    /*$$scope*/
    t[3],
    null
  );
  let s = (
    /*info*/
    t[1] && ra(t)
  );
  return {
    c() {
      e = uf("span"), o && o.c(), i = pf(), s && s.c(), r = ia(), this.h();
    },
    l(u) {
      e = rf(u, "SPAN", {
        "data-testid": !0,
        dir: !0,
        class: !0
      });
      var c = tf(e);
      o && o.l(c), c.forEach(bn), i = af(u), s && s.l(u), r = ia(), this.h();
    },
    h() {
      gn(e, "data-testid", "block-info"), gn(e, "dir", n = /*rtl*/
      t[2] ? "rtl" : "ltr"), gn(e, "class", "svelte-zgrq3"), bt(e, "sr-only", !/*show_label*/
      t[0]), bt(e, "hide", !/*show_label*/
      t[0]), bt(
        e,
        "has-info",
        /*info*/
        t[1] != null
      );
    },
    m(u, c) {
      di(u, e, c), o && o.m(e, null), di(u, i, c), s && s.m(u, c), di(u, r, c), l = !0;
    },
    p(u, [c]) {
      o && o.p && (!l || c & /*$$scope*/
      8) && gf(
        o,
        a,
        u,
        /*$$scope*/
        u[3],
        l ? hf(
          a,
          /*$$scope*/
          u[3],
          c,
          null
        ) : cf(
          /*$$scope*/
          u[3]
        ),
        null
      ), (!l || c & /*rtl*/
      4 && n !== (n = /*rtl*/
      u[2] ? "rtl" : "ltr")) && gn(e, "dir", n), (!l || c & /*show_label*/
      1) && bt(e, "sr-only", !/*show_label*/
      u[0]), (!l || c & /*show_label*/
      1) && bt(e, "hide", !/*show_label*/
      u[0]), (!l || c & /*info*/
      2) && bt(
        e,
        "has-info",
        /*info*/
        u[1] != null
      ), /*info*/
      u[1] ? s ? (s.p(u, c), c & /*info*/
      2 && qt(s, 1)) : (s = ra(u), s.c(), qt(s, 1), s.m(r.parentNode, r)) : s && (ff(), Bn(s, 1, 1, () => {
        s = null;
      }), ef());
    },
    i(u) {
      l || (qt(o, u), qt(s), l = !0);
    },
    o(u) {
      Bn(o, u), Bn(s), l = !1;
    },
    d(u) {
      u && (bn(e), bn(i), bn(r)), o && o.d(u), s && s.d(u);
    }
  };
}
function vf(t, e, n) {
  let { $$slots: i = {}, $$scope: r } = e, { show_label: l = !0 } = e, { info: a = void 0 } = e, { rtl: o = !1 } = e;
  return t.$$set = (s) => {
    "show_label" in s && n(0, l = s.show_label), "info" in s && n(1, a = s.info), "rtl" in s && n(2, o = s.rtl), "$$scope" in s && n(3, r = s.$$scope);
  }, [l, a, o, r, i];
}
class bo extends Kh {
  constructor(e) {
    super(), _f(this, e, vf, bf, mf, { show_label: 0, info: 1, rtl: 2 });
  }
}
const {
  SvelteComponent: lm,
  append_hydration: om,
  attr: sm,
  children: um,
  claim_component: cm,
  claim_element: hm,
  claim_space: fm,
  claim_text: _m,
  create_component: dm,
  destroy_component: mm,
  detach: pm,
  element: gm,
  init: bm,
  insert_hydration: vm,
  mount_component: ym,
  safe_not_equal: wm,
  set_data: Dm,
  space: Em,
  text: Fm,
  toggle_class: km,
  transition_in: Am,
  transition_out: Cm
} = window.__gradio__svelte__internal, {
  SvelteComponent: yf,
  append_hydration: $n,
  attr: Ye,
  bubble: wf,
  check_outros: Df,
  children: qi,
  claim_component: Ef,
  claim_element: Ui,
  claim_space: aa,
  claim_text: Ff,
  construct_svelte_component: la,
  create_component: oa,
  create_slot: kf,
  destroy_component: sa,
  detach: Vt,
  element: Gi,
  get_all_dirty_from_scope: Af,
  get_slot_changes: Cf,
  group_outros: Sf,
  init: xf,
  insert_hydration: vo,
  listen: Bf,
  mount_component: ua,
  safe_not_equal: $f,
  set_data: Tf,
  set_style: vn,
  space: ca,
  text: If,
  toggle_class: se,
  transition_in: mi,
  transition_out: pi,
  update_slot_base: Lf
} = window.__gradio__svelte__internal;
function ha(t) {
  let e, n;
  return {
    c() {
      e = Gi("span"), n = If(
        /*label*/
        t[1]
      ), this.h();
    },
    l(i) {
      e = Ui(i, "SPAN", { class: !0 });
      var r = qi(e);
      n = Ff(
        r,
        /*label*/
        t[1]
      ), r.forEach(Vt), this.h();
    },
    h() {
      Ye(e, "class", "svelte-qgco6m");
    },
    m(i, r) {
      vo(i, e, r), $n(e, n);
    },
    p(i, r) {
      r & /*label*/
      2 && Tf(
        n,
        /*label*/
        i[1]
      );
    },
    d(i) {
      i && Vt(e);
    }
  };
}
function Hf(t) {
  let e, n, i, r, l, a, o, s, u = (
    /*show_label*/
    t[2] && ha(t)
  );
  var c = (
    /*Icon*/
    t[0]
  );
  function _(D, E) {
    return {};
  }
  c && (r = la(c, _()));
  const h = (
    /*#slots*/
    t[14].default
  ), d = kf(
    h,
    t,
    /*$$scope*/
    t[13],
    null
  );
  return {
    c() {
      e = Gi("button"), u && u.c(), n = ca(), i = Gi("div"), r && oa(r.$$.fragment), l = ca(), d && d.c(), this.h();
    },
    l(D) {
      e = Ui(D, "BUTTON", {
        "aria-label": !0,
        "aria-haspopup": !0,
        title: !0,
        class: !0
      });
      var E = qi(e);
      u && u.l(E), n = aa(E), i = Ui(E, "DIV", { class: !0 });
      var F = qi(i);
      r && Ef(r.$$.fragment, F), l = aa(F), d && d.l(F), F.forEach(Vt), E.forEach(Vt), this.h();
    },
    h() {
      Ye(i, "class", "svelte-qgco6m"), se(
        i,
        "x-small",
        /*size*/
        t[4] === "x-small"
      ), se(
        i,
        "small",
        /*size*/
        t[4] === "small"
      ), se(
        i,
        "large",
        /*size*/
        t[4] === "large"
      ), se(
        i,
        "medium",
        /*size*/
        t[4] === "medium"
      ), e.disabled = /*disabled*/
      t[7], Ye(
        e,
        "aria-label",
        /*label*/
        t[1]
      ), Ye(
        e,
        "aria-haspopup",
        /*hasPopup*/
        t[8]
      ), Ye(
        e,
        "title",
        /*label*/
        t[1]
      ), Ye(e, "class", "svelte-qgco6m"), se(
        e,
        "pending",
        /*pending*/
        t[3]
      ), se(
        e,
        "padded",
        /*padded*/
        t[5]
      ), se(
        e,
        "highlight",
        /*highlight*/
        t[6]
      ), se(
        e,
        "transparent",
        /*transparent*/
        t[9]
      ), vn(e, "color", !/*disabled*/
      t[7] && /*_color*/
      t[11] ? (
        /*_color*/
        t[11]
      ) : "var(--block-label-text-color)"), vn(e, "--bg-color", /*disabled*/
      t[7] ? "auto" : (
        /*background*/
        t[10]
      ));
    },
    m(D, E) {
      vo(D, e, E), u && u.m(e, null), $n(e, n), $n(e, i), r && ua(r, i, null), $n(i, l), d && d.m(i, null), a = !0, o || (s = Bf(
        e,
        "click",
        /*click_handler*/
        t[15]
      ), o = !0);
    },
    p(D, [E]) {
      if (/*show_label*/
      D[2] ? u ? u.p(D, E) : (u = ha(D), u.c(), u.m(e, n)) : u && (u.d(1), u = null), E & /*Icon*/
      1 && c !== (c = /*Icon*/
      D[0])) {
        if (r) {
          Sf();
          const F = r;
          pi(F.$$.fragment, 1, 0, () => {
            sa(F, 1);
          }), Df();
        }
        c ? (r = la(c, _()), oa(r.$$.fragment), mi(r.$$.fragment, 1), ua(r, i, l)) : r = null;
      }
      d && d.p && (!a || E & /*$$scope*/
      8192) && Lf(
        d,
        h,
        D,
        /*$$scope*/
        D[13],
        a ? Cf(
          h,
          /*$$scope*/
          D[13],
          E,
          null
        ) : Af(
          /*$$scope*/
          D[13]
        ),
        null
      ), (!a || E & /*size*/
      16) && se(
        i,
        "x-small",
        /*size*/
        D[4] === "x-small"
      ), (!a || E & /*size*/
      16) && se(
        i,
        "small",
        /*size*/
        D[4] === "small"
      ), (!a || E & /*size*/
      16) && se(
        i,
        "large",
        /*size*/
        D[4] === "large"
      ), (!a || E & /*size*/
      16) && se(
        i,
        "medium",
        /*size*/
        D[4] === "medium"
      ), (!a || E & /*disabled*/
      128) && (e.disabled = /*disabled*/
      D[7]), (!a || E & /*label*/
      2) && Ye(
        e,
        "aria-label",
        /*label*/
        D[1]
      ), (!a || E & /*hasPopup*/
      256) && Ye(
        e,
        "aria-haspopup",
        /*hasPopup*/
        D[8]
      ), (!a || E & /*label*/
      2) && Ye(
        e,
        "title",
        /*label*/
        D[1]
      ), (!a || E & /*pending*/
      8) && se(
        e,
        "pending",
        /*pending*/
        D[3]
      ), (!a || E & /*padded*/
      32) && se(
        e,
        "padded",
        /*padded*/
        D[5]
      ), (!a || E & /*highlight*/
      64) && se(
        e,
        "highlight",
        /*highlight*/
        D[6]
      ), (!a || E & /*transparent*/
      512) && se(
        e,
        "transparent",
        /*transparent*/
        D[9]
      ), E & /*disabled, _color*/
      2176 && vn(e, "color", !/*disabled*/
      D[7] && /*_color*/
      D[11] ? (
        /*_color*/
        D[11]
      ) : "var(--block-label-text-color)"), E & /*disabled, background*/
      1152 && vn(e, "--bg-color", /*disabled*/
      D[7] ? "auto" : (
        /*background*/
        D[10]
      ));
    },
    i(D) {
      a || (r && mi(r.$$.fragment, D), mi(d, D), a = !0);
    },
    o(D) {
      r && pi(r.$$.fragment, D), pi(d, D), a = !1;
    },
    d(D) {
      D && Vt(e), u && u.d(), r && sa(r), d && d.d(D), o = !1, s();
    }
  };
}
function Pf(t, e, n) {
  let i, { $$slots: r = {}, $$scope: l } = e, { Icon: a } = e, { label: o = "" } = e, { show_label: s = !1 } = e, { pending: u = !1 } = e, { size: c = "small" } = e, { padded: _ = !0 } = e, { highlight: h = !1 } = e, { disabled: d = !1 } = e, { hasPopup: D = !1 } = e, { color: E = "var(--block-label-text-color)" } = e, { transparent: F = !1 } = e, { background: C = "var(--block-background-fill)" } = e;
  function g(f) {
    wf.call(this, t, f);
  }
  return t.$$set = (f) => {
    "Icon" in f && n(0, a = f.Icon), "label" in f && n(1, o = f.label), "show_label" in f && n(2, s = f.show_label), "pending" in f && n(3, u = f.pending), "size" in f && n(4, c = f.size), "padded" in f && n(5, _ = f.padded), "highlight" in f && n(6, h = f.highlight), "disabled" in f && n(7, d = f.disabled), "hasPopup" in f && n(8, D = f.hasPopup), "color" in f && n(12, E = f.color), "transparent" in f && n(9, F = f.transparent), "background" in f && n(10, C = f.background), "$$scope" in f && n(13, l = f.$$scope);
  }, t.$$.update = () => {
    t.$$.dirty & /*highlight, color*/
    4160 && n(11, i = h ? "var(--color-accent)" : E);
  }, [
    a,
    o,
    s,
    u,
    c,
    _,
    h,
    d,
    D,
    F,
    C,
    i,
    E,
    l,
    r,
    g
  ];
}
class Nf extends yf {
  constructor(e) {
    super(), xf(this, e, Pf, Hf, $f, {
      Icon: 0,
      label: 1,
      show_label: 2,
      pending: 3,
      size: 4,
      padded: 5,
      highlight: 6,
      disabled: 7,
      hasPopup: 8,
      color: 12,
      transparent: 9,
      background: 10
    });
  }
}
const {
  SvelteComponent: Sm,
  append_hydration: xm,
  attr: Bm,
  binding_callbacks: $m,
  children: Tm,
  claim_element: Im,
  create_slot: Lm,
  detach: Hm,
  element: Pm,
  get_all_dirty_from_scope: Nm,
  get_slot_changes: Om,
  init: Rm,
  insert_hydration: Mm,
  safe_not_equal: qm,
  toggle_class: Um,
  transition_in: Gm,
  transition_out: zm,
  update_slot_base: jm
} = window.__gradio__svelte__internal, {
  SvelteComponent: Vm,
  append_hydration: Xm,
  attr: Zm,
  children: Wm,
  claim_svg_element: Qm,
  detach: Ym,
  init: Jm,
  insert_hydration: Km,
  noop: ep,
  safe_not_equal: tp,
  svg_element: np
} = window.__gradio__svelte__internal, {
  SvelteComponent: ip,
  append_hydration: rp,
  attr: ap,
  children: lp,
  claim_svg_element: op,
  detach: sp,
  init: up,
  insert_hydration: cp,
  noop: hp,
  safe_not_equal: fp,
  svg_element: _p
} = window.__gradio__svelte__internal, {
  SvelteComponent: dp,
  append_hydration: mp,
  attr: pp,
  children: gp,
  claim_svg_element: bp,
  detach: vp,
  init: yp,
  insert_hydration: wp,
  noop: Dp,
  safe_not_equal: Ep,
  svg_element: Fp
} = window.__gradio__svelte__internal, {
  SvelteComponent: kp,
  append_hydration: Ap,
  attr: Cp,
  children: Sp,
  claim_svg_element: xp,
  detach: Bp,
  init: $p,
  insert_hydration: Tp,
  noop: Ip,
  safe_not_equal: Lp,
  svg_element: Hp
} = window.__gradio__svelte__internal, {
  SvelteComponent: Pp,
  append_hydration: Np,
  attr: Op,
  children: Rp,
  claim_svg_element: Mp,
  detach: qp,
  init: Up,
  insert_hydration: Gp,
  noop: zp,
  safe_not_equal: jp,
  svg_element: Vp
} = window.__gradio__svelte__internal, {
  SvelteComponent: Xp,
  append_hydration: Zp,
  attr: Wp,
  children: Qp,
  claim_svg_element: Yp,
  detach: Jp,
  init: Kp,
  insert_hydration: e0,
  noop: t0,
  safe_not_equal: n0,
  svg_element: i0
} = window.__gradio__svelte__internal, {
  SvelteComponent: r0,
  append_hydration: a0,
  attr: l0,
  children: o0,
  claim_svg_element: s0,
  detach: u0,
  init: c0,
  insert_hydration: h0,
  noop: f0,
  safe_not_equal: _0,
  svg_element: d0
} = window.__gradio__svelte__internal, {
  SvelteComponent: m0,
  append_hydration: p0,
  attr: g0,
  children: b0,
  claim_svg_element: v0,
  detach: y0,
  init: w0,
  insert_hydration: D0,
  noop: E0,
  safe_not_equal: F0,
  svg_element: k0
} = window.__gradio__svelte__internal, {
  SvelteComponent: A0,
  append_hydration: C0,
  attr: S0,
  children: x0,
  claim_svg_element: B0,
  detach: $0,
  init: T0,
  insert_hydration: I0,
  noop: L0,
  safe_not_equal: H0,
  svg_element: P0
} = window.__gradio__svelte__internal, {
  SvelteComponent: N0,
  append_hydration: O0,
  attr: R0,
  children: M0,
  claim_svg_element: q0,
  detach: U0,
  init: G0,
  insert_hydration: z0,
  noop: j0,
  safe_not_equal: V0,
  svg_element: X0
} = window.__gradio__svelte__internal, {
  SvelteComponent: Z0,
  append_hydration: W0,
  attr: Q0,
  children: Y0,
  claim_svg_element: J0,
  detach: K0,
  init: eg,
  insert_hydration: tg,
  noop: ng,
  safe_not_equal: ig,
  svg_element: rg
} = window.__gradio__svelte__internal, {
  SvelteComponent: ag,
  append_hydration: lg,
  attr: og,
  children: sg,
  claim_svg_element: ug,
  detach: cg,
  init: hg,
  insert_hydration: fg,
  noop: _g,
  safe_not_equal: dg,
  svg_element: mg
} = window.__gradio__svelte__internal, {
  SvelteComponent: Of,
  append_hydration: gi,
  attr: Te,
  children: yn,
  claim_svg_element: wn,
  detach: Rt,
  init: Rf,
  insert_hydration: Mf,
  noop: bi,
  safe_not_equal: qf,
  set_style: Me,
  svg_element: Dn
} = window.__gradio__svelte__internal;
function Uf(t) {
  let e, n, i, r;
  return {
    c() {
      e = Dn("svg"), n = Dn("g"), i = Dn("path"), r = Dn("path"), this.h();
    },
    l(l) {
      e = wn(l, "svg", {
        width: !0,
        height: !0,
        viewBox: !0,
        version: !0,
        xmlns: !0,
        "xmlns:xlink": !0,
        "xml:space": !0,
        stroke: !0,
        style: !0
      });
      var a = yn(e);
      n = wn(a, "g", { transform: !0 });
      var o = yn(n);
      i = wn(o, "path", { d: !0, style: !0 }), yn(i).forEach(Rt), o.forEach(Rt), r = wn(a, "path", { d: !0, style: !0 }), yn(r).forEach(Rt), a.forEach(Rt), this.h();
    },
    h() {
      Te(i, "d", "M18,6L6.087,17.913"), Me(i, "fill", "none"), Me(i, "fill-rule", "nonzero"), Me(i, "stroke-width", "2px"), Te(n, "transform", "matrix(1.14096,-0.140958,-0.140958,1.14096,-0.0559523,0.0559523)"), Te(r, "d", "M4.364,4.364L19.636,19.636"), Me(r, "fill", "none"), Me(r, "fill-rule", "nonzero"), Me(r, "stroke-width", "2px"), Te(e, "width", "100%"), Te(e, "height", "100%"), Te(e, "viewBox", "0 0 24 24"), Te(e, "version", "1.1"), Te(e, "xmlns", "http://www.w3.org/2000/svg"), Te(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), Te(e, "xml:space", "preserve"), Te(e, "stroke", "currentColor"), Me(e, "fill-rule", "evenodd"), Me(e, "clip-rule", "evenodd"), Me(e, "stroke-linecap", "round"), Me(e, "stroke-linejoin", "round");
    },
    m(l, a) {
      Mf(l, e, a), gi(e, n), gi(n, i), gi(e, r);
    },
    p: bi,
    i: bi,
    o: bi,
    d(l) {
      l && Rt(e);
    }
  };
}
class Gf extends Of {
  constructor(e) {
    super(), Rf(this, e, null, Uf, qf, {});
  }
}
const {
  SvelteComponent: pg,
  append_hydration: gg,
  attr: bg,
  children: vg,
  claim_svg_element: yg,
  detach: wg,
  init: Dg,
  insert_hydration: Eg,
  noop: Fg,
  safe_not_equal: kg,
  svg_element: Ag
} = window.__gradio__svelte__internal, {
  SvelteComponent: Cg,
  append_hydration: Sg,
  attr: xg,
  children: Bg,
  claim_svg_element: $g,
  detach: Tg,
  init: Ig,
  insert_hydration: Lg,
  noop: Hg,
  safe_not_equal: Pg,
  svg_element: Ng
} = window.__gradio__svelte__internal, {
  SvelteComponent: Og,
  append_hydration: Rg,
  attr: Mg,
  children: qg,
  claim_svg_element: Ug,
  detach: Gg,
  init: zg,
  insert_hydration: jg,
  noop: Vg,
  safe_not_equal: Xg,
  svg_element: Zg
} = window.__gradio__svelte__internal, {
  SvelteComponent: Wg,
  append_hydration: Qg,
  attr: Yg,
  children: Jg,
  claim_svg_element: Kg,
  detach: e1,
  init: t1,
  insert_hydration: n1,
  noop: i1,
  safe_not_equal: r1,
  svg_element: a1
} = window.__gradio__svelte__internal, {
  SvelteComponent: l1,
  append_hydration: o1,
  attr: s1,
  children: u1,
  claim_svg_element: c1,
  detach: h1,
  init: f1,
  insert_hydration: _1,
  noop: d1,
  safe_not_equal: m1,
  svg_element: p1
} = window.__gradio__svelte__internal, {
  SvelteComponent: g1,
  append_hydration: b1,
  attr: v1,
  children: y1,
  claim_svg_element: w1,
  detach: D1,
  init: E1,
  insert_hydration: F1,
  noop: k1,
  safe_not_equal: A1,
  svg_element: C1
} = window.__gradio__svelte__internal, {
  SvelteComponent: S1,
  append_hydration: x1,
  attr: B1,
  children: $1,
  claim_svg_element: T1,
  detach: I1,
  init: L1,
  insert_hydration: H1,
  noop: P1,
  safe_not_equal: N1,
  svg_element: O1
} = window.__gradio__svelte__internal, {
  SvelteComponent: zf,
  append_hydration: jf,
  attr: vt,
  children: fa,
  claim_svg_element: _a,
  detach: vi,
  init: Vf,
  insert_hydration: Xf,
  noop: yi,
  safe_not_equal: Zf,
  svg_element: da
} = window.__gradio__svelte__internal;
function Wf(t) {
  let e, n;
  return {
    c() {
      e = da("svg"), n = da("path"), this.h();
    },
    l(i) {
      e = _a(i, "svg", {
        class: !0,
        xmlns: !0,
        width: !0,
        height: !0,
        viewBox: !0
      });
      var r = fa(e);
      n = _a(r, "path", { d: !0 }), fa(n).forEach(vi), r.forEach(vi), this.h();
    },
    h() {
      vt(n, "d", "M5 8l4 4 4-4z"), vt(e, "class", "dropdown-arrow svelte-145leq6"), vt(e, "xmlns", "http://www.w3.org/2000/svg"), vt(e, "width", "100%"), vt(e, "height", "100%"), vt(e, "viewBox", "0 0 18 18");
    },
    m(i, r) {
      Xf(i, e, r), jf(e, n);
    },
    p: yi,
    i: yi,
    o: yi,
    d(i) {
      i && vi(e);
    }
  };
}
class yo extends zf {
  constructor(e) {
    super(), Vf(this, e, null, Wf, Zf, {});
  }
}
const {
  SvelteComponent: R1,
  append_hydration: M1,
  attr: q1,
  children: U1,
  claim_svg_element: G1,
  detach: z1,
  init: j1,
  insert_hydration: V1,
  noop: X1,
  safe_not_equal: Z1,
  svg_element: W1
} = window.__gradio__svelte__internal, {
  SvelteComponent: Q1,
  append_hydration: Y1,
  attr: J1,
  children: K1,
  claim_svg_element: eb,
  detach: tb,
  init: nb,
  insert_hydration: ib,
  noop: rb,
  safe_not_equal: ab,
  svg_element: lb
} = window.__gradio__svelte__internal, {
  SvelteComponent: ob,
  append_hydration: sb,
  attr: ub,
  children: cb,
  claim_svg_element: hb,
  detach: fb,
  init: _b,
  insert_hydration: db,
  noop: mb,
  safe_not_equal: pb,
  svg_element: gb
} = window.__gradio__svelte__internal, {
  SvelteComponent: bb,
  append_hydration: vb,
  attr: yb,
  children: wb,
  claim_svg_element: Db,
  detach: Eb,
  init: Fb,
  insert_hydration: kb,
  noop: Ab,
  safe_not_equal: Cb,
  svg_element: Sb
} = window.__gradio__svelte__internal, {
  SvelteComponent: xb,
  append_hydration: Bb,
  attr: $b,
  children: Tb,
  claim_svg_element: Ib,
  detach: Lb,
  init: Hb,
  insert_hydration: Pb,
  noop: Nb,
  safe_not_equal: Ob,
  svg_element: Rb
} = window.__gradio__svelte__internal, {
  SvelteComponent: Mb,
  append_hydration: qb,
  attr: Ub,
  children: Gb,
  claim_svg_element: zb,
  detach: jb,
  init: Vb,
  insert_hydration: Xb,
  noop: Zb,
  safe_not_equal: Wb,
  svg_element: Qb
} = window.__gradio__svelte__internal, {
  SvelteComponent: Yb,
  append_hydration: Jb,
  attr: Kb,
  children: ev,
  claim_svg_element: tv,
  detach: nv,
  init: iv,
  insert_hydration: rv,
  noop: av,
  safe_not_equal: lv,
  svg_element: ov
} = window.__gradio__svelte__internal, {
  SvelteComponent: sv,
  append_hydration: uv,
  attr: cv,
  children: hv,
  claim_svg_element: fv,
  detach: _v,
  init: dv,
  insert_hydration: mv,
  noop: pv,
  safe_not_equal: gv,
  svg_element: bv
} = window.__gradio__svelte__internal, {
  SvelteComponent: vv,
  append_hydration: yv,
  attr: wv,
  children: Dv,
  claim_svg_element: Ev,
  detach: Fv,
  init: kv,
  insert_hydration: Av,
  noop: Cv,
  safe_not_equal: Sv,
  svg_element: xv
} = window.__gradio__svelte__internal, {
  SvelteComponent: Bv,
  append_hydration: $v,
  attr: Tv,
  children: Iv,
  claim_svg_element: Lv,
  detach: Hv,
  init: Pv,
  insert_hydration: Nv,
  noop: Ov,
  safe_not_equal: Rv,
  svg_element: Mv
} = window.__gradio__svelte__internal, {
  SvelteComponent: qv,
  append_hydration: Uv,
  attr: Gv,
  children: zv,
  claim_svg_element: jv,
  detach: Vv,
  init: Xv,
  insert_hydration: Zv,
  noop: Wv,
  safe_not_equal: Qv,
  svg_element: Yv
} = window.__gradio__svelte__internal, {
  SvelteComponent: Jv,
  append_hydration: Kv,
  attr: e2,
  children: t2,
  claim_svg_element: n2,
  detach: i2,
  init: r2,
  insert_hydration: a2,
  noop: l2,
  safe_not_equal: o2,
  svg_element: s2
} = window.__gradio__svelte__internal, {
  SvelteComponent: u2,
  append_hydration: c2,
  attr: h2,
  children: f2,
  claim_svg_element: _2,
  detach: d2,
  init: m2,
  insert_hydration: p2,
  noop: g2,
  safe_not_equal: b2,
  svg_element: v2
} = window.__gradio__svelte__internal, {
  SvelteComponent: y2,
  append_hydration: w2,
  attr: D2,
  children: E2,
  claim_svg_element: F2,
  detach: k2,
  init: A2,
  insert_hydration: C2,
  noop: S2,
  safe_not_equal: x2,
  svg_element: B2
} = window.__gradio__svelte__internal, {
  SvelteComponent: $2,
  append_hydration: T2,
  attr: I2,
  children: L2,
  claim_svg_element: H2,
  detach: P2,
  init: N2,
  insert_hydration: O2,
  noop: R2,
  safe_not_equal: M2,
  svg_element: q2
} = window.__gradio__svelte__internal, {
  SvelteComponent: U2,
  append_hydration: G2,
  attr: z2,
  children: j2,
  claim_svg_element: V2,
  detach: X2,
  init: Z2,
  insert_hydration: W2,
  noop: Q2,
  safe_not_equal: Y2,
  svg_element: J2
} = window.__gradio__svelte__internal, {
  SvelteComponent: K2,
  append_hydration: ey,
  attr: ty,
  children: ny,
  claim_svg_element: iy,
  detach: ry,
  init: ay,
  insert_hydration: ly,
  noop: oy,
  safe_not_equal: sy,
  svg_element: uy
} = window.__gradio__svelte__internal, {
  SvelteComponent: cy,
  append_hydration: hy,
  attr: fy,
  children: _y,
  claim_svg_element: dy,
  detach: my,
  init: py,
  insert_hydration: gy,
  noop: by,
  safe_not_equal: vy,
  svg_element: yy
} = window.__gradio__svelte__internal, {
  SvelteComponent: wy,
  append_hydration: Dy,
  attr: Ey,
  children: Fy,
  claim_svg_element: ky,
  detach: Ay,
  init: Cy,
  insert_hydration: Sy,
  noop: xy,
  safe_not_equal: By,
  svg_element: $y
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ty,
  append_hydration: Iy,
  attr: Ly,
  children: Hy,
  claim_svg_element: Py,
  detach: Ny,
  init: Oy,
  insert_hydration: Ry,
  noop: My,
  safe_not_equal: qy,
  svg_element: Uy
} = window.__gradio__svelte__internal, {
  SvelteComponent: Gy,
  append_hydration: zy,
  attr: jy,
  children: Vy,
  claim_svg_element: Xy,
  detach: Zy,
  init: Wy,
  insert_hydration: Qy,
  noop: Yy,
  safe_not_equal: Jy,
  svg_element: Ky
} = window.__gradio__svelte__internal, {
  SvelteComponent: ew,
  append_hydration: tw,
  attr: nw,
  children: iw,
  claim_svg_element: rw,
  detach: aw,
  init: lw,
  insert_hydration: ow,
  noop: sw,
  safe_not_equal: uw,
  svg_element: cw
} = window.__gradio__svelte__internal, {
  SvelteComponent: hw,
  append_hydration: fw,
  attr: _w,
  children: dw,
  claim_svg_element: mw,
  detach: pw,
  init: gw,
  insert_hydration: bw,
  noop: vw,
  safe_not_equal: yw,
  svg_element: ww
} = window.__gradio__svelte__internal, {
  SvelteComponent: Dw,
  append_hydration: Ew,
  attr: Fw,
  children: kw,
  claim_svg_element: Aw,
  detach: Cw,
  init: Sw,
  insert_hydration: xw,
  noop: Bw,
  safe_not_equal: $w,
  svg_element: Tw
} = window.__gradio__svelte__internal, {
  SvelteComponent: Iw,
  append_hydration: Lw,
  attr: Hw,
  children: Pw,
  claim_svg_element: Nw,
  detach: Ow,
  init: Rw,
  insert_hydration: Mw,
  noop: qw,
  safe_not_equal: Uw,
  svg_element: Gw
} = window.__gradio__svelte__internal, {
  SvelteComponent: zw,
  append_hydration: jw,
  attr: Vw,
  children: Xw,
  claim_svg_element: Zw,
  detach: Ww,
  init: Qw,
  insert_hydration: Yw,
  noop: Jw,
  safe_not_equal: Kw,
  set_style: eD,
  svg_element: tD
} = window.__gradio__svelte__internal, {
  SvelteComponent: Qf,
  append_hydration: Yf,
  attr: Mt,
  children: ma,
  claim_svg_element: pa,
  detach: wi,
  init: Jf,
  insert_hydration: Kf,
  noop: Di,
  safe_not_equal: e_,
  svg_element: ga
} = window.__gradio__svelte__internal;
function t_(t) {
  let e, n;
  return {
    c() {
      e = ga("svg"), n = ga("path"), this.h();
    },
    l(i) {
      e = pa(i, "svg", {
        xmlns: !0,
        viewBox: !0,
        width: !0,
        height: !0
      });
      var r = ma(e);
      n = pa(r, "path", { d: !0 }), ma(n).forEach(wi), r.forEach(wi), this.h();
    },
    h() {
      Mt(n, "d", "M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"), Mt(e, "xmlns", "http://www.w3.org/2000/svg"), Mt(e, "viewBox", "0 0 24 24"), Mt(e, "width", "100%"), Mt(e, "height", "100%");
    },
    m(i, r) {
      Kf(i, e, r), Yf(e, n);
    },
    p: Di,
    i: Di,
    o: Di,
    d(i) {
      i && wi(e);
    }
  };
}
class wo extends Qf {
  constructor(e) {
    super(), Jf(this, e, null, t_, e_, {});
  }
}
const {
  SvelteComponent: nD,
  append_hydration: iD,
  attr: rD,
  children: aD,
  claim_svg_element: lD,
  detach: oD,
  init: sD,
  insert_hydration: uD,
  noop: cD,
  safe_not_equal: hD,
  svg_element: fD
} = window.__gradio__svelte__internal, {
  SvelteComponent: _D,
  append_hydration: dD,
  attr: mD,
  children: pD,
  claim_svg_element: gD,
  detach: bD,
  init: vD,
  insert_hydration: yD,
  noop: wD,
  safe_not_equal: DD,
  svg_element: ED
} = window.__gradio__svelte__internal, {
  SvelteComponent: FD,
  append_hydration: kD,
  attr: AD,
  children: CD,
  claim_svg_element: SD,
  detach: xD,
  init: BD,
  insert_hydration: $D,
  noop: TD,
  safe_not_equal: ID,
  svg_element: LD
} = window.__gradio__svelte__internal, {
  SvelteComponent: HD,
  append_hydration: PD,
  attr: ND,
  children: OD,
  claim_svg_element: RD,
  detach: MD,
  init: qD,
  insert_hydration: UD,
  noop: GD,
  safe_not_equal: zD,
  svg_element: jD
} = window.__gradio__svelte__internal, {
  SvelteComponent: VD,
  append_hydration: XD,
  attr: ZD,
  children: WD,
  claim_svg_element: QD,
  detach: YD,
  init: JD,
  insert_hydration: KD,
  noop: eE,
  safe_not_equal: tE,
  svg_element: nE
} = window.__gradio__svelte__internal, {
  SvelteComponent: iE,
  append_hydration: rE,
  attr: aE,
  children: lE,
  claim_svg_element: oE,
  detach: sE,
  init: uE,
  insert_hydration: cE,
  noop: hE,
  safe_not_equal: fE,
  svg_element: _E
} = window.__gradio__svelte__internal, {
  SvelteComponent: dE,
  append_hydration: mE,
  attr: pE,
  children: gE,
  claim_svg_element: bE,
  detach: vE,
  init: yE,
  insert_hydration: wE,
  noop: DE,
  safe_not_equal: EE,
  svg_element: FE
} = window.__gradio__svelte__internal, {
  SvelteComponent: kE,
  append_hydration: AE,
  attr: CE,
  children: SE,
  claim_svg_element: xE,
  claim_text: BE,
  detach: $E,
  init: TE,
  insert_hydration: IE,
  noop: LE,
  safe_not_equal: HE,
  svg_element: PE,
  text: NE
} = window.__gradio__svelte__internal, {
  SvelteComponent: OE,
  append_hydration: RE,
  attr: ME,
  children: qE,
  claim_svg_element: UE,
  detach: GE,
  init: zE,
  insert_hydration: jE,
  noop: VE,
  safe_not_equal: XE,
  svg_element: ZE
} = window.__gradio__svelte__internal, {
  SvelteComponent: WE,
  append_hydration: QE,
  attr: YE,
  children: JE,
  claim_svg_element: KE,
  detach: eF,
  init: tF,
  insert_hydration: nF,
  noop: iF,
  safe_not_equal: rF,
  svg_element: aF
} = window.__gradio__svelte__internal, {
  SvelteComponent: lF,
  append_hydration: oF,
  attr: sF,
  children: uF,
  claim_svg_element: cF,
  detach: hF,
  init: fF,
  insert_hydration: _F,
  noop: dF,
  safe_not_equal: mF,
  svg_element: pF
} = window.__gradio__svelte__internal, {
  SvelteComponent: gF,
  append_hydration: bF,
  attr: vF,
  children: yF,
  claim_svg_element: wF,
  detach: DF,
  init: EF,
  insert_hydration: FF,
  noop: kF,
  safe_not_equal: AF,
  svg_element: CF
} = window.__gradio__svelte__internal, {
  SvelteComponent: SF,
  append_hydration: xF,
  attr: BF,
  children: $F,
  claim_svg_element: TF,
  detach: IF,
  init: LF,
  insert_hydration: HF,
  noop: PF,
  safe_not_equal: NF,
  svg_element: OF
} = window.__gradio__svelte__internal, {
  SvelteComponent: RF,
  append_hydration: MF,
  attr: qF,
  children: UF,
  claim_svg_element: GF,
  detach: zF,
  init: jF,
  insert_hydration: VF,
  noop: XF,
  safe_not_equal: ZF,
  svg_element: WF
} = window.__gradio__svelte__internal, {
  SvelteComponent: QF,
  append_hydration: YF,
  attr: JF,
  children: KF,
  claim_svg_element: ek,
  detach: tk,
  init: nk,
  insert_hydration: ik,
  noop: rk,
  safe_not_equal: ak,
  svg_element: lk
} = window.__gradio__svelte__internal, {
  SvelteComponent: ok,
  append_hydration: sk,
  attr: uk,
  children: ck,
  claim_svg_element: hk,
  claim_text: fk,
  detach: _k,
  init: dk,
  insert_hydration: mk,
  noop: pk,
  safe_not_equal: gk,
  svg_element: bk,
  text: vk
} = window.__gradio__svelte__internal, {
  SvelteComponent: yk,
  append_hydration: wk,
  attr: Dk,
  children: Ek,
  claim_svg_element: Fk,
  claim_text: kk,
  detach: Ak,
  init: Ck,
  insert_hydration: Sk,
  noop: xk,
  safe_not_equal: Bk,
  svg_element: $k,
  text: Tk
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ik,
  append_hydration: Lk,
  attr: Hk,
  children: Pk,
  claim_svg_element: Nk,
  claim_text: Ok,
  detach: Rk,
  init: Mk,
  insert_hydration: qk,
  noop: Uk,
  safe_not_equal: Gk,
  svg_element: zk,
  text: jk
} = window.__gradio__svelte__internal, {
  SvelteComponent: Vk,
  append_hydration: Xk,
  attr: Zk,
  children: Wk,
  claim_svg_element: Qk,
  detach: Yk,
  init: Jk,
  insert_hydration: Kk,
  noop: e3,
  safe_not_equal: t3,
  svg_element: n3
} = window.__gradio__svelte__internal, {
  SvelteComponent: i3,
  append_hydration: r3,
  attr: a3,
  children: l3,
  claim_svg_element: o3,
  detach: s3,
  init: u3,
  insert_hydration: c3,
  noop: h3,
  safe_not_equal: f3,
  svg_element: _3
} = window.__gradio__svelte__internal, {
  SvelteComponent: d3,
  append_hydration: m3,
  attr: p3,
  children: g3,
  claim_svg_element: b3,
  detach: v3,
  init: y3,
  insert_hydration: w3,
  noop: D3,
  safe_not_equal: E3,
  svg_element: F3
} = window.__gradio__svelte__internal, {
  SvelteComponent: k3,
  append_hydration: A3,
  attr: C3,
  children: S3,
  claim_svg_element: x3,
  detach: B3,
  init: $3,
  insert_hydration: T3,
  noop: I3,
  safe_not_equal: L3,
  svg_element: H3
} = window.__gradio__svelte__internal, {
  SvelteComponent: P3,
  append_hydration: N3,
  attr: O3,
  children: R3,
  claim_svg_element: M3,
  detach: q3,
  init: U3,
  insert_hydration: G3,
  noop: z3,
  safe_not_equal: j3,
  svg_element: V3
} = window.__gradio__svelte__internal, {
  SvelteComponent: X3,
  append_hydration: Z3,
  attr: W3,
  children: Q3,
  claim_svg_element: Y3,
  detach: J3,
  init: K3,
  insert_hydration: eA,
  noop: tA,
  safe_not_equal: nA,
  svg_element: iA
} = window.__gradio__svelte__internal, {
  SvelteComponent: rA,
  append_hydration: aA,
  attr: lA,
  children: oA,
  claim_svg_element: sA,
  detach: uA,
  init: cA,
  insert_hydration: hA,
  noop: fA,
  safe_not_equal: _A,
  svg_element: dA
} = window.__gradio__svelte__internal, {
  SvelteComponent: mA,
  append_hydration: pA,
  attr: gA,
  children: bA,
  claim_svg_element: vA,
  detach: yA,
  init: wA,
  insert_hydration: DA,
  noop: EA,
  safe_not_equal: FA,
  svg_element: kA
} = window.__gradio__svelte__internal, {
  SvelteComponent: AA,
  append_hydration: CA,
  attr: SA,
  children: xA,
  claim_svg_element: BA,
  detach: $A,
  init: TA,
  insert_hydration: IA,
  noop: LA,
  safe_not_equal: HA,
  svg_element: PA
} = window.__gradio__svelte__internal, {
  SvelteComponent: NA,
  append_hydration: OA,
  attr: RA,
  children: MA,
  claim_svg_element: qA,
  detach: UA,
  init: GA,
  insert_hydration: zA,
  noop: jA,
  safe_not_equal: VA,
  svg_element: XA
} = window.__gradio__svelte__internal, {
  SvelteComponent: ZA,
  append_hydration: WA,
  attr: QA,
  children: YA,
  claim_svg_element: JA,
  detach: KA,
  init: eC,
  insert_hydration: tC,
  noop: nC,
  safe_not_equal: iC,
  svg_element: rC
} = window.__gradio__svelte__internal, n_ = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], ba = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
n_.reduce(
  (t, { color: e, primary: n, secondary: i }) => ({
    ...t,
    [e]: {
      primary: ba[e][n],
      secondary: ba[e][i]
    }
  }),
  {}
);
const {
  SvelteComponent: aC,
  claim_component: lC,
  create_component: oC,
  destroy_component: sC,
  init: uC,
  mount_component: cC,
  safe_not_equal: hC,
  transition_in: fC,
  transition_out: _C
} = window.__gradio__svelte__internal, { createEventDispatcher: dC } = window.__gradio__svelte__internal, {
  SvelteComponent: mC,
  append_hydration: pC,
  attr: gC,
  check_outros: bC,
  children: vC,
  claim_component: yC,
  claim_element: wC,
  claim_space: DC,
  claim_text: EC,
  create_component: FC,
  destroy_component: kC,
  detach: AC,
  element: CC,
  empty: SC,
  group_outros: xC,
  init: BC,
  insert_hydration: $C,
  mount_component: TC,
  safe_not_equal: IC,
  set_data: LC,
  space: HC,
  text: PC,
  toggle_class: NC,
  transition_in: OC,
  transition_out: RC
} = window.__gradio__svelte__internal, {
  SvelteComponent: MC,
  attr: qC,
  children: UC,
  claim_element: GC,
  create_slot: zC,
  detach: jC,
  element: VC,
  get_all_dirty_from_scope: XC,
  get_slot_changes: ZC,
  init: WC,
  insert_hydration: QC,
  safe_not_equal: YC,
  toggle_class: JC,
  transition_in: KC,
  transition_out: eS,
  update_slot_base: tS
} = window.__gradio__svelte__internal, {
  SvelteComponent: nS,
  append_hydration: iS,
  attr: rS,
  check_outros: aS,
  children: lS,
  claim_component: oS,
  claim_element: sS,
  claim_space: uS,
  create_component: cS,
  destroy_component: hS,
  detach: fS,
  element: _S,
  empty: dS,
  group_outros: mS,
  init: pS,
  insert_hydration: gS,
  listen: bS,
  mount_component: vS,
  safe_not_equal: yS,
  space: wS,
  toggle_class: DS,
  transition_in: ES,
  transition_out: FS
} = window.__gradio__svelte__internal, {
  SvelteComponent: kS,
  attr: AS,
  children: CS,
  claim_element: SS,
  create_slot: xS,
  detach: BS,
  element: $S,
  get_all_dirty_from_scope: TS,
  get_slot_changes: IS,
  init: LS,
  insert_hydration: HS,
  null_to_empty: PS,
  safe_not_equal: NS,
  transition_in: OS,
  transition_out: RS,
  update_slot_base: MS
} = window.__gradio__svelte__internal, {
  SvelteComponent: qS,
  check_outros: US,
  claim_component: GS,
  create_component: zS,
  destroy_component: jS,
  detach: VS,
  empty: XS,
  group_outros: ZS,
  init: WS,
  insert_hydration: QS,
  mount_component: YS,
  noop: JS,
  safe_not_equal: KS,
  transition_in: e4,
  transition_out: t4
} = window.__gradio__svelte__internal, { createEventDispatcher: n4 } = window.__gradio__svelte__internal, {
  SvelteComponent: i_,
  add_render_callback: Do,
  append_hydration: En,
  attr: be,
  binding_callbacks: va,
  check_outros: r_,
  children: hr,
  claim_element: Nn,
  claim_space: zi,
  claim_text: a_,
  create_bidirectional_transition: ya,
  destroy_each: l_,
  detach: rt,
  element: On,
  empty: wa,
  ensure_array_like: Da,
  get_svelte_dataset: o_,
  group_outros: s_,
  init: u_,
  insert_hydration: Xt,
  listen: Rn,
  prevent_default: c_,
  run_all: Eo,
  safe_not_equal: h_,
  set_data: f_,
  set_style: Ue,
  space: ji,
  text: __,
  toggle_class: qe,
  transition_in: Ei,
  transition_out: Ea
} = window.__gradio__svelte__internal, { createEventDispatcher: d_ } = window.__gradio__svelte__internal;
function Fa(t, e, n) {
  const i = t.slice();
  return i[32] = e[n], i;
}
function ka(t) {
  let e, n, i, r, l, a = Da(
    /*filtered_indices*/
    t[1]
  ), o = [];
  for (let s = 0; s < a.length; s += 1)
    o[s] = Aa(Fa(t, a, s));
  return {
    c() {
      e = On("ul");
      for (let s = 0; s < o.length; s += 1)
        o[s].c();
      this.h();
    },
    l(s) {
      e = Nn(s, "UL", { class: !0, role: !0 });
      var u = hr(e);
      for (let c = 0; c < o.length; c += 1)
        o[c].l(u);
      u.forEach(rt), this.h();
    },
    h() {
      be(e, "class", "options svelte-wmd465"), be(e, "role", "listbox"), Ue(
        e,
        "top",
        /*top*/
        t[9]
      ), Ue(
        e,
        "bottom",
        /*bottom*/
        t[10]
      ), Ue(e, "max-height", `calc(${/*max_height*/
      t[11]}px - var(--window-padding))`), Ue(
        e,
        "width",
        /*input_width*/
        t[8] + "px"
      );
    },
    m(s, u) {
      Xt(s, e, u);
      for (let c = 0; c < o.length; c += 1)
        o[c] && o[c].m(e, null);
      t[28](e), i = !0, r || (l = [
        Rn(e, "mousedown", c_(
          /*mousedown_handler*/
          t[26]
        )),
        Rn(
          e,
          "scroll",
          /*scroll_handler*/
          t[27]
        )
      ], r = !0);
    },
    p(s, u) {
      if (u[0] & /*filtered_indices, choices, selected_indices, active_index, input_width*/
      307) {
        a = Da(
          /*filtered_indices*/
          s[1]
        );
        let c;
        for (c = 0; c < a.length; c += 1) {
          const _ = Fa(s, a, c);
          o[c] ? o[c].p(_, u) : (o[c] = Aa(_), o[c].c(), o[c].m(e, null));
        }
        for (; c < o.length; c += 1)
          o[c].d(1);
        o.length = a.length;
      }
      u[0] & /*top*/
      512 && Ue(
        e,
        "top",
        /*top*/
        s[9]
      ), u[0] & /*bottom*/
      1024 && Ue(
        e,
        "bottom",
        /*bottom*/
        s[10]
      ), u[0] & /*max_height*/
      2048 && Ue(e, "max-height", `calc(${/*max_height*/
      s[11]}px - var(--window-padding))`), u[0] & /*input_width*/
      256 && Ue(
        e,
        "width",
        /*input_width*/
        s[8] + "px"
      );
    },
    i(s) {
      i || (s && Do(() => {
        i && (n || (n = ya(e, vr, { duration: 200, y: 5 }, !0)), n.run(1));
      }), i = !0);
    },
    o(s) {
      s && (n || (n = ya(e, vr, { duration: 200, y: 5 }, !1)), n.run(0)), i = !1;
    },
    d(s) {
      s && rt(e), l_(o, s), t[28](null), s && n && n.end(), r = !1, Eo(l);
    }
  };
}
function Aa(t) {
  let e, n, i = "✓", r, l = (
    /*choices*/
    t[0][
      /*index*/
      t[32]
    ][0] + ""
  ), a, o, s, u, c;
  return {
    c() {
      e = On("li"), n = On("span"), n.textContent = i, r = ji(), a = __(l), o = ji(), this.h();
    },
    l(_) {
      e = Nn(_, "LI", {
        class: !0,
        "data-index": !0,
        "aria-label": !0,
        "data-testid": !0,
        role: !0,
        "aria-selected": !0
      });
      var h = hr(e);
      n = Nn(h, "SPAN", { class: !0, "data-svelte-h": !0 }), o_(n) !== "svelte-1id9b8g" && (n.textContent = i), r = zi(h), a = a_(h, l), o = zi(h), h.forEach(rt), this.h();
    },
    h() {
      be(n, "class", "inner-item svelte-wmd465"), qe(n, "hide", !/*selected_indices*/
      t[4].includes(
        /*index*/
        t[32]
      )), be(e, "class", "item svelte-wmd465"), be(e, "data-index", s = /*index*/
      t[32]), be(e, "aria-label", u = /*choices*/
      t[0][
        /*index*/
        t[32]
      ][0]), be(e, "data-testid", "dropdown-option"), be(e, "role", "option"), be(e, "aria-selected", c = /*selected_indices*/
      t[4].includes(
        /*index*/
        t[32]
      )), qe(
        e,
        "selected",
        /*selected_indices*/
        t[4].includes(
          /*index*/
          t[32]
        )
      ), qe(
        e,
        "active",
        /*index*/
        t[32] === /*active_index*/
        t[5]
      ), qe(
        e,
        "bg-gray-100",
        /*index*/
        t[32] === /*active_index*/
        t[5]
      ), qe(
        e,
        "dark:bg-gray-600",
        /*index*/
        t[32] === /*active_index*/
        t[5]
      ), Ue(
        e,
        "width",
        /*input_width*/
        t[8] + "px"
      );
    },
    m(_, h) {
      Xt(_, e, h), En(e, n), En(e, r), En(e, a), En(e, o);
    },
    p(_, h) {
      h[0] & /*selected_indices, filtered_indices*/
      18 && qe(n, "hide", !/*selected_indices*/
      _[4].includes(
        /*index*/
        _[32]
      )), h[0] & /*choices, filtered_indices*/
      3 && l !== (l = /*choices*/
      _[0][
        /*index*/
        _[32]
      ][0] + "") && f_(a, l), h[0] & /*filtered_indices*/
      2 && s !== (s = /*index*/
      _[32]) && be(e, "data-index", s), h[0] & /*choices, filtered_indices*/
      3 && u !== (u = /*choices*/
      _[0][
        /*index*/
        _[32]
      ][0]) && be(e, "aria-label", u), h[0] & /*selected_indices, filtered_indices*/
      18 && c !== (c = /*selected_indices*/
      _[4].includes(
        /*index*/
        _[32]
      )) && be(e, "aria-selected", c), h[0] & /*selected_indices, filtered_indices*/
      18 && qe(
        e,
        "selected",
        /*selected_indices*/
        _[4].includes(
          /*index*/
          _[32]
        )
      ), h[0] & /*filtered_indices, active_index*/
      34 && qe(
        e,
        "active",
        /*index*/
        _[32] === /*active_index*/
        _[5]
      ), h[0] & /*filtered_indices, active_index*/
      34 && qe(
        e,
        "bg-gray-100",
        /*index*/
        _[32] === /*active_index*/
        _[5]
      ), h[0] & /*filtered_indices, active_index*/
      34 && qe(
        e,
        "dark:bg-gray-600",
        /*index*/
        _[32] === /*active_index*/
        _[5]
      ), h[0] & /*input_width*/
      256 && Ue(
        e,
        "width",
        /*input_width*/
        _[8] + "px"
      );
    },
    d(_) {
      _ && rt(e);
    }
  };
}
function m_(t) {
  let e, n, i, r, l;
  Do(
    /*onwindowresize*/
    t[24]
  );
  let a = (
    /*show_options*/
    t[2] && !/*disabled*/
    t[3] && ka(t)
  );
  return {
    c() {
      e = On("div"), n = ji(), a && a.c(), i = wa(), this.h();
    },
    l(o) {
      e = Nn(o, "DIV", { class: !0 }), hr(e).forEach(rt), n = zi(o), a && a.l(o), i = wa(), this.h();
    },
    h() {
      be(e, "class", "reference");
    },
    m(o, s) {
      Xt(o, e, s), t[25](e), Xt(o, n, s), a && a.m(o, s), Xt(o, i, s), r || (l = [
        Rn(
          window,
          "scroll",
          /*scroll_listener*/
          t[14]
        ),
        Rn(
          window,
          "resize",
          /*onwindowresize*/
          t[24]
        )
      ], r = !0);
    },
    p(o, s) {
      /*show_options*/
      o[2] && !/*disabled*/
      o[3] ? a ? (a.p(o, s), s[0] & /*show_options, disabled*/
      12 && Ei(a, 1)) : (a = ka(o), a.c(), Ei(a, 1), a.m(i.parentNode, i)) : a && (s_(), Ea(a, 1, 1, () => {
        a = null;
      }), r_());
    },
    i(o) {
      Ei(a);
    },
    o(o) {
      Ea(a);
    },
    d(o) {
      o && (rt(e), rt(n), rt(i)), t[25](null), a && a.d(o), r = !1, Eo(l);
    }
  };
}
function p_(t, e, n) {
  var i, r;
  let { choices: l } = e, { filtered_indices: a } = e, { show_options: o = !1 } = e, { disabled: s = !1 } = e, { selected_indices: u = [] } = e, { active_index: c = null } = e, { remember_scroll: _ = !1 } = e, { offset_from_top: h = 0 } = e, { from_top: d = !1 } = e, D, E, F, C, g, f, m, v, p, b, k = 0;
  function y() {
    const { top: T, bottom: ee } = g.getBoundingClientRect();
    d ? n(21, D = h) : n(21, D = T), n(22, E = b - ee);
  }
  let w = null;
  function A() {
    o && (w !== null && clearTimeout(w), w = setTimeout(
      () => {
        y(), w = null;
      },
      10
    ));
  }
  function B() {
    var T;
    (T = f == null ? void 0 : f.scrollTo) === null || T === void 0 || T.call(f, 0, k);
  }
  const N = d_();
  function L() {
    n(12, b = window.innerHeight);
  }
  function R(T) {
    va[T ? "unshift" : "push"](() => {
      g = T, n(6, g);
    });
  }
  const M = (T) => N("change", T), J = (T) => n(13, k = T.currentTarget.scrollTop);
  function V(T) {
    va[T ? "unshift" : "push"](() => {
      f = T, n(7, f);
    });
  }
  return t.$$set = (T) => {
    "choices" in T && n(0, l = T.choices), "filtered_indices" in T && n(1, a = T.filtered_indices), "show_options" in T && n(2, o = T.show_options), "disabled" in T && n(3, s = T.disabled), "selected_indices" in T && n(4, u = T.selected_indices), "active_index" in T && n(5, c = T.active_index), "remember_scroll" in T && n(16, _ = T.remember_scroll), "offset_from_top" in T && n(17, h = T.offset_from_top), "from_top" in T && n(18, d = T.from_top);
  }, t.$$.update = () => {
    if (t.$$.dirty[0] & /*show_options, refElement, remember_scroll, listElement, selected_indices, _a, _b, distance_from_bottom, distance_from_top, from_top, input_height*/
    16580820) {
      if (o && g) {
        if (_)
          B();
        else if (f && u.length > 0) {
          let ee = f.querySelectorAll("li");
          for (const x of Array.from(ee))
            if (x.getAttribute("data-index") === u[0].toString()) {
              n(19, i = f == null ? void 0 : f.scrollTo) === null || i === void 0 || i.call(f, 0, x.offsetTop);
              break;
            }
        }
        y();
        const T = n(20, r = g.parentElement) === null || r === void 0 ? void 0 : r.getBoundingClientRect();
        n(23, F = (T == null ? void 0 : T.height) || 0), n(8, C = (T == null ? void 0 : T.width) || 0);
      }
      E > D || d ? (n(9, m = `${D}px`), n(11, p = E), n(10, v = null)) : (n(10, v = `${E + F}px`), n(11, p = D - F), n(9, m = null));
    }
  }, [
    l,
    a,
    o,
    s,
    u,
    c,
    g,
    f,
    C,
    m,
    v,
    p,
    b,
    k,
    A,
    N,
    _,
    h,
    d,
    i,
    r,
    D,
    E,
    F,
    L,
    R,
    M,
    J,
    V
  ];
}
class Fo extends i_ {
  constructor(e) {
    super(), u_(
      this,
      e,
      p_,
      m_,
      h_,
      {
        choices: 0,
        filtered_indices: 1,
        show_options: 2,
        disabled: 3,
        selected_indices: 4,
        active_index: 5,
        remember_scroll: 16,
        offset_from_top: 17,
        from_top: 18
      },
      null,
      [-1, -1]
    );
  }
}
function g_(t, e) {
  return (t % e + e) % e;
}
function Vi(t, e) {
  return t.reduce((n, i, r) => ((!e || i[0].toLowerCase().includes(e.toLowerCase())) && n.push(r), n), []);
}
function ko(t, e, n) {
  t("change", e), n || t("input");
}
function Ao(t, e, n) {
  if (t.key === "Escape")
    return [!1, e];
  if ((t.key === "ArrowDown" || t.key === "ArrowUp") && n.length > 0)
    if (e === null)
      e = t.key === "ArrowDown" ? n[0] : n[n.length - 1];
    else {
      const i = n.indexOf(e), r = t.key === "ArrowUp" ? -1 : 1;
      e = n[g_(i + r, n.length)];
    }
  return [!0, e];
}
const {
  SvelteComponent: b_,
  action_destroyer: v_,
  append_hydration: le,
  attr: X,
  binding_callbacks: Fi,
  check_outros: Mn,
  children: me,
  claim_component: Yt,
  claim_element: ce,
  claim_space: Je,
  claim_text: on,
  create_component: Jt,
  destroy_component: Kt,
  destroy_each: y_,
  detach: Q,
  element: he,
  ensure_array_like: Ca,
  get_svelte_dataset: w_,
  group_outros: qn,
  init: D_,
  insert_hydration: xe,
  listen: we,
  mount_component: en,
  prevent_default: Sa,
  run_all: Yn,
  safe_not_equal: E_,
  set_data: sn,
  set_input_value: xa,
  space: Ke,
  text: un,
  toggle_class: yt,
  transition_in: oe,
  transition_out: ye
} = window.__gradio__svelte__internal, { afterUpdate: F_, createEventDispatcher: k_, tick: A_ } = window.__gradio__svelte__internal;
function Ba(t, e, n) {
  const i = t.slice();
  return i[50] = e[n], i;
}
function C_(t) {
  let e;
  return {
    c() {
      e = un(
        /*label*/
        t[0]
      );
    },
    l(n) {
      e = on(
        n,
        /*label*/
        t[0]
      );
    },
    m(n, i) {
      xe(n, e, i);
    },
    p(n, i) {
      i[0] & /*label*/
      1 && sn(
        e,
        /*label*/
        n[0]
      );
    },
    d(n) {
      n && Q(e);
    }
  };
}
function $a(t) {
  let e, n, i = "?", r, l, a, o = (
    /*show_tooltip*/
    t[18] && Ta(t)
  );
  return {
    c() {
      e = he("div"), n = he("span"), n.textContent = i, r = Ke(), o && o.c(), this.h();
    },
    l(s) {
      e = ce(s, "DIV", {
        class: !0,
        role: !0,
        tabindex: !0,
        "aria-label": !0
      });
      var u = me(e);
      n = ce(u, "SPAN", { class: !0, "data-svelte-h": !0 }), w_(n) !== "svelte-ekz8yf" && (n.textContent = i), r = Je(u), o && o.l(u), u.forEach(Q), this.h();
    },
    h() {
      X(n, "class", "tooltip-icon svelte-1v1y8ad"), X(e, "class", "tooltip-container svelte-1v1y8ad"), X(e, "role", "button"), X(e, "tabindex", "0"), X(e, "aria-label", "Help");
    },
    m(s, u) {
      xe(s, e, u), le(e, n), t[36](n), le(e, r), o && o.m(e, null), l || (a = [
        we(
          e,
          "mouseenter",
          /*handle_show_tooltip*/
          t[22]
        ),
        we(
          e,
          "mouseleave",
          /*mouseleave_handler*/
          t[38]
        ),
        we(
          e,
          "focusin",
          /*handle_show_tooltip*/
          t[22]
        ),
        we(
          e,
          "focusout",
          /*focusout_handler*/
          t[39]
        )
      ], l = !0);
    },
    p(s, u) {
      /*show_tooltip*/
      s[18] ? o ? o.p(s, u) : (o = Ta(s), o.c(), o.m(e, null)) : o && (o.d(1), o = null);
    },
    d(s) {
      s && Q(e), t[36](null), o && o.d(), l = !1, Yn(a);
    }
  };
}
function Ta(t) {
  let e, n, i, r;
  return {
    c() {
      e = he("span"), n = un(
        /*help*/
        t[2]
      ), this.h();
    },
    l(l) {
      e = ce(l, "SPAN", { class: !0 });
      var a = me(e);
      n = on(
        a,
        /*help*/
        t[2]
      ), a.forEach(Q), this.h();
    },
    h() {
      X(e, "class", "tooltip-text svelte-1v1y8ad");
    },
    m(l, a) {
      xe(l, e, a), le(e, n), t[37](e), i || (r = v_($_.call(null, e)), i = !0);
    },
    p(l, a) {
      a[0] & /*help*/
      4 && sn(
        n,
        /*help*/
        l[2]
      );
    },
    d(l) {
      l && Q(e), t[37](null), i = !1, r();
    }
  };
}
function Ia(t) {
  let e, n;
  return {
    c() {
      e = he("div"), n = un(
        /*info*/
        t[1]
      ), this.h();
    },
    l(i) {
      e = ce(i, "DIV", { class: !0 });
      var r = me(e);
      n = on(
        r,
        /*info*/
        t[1]
      ), r.forEach(Q), this.h();
    },
    h() {
      X(e, "class", "info-text svelte-1v1y8ad");
    },
    m(i, r) {
      xe(i, e, r), le(e, n);
    },
    p(i, r) {
      r[0] & /*info*/
      2 && sn(
        n,
        /*info*/
        i[1]
      );
    },
    d(i) {
      i && Q(e);
    }
  };
}
function S_(t) {
  let e = (
    /*s*/
    t[50] + ""
  ), n;
  return {
    c() {
      n = un(e);
    },
    l(i) {
      n = on(i, e);
    },
    m(i, r) {
      xe(i, n, r);
    },
    p(i, r) {
      r[0] & /*selected_indices*/
      8192 && e !== (e = /*s*/
      i[50] + "") && sn(n, e);
    },
    d(i) {
      i && Q(n);
    }
  };
}
function x_(t) {
  let e = (
    /*choices_names*/
    t[16][
      /*s*/
      t[50]
    ] + ""
  ), n;
  return {
    c() {
      n = un(e);
    },
    l(i) {
      n = on(i, e);
    },
    m(i, r) {
      xe(i, n, r);
    },
    p(i, r) {
      r[0] & /*choices_names, selected_indices*/
      73728 && e !== (e = /*choices_names*/
      i[16][
        /*s*/
        i[50]
      ] + "") && sn(n, e);
    },
    d(i) {
      i && Q(n);
    }
  };
}
function La(t) {
  let e, n, i, r, l, a;
  n = new wo({});
  function o() {
    return (
      /*click_handler*/
      t[40](
        /*s*/
        t[50]
      )
    );
  }
  function s(...u) {
    return (
      /*keydown_handler*/
      t[41](
        /*s*/
        t[50],
        ...u
      )
    );
  }
  return {
    c() {
      e = he("div"), Jt(n.$$.fragment), this.h();
    },
    l(u) {
      e = ce(u, "DIV", {
        class: !0,
        role: !0,
        tabindex: !0,
        title: !0
      });
      var c = me(e);
      Yt(n.$$.fragment, c), c.forEach(Q), this.h();
    },
    h() {
      X(e, "class", "token-remove svelte-1v1y8ad"), X(e, "role", "button"), X(e, "tabindex", "0"), X(e, "title", i = /*i18n*/
      t[10]("common.remove") + " " + /*s*/
      t[50]);
    },
    m(u, c) {
      xe(u, e, c), en(n, e, null), r = !0, l || (a = [
        we(e, "click", Sa(o)),
        we(e, "keydown", Sa(s))
      ], l = !0);
    },
    p(u, c) {
      t = u, (!r || c[0] & /*i18n, selected_indices*/
      9216 && i !== (i = /*i18n*/
      t[10]("common.remove") + " " + /*s*/
      t[50])) && X(e, "title", i);
    },
    i(u) {
      r || (oe(n.$$.fragment, u), r = !0);
    },
    o(u) {
      ye(n.$$.fragment, u), r = !1;
    },
    d(u) {
      u && Q(e), Kt(n), l = !1, Yn(a);
    }
  };
}
function Ha(t) {
  let e, n, i, r;
  function l(u, c) {
    return typeof /*s*/
    u[50] == "number" ? x_ : S_;
  }
  let a = l(t), o = a(t), s = !/*disabled*/
  t[5] && La(t);
  return {
    c() {
      e = he("div"), n = he("span"), o.c(), i = Ke(), s && s.c(), this.h();
    },
    l(u) {
      e = ce(u, "DIV", { class: !0 });
      var c = me(e);
      n = ce(c, "SPAN", { class: !0 });
      var _ = me(n);
      o.l(_), _.forEach(Q), i = Je(c), s && s.l(c), c.forEach(Q), this.h();
    },
    h() {
      X(n, "class", "svelte-1v1y8ad"), X(e, "class", "token svelte-1v1y8ad");
    },
    m(u, c) {
      xe(u, e, c), le(e, n), o.m(n, null), le(e, i), s && s.m(e, null), r = !0;
    },
    p(u, c) {
      a === (a = l(u)) && o ? o.p(u, c) : (o.d(1), o = a(u), o && (o.c(), o.m(n, null))), /*disabled*/
      u[5] ? s && (qn(), ye(s, 1, 1, () => {
        s = null;
      }), Mn()) : s ? (s.p(u, c), c[0] & /*disabled*/
      32 && oe(s, 1)) : (s = La(u), s.c(), oe(s, 1), s.m(e, null));
    },
    i(u) {
      r || (oe(s), r = !0);
    },
    o(u) {
      ye(s), r = !1;
    },
    d(u) {
      u && Q(e), o.d(), s && s.d();
    }
  };
}
function Pa(t) {
  let e, n, i, r, l = (
    /*selected_indices*/
    t[13].length > 0 && Na(t)
  );
  return i = new yo({}), {
    c() {
      l && l.c(), e = Ke(), n = he("span"), Jt(i.$$.fragment), this.h();
    },
    l(a) {
      l && l.l(a), e = Je(a), n = ce(a, "SPAN", { class: !0 });
      var o = me(n);
      Yt(i.$$.fragment, o), o.forEach(Q), this.h();
    },
    h() {
      X(n, "class", "icon-wrap svelte-1v1y8ad");
    },
    m(a, o) {
      l && l.m(a, o), xe(a, e, o), xe(a, n, o), en(i, n, null), r = !0;
    },
    p(a, o) {
      /*selected_indices*/
      a[13].length > 0 ? l ? (l.p(a, o), o[0] & /*selected_indices*/
      8192 && oe(l, 1)) : (l = Na(a), l.c(), oe(l, 1), l.m(e.parentNode, e)) : l && (qn(), ye(l, 1, 1, () => {
        l = null;
      }), Mn());
    },
    i(a) {
      r || (oe(l), oe(i.$$.fragment, a), r = !0);
    },
    o(a) {
      ye(l), ye(i.$$.fragment, a), r = !1;
    },
    d(a) {
      a && (Q(e), Q(n)), l && l.d(a), Kt(i);
    }
  };
}
function Na(t) {
  let e, n, i, r, l, a;
  return n = new wo({}), {
    c() {
      e = he("div"), Jt(n.$$.fragment), this.h();
    },
    l(o) {
      e = ce(o, "DIV", {
        role: !0,
        tabindex: !0,
        class: !0,
        title: !0
      });
      var s = me(e);
      Yt(n.$$.fragment, s), s.forEach(Q), this.h();
    },
    h() {
      X(e, "role", "button"), X(e, "tabindex", "0"), X(e, "class", "token-remove remove-all svelte-1v1y8ad"), X(e, "title", i = /*i18n*/
      t[10]("common.clear"));
    },
    m(o, s) {
      xe(o, e, s), en(n, e, null), r = !0, l || (a = [
        we(
          e,
          "click",
          /*remove_all*/
          t[26]
        ),
        we(
          e,
          "keydown",
          /*keydown_handler_1*/
          t[45]
        )
      ], l = !0);
    },
    p(o, s) {
      (!r || s[0] & /*i18n*/
      1024 && i !== (i = /*i18n*/
      o[10]("common.clear"))) && X(e, "title", i);
    },
    i(o) {
      r || (oe(n.$$.fragment, o), r = !0);
    },
    o(o) {
      ye(n.$$.fragment, o), r = !1;
    },
    d(o) {
      o && Q(e), Kt(n), l = !1, Yn(a);
    }
  };
}
function B_(t) {
  let e, n, i, r, l, a, o, s, u, c, _, h, d, D, E, F, C, g, f;
  r = new bo({
    props: {
      show_label: (
        /*show_label*/
        t[6]
      ),
      info: void 0,
      $$slots: { default: [C_] },
      $$scope: { ctx: t }
    }
  });
  let m = (
    /*help*/
    t[2] && /*show_label*/
    t[6] && $a(t)
  ), v = (
    /*info*/
    t[1] && /*show_label*/
    t[6] && Ia(t)
  ), p = Ca(
    /*selected_indices*/
    t[13]
  ), b = [];
  for (let w = 0; w < p.length; w += 1)
    b[w] = Ha(Ba(t, p, w));
  const k = (w) => ye(b[w], 1, 1, () => {
    b[w] = null;
  });
  let y = !/*disabled*/
  t[5] && Pa(t);
  return F = new Fo({
    props: {
      show_options: (
        /*show_options*/
        t[15]
      ),
      choices: (
        /*choices*/
        t[4]
      ),
      filtered_indices: (
        /*filtered_indices*/
        t[12]
      ),
      disabled: (
        /*disabled*/
        t[5]
      ),
      selected_indices: (
        /*selected_indices*/
        t[13]
      ),
      active_index: (
        /*active_index*/
        t[17]
      ),
      remember_scroll: !0
    }
  }), F.$on(
    "change",
    /*handle_option_selected*/
    t[25]
  ), {
    c() {
      e = he("label"), n = he("div"), i = he("div"), Jt(r.$$.fragment), l = Ke(), m && m.c(), a = Ke(), v && v.c(), o = Ke(), s = he("div"), u = he("div");
      for (let w = 0; w < b.length; w += 1)
        b[w].c();
      c = Ke(), _ = he("div"), h = he("input"), D = Ke(), y && y.c(), E = Ke(), Jt(F.$$.fragment), this.h();
    },
    l(w) {
      e = ce(w, "LABEL", { class: !0 });
      var A = me(e);
      n = ce(A, "DIV", { class: !0 });
      var B = me(n);
      i = ce(B, "DIV", { class: !0 });
      var N = me(i);
      Yt(r.$$.fragment, N), l = Je(N), m && m.l(N), N.forEach(Q), a = Je(B), v && v.l(B), B.forEach(Q), o = Je(A), s = ce(A, "DIV", { class: !0 });
      var L = me(s);
      u = ce(L, "DIV", { class: !0 });
      var R = me(u);
      for (let J = 0; J < b.length; J += 1)
        b[J].l(R);
      c = Je(R), _ = ce(R, "DIV", { class: !0 });
      var M = me(_);
      h = ce(M, "INPUT", { class: !0, autocomplete: !0 }), D = Je(M), y && y.l(M), M.forEach(Q), R.forEach(Q), E = Je(L), Yt(F.$$.fragment, L), L.forEach(Q), A.forEach(Q), this.h();
    },
    h() {
      X(i, "class", "title-line svelte-1v1y8ad"), X(n, "class", "label-container svelte-1v1y8ad"), X(h, "class", "border-none svelte-1v1y8ad"), h.disabled = /*disabled*/
      t[5], X(h, "autocomplete", "off"), h.readOnly = d = !/*filterable*/
      t[9], yt(h, "subdued", !/*choices_names*/
      t[16].includes(
        /*input_text*/
        t[11]
      ) && !/*allow_custom_value*/
      t[8] || /*selected_indices*/
      t[13].length === /*max_choices*/
      t[3]), X(_, "class", "secondary-wrap svelte-1v1y8ad"), X(u, "class", "wrap-inner svelte-1v1y8ad"), yt(
        u,
        "show_options",
        /*show_options*/
        t[15]
      ), X(s, "class", "wrap svelte-1v1y8ad"), X(e, "class", "svelte-1v1y8ad"), yt(
        e,
        "container",
        /*container*/
        t[7]
      );
    },
    m(w, A) {
      xe(w, e, A), le(e, n), le(n, i), en(r, i, null), le(i, l), m && m.m(i, null), le(n, a), v && v.m(n, null), le(e, o), le(e, s), le(s, u);
      for (let B = 0; B < b.length; B += 1)
        b[B] && b[B].m(u, null);
      le(u, c), le(u, _), le(_, h), xa(
        h,
        /*input_text*/
        t[11]
      ), t[43](h), le(_, D), y && y.m(_, null), le(s, E), en(F, s, null), C = !0, g || (f = [
        we(
          h,
          "input",
          /*input_input_handler*/
          t[42]
        ),
        we(
          h,
          "keydown",
          /*handle_key_down*/
          t[28]
        ),
        we(
          h,
          "keyup",
          /*keyup_handler*/
          t[44]
        ),
        we(
          h,
          "blur",
          /*handle_blur*/
          t[23]
        ),
        we(
          h,
          "focus",
          /*handle_focus*/
          t[27]
        )
      ], g = !0);
    },
    p(w, A) {
      const B = {};
      if (A[0] & /*show_label*/
      64 && (B.show_label = /*show_label*/
      w[6]), A[0] & /*label*/
      1 | A[1] & /*$$scope*/
      4194304 && (B.$$scope = { dirty: A, ctx: w }), r.$set(B), /*help*/
      w[2] && /*show_label*/
      w[6] ? m ? m.p(w, A) : (m = $a(w), m.c(), m.m(i, null)) : m && (m.d(1), m = null), /*info*/
      w[1] && /*show_label*/
      w[6] ? v ? v.p(w, A) : (v = Ia(w), v.c(), v.m(n, null)) : v && (v.d(1), v = null), A[0] & /*i18n, selected_indices, remove_selected_choice, disabled, choices_names*/
      16852e3) {
        p = Ca(
          /*selected_indices*/
          w[13]
        );
        let L;
        for (L = 0; L < p.length; L += 1) {
          const R = Ba(w, p, L);
          b[L] ? (b[L].p(R, A), oe(b[L], 1)) : (b[L] = Ha(R), b[L].c(), oe(b[L], 1), b[L].m(u, c));
        }
        for (qn(), L = p.length; L < b.length; L += 1)
          k(L);
        Mn();
      }
      (!C || A[0] & /*disabled*/
      32) && (h.disabled = /*disabled*/
      w[5]), (!C || A[0] & /*filterable*/
      512 && d !== (d = !/*filterable*/
      w[9])) && (h.readOnly = d), A[0] & /*input_text*/
      2048 && h.value !== /*input_text*/
      w[11] && xa(
        h,
        /*input_text*/
        w[11]
      ), (!C || A[0] & /*choices_names, input_text, allow_custom_value, selected_indices, max_choices*/
      76040) && yt(h, "subdued", !/*choices_names*/
      w[16].includes(
        /*input_text*/
        w[11]
      ) && !/*allow_custom_value*/
      w[8] || /*selected_indices*/
      w[13].length === /*max_choices*/
      w[3]), /*disabled*/
      w[5] ? y && (qn(), ye(y, 1, 1, () => {
        y = null;
      }), Mn()) : y ? (y.p(w, A), A[0] & /*disabled*/
      32 && oe(y, 1)) : (y = Pa(w), y.c(), oe(y, 1), y.m(_, null)), (!C || A[0] & /*show_options*/
      32768) && yt(
        u,
        "show_options",
        /*show_options*/
        w[15]
      );
      const N = {};
      A[0] & /*show_options*/
      32768 && (N.show_options = /*show_options*/
      w[15]), A[0] & /*choices*/
      16 && (N.choices = /*choices*/
      w[4]), A[0] & /*filtered_indices*/
      4096 && (N.filtered_indices = /*filtered_indices*/
      w[12]), A[0] & /*disabled*/
      32 && (N.disabled = /*disabled*/
      w[5]), A[0] & /*selected_indices*/
      8192 && (N.selected_indices = /*selected_indices*/
      w[13]), A[0] & /*active_index*/
      131072 && (N.active_index = /*active_index*/
      w[17]), F.$set(N), (!C || A[0] & /*container*/
      128) && yt(
        e,
        "container",
        /*container*/
        w[7]
      );
    },
    i(w) {
      if (!C) {
        oe(r.$$.fragment, w);
        for (let A = 0; A < p.length; A += 1)
          oe(b[A]);
        oe(y), oe(F.$$.fragment, w), C = !0;
      }
    },
    o(w) {
      ye(r.$$.fragment, w), b = b.filter(Boolean);
      for (let A = 0; A < b.length; A += 1)
        ye(b[A]);
      ye(y), ye(F.$$.fragment, w), C = !1;
    },
    d(w) {
      w && Q(e), Kt(r), m && m.d(), v && v.d(), y_(b, w), t[43](null), y && y.d(), Kt(F), g = !1, Yn(f);
    }
  };
}
function $_(t) {
  return document.body.appendChild(t), {
    destroy() {
      t.parentNode && t.parentNode.removeChild(t);
    }
  };
}
function T_(t, e, n) {
  let { label: i } = e, { info: r = void 0 } = e, { help: l = void 0 } = e, { value: a = [] } = e, o = [], { value_is_output: s = !1 } = e, { max_choices: u = null } = e, { choices: c } = e, _, { disabled: h = !1 } = e, { show_label: d } = e, { container: D = !0 } = e, { allow_custom_value: E = !1 } = e, { filterable: F = !0 } = e, { i18n: C } = e, g, f = "", m = "", v = !1, p, b, k = [], y = null, w = [], A = [], B = !1, N, L;
  const R = k_();
  Array.isArray(a) && a.forEach((S) => {
    const De = c.map((ni) => ni[1]).indexOf(S);
    De !== -1 ? w.push(De) : w.push(S);
  });
  function M() {
    if (!N || !L) return;
    const S = L.getBoundingClientRect();
    n(19, N.style.position = "fixed", N), n(19, N.style.left = `${S.right + 8}px`, N), n(19, N.style.top = `${S.top}px`, N);
  }
  function J() {
    n(18, B = !0), A_().then(M);
  }
  function V() {
    E || n(11, f = ""), E && f !== "" && (ee(f), n(11, f = "")), n(15, v = !1), n(17, y = null), R("blur");
  }
  function T(S) {
    n(13, w = w.filter((De) => De !== S)), R("select", {
      index: typeof S == "number" ? S : -1,
      value: typeof S == "number" ? b[S] : S,
      selected: !1
    });
  }
  function ee(S) {
    (u === null || w.length < u) && (n(13, w = [...w, S]), R("select", {
      index: typeof S == "number" ? S : -1,
      value: typeof S == "number" ? b[S] : S,
      selected: !0
    })), w.length === u && (n(15, v = !1), n(17, y = null), g.blur());
  }
  function x(S) {
    const De = parseInt(S.detail.target.dataset.index);
    te(De);
  }
  function te(S) {
    w.includes(S) ? T(S) : ee(S), n(11, f = "");
  }
  function pe(S) {
    n(13, w = []), n(11, f = ""), S.preventDefault();
  }
  function $(S) {
    n(12, k = c.map((De, ni) => ni)), (u === null || w.length < u) && n(15, v = !0), R("focus");
  }
  function I(S) {
    n(15, [v, y] = Ao(S, y, k), v, (n(17, y), n(4, c), n(32, _), n(11, f), n(33, m), n(8, E), n(12, k))), S.key === "Enter" && (y !== null ? te(y) : E && (ee(f), n(11, f = ""))), S.key === "Backspace" && f === "" && n(13, w = [...w.slice(0, -1)]), w.length === u && (n(15, v = !1), n(17, y = null));
  }
  function Re() {
    a === void 0 ? n(13, w = []) : Array.isArray(a) && n(13, w = a.map((S) => {
      const De = b.indexOf(S);
      if (De !== -1)
        return De;
      if (E)
        return S;
    }).filter((S) => S !== void 0));
  }
  F_(() => {
    n(30, s = !1);
  });
  function tt(S) {
    Fi[S ? "unshift" : "push"](() => {
      L = S, n(20, L);
    });
  }
  function lt(S) {
    Fi[S ? "unshift" : "push"](() => {
      N = S, n(19, N);
    });
  }
  const pt = () => n(18, B = !1), ot = () => n(18, B = !1), H = (S) => T(S), cn = (S, De) => {
    De.key === "Enter" && T(S);
  };
  function st() {
    f = this.value, n(11, f);
  }
  function Oo(S) {
    Fi[S ? "unshift" : "push"](() => {
      g = S, n(14, g);
    });
  }
  const Ro = (S) => R("key_up", { key: S.key, input_value: f }), Mo = (S) => {
    S.key === "Enter" && pe(S);
  };
  return t.$$set = (S) => {
    "label" in S && n(0, i = S.label), "info" in S && n(1, r = S.info), "help" in S && n(2, l = S.help), "value" in S && n(29, a = S.value), "value_is_output" in S && n(30, s = S.value_is_output), "max_choices" in S && n(3, u = S.max_choices), "choices" in S && n(4, c = S.choices), "disabled" in S && n(5, h = S.disabled), "show_label" in S && n(6, d = S.show_label), "container" in S && n(7, D = S.container), "allow_custom_value" in S && n(8, E = S.allow_custom_value), "filterable" in S && n(9, F = S.filterable), "i18n" in S && n(10, C = S.i18n);
  }, t.$$.update = () => {
    t.$$.dirty[0] & /*choices*/
    16 && (n(16, p = c.map((S) => S[0])), n(34, b = c.map((S) => S[1]))), t.$$.dirty[0] & /*choices, input_text, allow_custom_value, filtered_indices*/
    6416 | t.$$.dirty[1] & /*old_choices, old_input_text*/
    6 && (c !== _ || f !== m) && (n(12, k = Vi(c, f)), n(32, _ = c), n(33, m = f), E || n(17, y = k[0])), t.$$.dirty[0] & /*selected_indices*/
    8192 | t.$$.dirty[1] & /*old_selected_index, choices_values*/
    24 && JSON.stringify(w) != JSON.stringify(A) && (n(29, a = w.map((S) => typeof S == "number" ? b[S] : S)), n(35, A = w.slice())), t.$$.dirty[0] & /*value, value_is_output*/
    1610612736 | t.$$.dirty[1] & /*old_value*/
    1 && JSON.stringify(a) != JSON.stringify(o) && (ko(R, a, s), n(31, o = Array.isArray(a) ? a.slice() : a)), t.$$.dirty[0] & /*value*/
    536870912 && Re();
  }, [
    i,
    r,
    l,
    u,
    c,
    h,
    d,
    D,
    E,
    F,
    C,
    f,
    k,
    w,
    g,
    v,
    p,
    y,
    B,
    N,
    L,
    R,
    J,
    V,
    T,
    x,
    pe,
    $,
    I,
    a,
    s,
    o,
    _,
    m,
    b,
    A,
    tt,
    lt,
    pt,
    ot,
    H,
    cn,
    st,
    Oo,
    Ro,
    Mo
  ];
}
class I_ extends b_ {
  constructor(e) {
    super(), D_(
      this,
      e,
      T_,
      B_,
      E_,
      {
        label: 0,
        info: 1,
        help: 2,
        value: 29,
        value_is_output: 30,
        max_choices: 3,
        choices: 4,
        disabled: 5,
        show_label: 6,
        container: 7,
        allow_custom_value: 8,
        filterable: 9,
        i18n: 10
      },
      null,
      [-1, -1]
    );
  }
}
const {
  SvelteComponent: L_,
  action_destroyer: H_,
  append_hydration: _e,
  attr: re,
  binding_callbacks: ki,
  check_outros: P_,
  children: Ge,
  claim_component: Xi,
  claim_element: ke,
  claim_space: Et,
  claim_text: fr,
  create_component: Zi,
  destroy_component: Wi,
  detach: fe,
  element: Ae,
  get_svelte_dataset: N_,
  group_outros: O_,
  init: R_,
  insert_hydration: Pt,
  listen: et,
  mount_component: Qi,
  run_all: Co,
  safe_not_equal: M_,
  set_data: _r,
  set_input_value: Oa,
  space: Ft,
  text: dr,
  toggle_class: wt,
  transition_in: kt,
  transition_out: Ut
} = window.__gradio__svelte__internal, { createEventDispatcher: q_, afterUpdate: U_, tick: G_ } = window.__gradio__svelte__internal;
function z_(t) {
  let e;
  return {
    c() {
      e = dr(
        /*label*/
        t[0]
      );
    },
    l(n) {
      e = fr(
        n,
        /*label*/
        t[0]
      );
    },
    m(n, i) {
      Pt(n, e, i);
    },
    p(n, i) {
      i[0] & /*label*/
      1 && _r(
        e,
        /*label*/
        n[0]
      );
    },
    d(n) {
      n && fe(e);
    }
  };
}
function Ra(t) {
  let e, n, i = "?", r, l, a, o = (
    /*show_tooltip*/
    t[16] && Ma(t)
  );
  return {
    c() {
      e = Ae("div"), n = Ae("span"), n.textContent = i, r = Ft(), o && o.c(), this.h();
    },
    l(s) {
      e = ke(s, "DIV", {
        class: !0,
        role: !0,
        tabindex: !0,
        "aria-label": !0
      });
      var u = Ge(e);
      n = ke(u, "SPAN", { class: !0, "data-svelte-h": !0 }), N_(n) !== "svelte-ekz8yf" && (n.textContent = i), r = Et(u), o && o.l(u), u.forEach(fe), this.h();
    },
    h() {
      re(n, "class", "tooltip-icon svelte-1jp62le"), re(e, "class", "tooltip-container svelte-1jp62le"), re(e, "role", "button"), re(e, "tabindex", "0"), re(e, "aria-label", "Help");
    },
    m(s, u) {
      Pt(s, e, u), _e(e, n), t[33](n), _e(e, r), o && o.m(e, null), l || (a = [
        et(
          e,
          "mouseenter",
          /*handle_show_tooltip*/
          t[20]
        ),
        et(
          e,
          "mouseleave",
          /*mouseleave_handler*/
          t[35]
        ),
        et(
          e,
          "focusin",
          /*handle_show_tooltip*/
          t[20]
        ),
        et(
          e,
          "focusout",
          /*focusout_handler*/
          t[36]
        )
      ], l = !0);
    },
    p(s, u) {
      /*show_tooltip*/
      s[16] ? o ? o.p(s, u) : (o = Ma(s), o.c(), o.m(e, null)) : o && (o.d(1), o = null);
    },
    d(s) {
      s && fe(e), t[33](null), o && o.d(), l = !1, Co(a);
    }
  };
}
function Ma(t) {
  let e, n, i, r;
  return {
    c() {
      e = Ae("span"), n = dr(
        /*help*/
        t[2]
      ), this.h();
    },
    l(l) {
      e = ke(l, "SPAN", { class: !0 });
      var a = Ge(e);
      n = fr(
        a,
        /*help*/
        t[2]
      ), a.forEach(fe), this.h();
    },
    h() {
      re(e, "class", "tooltip-text svelte-1jp62le");
    },
    m(l, a) {
      Pt(l, e, a), _e(e, n), t[34](e), i || (r = H_(V_.call(null, e)), i = !0);
    },
    p(l, a) {
      a[0] & /*help*/
      4 && _r(
        n,
        /*help*/
        l[2]
      );
    },
    d(l) {
      l && fe(e), t[34](null), i = !1, r();
    }
  };
}
function qa(t) {
  let e, n;
  return {
    c() {
      e = Ae("div"), n = dr(
        /*info*/
        t[1]
      ), this.h();
    },
    l(i) {
      e = ke(i, "DIV", { class: !0 });
      var r = Ge(e);
      n = fr(
        r,
        /*info*/
        t[1]
      ), r.forEach(fe), this.h();
    },
    h() {
      re(e, "class", "info-text svelte-1jp62le");
    },
    m(i, r) {
      Pt(i, e, r), _e(e, n);
    },
    p(i, r) {
      r[0] & /*info*/
      2 && _r(
        n,
        /*info*/
        i[1]
      );
    },
    d(i) {
      i && fe(e);
    }
  };
}
function Ua(t) {
  let e, n, i;
  return n = new yo({}), {
    c() {
      e = Ae("div"), Zi(n.$$.fragment), this.h();
    },
    l(r) {
      e = ke(r, "DIV", { class: !0 });
      var l = Ge(e);
      Xi(n.$$.fragment, l), l.forEach(fe), this.h();
    },
    h() {
      re(e, "class", "icon-wrap svelte-1jp62le");
    },
    m(r, l) {
      Pt(r, e, l), Qi(n, e, null), i = !0;
    },
    i(r) {
      i || (kt(n.$$.fragment, r), i = !0);
    },
    o(r) {
      Ut(n.$$.fragment, r), i = !1;
    },
    d(r) {
      r && fe(e), Wi(n);
    }
  };
}
function j_(t) {
  let e, n, i, r, l, a, o, s, u, c, _, h, d, D, E, F, C, g;
  r = new bo({
    props: {
      show_label: (
        /*show_label*/
        t[5]
      ),
      info: void 0,
      $$slots: { default: [z_] },
      $$scope: { ctx: t }
    }
  });
  let f = (
    /*help*/
    t[2] && /*show_label*/
    t[5] && Ra(t)
  ), m = (
    /*info*/
    t[1] && /*show_label*/
    t[5] && qa(t)
  ), v = !/*disabled*/
  t[4] && Ua();
  return E = new Fo({
    props: {
      show_options: (
        /*show_options*/
        t[13]
      ),
      choices: (
        /*choices*/
        t[3]
      ),
      filtered_indices: (
        /*filtered_indices*/
        t[11]
      ),
      disabled: (
        /*disabled*/
        t[4]
      ),
      selected_indices: (
        /*selected_index*/
        t[12] === null ? [] : [
          /*selected_index*/
          t[12]
        ]
      ),
      active_index: (
        /*active_index*/
        t[15]
      )
    }
  }), E.$on(
    "change",
    /*handle_option_selected*/
    t[21]
  ), {
    c() {
      e = Ae("div"), n = Ae("div"), i = Ae("div"), Zi(r.$$.fragment), l = Ft(), f && f.c(), a = Ft(), m && m.c(), o = Ft(), s = Ae("div"), u = Ae("div"), c = Ae("div"), _ = Ae("input"), d = Ft(), v && v.c(), D = Ft(), Zi(E.$$.fragment), this.h();
    },
    l(p) {
      e = ke(p, "DIV", { class: !0 });
      var b = Ge(e);
      n = ke(b, "DIV", { class: !0 });
      var k = Ge(n);
      i = ke(k, "DIV", { class: !0 });
      var y = Ge(i);
      Xi(r.$$.fragment, y), l = Et(y), f && f.l(y), y.forEach(fe), a = Et(k), m && m.l(k), k.forEach(fe), o = Et(b), s = ke(b, "DIV", { class: !0 });
      var w = Ge(s);
      u = ke(w, "DIV", { class: !0 });
      var A = Ge(u);
      c = ke(A, "DIV", { class: !0 });
      var B = Ge(c);
      _ = ke(B, "INPUT", {
        role: !0,
        "aria-controls": !0,
        "aria-expanded": !0,
        "aria-label": !0,
        class: !0,
        autocomplete: !0
      }), d = Et(B), v && v.l(B), B.forEach(fe), A.forEach(fe), D = Et(w), Xi(E.$$.fragment, w), w.forEach(fe), b.forEach(fe), this.h();
    },
    h() {
      re(i, "class", "title-line svelte-1jp62le"), re(n, "class", "label-container svelte-1jp62le"), re(_, "role", "listbox"), re(_, "aria-controls", "dropdown-options"), re(
        _,
        "aria-expanded",
        /*show_options*/
        t[13]
      ), re(
        _,
        "aria-label",
        /*label*/
        t[0]
      ), re(_, "class", "border-none svelte-1jp62le"), _.disabled = /*disabled*/
      t[4], re(_, "autocomplete", "off"), _.readOnly = h = !/*filterable*/
      t[8], wt(_, "subdued", !/*choices_names*/
      t[14].includes(
        /*input_text*/
        t[10]
      ) && !/*allow_custom_value*/
      t[7]), re(c, "class", "secondary-wrap svelte-1jp62le"), re(u, "class", "wrap-inner svelte-1jp62le"), wt(
        u,
        "show_options",
        /*show_options*/
        t[13]
      ), re(s, "class", "wrap svelte-1jp62le"), re(e, "class", "svelte-1jp62le"), wt(
        e,
        "container",
        /*container*/
        t[6]
      );
    },
    m(p, b) {
      Pt(p, e, b), _e(e, n), _e(n, i), Qi(r, i, null), _e(i, l), f && f.m(i, null), _e(n, a), m && m.m(n, null), _e(e, o), _e(e, s), _e(s, u), _e(u, c), _e(c, _), Oa(
        _,
        /*input_text*/
        t[10]
      ), t[38](_), _e(c, d), v && v.m(c, null), _e(s, D), Qi(E, s, null), F = !0, C || (g = [
        et(
          _,
          "input",
          /*input_input_handler*/
          t[37]
        ),
        et(
          _,
          "keydown",
          /*handle_key_down*/
          t[24]
        ),
        et(
          _,
          "keyup",
          /*keyup_handler*/
          t[39]
        ),
        et(
          _,
          "blur",
          /*handle_blur*/
          t[23]
        ),
        et(
          _,
          "focus",
          /*handle_focus*/
          t[22]
        )
      ], C = !0);
    },
    p(p, b) {
      const k = {};
      b[0] & /*show_label*/
      32 && (k.show_label = /*show_label*/
      p[5]), b[0] & /*label*/
      1 | b[1] & /*$$scope*/
      8192 && (k.$$scope = { dirty: b, ctx: p }), r.$set(k), /*help*/
      p[2] && /*show_label*/
      p[5] ? f ? f.p(p, b) : (f = Ra(p), f.c(), f.m(i, null)) : f && (f.d(1), f = null), /*info*/
      p[1] && /*show_label*/
      p[5] ? m ? m.p(p, b) : (m = qa(p), m.c(), m.m(n, null)) : m && (m.d(1), m = null), (!F || b[0] & /*show_options*/
      8192) && re(
        _,
        "aria-expanded",
        /*show_options*/
        p[13]
      ), (!F || b[0] & /*label*/
      1) && re(
        _,
        "aria-label",
        /*label*/
        p[0]
      ), (!F || b[0] & /*disabled*/
      16) && (_.disabled = /*disabled*/
      p[4]), (!F || b[0] & /*filterable*/
      256 && h !== (h = !/*filterable*/
      p[8])) && (_.readOnly = h), b[0] & /*input_text*/
      1024 && _.value !== /*input_text*/
      p[10] && Oa(
        _,
        /*input_text*/
        p[10]
      ), (!F || b[0] & /*choices_names, input_text, allow_custom_value*/
      17536) && wt(_, "subdued", !/*choices_names*/
      p[14].includes(
        /*input_text*/
        p[10]
      ) && !/*allow_custom_value*/
      p[7]), /*disabled*/
      p[4] ? v && (O_(), Ut(v, 1, 1, () => {
        v = null;
      }), P_()) : v ? b[0] & /*disabled*/
      16 && kt(v, 1) : (v = Ua(), v.c(), kt(v, 1), v.m(c, null)), (!F || b[0] & /*show_options*/
      8192) && wt(
        u,
        "show_options",
        /*show_options*/
        p[13]
      );
      const y = {};
      b[0] & /*show_options*/
      8192 && (y.show_options = /*show_options*/
      p[13]), b[0] & /*choices*/
      8 && (y.choices = /*choices*/
      p[3]), b[0] & /*filtered_indices*/
      2048 && (y.filtered_indices = /*filtered_indices*/
      p[11]), b[0] & /*disabled*/
      16 && (y.disabled = /*disabled*/
      p[4]), b[0] & /*selected_index*/
      4096 && (y.selected_indices = /*selected_index*/
      p[12] === null ? [] : [
        /*selected_index*/
        p[12]
      ]), b[0] & /*active_index*/
      32768 && (y.active_index = /*active_index*/
      p[15]), E.$set(y), (!F || b[0] & /*container*/
      64) && wt(
        e,
        "container",
        /*container*/
        p[6]
      );
    },
    i(p) {
      F || (kt(r.$$.fragment, p), kt(v), kt(E.$$.fragment, p), F = !0);
    },
    o(p) {
      Ut(r.$$.fragment, p), Ut(v), Ut(E.$$.fragment, p), F = !1;
    },
    d(p) {
      p && fe(e), Wi(r), f && f.d(), m && m.d(), t[38](null), v && v.d(), Wi(E), C = !1, Co(g);
    }
  };
}
function V_(t) {
  return document.body.appendChild(t), {
    destroy() {
      t.parentNode && t.parentNode.removeChild(t);
    }
  };
}
function X_(t, e, n) {
  let { label: i } = e, { info: r = void 0 } = e, { help: l = void 0 } = e, { value: a = void 0 } = e, o, { value_is_output: s = !1 } = e, { choices: u } = e, c, { disabled: _ = !1 } = e, { show_label: h } = e, { container: d = !0 } = e, { allow_custom_value: D = !1 } = e, { filterable: E = !0 } = e, F, C = !1, g, f, m = "", v = "", p = !1, b = [], k = null, y = null, w, A = !1, B, N;
  const L = q_();
  a && (w = u.map((H) => H[1]).indexOf(a), y = w, y === -1 ? (o = a, y = null) : ([m, o] = u[y], v = m), T());
  function R() {
    n(14, g = u.map((H) => H[0])), n(29, f = u.map((H) => H[1]));
  }
  const M = typeof window < "u";
  function J() {
    if (!B || !N) return;
    const H = N.getBoundingClientRect();
    n(17, B.style.position = "fixed", B), n(17, B.style.left = `${H.right + 8}px`, B), n(17, B.style.top = `${H.top}px`, B);
  }
  function V() {
    n(16, A = !0), G_().then(J);
  }
  function T() {
    R(), a === void 0 || Array.isArray(a) && a.length === 0 ? (n(10, m = ""), n(12, y = null)) : f.includes(a) ? (n(10, m = g[f.indexOf(a)]), n(12, y = f.indexOf(a))) : D ? (n(10, m = a), n(12, y = null)) : (n(10, m = ""), n(12, y = null)), n(32, w = y);
  }
  function ee(H) {
    if (n(12, y = parseInt(H.detail.target.dataset.index)), isNaN(y)) {
      n(12, y = null);
      return;
    }
    n(13, C = !1), n(15, k = null), F.blur();
  }
  function x(H) {
    n(11, b = u.map((cn, st) => st)), n(13, C = !0), L("focus");
  }
  function te() {
    D ? n(25, a = m) : n(10, m = g[f.indexOf(a)]), n(13, C = !1), n(15, k = null), L("blur");
  }
  function pe(H) {
    n(13, [C, k] = Ao(H, k, b), C, (n(15, k), n(3, u), n(28, c), n(7, D), n(10, m), n(11, b), n(9, F), n(30, v), n(12, y), n(32, w), n(31, p), n(29, f))), H.key === "Enter" && (k !== null ? (n(12, y = k), n(13, C = !1), F.blur(), n(15, k = null)) : g.includes(m) ? (n(12, y = g.indexOf(m)), n(13, C = !1), n(15, k = null), F.blur()) : D && (n(25, a = m), n(12, y = null), n(13, C = !1), n(15, k = null), F.blur()));
  }
  U_(() => {
    n(26, s = !1), n(31, p = !0);
  });
  function $(H) {
    ki[H ? "unshift" : "push"](() => {
      N = H, n(18, N);
    });
  }
  function I(H) {
    ki[H ? "unshift" : "push"](() => {
      B = H, n(17, B);
    });
  }
  const Re = () => n(16, A = !1), tt = () => n(16, A = !1);
  function lt() {
    m = this.value, n(10, m), n(12, y), n(32, w), n(31, p), n(3, u), n(29, f);
  }
  function pt(H) {
    ki[H ? "unshift" : "push"](() => {
      F = H, n(9, F);
    });
  }
  const ot = (H) => L("key_up", { key: H.key, input_value: m });
  return t.$$set = (H) => {
    "label" in H && n(0, i = H.label), "info" in H && n(1, r = H.info), "help" in H && n(2, l = H.help), "value" in H && n(25, a = H.value), "value_is_output" in H && n(26, s = H.value_is_output), "choices" in H && n(3, u = H.choices), "disabled" in H && n(4, _ = H.disabled), "show_label" in H && n(5, h = H.show_label), "container" in H && n(6, d = H.container), "allow_custom_value" in H && n(7, D = H.allow_custom_value), "filterable" in H && n(8, E = H.filterable);
  }, t.$$.update = () => {
    t.$$.dirty[0] & /*selected_index, choices, choices_values*/
    536875016 | t.$$.dirty[1] & /*old_selected_index, initialized*/
    3 && y !== w && y !== null && p && (n(10, [m, a] = u[y], m, (n(25, a), n(12, y), n(32, w), n(31, p), n(3, u), n(29, f))), n(32, w = y), L("select", {
      index: y,
      value: f[y],
      selected: !0
    })), t.$$.dirty[0] & /*old_value, value, value_is_output*/
    234881024 && JSON.stringify(o) !== JSON.stringify(a) && (T(), ko(L, a, s), n(27, o = a)), t.$$.dirty[0] & /*choices*/
    8 && R(), t.$$.dirty[0] & /*choices, old_choices, allow_custom_value, input_text, filtered_indices, filter_input*/
    268439176 && u !== c && (D || T(), n(28, c = u), n(11, b = Vi(u, m)), !D && b.length > 0 && n(15, k = b[0]), M && F === document.activeElement && n(13, C = !0)), t.$$.dirty[0] & /*input_text, old_input_text, choices, allow_custom_value, filtered_indices*/
    1073745032 && m !== v && (n(11, b = Vi(u, m)), n(30, v = m), !D && b.length > 0 && n(15, k = b[0]));
  }, [
    i,
    r,
    l,
    u,
    _,
    h,
    d,
    D,
    E,
    F,
    m,
    b,
    y,
    C,
    g,
    k,
    A,
    B,
    N,
    L,
    V,
    ee,
    x,
    te,
    pe,
    a,
    s,
    o,
    c,
    f,
    v,
    p,
    w,
    $,
    I,
    Re,
    tt,
    lt,
    pt,
    ot
  ];
}
class Z_ extends L_ {
  constructor(e) {
    super(), R_(
      this,
      e,
      X_,
      j_,
      M_,
      {
        label: 0,
        info: 1,
        help: 2,
        value: 25,
        value_is_output: 26,
        choices: 3,
        disabled: 4,
        show_label: 5,
        container: 6,
        allow_custom_value: 7,
        filterable: 8
      },
      null,
      [-1, -1]
    );
  }
}
function At(t) {
  let e = ["", "k", "M", "G", "T", "P", "E", "Z"], n = 0;
  for (; t > 1e3 && n < e.length - 1; )
    t /= 1e3, n++;
  let i = e[n];
  return (Number.isInteger(t) ? t : t.toFixed(1)) + i;
}
const {
  SvelteComponent: W_,
  append_hydration: Ie,
  attr: G,
  children: Ee,
  claim_element: Q_,
  claim_svg_element: Le,
  component_subscribe: Ga,
  detach: ge,
  element: Y_,
  init: J_,
  insert_hydration: K_,
  noop: za,
  safe_not_equal: ed,
  set_style: Fn,
  svg_element: He,
  toggle_class: ja
} = window.__gradio__svelte__internal, { onMount: td } = window.__gradio__svelte__internal;
function nd(t) {
  let e, n, i, r, l, a, o, s, u, c, _, h;
  return {
    c() {
      e = Y_("div"), n = He("svg"), i = He("g"), r = He("path"), l = He("path"), a = He("path"), o = He("path"), s = He("g"), u = He("path"), c = He("path"), _ = He("path"), h = He("path"), this.h();
    },
    l(d) {
      e = Q_(d, "DIV", { class: !0 });
      var D = Ee(e);
      n = Le(D, "svg", {
        viewBox: !0,
        fill: !0,
        xmlns: !0,
        class: !0
      });
      var E = Ee(n);
      i = Le(E, "g", { style: !0 });
      var F = Ee(i);
      r = Le(F, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), Ee(r).forEach(ge), l = Le(F, "path", { d: !0, fill: !0, class: !0 }), Ee(l).forEach(ge), a = Le(F, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), Ee(a).forEach(ge), o = Le(F, "path", { d: !0, fill: !0, class: !0 }), Ee(o).forEach(ge), F.forEach(ge), s = Le(E, "g", { style: !0 });
      var C = Ee(s);
      u = Le(C, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), Ee(u).forEach(ge), c = Le(C, "path", { d: !0, fill: !0, class: !0 }), Ee(c).forEach(ge), _ = Le(C, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), Ee(_).forEach(ge), h = Le(C, "path", { d: !0, fill: !0, class: !0 }), Ee(h).forEach(ge), C.forEach(ge), E.forEach(ge), D.forEach(ge), this.h();
    },
    h() {
      G(r, "d", "M255.926 0.754768L509.702 139.936V221.027L255.926 81.8465V0.754768Z"), G(r, "fill", "#FF7C00"), G(r, "fill-opacity", "0.4"), G(r, "class", "svelte-43sxxs"), G(l, "d", "M509.69 139.936L254.981 279.641V361.255L509.69 221.55V139.936Z"), G(l, "fill", "#FF7C00"), G(l, "class", "svelte-43sxxs"), G(a, "d", "M0.250138 139.937L254.981 279.641V361.255L0.250138 221.55V139.937Z"), G(a, "fill", "#FF7C00"), G(a, "fill-opacity", "0.4"), G(a, "class", "svelte-43sxxs"), G(o, "d", "M255.923 0.232622L0.236328 139.936V221.55L255.923 81.8469V0.232622Z"), G(o, "fill", "#FF7C00"), G(o, "class", "svelte-43sxxs"), Fn(i, "transform", "translate(" + /*$top*/
      t[1][0] + "px, " + /*$top*/
      t[1][1] + "px)"), G(u, "d", "M255.926 141.5L509.702 280.681V361.773L255.926 222.592V141.5Z"), G(u, "fill", "#FF7C00"), G(u, "fill-opacity", "0.4"), G(u, "class", "svelte-43sxxs"), G(c, "d", "M509.69 280.679L254.981 420.384V501.998L509.69 362.293V280.679Z"), G(c, "fill", "#FF7C00"), G(c, "class", "svelte-43sxxs"), G(_, "d", "M0.250138 280.681L254.981 420.386V502L0.250138 362.295V280.681Z"), G(_, "fill", "#FF7C00"), G(_, "fill-opacity", "0.4"), G(_, "class", "svelte-43sxxs"), G(h, "d", "M255.923 140.977L0.236328 280.68V362.294L255.923 222.591V140.977Z"), G(h, "fill", "#FF7C00"), G(h, "class", "svelte-43sxxs"), Fn(s, "transform", "translate(" + /*$bottom*/
      t[2][0] + "px, " + /*$bottom*/
      t[2][1] + "px)"), G(n, "viewBox", "-1200 -1200 3000 3000"), G(n, "fill", "none"), G(n, "xmlns", "http://www.w3.org/2000/svg"), G(n, "class", "svelte-43sxxs"), G(e, "class", "svelte-43sxxs"), ja(
        e,
        "margin",
        /*margin*/
        t[0]
      );
    },
    m(d, D) {
      K_(d, e, D), Ie(e, n), Ie(n, i), Ie(i, r), Ie(i, l), Ie(i, a), Ie(i, o), Ie(n, s), Ie(s, u), Ie(s, c), Ie(s, _), Ie(s, h);
    },
    p(d, [D]) {
      D & /*$top*/
      2 && Fn(i, "transform", "translate(" + /*$top*/
      d[1][0] + "px, " + /*$top*/
      d[1][1] + "px)"), D & /*$bottom*/
      4 && Fn(s, "transform", "translate(" + /*$bottom*/
      d[2][0] + "px, " + /*$bottom*/
      d[2][1] + "px)"), D & /*margin*/
      1 && ja(
        e,
        "margin",
        /*margin*/
        d[0]
      );
    },
    i: za,
    o: za,
    d(d) {
      d && ge(e);
    }
  };
}
function id(t, e, n) {
  let i, r;
  var l = this && this.__awaiter || function(d, D, E, F) {
    function C(g) {
      return g instanceof E ? g : new E(function(f) {
        f(g);
      });
    }
    return new (E || (E = Promise))(function(g, f) {
      function m(b) {
        try {
          p(F.next(b));
        } catch (k) {
          f(k);
        }
      }
      function v(b) {
        try {
          p(F.throw(b));
        } catch (k) {
          f(k);
        }
      }
      function p(b) {
        b.done ? g(b.value) : C(b.value).then(m, v);
      }
      p((F = F.apply(d, D || [])).next());
    });
  };
  let { margin: a = !0 } = e;
  const o = wr([0, 0]);
  Ga(t, o, (d) => n(1, i = d));
  const s = wr([0, 0]);
  Ga(t, s, (d) => n(2, r = d));
  let u;
  function c() {
    return l(this, void 0, void 0, function* () {
      yield Promise.all([o.set([125, 140]), s.set([-125, -140])]), yield Promise.all([o.set([-125, 140]), s.set([125, -140])]), yield Promise.all([o.set([-125, 0]), s.set([125, -0])]), yield Promise.all([o.set([125, 0]), s.set([-125, 0])]);
    });
  }
  function _() {
    return l(this, void 0, void 0, function* () {
      yield c(), u || _();
    });
  }
  function h() {
    return l(this, void 0, void 0, function* () {
      yield Promise.all([o.set([125, 0]), s.set([-125, 0])]), _();
    });
  }
  return td(() => (h(), () => u = !0)), t.$$set = (d) => {
    "margin" in d && n(0, a = d.margin);
  }, [a, i, r, o, s];
}
class rd extends W_ {
  constructor(e) {
    super(), J_(this, e, id, nd, ed, { margin: 0 });
  }
}
const {
  SvelteComponent: ad,
  append_hydration: ct,
  attr: Ne,
  binding_callbacks: Va,
  check_outros: Yi,
  children: Xe,
  claim_component: So,
  claim_element: Ze,
  claim_space: Ce,
  claim_text: ne,
  create_component: xo,
  create_slot: Bo,
  destroy_component: $o,
  destroy_each: To,
  detach: P,
  element: We,
  empty: Be,
  ensure_array_like: Un,
  get_all_dirty_from_scope: Io,
  get_slot_changes: Lo,
  group_outros: Ji,
  init: ld,
  insert_hydration: O,
  mount_component: Ho,
  noop: Ki,
  safe_not_equal: od,
  set_data: $e,
  set_style: at,
  space: Se,
  text: ie,
  toggle_class: Fe,
  transition_in: Pe,
  transition_out: Qe,
  update_slot_base: Po
} = window.__gradio__svelte__internal, { tick: sd } = window.__gradio__svelte__internal, { onDestroy: ud } = window.__gradio__svelte__internal, { createEventDispatcher: cd } = window.__gradio__svelte__internal, hd = (t) => ({}), Xa = (t) => ({}), fd = (t) => ({}), Za = (t) => ({});
function Wa(t, e, n) {
  const i = t.slice();
  return i[40] = e[n], i[42] = n, i;
}
function Qa(t, e, n) {
  const i = t.slice();
  return i[40] = e[n], i;
}
function _d(t) {
  let e, n, i, r, l = (
    /*i18n*/
    t[1]("common.error") + ""
  ), a, o, s;
  n = new Nf({
    props: {
      Icon: Gf,
      label: (
        /*i18n*/
        t[1]("common.clear")
      ),
      disabled: !1
    }
  }), n.$on(
    "click",
    /*click_handler*/
    t[32]
  );
  const u = (
    /*#slots*/
    t[30].error
  ), c = Bo(
    u,
    t,
    /*$$scope*/
    t[29],
    Xa
  );
  return {
    c() {
      e = We("div"), xo(n.$$.fragment), i = Se(), r = We("span"), a = ie(l), o = Se(), c && c.c(), this.h();
    },
    l(_) {
      e = Ze(_, "DIV", { class: !0 });
      var h = Xe(e);
      So(n.$$.fragment, h), h.forEach(P), i = Ce(_), r = Ze(_, "SPAN", { class: !0 });
      var d = Xe(r);
      a = ne(d, l), d.forEach(P), o = Ce(_), c && c.l(_), this.h();
    },
    h() {
      Ne(e, "class", "clear-status svelte-17v219f"), Ne(r, "class", "error svelte-17v219f");
    },
    m(_, h) {
      O(_, e, h), Ho(n, e, null), O(_, i, h), O(_, r, h), ct(r, a), O(_, o, h), c && c.m(_, h), s = !0;
    },
    p(_, h) {
      const d = {};
      h[0] & /*i18n*/
      2 && (d.label = /*i18n*/
      _[1]("common.clear")), n.$set(d), (!s || h[0] & /*i18n*/
      2) && l !== (l = /*i18n*/
      _[1]("common.error") + "") && $e(a, l), c && c.p && (!s || h[0] & /*$$scope*/
      536870912) && Po(
        c,
        u,
        _,
        /*$$scope*/
        _[29],
        s ? Lo(
          u,
          /*$$scope*/
          _[29],
          h,
          hd
        ) : Io(
          /*$$scope*/
          _[29]
        ),
        Xa
      );
    },
    i(_) {
      s || (Pe(n.$$.fragment, _), Pe(c, _), s = !0);
    },
    o(_) {
      Qe(n.$$.fragment, _), Qe(c, _), s = !1;
    },
    d(_) {
      _ && (P(e), P(i), P(r), P(o)), $o(n), c && c.d(_);
    }
  };
}
function dd(t) {
  let e, n, i, r, l, a, o, s, u, c = (
    /*variant*/
    t[8] === "default" && /*show_eta_bar*/
    t[18] && /*show_progress*/
    t[6] === "full" && Ya(t)
  );
  function _(f, m) {
    if (
      /*progress*/
      f[7]
    ) return gd;
    if (
      /*queue_position*/
      f[2] !== null && /*queue_size*/
      f[3] !== void 0 && /*queue_position*/
      f[2] >= 0
    ) return pd;
    if (
      /*queue_position*/
      f[2] === 0
    ) return md;
  }
  let h = _(t), d = h && h(t), D = (
    /*timer*/
    t[5] && el(t)
  );
  const E = [wd, yd], F = [];
  function C(f, m) {
    return (
      /*last_progress_level*/
      f[15] != null ? 0 : (
        /*show_progress*/
        f[6] === "full" ? 1 : -1
      )
    );
  }
  ~(l = C(t)) && (a = F[l] = E[l](t));
  let g = !/*timer*/
  t[5] && ol(t);
  return {
    c() {
      c && c.c(), e = Se(), n = We("div"), d && d.c(), i = Se(), D && D.c(), r = Se(), a && a.c(), o = Se(), g && g.c(), s = Be(), this.h();
    },
    l(f) {
      c && c.l(f), e = Ce(f), n = Ze(f, "DIV", { class: !0 });
      var m = Xe(n);
      d && d.l(m), i = Ce(m), D && D.l(m), m.forEach(P), r = Ce(f), a && a.l(f), o = Ce(f), g && g.l(f), s = Be(), this.h();
    },
    h() {
      Ne(n, "class", "progress-text svelte-17v219f"), Fe(
        n,
        "meta-text-center",
        /*variant*/
        t[8] === "center"
      ), Fe(
        n,
        "meta-text",
        /*variant*/
        t[8] === "default"
      );
    },
    m(f, m) {
      c && c.m(f, m), O(f, e, m), O(f, n, m), d && d.m(n, null), ct(n, i), D && D.m(n, null), O(f, r, m), ~l && F[l].m(f, m), O(f, o, m), g && g.m(f, m), O(f, s, m), u = !0;
    },
    p(f, m) {
      /*variant*/
      f[8] === "default" && /*show_eta_bar*/
      f[18] && /*show_progress*/
      f[6] === "full" ? c ? c.p(f, m) : (c = Ya(f), c.c(), c.m(e.parentNode, e)) : c && (c.d(1), c = null), h === (h = _(f)) && d ? d.p(f, m) : (d && d.d(1), d = h && h(f), d && (d.c(), d.m(n, i))), /*timer*/
      f[5] ? D ? D.p(f, m) : (D = el(f), D.c(), D.m(n, null)) : D && (D.d(1), D = null), (!u || m[0] & /*variant*/
      256) && Fe(
        n,
        "meta-text-center",
        /*variant*/
        f[8] === "center"
      ), (!u || m[0] & /*variant*/
      256) && Fe(
        n,
        "meta-text",
        /*variant*/
        f[8] === "default"
      );
      let v = l;
      l = C(f), l === v ? ~l && F[l].p(f, m) : (a && (Ji(), Qe(F[v], 1, 1, () => {
        F[v] = null;
      }), Yi()), ~l ? (a = F[l], a ? a.p(f, m) : (a = F[l] = E[l](f), a.c()), Pe(a, 1), a.m(o.parentNode, o)) : a = null), /*timer*/
      f[5] ? g && (Ji(), Qe(g, 1, 1, () => {
        g = null;
      }), Yi()) : g ? (g.p(f, m), m[0] & /*timer*/
      32 && Pe(g, 1)) : (g = ol(f), g.c(), Pe(g, 1), g.m(s.parentNode, s));
    },
    i(f) {
      u || (Pe(a), Pe(g), u = !0);
    },
    o(f) {
      Qe(a), Qe(g), u = !1;
    },
    d(f) {
      f && (P(e), P(n), P(r), P(o), P(s)), c && c.d(f), d && d.d(), D && D.d(), ~l && F[l].d(f), g && g.d(f);
    }
  };
}
function Ya(t) {
  let e, n = `translateX(${/*eta_level*/
  (t[17] || 0) * 100 - 100}%)`;
  return {
    c() {
      e = We("div"), this.h();
    },
    l(i) {
      e = Ze(i, "DIV", { class: !0 }), Xe(e).forEach(P), this.h();
    },
    h() {
      Ne(e, "class", "eta-bar svelte-17v219f"), at(e, "transform", n);
    },
    m(i, r) {
      O(i, e, r);
    },
    p(i, r) {
      r[0] & /*eta_level*/
      131072 && n !== (n = `translateX(${/*eta_level*/
      (i[17] || 0) * 100 - 100}%)`) && at(e, "transform", n);
    },
    d(i) {
      i && P(e);
    }
  };
}
function md(t) {
  let e;
  return {
    c() {
      e = ie("processing |");
    },
    l(n) {
      e = ne(n, "processing |");
    },
    m(n, i) {
      O(n, e, i);
    },
    p: Ki,
    d(n) {
      n && P(e);
    }
  };
}
function pd(t) {
  let e, n = (
    /*queue_position*/
    t[2] + 1 + ""
  ), i, r, l, a;
  return {
    c() {
      e = ie("queue: "), i = ie(n), r = ie("/"), l = ie(
        /*queue_size*/
        t[3]
      ), a = ie(" |");
    },
    l(o) {
      e = ne(o, "queue: "), i = ne(o, n), r = ne(o, "/"), l = ne(
        o,
        /*queue_size*/
        t[3]
      ), a = ne(o, " |");
    },
    m(o, s) {
      O(o, e, s), O(o, i, s), O(o, r, s), O(o, l, s), O(o, a, s);
    },
    p(o, s) {
      s[0] & /*queue_position*/
      4 && n !== (n = /*queue_position*/
      o[2] + 1 + "") && $e(i, n), s[0] & /*queue_size*/
      8 && $e(
        l,
        /*queue_size*/
        o[3]
      );
    },
    d(o) {
      o && (P(e), P(i), P(r), P(l), P(a));
    }
  };
}
function gd(t) {
  let e, n = Un(
    /*progress*/
    t[7]
  ), i = [];
  for (let r = 0; r < n.length; r += 1)
    i[r] = Ka(Qa(t, n, r));
  return {
    c() {
      for (let r = 0; r < i.length; r += 1)
        i[r].c();
      e = Be();
    },
    l(r) {
      for (let l = 0; l < i.length; l += 1)
        i[l].l(r);
      e = Be();
    },
    m(r, l) {
      for (let a = 0; a < i.length; a += 1)
        i[a] && i[a].m(r, l);
      O(r, e, l);
    },
    p(r, l) {
      if (l[0] & /*progress*/
      128) {
        n = Un(
          /*progress*/
          r[7]
        );
        let a;
        for (a = 0; a < n.length; a += 1) {
          const o = Qa(r, n, a);
          i[a] ? i[a].p(o, l) : (i[a] = Ka(o), i[a].c(), i[a].m(e.parentNode, e));
        }
        for (; a < i.length; a += 1)
          i[a].d(1);
        i.length = n.length;
      }
    },
    d(r) {
      r && P(e), To(i, r);
    }
  };
}
function Ja(t) {
  let e, n = (
    /*p*/
    t[40].unit + ""
  ), i, r, l = " ", a;
  function o(c, _) {
    return (
      /*p*/
      c[40].length != null ? vd : bd
    );
  }
  let s = o(t), u = s(t);
  return {
    c() {
      u.c(), e = Se(), i = ie(n), r = ie(" | "), a = ie(l);
    },
    l(c) {
      u.l(c), e = Ce(c), i = ne(c, n), r = ne(c, " | "), a = ne(c, l);
    },
    m(c, _) {
      u.m(c, _), O(c, e, _), O(c, i, _), O(c, r, _), O(c, a, _);
    },
    p(c, _) {
      s === (s = o(c)) && u ? u.p(c, _) : (u.d(1), u = s(c), u && (u.c(), u.m(e.parentNode, e))), _[0] & /*progress*/
      128 && n !== (n = /*p*/
      c[40].unit + "") && $e(i, n);
    },
    d(c) {
      c && (P(e), P(i), P(r), P(a)), u.d(c);
    }
  };
}
function bd(t) {
  let e = At(
    /*p*/
    t[40].index || 0
  ) + "", n;
  return {
    c() {
      n = ie(e);
    },
    l(i) {
      n = ne(i, e);
    },
    m(i, r) {
      O(i, n, r);
    },
    p(i, r) {
      r[0] & /*progress*/
      128 && e !== (e = At(
        /*p*/
        i[40].index || 0
      ) + "") && $e(n, e);
    },
    d(i) {
      i && P(n);
    }
  };
}
function vd(t) {
  let e = At(
    /*p*/
    t[40].index || 0
  ) + "", n, i, r = At(
    /*p*/
    t[40].length
  ) + "", l;
  return {
    c() {
      n = ie(e), i = ie("/"), l = ie(r);
    },
    l(a) {
      n = ne(a, e), i = ne(a, "/"), l = ne(a, r);
    },
    m(a, o) {
      O(a, n, o), O(a, i, o), O(a, l, o);
    },
    p(a, o) {
      o[0] & /*progress*/
      128 && e !== (e = At(
        /*p*/
        a[40].index || 0
      ) + "") && $e(n, e), o[0] & /*progress*/
      128 && r !== (r = At(
        /*p*/
        a[40].length
      ) + "") && $e(l, r);
    },
    d(a) {
      a && (P(n), P(i), P(l));
    }
  };
}
function Ka(t) {
  let e, n = (
    /*p*/
    t[40].index != null && Ja(t)
  );
  return {
    c() {
      n && n.c(), e = Be();
    },
    l(i) {
      n && n.l(i), e = Be();
    },
    m(i, r) {
      n && n.m(i, r), O(i, e, r);
    },
    p(i, r) {
      /*p*/
      i[40].index != null ? n ? n.p(i, r) : (n = Ja(i), n.c(), n.m(e.parentNode, e)) : n && (n.d(1), n = null);
    },
    d(i) {
      i && P(e), n && n.d(i);
    }
  };
}
function el(t) {
  let e, n = (
    /*eta*/
    t[0] ? `/${/*formatted_eta*/
    t[19]}` : ""
  ), i, r;
  return {
    c() {
      e = ie(
        /*formatted_timer*/
        t[20]
      ), i = ie(n), r = ie("s");
    },
    l(l) {
      e = ne(
        l,
        /*formatted_timer*/
        t[20]
      ), i = ne(l, n), r = ne(l, "s");
    },
    m(l, a) {
      O(l, e, a), O(l, i, a), O(l, r, a);
    },
    p(l, a) {
      a[0] & /*formatted_timer*/
      1048576 && $e(
        e,
        /*formatted_timer*/
        l[20]
      ), a[0] & /*eta, formatted_eta*/
      524289 && n !== (n = /*eta*/
      l[0] ? `/${/*formatted_eta*/
      l[19]}` : "") && $e(i, n);
    },
    d(l) {
      l && (P(e), P(i), P(r));
    }
  };
}
function yd(t) {
  let e, n;
  return e = new rd({
    props: { margin: (
      /*variant*/
      t[8] === "default"
    ) }
  }), {
    c() {
      xo(e.$$.fragment);
    },
    l(i) {
      So(e.$$.fragment, i);
    },
    m(i, r) {
      Ho(e, i, r), n = !0;
    },
    p(i, r) {
      const l = {};
      r[0] & /*variant*/
      256 && (l.margin = /*variant*/
      i[8] === "default"), e.$set(l);
    },
    i(i) {
      n || (Pe(e.$$.fragment, i), n = !0);
    },
    o(i) {
      Qe(e.$$.fragment, i), n = !1;
    },
    d(i) {
      $o(e, i);
    }
  };
}
function wd(t) {
  let e, n, i, r, l, a = `${/*last_progress_level*/
  t[15] * 100}%`, o = (
    /*progress*/
    t[7] != null && tl(t)
  );
  return {
    c() {
      e = We("div"), n = We("div"), o && o.c(), i = Se(), r = We("div"), l = We("div"), this.h();
    },
    l(s) {
      e = Ze(s, "DIV", { class: !0 });
      var u = Xe(e);
      n = Ze(u, "DIV", { class: !0 });
      var c = Xe(n);
      o && o.l(c), c.forEach(P), i = Ce(u), r = Ze(u, "DIV", { class: !0 });
      var _ = Xe(r);
      l = Ze(_, "DIV", { class: !0 }), Xe(l).forEach(P), _.forEach(P), u.forEach(P), this.h();
    },
    h() {
      Ne(n, "class", "progress-level-inner svelte-17v219f"), Ne(l, "class", "progress-bar svelte-17v219f"), at(l, "width", a), Ne(r, "class", "progress-bar-wrap svelte-17v219f"), Ne(e, "class", "progress-level svelte-17v219f");
    },
    m(s, u) {
      O(s, e, u), ct(e, n), o && o.m(n, null), ct(e, i), ct(e, r), ct(r, l), t[31](l);
    },
    p(s, u) {
      /*progress*/
      s[7] != null ? o ? o.p(s, u) : (o = tl(s), o.c(), o.m(n, null)) : o && (o.d(1), o = null), u[0] & /*last_progress_level*/
      32768 && a !== (a = `${/*last_progress_level*/
      s[15] * 100}%`) && at(l, "width", a);
    },
    i: Ki,
    o: Ki,
    d(s) {
      s && P(e), o && o.d(), t[31](null);
    }
  };
}
function tl(t) {
  let e, n = Un(
    /*progress*/
    t[7]
  ), i = [];
  for (let r = 0; r < n.length; r += 1)
    i[r] = ll(Wa(t, n, r));
  return {
    c() {
      for (let r = 0; r < i.length; r += 1)
        i[r].c();
      e = Be();
    },
    l(r) {
      for (let l = 0; l < i.length; l += 1)
        i[l].l(r);
      e = Be();
    },
    m(r, l) {
      for (let a = 0; a < i.length; a += 1)
        i[a] && i[a].m(r, l);
      O(r, e, l);
    },
    p(r, l) {
      if (l[0] & /*progress_level, progress*/
      16512) {
        n = Un(
          /*progress*/
          r[7]
        );
        let a;
        for (a = 0; a < n.length; a += 1) {
          const o = Wa(r, n, a);
          i[a] ? i[a].p(o, l) : (i[a] = ll(o), i[a].c(), i[a].m(e.parentNode, e));
        }
        for (; a < i.length; a += 1)
          i[a].d(1);
        i.length = n.length;
      }
    },
    d(r) {
      r && P(e), To(i, r);
    }
  };
}
function nl(t) {
  let e, n, i, r, l = (
    /*i*/
    t[42] !== 0 && Dd()
  ), a = (
    /*p*/
    t[40].desc != null && il(t)
  ), o = (
    /*p*/
    t[40].desc != null && /*progress_level*/
    t[14] && /*progress_level*/
    t[14][
      /*i*/
      t[42]
    ] != null && rl()
  ), s = (
    /*progress_level*/
    t[14] != null && al(t)
  );
  return {
    c() {
      l && l.c(), e = Se(), a && a.c(), n = Se(), o && o.c(), i = Se(), s && s.c(), r = Be();
    },
    l(u) {
      l && l.l(u), e = Ce(u), a && a.l(u), n = Ce(u), o && o.l(u), i = Ce(u), s && s.l(u), r = Be();
    },
    m(u, c) {
      l && l.m(u, c), O(u, e, c), a && a.m(u, c), O(u, n, c), o && o.m(u, c), O(u, i, c), s && s.m(u, c), O(u, r, c);
    },
    p(u, c) {
      /*p*/
      u[40].desc != null ? a ? a.p(u, c) : (a = il(u), a.c(), a.m(n.parentNode, n)) : a && (a.d(1), a = null), /*p*/
      u[40].desc != null && /*progress_level*/
      u[14] && /*progress_level*/
      u[14][
        /*i*/
        u[42]
      ] != null ? o || (o = rl(), o.c(), o.m(i.parentNode, i)) : o && (o.d(1), o = null), /*progress_level*/
      u[14] != null ? s ? s.p(u, c) : (s = al(u), s.c(), s.m(r.parentNode, r)) : s && (s.d(1), s = null);
    },
    d(u) {
      u && (P(e), P(n), P(i), P(r)), l && l.d(u), a && a.d(u), o && o.d(u), s && s.d(u);
    }
  };
}
function Dd(t) {
  let e;
  return {
    c() {
      e = ie(" /");
    },
    l(n) {
      e = ne(n, " /");
    },
    m(n, i) {
      O(n, e, i);
    },
    d(n) {
      n && P(e);
    }
  };
}
function il(t) {
  let e = (
    /*p*/
    t[40].desc + ""
  ), n;
  return {
    c() {
      n = ie(e);
    },
    l(i) {
      n = ne(i, e);
    },
    m(i, r) {
      O(i, n, r);
    },
    p(i, r) {
      r[0] & /*progress*/
      128 && e !== (e = /*p*/
      i[40].desc + "") && $e(n, e);
    },
    d(i) {
      i && P(n);
    }
  };
}
function rl(t) {
  let e;
  return {
    c() {
      e = ie("-");
    },
    l(n) {
      e = ne(n, "-");
    },
    m(n, i) {
      O(n, e, i);
    },
    d(n) {
      n && P(e);
    }
  };
}
function al(t) {
  let e = (100 * /*progress_level*/
  (t[14][
    /*i*/
    t[42]
  ] || 0)).toFixed(1) + "", n, i;
  return {
    c() {
      n = ie(e), i = ie("%");
    },
    l(r) {
      n = ne(r, e), i = ne(r, "%");
    },
    m(r, l) {
      O(r, n, l), O(r, i, l);
    },
    p(r, l) {
      l[0] & /*progress_level*/
      16384 && e !== (e = (100 * /*progress_level*/
      (r[14][
        /*i*/
        r[42]
      ] || 0)).toFixed(1) + "") && $e(n, e);
    },
    d(r) {
      r && (P(n), P(i));
    }
  };
}
function ll(t) {
  let e, n = (
    /*p*/
    (t[40].desc != null || /*progress_level*/
    t[14] && /*progress_level*/
    t[14][
      /*i*/
      t[42]
    ] != null) && nl(t)
  );
  return {
    c() {
      n && n.c(), e = Be();
    },
    l(i) {
      n && n.l(i), e = Be();
    },
    m(i, r) {
      n && n.m(i, r), O(i, e, r);
    },
    p(i, r) {
      /*p*/
      i[40].desc != null || /*progress_level*/
      i[14] && /*progress_level*/
      i[14][
        /*i*/
        i[42]
      ] != null ? n ? n.p(i, r) : (n = nl(i), n.c(), n.m(e.parentNode, e)) : n && (n.d(1), n = null);
    },
    d(i) {
      i && P(e), n && n.d(i);
    }
  };
}
function ol(t) {
  let e, n, i, r;
  const l = (
    /*#slots*/
    t[30]["additional-loading-text"]
  ), a = Bo(
    l,
    t,
    /*$$scope*/
    t[29],
    Za
  );
  return {
    c() {
      e = We("p"), n = ie(
        /*loading_text*/
        t[9]
      ), i = Se(), a && a.c(), this.h();
    },
    l(o) {
      e = Ze(o, "P", { class: !0 });
      var s = Xe(e);
      n = ne(
        s,
        /*loading_text*/
        t[9]
      ), s.forEach(P), i = Ce(o), a && a.l(o), this.h();
    },
    h() {
      Ne(e, "class", "loading svelte-17v219f");
    },
    m(o, s) {
      O(o, e, s), ct(e, n), O(o, i, s), a && a.m(o, s), r = !0;
    },
    p(o, s) {
      (!r || s[0] & /*loading_text*/
      512) && $e(
        n,
        /*loading_text*/
        o[9]
      ), a && a.p && (!r || s[0] & /*$$scope*/
      536870912) && Po(
        a,
        l,
        o,
        /*$$scope*/
        o[29],
        r ? Lo(
          l,
          /*$$scope*/
          o[29],
          s,
          fd
        ) : Io(
          /*$$scope*/
          o[29]
        ),
        Za
      );
    },
    i(o) {
      r || (Pe(a, o), r = !0);
    },
    o(o) {
      Qe(a, o), r = !1;
    },
    d(o) {
      o && (P(e), P(i)), a && a.d(o);
    }
  };
}
function Ed(t) {
  let e, n, i, r, l;
  const a = [dd, _d], o = [];
  function s(u, c) {
    return (
      /*status*/
      u[4] === "pending" ? 0 : (
        /*status*/
        u[4] === "error" ? 1 : -1
      )
    );
  }
  return ~(n = s(t)) && (i = o[n] = a[n](t)), {
    c() {
      e = We("div"), i && i.c(), this.h();
    },
    l(u) {
      e = Ze(u, "DIV", { class: !0 });
      var c = Xe(e);
      i && i.l(c), c.forEach(P), this.h();
    },
    h() {
      Ne(e, "class", r = "wrap " + /*variant*/
      t[8] + " " + /*show_progress*/
      t[6] + " svelte-17v219f"), Fe(e, "hide", !/*status*/
      t[4] || /*status*/
      t[4] === "complete" || /*show_progress*/
      t[6] === "hidden" || /*status*/
      t[4] == "streaming"), Fe(
        e,
        "translucent",
        /*variant*/
        t[8] === "center" && /*status*/
        (t[4] === "pending" || /*status*/
        t[4] === "error") || /*translucent*/
        t[11] || /*show_progress*/
        t[6] === "minimal"
      ), Fe(
        e,
        "generating",
        /*status*/
        t[4] === "generating" && /*show_progress*/
        t[6] === "full"
      ), Fe(
        e,
        "border",
        /*border*/
        t[12]
      ), at(
        e,
        "position",
        /*absolute*/
        t[10] ? "absolute" : "static"
      ), at(
        e,
        "padding",
        /*absolute*/
        t[10] ? "0" : "var(--size-8) 0"
      );
    },
    m(u, c) {
      O(u, e, c), ~n && o[n].m(e, null), t[33](e), l = !0;
    },
    p(u, c) {
      let _ = n;
      n = s(u), n === _ ? ~n && o[n].p(u, c) : (i && (Ji(), Qe(o[_], 1, 1, () => {
        o[_] = null;
      }), Yi()), ~n ? (i = o[n], i ? i.p(u, c) : (i = o[n] = a[n](u), i.c()), Pe(i, 1), i.m(e, null)) : i = null), (!l || c[0] & /*variant, show_progress*/
      320 && r !== (r = "wrap " + /*variant*/
      u[8] + " " + /*show_progress*/
      u[6] + " svelte-17v219f")) && Ne(e, "class", r), (!l || c[0] & /*variant, show_progress, status, show_progress*/
      336) && Fe(e, "hide", !/*status*/
      u[4] || /*status*/
      u[4] === "complete" || /*show_progress*/
      u[6] === "hidden" || /*status*/
      u[4] == "streaming"), (!l || c[0] & /*variant, show_progress, variant, status, translucent, show_progress*/
      2384) && Fe(
        e,
        "translucent",
        /*variant*/
        u[8] === "center" && /*status*/
        (u[4] === "pending" || /*status*/
        u[4] === "error") || /*translucent*/
        u[11] || /*show_progress*/
        u[6] === "minimal"
      ), (!l || c[0] & /*variant, show_progress, status, show_progress*/
      336) && Fe(
        e,
        "generating",
        /*status*/
        u[4] === "generating" && /*show_progress*/
        u[6] === "full"
      ), (!l || c[0] & /*variant, show_progress, border*/
      4416) && Fe(
        e,
        "border",
        /*border*/
        u[12]
      ), c[0] & /*absolute*/
      1024 && at(
        e,
        "position",
        /*absolute*/
        u[10] ? "absolute" : "static"
      ), c[0] & /*absolute*/
      1024 && at(
        e,
        "padding",
        /*absolute*/
        u[10] ? "0" : "var(--size-8) 0"
      );
    },
    i(u) {
      l || (Pe(i), l = !0);
    },
    o(u) {
      Qe(i), l = !1;
    },
    d(u) {
      u && P(e), ~n && o[n].d(), t[33](null);
    }
  };
}
var Fd = function(t, e, n, i) {
  function r(l) {
    return l instanceof n ? l : new n(function(a) {
      a(l);
    });
  }
  return new (n || (n = Promise))(function(l, a) {
    function o(c) {
      try {
        u(i.next(c));
      } catch (_) {
        a(_);
      }
    }
    function s(c) {
      try {
        u(i.throw(c));
      } catch (_) {
        a(_);
      }
    }
    function u(c) {
      c.done ? l(c.value) : r(c.value).then(o, s);
    }
    u((i = i.apply(t, e || [])).next());
  });
};
let kn = [], Ai = !1;
const kd = typeof window < "u", No = kd ? window.requestAnimationFrame : (t) => {
};
function Ad(t) {
  return Fd(this, arguments, void 0, function* (e, n = !0) {
    if (!(window.__gradio_mode__ === "website" || window.__gradio_mode__ !== "app" && n !== !0)) {
      if (kn.push(e), !Ai) Ai = !0;
      else return;
      yield sd(), No(() => {
        let i = [0, 0];
        for (let r = 0; r < kn.length; r++) {
          const a = kn[r].getBoundingClientRect();
          (r === 0 || a.top + window.scrollY <= i[0]) && (i[0] = a.top + window.scrollY, i[1] = r);
        }
        window.scrollTo({ top: i[0] - 20, behavior: "smooth" }), Ai = !1, kn = [];
      });
    }
  });
}
function Cd(t, e, n) {
  let i, { $$slots: r = {}, $$scope: l } = e;
  const a = cd();
  let { i18n: o } = e, { eta: s = null } = e, { queue_position: u } = e, { queue_size: c } = e, { status: _ } = e, { scroll_to_output: h = !1 } = e, { timer: d = !0 } = e, { show_progress: D = "full" } = e, { message: E = null } = e, { progress: F = null } = e, { variant: C = "default" } = e, { loading_text: g = "Loading..." } = e, { absolute: f = !0 } = e, { translucent: m = !1 } = e, { border: v = !1 } = e, { autoscroll: p } = e, b, k = !1, y = 0, w = 0, A = null, B = null, N = 0, L = null, R, M = null, J = !0;
  const V = () => {
    n(0, s = n(27, A = n(19, x = null))), n(25, y = performance.now()), n(26, w = 0), k = !0, T();
  };
  function T() {
    No(() => {
      n(26, w = (performance.now() - y) / 1e3), k && T();
    });
  }
  function ee() {
    n(26, w = 0), n(0, s = n(27, A = n(19, x = null))), k && (k = !1);
  }
  ud(() => {
    k && ee();
  });
  let x = null;
  function te(I) {
    Va[I ? "unshift" : "push"](() => {
      M = I, n(16, M), n(7, F), n(14, L), n(15, R);
    });
  }
  const pe = () => {
    a("clear_status");
  };
  function $(I) {
    Va[I ? "unshift" : "push"](() => {
      b = I, n(13, b);
    });
  }
  return t.$$set = (I) => {
    "i18n" in I && n(1, o = I.i18n), "eta" in I && n(0, s = I.eta), "queue_position" in I && n(2, u = I.queue_position), "queue_size" in I && n(3, c = I.queue_size), "status" in I && n(4, _ = I.status), "scroll_to_output" in I && n(22, h = I.scroll_to_output), "timer" in I && n(5, d = I.timer), "show_progress" in I && n(6, D = I.show_progress), "message" in I && n(23, E = I.message), "progress" in I && n(7, F = I.progress), "variant" in I && n(8, C = I.variant), "loading_text" in I && n(9, g = I.loading_text), "absolute" in I && n(10, f = I.absolute), "translucent" in I && n(11, m = I.translucent), "border" in I && n(12, v = I.border), "autoscroll" in I && n(24, p = I.autoscroll), "$$scope" in I && n(29, l = I.$$scope);
  }, t.$$.update = () => {
    t.$$.dirty[0] & /*eta, old_eta, timer_start, eta_from_start*/
    436207617 && (s === null && n(0, s = A), s != null && A !== s && (n(28, B = (performance.now() - y) / 1e3 + s), n(19, x = B.toFixed(1)), n(27, A = s))), t.$$.dirty[0] & /*eta_from_start, timer_diff*/
    335544320 && n(17, N = B === null || B <= 0 || !w ? null : Math.min(w / B, 1)), t.$$.dirty[0] & /*progress*/
    128 && F != null && n(18, J = !1), t.$$.dirty[0] & /*progress, progress_level, progress_bar, last_progress_level*/
    114816 && (F != null ? n(14, L = F.map((I) => {
      if (I.index != null && I.length != null)
        return I.index / I.length;
      if (I.progress != null)
        return I.progress;
    })) : n(14, L = null), L ? (n(15, R = L[L.length - 1]), M && (R === 0 ? n(16, M.style.transition = "0", M) : n(16, M.style.transition = "150ms", M))) : n(15, R = void 0)), t.$$.dirty[0] & /*status*/
    16 && (_ === "pending" ? V() : ee()), t.$$.dirty[0] & /*el, scroll_to_output, status, autoscroll*/
    20979728 && b && h && (_ === "pending" || _ === "complete") && Ad(b, p), t.$$.dirty[0] & /*status, message*/
    8388624, t.$$.dirty[0] & /*timer_diff*/
    67108864 && n(20, i = w.toFixed(1));
  }, [
    s,
    o,
    u,
    c,
    _,
    d,
    D,
    F,
    C,
    g,
    f,
    m,
    v,
    b,
    L,
    R,
    M,
    N,
    J,
    x,
    i,
    a,
    h,
    E,
    p,
    y,
    w,
    A,
    B,
    l,
    r,
    te,
    pe,
    $
  ];
}
class Sd extends ad {
  constructor(e) {
    super(), ld(
      this,
      e,
      Cd,
      Ed,
      od,
      {
        i18n: 1,
        eta: 0,
        queue_position: 2,
        queue_size: 3,
        status: 4,
        scroll_to_output: 22,
        timer: 5,
        show_progress: 6,
        message: 23,
        progress: 7,
        variant: 8,
        loading_text: 9,
        absolute: 10,
        translucent: 11,
        border: 12,
        autoscroll: 24
      },
      null,
      [-1, -1]
    );
  }
}
const {
  HtmlTagHydration: i4,
  SvelteComponent: r4,
  add_render_callback: a4,
  append_hydration: l4,
  attr: o4,
  bubble: s4,
  check_outros: u4,
  children: c4,
  claim_component: h4,
  claim_element: f4,
  claim_html_tag: _4,
  claim_space: d4,
  claim_text: m4,
  create_component: p4,
  create_in_transition: g4,
  create_out_transition: b4,
  destroy_component: v4,
  detach: y4,
  element: w4,
  get_svelte_dataset: D4,
  group_outros: E4,
  init: F4,
  insert_hydration: k4,
  listen: A4,
  mount_component: C4,
  run_all: S4,
  safe_not_equal: x4,
  set_data: B4,
  space: $4,
  stop_propagation: T4,
  text: I4,
  toggle_class: L4,
  transition_in: H4,
  transition_out: P4
} = window.__gradio__svelte__internal, { createEventDispatcher: N4, onMount: O4 } = window.__gradio__svelte__internal, {
  SvelteComponent: R4,
  append_hydration: M4,
  attr: q4,
  bubble: U4,
  check_outros: G4,
  children: z4,
  claim_component: j4,
  claim_element: V4,
  claim_space: X4,
  create_animation: Z4,
  create_component: W4,
  destroy_component: Q4,
  detach: Y4,
  element: J4,
  ensure_array_like: K4,
  fix_and_outro_and_destroy_block: e5,
  fix_position: t5,
  group_outros: n5,
  init: i5,
  insert_hydration: r5,
  mount_component: a5,
  noop: l5,
  safe_not_equal: o5,
  set_style: s5,
  space: u5,
  transition_in: c5,
  transition_out: h5,
  update_keyed_each: f5
} = window.__gradio__svelte__internal, {
  SvelteComponent: _5,
  attr: d5,
  children: m5,
  claim_element: p5,
  detach: g5,
  element: b5,
  empty: v5,
  init: y5,
  insert_hydration: w5,
  noop: D5,
  safe_not_equal: E5,
  set_style: F5
} = window.__gradio__svelte__internal, {
  SvelteComponent: xd,
  append_hydration: Bd,
  attr: $d,
  children: Td,
  claim_element: Id,
  claim_text: Ld,
  detach: sl,
  element: Hd,
  init: Pd,
  insert_hydration: Nd,
  noop: ul,
  safe_not_equal: Od,
  text: Rd,
  toggle_class: Dt
} = window.__gradio__svelte__internal;
function Md(t) {
  let e, n;
  return {
    c() {
      e = Hd("div"), n = Rd(
        /*names_string*/
        t[2]
      ), this.h();
    },
    l(i) {
      e = Id(i, "DIV", { class: !0 });
      var r = Td(e);
      n = Ld(
        r,
        /*names_string*/
        t[2]
      ), r.forEach(sl), this.h();
    },
    h() {
      $d(e, "class", "svelte-1gecy8w"), Dt(
        e,
        "table",
        /*type*/
        t[0] === "table"
      ), Dt(
        e,
        "gallery",
        /*type*/
        t[0] === "gallery"
      ), Dt(
        e,
        "selected",
        /*selected*/
        t[1]
      );
    },
    m(i, r) {
      Nd(i, e, r), Bd(e, n);
    },
    p(i, [r]) {
      r & /*type*/
      1 && Dt(
        e,
        "table",
        /*type*/
        i[0] === "table"
      ), r & /*type*/
      1 && Dt(
        e,
        "gallery",
        /*type*/
        i[0] === "gallery"
      ), r & /*selected*/
      2 && Dt(
        e,
        "selected",
        /*selected*/
        i[1]
      );
    },
    i: ul,
    o: ul,
    d(i) {
      i && sl(e);
    }
  };
}
function qd(t, e, n) {
  let { value: i } = e, { type: r } = e, { selected: l = !1 } = e, { choices: a } = e, u = (i ? Array.isArray(i) ? i : [i] : []).map((c) => {
    var _;
    return (_ = a.find((h) => h[1] === c)) === null || _ === void 0 ? void 0 : _[0];
  }).filter((c) => c !== void 0).join(", ");
  return t.$$set = (c) => {
    "value" in c && n(3, i = c.value), "type" in c && n(0, r = c.type), "selected" in c && n(1, l = c.selected), "choices" in c && n(4, a = c.choices);
  }, [r, l, u, i, a];
}
class k5 extends xd {
  constructor(e) {
    super(), Pd(this, e, qd, Md, Od, {
      value: 3,
      type: 0,
      selected: 1,
      choices: 4
    });
  }
}
const {
  SvelteComponent: Ud,
  add_flush_callback: Gn,
  assign: Gd,
  bind: zn,
  binding_callbacks: jn,
  check_outros: zd,
  claim_component: Jn,
  claim_space: jd,
  create_component: Kn,
  destroy_component: ei,
  detach: cl,
  empty: hl,
  get_spread_object: Vd,
  get_spread_update: Xd,
  group_outros: Zd,
  init: Wd,
  insert_hydration: fl,
  mount_component: ti,
  safe_not_equal: Qd,
  space: Yd,
  transition_in: St,
  transition_out: xt
} = window.__gradio__svelte__internal;
function Jd(t) {
  let e, n, i, r;
  function l(s) {
    t[29](s);
  }
  function a(s) {
    t[30](s);
  }
  let o = {
    choices: (
      /*choices*/
      t[10]
    ),
    label: (
      /*label*/
      t[2]
    ),
    info: (
      /*info*/
      t[3]
    ),
    help: (
      /*help*/
      t[4]
    ),
    show_label: (
      /*show_label*/
      t[11]
    ),
    filterable: (
      /*filterable*/
      t[12]
    ),
    allow_custom_value: (
      /*allow_custom_value*/
      t[17]
    ),
    container: (
      /*container*/
      t[13]
    ),
    disabled: !/*interactive*/
    t[19]
  };
  return (
    /*value*/
    t[0] !== void 0 && (o.value = /*value*/
    t[0]), /*value_is_output*/
    t[1] !== void 0 && (o.value_is_output = /*value_is_output*/
    t[1]), e = new Z_({ props: o }), jn.push(() => zn(e, "value", l)), jn.push(() => zn(e, "value_is_output", a)), e.$on(
      "change",
      /*change_handler_1*/
      t[31]
    ), e.$on(
      "input",
      /*input_handler_1*/
      t[32]
    ), e.$on(
      "select",
      /*select_handler_1*/
      t[33]
    ), e.$on(
      "blur",
      /*blur_handler_1*/
      t[34]
    ), e.$on(
      "focus",
      /*focus_handler_1*/
      t[35]
    ), e.$on(
      "key_up",
      /*key_up_handler_1*/
      t[36]
    ), {
      c() {
        Kn(e.$$.fragment);
      },
      l(s) {
        Jn(e.$$.fragment, s);
      },
      m(s, u) {
        ti(e, s, u), r = !0;
      },
      p(s, u) {
        const c = {};
        u[0] & /*choices*/
        1024 && (c.choices = /*choices*/
        s[10]), u[0] & /*label*/
        4 && (c.label = /*label*/
        s[2]), u[0] & /*info*/
        8 && (c.info = /*info*/
        s[3]), u[0] & /*help*/
        16 && (c.help = /*help*/
        s[4]), u[0] & /*show_label*/
        2048 && (c.show_label = /*show_label*/
        s[11]), u[0] & /*filterable*/
        4096 && (c.filterable = /*filterable*/
        s[12]), u[0] & /*allow_custom_value*/
        131072 && (c.allow_custom_value = /*allow_custom_value*/
        s[17]), u[0] & /*container*/
        8192 && (c.container = /*container*/
        s[13]), u[0] & /*interactive*/
        524288 && (c.disabled = !/*interactive*/
        s[19]), !n && u[0] & /*value*/
        1 && (n = !0, c.value = /*value*/
        s[0], Gn(() => n = !1)), !i && u[0] & /*value_is_output*/
        2 && (i = !0, c.value_is_output = /*value_is_output*/
        s[1], Gn(() => i = !1)), e.$set(c);
      },
      i(s) {
        r || (St(e.$$.fragment, s), r = !0);
      },
      o(s) {
        xt(e.$$.fragment, s), r = !1;
      },
      d(s) {
        ei(e, s);
      }
    }
  );
}
function Kd(t) {
  let e, n, i, r;
  function l(s) {
    t[21](s);
  }
  function a(s) {
    t[22](s);
  }
  let o = {
    choices: (
      /*choices*/
      t[10]
    ),
    max_choices: (
      /*max_choices*/
      t[9]
    ),
    label: (
      /*label*/
      t[2]
    ),
    info: (
      /*info*/
      t[3]
    ),
    help: (
      /*help*/
      t[4]
    ),
    show_label: (
      /*show_label*/
      t[11]
    ),
    allow_custom_value: (
      /*allow_custom_value*/
      t[17]
    ),
    filterable: (
      /*filterable*/
      t[12]
    ),
    container: (
      /*container*/
      t[13]
    ),
    i18n: (
      /*gradio*/
      t[18].i18n
    ),
    disabled: !/*interactive*/
    t[19]
  };
  return (
    /*value*/
    t[0] !== void 0 && (o.value = /*value*/
    t[0]), /*value_is_output*/
    t[1] !== void 0 && (o.value_is_output = /*value_is_output*/
    t[1]), e = new I_({ props: o }), jn.push(() => zn(e, "value", l)), jn.push(() => zn(e, "value_is_output", a)), e.$on(
      "change",
      /*change_handler*/
      t[23]
    ), e.$on(
      "input",
      /*input_handler*/
      t[24]
    ), e.$on(
      "select",
      /*select_handler*/
      t[25]
    ), e.$on(
      "blur",
      /*blur_handler*/
      t[26]
    ), e.$on(
      "focus",
      /*focus_handler*/
      t[27]
    ), e.$on(
      "key_up",
      /*key_up_handler*/
      t[28]
    ), {
      c() {
        Kn(e.$$.fragment);
      },
      l(s) {
        Jn(e.$$.fragment, s);
      },
      m(s, u) {
        ti(e, s, u), r = !0;
      },
      p(s, u) {
        const c = {};
        u[0] & /*choices*/
        1024 && (c.choices = /*choices*/
        s[10]), u[0] & /*max_choices*/
        512 && (c.max_choices = /*max_choices*/
        s[9]), u[0] & /*label*/
        4 && (c.label = /*label*/
        s[2]), u[0] & /*info*/
        8 && (c.info = /*info*/
        s[3]), u[0] & /*help*/
        16 && (c.help = /*help*/
        s[4]), u[0] & /*show_label*/
        2048 && (c.show_label = /*show_label*/
        s[11]), u[0] & /*allow_custom_value*/
        131072 && (c.allow_custom_value = /*allow_custom_value*/
        s[17]), u[0] & /*filterable*/
        4096 && (c.filterable = /*filterable*/
        s[12]), u[0] & /*container*/
        8192 && (c.container = /*container*/
        s[13]), u[0] & /*gradio*/
        262144 && (c.i18n = /*gradio*/
        s[18].i18n), u[0] & /*interactive*/
        524288 && (c.disabled = !/*interactive*/
        s[19]), !n && u[0] & /*value*/
        1 && (n = !0, c.value = /*value*/
        s[0], Gn(() => n = !1)), !i && u[0] & /*value_is_output*/
        2 && (i = !0, c.value_is_output = /*value_is_output*/
        s[1], Gn(() => i = !1)), e.$set(c);
      },
      i(s) {
        r || (St(e.$$.fragment, s), r = !0);
      },
      o(s) {
        xt(e.$$.fragment, s), r = !1;
      },
      d(s) {
        ei(e, s);
      }
    }
  );
}
function em(t) {
  let e, n, i, r, l, a;
  const o = [
    {
      autoscroll: (
        /*gradio*/
        t[18].autoscroll
      )
    },
    { i18n: (
      /*gradio*/
      t[18].i18n
    ) },
    /*loading_status*/
    t[16]
  ];
  let s = {};
  for (let h = 0; h < o.length; h += 1)
    s = Gd(s, o[h]);
  e = new Sd({ props: s }), e.$on(
    "clear_status",
    /*clear_status_handler*/
    t[20]
  );
  const u = [Kd, Jd], c = [];
  function _(h, d) {
    return (
      /*multiselect*/
      h[8] ? 0 : 1
    );
  }
  return i = _(t), r = c[i] = u[i](t), {
    c() {
      Kn(e.$$.fragment), n = Yd(), r.c(), l = hl();
    },
    l(h) {
      Jn(e.$$.fragment, h), n = jd(h), r.l(h), l = hl();
    },
    m(h, d) {
      ti(e, h, d), fl(h, n, d), c[i].m(h, d), fl(h, l, d), a = !0;
    },
    p(h, d) {
      const D = d[0] & /*gradio, loading_status*/
      327680 ? Xd(o, [
        d[0] & /*gradio*/
        262144 && {
          autoscroll: (
            /*gradio*/
            h[18].autoscroll
          )
        },
        d[0] & /*gradio*/
        262144 && { i18n: (
          /*gradio*/
          h[18].i18n
        ) },
        d[0] & /*loading_status*/
        65536 && Vd(
          /*loading_status*/
          h[16]
        )
      ]) : {};
      e.$set(D);
      let E = i;
      i = _(h), i === E ? c[i].p(h, d) : (Zd(), xt(c[E], 1, 1, () => {
        c[E] = null;
      }), zd(), r = c[i], r ? r.p(h, d) : (r = c[i] = u[i](h), r.c()), St(r, 1), r.m(l.parentNode, l));
    },
    i(h) {
      a || (St(e.$$.fragment, h), St(r), a = !0);
    },
    o(h) {
      xt(e.$$.fragment, h), xt(r), a = !1;
    },
    d(h) {
      h && (cl(n), cl(l)), ei(e, h), c[i].d(h);
    }
  };
}
function tm(t) {
  let e, n;
  return e = new Xu({
    props: {
      visible: (
        /*visible*/
        t[7]
      ),
      elem_id: (
        /*elem_id*/
        t[5]
      ),
      elem_classes: (
        /*elem_classes*/
        t[6]
      ),
      padding: (
        /*container*/
        t[13]
      ),
      allow_overflow: !1,
      scale: (
        /*scale*/
        t[14]
      ),
      min_width: (
        /*min_width*/
        t[15]
      ),
      $$slots: { default: [em] },
      $$scope: { ctx: t }
    }
  }), {
    c() {
      Kn(e.$$.fragment);
    },
    l(i) {
      Jn(e.$$.fragment, i);
    },
    m(i, r) {
      ti(e, i, r), n = !0;
    },
    p(i, r) {
      const l = {};
      r[0] & /*visible*/
      128 && (l.visible = /*visible*/
      i[7]), r[0] & /*elem_id*/
      32 && (l.elem_id = /*elem_id*/
      i[5]), r[0] & /*elem_classes*/
      64 && (l.elem_classes = /*elem_classes*/
      i[6]), r[0] & /*container*/
      8192 && (l.padding = /*container*/
      i[13]), r[0] & /*scale*/
      16384 && (l.scale = /*scale*/
      i[14]), r[0] & /*min_width*/
      32768 && (l.min_width = /*min_width*/
      i[15]), r[0] & /*choices, max_choices, label, info, help, show_label, allow_custom_value, filterable, container, gradio, interactive, value, value_is_output, multiselect, loading_status*/
      999199 | r[1] & /*$$scope*/
      64 && (l.$$scope = { dirty: r, ctx: i }), e.$set(l);
    },
    i(i) {
      n || (St(e.$$.fragment, i), n = !0);
    },
    o(i) {
      xt(e.$$.fragment, i), n = !1;
    },
    d(i) {
      ei(e, i);
    }
  };
}
function nm(t, e, n) {
  let { label: i = "Dropdown" } = e, { info: r = void 0 } = e, { help: l = void 0 } = e, { elem_id: a = "" } = e, { elem_classes: o = [] } = e, { visible: s = !0 } = e, { multiselect: u = !1 } = e, { value: c = u ? [] : void 0 } = e, { value_is_output: _ = !1 } = e, { max_choices: h = null } = e, { choices: d } = e, { show_label: D } = e, { filterable: E } = e, { container: F = !0 } = e, { scale: C = null } = e, { min_width: g = void 0 } = e, { loading_status: f } = e, { allow_custom_value: m = !1 } = e, { gradio: v } = e, { interactive: p } = e;
  const b = () => v.dispatch("clear_status", f);
  function k($) {
    c = $, n(0, c);
  }
  function y($) {
    _ = $, n(1, _);
  }
  const w = () => v.dispatch("change"), A = () => v.dispatch("input"), B = ($) => v.dispatch("select", $.detail), N = () => v.dispatch("blur"), L = () => v.dispatch("focus"), R = () => v.dispatch("key_up");
  function M($) {
    c = $, n(0, c);
  }
  function J($) {
    _ = $, n(1, _);
  }
  const V = () => v.dispatch("change"), T = () => v.dispatch("input"), ee = ($) => v.dispatch("select", $.detail), x = () => v.dispatch("blur"), te = () => v.dispatch("focus"), pe = ($) => v.dispatch("key_up", $.detail);
  return t.$$set = ($) => {
    "label" in $ && n(2, i = $.label), "info" in $ && n(3, r = $.info), "help" in $ && n(4, l = $.help), "elem_id" in $ && n(5, a = $.elem_id), "elem_classes" in $ && n(6, o = $.elem_classes), "visible" in $ && n(7, s = $.visible), "multiselect" in $ && n(8, u = $.multiselect), "value" in $ && n(0, c = $.value), "value_is_output" in $ && n(1, _ = $.value_is_output), "max_choices" in $ && n(9, h = $.max_choices), "choices" in $ && n(10, d = $.choices), "show_label" in $ && n(11, D = $.show_label), "filterable" in $ && n(12, E = $.filterable), "container" in $ && n(13, F = $.container), "scale" in $ && n(14, C = $.scale), "min_width" in $ && n(15, g = $.min_width), "loading_status" in $ && n(16, f = $.loading_status), "allow_custom_value" in $ && n(17, m = $.allow_custom_value), "gradio" in $ && n(18, v = $.gradio), "interactive" in $ && n(19, p = $.interactive);
  }, [
    c,
    _,
    i,
    r,
    l,
    a,
    o,
    s,
    u,
    h,
    d,
    D,
    E,
    F,
    C,
    g,
    f,
    m,
    v,
    p,
    b,
    k,
    y,
    w,
    A,
    B,
    N,
    L,
    R,
    M,
    J,
    V,
    T,
    ee,
    x,
    te,
    pe
  ];
}
class A5 extends Ud {
  constructor(e) {
    super(), Wd(
      this,
      e,
      nm,
      tm,
      Qd,
      {
        label: 2,
        info: 3,
        help: 4,
        elem_id: 5,
        elem_classes: 6,
        visible: 7,
        multiselect: 8,
        value: 0,
        value_is_output: 1,
        max_choices: 9,
        choices: 10,
        show_label: 11,
        filterable: 12,
        container: 13,
        scale: 14,
        min_width: 15,
        loading_status: 16,
        allow_custom_value: 17,
        gradio: 18,
        interactive: 19
      },
      null,
      [-1, -1]
    );
  }
}
export {
  Fo as D,
  k5 as E,
  A5 as I,
  I_ as M,
  Z_ as a,
  Zr as c,
  rm as g
};
