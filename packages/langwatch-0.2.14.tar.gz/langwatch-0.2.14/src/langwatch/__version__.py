"""Version information for LangWatch."""

__version__ = "0.2.14"
