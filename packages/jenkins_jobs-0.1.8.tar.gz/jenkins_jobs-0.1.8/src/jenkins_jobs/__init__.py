"""Top-level package for Jenkins Jobs."""

__author__ = """Alceu Rodrigues de Freitas Junior"""
__email__ = 'glasswalk3r@yahoo.com.br'
__version__ = '0.1.6'
