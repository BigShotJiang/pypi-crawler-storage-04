=======
History
=======

0.0.1 (2021-02-14)
------------------

* First release on PyPI.
