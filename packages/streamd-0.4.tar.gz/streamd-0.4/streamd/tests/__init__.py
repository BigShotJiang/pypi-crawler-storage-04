"""Tests for StreaMD."""
