"""utility functions for StreaMD."""

