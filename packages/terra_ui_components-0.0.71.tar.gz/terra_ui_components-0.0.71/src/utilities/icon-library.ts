export {
    registerIconLibrary,
    unregisterIconLibrary,
} from '../components/icon/library.js'
