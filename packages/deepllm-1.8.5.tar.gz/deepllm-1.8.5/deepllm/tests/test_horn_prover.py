from deepllm.horn_prover import test_horn_prover

if __name__ == "__main__":
    test_horn_prover()
