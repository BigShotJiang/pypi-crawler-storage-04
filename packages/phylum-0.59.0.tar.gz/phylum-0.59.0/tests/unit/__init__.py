"""Create a package for unit tests.

The tests in this package should be small, fast, and focused on testing individual modules or functions therein.
"""
