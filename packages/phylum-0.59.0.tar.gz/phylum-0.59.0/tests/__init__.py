"""Create a package for tests.

This package is not intended to be included when building a wheel, but it will be when building a source distribution.
"""
