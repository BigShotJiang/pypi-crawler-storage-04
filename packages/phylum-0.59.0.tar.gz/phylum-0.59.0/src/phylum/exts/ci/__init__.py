"""Package for custom Phylum analysis extension."""

import pathlib

# Provide the path to this extension's directory
CI_EXT_PATH = pathlib.Path(__file__).resolve().parent
