"""Package for the phylum CI script."""

# Dynamically create the script name based on the package structure to help stay DRY
SCRIPT_NAME = __name__.replace(".", "-")
