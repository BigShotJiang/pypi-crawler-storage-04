"""Provide the `python -m <module_name>` format to 'run library module as a script'."""

from phylum.ci.cli import script_main

script_main()
