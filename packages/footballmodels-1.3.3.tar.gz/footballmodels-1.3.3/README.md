# footballmodels

Library for football models