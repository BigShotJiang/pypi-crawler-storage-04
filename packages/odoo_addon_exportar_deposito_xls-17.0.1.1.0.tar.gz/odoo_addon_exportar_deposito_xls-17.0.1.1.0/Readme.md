Exportar depositos en Excel v13
Versión Devcontrol

=================================
This module helps you to take current stock report for all products in each warehouse.


Configuration
=============
* No additional configurations needed

Company
-------
* `Cybrosys Techno Solutions <https://cybrosys.com/>`__

Credits
-------
* Developers: 	Cybrosys Techno Solutions odoo@cybrosys.com
		Alex Berbel (KOMUN.ORG para Descontrol)
Contacts
--------
* Mail Contact : odoo@cybrosys.com
* Website : https://cybrosys.com

Bug Tracker
-----------
Bugs are tracked on GitHub Issues. In case of trouble, please check there if your issue has already been reported.

Maintainer
==========
.. image:: https://cybrosys.com/images/logo.png
   :target: https://cybrosys.com

This module is maintained by Cybrosys Technologies.

For support and more information, please visit `Our Website <https://cybrosys.com/>`__

Further information
===================
HTML Description: `<static/description/index.html>`__
