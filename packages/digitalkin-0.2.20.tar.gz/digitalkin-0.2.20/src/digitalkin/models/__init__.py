"""This package contains the models for DigitalKin."""

from digitalkin.models.module import Module, ModuleStatus

__all__ = [
    "Module",
    "ModuleStatus",
]
