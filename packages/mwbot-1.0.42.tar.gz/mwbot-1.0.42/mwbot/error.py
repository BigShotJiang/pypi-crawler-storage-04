class mwbotLoginError(Exception):
    pass