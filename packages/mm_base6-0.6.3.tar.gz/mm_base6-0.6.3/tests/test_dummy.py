def test_dummy() -> None:
    assert True
