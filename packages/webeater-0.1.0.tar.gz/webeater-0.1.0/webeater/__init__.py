"""
WebEater - A web content extraction tool designed to fetch and process web pages efficiently.

This package provides tools for extracting structured data from web pages using
Selenium and BeautifulSoup, with configurable hints and extraction strategies.
"""

from webeater.eater import Webeater

__version__ = "0.1.0"
__author__ = "Tiago Ribeiro"
__email__ = "webeater@tiagoribeiro.pt"
__license__ = "MIT"

# For backward compatibility
WebeaterEngine = Webeater

__all__ = ["Webeater", "WebeaterEngine"]
