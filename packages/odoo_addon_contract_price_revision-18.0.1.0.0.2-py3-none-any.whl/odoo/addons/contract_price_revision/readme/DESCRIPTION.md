This module allows to create revisions of contract line prices.
