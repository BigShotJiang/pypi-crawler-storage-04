:orphan:

==========================
Making kernels for IPython
==========================

Kernels are now part of Jupyter - see
:ref:`jupyterclient:kernels` for the documentation.
