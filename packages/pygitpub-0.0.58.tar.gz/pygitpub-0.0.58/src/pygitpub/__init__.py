"""
Initialize the module
"""

LOGGER_NAME = "pygitpub"
