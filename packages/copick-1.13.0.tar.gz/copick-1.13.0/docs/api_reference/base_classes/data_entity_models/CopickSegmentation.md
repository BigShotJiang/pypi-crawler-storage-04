[](){#CopickSegmentation}
::: copick.models.CopickSegmentation
