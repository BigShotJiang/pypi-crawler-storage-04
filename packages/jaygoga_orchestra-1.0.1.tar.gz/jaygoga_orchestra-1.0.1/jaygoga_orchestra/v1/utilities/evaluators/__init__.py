from rich.console import Console
console = Console()
"""Evaluators for crewAI."""
