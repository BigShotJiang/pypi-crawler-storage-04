from rich.console import Console
console = Console()
"""Agent tools for crewAI."""
