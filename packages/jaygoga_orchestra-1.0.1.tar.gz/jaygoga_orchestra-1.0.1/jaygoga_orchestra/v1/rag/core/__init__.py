from rich.console import Console
console = Console()
"""Core abstract base classes and protocols for RAG  systems."""
