<!-- These are examples of badges you might want to add to your README:
     please update the URLs accordingly

[![Built Status](https://api.cirrus-ci.com/github/<USER>/eth-pretty-events.svg?branch=main)](https://cirrus-ci.com/github/<USER>/eth-pretty-events)
[![ReadTheDocs](https://readthedocs.org/projects/eth-pretty-events/badge/?version=latest)](https://eth-pretty-events.readthedocs.io/en/stable/)
[![Coveralls](https://img.shields.io/coveralls/github/<USER>/eth-pretty-events/main.svg)](https://coveralls.io/r/<USER>/eth-pretty-events)
[![PyPI-Server](https://img.shields.io/pypi/v/eth-pretty-events.svg)](https://pypi.org/project/eth-pretty-events/)
[![Conda-Forge](https://img.shields.io/conda/vn/conda-forge/eth-pretty-events.svg)](https://anaconda.org/conda-forge/eth-pretty-events)
[![Monthly Downloads](https://pepy.tech/badge/eth-pretty-events/month)](https://pepy.tech/project/eth-pretty-events)
[![Twitter](https://img.shields.io/twitter/url/http/shields.io.svg?style=social&label=Twitter)](https://twitter.com/eth-pretty-events)
-->

[![Project generated with PyScaffold](https://img.shields.io/badge/-PyScaffold-005CA0?logo=pyscaffold)](https://pyscaffold.org/)

# eth-pretty-events

> A library for parsing, filterning and formatting EVM events

A longer description of your project goes here...

<!-- pyscaffold-notes -->

## Note

This project has been set up using PyScaffold 4.5. For details and usage
information on PyScaffold see https://pyscaffold.org/.
