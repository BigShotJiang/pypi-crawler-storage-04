from .core import MWUTSDZ

