"""A set of rich enums for various purposes."""
