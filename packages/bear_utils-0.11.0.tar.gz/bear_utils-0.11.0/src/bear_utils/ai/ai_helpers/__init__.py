"""Helper utilities for constructing AI endpoints with custom response parsing."""
