"""
CosmosDB Isolation Utils

A Python library providing utilities for Azure CosmosDB isolation and testing.
"""

from .__main__ import main

__version__ = "0.1.0"
__author__ = "Starforge Worker"
__email__ = "star.forge.worker@gmail.com"

__all__ = ['main']
