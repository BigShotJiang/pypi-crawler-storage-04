DEVICE_TYPE = "plate reader"
