DISPLAY_NAME = "Thermo Fisher Scientific Nanodrop One"
