LUMINESCENCE = "luminescence"
LUMINESCENCE_DETECTOR = "luminescence detector"
