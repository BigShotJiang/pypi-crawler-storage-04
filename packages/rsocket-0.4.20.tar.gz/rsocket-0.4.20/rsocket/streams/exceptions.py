class FinishedIterator(Exception):
    pass
