.. Silver Fund Quant documentation master file, created by
   sphinx-quickstart on Wed Aug 27 08:33:05 2025.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Silver Fund Quant documentation
===============================

.. toctree::
   :maxdepth: 1
   :caption: Reference

   reference/data
   reference/optimizer
   reference/backtester
   reference/performance

