# DatasetLocatorFieldDataType


## Enum

* `UUID` (value: `'UUID'`)

* `STRING` (value: `'string'`)

* `ENUM` (value: `'enum'`)

* `REGEX_STRING` (value: `'regex_string'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


