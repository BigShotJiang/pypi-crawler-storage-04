2024-10-15 Version: 3.2.2
- Update API PlayVideoFile: add param OnlyPhone.
- Update API PlayVideoFile: update param CalledNumber.


2024-04-26 Version: 3.2.1
- Generated python 2017-05-25 for Dyvmsapi.

2024-04-25 Version: 3.2.0
- Support API GetCallMediaType.
- Support API GetTemporaryFileUrl.


2024-04-18 Version: 3.1.0
- Support API ChangeMediaType.
- Support API DegradeVideoFile.
- Support API GetCallProgress.
- Support API GetVideoFieldUrl.
- Support API PauseVideoFile.
- Support API PlayVideoFile.
- Support API QueryVideoPlayProgress.
- Support API ResumeVideoFile.
- Support API SeekVideoFile.
- Support API SingleCallByVideo.
- Support API SkipVideoFile.
- Support API UpgradeVideoFile.
- Update API SmartCall: add param NoiseThreshold.


2024-02-23 Version: 3.0.0
- Delete API AddRtcAccount.
- Delete API GetCallInfo.
- Delete API GetMqttToken.
- Delete API GetRtcToken.
- Delete API RefreshMqttToken.
- Update API CancelRobotTask: update param TaskId.
- Update API GetToken: update param AccessKeyId.
- Update API IvrCall: update param MenuKeyMap.
- Update API ListCallTaskDetail: update param AccessKeyId.


2022-04-20 Version: 2.1.4
- Update SDK.

2022-02-08 Version: 2.1.3
- Update SDK.

2022-01-20 Version: 2.1.2
- Add QueryVoiceFileAuditInfo.

2021-11-29 Version: 2.1.1
- Update Dyvmsapi SDK.

2021-10-26 Version: 2.1.0
- Update Dyvmsapi SDK.

2021-07-30 Version: 2.0.2
- Update Dyvmsapi SDK.

2021-07-07 Version: 2.0.1
- Generated python 2017-05-25 for Dyvmsapi.

2021-01-30 Version: 2.0.0
- Generated python 2017-05-25 for Dyvmsapi.

