# Resvg Module

```{eval-rst}

.. currentmodule:: resvg_py

.. autofunction:: svg_to_bytes

.. autoclass:: __version__


.. autoclass:: __author__

```
