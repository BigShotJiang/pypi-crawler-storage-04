def about():
    return "17 time world champion"
def name():
    return "john cena"
def age():
    return 50

