from example import age
print(about())
