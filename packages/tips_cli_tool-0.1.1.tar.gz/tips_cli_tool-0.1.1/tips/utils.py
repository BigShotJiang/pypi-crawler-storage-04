"""
Utility functions for the Tips CLI tool.
"""

import os
from pathlib import Path

# This file can be expanded with more utilities as needed.
# For now, it's a placeholder for future utility functions.