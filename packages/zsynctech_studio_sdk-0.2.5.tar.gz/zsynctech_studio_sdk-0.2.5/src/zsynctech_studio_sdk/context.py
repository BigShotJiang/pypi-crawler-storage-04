class Context:
    execution = None
    task = None
    step = None