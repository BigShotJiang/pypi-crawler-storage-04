# Toml_update

Automatically update `pyproject.toml` with a simple command:

```bash
toml_update
```

This project is not yet in release version.


# Installation

```bash
pip install toml_update
```

# Requirements

None! 

Simplicity is the key focus of this project.