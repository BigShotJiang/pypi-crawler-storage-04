# ☕ FilterKaapi Language

FilterKaapi is a **Tamil-inspired programming language** written in Python.  
Just like Chennai's famous filter coffee, this language is simple, strong, and gives a warm kick to coding!

🖋️ **Keywords are in Tamil** to make coding feel closer to home:

- `kaapi` → print (like pouring kaapi ☕)
- `vechiko` → variable declaration (means "keep it")
- `iruntha ... ilana ...` → if ... else
- `varai` → while loop
- `seyyu` → Functions
- `notepaniko` → Input from user
- `push,pop,remove,length` → List operations

---

## 🚀 Features

- 📝 **Tamil keywords** for programming basics
- ➕ Arithmetic operations (`+`, `-`, `*`, `/`, `%`, `//`)
- 🔑 Variables with `vechiko`
- 🔍 Conditional logic with `iruntha ... ilana ...`
- 🔁 `varai` for loops
- 📦 `seyyu` for functions
- 🖥️ REPL and script execution support
- 📋 List support with built-in functions:
  - `push` → add an element to a list
  - `pop` → remove last element
  - `remove` → remove a specific value
  - `length` → get list size

---

## 📦 Installation

For now, install from source:

```bash
git clone https://github.com/chiddesh/filterKaapi.git
cd filterKaapi
pip install .
```

### After installation, run:

```bash
kaapi main.kaapi
```

Or start the interactive REPL:

```bash
kaapi
```

### 🔤 Language Syntax

Input

```bash
notepaniko <var_name> "message"
```

- example
  ```bash
  notepaniko name "Enter Name"
  kaapi name
  ```
- output
  ```bash
  "Enter Name:" your_name
  your_name
  ```

Printing

```bash
kaapi "Vanakkam Chennai!"
```

- output

  ```bash
  Vanakkam Chennai!
  ```

Variables

```bash
vechiko x = 10
kaapi x
```

- output

  ```bash
  10
  ```

Lists

```bash
vechiko myList = [1,2,3,4,5]
kaapi myList
```

- output
  ```bash
  [1,2,3,4,5]
  ```

List Operations

```bash
vechiko myList = [1,2,3,4,5]
kaapi myList[0] → indexing
push myList[6] → push operation appends
kaapi myList
pop mylist → pop's last element
kaapi myList
remove myList[1] → remove a particular element
kaapi myList
len myList → print the length of the list
kaapi myList
```

- output
  ```bash
  1 → after indexing
  [1,2,3,4,5,6] → after push operation
  [1,2,3,4,5] → after pop operation
  [2,3,4,5] → after remove operation
  4 → len operation
  ```

Arithmetic

```bash
kaapi (5 + 3) * 2
```

- output

  ```bash
  10
  ```

Functions

```bash
seyyu function_name(args)
    body
mudinchu
```

- example

  ```bash
  seyyu add(a,b)
      kaapi a + b
  mudinchu

  add(2,5)
  ```

- output

  ```bash
  7
  ```

If/Else

```bash
5 > 3 iruntha kaapi "Periya number" ilana kaapi "Siriya number"
```

- output

  ```bash
  Periya number
  ```

While Loop

```bash
vechiko i = 0
varai i < 5
    kaapi i
    vechiko i = i + 1
end
```

- output

  ```bash
  0
  1
  2
  3
  4
  ```

## 🛠 Project Structure

```bash
kaapi_lang/
 ├── __init__.py
 ├── cli.py           # CLI entry point
 ├── interpreter.py   # Evaluator
 ├── lexer.py         # Tokenizer
 ├── parser.py        # Parser
 └── main.py          # Runner

setup.py              # For packaging
```

# 👨‍💻 Author

Created with ❤️ in Chennai by Chiddesh Ram\
Inspired by strong Filter Kaapi and a love for coding.
