idds-atlas
====

idds-atlas subpackage is for CERN ATLAS specific functions and plugins.
With it, iDDS can support CERN ATLAS workflows.
