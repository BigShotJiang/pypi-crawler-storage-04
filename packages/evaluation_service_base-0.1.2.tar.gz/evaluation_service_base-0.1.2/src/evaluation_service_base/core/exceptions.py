
class TaskCancelledException(Exception):
    pass

