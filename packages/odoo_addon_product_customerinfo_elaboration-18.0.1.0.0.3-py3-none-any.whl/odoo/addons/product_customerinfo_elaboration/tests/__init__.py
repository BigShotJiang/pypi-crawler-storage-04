from . import test_customerinfo_elaboration
