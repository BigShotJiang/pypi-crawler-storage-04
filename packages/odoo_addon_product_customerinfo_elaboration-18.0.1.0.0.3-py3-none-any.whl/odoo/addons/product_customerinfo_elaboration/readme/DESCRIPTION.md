This modules allows to use customers info structure, available in
*Sales* tab of the product form, also for defining customer
information, allowing to define default elaboration per customer and
product.
