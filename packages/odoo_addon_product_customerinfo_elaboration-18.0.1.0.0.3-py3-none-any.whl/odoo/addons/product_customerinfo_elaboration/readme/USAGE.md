To use this module, you need to:

1.  Go to *Sales \> Products \> Products*
2.  Create or select one of existing
3.  Go to window *Sales* and create a new entry for some customer
4.  Select one elaboration and one elaboration note

After this create a new quotation and select the partner with that was
configured. You will see that the elaboration and the elaboration note
is completed.
