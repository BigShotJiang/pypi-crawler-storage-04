# surfari/tests/test_mcp_client_integration.py
import sys
import os
import asyncio
from pathlib import Path

# Make repo root importable (…/surfari)
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from surfari.model.mcp.manager import MCPClientManager
from surfari.model.mcp.tool_registry import MCPToolRegistry
from surfari.model.mcp.types import MCPServerInfo

SERVER_URL = "http://localhost:8000/mcp"
STDIO_SERVER = Path(__file__).resolve().parent / "my_mcp_stdio_server.py"
RESOURCE_URI = "test://hello"   # only works if your server registers this resource

async def main_http():
    print("\n=== HTTP mode: Manager.add_server(url) -> Registry ===")
    # Build MCPServerInfo; allow a dynamic 'url' attribute if your dataclass lacks it
    http_info = MCPServerInfo(
        id="http_server",
        command="", args=[], env={}, cwd=""  # placeholders; not used for HTTP
    )
    setattr(http_info, "url", SERVER_URL)

    mgr = MCPClientManager()
    await mgr.add_server(http_info)  # auto-picks HTTP session

    registry = MCPToolRegistry(mgr)
    await registry.refresh(server_ids=["http_server"])

    names = registry.list_function_names()
    print("Discovered tools (HTTP):", names)

    add_fn = next((n for n in names if n.endswith("__add")), None)
    if add_fn:
        r = await registry.execute(add_fn, {"a": 5, "b": 3}, timeout_s=10)
        print("add() [HTTP] ->", r.data if r.ok else f"ERROR: {r.error}")

    # Only try process_data if your server can read a resource
    proc_fn = next((n for n in names if n.endswith("__process_data")), None)
    if proc_fn:
        r2 = await registry.execute(proc_fn, {"uri": RESOURCE_URI}, timeout_s=15)
        print("process_data() [HTTP] ->", r2.data if r2.ok else f"ERROR: {r2.error}")

    await mgr.aclose()

async def main_stdio():
    print("\n=== STDIO mode: Manager.add_server(command/args) -> Registry ===")
    env = os.environ.copy()
    stdio_info = MCPServerInfo(
        id="stdio_server",
        command=sys.executable,
        args=["-u", str(STDIO_SERVER)],
        env=env,
        cwd=str(STDIO_SERVER.parent),
    )

    mgr = MCPClientManager()
    # Default prefers FastMCP stdio (robust with your server)
    await mgr.add_server(stdio_info)  # or: await mgr.add_server(stdio_info, prefer="mcp_stdio")

    registry = MCPToolRegistry(mgr)
    await registry.refresh(server_ids=["stdio_server"])

    names = registry.list_function_names()
    print("Discovered tools (STDIO):", names)

    add_fn = next((n for n in names if n.endswith("__add")), None)
    if add_fn:
        r = await registry.execute(add_fn, {"a": 5, "b": 3}, timeout_s=10)
        print("add() [STDIO] ->", r.data if r.ok else f"ERROR: {r.error}")
    else:
        print("No 'add' tool exposed over STDIO.")

    proc_fn = next((n for n in names if n.endswith("__process_data")), None)
    if proc_fn:
        r2 = await registry.execute(proc_fn, {"uri": RESOURCE_URI}, timeout_s=15)
        print("process_data() [STDIO] ->", r2.data if r2.ok else f"ERROR: {r2.error}")
        
    await mgr.aclose()

if __name__ == "__main__":
    async def _both():
        await main_http()
        await main_stdio()
    asyncio.run(_both())
