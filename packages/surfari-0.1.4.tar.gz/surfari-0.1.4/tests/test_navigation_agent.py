import asyncio
from surfari.util.cdp_browser import ChromiumManager
from surfari.util.surfari_logger import getLogger
from surfari.agents.navigation_agent import NavigationAgent
from surfari.agents.tools.account_tool._tool_definition import tools as account_tools
from surfari.agents.tools.gmail_tools import TOOLS as gmail_tools
from surfari.model.mcp.manager import MCPClientManager
from surfari.model.mcp.tool_registry import MCPToolRegistry
from surfari.model.mcp.types import MCPServerInfo

logger = getLogger(__name__)

TEST_CASES = {
    1: ("Schwab", "login to Schwab online banking first, and report balances or all my accounts and investment positions using tools."), 
    2: ("Schwab", "login to schwab site, for each account, send yonghui.zhang.ca@gmail.com an email with gmail on its balance and today's change."),
    3: ("Schwab", "login to schwab site, get all accounts with account number, cash balances, total balances, today's changes and put in a new google sheet."),
    4: ("Schwab", "login to schwab site, get all accounts with account number, cash balances, total balances, today's changes and put in a new google doc."),
    5: ("Schwab", "login to schwab site, get all accounts with account number, total balances, compare them with my Wells Fargo accounts for zelle"),
    6: ("Schwab", "login to schwab site, get all accounts with account number, total balances, send myself an email to yonghui.zhang.ca@gmail.com with account info subject, and all accounts info in the body. As soon as an email is sent, mark the task success. Numbers don't matter."),
    7: ("Schwab", "login to schwab site, get all accounts with masked account number, account values, and today's changes. create a google sheet. mark task successful as soon as sheet is created."),
    8: ("Schwab", "login to schwab site, from the summary page, get all accounts with account number, total balances, and today's changes. compare with Sheet1 of 1-DWcPuSckOobmHt_1RgjxrcsA1ZIHtpa-9plZBcVax4, anything changed?"),
    9: ("Schwab", "login to schwab site, from the summary page, get any two accounts and add their values and tell me the sum? you must call a tool to calculate it.")
}

async def test_navigation_agent():
    test_case = 9  # Change this to run a different test case
    if test_case not in TEST_CASES:
        logger.error(f"Invalid test_case: {test_case}")
        return

    site_name, task_goal = TEST_CASES[test_case]
    logger.info(f"Running test case {test_case}: {site_name} → {task_goal}")

    manager = await ChromiumManager.get_instance(use_system_chrome=False)
    context = manager.browser_context
    page = await context.new_page()

    SERVER_URL = "http://localhost:8000/mcp"   # your running FastMCP server

    info = MCPServerInfo(
        id="local_http_server",
        command="", args=[], env={}, cwd=""   # placeholders; not used for HTTP
    )
    # If MCPServerInfo doesn’t have a 'url' field, attach it dynamically:
    setattr(info, "url", SERVER_URL)

    mgr = MCPClientManager()
    await mgr.add_server(info)  # manager chooses MCPHTTPClientSession

    # 2) Registry discovery
    mcp_reg = MCPToolRegistry(mgr)
    await mcp_reg.refresh(server_ids=["local_http_server"])
    
    site_list = []

    site_list.append({"site_name": "Wells Fargo", "url": "https://www.wellsfargo.com/", "purpose": "For paying others through Zelle"})
    site_list.append({"site_name": "Venmo", "url": "https://www.venmo.com/", "purpose": "Sending money to friends with Venmo"})
    site_list.append({"site_name": "Gmail", "url": "https://mail.google.com/", "purpose": "For sending emails with Gmail"})
    site_list.append({"site_name": "Google Sheets", "url": "https://sheets.google.com/", "purpose": "For managing spreadsheets with Google Sheets"})
    site_list.append({"site_name": "Google Docs", "url": "https://docs.google.com/", "purpose": "For creating and editing documents with Google Docs"})

    nav_agent = NavigationAgent(site_name=site_name, 
                                enable_data_masking=False, 
                                tools=gmail_tools,
                                multi_action_per_turn=True,
                                mcp_tool_registry=mcp_reg,
                                agent_delegation_site_list=site_list)

    answer = await nav_agent.run(page, task_goal=task_goal)
    logger.info("Final answer:", answer)

if __name__ == "__main__":
    asyncio.run(test_navigation_agent())
