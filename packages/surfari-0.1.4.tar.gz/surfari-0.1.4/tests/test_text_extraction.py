import asyncio
import re
import time
from typing import List, Dict, Any

import surfari.util.surfari_logger as surfari_logger
import surfari.view.text_layouter as text_layouter
from surfari.util.cdp_browser import ChromiumManager
from surfari.view.full_text_extractor import WebPageTextExtractor
import surfari.util.playwright_util as playwright_util

logger = surfari_logger.getLogger(__name__)


async def lookup_interactive_elements(full_page_text: str, extractor: WebPageTextExtractor, page) -> List[Dict[str, Any]]:
    """
    Look up interactive elements in the full page text using the extractor.
    """
    # This function will use the extractor to find interactive elements
    # in the full_page_text and return their details.
    pattern = WebPageTextExtractor.TEXT_LINE_PATTERN

    for lineno, raw in enumerate(full_page_text.splitlines(), 1):
        line = raw.strip()
        if not line:
            continue
        m = pattern.match(line)
        print(f"Processing line {lineno}: {line}")
        if not m:
            # Optional: log skipped lines
            logger.debug(f"Line {lineno} did not match TEXT_LINE_PATTERN: {line}")
            continue

        gd = m.groupdict()
        content = gd.get("content", "")
        if (extractor.BRACKET_RE.match(content) or extractor.ICON_RE.match(content)):
            locator, _ = await extractor.get_locator_from_text(page, content)
            if locator:
                await playwright_util.highlight_elements(page, [locator])


async def extract_and_eval_locators(full_page_text: str, extractor: WebPageTextExtractor, page) -> List[Dict[str, Any]]:
    """
    Parse each line, extract locator_string, and eval it against the given `page`.
    Returns a list of dicts containing frame_name, content, xpath, locator_string, and locator object.
    """
    results: List[Dict[str, Any]] = []
    pattern = WebPageTextExtractor.TEXT_LINE_PATTERN

    for lineno, raw in enumerate(full_page_text.splitlines(), 1):
        line = raw.strip()
        if not line:
            continue
        m = pattern.match(line)
        print(f"Processing line {lineno}: {line}")
        if not m:
            # Optional: log skipped lines
            logger.debug(f"Line {lineno} did not match TEXT_LINE_PATTERN: {line}")
            continue

        gd = m.groupdict()
        locator_string = gd.get("locator_string", "")
        content = gd.get("content", "")
        locator_old, _ = await extractor.get_locator_from_text(page, content)
        locator = None
        if locator_string:
            try:
                locator = eval(locator_string)
            except Exception as e:
                # log or raise depending on your needs
                # logger.error(f"Eval failed on line {lineno}: {locator_string} -> {e}")
                print(f"Eval failed on line {lineno}: {locator_string} -> {e}")
                pass

        results.append({
            "line_no": lineno,
            "frame_name": gd.get("frame_name", ""),
            "content": gd.get("content", ""),
            "xpath": gd.get("xpath", ""),
            "locator_string": locator_string,
            "locator": locator,   # <-- actual Playwright locator (or None if failed)
            "locator_old": locator_old,
            "raw": line,
        })

    return results

async def print_and_highlight_locators(page, full_page_text, extractor):
    locators_info = await extract_and_eval_locators(full_page_text, extractor, page)
    interactive_el_cnt = 0
    locator_string_cnt = 0
    locator_cnt = 0
    unique_locator_cnt = 0
    
    for item in locators_info:
        content = item["content"]
        if content:
            if (extractor.BRACKET_RE.match(content) or extractor.ICON_RE.match(content)):
                interactive_el_cnt += 1
                if item["locator_string"]:
                    locator_string_cnt += 1
                else: item["locator_string"] = "No locator generated for this element"
                    
                if item["locator"]:
                    locator_cnt += 1   
                    resolved = await item["locator"].count()
                    if resolved == 1:
                        unique_locator_cnt += 1
                        # await playwright_util.highlight_elements(page, [item["locator"]])

                    print(item["line_no"], item["content"], "Found " + str(resolved) + " Items",  item["locator_string"], item["xpath"])
                else:
                    print(item["line_no"], item["content"], item["locator_string"], item["xpath"])
            else:
                print(item["line_no"], item["content"], item["locator_string"] if item["locator_string"] else "No locator generated for non-interactive element", item["xpath"])
        else:
            print(item["line_no"], "No content", item["locator_string"] if item["locator_string"] else "No locator generated for empty content", item["xpath"])
            continue

    print(f"Interactive elements: {interactive_el_cnt}, with locator string: {locator_string_cnt}, with locator object: {locator_cnt}, unique locators: {unique_locator_cnt}")
# =============================================================================
# Main Program
# =============================================================================
async def main():
    manager = await ChromiumManager.get_instance(use_system_chrome=False)
    context = manager.browser_context
    page = context.pages[0]
    # page.on("console", lambda msg: logger.debug(f"Console message: {msg.type}: {msg.text}"))
    await page.expose_function("pyLog", lambda *args: logger.debug(*args))

    await page.goto("https://www.amazon.com", wait_until="load")
    # await page.goto("https://www.kayak.com/flights", wait_until="load")
    # await page.goto('https://www.amazon.com/s?k=laptop&s=review-rank&crid=1RZCEJ289EUSI&qid=1740202453&sprefix=laptop%2Caps%2C166&ref=sr_st_review-rank&ds=v1%3A4EnYKXVQA7DIE41qCvRZoNB4qN92Jlztd3BPsTFXmxU', wait_until="load")
    # await page.goto("https://www.schwab.com/client-home", wait_until="load")
    # await page.goto("https://myedd.edd.ca.gov/s/login/?language=en_US&ec=302&startURL=%2Fs%2F", wait_until="load")            
    # await page.goto("https://www.wellsfargo.com", wait_until="load")
    # await page.goto("https://www.bankofamerica.com", wait_until="load")
    # await page.goto("https://www.google.com/", wait_until="load")
    # await page.goto("https://gmail.google.com/", wait_until="load")            
    # await page.goto("https://www.united.com", wait_until="load")
    # await page.goto("https://www.southwest.com", wait_until="load")            
    # await page.goto("https://www.booking.com/flights", wait_until="load")
    # await page.goto("https://www.google.com/travel/flights", wait_until="load")
    
    # await page.goto("https://web.oncentrl.com/#/login", wait_until="load")
    # await page.goto("https://www.ally.com", wait_until="load")
    # await page.goto("https://www.expedia.com", wait_until="load")
    # await page.goto("https://calendar.google.com", wait_until="load")
    # await page.goto("https://mail.google.com", wait_until="load")            
    # await page.goto("https://www.linkedin.com/feed/", wait_until="load")
    # await page.goto("https://playwright.dev/python/docs/api/class-locator#locator-evaluate", wait_until="load")
    # await playwright_util.inject_control_bar(page)
    counter = 0
    while counter < 20:  
        counter += 1
        input("Press Enter to continue...")
        # await page.wait_for_timeout(10000)
        await page.wait_for_timeout(2000)

        
        extractor = WebPageTextExtractor()

        full_page_text, legend_dict = await extractor.get_full_text(page)
        await logger.log_text_to_file("999", full_page_text, "content")
        legend_str = extractor.filter_legend(legend_dict)
        full_page_text_layout = text_layouter.rearrange_texts(full_page_text, additional_text=legend_str)
        await logger.log_text_to_file("999", full_page_text_layout, "layout")
        # # await print_and_highlight_locators(page, full_page_text, extractor)
        # await lookup_interactive_elements(full_page_text, extractor, page)

    logger.info("Page loaded. waiting for browser to be closed manually...")
    await context.wait_for_event("close")

    if ChromiumManager._instance:
        await ChromiumManager._instance.stop()                                  
                            
if __name__ == "__main__":
    asyncio.run(main())
