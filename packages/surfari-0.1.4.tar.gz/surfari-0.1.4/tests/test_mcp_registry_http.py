# surfari/tests/test_registry_http_only.py
import sys
import asyncio
from pathlib import Path

# Make repo root importable (…/surfari)
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from surfari.model.mcp.manager import MCPClientManager
from surfari.model.mcp.tool_registry import MCPToolRegistry
from surfari.model.mcp.types import MCPServerInfo

SERVER_URL = "http://localhost:8000/mcp"   # your running FastMCP server
RESOURCE_URI = "test://hello"              # only works if your server registered it

async def main():
    # 1) Build manager with an HTTP server
    info = MCPServerInfo(
        id="http_server",
        command="", args=[], env={}, cwd=""   # placeholders; not used for HTTP
    )
    # If MCPServerInfo doesn’t have a 'url' field, attach it dynamically:
    setattr(info, "url", SERVER_URL)

    mgr = MCPClientManager()
    await mgr.add_server(info)  # manager chooses MCPHTTPClientSession

    # 2) Registry discovery
    reg = MCPToolRegistry(mgr)
    await reg.refresh(server_ids=["http_server"])

    fns = reg.list_function_names()
    print("Discovered MCP tools:", fns)
    assert fns, "No tools discovered from HTTP server"

    # 3) Call `add`
    add_fn = next((n for n in fns if n.endswith("__add")), None)
    assert add_fn, "Expected 'add' tool not found"
    res = await reg.execute(add_fn, {"a": 5, "b": 3}, timeout_s=10)
    print("add ->", res.data if res.ok else f"ERROR: {res.error}")
    assert res.ok and res.data in (8, {"result": 8}) or (isinstance(res.data, dict) and res.data.get("result") == 8), \
        f"'add' returned unexpected result: {res.data}"

    # 4) Try `process_data` (optional; skip if fails or missing)
    proc_fn = next((n for n in fns if n.endswith("__process_data")), None)
    if proc_fn:
        res2 = await reg.execute(proc_fn, {"uri": RESOURCE_URI}, timeout_s=15)
        print("process_data ->", res2.data if res2.ok else f"ERROR: {res2.error}")
        # Don’t assert ok; it depends on your server’s resource + sampling wiring
    else:
        print("No 'process_data' tool exposed; skipping.")

    # 5) Also show OpenAI/Anthropic/Gemini tool exposures (sanity check)
    print("OpenAI tools preview:", reg.as_openai_tools())
    print("Anthropic tools preview:", reg.as_anthropic_tools())
    print("Gemini declarations preview:", reg.as_gemini_function_declarations())

    await mgr.aclose()

if __name__ == "__main__":
    asyncio.run(main())
