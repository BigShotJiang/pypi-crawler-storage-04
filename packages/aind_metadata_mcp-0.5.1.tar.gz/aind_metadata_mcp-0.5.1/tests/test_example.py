"""Example test template."""

import unittest


class ExampleTest(unittest.TestCase):
    """Example Test Class"""

    def test_assert_example(self):
        """Example of how to test the truth of a statement."""

        self.assertTrue(1 == 1)


if __name__ == "__main__":
    unittest.main()
