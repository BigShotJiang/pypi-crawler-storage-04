from .open_meteo import WeatherService  # noqa: F401
