"""Parser of audio files and subtitles."""
