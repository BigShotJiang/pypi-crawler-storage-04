# otto_api42

**This is a fork from [HiveHelsinki's api42](https://github.com/hivehelsinki/42api-lib).**  
The aim of this fork is to facilitate API communication for student by Pythonizing the results from the API.
