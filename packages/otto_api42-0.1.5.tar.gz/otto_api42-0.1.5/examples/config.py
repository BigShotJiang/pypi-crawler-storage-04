# You can add all manner of variables and values here
# It is easier to change a single value in here, than to change it everywhere in the code

campus_id = 13
cursus_id = 1