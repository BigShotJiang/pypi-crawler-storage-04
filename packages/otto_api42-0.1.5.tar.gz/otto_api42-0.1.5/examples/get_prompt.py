from intra import ic

ic.prompt()