"""Retry strategy implementations."""
