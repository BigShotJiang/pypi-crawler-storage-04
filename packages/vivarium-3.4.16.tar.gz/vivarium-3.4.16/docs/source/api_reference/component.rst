.. automodule:: vivarium.component
