.. automodule:: vivarium.exceptions
