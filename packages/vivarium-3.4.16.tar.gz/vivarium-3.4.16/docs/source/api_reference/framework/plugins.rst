.. automodule:: vivarium.framework.plugins
