import rich
from rich.console import Console
from rich.table import Table
import os

console = Console()
