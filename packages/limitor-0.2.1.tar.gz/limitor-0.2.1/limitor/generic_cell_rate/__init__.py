"""Generic Cell Rate Algorithm Limiter"""
