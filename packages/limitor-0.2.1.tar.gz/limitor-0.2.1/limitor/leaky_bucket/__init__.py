"""Leaky Bucket Rate Limiter"""
