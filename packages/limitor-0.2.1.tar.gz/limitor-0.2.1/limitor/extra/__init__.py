"""Extra rate limit implementations."""
