from .model import MAnet
