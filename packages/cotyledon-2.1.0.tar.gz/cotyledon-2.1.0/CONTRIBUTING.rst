Bugs should be filed on Github: https://github.com/sileht/cotyledon/issues

Contribution can be via Github pull requests: https://github.com/sileht/cotyledon/pulls

