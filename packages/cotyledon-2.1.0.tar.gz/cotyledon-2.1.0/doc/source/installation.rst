============
Installation
============

At the command line::

    $ pip install cotyledon

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv cotyledon
    $ pip install cotyledon
