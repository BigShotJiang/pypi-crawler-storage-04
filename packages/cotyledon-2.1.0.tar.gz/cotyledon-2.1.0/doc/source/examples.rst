========
Examples
========

.. literalinclude:: ../../cotyledon/tests/examples.py
   :language: python
