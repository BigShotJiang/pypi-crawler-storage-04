========
API
========

.. autoclass:: cotyledon.Service
   :members:
   :special-members: __init__

.. autoclass:: cotyledon.ServiceManager
   :members:
   :special-members: __init__

.. autofunction:: cotyledon.oslo_config_glue.setup

