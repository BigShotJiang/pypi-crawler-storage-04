# portndock

A cross-platform terminal tool for developers to easily find and kill processes using specific ports, with special support for Docker containers.

Perfect for fixing **"port already in use"** errors during development!

## Features

- **Find processes by port** - Quickly see what's using any port
- **Docker awareness** - Special handling for Docker containers
- **Interactive TUI** - Real-time terminal interface with color coding
- **Safety first** - Color-coded process safety levels (safe to kill vs dangerous)
- **Cross-platform** - Works on Windows, macOS, and Linux
- **Zero dependencies** - No external packages required
- **Easy controls** - Arrow keys + Enter to kill processes

## Installation

```bash
pip install portndock
```

## Quick Start

Simply run the command:

```bash
portndock
```

### Interactive Mode (Recommended)
```bash
portndock ui
```

This opens the live TUI where you can:
- Use ↑/↓ arrows to select processes
- Press **Enter** to kill selected process  
- Press **D** to stop Docker containers
- Press **?** for help

### Command Line Mode
```bash
# Kill process on specific port
portndock kill --port 3000

# Kill by PID
portndock kill --pid 12345

# List all processes using ports
portndock list

# Free a specific port
portndock free --port 8080
```

## Color Coding

The TUI uses colors to indicate safety levels:

- **Blue** - Docker containers (safe to kill)
- **Green** - Your user processes (usually safe) 
- **Yellow** - System processes (be careful!)
- **Red** - Critical processes (dangerous!)

## Common Use Cases

### Fix "Port Already in Use" Errors
```bash
# Your dev server says port 3000 is busy?
portndock ui
# Select the process on port 3000 and press Enter!
```

### Manage Docker Development
```bash
# See all your Docker containers and their ports
portndock ui
# Press 'D' to stop containers cleanly
```

### Clean Up Development Environment  
```bash
# View all development ports (3000s, 8000s, etc.)
# Press 'V' to cycle through app/stack/all filters
portndock ui
```

## Key Bindings (Interactive Mode)

- **↑/↓** - Navigate processes
- **Enter** - Kill selected process
- **D** - Stop Docker container
- **R** - Refresh process list  
- **V** - Cycle port filters (app/stack/all)
- **P** - Cycle protocols (tcp/udp/all)
- **X** - Toggle IPv6 duplicates
- **?** - Show help
- **Q** - Quit

## Examples

```bash
# Interactive mode (recommended)
portndock ui

# Kill process on port 3000
portndock kill --port 3000

# Kill multiple processes on a port  
portndock kill --port 8080 --all

# Interactive selection when multiple processes found
portndock kill --port 3000 --interactive

# List all processes with ports
portndock list

# List only TCP processes
portndock list --protocol tcp

# Free port (try container stop first, then kill process)
portndock free --port 5432

# Show only development ports
portndock ui --dev app
```

## Requirements

- Python 3.8+
- Works on Windows, macOS, and Linux
- No additional dependencies required

## Development

This tool is designed by developers, for developers. It understands the common pain points of port conflicts during development and provides a fast, safe way to resolve them.

### Why portndock?

- **Fast**: Quickly identify and resolve port conflicts
- **Safe**: Color-coded warnings prevent accidentally killing important processes  
- **Smart**: Understands Docker containers and development workflows
- **Simple**: No configuration needed, works out of the box

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## License

MIT License - see LICENSE file for details.

---

**Having port conflicts?** Install portndock and get back to coding!