__version__: bytes
