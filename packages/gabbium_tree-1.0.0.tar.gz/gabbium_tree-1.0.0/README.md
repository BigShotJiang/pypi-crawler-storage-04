# gabbium-tree

A simple [Python CLI](https://pypi.org/project/gabbium-tree) to print a
**directory tree** (like `tree` command), with support for depth limits,
hidden files, and excludes.

## ✅ What it does

- Prints a project folder structure in a clean tree format\
- Supports options like:
  - `--max-depth` → limit tree depth\
  - `--only-dirs` → show only directories\
  - `--exclude` → skip specific directories (defaults: `.git`,
    `node_modules`, `__pycache__`, ...)\
  - `--output` → save output to file

---

## 📦 Installation

```bash
pip install gabbium-tree
```

---

## ⚙️ Usage

Basic:

```bash
gtree .
```

Limit depth:

```bash
gtree . --max-depth 2
```

Only directories:

```bash
gtree . --only-dirs
```

Exclude extra paths:

```bash
gtree . --exclude dist build
```

Save to file:

```bash
gtree . --output tree.txt
```

Or with shell redirection:

```bash
gtree . > tree.txt
```

---

## 🔑 Features

- Cross-platform (Windows, macOS, Linux)\
- Prints with Unicode characters (fallback to ASCII if needed)\
- Defaults to ignoring common junk folders (`.git`, `node_modules`,
  `__pycache__`)

---

## ✅ Example output

```bash
~/my-project
├── src/
│   ├── app/
│   └── utils/
├── tests/
└── pyproject.toml
```

---

## 🛠 Roadmap

- [ ] Option for ASCII-only mode (`--ascii`)\
- [ ] Output to file (`--output tree.txt`)\
- [ ] Config file support (`.gtreerc`)

---

## 🪪 License

This project is licensed under the MIT License -- see [LICENSE](LICENSE)
for details.
