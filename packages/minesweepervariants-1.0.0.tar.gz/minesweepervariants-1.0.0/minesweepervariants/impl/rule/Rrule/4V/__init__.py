#!/usr/bin/env python3
# -*- coding:utf-8 -*-
#
# @Time    : 2025/07/28 17:12
# @Author  : Wu_RH
# @FileName: __init__.py

BOARD_NAME_4V = "4V"
