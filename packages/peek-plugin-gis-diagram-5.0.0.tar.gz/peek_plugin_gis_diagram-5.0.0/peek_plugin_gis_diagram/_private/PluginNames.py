gisDiagramFilt = {"plugin": "peek_plugin_gis_diagram"}
gisDiagramTuplePrefix = "peek_plugin_gis_diagram."
gisDiagramObservableName = "peek_plugin_gis_diagram"
gisDiagramActionProcessorName = "peek_plugin_gis_diagram"
gisDiagramTupleOfflineServiceName = "peek_plugin_gis_diagram"

gisDiagramModelSetName = "gisDiagram"
gisDiagramCoordSetName = "gisDiagram"
