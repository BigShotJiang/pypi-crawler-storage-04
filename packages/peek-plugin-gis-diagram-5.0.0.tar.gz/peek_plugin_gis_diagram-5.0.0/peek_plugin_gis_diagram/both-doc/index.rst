==========
User Guide
==========


..image: icon.png

Welcome to GIS Diagram Viewer

The Peek GIS Viewer displays provides a web and mobile friendly
view of the GIS.


    * View an up to date GIS diagram

    * Enable offline caching to view the whole network diagram offline

    * Edit the diagram to create mockups and corrections

    * Navigate between worlds.