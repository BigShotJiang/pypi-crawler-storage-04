# Copyright Axis Communications AB.
#
# For a full list of individual contributors, please see the commit history.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""JSONTas join data structure module."""
from jsontas.data_structures.datastructure import DataStructure

# pylint:disable=too-few-public-methods


class Join(DataStructure):
    """Join datastructure.

    Join a list of strings together to a string.
    """

    def execute(self) -> tuple[None, str]:
        """Execute datastructure.

        :return: None and a joined list of strings.
        """
        return None, "".join([str(string) for string in self.data.get("strings")])
