if __name__ == "__main__":
    from .run import main

    main()
