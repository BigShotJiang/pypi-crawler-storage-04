# PDF Merger Application

A modern, feature-rich Python application for merging multiple PDF files into a single document. Built with PyQt5, this application offers an intuitive graphical interface with advanced features like PDF preview, drag-and-drop reordering, page range selection, and theme switching.

## ✨ Features

### 📁 **File Management**
- **Add Files**: Easily add multiple PDF files with drag-and-drop support
- **Delete Files**: Remove unwanted files with confirmation dialogs
- **Reorder Files**: Drag and drop files within the list or use move buttons
- **Undo/Redo**: Complete undo/redo functionality for all file operations
- **File Validation**: Automatic validation of PDF files on import

### 📄 **Page Range Selection**
- **Direct Control**: Select specific page ranges for each PDF file directly in the file list
- **Smart Sync**: Minimum and maximum page ranges automatically stay in sync
- **Whole PDF Option**: Toggle between whole PDF or custom page ranges
- **Visual Feedback**: Clear indication of selected ranges with enabled/disabled controls

### 👁️ **Advanced Preview**
- **Multi-Page Navigation**: Browse through all pages of selected PDFs
- **Real-Time Updates**: Preview automatically updates when page ranges change
- **High-Quality Rendering**: Crisp preview images with proper scaling
- **Navigation Controls**: Previous/Next buttons with page indicators

### 🎨 **Modern UI/UX**
- **Dark/Light Themes**: Switch between modern dark and light themes
- **Responsive Design**: Clean, modern interface with smooth animations
- **Clickable Elements**: File names are clickable for easy selection
- **Visual Feedback**: Hover effects and clear visual states
- **Settings Persistence**: All settings saved automatically in JSON format

### ⚙️ **Advanced Settings**
- **Independent Settings**: Access settings regardless of file import status
- **Merge Options**: Configure quality, compression, bookmarks, and optimization
- **Window Geometry**: Application remembers window position and size
- **Theme Persistence**: Selected theme is remembered between sessions

### 🔧 **Technical Features**
- **Multi-Threading**: Background processing for preview and merge operations
- **Error Handling**: Robust error handling with user-friendly messages
- **File Overwrite Protection**: Confirmation dialogs for file operations
- **Memory Management**: Efficient handling of large PDF files
- **Windows Integration**: Optimized for Windows 10/11 environments

## 🚀 Usage

### Basic Workflow
1. **Add PDF Files**: Click "Add Files" or drag PDFs into the application
2. **Configure Page Ranges**: For each file, choose "All Pages" or specify custom ranges
3. **Reorder Files**: Drag files to reorder or use move buttons
4. **Preview PDFs**: Click on files to preview and navigate through pages
5. **Merge PDFs**: Click "Merge PDFs" to combine files into a single document

### Advanced Features
- **Theme Switching**: Click the 🌙/☀️ button to switch between light and dark themes
- **Settings Access**: Click the settings button to configure merge options
- **Undo/Redo**: Use Ctrl+Z and Ctrl+Y for quick file list modifications
- **File Selection**: Click on file names to select them for preview

## 📦 Installation

### 🚀 **Method 1: Install from PyPI (Recommended)**
```bash
pip install pdf-merger-advanced
```
Then run:
```bash
pdf-merger
```

### 🔧 **Method 2: Install from Source**
   ```bash
git clone https://github.com/Gunjan000/PDF-Merger-Advanced.git
cd PDF-Merger-Advanced
pip install -e .
```

### 💾 **Method 3: Standalone Executable**
Download the latest executable from [Releases](https://github.com/Gunjan000/PDF-Merger-Advanced/releases)
- **Windows**: `PDF-Merger-Advanced.exe`

### 🛠️ **Method 4: Development Setup**
```bash
git clone https://github.com/Gunjan000/PDF-Merger-Advanced.git
cd PDF-Merger-Advanced
pip install -r requirements.txt
python pdf_merger.py
```

### 📋 **Prerequisites**
- Python 3.7 or higher
- Windows 10/11 (primary support)

### 🏗️ **Building Executables**
To create standalone Windows executable:
```bash
python build_executable.py
```
This will create `PDF-Merger-Advanced.exe` in the `dist/` folder.

## 🎯 Key Improvements

### Version 2.0 Features
- **Dark Mode Support**: Complete dark theme with proper color adaptation
- **Page Range Selection**: Direct control over page ranges for each PDF
- **Multi-Page Preview**: Navigate through all pages of selected PDFs
- **Settings Persistence**: JSON-based settings storage
- **Modern UI**: Redesigned interface with better usability
- **Threading**: Background processing for smooth user experience
- **Error Handling**: Comprehensive error handling and user feedback

### UI/UX Enhancements
- **Responsive Layout**: Adaptive design that works on different screen sizes
- **Visual Feedback**: Clear indication of selected files and current states
- **Accessibility**: Better contrast and readable text in both themes
- **Intuitive Controls**: Logical placement and behavior of all controls

## 🔧 Technical Details

### Architecture
- **PyQt5**: Modern GUI framework for cross-platform compatibility
- **PyPDF2**: PDF manipulation and merging capabilities
- **PyMuPDF**: High-quality PDF preview generation
- **QThread**: Multi-threading for responsive UI during heavy operations
- **JSON**: Settings persistence and configuration management

### File Structure
```
PDF-Merger-Advanced/
├── pdf_merger.py          # Main application file
├── README.md              # This documentation
├── assets/                # Preview images and resources
│   ├── preview_light_theme.jpg
│   └── preview_dark_theme.jpg
└── pdf_merger_settings.json  # Auto-generated settings file
```

## 🎨 Screenshots

### Light Theme
![Light Theme Preview](assets/preview_light_theme.jpg)
*Clean, professional light theme with modern gradients and intuitive controls*

### Dark Theme  
![Dark Theme Preview](assets/preview_dark_theme.jpg)
*Easy-on-the-eyes dark theme with proper contrast and enhanced readability*

### Key UI Features
The application features a modern interface with:
- **Light Theme**: Clean, professional appearance with subtle gradients
- **Dark Theme**: Easy on the eyes with proper contrast and readability
- **File List**: Direct page range controls for each PDF file
- **Preview Panel**: High-quality PDF preview with navigation
- **Settings Dialog**: Comprehensive configuration options
- **Responsive Design**: Adapts to different screen sizes and user preferences

## 🤝 Contributing

Contributions are welcome! Please feel free to submit issues, feature requests, or pull requests.

## 📄 License

This project is open source and available under the MIT License.

## 👨‍💻 Credits

**Created by**: Gunjan Vaishnav

**GitHub**: [https://github.com/Gunjan000/PDF-Merger-Advanced](https://github.com/Gunjan000/PDF-Merger-Advanced)

---

*Built with ❤️ using Python and PyQt5*