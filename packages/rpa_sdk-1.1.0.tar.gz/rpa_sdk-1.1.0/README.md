# RPA SDK

[![Python Version](https://img.shields.io/badge/python-3.8%2B-blue.svg)](https://www.python.org/downloads/)
[![License](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)
[![Version](https://img.shields.io/badge/version-1.0.0-orange.svg)](https://gitee.com/aitmc/rpa-sdk)

**RPA SDK** 是一个功能强大的机器人流程自动化（RPA）软件开发工具包，专为Python开发者设计。它提供了浏览器自动化、WebSocket通信、数据库操作等核心功能，帮助您快速构建高效的RPA应用程序。

## ✨ 主要特性

- 🌐 **浏览器自动化**: 基于Playwright的现代浏览器自动化支持
- 🔌 **WebSocket通信**: 实时双向通信能力
- 🗄️ **数据库集成**: 支持MySQL数据库操作
- 📊 **数据模型**: 内置访问、体检、档案等数据模型
- 🛠️ **丰富工具**: 提供字符串处理、文件操作、系统工具等实用功能
- 📝 **完整日志**: 支持调试模式和详细日志记录
- 🎯 **易于扩展**: 模块化设计，支持自定义任务处理器

## 📦 安装

### 使用pip安装

```bash
pip install rpa-sdk
```

### 从源码安装

```bash
git clone https://gitee.com/aitmc/rpa-sdk.git
cd rpa-sdk
pip install -e .
```

### 安装浏览器驱动

安装完成后，需要安装Playwright浏览器驱动：

```bash
playwright install
```

## 🚀 快速开始

### 基本使用

```python
from rpa_sdk import RPAClient, Logger

# 创建RPA客户端
client = RPAClient()

# 启用调试日志
Logger.setup(debug_mode=True)

# 初始化浏览器
if client.initialize_browser(headless=False):
    Logger.info("浏览器初始化成功")
    
    # 执行自动化任务
    # ...
    
    # 清理资源
    client.cleanup()
```

### 使用浏览器管理器

```python
from rpa_sdk import PlaywrightBrowserManager

with PlaywrightBrowserManager() as browser:
    if browser.initialize(headless=False):
        browser.navigate_to("https://example.com")
        # 执行页面操作
        # ...
```

### WebSocket通信

```python
from rpa_sdk import WebSocketClient

def handle_message(data):
    print(f"收到消息: {data}")

# 创建WebSocket客户端
ws_client = WebSocketClient(
    url="ws://localhost:8765",
    message_handler=handle_message
)

# 连接并发送消息
ws_client.connect()
ws_client.send_message("hello", "Hello, Server!")
```

### 数据库操作

```python
from rpa_sdk import DatabaseManager

# 获取数据库管理器
db = DatabaseManager()

# 执行查询
results = db.execute_query("SELECT * FROM users WHERE active = 1")
for row in results:
    print(row)
```

## 📚 API文档

### 核心类

#### RPAClient
主要的RPA客户端类，提供完整的RPA功能。

- `initialize_browser(headless=True)`: 初始化浏览器
- `login_system(username, password)`: 系统登录
- `start()`: 启动客户端
- `stop()`: 停止客户端
- `cleanup()`: 清理资源

#### PlaywrightBrowserManager
浏览器管理器，负责浏览器实例的生命周期管理。

- `initialize(headless=True)`: 初始化浏览器
- `navigate_to(url)`: 导航到指定URL
- `login(username, password)`: 执行登录操作
- `cleanup()`: 清理浏览器资源

#### WebSocketClient
WebSocket客户端，提供实时通信功能。

- `connect()`: 连接到WebSocket服务器
- `send_message(action, message, data=None)`: 发送消息
- `send_result(key_id, rpa_type, rpa_state, rpa_note)`: 发送执行结果
- `stop()`: 停止连接

### 工具类

#### Logger
增强的日志记录器。

- `Logger.setup(debug_mode=False, log_file="rpa.log")`: 设置日志配置
- `Logger.info(message, extra_data=None)`: 记录信息日志
- `Logger.warning(message, extra_data=None)`: 记录警告日志
- `Logger.error(message, exception=None, extra_data=None)`: 记录错误日志

## 🔧 配置

### 环境变量

- `RPA_DEBUG`: 设置为`true`启用调试模式
- `RPA_LOG_FILE`: 指定日志文件路径
- `WEBSOCKET_URL`: WebSocket服务器地址

### 配置文件

您可以创建配置文件来自定义RPA客户端的行为：

```python
# config.py
CONFIG = {
    'browser': {
        'headless': True,
        'timeout': 30000,
    },
    'websocket': {
        'url': 'ws://localhost:8765',
        'reconnect_interval': 5,
    },
    'database': {
        'host': 'localhost',
        'port': 3306,
        'user': 'root',
        'password': 'password',
        'database': 'rpa_db',
    }
}
```

## 🎯 使用场景

- **Web自动化测试**: 自动化网页操作和测试
- **数据采集**: 从网站批量采集数据
- **业务流程自动化**: 自动化重复性业务操作
- **系统集成**: 连接不同系统进行数据交换
- **监控和报告**: 自动生成报告和监控系统状态

## 🤝 贡献

欢迎贡献代码！请遵循以下步骤：

1. Fork 本仓库
2. 创建特性分支 (`git checkout -b feature/AmazingFeature`)
3. 提交更改 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 创建Pull Request

## 📄 许可证

本项目采用MIT许可证 - 查看 [LICENSE](LICENSE) 文件了解详情。

## 📞 支持

- 📧 邮箱: support@aitmc.com
- 🐛 问题反馈: [Gitee Issues](https://gitee.com/aitmc/rpa-sdk/issues)
- 📖 文档: [项目Wiki](https://gitee.com/aitmc/rpa-sdk/wikis)

## 🔄 更新日志

### v1.0.0 (2024-01-15)
- 🎉 首次发布
- ✨ 支持Playwright浏览器自动化
- ✨ WebSocket实时通信
- ✨ MySQL数据库集成
- ✨ 完整的日志系统
- ✨ 模块化架构设计

---

**RPA SDK** - 让自动化更简单！ 🚀