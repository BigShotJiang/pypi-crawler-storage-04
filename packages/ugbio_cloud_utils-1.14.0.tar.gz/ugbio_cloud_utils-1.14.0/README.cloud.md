# ugbio_cloud_utils

This module includes cloud (AWS/GS) python scripts:

List of tools:

1. **cloud_sync** - Download aws s3 or google storage file to a respective local path

   Run `uv run cloud_sync --help` for more details.
