# Personal utilities

Install:

```bash
uv pip install doehyunbaek
```

Usage:

```bash
doehyunbaek
```
