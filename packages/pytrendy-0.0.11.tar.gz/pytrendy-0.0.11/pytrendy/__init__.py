from .detect_trends import detect_trends
from .data_loader import load_data
from .plot_pytrendy import plot_pytrendy
from .simpledtw import dtw