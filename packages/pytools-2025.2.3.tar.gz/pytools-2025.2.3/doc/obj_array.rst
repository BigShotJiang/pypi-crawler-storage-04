.. automodule:: pytools.obj_array
