Testing convergence
-------------------

.. automodule:: pytools.convergence
