.. automodule:: pytools.persistent_dict
