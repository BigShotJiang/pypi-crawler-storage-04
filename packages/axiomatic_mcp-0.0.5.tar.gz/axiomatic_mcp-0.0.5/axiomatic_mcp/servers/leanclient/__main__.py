"""Entry point for running lean_tools as a module."""

from .server import main

if __name__ == "__main__":
    main()
