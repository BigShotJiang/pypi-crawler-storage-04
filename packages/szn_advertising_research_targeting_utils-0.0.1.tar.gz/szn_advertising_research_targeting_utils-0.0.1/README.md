# szn-advertising-research-targeting-utils

This is a security placeholder package created to prevent dependency confusion attacks.