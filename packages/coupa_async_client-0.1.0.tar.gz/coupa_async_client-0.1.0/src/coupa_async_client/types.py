from __future__ import annotations
from typing import Any, Dict

JSONObject = Dict[str, Any]
