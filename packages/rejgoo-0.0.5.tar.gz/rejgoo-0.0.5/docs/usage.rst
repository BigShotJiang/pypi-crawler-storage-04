=====
Usage
=====

To use equation solver in a project::

    import rejgoo
