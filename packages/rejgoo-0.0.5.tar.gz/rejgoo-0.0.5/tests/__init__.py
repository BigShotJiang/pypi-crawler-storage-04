"""Unit test package for rejgoo."""
