"""Tests for Rails library."""
