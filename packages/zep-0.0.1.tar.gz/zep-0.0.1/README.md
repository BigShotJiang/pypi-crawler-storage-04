zed wrapped in Python
