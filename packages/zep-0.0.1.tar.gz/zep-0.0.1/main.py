def main():
    print("Hello from zep!")


if __name__ == "__main__":
    main()
