from enum import Enum

class ArkEquipmentStat(Enum):
    ARMOR = 1
    DURABILITY = 2
    DAMAGE = 3
    HYPOTHERMAL_RESISTANCE = 5
    HYPERTHERMAL_RESISTANCE = 7