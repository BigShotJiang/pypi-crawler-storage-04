class CompilationException(Exception):
    pass