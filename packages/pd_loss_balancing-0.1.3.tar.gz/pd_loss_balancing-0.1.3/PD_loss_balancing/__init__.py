__version__ = "0.1.3"

from .main import (
    LossBalancer,
    LinearTrajectoryTarget,
    ConstantTarget,
    RelativeTarget,
    Target,
)
