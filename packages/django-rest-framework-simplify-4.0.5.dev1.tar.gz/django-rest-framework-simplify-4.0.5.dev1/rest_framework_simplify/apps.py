from django.apps import AppConfig


class RestFrameworkSimplifyAppConfig(AppConfig):
    name = 'rest_framework_simplify'