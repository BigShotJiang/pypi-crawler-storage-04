# Templates directory marker
