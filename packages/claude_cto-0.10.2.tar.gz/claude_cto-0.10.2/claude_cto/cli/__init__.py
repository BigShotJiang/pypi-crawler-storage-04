"""CLI module for claude-cto."""
# Dumb client layer - only HTTP calls to server
