# Named Entity Recognition Task

::: openaivec.task.nlp.named_entity_recognition
