# Sentiment Analysis Task

::: openaivec.task.nlp.sentiment_analysis
