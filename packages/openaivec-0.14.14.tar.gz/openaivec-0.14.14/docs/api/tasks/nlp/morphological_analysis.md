# Morphological Analysis Task

::: openaivec.task.nlp.morphological_analysis
