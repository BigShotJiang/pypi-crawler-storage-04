class ThrottlingMisconfigurationException(Exception):
    pass
