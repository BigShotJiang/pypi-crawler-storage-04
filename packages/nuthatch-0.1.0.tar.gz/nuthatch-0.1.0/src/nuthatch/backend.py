"""The backend module is used to register and get backends.

It also contains the abstract base class for all backends.
"""
from abc import ABC, abstractmethod
from os.path import join
import fsspec
import sqlalchemy

registered_backends = {}
default_backends = {}

def register_backend(backendClass):
    """Register a backend class with the nuthatch system.

    This function registers a backend class so it can be used by the nuthatch
    caching system. The backend class must have a `backend_name` attribute.
    Optionally, if the backend class has a `default_for_type` attribute, it
    will be set as the default backend for that data type.

    Args:
        backendClass: The backend class to register. Must have a `backend_name`
                     attribute and optionally a `default_for_type` attribute.

    Returns:
        The registered backend class (allows use as a decorator).

    Example:
        @register_backend
        class MyBackend:
            backend_name = "my_backend"
            default_for_type = "my_data_type"
    """
    registered_backends[backendClass.backend_name] = backendClass

    if 'default_for_type' in backendClass.__dict__:
        default_backends[backendClass.default_for_type] = backendClass.backend_name

    return backendClass

def get_backend_by_name(backend_name):
    """Retrieve a registered backend class by its name.

    Args:
        backend_name (str): The name of the backend to retrieve.

    Returns:
        The backend class associated with the given name.

    Raises:
        KeyError: If no backend is registered with the given name.
    """
    return registered_backends[backend_name]

def get_default_backend(data_type):
    """Get the default backend name for a specific data type.

    Args:
        data_type (str): The data type to get the default backend for.

    Returns:
        str: The name of the default backend for the data type, or 'basic'
             if no default is set.
    """
    if data_type in default_backends:
        return default_backends[data_type]
    else:
        return 'basic'

class NuthatchBackend(ABC):
    config_parameters = []

    def __init__(self, cacheable_config, cache_key, namespace, args, backend_kwargs):
        """The abstract base class for all cacheable backends.

        This is the base class for all cacheable backends in the nuthatch system.
        Each backend instance manages a specific cache entry with its own
        configuration and storage mechanism.

        Args:
            cacheable_config (dict): Configuration dictionary containing static or
                dynamic parameters. Required parameters should be listed as strings
                in the backend's `config_parameters` class attribute.
            cache_key (str): Unique identifier for the cache entry. This key is
                used to distinguish between different cached items.
            namespace (str, optional): Optional namespace to organize cache entries.
                If provided, cache entries will be stored under this namespace.
            args (dict): Key-value pairs of arguments and values that were passed
                to the function being cached. These are used to generate cache
                keys and may influence backend behavior.
            backend_kwargs (dict): User-configurable keyword arguments specific to
                the backend implementation. For example, the zarr backend uses
                these for per-argument-value chunking configuration.

        Note:
            This is an abstract base class. Subclasses must implement the abstract
            methods: `write()`, `read()`, `delete()`, `exists()`, `get_file_path()`,
            and `sync()`.
        """

        # Store base
        self.config = cacheable_config
        self.cache_key = cache_key
        self.namespace = namespace
        self.backend_kwargs = backend_kwargs
        self.args = args


    @abstractmethod
    def write(self, data, upsert=False, primary_keys=None):
        """Write data to the backend.

        This method is responsible for writing data to the backend. It should
        be implemented by subclasses to handle the specific storage mechanism
        of the backend.

        Args:
            data (any): The data to write to the backend.
            upsert (bool, optional): Whether to perform an upsert operation.
                If True, the data will be inserted or updated based on the
                primary keys provided.
            primary_keys (list, optional): List of primary key columns to use
                for upsert operations.
        """
        pass

    @abstractmethod
    def read(self, engine):
        """Read data from the backend.

        This method is responsible for reading data from the backend. It should
        be implemented by subclasses to handle the specific storage mechanism
        of the backend.

        Args:
            engine (str or type): The data processing engine to use for
                reading data from the backend.

        Returns:
            Any: The data read from the backend.
        """
        pass

    @abstractmethod
    def delete(self):
        """Delete data from the backend.

        This method is responsible for deleting data from the backend. It should
        be implemented by subclasses to handle the specific storage mechanism
        of the backend.
        """
        pass

    @abstractmethod
    def exists(self):
        """Check if the data exists in the backend.

        This method is responsible for checking if the data exists in the backend.
        It should be implemented by subclasses to handle the specific storage
        mechanism of the backend.

        Returns:
            bool: True if the data exists in the backend, False otherwise.
        """
        pass

    @abstractmethod
    def get_file_path(self):
        """Get the file path of the data in the backend.

        This method is responsible for returning the file path of the data in the
        backend. It should be implemented by subclasses to handle the specific
        storage mechanism of the backend.

        Returns:
            str: The file path of the data in the backend.
        """
        pass

    @abstractmethod
    def sync(self, from_backend):
        """Sync data from one backend to another.

        This method is responsible for syncing data from one backend to another.
        It should be implemented by subclasses to handle the specific storage
        mechanism of the backend.

        Args:
            from_backend (NuthatchBackend): The backend to sync data from.
        """
        pass


class FileBackend(NuthatchBackend):
    """Base class for all backends that rely on a filesystem."""

    config_parameters = ["filesystem", "filesystem_options"]

    def __init__(self, cacheable_config, cache_key, namespace, args, backend_kwargs, extension):
        super().__init__(cacheable_config, cache_key, namespace, args, backend_kwargs)

        self.base_path = self.config['filesystem']

        if namespace:
            self.raw_cache_path = join(self.base_path, namespace, cache_key)
        else:
            self.raw_cache_path = join(self.base_path, cache_key)

        self.temp_cache_path = join(self.base_path, 'temp', cache_key)
        self.extension = extension
        self.path = self.raw_cache_path + '.' + extension
        if 'filesystem_options' not in self.config:
            self.config['filesystem_options'] = {}

        if fsspec.utils.get_protocol(self.path) == 'file':
            # If the protocol is a local filesystem, we need to create the directory if it doesn't exist
            self.fs = fsspec.core.url_to_fs(self.path, auto_mkdir=True, **self.config['filesystem_options'])[0]
        else:
            self.fs = fsspec.core.url_to_fs(self.path, **self.config['filesystem_options'])[0]


    def exists(self):
        return (self.fs.exists(self.path))

    def delete(self):
        self.fs.rm(self.path, recursive=True)

    def get_file_path(self):
        return self.path

    def get_cache_key(self, path):
        if path.endswith('.' + self.extension):
            path = path[:-len('.' + self.extension)]

        if path.startswith(self.base_path):
            path = path[len(self.base_path):]

        stripped = fsspec.core.strip_protocol(self.base_path)
        if path.startswith(stripped):
            path = path[len(stripped):]

        if path.startswith('/'):
            path = path[1:]

        if self.namespace:
            if path.startswith(self.namespace):
                path = path[len(self.namespace):]

        if path.startswith('/'):
            path = path[1:]

        return path


    def sync(self, from_backend):
        from_backend.fs.get(from_backend.path, self.path)

@register_backend
class NullBackend(FileBackend):

    backend_name = 'null'

    def __init__(self, cacheable_config, cache_key, namespace, args, backend_kwargs):
        super().__init__(cacheable_config, cache_key, namespace, args, backend_kwargs, 'null')

    def read(self, engine=None):
        raise RuntimeError("Null backend used only for import/export path manipulation. Cannot read from null backend.")

    def write(self, engine=None):
        raise RuntimeError("Null backend used only for import/export path manipulation. Cannot write to null backend.")


class DatabaseBackend(NuthatchBackend):
    """Base class for all backends that rely on a database."""

    config_parameters = ["driver", "host", "port", "database", "username", "password", "write_username", "write_password"]

    def __init__(self, cacheable_config, cache_key, namespace, args, backend_kwargs):
        super().__init__(cacheable_config, cache_key, namespace, args, backend_kwargs)

        database_url = sqlalchemy.URL.create(self.config['driver'],
                                username = self.config['username'],
                                password = self.config['password'],
                                host = self.config['host'],
                                port = self.config['port'],
                                database = self.config['database'])
        self.engine = sqlalchemy.create_engine(database_url)

        if 'write_username' in self.config and 'write_password' in self.config:
            write_database_url = sqlalchemy.URL.create(self.config['driver'],
                                username = self.config['write_username'],
                                password = self.config['write_password'],
                                host = self.config['host'],
                                port = self.config['port'],
                                database = self.config['database'])
            self.write_engine = sqlalchemy.create_engine(write_database_url)
        else:
            self.write_engine = self.engine

    def sync(self, local_backend):
        raise NotImplementedError("Backend syncing not implemented for database-like backends.")
