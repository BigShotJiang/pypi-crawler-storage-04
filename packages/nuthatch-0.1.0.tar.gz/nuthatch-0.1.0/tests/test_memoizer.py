# Test the memoizer here
