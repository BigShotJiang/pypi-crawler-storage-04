# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added

-

### Changed

-

### Removed

-

## [0.0.1] - 2024-05-05

### Added

- Added basic provider structure and default providers
- Added documentation
- Processing module to be able to search, download and convert songs and playlists from Spotify