# -*- coding: utf-8 -*-
#
# pygenda_version.py
# Version data in a separate file so it can be found easily by ../setup.py

# For valid/suggested versioning schemes, see:
# https://packaging.python.org/guides/distributing-packages-using-setuptools/#choosing-a-versioning-scheme

__version__ = '0.3.8'
