Pygenda is a calendar/agenda application written in Python3/GTK3. The UI is inspired by the Agenda programs on the Psion Series 3 and Series 5 range of keyboard-equipped PDAs, with the aim of being suitable for devices such as Planet Computers' Gemini PDA and Cosmo Communicator (running Linux).

For more information/latest source, see https://github.com/semiprime/pygenda
