# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
from .conv2d import conv2d, conv2d_channel_last
from .conv2d import Conv2dOp, Conv2dChannelLastOp
from .conv2d_winograd import conv2d_winograd, conv2d_winograd_image_transform, conv2d_winograd_filter_transform
from .conv2d_winograd import conv2d_winograd_inverse_transform
from .conv2d_winograd import Conv2dWinogradInverseTransformOp, Conv2dWinogradFilterTransformOp
from .conv2d_winograd import Conv2dWinogradImageTransformOp
from .conv2d_gemm import (
    conv2d_gemm,
    conv2d_gemm_fp16,
    conv2d_gemm_fp16_channel_last,
    conv2d_gemm_image_transform,
    conv2d_gemm_filter_transform,
)
from .conv2d_gemm import conv2d_gemm_inverse_transform
from .conv2d_gemm import Conv2dGemmImageTransformOp


from . import resolve
