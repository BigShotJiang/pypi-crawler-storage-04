# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
from .symmetric import symmetric_quantize, symmetric_dequantize
from .matmul import symmetric_quant_matmul
from .matmul_f16_i8 import symmetric_quant_matmul_f16_i8
from .matmul_f16_i8_atomic import symmetric_quant_matmul_atomic_f16_i8
