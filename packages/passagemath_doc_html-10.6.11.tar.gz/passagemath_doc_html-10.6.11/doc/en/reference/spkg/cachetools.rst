.. _spkg_cachetools:

cachetools: Extensible memoizing collections and decorators
===========================================================

Description
-----------

Extensible memoizing collections and decorators

License
-------

MIT

Upstream Contact
----------------

https://pypi.org/project/cachetools/



Type
----

standard


Dependencies
------------

- $(PYTHON)
- :ref:`spkg_pip`

Version Information
-------------------

package-version.txt::

    5.3.3

version_requirements.txt::

    cachetools

Equivalent System Packages
--------------------------

(none known)
