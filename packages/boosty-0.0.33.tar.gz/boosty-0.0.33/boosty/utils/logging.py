import logging

logger = logging.getLogger(__name__.split(".", maxsplit=1)[0])
