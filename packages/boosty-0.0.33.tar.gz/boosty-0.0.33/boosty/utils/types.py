from os import PathLike
from typing import TypeAlias

StrPath: TypeAlias = str | PathLike[str]
