API_URL = "https://api.boosty.to"
LOGIN_URL = "https://boosty.to"

DEFAULT_USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
)
"""https://techblog.willshouse.com/2012/01/03/most-common-user-agents/"""
