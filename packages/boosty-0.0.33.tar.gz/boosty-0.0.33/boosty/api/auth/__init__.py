from boosty.api.auth.auth import Auth

__all__ = ("Auth",)
