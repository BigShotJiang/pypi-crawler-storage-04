from boosty.api.api import API

__all__ = ("API",)
