# Django Logger

Un módulo de Django para logging y auditoría avanzada de aplicaciones.

## Características

- Logging automático de todas las requests HTTP
- Registro de acciones de usuario (CRUD)
- Seguimiento de cambios en modelos
- Sistema de auditoría con niveles de importancia
- Almacenamiento de información detallada de requests/responses
- Decoradores para vistas y modelos
