from pyasic.miners.backends.luckyminer import LuckyMiner
from pyasic.miners.device.models.luckyminer import LV07


class LuckyMinerLV07(LuckyMiner, LV07):
    pass
