from pyasic.miners.backends.iceriver import IceRiver
from pyasic.miners.device.models.iceriver import AL3


class IceRiverAL3(IceRiver, AL3):
    pass
