from pyasic.miners.backends.iceriver import IceRiver
from pyasic.miners.device.models import KS2


class IceRiverKS2(IceRiver, KS2):
    pass
