from .M70 import M70VM30
