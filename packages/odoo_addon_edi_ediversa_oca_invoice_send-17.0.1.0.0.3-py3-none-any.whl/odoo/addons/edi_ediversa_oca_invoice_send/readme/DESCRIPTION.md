This module extends the base edi_ediversa_oca module to generate and send the invoices
files to Ediversa.
