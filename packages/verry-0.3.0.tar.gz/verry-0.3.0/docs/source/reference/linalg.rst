.. automodule:: verry.linalg
