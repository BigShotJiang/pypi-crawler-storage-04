.. automodule:: verry.misc
