.. automodule:: verry.affine
