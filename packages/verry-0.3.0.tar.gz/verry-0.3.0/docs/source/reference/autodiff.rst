.. automodule:: verry.autodiff
