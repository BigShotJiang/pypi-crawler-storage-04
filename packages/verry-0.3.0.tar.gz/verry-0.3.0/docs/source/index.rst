###################
Verry documentation
###################

Verry is an open-source package for verified computation written in Python. 

.. grid:: 2

    .. grid-item-card:: User guide
         :text-align: center

         Under construction.

         +++

         .. button-ref:: userguide/index
            :expand:
            :color: secondary
            :click-parent:

            To the user guide

    .. grid-item-card::  API reference
         :text-align: center

         Under construction.

         +++

         .. button-ref:: reference/index
            :expand:
            :color: secondary
            :click-parent:

            To the API reference

.. toctree::
   :maxdepth: 1
   :hidden:

   reference/index.rst
   userguide/index.rst
