#####
Verry
#####

Verry is an open-source package for `verified computation <https://en.wikipedia.org/wiki/Validated_numerics>`__ written in Python.

Documentation is at https://python-verry.github.io/verry

Note that Verry is in the alpha stage. There is not enough testing and any breaking changes possibly occur.

Authorship and Acknowledgement
==============================

Verry is developed by Ryoga Iwanami in master's course at Waseda University.
The author would like to acknowledge Masahide Kashiwagi, the developer of `kv <http://verifiedby.me/kv/index-e.html>`__, and the author's supervisor.
