# This file is only needed for the automatic versioning in the conda recipe
from setuptools import setup
import setuptools_scm

setup(version=setuptools_scm.get_version())
