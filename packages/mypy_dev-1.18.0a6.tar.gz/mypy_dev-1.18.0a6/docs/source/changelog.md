<!-- This file includes mypy/CHANGELOG.md into mypy documentation -->
```{include} ../../CHANGELOG.md
```
