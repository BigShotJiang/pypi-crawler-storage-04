# ⚡ RepoSmith 

[![PyPI version](https://img.shields.io/pypi/v/reposmith-tol?style=flat-square)](https://pypi.org/project/reposmith-tol/)
![Python](https://img.shields.io/pypi/pyversions/reposmith-tol?style=flat-square)
![License](https://img.shields.io/github/license/liebemama/RepoSmith?style=flat-square)
![CI Success](https://img.shields.io/github/actions/workflow/status/liebemama/RepoSmith/ci.yml?branch=main&label=CI%20Success&style=flat-square&logo=github)
![Security Advisories](https://img.shields.io/badge/Advisories-Active-blue?style=flat-square&logo=github)
[![Sponsor](https://img.shields.io/badge/Sponsor-💖-pink?style=flat-square)](https://github.com/sponsors/liebemama)



**RepoSmith** is a **portable Python project bootstrapper** — a zero-dependency CLI & library that helps you spin up new projects instantly.  
With one command, you get a ready-to-code environment: virtualenv, config files, VS Code setup, `.gitignore`, LICENSE, and optional CI.

---

## ✨ Features
- 🚀 **Zero dependencies** — built only with Python stdlib
- ⚙️ **Virtual environment** auto-created (`.venv`)
- 📦 **requirements.txt** scaffolded (empty but ready)
- 📝 **Entry file** (`main.py` or `run.py`) with a welcome message
- 🛡 **LICENSE** (MIT by default, more soon)
- 🙈 **.gitignore** presets (Python, Node, Django…)
- 💻 **VS Code config** (`settings.json`, `launch.json`, workspace)
- 🔄 **GitHub Actions** workflow (`.github/workflows/ci.yml`)
- 🔧 Idempotent: runs safely again without overwriting unless `--force`

---

## ⚡ Quick Start

### Option 1 — run via Python module (always works)
```powershell
cd MyProject
py -m reposmith init --entry run.py --with-vscode --with-ci
```

### Option 2 — run via CLI (if Scripts folder is on PATH)
```powershell
reposmith init --entry run.py --with-vscode --with-ci
```

Both commands will:
- create `.venv/`
- add `requirements.txt`, `run.py`, `.gitignore`, `LICENSE`, `.vscode/`
- configure everything automatically with defaults

---


> ℹ️ **Note:** For compatibility with older versions, you can still run  
> `py -m reposmith.main ...` but it is recommended to use  
> `py -m reposmith ...` going forward.

## 🚀 Usage

Basic:
```powershell
reposmith init --entry main.py
```

With extras:
```powershell
reposmith init --entry run.py --with-ci --with-gitignore --with-license --with-vscode --author "YourName"
```

Flags:
- `--force` → overwrite existing files (with `.bak` backup)
- `--no-venv` → skip creating `.venv`
- `--with-license` → add LICENSE (MIT)
- `--with-gitignore` → add .gitignore (Python preset by default)
- `--with-vscode` → add VS Code config
- `--with-ci` → add GitHub Actions workflow
- `--author` / `--year` → customize LICENSE metadata
- `--ci-python` → set Python version for CI (default: 3.12)

---

### Option 3 — run via `on` helper (shortcut)

For convenience, RepoSmith also ships with an **`on/` package** in the repo root.  
This lets you launch the tool with a shorter command:

```powershell
cd MyProject
py -m on init
```

---

## 📦 Installation
```powershell
py -m pip install --upgrade reposmith-tol
```

If PATH not configured, use:
```powershell
py -m reposmith init --entry run.py
```

---

## 🧪 Development
Run tests:
```powershell
python -m unittest discover -s tests -v
```

---

## 🗺️ Roadmap

- Support additional templates (Django, FastAPI, React)
- Interactive wizard (`reposmith init --interactive`)
- More license options (Apache-2.0, GPL-3.0)
- Release workflow via GitHub Releases

🔗 [Follow the project progress on GitHub Projects](https://github.com/orgs/liebemama/projects/2)


---


## 🛡 License
This project is licensed under the [MIT License](https://github.com/liebemama/RepoSmith/blob/main/LICENSE).  
© 2025 TamerOnLine

---

## 💬 Support

- 🐞 **Bug Report:** [Open Bug Report](https://github.com/liebemama/RepoSmith/issues/new?template=bug.yml)  
- 💡 **Feature Request:** [Suggest a Feature](https://github.com/liebemama/RepoSmith/issues/new?template=feature.yml)  
- ✅ **Task / ToDo:** [Create Task](https://github.com/liebemama/RepoSmith/issues/new?assignees=&labels=task&template=task.yml)  
- 📄 **Blank Issue:** [Open Blank Issue](https://github.com/liebemama/RepoSmith/issues/new)  
- 📂 **All Issues:** [GitHub Issues](https://github.com/liebemama/RepoSmith/issues)  
- 💬 **Discussions:** [Join the Conversation](https://github.com/liebemama/RepoSmith/discussions)  
- 💖 **Sponsor:** [GitHub Sponsors](https://github.com/sponsors/liebemama)  
- 📧 **Contact:** [info@tameronline.com](mailto:info@tameronline.com)

---


