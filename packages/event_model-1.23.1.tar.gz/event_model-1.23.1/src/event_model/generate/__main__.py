from event_model.generate.create_documents import generate

if __name__ == "__main__":
    generate()
