from . import main

main.main()  # type: ignore
