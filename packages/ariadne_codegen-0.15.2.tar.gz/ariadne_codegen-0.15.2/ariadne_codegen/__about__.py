__version__ = "0.15.2"  # This is overwritten by Hatch in CI/CD, don't change it.
