
#if defined(_MSC_VER)
    #pragma comment(lib, "Winmm.lib")
    #pragma comment(lib, "Avrt.lib")
#endif

#include "stim.hpp"

void make_dto() {
}

void init() {
}
