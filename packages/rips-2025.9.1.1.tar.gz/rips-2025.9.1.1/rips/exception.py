class RipsError(Exception):
    pass
