"""
Test suite for RAGPack.

This module contains tests for all RAGPack functionality including
core features, provider integrations, encryption, and error handling.
"""
