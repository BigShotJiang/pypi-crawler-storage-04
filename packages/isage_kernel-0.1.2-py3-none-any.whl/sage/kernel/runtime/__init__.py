"""
Runtime module for SAGE framework
"""

__version__ = "1.0.0"