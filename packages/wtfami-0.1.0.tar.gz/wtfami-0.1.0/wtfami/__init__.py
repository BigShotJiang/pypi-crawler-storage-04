import os


def getPath():
    return os.getcwd()