from typing import List

from samtranslator.parser.parser import Parser

__all__: List[str] = ["Parser"]
