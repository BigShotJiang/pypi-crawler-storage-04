"""
The module for samtranslator internal implementations.

External packages should not import anything from it
as all interfaces are subject to change without warning.
"""
