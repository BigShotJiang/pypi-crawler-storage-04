"""Utility functions for AIS."""

# Future utility functions can be added here
