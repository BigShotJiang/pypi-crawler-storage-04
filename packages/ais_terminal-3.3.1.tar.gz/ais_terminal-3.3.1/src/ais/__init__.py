"""AIS - 上下文感知的错误分析学习助手。"""

__version__ = "3.3.1"
__author__ = "AIS Team"
__email__ = "ais@example.com"
__description__ = "上下文感知的错误分析学习助手 - 让每次报错都是成长"
