Schema
======

.. automodule:: ocdskit.schema
   :members:
   :undoc-members:
   :special-members:
   :exclude-members: __repr__,__dict__,__setitem__,__module__,__weakref__
