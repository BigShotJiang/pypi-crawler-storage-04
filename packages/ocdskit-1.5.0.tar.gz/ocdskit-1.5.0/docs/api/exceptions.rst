Exceptions
==========

.. autoexception:: ocdskit.exceptions.OCDSKitError
.. autoexception:: ocdskit.exceptions.CommandError
.. autoexception:: ocdskit.exceptions.InconsistentVersionError
.. autoexception:: ocdskit.exceptions.MissingColumnError
.. autoexception:: ocdskit.exceptions.UnknownFormatError
.. autoexception:: ocdskit.exceptions.MissingOcidKeyError
