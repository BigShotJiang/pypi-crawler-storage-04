# getpath

A dead-simple Python library to get the current working directory.

## Install

```bash
pip install wtfami
```