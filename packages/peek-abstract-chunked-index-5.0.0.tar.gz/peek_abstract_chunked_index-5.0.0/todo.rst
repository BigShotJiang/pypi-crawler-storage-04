Things TODO
-----------

Implement worker ItemKeyIndexRemover


