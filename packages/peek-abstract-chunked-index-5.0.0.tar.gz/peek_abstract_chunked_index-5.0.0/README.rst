======================
Index Blueprint Plugin
======================

This plugin is the blueprint for how the Peek indexed data with
offline support works.

