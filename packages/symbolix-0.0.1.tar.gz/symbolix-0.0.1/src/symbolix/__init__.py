"""symbolix: A step-by-step computer algebra library for Python."""

__version__ = "0.1.0"
