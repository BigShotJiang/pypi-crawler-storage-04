# symbolix
symbolix is a step-by-step computer algebra library for Python. Unlike traditional CAS, it performs only explicit, user-requested transformations and preserves expression order. Designed as a reliable replacement for paper-and-pencil calculations in science.
