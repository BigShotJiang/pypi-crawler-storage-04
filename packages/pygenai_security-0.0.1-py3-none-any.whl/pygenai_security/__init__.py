"""
PyGenAI Security Framework
==========================

A comprehensive, production-ready security framework for Python and GenAI applications.
Designed for enterprise use with VS Code integration, TestSprite MCP connectivity,
and privacy-first analytics.

Copyright (C) 2025 RiteshGenAI
Repository: https://github.com/RiteshGenAI/pygenai-security
License: MIT

Features:
- Traditional Python security scanning (SQL injection, XSS, etc.)
- GenAI-specific security (prompt injection, data leakage, etc.)  
- VS Code Language Server integration
- TestSprite MCP connectivity
- Enterprise analytics and compliance reporting
- Multi-format reporting (JSON, HTML, CSV, PDF)
"""

__version__ = "1.0.0"
__author__ = "RiteshGenAI"
__email__ = "support@pygenai-security.com"
__license__ = "MIT"
__repository__ = "https://github.com/RiteshGenAI/pygenai-security"

# Core imports for easy access
from .core.security_scanner import PyGenAIScanner
from .core.vulnerability import Vulnerability, ThreatLevel, VulnerabilityCategory
from .core.config_manager import ConfigManager
from .core.exceptions import PyGenAISecurityError, ScanError, ConfigurationError

# Enterprise imports
from .enterprise.license_manager import LicenseManager
from .enterprise.compliance_reporter import ComplianceReporter

# Analytics imports  
from .analytics.usage_tracker import UsageTracker
from .analytics.telemetry_client import TelemetryClient

# Utils
from .utils.report_generator import ReportGenerator

# Main scanner class for simple usage
Scanner = PyGenAIScanner

__all__ = [
    # Core classes
    'PyGenAIScanner',
    'Scanner', 
    'Vulnerability',
    'ThreatLevel',
    'VulnerabilityCategory',
    'ConfigManager',
    
    # Enterprise features
    'LicenseManager',
    'ComplianceReporter',
    
    # Analytics
    'UsageTracker',
    'TelemetryClient',
    
    # Utils
    'ReportGenerator',
    
    # Exceptions
    'PyGenAISecurityError',
    'ScanError', 
    'ConfigurationError',
    
    # Metadata
    '__version__',
    '__author__',
    '__license__',
    '__repository__'
]

# Simple usage example in module docstring
def quick_scan_example():
    """
    Quick usage example:
    
    from pygenai_security import Scanner
    
    scanner = Scanner()
    results = scanner.scan_directory('/path/to/your/project')
    
    print(f"Found {results['total_vulnerabilities']} security issues")
    """
    pass
