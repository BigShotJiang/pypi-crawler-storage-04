"""Merge 51dd and d2aa

Revision ID: d643752544de
Revises: 51dddd79aa21, d2aafa234374
Create Date: 2020-03-09 12:04:27.013567

"""

# revision identifiers, used by Alembic.
revision = "d643752544de"
down_revision = ("51dddd79aa21", "d2aafa234374")
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
