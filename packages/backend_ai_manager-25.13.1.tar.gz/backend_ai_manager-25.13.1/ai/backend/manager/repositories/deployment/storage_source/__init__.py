"""Storage source for deployment repository."""

from .storage_source import DeploymentStorageSource

__all__ = ["DeploymentStorageSource"]
