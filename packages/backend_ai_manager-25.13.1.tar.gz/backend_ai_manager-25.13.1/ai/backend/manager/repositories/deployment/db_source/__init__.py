"""Database source for deployment repository."""

from .db_source import DeploymentDBSource

__all__ = ["DeploymentDBSource"]
