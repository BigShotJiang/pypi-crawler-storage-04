## Example scripts to run evaluations from generated *ShEPhERD* samples

Data can be downloaded from this link: https://www.dropbox.com/scl/fo/rgn33g9kwthnjt27bsc3m/ADGt-CplyEXSU7u5MKc0aTo?rlkey=fhi74vkktpoj1irl84ehnw95h&e=1&st=wn46d6o2&dl=0

You will need to change the `.sh` scripts to point to the correct, local path.
