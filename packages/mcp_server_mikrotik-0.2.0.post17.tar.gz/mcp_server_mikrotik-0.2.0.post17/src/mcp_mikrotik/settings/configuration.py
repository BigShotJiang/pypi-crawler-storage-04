DEFAULT_MIKROTIK_HOST = "127.0.0.1"  
DEFAULT_MIKROTIK_USER = "admin"        
DEFAULT_MIKROTIK_PASS = ""    

mikrotik_config = {
    "host": DEFAULT_MIKROTIK_HOST,
    "username": DEFAULT_MIKROTIK_USER,
    "password": DEFAULT_MIKROTIK_PASS,
    "port": 22
}
