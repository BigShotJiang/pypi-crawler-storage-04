# File Statistics Report for contxt

## Files Sorted by Size

| Size (bytes)   | Lines        | File                  |
|----------------|--------------|---------------------- |
|       19,677 |        450 | contxt\repo_flattener.py |
|        1,721 |         58 | .github\workflows\pypi-publish.yml |
|          616 |         30 | pytest.ini |
|          562 |         31 | pyproject.toml |
|          154 |         11 | contxt.toml |
|          134 |         13 | .gitignore |
|           89 |          7 | Taskfile.yml |
|           51 |          3 | contxt\logger.py |
|            0 |          0 | README.md |
|            0 |          0 | contxt\__init__.py |

## Files Sorted by Line Count

| Size (bytes)   | Lines        | File                  |
|----------------|--------------|---------------------- |
|       19,677 |        450 | contxt\repo_flattener.py |
|        1,721 |         58 | .github\workflows\pypi-publish.yml |
|          562 |         31 | pyproject.toml |
|          616 |         30 | pytest.ini |
|          134 |         13 | .gitignore |
|          154 |         11 | contxt.toml |
|           89 |          7 | Taskfile.yml |
|           51 |          3 | contxt\logger.py |
|            0 |          0 | README.md |
|            0 |          0 | contxt\__init__.py |

## Summary

- Total text files: 10
- Total size: 23,004 bytes
- Total lines: 603
- Average size: 2,300.40 bytes per file
- Average lines: 60.30 lines per file
