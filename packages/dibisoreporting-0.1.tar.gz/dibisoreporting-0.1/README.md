# DiBISO reporting

*Archive:* new repository at https://github.com/dibiso-upsaclay/dibisoreporting

A Python library for generating bibliometric reports, developed at the [DiBISO](https://www.bibliotheques.universite-paris-saclay.fr/en/department-libraries-information-and-open-science-dibiso-and-its-missions).

The library contains the following submodules:
  - `biso`: reporting for the BiSO (Open-Science Report)


Homepage: https://pypi.org/project/dibisoreporting/

Documentation: https://dibiso-upsaclay.github.io/dibisoreporting/

Repository URL: https://github.com/dibiso-upsaclay/dibisoreporting

Romain THOMAS 2025  
Department of Libraries, Information and Open Science (DiBISO)  
Université Paris-Saclay
