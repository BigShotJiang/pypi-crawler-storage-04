"""Resolvers for database operations."""

from lightly_purple.resolvers import metadata_resolver

__all__ = [
    "metadata_resolver",
]
