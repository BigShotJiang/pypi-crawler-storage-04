# Selection

The architecture follows the design document. 
See https://docs.google.com/document/d/1ZRICdFmfJmxUBy3FFoeUWsAgsCNWDHg8CK5MJiGmX74/edit?tab=t.kbfvnrepsuf#bookmark=id.4wbh2eqhgokk
The design document also contains an architecture diagram showing the
relationship between the various components of the system.