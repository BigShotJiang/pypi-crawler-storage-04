"""Global list fo the active features."""

# TODO(Kondrat 04/25): Pass the feature flag to app
# https://linear.app/lightly/issue/LIG-6708/introduce-apifeatures-endpoint
from typing import List

purple_active_features: List[str] = []
