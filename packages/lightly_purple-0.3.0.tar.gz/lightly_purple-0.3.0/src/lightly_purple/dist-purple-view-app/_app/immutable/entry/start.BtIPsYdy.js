import{l as o,d as r}from"../chunks/DVrGeszw.js";export{o as load_css,r as start};
