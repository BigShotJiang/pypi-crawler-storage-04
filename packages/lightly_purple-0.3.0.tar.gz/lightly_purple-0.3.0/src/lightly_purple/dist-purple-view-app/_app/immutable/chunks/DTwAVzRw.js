import{l as o,E as f,m as i,n as p,o as c,q as d,v as h}from"./Bzf_CGVu.js";function v(s,e,...t){var r=s,n=p,a;o(()=>{n!==(n=e())&&(a&&(c(a),a=null),a=i(()=>n(r,...t)))},f),d&&(r=h)}export{v as s};
