=====
Nexia
=====


.. image:: https://img.shields.io/pypi/v/nexia.svg
        :target: https://pypi.python.org/pypi/nexia

.. image:: https://img.shields.io/travis/bdraco/nexia.svg
        :target: https://travis-ci.com/bdraco/nexia

.. image:: https://readthedocs.org/projects/nexia/badge/?version=latest
        :target: https://nexia.readthedocs.io/en/latest/?badge=latest
        :alt: Documentation Status


.. image:: https://pyup.io/repos/github/bdraco/nexia/shield.svg
     :target: https://pyup.io/repos/github/bdraco/nexia/
     :alt: Updates



Python library for connecting to nexia


* Free software: Apache Software License 2.0
* Documentation: https://nexia.readthedocs.io.


Features
--------

* TODO

Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
