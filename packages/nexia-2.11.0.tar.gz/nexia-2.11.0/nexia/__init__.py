"""Top-level package for Nexia."""

from .const import __version__  # noqa: F401
