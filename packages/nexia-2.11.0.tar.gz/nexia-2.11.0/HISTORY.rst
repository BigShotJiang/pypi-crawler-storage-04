=======
History
=======

0.1.0 (2020-03-14)
------------------

* First release on PyPI.
