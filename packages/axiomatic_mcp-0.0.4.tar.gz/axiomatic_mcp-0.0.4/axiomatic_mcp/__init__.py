"""Axiomatic MCP Servers - Modular MCP servers built with FastMCP."""

__version__ = "1.0.0"
