from .main import start
from .main import build_exe

__version__ = "1.0.4"