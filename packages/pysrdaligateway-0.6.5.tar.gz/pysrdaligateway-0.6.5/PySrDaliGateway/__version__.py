"""Version information for PySrDaliGateway."""
# pylint: disable=invalid-name

__version__ = "0.6.5"
