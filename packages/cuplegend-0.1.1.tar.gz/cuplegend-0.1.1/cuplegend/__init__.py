from .main import CupLegend
