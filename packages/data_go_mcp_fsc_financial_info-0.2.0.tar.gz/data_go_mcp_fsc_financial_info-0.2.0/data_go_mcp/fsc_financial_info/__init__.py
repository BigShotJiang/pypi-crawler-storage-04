"""FSC Financial Information MCP Server."""

__version__ = "0.1.1"