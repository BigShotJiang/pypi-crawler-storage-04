"""Public package interface for smsn_telegram_notify."""

from .notify import TelegramNotify

__all__ = ["TelegramNotify"]
__version__ = "0.1.0"
