"""Configuration management for pltr."""
