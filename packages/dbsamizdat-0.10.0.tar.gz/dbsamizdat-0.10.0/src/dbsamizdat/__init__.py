from .samizdat import entitypes, SamizdatView, SamizdatMaterializedView, SamizdatFunction, SamizdatTrigger  # noqa F401

default_app_config = 'dbsamizdat.apps.DBSamizdatConfig'  # For Django < 4.0
