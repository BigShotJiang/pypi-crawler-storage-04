#!/usr/bin/env python3
import setuptools

setuptools.setup()
