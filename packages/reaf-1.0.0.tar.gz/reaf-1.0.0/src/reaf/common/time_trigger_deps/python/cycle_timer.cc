// Copyright 2025 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// https://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
#include "cycle_timer.h"

#include <memory>

#include <absl/memory/memory.h>
#include <absl/time/time.h>
#include <pybind11/detail/common.h>
#include <pybind11/pybind11.h>
#include <pybind11_abseil/absl_casters.h>
#include "clock.h"

namespace reaf {

namespace {

namespace py = ::pybind11;

CycleTimer CreateCycleTimer(absl::Duration period) {
  return CycleTimer(
      std::make_unique<reaf::MonotonicClock>(),
      period);
}

PYBIND11_MODULE(cycle_timer, m) {
  py::class_<CycleTimer>(m, "CycleTimer")
      .def(py::init(&CreateCycleTimer), py::arg("period"))
      .def("wait_for_next_period", &CycleTimer::WaitForNextPeriod,
           py::call_guard<py::gil_scoped_release>());
}

}  // namespace
}  // namespace reaf
