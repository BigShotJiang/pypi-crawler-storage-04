#!/bin/bash

export IDDS_HOST=https://aipanda160.cern.ch:443/idds
export IDDS_LOCAL_CONFIG_ROOT=~/.idds
# export IDDS_CONFIG=
export IDDS_AUTH_TYPE=oidc
# export IDDS_OIDC_TOKEN=~/.idds/.token
export IDDS_VO=Rubin
export IDDS_AUTH_NO_VERIFY=1

