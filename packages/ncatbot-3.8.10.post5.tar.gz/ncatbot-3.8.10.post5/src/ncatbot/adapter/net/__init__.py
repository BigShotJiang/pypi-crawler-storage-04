# NapCat 网络连接适配

from ncatbot.adapter.net.connect import Websocket
from ncatbot.adapter.net.wsroute import Route, check_websocket

__all__ = ["Websocket", "Route", "check_websocket"]
