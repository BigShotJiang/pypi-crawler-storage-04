from ncatbot.plugin.base_plugin.base_plugin import BasePlugin

__all__ = [
    "BasePlugin",
]
