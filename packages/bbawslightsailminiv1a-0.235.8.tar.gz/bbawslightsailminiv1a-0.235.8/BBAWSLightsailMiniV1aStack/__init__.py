"""
Stacks subpackage containing all CDK stack definitions
"""

from .bb_aws_lightsail_mini_v1a import BBAWSLightsailMiniV1a

__all__ = ['BBAWSLightsailMiniV1a']
