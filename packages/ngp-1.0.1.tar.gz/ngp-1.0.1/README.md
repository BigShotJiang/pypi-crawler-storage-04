# name generator, [in] python

```
$ ngp --help
Usage: ngp [--count=COUNT] [--min-length=MIN_LENGTH] [--max-length=MAX_LENGTH]

Generate phrases that are easy to type when using QWERTY
$ ngp --count=3
vus
smeiau
uxkq
$ ngp --count=3 --min-length=10 --max-length=20
yckcpzhqnfkzbcoq
spvixkdoziaj
hsmxoqutnsnvu
$
```
