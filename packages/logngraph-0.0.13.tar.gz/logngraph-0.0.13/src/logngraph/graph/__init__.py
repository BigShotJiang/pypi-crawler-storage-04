from logngraph.errors import *
import contextlib
with contextlib.redirect_stdout(None):
    import pygame

from logngraph.graph.graph import *
