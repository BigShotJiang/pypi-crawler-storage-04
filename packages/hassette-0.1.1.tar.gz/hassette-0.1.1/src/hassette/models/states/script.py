from typing import Literal

from pydantic import Field

from .base import AttributesBase, StringBaseState


class ScriptState(StringBaseState):
    class Attributes(AttributesBase):
        last_triggered: str | None = Field(default=None)
        mode: str | None = Field(default=None)
        current: int | None = Field(default=None)

    domain: Literal["script"]

    attributes: Attributes | None = Field(default=None)
