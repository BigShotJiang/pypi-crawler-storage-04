This is the main python package for Koatl.
