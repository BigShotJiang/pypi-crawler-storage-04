from autoclean.core.task import Task

class GoodTask(Task):
    """This is a good task."""
    def run(self):
        pass
