
github_web = "https://koolshow.github.io/MinesweeperVariants-Vue/"

CORS_resources = {r"/*": {"origins": "*"}}

HOT_RELOAD = True

MULTIPLAYER = True
