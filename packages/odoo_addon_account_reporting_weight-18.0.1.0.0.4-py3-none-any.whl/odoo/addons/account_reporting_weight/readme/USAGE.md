1.  Go to *Invoicing \> Reporting \> Management \> Invoice Analysis*.
2.  Add the "Weight" measure from your "Measures" dropdown in your
    analysis.
