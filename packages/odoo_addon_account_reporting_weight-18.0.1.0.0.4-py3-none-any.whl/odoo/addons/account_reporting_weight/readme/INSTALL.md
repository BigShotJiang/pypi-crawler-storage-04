- product_weight_through_uom is recommended in case you have products
  with a UoM in the Weight category so the weight is correctly computed.
