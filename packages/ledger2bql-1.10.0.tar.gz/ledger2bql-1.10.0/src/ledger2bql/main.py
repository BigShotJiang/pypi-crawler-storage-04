"""
CLI runner for Ledger2BQL utility.
"""
import sys
from importlib.metadata import PackageNotFoundError
from dotenv import find_dotenv, load_dotenv
import click

from .balance import bal_command
from .register import reg_command


class AliasedGroup(click.Group):
    """A click Group that supports command aliases."""
    
    def get_command(self, ctx, cmd_name):
        """Get the command by name or alias."""
        # Try the normal way first
        rv = click.Group.get_command(self, ctx, cmd_name)
        if rv is not None:
            return rv
        
        # Check for aliases
        aliases = {
            'b': 'bal',
            'r': 'reg'
        }
        
        if cmd_name in aliases:
            return click.Group.get_command(self, ctx, aliases[cmd_name])
        
        return None


@click.group(cls=AliasedGroup, invoke_without_command=True)
@click.option('--version', is_flag=True, help='Show the version and exit.')
@click.pass_context
def cli(ctx, version):
    """Translate Ledger CLI query syntax into BQL"""
    if version:
        try:
            v = version("ledger2bql")
        except PackageNotFoundError:
            v = "local"
        click.echo(f"ledger2bql v{v}")
        sys.exit(0)
    
    # Initialize environment variables by loading .env files in the 
    # parent directories.
    dotenv_path = find_dotenv()
    load_dotenv(dotenv_path, override=True)
    
    # If no subcommand was called, show help
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())
        sys.exit(0)


# Add the subcommands
cli.add_command(bal_command)
cli.add_command(reg_command)


def main():
    """main entry point"""
    cli()


if __name__ == "__main__":
    main()