"""
XandAI Core - Funcionalidades principais
"""
