# gepeto
pip install gepeto
pip install build
pip install twine


# to update pypi package
python -m build
python -m twine upload dist/*


# background
This is a simple agent framework inspired by Swarm, Atomic-Agents, CrewAI.
