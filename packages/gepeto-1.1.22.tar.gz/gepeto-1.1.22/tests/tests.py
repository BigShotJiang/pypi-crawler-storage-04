# make sure instructions can be a prompt

# make sure instructions can be a callable

# make sure instructions can be a string

# make sure a range of pydantic models can be used as response_format

# make sure a range of pydantic models can be used as function inputs

# make sure we can use different llm providers

# make sure we can use different llm models

# make sure we can define a prompt locally, create it remotely, modify it remotely, pull it locally, and delete it remotely

# make sure we can define a team locally, create it remotely, modify it remotely, pull it locally, and delete it remotely

# make sure we can define an agent locally, create it remotely, modify it remotely, pull it locally, and delete it remotely

# make sure we can define a function locally, create it remotely, modify it remotely, pull it locally, and delete it remotely

# make sure the pydantic to json and json to pydantic is working for both function calling and structured output
