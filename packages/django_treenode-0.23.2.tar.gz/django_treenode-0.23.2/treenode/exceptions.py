class CacheError(Exception):
    pass
