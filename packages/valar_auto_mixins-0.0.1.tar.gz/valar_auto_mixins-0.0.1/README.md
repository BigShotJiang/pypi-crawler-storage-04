# mixins for valar
## auto migration
## auto make urlpatterns