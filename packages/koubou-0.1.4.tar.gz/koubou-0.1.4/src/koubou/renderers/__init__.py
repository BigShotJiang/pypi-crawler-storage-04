"""Rendering modules for different screenshot components."""
