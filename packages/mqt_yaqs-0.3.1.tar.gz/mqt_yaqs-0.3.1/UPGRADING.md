# Upgrade Guide

This document describes breaking changes and how to upgrade. For a complete list of changes including minor and patch releases, please refer to the [changelog](CHANGELOG.md).

## [Unreleased]

<!-- Version links -->

[unreleased]: https://github.com/munich-quantum-toolkit/yaqs/compare/v0.3.0...HEAD
