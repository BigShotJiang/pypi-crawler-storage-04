streamlit run symapp.py
