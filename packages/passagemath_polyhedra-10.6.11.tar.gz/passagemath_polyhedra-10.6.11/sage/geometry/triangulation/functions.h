/* sage_setup: distribution = sagemath-polyhedra
 */
#ifndef FUNCTIONS__H
#define FUNCTIONS__H

int factorial(int n);
int binomial(int n, int D);


#endif
