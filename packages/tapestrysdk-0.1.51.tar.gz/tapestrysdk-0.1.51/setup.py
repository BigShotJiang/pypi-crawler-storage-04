from setuptools import setup, find_packages

setup(
    name= "tapestrysdk",
    version="0.1.51",
    packages=find_packages(),
    install_requires=[],
)