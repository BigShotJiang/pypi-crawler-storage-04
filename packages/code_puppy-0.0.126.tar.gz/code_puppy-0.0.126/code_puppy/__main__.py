"""
Entry point for running code-puppy as a module.

This allows the package to be run with: python -m code_puppy
"""

from code_puppy.main import main_entry

if __name__ == "__main__":
    main_entry()
