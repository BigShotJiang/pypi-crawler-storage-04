# pylint: disable=missing-module-docstring
# pylint: disable=cyclic-import

__version__ = '0.4.1'
