async def fetch_binaries() -> None:
    pass
