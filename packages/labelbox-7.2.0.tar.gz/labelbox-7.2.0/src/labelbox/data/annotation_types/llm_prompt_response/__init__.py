from .prompt import PromptText
from .prompt import PromptClassificationAnnotation
