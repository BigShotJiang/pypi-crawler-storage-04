﻿sf\_quant.data.get\_crsp\_daily\_columns
========================================

.. currentmodule:: sf_quant.data

.. autofunction:: get_crsp_daily_columns