Performance
===========

.. automodule:: sf_quant.performance
   :no-members:
   :no-undoc-members:
   :no-imported-members:

.. currentmodule:: sf_quant.performance

.. autosummary::
   :toctree: performance
   :nosignatures: