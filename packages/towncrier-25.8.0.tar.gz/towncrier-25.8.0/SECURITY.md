# Security Policy

The twisted/towncrier project uses the same security policy as [twisted/twisted](https://github.com/twisted/twisted).

For more details, please check the [Twisted security process](https://github.com/twisted/twisted?tab=security-ov-file#readme).
