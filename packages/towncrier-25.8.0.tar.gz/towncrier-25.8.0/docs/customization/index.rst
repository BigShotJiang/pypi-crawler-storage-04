Customizing ``towncrier``
=========================

``towncrier`` can be customized to suit your project's needs.
These pages should describe common customization tasks, while if you want a reference, see `Configuration <../configuration.html>`_.

.. toctree::
   :maxdepth: 2

   newsfile
