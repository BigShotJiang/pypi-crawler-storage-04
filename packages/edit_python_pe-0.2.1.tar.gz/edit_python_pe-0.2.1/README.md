# edit-python.pe

## *Textual Tool for Creating Member Profiles for python.pe*

## **QUICK START**

> This tutorial will guide you step-by-step to create your profile on python.pe
> quickly and securely.

### **PREREQUISITES**

```bash
# Check required versions
uv --version # >= 0.8.11
```

## **INSTALLING edit-python.pe**

### Installing dependencies

```bash
uv sync
```

### **Creating the access token**

1. Generate a [Personal access token
(classic)](https://github.com/settings/tokens).
2. Grant the scope: `public_repo`.
3. Copy the token and keep it handy for the command below

### **For users seeking maximum speed**

```bash
uvx edit-python-pe  
# Next you'll be prompted for your access token
```
