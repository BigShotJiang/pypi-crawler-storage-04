import sys

if __name__ == "__main__":
    from dcaspt2_input_generator.dcaspt2_input_generator import main

    sys.exit(main())
