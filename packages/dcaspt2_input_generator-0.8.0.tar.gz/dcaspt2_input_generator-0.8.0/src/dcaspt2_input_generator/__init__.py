from dcaspt2_input_generator.dcaspt2_input_generator import main  # noqa: F401
