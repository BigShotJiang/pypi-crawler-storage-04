This is a list of useful resources.

# MP4
* https://github.com/sannies/mp4parser

# PNG
* https://www.libpng.org/pub/png/spec/1.2/png-1.2-pdg.html

# OID
* https://oid-base.com/

# FLAC
* https://datatracker.ietf.org/doc/rfc9639/

# OGG
* https://xiph.org/ogg/doc/framing.html

# Matroska
* https://www.matroska.org/technical/elements.html
* https://www.rfc-editor.org/rfc/rfc8794

# PDF
* https://github.com/py-pdf/pypdf

# JPEG
* https://web.archive.org/web/20190713230858/http://www.cipa.jp/std/documents/e/DC-007_E.pdf

# PGP
* https://www.rfc-editor.org/rfc/rfc4880
* https://www.rfc-editor.org/rfc/rfc9580

# ID3v2
* https://id3.org/id3v2.4.0-structure
* https://id3.org/id3v2.4.0-frames

# Files in the exiftool tree
* lib/Image/ExifTool/FujiFilm.pm
