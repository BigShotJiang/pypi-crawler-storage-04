* new file formats
  * DJVU
* ZIP family detection
* more consistent naming convention
* backends (process the json blob)
  * exiftool-like output
  * filtering/labeling files (e.g. "files that have a gps coordinate in the northern hemisphere")
  * plugins (?)
