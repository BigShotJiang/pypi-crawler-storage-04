from schemathesis.pytest.loaders import from_fixture

__all__ = [
    "from_fixture",
]
