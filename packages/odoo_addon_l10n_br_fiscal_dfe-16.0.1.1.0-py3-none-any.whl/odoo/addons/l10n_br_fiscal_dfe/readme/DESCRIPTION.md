Distribuição de documentos fiscais
