# from tk_core.serp_api.trend import get_trend_client
