"""Generated protocol buffer code."""
from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder
_sym_db = _symbol_database.Default()
DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n\tqos.proto\x12\x17com.fundamentum.edge.v1*H\n\x03Qos\x12\x14\n\x10QOS_AT_MOST_ONCE\x10\x00\x12\x15\n\x11QOS_AT_LEAST_ONCE\x10\x01\x12\x14\n\x10QOS_EXACTLY_ONCE\x10\x02b\x06proto3')
_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'qos_pb2', _globals)
if _descriptor._USE_C_DESCRIPTORS == False:
    DESCRIPTOR._options = None
    _globals['_QOS']._serialized_start = 38
    _globals['_QOS']._serialized_end = 110