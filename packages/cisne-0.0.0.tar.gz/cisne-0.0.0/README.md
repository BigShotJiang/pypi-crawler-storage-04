# Cisne

A Python package called cisne.

## Installation

```bash
pip install cisne
```

## Usage

```python
import cisne

# Your package functionality here
```

## Development

To set up the development environment:

```bash
git clone https://github.com/pynosaur/cisne.git
cd cisne
pip install -e .
```

## License

This project is licensed under the MIT License.
