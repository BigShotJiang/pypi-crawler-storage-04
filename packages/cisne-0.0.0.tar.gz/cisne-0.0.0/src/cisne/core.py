def hello_cisne():
    return "Hello from cisne!"

def get_version():
    from . import __version__
    return __version__
