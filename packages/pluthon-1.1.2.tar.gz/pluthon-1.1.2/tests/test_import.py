def test_imports():
    from pluthon import PLambda, IndexAccessList, FunctionalMapAccess  # noqa: F401
