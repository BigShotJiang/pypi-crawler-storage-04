from pathlib import Path

DEFAULT_CHANNELS = ["https://prefix.dev/emscripten-forge-dev", "https://prefix.dev/conda-forge"]
EXTENSION_NAME = "xeus"
STATIC_DIR = Path("@jupyterlite") / EXTENSION_NAME / "static"
