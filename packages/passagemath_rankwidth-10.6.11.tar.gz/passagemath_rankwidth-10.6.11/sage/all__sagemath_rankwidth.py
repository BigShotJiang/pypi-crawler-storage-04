# sage_setup: distribution = sagemath-rankwidth
# delvewheel: patch

from sage.all__sagemath_graphs import *
