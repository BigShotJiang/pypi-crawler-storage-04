"""
Composite operations package
""" 