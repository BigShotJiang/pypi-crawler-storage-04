#ifndef EIGEN_SPARSE_EXTRA_MODULE_H
#error "Please include unsupported/Eigen/SparseExtra instead of including headers inside the src directory directly."
#endif
