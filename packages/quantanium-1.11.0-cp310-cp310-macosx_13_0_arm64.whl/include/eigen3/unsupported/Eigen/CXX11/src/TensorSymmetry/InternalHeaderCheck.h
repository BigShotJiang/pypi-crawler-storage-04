#ifndef EIGEN_CXX11_TENSORSYMMETRY_MODULE_H
#error "Please include unsupported/Eigen/CXX11/TensorSymmetry instead of including headers inside the src directory directly."
#endif
