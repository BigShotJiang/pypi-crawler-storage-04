# curl-cffi request extension.

## Installation

You can install via [pypi](https://pypi.org/project/curl_cffi_request/)

```console
pip install -U curl_cffi_request
```

## Usage

```python
from curl_cffi_request import request
```
