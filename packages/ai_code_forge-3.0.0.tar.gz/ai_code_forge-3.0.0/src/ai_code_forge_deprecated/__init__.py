"""Deprecated ai-code-forge package - use 'acforge' instead."""

__version__ = "3.0.0"