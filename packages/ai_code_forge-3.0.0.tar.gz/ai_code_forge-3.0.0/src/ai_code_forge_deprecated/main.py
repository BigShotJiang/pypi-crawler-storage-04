#!/usr/bin/env python3
"""Entry point function for deprecated package commands."""

from .__main__ import main

__all__ = ["main"]