"""A tool to process LaTeX documents using the 'changes' package."""
__version__ = "0.1.0"