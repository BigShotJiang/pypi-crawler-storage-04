# MU-INVENIO-CLI

MU-INVENIO-CLI is a command-line tool for creating drafts and uploading files in the Invenio webpage.

## Features

- Create and edit record drafts
- Upload files to records
- Delete drafts
