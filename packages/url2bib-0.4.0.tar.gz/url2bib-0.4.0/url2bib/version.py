"""Version information for url2bib."""

__version__ = "0.4.0"
