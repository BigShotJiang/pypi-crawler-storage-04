from biobase.parser import fasta

# Fasta parser functions
fasta_parser = fasta.fasta_parser
fasta_file_parser = fasta.fasta_file_parser

# Record Class
FastaRecord = fasta.FastaRecord
