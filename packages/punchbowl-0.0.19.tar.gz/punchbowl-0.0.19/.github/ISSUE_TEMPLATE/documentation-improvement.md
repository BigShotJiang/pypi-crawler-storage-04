---
name: Documentation improvement
about: Suggest how to improve the documentation
title: ''
labels: documentation
assignees: ''

---

How can the documentation be improved?
