"""Data processing algorithms."""
