"""Utilities to process multiple samples."""

from .assay import Assay

__all__ = ["Assay"]
