"""TidyMS2 abstract operators."""
