.. algorithms-api

algorithms
==========

Low level algorithms for data processing:

.. toctree::
   :maxdepth: 1

   Raw data <algorithms/raw>
   Signal processing <algorithms/signal>