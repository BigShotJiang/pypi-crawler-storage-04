.. _chemistry-api:

Chemistry
=========

.. automodule:: tidyms2.chem
   :members:
        Element,
        Formula
   :inherited-members: BaseModel
   :exclude-members: model_computed_fields, model_config, model_fields
