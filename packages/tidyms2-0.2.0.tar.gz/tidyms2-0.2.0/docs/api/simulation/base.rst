.. _simulation-base-api:

Base utilities
==============

..   automodule:: tidyms2.simulation.base
     :members:
     :show-inheritance:
     :inherited-members: BaseModel
     :exclude-members: model_computed_fields, model_config, model_fields