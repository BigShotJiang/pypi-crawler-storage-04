.. _simulation-lcms-api:

LC-MS data simulation
=====================

..   automodule:: tidyms2.simulation.lcms
     :show-inheritance:
     :inherited-members: BaseModel
     :exclude-members: MSSpectrumFactory