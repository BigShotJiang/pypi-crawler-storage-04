.. _core-api:

Core components
===============

.. toctree::
   :maxdepth: 1

   core/enumerations
   core/models
   Operators <core/operators>
   Data flow <core/dataflow>
   core/interfaces
   core/matrix