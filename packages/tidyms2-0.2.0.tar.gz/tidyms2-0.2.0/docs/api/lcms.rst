.. _lcms-api:

LC-MS
=====

..   automodule:: tidyms2.lcms
     :show-inheritance:
     :members:
          Peak,
          create_lcms_assay,
          LCFeatureMatcher,
          LCTraceBaselineEstimator,
          LCTraceExtractor,
          LCTraceSmoother,
          LCPeakExtractor,
     :exclude-members: model_computed_fields, model_config, model_fields