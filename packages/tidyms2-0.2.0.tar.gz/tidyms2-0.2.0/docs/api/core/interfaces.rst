.. _core-interfaces-api:

Storage interfaces
==================

.. automodule:: tidyms2.core.storage
   :show-inheritance:
   :members: SampleStorage, AssayStorage