.. _core-matrix-api:

Data matrix
===========

.. automodule:: tidyms2.core.matrix
   :show-inheritance:
   :members: DataMatrix, FeatureVector, SampleVector