.. _core-enums-api:

Enumerations
============

.. autoclass:: tidyms2.core.enums.OperatorType()
    :members:

.. autoclass:: tidyms2.core.enums.MSInstrument()
    :members: