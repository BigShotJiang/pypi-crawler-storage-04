.. _core-models-api:

Data models
===========

.. automodule:: tidyms2.core.models
   :members:
   :show-inheritance:
   :inherited-members: BaseModel
   :exclude-members: model_computed_fields, model_config, model_fields