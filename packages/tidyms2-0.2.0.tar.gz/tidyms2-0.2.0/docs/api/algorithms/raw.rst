.. _raw-data-algorithms:

Raw data data algorithms
========================

.. automodule:: tidyms2.algorithms.raw
    :members:
    :exclude-members: BaseRawMsFunctionParameter, SpectrumMatch