.. _developer-guides:

Developer guides
================

Here you can find guides aimed at contributors or users that want to extend the library:

.. toctree::
   :maxdepth: 1

   dev/contributing
   dev/extending