# Releasing e2b cli

to create a changeset run `npx changeset`
