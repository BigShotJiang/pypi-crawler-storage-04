export function HeaderSeparator() {
  return (
    <div className="hidden md:block md:h-5 md:w-px md:bg-zinc-900/10 md:dark:bg-white/15"/>
  )
}
