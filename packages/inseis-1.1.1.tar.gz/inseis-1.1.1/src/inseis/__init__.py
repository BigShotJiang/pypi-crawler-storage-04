"""
InSeis: Seismic Unix Workflow Manager

A GUI application for creating and running Seismic Unix workflows.
"""

__version__ = "1.1.1"
