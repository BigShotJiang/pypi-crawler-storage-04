"""Data resources for the SuBridge application."""
