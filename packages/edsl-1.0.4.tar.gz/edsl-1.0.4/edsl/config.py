"""Config module wrapper for backward compatibility.

# Re-export everything from edsl.config module
from edsl.config import *
from edsl.config.config_class import *