[![PyPI version](https://badge.fury.io/py/django-advanced-report-builder.svg)](https://badge.fury.io/py/django-advanced-report-builder)


# django-advanced-report-builder
