from .task import sqa, sqa_dev, sqa_test

__all__ = ["sqa", "sqa_dev", "sqa_test"]
