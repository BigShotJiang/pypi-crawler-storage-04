"""Test package for sentineliqsdk."""
