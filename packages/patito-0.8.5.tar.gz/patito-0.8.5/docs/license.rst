Licence
=======

.. include:: ../LICENSE
