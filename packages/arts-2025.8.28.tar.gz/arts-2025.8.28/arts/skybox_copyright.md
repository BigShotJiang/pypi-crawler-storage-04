# 描述

`skybox` 文件夹内存放的是我的个人文件，这些文件不纳入开源范围，其相关全部权利由我本人（许灿标）保留。

# 作者

姓名: 许灿标

作者相关链接: [主页](https://lcctoor.com/) \| [Github](https://github.com/lcctoor) \| [PyPi](https://pypi.org/user/lcctoor) \| [微信](https://lcctoor.com/cdn/wechat_qrc.jpg) \| [邮箱](mailto:lcctoor@outlook.com) \| [捐赠](https://lcctoor.com/cdn/donation_qrc_0rmb.jpg)

# 版权声明

copyright 许灿标. 保留所有权利。
