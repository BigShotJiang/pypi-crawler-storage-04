# 描述

`local_file_hashes.yaml` 文件中记录的是我的一些本地个人文件的哈希值。
