Run pip only as subprocess, not access its API programatically: https://pip.pypa.io/en/stable/user_guide/#using-pip-from-your-program
