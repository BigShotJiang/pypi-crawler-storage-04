from mcp_server_multi_fetch import main

main()
