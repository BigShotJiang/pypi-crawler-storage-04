# NAC Pusher

A Python package for pushing messages to Feishu (Lark).

## Installation

```bash
pip install nac-pusher
```

## Usage

```python
from feishu_push import FeishuBot

bot = FeishuBot()
bot.append_push_txt('Hello, World!').send()
```

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.