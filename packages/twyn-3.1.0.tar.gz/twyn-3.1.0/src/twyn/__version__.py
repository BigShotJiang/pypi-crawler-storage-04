from importlib import metadata

__version__: str = metadata.version("twyn")
