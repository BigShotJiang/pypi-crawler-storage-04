"""Generalized CP Decomposition Support Code."""
