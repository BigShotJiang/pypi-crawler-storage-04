from .cli import main as run_main

__all__ = ["run_main"]

if __name__ == "__main__":
    run_main()
