"""Command-line interface for the OpenAPI to Arazzo generator."""

from .main import main

__all__ = ["main"]
