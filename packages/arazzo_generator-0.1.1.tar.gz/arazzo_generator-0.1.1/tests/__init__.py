"""Test package for the OpenAPI to Arazzo generator."""
