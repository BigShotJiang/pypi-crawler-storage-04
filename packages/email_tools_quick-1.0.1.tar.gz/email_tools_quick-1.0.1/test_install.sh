. .env
uv run --with email_tools -i $UV_PUBLISH_INDEX --no-project -- python -c "import email_tools"
