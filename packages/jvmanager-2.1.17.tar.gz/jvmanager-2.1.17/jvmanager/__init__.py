"""
jvmanager package initialization.

This package provides the jvmanager client
"""

from importlib.metadata import version

__version__ = version("jvmanager")
