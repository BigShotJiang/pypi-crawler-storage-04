"""
Here we keep helper code to include external packages into RETURNN.
Here we also keep git submodules of the external packages.
"""
