Kokkos Thread Parallelism
=========================

For performance portable thread parallelism as well as thread safe random number generation we use
Kokkos! :cite:`kokkos1` :cite:`kokkos2`, :cite:`kokkos3`.

It has great documentation, lectures, tutorials and more, all of which
you can enjoy when you explore
`Kokkos' GitHub repositories <https://github.com/kokkos>`_.
