Coalescence-Breakup-Rebound
===========================

Header file: ``<libs/superdrops/collisions/coalbure.hpp>``
`[source] <https://github.com/yoctoyotta1024/CLEO/blob/main/libs/superdrops/collisions/coalbure.hpp>`_

.. doxygenstruct:: DoCoalBuRe
   :project: superdrops
   :private-members:
   :protected-members:
   :members:
   :undoc-members:

.. doxygenfunction:: CoalBuRe
   :project: superdrops
