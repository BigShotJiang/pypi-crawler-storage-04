Collisions
==========

Header file: ``<libs/superdrops/collisions/collisions.hpp>``
`[source] <https://github.com/yoctoyotta1024/CLEO/blob/main/libs/superdrops/collisions/collisions.hpp>`_

.. doxygenconcept:: PairProbability
   :project: superdrops

.. doxygenconcept:: PairEnactX
   :project: superdrops

.. doxygenstruct:: DoCollisions
   :project: superdrops
   :private-members:
   :protected-members:
   :members:
   :undoc-members:
