Zarr Metadata
=============

Header file: ``<libs/zarr/zarr_metadata.hpp>``
`[source] <https://github.com/yoctoyotta1024/CLEO/blob/main/libs/zarr/zarr_metadata.hpp>`_

.. doxygenfunction:: vec_to_string
   :project: zarr

.. doxygenfunction:: make_part_zarrmetadata
   :project: zarr

.. doxygenclass:: ZarrMetadata
   :project: zarr
   :private-members:
   :protected-members:
   :members:
   :undoc-members:
