"""Integration tests for NovaEval."""
