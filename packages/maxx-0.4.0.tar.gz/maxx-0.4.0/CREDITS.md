# Credits

This library is heavily inspired by [griffe](https://github.com/mkdocstrings/griffe).  
This package intends to do the same, but for MATLAB.
