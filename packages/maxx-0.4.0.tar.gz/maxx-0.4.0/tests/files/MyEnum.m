classdef MyEnum < int16
    enumeration
        foo (0) % foo
        bar (42)
            % bar
        baz (69)
    end
end
