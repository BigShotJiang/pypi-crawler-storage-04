"""
B站 API 工具模块 (异步版本)
参考项目：https://github.com/lesir831/bilibili-video-info-mcp
"""
import re
import httpx
import os
from typing import Optional, Tuple, List, Dict, Any

# B站 API 端点
API_GET_VIEW_INFO = "https://api.bilibili.com/x/web-interface/view"
API_GET_USER_INFO = "https://api.bilibili.com/x/space/acc/info"
API_GET_USER_VIDEOS = "https://api.bilibili.com/x/space/arc/search"
API_GET_USER_DYNAMICS = "https://api.bilibili.com/x/polymer/web-dynamic/v1/feed/space"

# 默认请求头
DEFAULT_HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36',
    'Referer': 'https://www.bilibili.com/'
}

def _get_headers() -> Dict[str, str]:
    """获取请求头，包含所有必要的 Cookie"""
    headers = DEFAULT_HEADERS.copy()
    sessdata = os.getenv("SESSDATA")
    bili_jct = os.getenv("BILI_JCT")
    buvid3 = os.getenv("BUVID3")
    
    cookies = []
    if sessdata:
        cookies.append(f'SESSDATA={sessdata}')
    if bili_jct:
        cookies.append(f'bili_jct={bili_jct}')
    if buvid3:
        cookies.append(f'BUVID3={buvid3}')
    
    if cookies:
        headers['Cookie'] = '; '.join(cookies)
        
    return headers

def extract_user_id(url_or_username: str) -> Optional[int]:
    """
    从 URL 或用户名中提取用户 ID

    Args:
        url_or_username: B站用户 URL 或用户名

    Returns:
        用户 ID，如果无法提取则返回 None
    """
    match = re.search(r'/(\d+)', url_or_username)
    if match:
        return int(match.group(1))

    if url_or_username.isdigit():
        return int(url_or_username)

    return None

async def get_user_basic_info(user_id: int) -> Tuple[Optional[Dict[str, Any]], Optional[Dict[str, Any]]]:
    """
    异步获取用户基本信息

    Args:
        user_id: 用户 ID

    Returns:
        (用户信息, 错误信息)
    """
    headers = _get_headers()
    async with httpx.AsyncClient() as client:
        try:
            params = {'mid': user_id}
            response = await client.get(API_GET_USER_INFO, params=params, headers=headers)
            response.raise_for_status()
            data = response.json()

            if data['code'] != 0:
                return None, {'error': 'Failed to get user info', 'details': data}

            return data['data'], None
        except httpx.RequestError as e:
            return None, {'error': f'Failed to fetch user details: {e}'}

async def get_user_videos(user_id: int, limit: int = 10) -> Tuple[Optional[List[Dict[str, Any]]], Optional[Dict[str, Any]]]:
    """
    异步获取用户视频列表

    Args:
        user_id: 用户 ID
        limit: 视频数量限制

    Returns:
        (视频列表, 错误信息)
    """
    headers = _get_headers()
    videos = []
    async with httpx.AsyncClient() as client:
        try:
            params = {
                'mid': user_id,
                'ps': min(limit, 50),
                'pn': 1
            }
            response = await client.get(API_GET_USER_VIDEOS, params=params, headers=headers)
            response.raise_for_status()
            data = response.json()

            if data['code'] != 0:
                return None, {'error': 'Failed to get user videos', 'details': data}

            video_list = data.get('data', {}).get('list', {}).get('vlist', [])
            for video in video_list:
                videos.append({
                    'bvid': video.get('bvid'),
                    'aid': video.get('aid'),
                    'title': video.get('title'),
                    'description': video.get('description'),
                    'created': video.get('created'),
                    'length': video.get('length'),
                    'pic': video.get('pic'),
                    'play': video.get('play'),
                    'favorites': video.get('favorites'),
                    'author': video.get('author'),
                    'mid': video.get('mid'),
                    'url': f"https://www.bilibili.com/video/{video.get('bvid')}" if video.get('bvid') else None
                })

            return videos, None
        except httpx.RequestError as e:
            return None, {'error': f'Failed to fetch user videos: {e}'}

async def get_user_dynamics(user_id: int, limit: int = 10) -> Tuple[Optional[List[Dict[str, Any]]], Optional[Dict[str, Any]]]:
    """
    异步获取用户动态列表

    Args:
        user_id: 用户 ID
        limit: 动态数量限制

    Returns:
        (动态列表, 错误信息)
    """
    headers = _get_headers()
    dynamics = []
    async with httpx.AsyncClient() as client:
        try:
            params = {
                'host_mid': user_id,
                'offset': '',
                'platform': 'web'
            }

            collected_count = 0
            while collected_count < limit:
                response = await client.get(API_GET_USER_DYNAMICS, params=params, headers=headers)
                response.raise_for_status()
                data = response.json()

                if data['code'] != 0:
                    return None, {'error': 'Failed to get user dynamics', 'details': data}

                items = data.get('data', {}).get('items', [])
                if not items:
                    break

                for item in items:
                    if collected_count >= limit:
                        break

                    modules = item.get('modules', {})
                    module_dynamic = modules.get('module_dynamic', {})
                    module_author = modules.get('module_author', {})

                    dynamic_id = item.get('id_str')
                    timestamp = module_author.get('pub_ts')
                    type_name = item.get('type')

                    text_content = ""
                    desc = module_dynamic.get('desc', {})
                    if desc and desc.get('text'):
                        text_content = desc.get('text')

                    pictures = []
                    major = module_dynamic.get('major', {})
                    if major and major.get('draw', {}).get('items'):
                        pictures = [img.get('src') for img in major.get('draw', {}).get('items', [])]

                    video_info = None
                    if major and major.get('archive'):
                        archive = major.get('archive', {})
                        video_info = {
                            'bvid': archive.get('bvid'),
                            'title': archive.get('title'),
                            'cover': archive.get('cover'),
                            'duration': archive.get('duration_text'),
                            'url': f"https://www.bilibili.com/video/{archive.get('bvid')}" if archive.get('bvid') else None
                        }

                    article_info = None
                    if major and major.get('article'):
                        article = major.get('article', {})
                        article_info = {
                            'id': article.get('id'),
                            'title': article.get('title'),
                            'summary': article.get('desc'),
                            'banner_url': article.get('banner_url'),
                            'url': f"https://www.bilibili.com/read/{article.get('id')}" if article.get('id') else None
                        }

                    stat = modules.get('module_stat', {})

                    dynamics.append({
                        'dynamic_id': dynamic_id,
                        'timestamp': timestamp,
                        'type': type_name,
                        'stat': {
                            'like': stat.get('like', {}).get('count', 0),
                            'comment': stat.get('comment', {}).get('count', 0),
                            'forward': stat.get('forward', {}).get('count', 0)
                        },
                        'content': {
                            'text': text_content,
                            'pictures': pictures,
                            'video': video_info,
                            'article': article_info
                        }
                    })

                    collected_count += 1

                has_more = data.get('data', {}).get('has_more', False)
                if not has_more:
                    break

                params['offset'] = data.get('data', {}).get('offset', '')

            return dynamics, None
        except httpx.RequestError as e:
            return None, {'error': f'Failed to fetch user dynamics: {e}'}
