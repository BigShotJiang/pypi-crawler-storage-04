"""
BiliStalkerMCP 服务器核心模块
参考项目：https://github.com/lesir831/bilibili-video-info-mcp
"""

from mcp.server.fastmcp import FastMCP
from . import bilibili_api

# 创建 FastMCP 服务器实例，命名为 BiliStalker
mcp = FastMCP("BiliStalker", dependencies=["requests"])

@mcp.tool(
    annotations={
        "title": "获取用户视频更新",
        "readOnlyHint": True,
        "openWorldHint": False
    }
)
async def get_user_video_updates(user_id: int = None, username: str = None, limit: int = 10) -> list:
    """
    获取 B站用户的视频列表，支持用户名或用户ID查询。

    使用用户名时会自动搜索并匹配最相关的用户。
    返回完整的视频详情，包括播放量、时长、发布日期等。

    Args:
        user_id: B站用户ID
        username: B站用户名
        limit: 返回视频数量限制 (1-50)

    Returns:
        用户视频列表，包含视频详细信息
    """
    if not user_id and not username:
        return ["错误: 必须提供 user_id 或 username"]

    if not (1 <= limit <= 50):
        return ["错误: limit 必须在 1-50 之间"]

    # 处理用户 ID
    target_uid = user_id
    if username:
        target_uid = bilibili_api.extract_user_id(username)
        if not target_uid:
            return [f"错误: 无法找到用户 '{username}'"]

    # 获取用户信息
    user_info, error = await bilibili_api.get_user_basic_info(target_uid)
    if error:
        return [f"获取用户信息失败: {error['error']}"]

    # 获取用户视频
    videos, error = await bilibili_api.get_user_videos(target_uid, limit)
    if error:
        return [f"获取用户视频失败: {error['error']}"]

    if not videos:
        return ["该用户没有公开视频"]

    # 格式化结果
    result = [{
        "user": {
            "mid": user_info.get("mid"),
            "name": user_info.get("name"),
            "face": user_info.get("face"),
            "sign": user_info.get("sign"),
            "level": user_info.get("level"),
        },
        "videos": videos,
        "total": len(videos)
    }]

    return result

@mcp.tool(
    annotations={
        "title": "获取用户动态更新",
        "readOnlyHint": True,
        "openWorldHint": False
    }
)
async def get_user_dynamic_updates(user_id: int = None, username: str = None, limit: int = 10) -> list:
    """
    获取 B站用户的动态列表，支持类型过滤和时间轴展示。

    支持多种动态类型过滤，显示完整的互动统计和媒体内容。
    包含文本、图片、视频和文章等多种动态形式。

    Args:
        user_id: B站用户ID
        username: B站用户名
        limit: 返回动态数量限制 (1-50)

    Returns:
        用户动态列表，包含动态详细信息
    """
    if not user_id and not username:
        return ["错误: 必须提供 user_id 或 username"]

    if not (1 <= limit <= 50):
        return ["错误: limit 必须在 1-50 之间"]

    # 处理用户 ID
    target_uid = user_id
    if username:
        target_uid = bilibili_api.extract_user_id(username)
        if not target_uid:
            return [f"错误: 无法找到用户 '{username}'"]

    # 获取用户信息
    user_info, error = await bilibili_api.get_user_basic_info(target_uid)
    if error:
        return [f"获取用户信息失败: {error['error']}"]

    # 获取用户动态
    dynamics, error = await bilibili_api.get_user_dynamics(target_uid, limit)
    if error:
        return [f"获取用户动态失败: {error['error']}"]

    if not dynamics:
        return ["该用户没有公开动态"]

    # 格式化结果
    result = [{
        "user": {
            "mid": user_info.get("mid"),
            "name": user_info.get("name"),
            "face": user_info.get("face"),
            "sign": user_info.get("sign"),
            "level": user_info.get("level"),
        },
        "dynamics": dynamics,
        "count": len(dynamics)
    }]

    return result

@mcp.custom_route("/health", methods=["GET"])
async def health_check(request):
    """健康检查端点"""
    from starlette.responses import JSONResponse
    return JSONResponse({"status": "ok"})

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="BiliStalkerMCP Server")
    parser.add_argument('transport', nargs='?', default='stdio',
                        choices=['stdio', 'sse', 'streamable-http'],
                        help='Transport type (stdio, sse, or streamable-http)')
    args = parser.parse_args()

    mcp.run(transport=args.transport)
