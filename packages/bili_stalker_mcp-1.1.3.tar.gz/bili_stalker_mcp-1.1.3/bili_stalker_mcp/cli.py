"""
BiliStalkerMCP CLI 入口
参考项目：https://github.com/lesir831/bilibili-video-info-mcp
"""
import argparse
from .server import mcp

def main():
    """主函数：启动 MCP 服务器"""
    parser = argparse.ArgumentParser(description="BiliStalkerMCP Server")
    parser.add_argument('transport', nargs='?', default='stdio',
                        choices=['stdio', 'sse', 'streamable-http'],
                        help='Transport type (stdio, sse, or streamable-http)')
    args = parser.parse_args()

    print("🚀 BiliStalkerMCP Server starting...")
    print(f"📡 Transport: {args.transport}")

    mcp.run(transport=args.transport)

if __name__ == "__main__":
    main()
