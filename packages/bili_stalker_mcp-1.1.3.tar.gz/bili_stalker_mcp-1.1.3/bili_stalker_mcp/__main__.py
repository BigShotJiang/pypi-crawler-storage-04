"""
BiliStalkerMCP 主入口
参考项目：https://github.com/lesir831/bilibili-video-info-mcp
"""
from .server import main

if __name__ == "__main__":
    main()
