__version__ = "0.1.1"
__author__ = "Lars Eggimann"
__email__ = "lars.eggimann@gmail.com"
