def cause_runtime_error():
  x = 10
  y = 1
  result = x / (y - 1) 
  print(result)

cause_runtime_error()