from setuptools import setup, find_packages

setup(
    name="querybuilder-llm",
    version="0.1.0",
    packages=find_packages(),
    install_requires=["requests"],
    author="Manoj Shetty K",
    description="A pip package to generate SQL/Mongo queries from natural language using an LLM API",
    url="",
    python_requires=">=3.8",
)
