type name_0[name_1: [name_2 for name_3 in name_3]] = name_4
