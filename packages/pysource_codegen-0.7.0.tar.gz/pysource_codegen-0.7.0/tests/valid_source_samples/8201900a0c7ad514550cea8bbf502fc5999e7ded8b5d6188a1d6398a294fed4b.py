del (_DAYNAMES,)
