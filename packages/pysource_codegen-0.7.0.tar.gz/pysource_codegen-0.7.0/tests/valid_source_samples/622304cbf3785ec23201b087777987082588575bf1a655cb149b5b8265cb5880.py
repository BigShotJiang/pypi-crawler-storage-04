lambda: (yield)
