def name_0(name_1: (name_2 for name_5 in name_5), /):
    pass
