raise NothingChanged from None
