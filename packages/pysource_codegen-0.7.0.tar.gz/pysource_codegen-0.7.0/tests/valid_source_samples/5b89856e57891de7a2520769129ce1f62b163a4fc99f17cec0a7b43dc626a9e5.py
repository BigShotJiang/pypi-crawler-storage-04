global a
global a
