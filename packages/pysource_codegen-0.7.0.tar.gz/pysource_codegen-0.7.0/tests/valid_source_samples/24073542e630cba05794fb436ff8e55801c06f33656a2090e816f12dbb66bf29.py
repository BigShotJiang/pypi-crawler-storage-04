(equal_ast for l, r in zip)
