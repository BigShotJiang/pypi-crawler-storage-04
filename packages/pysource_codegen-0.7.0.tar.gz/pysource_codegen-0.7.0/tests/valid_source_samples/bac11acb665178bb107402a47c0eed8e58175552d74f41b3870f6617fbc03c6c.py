class TestSuper:
    def tearDown():
        nonlocal __class__
