class name_1(*name_3):
    pass
