for file in something:
    continue
