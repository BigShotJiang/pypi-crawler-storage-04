del [something]
