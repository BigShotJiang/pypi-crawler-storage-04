async def leave_unfinalized_asyncgen():
    async def agen():
        yield item

    return status
