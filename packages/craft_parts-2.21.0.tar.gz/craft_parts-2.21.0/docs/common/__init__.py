# This file exists to enable the craft_parts_docs package to be produced.
