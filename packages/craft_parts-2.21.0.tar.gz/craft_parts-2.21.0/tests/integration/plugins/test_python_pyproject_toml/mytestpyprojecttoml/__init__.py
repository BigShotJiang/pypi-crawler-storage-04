def main():
    print("it works also with pyproject.toml!")
