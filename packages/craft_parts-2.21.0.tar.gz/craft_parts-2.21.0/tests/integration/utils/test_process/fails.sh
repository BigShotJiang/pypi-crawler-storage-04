#!/usr/bin/env bash
echo "Error: Not enough cows." >&2
exit 1
