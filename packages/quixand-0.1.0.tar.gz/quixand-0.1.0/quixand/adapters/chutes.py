from __future__ import annotations

# Placeholder for a Chutes adapter skeleton to illustrate pluggability.
# Implement gRPC/HTTP calls to your infra conforming to the Adapter protocol.


