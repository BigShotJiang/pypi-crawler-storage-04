from __future__ import annotations

# Placeholder for a RemoteHTTP adapter skeleton to illustrate pluggability.
# Full implementation can mirror the base.Adapter protocol over REST.


