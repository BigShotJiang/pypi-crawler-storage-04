// src/flood_solver.h
#ifndef FLOOD_SOLVER_H
#define FLOOD_SOLVER_H

#include <string>

// 洪水模拟主函数
int run_simulation(const std::string& work_dir);

#endif
