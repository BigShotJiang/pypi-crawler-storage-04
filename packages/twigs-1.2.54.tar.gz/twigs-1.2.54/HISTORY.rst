=======
History
=======

0.1.0 (2019-03-18)
------------------

* First release on PyPI.

1.1.0 (2022-01-23)
------------------

* Added support for twigs plugins.

1.2.0 (2024-06-19)
------------------

* Added support for Oracle Cloud (OCI) discovery via native inventory (OCI OS Mgmt Hub).
