from .base import Codec


STANDARD_CODECS: list[Codec] = []
