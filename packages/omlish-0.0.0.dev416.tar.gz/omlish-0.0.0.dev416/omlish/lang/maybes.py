from ..lite.maybes import Maybe


##


empty = Maybe.empty
just = Maybe.just
