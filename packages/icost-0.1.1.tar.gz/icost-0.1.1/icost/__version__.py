# -*- coding: utf-8 -*-
"""
Created on Wed Aug 27 18:27:46 2025

@author: asifn
"""

__version__ = "0.1.1"
