import pytest


@pytest.mark.django_db
class TestSpecificSerializers:
    pass
