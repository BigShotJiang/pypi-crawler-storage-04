"""DawnAI Strategy SDK for efficient strategy development."""

__version__ = "0.1.0"
