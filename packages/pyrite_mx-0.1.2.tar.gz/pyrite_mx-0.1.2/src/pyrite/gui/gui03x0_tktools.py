from hPyT import *
from pywinstyles import *
from sv_ttk import *
from tkinter import font


def center(window):
    window_frame.center(window)

def center_relative(window, relative_to_window):
    window_frame.center_relative(relative_to_window, window) 


