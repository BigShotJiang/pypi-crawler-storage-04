from tkinter.constants import *

