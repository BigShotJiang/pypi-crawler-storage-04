# Examples

Here you will find the jupyter notebook examples with mock data and analysis
routines. These may act as a helpful starting point to build a full analysis
pipeline.
