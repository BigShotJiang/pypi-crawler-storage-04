from .aws_secretsmanager import SecretsManagerStorage as SecureStorage

__all__ = ['SecureStorage']