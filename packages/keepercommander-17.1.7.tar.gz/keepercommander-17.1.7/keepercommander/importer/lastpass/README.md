Commander support for LastPass accounts
---

Keeper Commander uses lastpass-python library to access LastPass data.

https://pypi.org/project/lastpass-python/

[The MIT License](https://opensource.org/licenses/mit-license.php)

You can use the ```import --format=lastpass <email>``` commands within Keeper Commander.
