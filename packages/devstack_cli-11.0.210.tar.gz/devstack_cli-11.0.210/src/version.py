"""
constants, set by build
"""

MAJOR = '11'
BRANCH_NAME = 'release-11'
BUILD_DATE = '2025-09-04-032331'
SHORT_SHA = '000400e'
VERSION = '11+release-11.2025-09-04-032331.000400e'
