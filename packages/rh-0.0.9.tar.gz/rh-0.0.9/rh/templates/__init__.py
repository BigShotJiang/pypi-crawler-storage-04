"""Templates directory marker"""

# Templates directory marker
