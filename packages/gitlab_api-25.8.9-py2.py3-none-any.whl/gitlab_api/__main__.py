#!/usr/bin/python
# coding: utf-8

from .gitlab_api_mcp import main

if __name__ == "__main__":
    main()
