```markdown
# Numai

*Pure NumPy Machine Learning – coming soon.*

---

🚧 **This is a placeholder release**  
The package currently reserves the name on PyPI. Real code will land in `v0.1.0`.

Stay tuned for a lightweight, dependency-free ML toolkit built entirely on NumPy + SciPy.

---

### Installation (placeholder)

```bash
pip install numai
```

License

MIT © liujunyi

```
