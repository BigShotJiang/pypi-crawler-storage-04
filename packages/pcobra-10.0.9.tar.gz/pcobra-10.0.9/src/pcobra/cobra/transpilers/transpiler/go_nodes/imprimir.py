def visit_imprimir(self, nodo):
    valor = self.obtener_valor(nodo.expresion)
    self.agregar_import("fmt")
    self.agregar_linea(f"fmt.Println({valor})")

