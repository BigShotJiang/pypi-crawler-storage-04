"""
Sources
"""

NAME = "Preprocessors"

DESCRIPTION = "Preprocessors."

BACKGROUND = "#b9d47a"

ICON = "icons/ingranaggio.png"

PRIORITY = 1007