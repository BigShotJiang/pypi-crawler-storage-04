"""
Sources
"""

NAME = "Sources"

DESCRIPTION = "Sources."

BACKGROUND = "#b9d47a"

ICON = "icons/source.png"

PRIORITY = 1001
