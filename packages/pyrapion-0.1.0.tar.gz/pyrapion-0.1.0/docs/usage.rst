=====
Usage
=====

To use Python Package for Restful API Interaction in a project::

    import pyrapion
