==========================================
Python Package for Restful API interactiON
==========================================

Python package for helping restful api interaction

Features
--------

* TODO
* add list download for energis query

Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
