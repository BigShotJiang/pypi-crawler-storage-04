"""Top-level package for Python Package for Restful API Interaction."""

__author__ = """Long Lê"""
__email__ = 'long.le-van@outlook.com'
__version__ = '0.1.0'
