pygram11.histogram2d
^^^^^^^^^^^^^^^^^^^^

.. autofunction:: pygram11.histogram2d
