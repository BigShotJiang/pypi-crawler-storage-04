pygram11.var1d
^^^^^^^^^^^^^^

.. autofunction:: pygram11.var1d
