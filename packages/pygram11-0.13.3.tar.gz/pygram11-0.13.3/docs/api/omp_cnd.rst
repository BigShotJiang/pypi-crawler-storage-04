Decorators and Context Managers
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. autofunction:: pygram11.omp_disabled
.. autofunction:: pygram11.omp_forced
.. autofunction:: pygram11.without_omp
.. autofunction:: pygram11.with_omp
