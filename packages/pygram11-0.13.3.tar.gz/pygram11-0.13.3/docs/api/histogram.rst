pygram11.histogram
^^^^^^^^^^^^^^^^^^

.. autofunction:: pygram11.histogram
