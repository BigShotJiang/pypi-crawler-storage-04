pygram11.fix1dmw
^^^^^^^^^^^^^^^^

.. autofunction:: pygram11.fix1dmw
