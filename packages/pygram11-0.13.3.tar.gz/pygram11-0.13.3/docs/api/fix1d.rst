pygram11.fix1d
^^^^^^^^^^^^^^

.. autofunction:: pygram11.fix1d
