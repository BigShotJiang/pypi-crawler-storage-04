pygram11.var2d
^^^^^^^^^^^^^^

.. autofunction:: pygram11.var2d
