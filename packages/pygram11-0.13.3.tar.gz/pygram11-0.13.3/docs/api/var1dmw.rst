pygram11.var1dmw
^^^^^^^^^^^^^^^^

.. autofunction:: pygram11.var1dmw
