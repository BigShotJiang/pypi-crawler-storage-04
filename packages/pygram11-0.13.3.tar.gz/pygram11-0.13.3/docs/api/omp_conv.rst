Convenience Functions
^^^^^^^^^^^^^^^^^^^^^

.. autofunction:: pygram11.default_omp
.. autofunction:: pygram11.disable_omp
.. autofunction:: pygram11.force_omp
