pygram11.bin_centers
^^^^^^^^^^^^^^^^^^^^

.. autofunction:: pygram11.bin_centers
