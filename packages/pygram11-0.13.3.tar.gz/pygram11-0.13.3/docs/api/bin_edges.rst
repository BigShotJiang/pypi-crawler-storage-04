pygram11.bin_edges
^^^^^^^^^^^^^^^^^^

.. autofunction:: pygram11.bin_edges
