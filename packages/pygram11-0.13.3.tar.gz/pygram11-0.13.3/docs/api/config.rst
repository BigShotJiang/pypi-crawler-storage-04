Granular Configuration
^^^^^^^^^^^^^^^^^^^^^^

.. autofunction:: pygram11.config.get
.. autofunction:: pygram11.config.set
