# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]
## [16.0.1.0.2] - 2025-09-03
### Added
- [#1583](https://git.coopdevs.org/coopdevs/som-connexio/odoo-somconnexio/-/merge_requests/1583) add source param o crm-lead and create lead wizard

## [16.0.1.0.1] - 2025-08-26
### Fixed
- [#1569](https://git.coopdevs.org/coopdevs/som-connexio/odoo-somconnexio/-/merge_requests/1569) Fix mail compose _onchange_template_id
