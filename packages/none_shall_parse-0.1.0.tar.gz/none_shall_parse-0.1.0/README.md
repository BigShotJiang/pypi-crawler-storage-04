# none_shall_parse

Trinity Shared Python utilities.

## Installation

Using `uv`:

```bash
uv add git+https://bitbucket.org/trintel/py_tsu/src/v0.1.0/
```

Using `pip` with `uv`:

```bash
uv pip install git+https://bitbucket.org/trintel/py_tsu/src/v0.1.0/
```

Using `pip`:

```bash
pip install git+https://bitbucket.org/trintel/py_tsu/src/v0.1.0/
```
