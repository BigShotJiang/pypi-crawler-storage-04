"""Entry point for the package."""
from faster_whisper_hotkey.transcribe import main

if __name__ == "__main__":
    main()