# sstools - Swimstats Tools
sstools - Swimstats Tools
0.2.9
- Fix season 2024 FINA SCM

0.2.8
- Add season 2025 FINA SCM

0.2.7
- Trunc FINA calculation
- Add Rudolph-Punkttabelle 2025

0.2.6
- Fix available styles
- Add season 2025 FINA LCM

0.2.5
- Add season 2024 FINA SCM

0.2.4
- Add season 2024 FINA LCM

0.2.3
- Add season 2024 Rudolph

0.2.2
- Fix season 2022 Rudolph

0.2.1
- Add season 2023 (FINA and Rudolph)

0.2.0
- FINA base table derived from swimrankings

0.1.8
- round base times

0.1.7
- Add Fina 2022 SCM base times

0.1.6
- Add Fina 2022 LCM base times






