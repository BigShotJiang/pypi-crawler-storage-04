Contributing
============
Thank you for your interest in contributing. As in most open source projects,
contributions are very welcome.

Reporting issues
----------------
Bugs and questions are reported as issues on the github repository. 
If applicable, try to include a self-contained code example. Also test the latest version
(i.e. the "master" branch) in case the issue has already been fixed.

Contributing code
-----------------
In case this is your first contribution to a project hosted on github you may be helped by
this excellent documentation:

- https://help.github.com/categories/collaborating-with-issues-and-pull-requests/

You will submit your suggested changes (e.g. new feature/bugfix/documentation/typo-fix)
as a pull request. The new version of the code is automatically tested in isolation on
CI servers (remember to add your own tests in case you add new functionality). In addition
to the automatic tests, the code will be reviewed with respect to documentation & clarity
(docstrings follow the `numpy convention <https://github.com/numpy/numpy/blob/master/doc/HOWTO_DOCUMENT.rst.txt>`_).
This project uses `black <https://github.com/psf/black>`_ to format its source code, it
ensures that style is consistent and alleviates some of the work associated with code review.

If you want to contribute a major feature you may want to discuss this first by opening
an issue (in order to avoid unnecessary work in case someone else is already working on
something related).
