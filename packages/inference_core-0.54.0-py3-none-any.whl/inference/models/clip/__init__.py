from inference.models.clip.clip_model import Clip
