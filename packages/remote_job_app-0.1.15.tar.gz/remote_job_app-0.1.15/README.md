# Remote Job API

Provides a best-practices approach to help quickly integrate existing remote services with the Strangeworks platform.
