# LlamaIndex Python Client

This client is auto-generated using [Fern](https://buildwithfern.com/docs/intro)

## Setup

Before testing or releasing, ensure you have the development environment set up:

```bash
# Install Poetry (if not already installed)
curl -sSL https://install.python-poetry.org | python3 -

# Install project dependencies
poetry install

# Verify setup
poetry --version
python --version
```

## Quick Start

```bash
# Set up development environment (first time only)
make setup

# See all available commands
make help

# Test before releasing
make test

# Complete release workflow  
make release
```

## Commands

| Command | Description |
|---------|-------------|
| `make setup` | Set up development environment (first time only) |
| `make help` | Show all available commands |
| `make build` | Build the package |
| `make test` | Build, install locally, and run comprehensive tests |
| `make publish` | Test and publish to PyPI (with confirmation) |
| `make release` | Complete release workflow (clean → build → test → publish) |
| `make clean` | Clean build artifacts |
| `make setup-credentials` | Set up PyPI credentials (one-time setup) |

## Release Process

**First time setup:**
```bash
make setup  # Set up development environment
```

**For each release:**
1. **Update version** in `pyproject.toml`
2. **Run release workflow:**
   ```bash
   make release
   ```

That's it! The Makefile handles building, testing, and publishing with safety checks.

## Manual Steps (if needed)

<details>
<summary>Expand for manual commands</summary>

**Build and test manually:**
```bash
poetry build
pip install --force-reinstall dist/llama_cloud-*-py3-none-any.whl
python test_local_build.py
```

**Setup credentials manually:**
```bash
poetry config pypi-token.pypi <your-token>
```
Get token from [1Password](https://start.1password.com/open/i?a=32SA66TZ3JCRXOCMASLSDCT5TI&v=lhv7hvb5o46cwo257c3hviqkle&i=yvslwei7jtf6tgqamzcdantqi4&h=llamaindex.1password.com)

</details>
