"""
Core module for AstroInsight
"""
