# Copyright 2025 Marimo. All rights reserved.
DEFAULT_MAX_TOKENS = 4096
DEFAULT_MODEL = "openai/gpt-4o"
