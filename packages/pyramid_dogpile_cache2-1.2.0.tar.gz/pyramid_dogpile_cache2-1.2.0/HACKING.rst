=====================================
Developing pyramid_dogpile_cache2
=====================================

:Author:
    `Die ZEIT Engineering Online <zon-backend@zeit.de>`_

:PyPI page:
    https://pypi.org/project/pyramid-dogpile-cache2/

:Issues:
    `report by e-mail <zon-backend@zeit.de>`_

:Source code:
    https://github.com/zeitonline/pyramid_dogpile_cache2

:Current change log:
    https://github.com/zeitonline/pyramid_dogpile_cache2/blob/main/CHANGES.txt
