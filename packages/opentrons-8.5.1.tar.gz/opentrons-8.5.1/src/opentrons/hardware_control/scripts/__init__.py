"""Scripts for the hardware controller."""
