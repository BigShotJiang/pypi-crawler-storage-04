"""Protocol engine state module."""
