VERSION = (0, 14, 0)


__version__ = ".".join(map(str, VERSION))
