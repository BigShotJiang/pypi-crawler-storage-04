class GobletError(Exception):
    pass


class GobletValidationError(Exception):
    pass


class GobletRouteNotFoundError(Exception):
    pass
