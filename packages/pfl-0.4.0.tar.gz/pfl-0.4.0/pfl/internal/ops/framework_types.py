# Copyright © 2023-2024 Apple Inc.
from enum import Enum


class MLFramework(Enum):
    NUMPY = 'numpy'
    TENSORFLOW = 'tensorflow'
    PYTORCH = 'pytorch'
    MLX = 'mlx'
