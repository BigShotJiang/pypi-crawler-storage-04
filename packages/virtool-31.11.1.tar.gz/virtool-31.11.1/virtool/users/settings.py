"""Default user settings."""

DEFAULT_USER_SETTINGS = {
    "skip_quick_analyze_dialog": True,
    "show_ids": True,
    "show_versions": True,
    "quick_analyze_workflow": "pathoscope_bowtie",
}
