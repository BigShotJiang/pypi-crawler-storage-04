"""
The ML module contains functionality for downloading and managing models
used for machine learning-based virus detection.
"""
