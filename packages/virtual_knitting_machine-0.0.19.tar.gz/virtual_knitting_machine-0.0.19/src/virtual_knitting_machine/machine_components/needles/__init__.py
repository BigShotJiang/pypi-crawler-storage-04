"""This package contains classes for different needle types in the knitting machine."""
