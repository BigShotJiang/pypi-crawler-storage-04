# Voice Processor

A Python package for voice recognition and text-to-speech conversion.