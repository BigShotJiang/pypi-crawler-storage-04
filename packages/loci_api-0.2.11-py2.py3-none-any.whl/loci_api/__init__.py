__version__ = "0.2.5"
__credits__ = 'AuroraLabs'