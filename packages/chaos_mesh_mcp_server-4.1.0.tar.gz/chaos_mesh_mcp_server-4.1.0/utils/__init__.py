"""Utility module"""
