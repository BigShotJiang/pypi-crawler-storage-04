# Copyright (C) 2022-2023 initOS GmbH
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

from lxml import etree

from odoo.exceptions import UserError

from odoo.addons.base.tests.common import BaseCommon


class TestGenerator(BaseCommon):
    def test_xml_generator(self):
        """Only test failing because other cases or covered in full tests"""
        root = etree.fromstring("<invalid/>")
        with self.assertRaises(UserError):
            self.env["datev.xml.generator"].check_xml_file("inv.xml", root)
