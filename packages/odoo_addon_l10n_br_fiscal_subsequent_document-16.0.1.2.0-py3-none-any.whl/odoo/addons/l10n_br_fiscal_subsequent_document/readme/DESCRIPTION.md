Conceito de operações subsequentes e documentos fiscais subsequentes.
