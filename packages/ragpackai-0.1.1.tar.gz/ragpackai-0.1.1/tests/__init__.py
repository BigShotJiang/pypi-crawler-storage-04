"""
Test suite for ragpackai.

This module contains tests for all ragpackai functionality including
core features, provider integrations, encryption, and error handling.
"""
