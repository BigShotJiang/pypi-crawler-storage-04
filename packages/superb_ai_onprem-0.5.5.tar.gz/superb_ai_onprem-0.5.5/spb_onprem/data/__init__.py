from .service import DataService


__all__ = (
    "DataService",
)
