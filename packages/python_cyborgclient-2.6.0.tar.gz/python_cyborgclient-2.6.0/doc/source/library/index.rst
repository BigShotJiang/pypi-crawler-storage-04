========
Usage
========

To use python-cyborgclient in a project::

    import cyborgclient
