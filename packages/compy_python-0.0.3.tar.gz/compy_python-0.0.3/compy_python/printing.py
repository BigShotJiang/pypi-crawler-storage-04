def print_address[T](_type: T):
    print(hex(id(_type)))
