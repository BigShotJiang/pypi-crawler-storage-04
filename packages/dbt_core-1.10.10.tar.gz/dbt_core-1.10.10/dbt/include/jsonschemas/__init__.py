import os

JSONSCHEMAS_PATH = os.path.dirname(__file__)
