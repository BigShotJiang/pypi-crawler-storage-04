__all__ = ["MakoExceptionInfo"]

from django_mako.template.backend.debugging.mako_exception_info import (
    MakoExceptionInfo,
)
