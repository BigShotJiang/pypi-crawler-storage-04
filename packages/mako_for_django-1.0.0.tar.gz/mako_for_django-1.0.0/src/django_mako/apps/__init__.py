__all__ = ["DjangoMakoConfig"]

from django_mako.apps.django_mako_config import DjangoMakoConfig
