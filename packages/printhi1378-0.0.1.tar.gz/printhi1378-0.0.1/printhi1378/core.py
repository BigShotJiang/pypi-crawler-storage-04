# chrxzrbx.py
def printhi():
    print("Hi")
