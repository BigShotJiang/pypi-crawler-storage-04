from setuptools import setup, find_packages

setup(
    name="printhi1378",  # this is what ppl type in pip
    version="0.0.1",
    packages=find_packages(),
    install_requires=[],  # if u have other libs u use
    description="Prints hi!",
    author="chrxzrbx",
    url="https://www.google.com",  # optional
)
