# MindTools
Outils et librairies communes aux applications MIND

# Installation
```pip install -e .```

# Mise à jour wheel
Pour mettre à jour le .whl (Utilisé par le conteneur backend IAAR)

Il faut aller dans les Action et lancer "Build and Upload Wheel" sur la branche "main"

# Setup du linter
Installer les extensions `Python`, `Black Formatter` et `Flake8` sur VSCode.