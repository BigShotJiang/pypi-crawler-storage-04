import json


def read_json(path):
    with open(path, "r", encoding="utf-8") as file:
        content = file.read()
        if content.startswith("```json"):
            content = content[len("```json") :].strip()  # noqa: E203
        if content.endswith("```"):
            content = content[: -len("```")].strip()
        data = json.loads(content)
    return data


def read_md(path):
    with open(path, "r", encoding="utf-8") as file:
        content = file.read()
    return content


def get_batches(list_elements, batch_size):
    n_elements = len(list_elements)
    n_batches = n_elements // batch_size + int(n_elements % batch_size != 0)
    list_batches = []
    for i in range(n_batches):
        list_batches.append(list_elements[i * batch_size : min((i + 1) * batch_size, n_elements)])  # noqa: E203
    return list_batches
