import base64
import httpx
import io
import json
import os
import requests
from typing import List, Optional, Union

from markitdown import MarkItDown
from pydantic import BaseModel
from agno.agent import Agent
from agno.media import Image
from agno.models.openai import OpenAIResponses, OpenAIChat
from agno.tools.jina import JinaReaderTools
from agno.tools.googlesearch import GoogleSearchTools

DICT_MODELS = {
    "gpt-4o": OpenAIResponses,
    "gpt-4.1": OpenAIResponses,
    "gpt-4.1-2025-04-14@sncf": OpenAIChat,
    "gpt-4.1@sncf": OpenAIChat,
    "gemini-2.5-flash@sncf": OpenAIChat,
    "gpt-4.1-mini": OpenAIResponses,
    "gpt-4.1-nano": OpenAIResponses,
    "gpt-5": OpenAIResponses,
    "gpt-5-mini": OpenAIResponses,
    "gpt-5-nano": OpenAIResponses,
}
URL_VALIDATION_MODEL = OpenAIChat(
    id="gpt-4.1"
)  # JinaReader semble se lancer plus facilement avec l'API Chat d'OpenAI (par rapport à Responses)


# --- Add custom exceptions with error codes and attributes ---
class LLMError(Exception):
    code = 1000  # Default error code for LLM errors

    def __init__(self, message, code=None, details=None):
        super().__init__(message)
        self.message = message
        self.code = code or self.code
        self.details = details

    def to_dict(self):
        return {
            "type": self.__class__.__name__,
            "message": self.message,
            "code": self.code,
            "details": self.details,
        }


class LLMAPIError(LLMError):
    code = 1001


class LLMValidationError(LLMError):
    code = 1002


class LLMRateLimitError(LLMError):
    code = 1003


class LLMAuthError(LLMError):
    code = 1004


class ModelNotFoundError(LLMError):
    code = 1005


def get_model(model_name: str):
    print(f"Using {model_name}")
    if model_name in DICT_MODELS.keys():
        if model_name[-5:] == "@sncf":
            model_id = model_name[:-5]
            return DICT_MODELS[model_name](
                id=model_id,
                api_key=os.getenv("SNCF_GPT_API_KEY"),
                base_url=os.getenv("SNCF_GPT_BASE_URL"),
                http_client=httpx.Client(verify=False),
            )
        else:
            return DICT_MODELS[model_name](id=model_name)
    else:
        if model_name[:3] == "gpt":
            try:
                return OpenAIResponses(id=model_name)
            except Exception:
                raise ModelNotFoundError(f"Model '{model_name}' not found.")
        raise ModelNotFoundError(f"Model '{model_name}' not found.")


def get_output(response, response_format):
    if response_format:
        output = response.content.model_dump()
    else:
        output = response.content
    return output


def get_output_string(response, response_format):
    if response_format:
        output = json.dumps(response.content.model_dump(), indent=2, ensure_ascii=False)
    else:
        output = response.content
    return output


class LLM:
    def __init__(
        self,
        model_name: str,
        temperature: Optional[float] = 0,
        max_tokens: Optional[int] = None,
        response_format: Optional[BaseModel] = None,
        enable_web_search: Optional[bool] = False,
    ):
        self.model_name = model_name
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.response_format = response_format
        self.enable_web_search = enable_web_search
        self.tools = []
        self.instructions = []
        if self.enable_web_search:
            self.tools += [
                GoogleSearchTools(),  # For finding URLs
            ]
            self.instructions += [
                "Cherche sur internet pour répondre.",
            ]
        self.agent = Agent(
            model=get_model(self.model_name),
            tools=self.tools,
            response_model=self.response_format,
            instructions=self.instructions,
            # debug_mode=True, # pour une raison inconnue, la présence de ce paramètre (quelle que soit sa valeur)
            # désactive l'utilisation du scrapper JinaReaderTools, et empêche la vérification de la validité des URL
            show_tool_calls=True,
        )

    def call(
        self,
        prompt: str,
        images: Optional[List[Union[str, bytes]]] = None,
        documents: Optional[List[Union[str, bytes]]] = None,
    ):
        try:
            list_image_data = []
            if images:
                for image in images:
                    if isinstance(image, str):
                        if image.startswith("data:image"):
                            base64_message = image.split(",")[1]
                        else:
                            base64_message = image
                        base64_bytes = base64_message.encode("utf-8")
                        try:
                            message_bytes = base64.b64decode(base64_bytes)
                        except Exception as e:
                            raise LLMValidationError(f"Invalid base64 image data: {e}")
                        list_image_data.append(Image(content=message_bytes))
                    elif isinstance(image, bytes):
                        list_image_data.append(Image(content=image))
                    else:
                        raise LLMValidationError("L'image doit être une chaîne en base64 ou un objet de type bytes.")

            # Extraction de texte à partir de fichiers
            md = MarkItDown(enable_plugins=False)  # Set to True to enable plugins
            list_document_text = []
            if documents:  # dict[name: str, type: str, base64: str]
                for dict_document in documents:
                    document = dict_document["base64"]
                    response = requests.Response()
                    if isinstance(document, str):
                        if document.startswith("data:"):
                            base64_message = document.split(",")[1]
                        else:
                            base64_message = document
                        base64_bytes = base64_message.encode("utf-8")
                        try:
                            message_bytes = base64.b64decode(base64_bytes)
                        except Exception as e:
                            raise LLMValidationError(f"Invalid base64 document data: {e}")
                        response.raw = io.BytesIO(message_bytes)
                        try:
                            document_text = md.convert(response).text_content
                        except Exception as e:
                            raise LLMValidationError(f"Failed to extract text from document: {e}")
                    elif isinstance(document, bytes):
                        response.raw = io.BytesIO(document)  # Pour passer des bytes à MarkItDown
                        try:
                            document_text = md.convert(response).text_content
                        except Exception as e:
                            raise LLMValidationError(f"Failed to extract text from document: {e}")
                    else:
                        raise LLMValidationError("Le document doit être une chaîne base64 ou des bytes.")
                    list_document_text.append(document_text)
                prompt = prompt + "\n\n# Documents de référence\n\n" + "\n\n".join(list_document_text)

            try:
                response = self.agent.run(prompt, images=list_image_data)
            except Exception as e:
                # Could be network, API, or rate limit error
                # Try to detect rate limit from error message
                msg = str(e)
                if "rate limit" in msg.lower() or "429" in msg:
                    raise LLMRateLimitError(f"Rate limit error: {msg}")
                raise LLMAPIError(f"Error during LLM API call: {msg}")

            if self.enable_web_search:
                # Validation step
                try:
                    validator = Agent(
                        model=URL_VALIDATION_MODEL,
                        tools=[JinaReaderTools(search_query=False, read_url=True)],
                        response_model=self.response_format,
                        instructions=[
                            "Tu dois lire le contenu de chaque URL fournie pour vérifier que la page est accessible et \
                                valide (pas d'erreur 404, pas de login demandé, etc) en utilisant le tool read_url.",
                            "Si une URL est invalide, supprime-la de la réponse (par exemple, si elle fait partie \
                                d'une liste, supprime l'élément dans la liste). Sinon laisse-la inchangée.",
                            "Le reste du contenu de l'input doit resté inchangé.",
                        ],
                        show_tool_calls=True,
                    )
                    response = validator.run(get_output_string(response, self.response_format))
                except Exception as e:
                    raise LLMValidationError(f"Error during validation: {e}")

            output = get_output(response, self.response_format)
            return output
        except LLMError as e:
            raise e  # propagate known errors
        except Exception as e:
            raise LLMError(f"Unexpected error in LLM.call: {e}")
