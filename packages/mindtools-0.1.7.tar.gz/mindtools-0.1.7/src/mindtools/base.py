import random
import time
from typing import Any, Callable, Dict, Optional, Self, Type, TypeVar, Union
from fastapi import Body, FastAPI
from pydantic import BaseModel, model_validator
from jinja2 import Template
from genai_cyberlift.utils import tools
from copy import copy
from genai_cyberlift.utils.models import (
    LLM,
    LLMError,
)


class Data(dict):
    def store(self, new_data: dict):
        for k, v in new_data.items():
            self[k] = v


_BM = TypeVar("_BM", bound=BaseModel)
_DictOrPydanticClass = Union[Dict[str, Any], Type[_BM], Type]  # Type générique pour les response_format


class Step(BaseModel):
    name: str
    prompt_template: Template
    response_format: Optional[_DictOrPydanticClass] = None
    additional_data: Optional[object] = None
    pre_processing: Optional[Callable[[dict], dict]] = None
    post_processing: Callable[[list[dict]], list]
    batch_key: Optional[str] = None
    batch_size: Optional[int] = None
    enable_web_search: Optional[bool] = False

    @model_validator(mode="after")
    def validate_batch_fields(self) -> Self:
        # Condition : Si batch_key est spécifié, batch_size doit être spécifié
        if self.batch_key and self.batch_size is None:
            raise ValueError("batch_size is required when batch_key is specified")

        # Condition : Si batch_size est spécifié, batch_key doit être spécifié
        if self.batch_size and self.batch_key is None:
            raise ValueError("batch_key is required when batch_size is specified")
        return self

    class Config:
        arbitrary_types_allowed = True

    def run(self, model_name: str, input_data: object) -> object:
        try:
            print(self.name)
            data = Data(input_data)
            model = LLM(model_name, response_format=self.response_format, enable_web_search=self.enable_web_search)
            prompt_data = copy(input_data)
            if self.additional_data:
                for k, v in self.additional_data.items():
                    prompt_data[k] = v
            if not self.batch_key or not self.batch_size:
                if self.pre_processing:
                    pre_processed_prompt_data = self.pre_processing(prompt_data)
                else:
                    pre_processed_prompt_data = prompt_data
                list_prompts = [self.prompt_template.render(pre_processed_prompt_data)]
            else:
                list_batches = tools.get_batches(input_data[self.batch_key], self.batch_size)
                list_prompts = []
                for batch in list_batches:
                    prompt_data[self.batch_key] = copy(batch)
                    if self.pre_processing:
                        pre_processed_prompt_data = self.pre_processing(prompt_data)
                    else:
                        pre_processed_prompt_data = prompt_data
                    list_prompts.append(self.prompt_template.render(pre_processed_prompt_data))
            list_responses = []
            for i, prompt in enumerate(list_prompts):
                print(f"\tBatch {i + 1}/{len(list_prompts)}")
                print(prompt)
                if "images" in input_data.keys():
                    images = input_data.pop("images")
                else:
                    images = None
                if "documents" in input_data.keys():
                    documents = input_data.pop("documents")
                else:
                    documents = None
                response = model.call(prompt, images=images, documents=documents)
                list_responses.append(response)
            port_processed_response = self.post_processing(list_responses, input_data=input_data)
            data.store(port_processed_response)
            return data
        except LLMError as e:
            raise e
        except Exception as e:
            raise LLMError(f"Unexpected error in Step.run: {e}")

    def create_endpoint(
        self,
        app: FastAPI,
        endpoint_name: str,
        model_name: str,
        demo_data_path: str = None,
    ):
        if demo_data_path:

            async def endpoint(input_data: dict = Body(...)):
                try:
                    data = tools.read_json(demo_data_path)
                    time.sleep(random.uniform(5, 10))
                    return data
                except LLMError as e:
                    return e.to_dict(), 500
                except Exception as e:
                    return LLMError(f"Unexpected error in endpoint (demo): {e}").to_dict(), 500

        else:

            async def endpoint(input_data: dict = Body(...)):
                try:
                    return self.run(model_name, input_data)
                except LLMError as e:
                    return e.to_dict(), 500
                except Exception as e:
                    return LLMError(f"Unexpected error in endpoint: {e}").to_dict(), 500

        return app.post(endpoint_name)(endpoint)  # decorator @app.post(endpoint_name)
