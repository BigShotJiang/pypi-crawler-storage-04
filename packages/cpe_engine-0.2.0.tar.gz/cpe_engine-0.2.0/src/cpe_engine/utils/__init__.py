"""
Utility functions for CPE Engine.
"""