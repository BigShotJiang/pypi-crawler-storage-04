from django.apps import (
    AppConfig,
)


class M3DBUtilsConfig(AppConfig):
    """Конфигурация приложения m3_db_utils."""

    name = label = 'm3_db_utils'
    verbose_name = 'Утилиты для работы с БД'
