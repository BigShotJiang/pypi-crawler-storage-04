KEY_FIELD_NAME = 'key'
ORDER_NUMBER_FIELD_NAME = 'order_number'

ATTRIBUTE_NOT_FOUND = 'attribute not found'

DEFAULT_ORDER_NUMBER = 100_000

LOG_QUERY = 'log_query'
UNNAMED = 'unnamed'

LOOKUP_SEP = '__'

ID = 'id'
PK = 'pk'
