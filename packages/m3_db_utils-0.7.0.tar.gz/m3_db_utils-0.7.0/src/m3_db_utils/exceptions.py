class RequiredFieldEmptyModelEnumValueError(RuntimeError):
    """Возникает при установленном пустом (None) значении или его отсутствия у поля значения модели-перечисления."""
