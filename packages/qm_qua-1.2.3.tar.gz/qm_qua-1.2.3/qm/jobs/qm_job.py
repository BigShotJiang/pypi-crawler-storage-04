from qm.jobs.running_qm_job import RunningQmJob


class QmJob(RunningQmJob):
    pass
