from qm.program.program import Program  # noqa
from qm.program._qua_config_schema import load_config  # noqa

_Program = Program

__all__ = ["Program", "load_config"]
