"""Tests for the geometry module."""
