# sage_setup: distribution = sagemath-pari
