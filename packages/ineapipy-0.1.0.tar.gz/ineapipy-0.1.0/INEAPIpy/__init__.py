# Set shebang if needed
# -*- coding: utf-8 -*-
"""
Created on Tue Jul 15 19:46:52 2025

@author: mano
"""
