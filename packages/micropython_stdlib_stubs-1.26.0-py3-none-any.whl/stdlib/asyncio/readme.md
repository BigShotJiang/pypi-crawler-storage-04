# micropython-stdlib asyncio

This is a hand edited version of the [asyncio](https://docs.python.org/3/library/asyncio.html) library for MicroPython.
It is a subset of the original library, and is not a complete implementation. It is intended to be used with MicroPython.

It is packaged as part of the `micropython-stdlib-stubs` type-stub package.

