"""tkGUI View helpers"""
