9.0.0
-----

August 29, 2025

Revise for 9.0.0 Mathics3 Kernel API

Supports Python 3.13. Dropped support for Python 3.8 and Python 3.9


1.0.0
-----

July 27, 2025

Initial version
