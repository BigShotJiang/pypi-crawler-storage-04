# Instructions on generating new test data
1. Make sure you are in the `suite2p/scripts` directory instead of `suite2p/tests` where this `instructions.md` file is located. Run `python generate_test_data.py`. 
2. All the generated test data will be placed in the directory 
`suite2p/scripts/test_data`. These directories will correspond to the expected outputs for our tests.
