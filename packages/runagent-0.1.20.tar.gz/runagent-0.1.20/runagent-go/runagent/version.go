package runagent

// Version represents the current version of the RunAgent Go SDK
const Version = "0.1.20"
