[](){#CopickRoot}
::: copick.models.CopickRoot
