[](){#CopickPicksFile}
::: copick.models.CopickPicksFile
    options:
        show_if_no_docstring: true

****

::: copick.models.CopickPoint
    options:
        show_if_no_docstring: true

****

::: copick.models.CopickLocation
    options:
        show_if_no_docstring: true
