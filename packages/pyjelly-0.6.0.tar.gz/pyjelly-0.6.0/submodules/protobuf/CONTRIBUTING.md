# Contributing

**Please see the [contribution guide on the Jelly website](https://w3id.org/jelly/dev/contributing/).** Thanks!
