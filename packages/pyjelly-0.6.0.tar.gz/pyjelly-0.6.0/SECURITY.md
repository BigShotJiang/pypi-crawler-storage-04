# Security policy

## Reporting a vulnerability

If you find a security issue or vulnerability, please **do not** open a public issue. Instead, **[use the dedicated vulnerability reporting page](https://github.com/Jelly-RDF/pyjelly/security/advisories/new)**.

We will get back to you as soon as possible.
