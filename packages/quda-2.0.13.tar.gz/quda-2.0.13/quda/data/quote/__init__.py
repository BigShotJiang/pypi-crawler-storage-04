# -*- coding: utf-8 -*-
"""
---------------------------------------------
Copyright (c) 2025 ZhangYundi
Licensed under the MIT License. 
Created on 2025/7/9 15:40
Email: yundi.xxii@outlook.com
Description: 
---------------------------------------------
"""

from .tick_clean import save_ytick