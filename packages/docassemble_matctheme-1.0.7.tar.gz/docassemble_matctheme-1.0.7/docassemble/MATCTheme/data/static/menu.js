$(document).on('daPageLoad', function() {
  let label = val('navbar_dropdown_menu_label');
  $('.navbar-nav .dropdown-toggle').text('Menu');
});