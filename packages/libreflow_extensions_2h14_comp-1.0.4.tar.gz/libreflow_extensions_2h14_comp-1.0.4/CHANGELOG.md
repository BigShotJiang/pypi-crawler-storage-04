# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html)[^1].

<!---
Types of changes

- Added for new features.
- Changed for changes in existing functionality.
- Deprecated for soon-to-be removed features.
- Removed for now removed features.
- Fixed for any bug fixes.
- Security in case of vulnerabilities.

-->

## [Unreleased]

## [1.0.4] - 2025-09-04

### Changed

* After Effects Scene Builder action
    * Handle new organization from template file
    * The automation is now processed in the background since the look preset is no longer used

### Removed

* `.ffx` look preset is now baked into the template file within the pipe

## [1.0.3] - 2025-08-07

### Added

* A job type for the action to build an After Effects scene.
* An action to update dependencies in a After Effects scene.
* An action that sends jobs for TVPaint export layers and/or build after effects scene to a pool.
    * `libreflow.extensions.runner.tvpaint_playblast` module is required in order to work.
* An action that exports camera data from a blender file for import into After Effects.

### Changed

* After Effects Scene Builder action
    * Handle `tracking_camera.jsx` file for tracking shots
    * Make `layers` folder optional for non-animated shots

## [1.0.2.1] - 2025-06-13

### Fixed

* The package build did not include the `.js` files.

## [1.0.2] - 2025-06-12

### Added

* An action to build an After Effects scene.
    * It creates an `.aep` file and imports the necessary dependencies for compositing, including the animatic, the Photoshop background and the TVPaint layers.
    * To use an `.ffx` look preset, this automation shows the software interface in a new instance.

## [1.0.1] - 2025-05-28

### Added

* An After Effects playblast action dedicated to compositing, with Preview and Final render parameters:
    - Preview : classic playblast with image marking
    - Final : playblast without marking


## [1.0.0] - 2025-05-02

### Added

* initial release
