# kind

`kind` is a generic constructor that produces kinds from a variety
of inputs. This includes other kinds, strings in the s-expression
format (see below), FRPs, or the strings 'empty' or 'void' for the
empty kind,

If you pass an FRP to this function, be sure that its kind has
been computed or is not too large, as `kind` will attempt to
compute it. (You can see this by printing the value of the FRP.)

The string format for kinds is specified by a non-empty, ()-balanced
expression, where the outer layer of parentheses encompasses the
entire specification. Within each () pair, the string looks like
```
 (<_node_> _weight_1 _value_or_subtree_1 ...)
```
here `<_node_>` has explicit angle brackets to distinguish the
tuple values from the numeric weights. It is a comma-separated
list of numbers which can be empty. The root node of the
tree is always an empty <>.

Each `_value_or_subtree_k` is a node in angle brackets indicating
a leaf and giving the value at that leaf or it is another
()-balaced expression of the same form as just described.

As described in the chapter, the values within each subtree must be
distinct, and the nodes on any path from root to leaf must be
*consistent* in the sense that earlier nodes' numeric lists are
prefixes of later nodes' lists on that path. All leaf nodes must
also have the same dimension, and all weights must be positive.

Weights can be floating point numbers like 1.0 or 1e-7
or rational numbers like 1/7 with no space between the numbers and the /.

So,
```
    (<> 1 (<1> 2 <1, 2> 3 <1, 6>) 2 (<10> 1 <10, 20>))
is valid. Within each (), the nodes are disinct and
```
along one path we get consistent sequences `<>`, `<1>`, `<1,2>` or `<1,6>`
and on the other `<>`, `<10>`, `<10, 20>`.
But 
```
    (<> 1 (<1> 2 <1, 2> 3 <1, 2>) 2 (<10> 1 <10, 20>))
    (<> 1 (<1> 2 <1, 2> 3 <5, 6>) 2 (<10> 1 <10, 20>))
    (<> 1 (<1> 2 <1, 2> 3 <5, 6>) 2 (<10> 1 <10, 20, 30>))
```
are invalid. The first has two equal nodes `<1, 2>` in the
same subtree. The second has an inconsistent path `<>`, `<1>`,
`<5, 6>`. And the third has leaf nodes of different dimensions.

Examples:

```
   (<>)
   (<> 1 <2> 1 <3>)
   (<> 1 (<1> 1 <1, 100> 100 <1, 1>) (<4> 1/2 <4, -1> 0.01 <4, -10>) (<5> 100 <-1, -1>))
   (<> 1 (<1> 2 <1, 3> 4 <1, 5>) (<6> 7 <6, 8> 9 <6, 10>))
```
