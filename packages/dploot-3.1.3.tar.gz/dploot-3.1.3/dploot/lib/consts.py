# Define some dploot consts.

FALSE_POSITIVES = [
    ".",
    "..",
    "desktop.ini",
    "Public",
    "Default",
    "Default User",
    "All Users",
]
