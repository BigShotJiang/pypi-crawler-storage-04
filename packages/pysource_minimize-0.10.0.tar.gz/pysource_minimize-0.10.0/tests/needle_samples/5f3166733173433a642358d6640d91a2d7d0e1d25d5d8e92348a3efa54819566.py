def name_5(name_4: needle_17597, /):
    pass