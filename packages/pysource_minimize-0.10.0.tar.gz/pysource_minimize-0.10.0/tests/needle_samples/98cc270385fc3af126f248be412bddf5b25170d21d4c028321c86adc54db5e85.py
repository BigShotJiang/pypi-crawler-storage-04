
assert name_2, needle_17597
