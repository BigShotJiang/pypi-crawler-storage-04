try:
    needle_17597
except* {name_3 for name_2 in name_3 if name_3}:
    pass