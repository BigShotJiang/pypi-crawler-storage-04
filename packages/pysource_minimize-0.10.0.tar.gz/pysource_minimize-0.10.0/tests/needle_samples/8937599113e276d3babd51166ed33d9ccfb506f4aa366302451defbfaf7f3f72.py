def name_3():
    return needle_17597