

async def name_0(*, name_1=name_4[name_3]):
    needle_17597: name_1 = {name_0 async for name_4 in name_2}
