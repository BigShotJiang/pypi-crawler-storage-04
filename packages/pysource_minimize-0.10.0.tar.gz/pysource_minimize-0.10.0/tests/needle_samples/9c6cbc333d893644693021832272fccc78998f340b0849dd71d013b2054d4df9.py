try:
    pass
except needle_17597:
    pass