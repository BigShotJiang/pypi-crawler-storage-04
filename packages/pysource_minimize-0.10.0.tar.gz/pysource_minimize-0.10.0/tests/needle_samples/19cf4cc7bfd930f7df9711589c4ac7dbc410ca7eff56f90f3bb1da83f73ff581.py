try:
    pass
finally:
    needle_17597