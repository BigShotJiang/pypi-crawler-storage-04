try:
    pass
except* name_1:
    pass
else:
    needle_17597