match name_2:
    case name_1.name_5:
        needle_17597