
(name_2 if name_1 else name_3)
