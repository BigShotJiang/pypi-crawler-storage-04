
(name_3 is name_1)
