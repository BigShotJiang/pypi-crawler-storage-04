
(lambda name_5=name_3, name_0=name_4, /, name_1=name_2, *, name_3=name_1, name_2=name_3: (name_2 - name_3))
