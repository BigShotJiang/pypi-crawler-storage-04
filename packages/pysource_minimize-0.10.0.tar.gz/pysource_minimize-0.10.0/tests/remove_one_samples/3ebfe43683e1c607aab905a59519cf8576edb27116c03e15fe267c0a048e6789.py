async def name_3(): # type: ignore
    async for name_5 in name_0: # type: ignore
        pass
    else:
        pass