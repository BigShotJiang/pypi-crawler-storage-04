

def name_3(*, name_0: (lambda name_1, /, name_0=name_2, *, name_3=name_0: name_2)=name_4[name_0]):
    pass
