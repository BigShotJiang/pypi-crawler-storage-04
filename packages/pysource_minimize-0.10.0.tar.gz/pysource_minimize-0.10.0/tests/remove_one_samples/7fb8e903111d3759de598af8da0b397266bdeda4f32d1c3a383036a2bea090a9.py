try:
    pass
except name_4 as name_2:
    pass
else:
    pass
finally:
    pass