match name_5:
    case name_4():
        name_5
    case name_1.name_3:
        name_4