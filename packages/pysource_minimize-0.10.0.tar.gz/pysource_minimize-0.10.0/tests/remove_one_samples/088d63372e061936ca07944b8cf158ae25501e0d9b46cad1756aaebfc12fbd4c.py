
(lambda name_3=name_1, *name_5, name_0=name_2: name_1)
