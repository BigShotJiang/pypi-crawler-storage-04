

async def name_2(*, name_1=(name_3 if name_0 else name_1)):
    pass
