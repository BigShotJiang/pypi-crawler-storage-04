try:
    pass
except:
    pass
else:
    name_5
finally:
    name_1