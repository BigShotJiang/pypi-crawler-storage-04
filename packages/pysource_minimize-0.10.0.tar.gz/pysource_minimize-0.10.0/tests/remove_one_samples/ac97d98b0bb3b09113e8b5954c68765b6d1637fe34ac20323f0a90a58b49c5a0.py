try:
    pass
except* lambda name_4, /, name_1=name_0, *name_5: name_4:
    pass
except* (name_2 for name_4 in name_4 if name_3):
    pass