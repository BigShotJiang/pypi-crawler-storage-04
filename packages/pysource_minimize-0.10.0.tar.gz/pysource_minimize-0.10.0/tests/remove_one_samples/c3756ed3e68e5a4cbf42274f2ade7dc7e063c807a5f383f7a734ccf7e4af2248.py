
(name_1 if name_5 else name_2)
