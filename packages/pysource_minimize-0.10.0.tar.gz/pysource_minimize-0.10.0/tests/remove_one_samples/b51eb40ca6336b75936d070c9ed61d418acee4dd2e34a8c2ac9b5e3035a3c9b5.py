try:
    pass
except name_2 if name_4 else name_2 as name_0:
    pass
except {name_3 for name_3 in name_0 if name_4} as name_1:
    pass