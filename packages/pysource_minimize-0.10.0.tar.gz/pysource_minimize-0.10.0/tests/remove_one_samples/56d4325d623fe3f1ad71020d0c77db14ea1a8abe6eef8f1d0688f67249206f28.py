
(lambda name_2, /, name_3=name_5, *name_5, **name_0: name_3)
