match '':
    case {False: b'}\\'}:
        pass