try:
    pass
except name_2 as name_4:
    pass
else:
    pass
finally:
    pass