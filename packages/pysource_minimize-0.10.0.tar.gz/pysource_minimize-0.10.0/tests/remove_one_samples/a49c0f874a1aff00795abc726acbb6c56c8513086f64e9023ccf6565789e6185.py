async def name_0() -> name_4: # type: ignore
    pass