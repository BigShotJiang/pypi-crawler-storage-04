try:
    pass
except name_3 as name_4:
    pass
else:
    pass
finally:
    pass