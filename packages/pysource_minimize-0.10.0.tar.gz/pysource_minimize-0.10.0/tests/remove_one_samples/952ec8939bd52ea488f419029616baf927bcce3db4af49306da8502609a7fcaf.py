

async def name_0() -> ():
    pass
