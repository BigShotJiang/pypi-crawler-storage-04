match name_0:
    case [-0]:
        pass