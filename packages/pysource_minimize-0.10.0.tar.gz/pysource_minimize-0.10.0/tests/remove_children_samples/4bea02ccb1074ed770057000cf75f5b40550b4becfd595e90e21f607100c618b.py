for 0[0] in 0:
    pass