match {}:
    case name_5(name_0=name_1.name_2):
        pass