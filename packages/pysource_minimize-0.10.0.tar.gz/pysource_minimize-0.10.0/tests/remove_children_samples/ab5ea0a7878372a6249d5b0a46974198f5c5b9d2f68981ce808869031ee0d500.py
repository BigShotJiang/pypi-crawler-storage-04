def name_5(name_4=name_3, name_0=name_1, /):
    pass