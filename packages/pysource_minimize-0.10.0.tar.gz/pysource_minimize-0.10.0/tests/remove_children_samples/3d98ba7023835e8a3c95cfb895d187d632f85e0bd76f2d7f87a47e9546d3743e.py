match name_2:
    case b'' | '':
        pass