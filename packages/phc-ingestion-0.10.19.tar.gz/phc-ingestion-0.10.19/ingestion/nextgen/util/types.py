from enum import Enum
