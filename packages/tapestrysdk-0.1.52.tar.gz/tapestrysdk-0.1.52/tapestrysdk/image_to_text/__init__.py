from .image_to_text import image_to_text

__all__ = ["image_to_text"]
