
from click.testing import CliRunner

def test_exec_command():
    assert True
