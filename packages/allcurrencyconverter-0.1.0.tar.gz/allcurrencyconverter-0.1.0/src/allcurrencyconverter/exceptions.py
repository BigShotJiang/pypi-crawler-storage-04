class NotCorrectArgumentError(ValueError):
    """While not correct argument"""

    pass


class LegacyLibError(SystemError):
    """If this lib is deprecated"""

    pass
