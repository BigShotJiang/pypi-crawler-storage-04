# Changesets

To add changeset run: 
    
```bash
npx changeset
```

in the root of the project. This will create a new changeset in the `.changeset` folder.