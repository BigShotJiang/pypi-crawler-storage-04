O modulo depende do:

- l10n_br_account_payment_order
- account_move_base_import
