from .basicxml import basicxml_test
from .configuration import configuration_test
from .proposition import proposition_test
from .lightmarkdown import lightmarkdown_test
from .jwt import jwt_test

class TestMain():
  
  def test():
    
    #configuration_test.test()
    #jwt_test.test()
    #proposition_test.test()
    #lightmarkdown_test.test()
    basicxml_test.test()
