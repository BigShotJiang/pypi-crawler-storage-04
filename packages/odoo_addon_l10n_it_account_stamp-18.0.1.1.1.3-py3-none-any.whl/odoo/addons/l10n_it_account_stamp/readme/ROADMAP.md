** Italiano **

Sono stati aggiunti gli script di migrazione, da provare quando saranno rilasciati quelli relativi ad `account`.

** English **

Migration scripts have been added, to be tested when `account` related ones will be released.
