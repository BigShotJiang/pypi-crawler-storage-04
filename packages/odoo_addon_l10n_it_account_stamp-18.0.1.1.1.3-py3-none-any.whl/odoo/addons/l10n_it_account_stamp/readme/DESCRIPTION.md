**Italiano**

Questo modulo aggiunge il supporto all'imposta di bollo italiana nelle
fatture e nelle ricevute.

**English**

This module adds Italian Stamp Duty support in invoices and receipts.
