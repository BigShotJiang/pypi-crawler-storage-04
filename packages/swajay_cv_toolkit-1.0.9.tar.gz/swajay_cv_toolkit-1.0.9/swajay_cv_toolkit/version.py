# =============================================================================
# 2. swajay_cv_toolkit/version.py
# =============================================================================

__version__ = "1.0.9"
__author__ = "Swajay"
__email__ = "swajaynandanwade04@gmail.com"  # Replace with your email
__license__ = "MIT"
__description__ = "Advanced Computer Vision Toolkit for Image Classification"