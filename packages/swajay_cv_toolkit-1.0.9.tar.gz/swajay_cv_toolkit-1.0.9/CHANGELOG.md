## [1.0.5] - 2025-26-08

### Changed
- Updated README.md with better examples
- Fixed typos in documentation
- Added more detailed installation instructions
- Fixed augmentations.py error
- Fixed incorrect email address
