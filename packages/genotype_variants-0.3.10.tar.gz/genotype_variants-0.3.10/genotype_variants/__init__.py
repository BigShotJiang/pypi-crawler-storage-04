"""Top-level package for genotype_variants."""

__author__ = """Ronak Shah"""
__email__ = "rons.shah@gmail.com"
__version__ = "0.3.10"
