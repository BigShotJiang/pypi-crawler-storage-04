This page is old. See:

[Run GAM on a Chromebook / Chrome OS](https://github.com/jay0lee/GAM/wiki/Chrome-OS-Installation)

[Run GAM on Android](https://github.com/jay0lee/GAM/wiki/Android-Installation)