---
name: Question about using GAM
about: Help with using GAM or running it for the first time
title: Please use the GAM discussion group
labels: invalid
assignees: ''

---

If you need help with GAM, please do not file an issue here, it will be closed and ignored.

Please post your question to the GAM discussion group where other admins are ready and willing to help:

https://groups.google.com/g/google-apps-manager
