from mindsdb_evaluator.accuracy import *  # noqa
from mindsdb_evaluator.calibration import *  # noqa

__version__ = '0.0.19'
name = "mindsdb_evaluator"

__all__ = ['name', '__version__']
