# mindsdb_evaluator

Model evaluation for Machine Learning pipelines.