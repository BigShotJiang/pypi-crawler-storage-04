---
sidebar_label: wallet
title: aixplain.v2.wallet
---

