"""Core utilities and protocols for the optr framework."""
