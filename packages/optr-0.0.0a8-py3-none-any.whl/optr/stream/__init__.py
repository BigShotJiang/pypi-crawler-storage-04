"""Stream utilities for video processing."""

from .clip import ClipRecorder

__all__ = ["ClipRecorder"]
