This module allows you to add alias to UoMs and search for them by name
or one of their alias. This is useful in some situations, for example,
when importing electronic invoices from suppliers, where a product may
be registered in Odoo with the UoM "Unit" but in the supplier invoice
the UoM is "UND".
