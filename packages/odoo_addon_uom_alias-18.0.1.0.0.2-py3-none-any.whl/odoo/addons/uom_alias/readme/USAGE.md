When you search for a UoM in a document, you can search by the name of
the UoM or by one of its alias.

.. image:: ../static/img/screenshot-2.png
