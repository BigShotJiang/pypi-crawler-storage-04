To configure an alias in a UoM, you can access Inventory \> Settings \>
UoM Categories. When editing a UoM you can add one or more alias in
column UoM Alias.

.. image:: ../static/img/screenshot-1.png
