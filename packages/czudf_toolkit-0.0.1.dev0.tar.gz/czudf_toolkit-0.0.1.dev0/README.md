# czudf-python-toolkit

Python toolkit for developing UDFs on the ClickZetta platform.

![License](https://img.shields.io/badge/License-Apache%202.0-blue.svg)
This project is released under the Apache License 2.0. See the [LICENSE](LICENSE) file for more details.
