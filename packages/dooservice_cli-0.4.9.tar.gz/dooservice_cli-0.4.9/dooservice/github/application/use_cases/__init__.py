"""GitHub use cases."""
