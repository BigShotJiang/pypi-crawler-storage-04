"""GitHub domain entities."""
