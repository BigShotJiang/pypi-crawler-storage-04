class InstanceNotInLockfileError(Exception):
    """Raised when an instance is not found in the lockfile."""
