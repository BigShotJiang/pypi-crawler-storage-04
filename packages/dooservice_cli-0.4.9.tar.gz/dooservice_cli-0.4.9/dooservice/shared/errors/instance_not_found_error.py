class InstanceNotFoundError(Exception):
    """Raised when an instance is not found in the configuration."""
