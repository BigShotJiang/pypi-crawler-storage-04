from __future__ import annotations

from typing import Optional

from sw_mc_lib.Component import INNER_TO_XML_RESULT, Component
from sw_mc_lib.NumberProperty import NumberProperty
from sw_mc_lib.Position import Position
from sw_mc_lib.Types import ComponentType
from sw_mc_lib.XMLParser import XMLParserElement


class PropertyNumber(Component):
    """
    Adds a custom number input that will be seen on the microcontroller's property panel when placed on a vehicle.
    """

    def __init__(
        self,
        component_id: int,
        position: Position,
        name: str = "number",
        value_property: Optional[NumberProperty] = None,
    ):
        super().__init__(ComponentType.PropertyNumber, component_id, position, 0.5)
        self.name: str = name
        self.value_property: NumberProperty = value_property or NumberProperty("0", "v")

    @staticmethod
    def from_xml(element: XMLParserElement) -> PropertyNumber:
        obj: XMLParserElement = element.children[0]
        component_id, position, _, properties = Component._basic_in_parsing(obj)
        name: str = obj.attributes.get("n", "number")
        return PropertyNumber(component_id, position, name, properties.get("v"))

    def _inner_to_xml(self) -> INNER_TO_XML_RESULT:
        children: list[XMLParserElement] = self._pos_in_to_xml(
            properties={"v": self.value_property}
        )
        return {}, children
