"""Builders for diverse Collection types."""
