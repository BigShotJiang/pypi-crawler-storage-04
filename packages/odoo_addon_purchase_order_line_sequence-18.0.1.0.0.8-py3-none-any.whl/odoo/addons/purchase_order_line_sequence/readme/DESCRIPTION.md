The sequence in PO line is propagated to the Stock moves. The sequence
number appears in the PO form view and in the report.
