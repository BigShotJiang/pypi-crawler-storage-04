from gyt_cli.constants import APP_CONFIG_PATH


def path() -> None:
    print(f"{APP_CONFIG_PATH}")
