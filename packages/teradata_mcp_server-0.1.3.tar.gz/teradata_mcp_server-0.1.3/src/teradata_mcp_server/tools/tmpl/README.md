# Template Tools

**Dependencies**

Assumes Teradata >=17.20.

**Template** tools:

- tmpl_nameFunction - description of tool


**Template** prompts:

- tmpl_promptName - description of prompt


[Return to Main README](../../../../README.md)
