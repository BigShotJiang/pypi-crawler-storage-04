# Template Tools

**Dependencies**

Assumes Teradata >=20.
assumes security

**Template** tools:

- tmpl_nameFunction - description of tool


**Template** prompts:

- tmpl_promptName - description of prompt


[Return to Main README](../../../../README.md)
