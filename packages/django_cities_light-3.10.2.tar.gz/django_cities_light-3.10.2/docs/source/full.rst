Simple django app
=================

Settings
--------

.. automodule:: cities_light.settings
   :members:

Models
------

See source for details.

.. automodule:: cities_light.models
   :members:

Admin
-----

See source for details.

.. automodule:: cities_light.admin
   :members:
