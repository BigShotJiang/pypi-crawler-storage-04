from django.apps import AppConfig


class CitiesLightConfig(AppConfig):
    default_auto_field = 'django.db.models.AutoField'
    name = 'cities_light'
