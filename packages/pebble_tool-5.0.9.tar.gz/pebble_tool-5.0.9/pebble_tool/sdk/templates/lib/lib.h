#pragma once

bool ${project_name_c}_find_truth(void);
