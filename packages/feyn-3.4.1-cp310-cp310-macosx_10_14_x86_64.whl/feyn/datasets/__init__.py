from ._synthetic import make_classification, make_regression

__all__ = [
    "make_classification",
    "make_regression",
]