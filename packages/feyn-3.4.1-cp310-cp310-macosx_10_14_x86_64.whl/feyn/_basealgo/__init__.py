from ._basealgo import BaseAlgorithm

__all__ = ["BaseAlgorithm"]
