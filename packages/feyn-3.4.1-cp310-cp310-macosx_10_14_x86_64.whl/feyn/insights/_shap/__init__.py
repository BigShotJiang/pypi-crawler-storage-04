from ._kernelshap import KernelShap
__all__ = [
    "KernelShap"
]
