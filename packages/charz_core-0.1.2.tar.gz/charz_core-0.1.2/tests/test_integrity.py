def test_integrity() -> None:
    import charz_core
