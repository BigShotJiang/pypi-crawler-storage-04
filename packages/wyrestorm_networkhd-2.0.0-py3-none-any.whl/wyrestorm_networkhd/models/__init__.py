"""NetworkHD API data models.

This module contains Pydantic models for NetworkHD API responses and notifications.
These models provide type safety and automatic validation for all API interactions.

"""
