"""NetworkHD client and connection management.

This module contains the core client implementation for NetworkHD devices.
Users should import NetworkHDClientSSH from the main package instead of directly from here.
"""
