class Dataline:
    def __init__(self, asset, name, dataline, dtype):
        self.asset = asset
        self.name = name
        self.dataline = dataline
        self.dtype = dtype
