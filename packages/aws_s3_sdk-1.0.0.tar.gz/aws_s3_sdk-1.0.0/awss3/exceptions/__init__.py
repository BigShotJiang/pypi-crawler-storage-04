__all__ = [
    'api_exception',
    'error_exception',
]
