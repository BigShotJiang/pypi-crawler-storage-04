Go to "Shopfloor / Logs".
