"""Example for simple usage."""
