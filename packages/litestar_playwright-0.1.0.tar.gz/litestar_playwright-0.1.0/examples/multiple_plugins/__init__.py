"""Example for multiple plugins."""
