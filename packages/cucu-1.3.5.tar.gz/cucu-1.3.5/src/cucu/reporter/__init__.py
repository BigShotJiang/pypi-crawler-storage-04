# flake8: noqa
# nopycln: file
from cucu.reporter.html import generate
