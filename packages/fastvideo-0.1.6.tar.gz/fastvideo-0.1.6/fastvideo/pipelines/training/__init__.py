# SPDX-License-Identifier: Apache-2.0
"""
Training pipelines for fastvideo.v1.

This package contains pipelines for training diffusion models.
"""
