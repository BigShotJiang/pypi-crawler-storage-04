# SPDX-License-Identifier: Apache-2.0
"""
Basic inference pipelines for fastvideo.

This package contains basic pipelines for video and image generation.
"""
