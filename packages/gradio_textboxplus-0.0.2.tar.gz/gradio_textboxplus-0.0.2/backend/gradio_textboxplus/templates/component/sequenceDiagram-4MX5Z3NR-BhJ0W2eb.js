import { a as xe, b as Yt, g as At, d as Te, c as Ee, e as ye } from "./chunk-OMD6QJNC-twrQRHIQ.js";
import { I as be } from "./chunk-FHKO5MBM-vFMqTTbP.js";
import { _ as u, n as me, c as $, d as Lt, l as G, j as Qt, e as we, f as ve, k as I, b as Gt, s as Ie, p as Le, a as _e, g as Pe, q as Ae, y as ke, i as _t, u as Y, L as ot, M as bt, N as Zt, Z as Ne, O as Se, P as jt, E as Ct } from "./mermaid.core-CI4eqlkq.js";
var Ot = function() {
  var e = /* @__PURE__ */ u(function(ht, w, L, P) {
    for (L = L || {}, P = ht.length; P--; L[ht[P]] = w) ;
    return L;
  }, "o"), t = [1, 2], o = [1, 3], s = [1, 4], a = [2, 4], i = [1, 9], n = [1, 11], h = [1, 13], d = [1, 14], r = [1, 16], f = [1, 17], y = [1, 18], g = [1, 24], T = [1, 25], m = [1, 26], v = [1, 27], A = [1, 28], C = [1, 29], S = [1, 30], B = [1, 31], D = [1, 32], F = [1, 33], q = [1, 34], X = [1, 35], tt = [1, 36], z = [1, 37], H = [1, 38], W = [1, 39], M = [1, 41], J = [1, 42], U = [1, 43], Q = [1, 44], et = [1, 45], N = [1, 46], E = [1, 4, 5, 13, 14, 16, 18, 21, 23, 29, 30, 31, 33, 35, 36, 37, 38, 39, 41, 43, 44, 46, 47, 48, 49, 50, 52, 53, 54, 59, 60, 61, 62, 70], _ = [4, 5, 16, 50, 52, 53], Z = [4, 5, 13, 14, 16, 18, 21, 23, 29, 30, 31, 33, 35, 36, 37, 38, 39, 41, 43, 44, 46, 50, 52, 53, 54, 59, 60, 61, 62, 70], at = [4, 5, 13, 14, 16, 18, 21, 23, 29, 30, 31, 33, 35, 36, 37, 38, 39, 41, 43, 44, 46, 49, 50, 52, 53, 54, 59, 60, 61, 62, 70], k = [4, 5, 13, 14, 16, 18, 21, 23, 29, 30, 31, 33, 35, 36, 37, 38, 39, 41, 43, 44, 46, 48, 50, 52, 53, 54, 59, 60, 61, 62, 70], qt = [4, 5, 13, 14, 16, 18, 21, 23, 29, 30, 31, 33, 35, 36, 37, 38, 39, 41, 43, 44, 46, 47, 50, 52, 53, 54, 59, 60, 61, 62, 70], it = [68, 69, 70], ct = [1, 122], Nt = {
    trace: /* @__PURE__ */ u(function() {
    }, "trace"),
    yy: {},
    symbols_: { error: 2, start: 3, SPACE: 4, NEWLINE: 5, SD: 6, document: 7, line: 8, statement: 9, box_section: 10, box_line: 11, participant_statement: 12, create: 13, box: 14, restOfLine: 15, end: 16, signal: 17, autonumber: 18, NUM: 19, off: 20, activate: 21, actor: 22, deactivate: 23, note_statement: 24, links_statement: 25, link_statement: 26, properties_statement: 27, details_statement: 28, title: 29, legacy_title: 30, acc_title: 31, acc_title_value: 32, acc_descr: 33, acc_descr_value: 34, acc_descr_multiline_value: 35, loop: 36, rect: 37, opt: 38, alt: 39, else_sections: 40, par: 41, par_sections: 42, par_over: 43, critical: 44, option_sections: 45, break: 46, option: 47, and: 48, else: 49, participant: 50, AS: 51, participant_actor: 52, destroy: 53, note: 54, placement: 55, text2: 56, over: 57, actor_pair: 58, links: 59, link: 60, properties: 61, details: 62, spaceList: 63, ",": 64, left_of: 65, right_of: 66, signaltype: 67, "+": 68, "-": 69, ACTOR: 70, SOLID_OPEN_ARROW: 71, DOTTED_OPEN_ARROW: 72, SOLID_ARROW: 73, BIDIRECTIONAL_SOLID_ARROW: 74, DOTTED_ARROW: 75, BIDIRECTIONAL_DOTTED_ARROW: 76, SOLID_CROSS: 77, DOTTED_CROSS: 78, SOLID_POINT: 79, DOTTED_POINT: 80, TXT: 81, $accept: 0, $end: 1 },
    terminals_: { 2: "error", 4: "SPACE", 5: "NEWLINE", 6: "SD", 13: "create", 14: "box", 15: "restOfLine", 16: "end", 18: "autonumber", 19: "NUM", 20: "off", 21: "activate", 23: "deactivate", 29: "title", 30: "legacy_title", 31: "acc_title", 32: "acc_title_value", 33: "acc_descr", 34: "acc_descr_value", 35: "acc_descr_multiline_value", 36: "loop", 37: "rect", 38: "opt", 39: "alt", 41: "par", 43: "par_over", 44: "critical", 46: "break", 47: "option", 48: "and", 49: "else", 50: "participant", 51: "AS", 52: "participant_actor", 53: "destroy", 54: "note", 57: "over", 59: "links", 60: "link", 61: "properties", 62: "details", 64: ",", 65: "left_of", 66: "right_of", 68: "+", 69: "-", 70: "ACTOR", 71: "SOLID_OPEN_ARROW", 72: "DOTTED_OPEN_ARROW", 73: "SOLID_ARROW", 74: "BIDIRECTIONAL_SOLID_ARROW", 75: "DOTTED_ARROW", 76: "BIDIRECTIONAL_DOTTED_ARROW", 77: "SOLID_CROSS", 78: "DOTTED_CROSS", 79: "SOLID_POINT", 80: "DOTTED_POINT", 81: "TXT" },
    productions_: [0, [3, 2], [3, 2], [3, 2], [7, 0], [7, 2], [8, 2], [8, 1], [8, 1], [10, 0], [10, 2], [11, 2], [11, 1], [11, 1], [9, 1], [9, 2], [9, 4], [9, 2], [9, 4], [9, 3], [9, 3], [9, 2], [9, 3], [9, 3], [9, 2], [9, 2], [9, 2], [9, 2], [9, 2], [9, 1], [9, 1], [9, 2], [9, 2], [9, 1], [9, 4], [9, 4], [9, 4], [9, 4], [9, 4], [9, 4], [9, 4], [9, 4], [45, 1], [45, 4], [42, 1], [42, 4], [40, 1], [40, 4], [12, 5], [12, 3], [12, 5], [12, 3], [12, 3], [24, 4], [24, 4], [25, 3], [26, 3], [27, 3], [28, 3], [63, 2], [63, 1], [58, 3], [58, 1], [55, 1], [55, 1], [17, 5], [17, 5], [17, 4], [22, 1], [67, 1], [67, 1], [67, 1], [67, 1], [67, 1], [67, 1], [67, 1], [67, 1], [67, 1], [67, 1], [56, 1]],
    performAction: /* @__PURE__ */ u(function(w, L, P, b, R, l, yt) {
      var p = l.length - 1;
      switch (R) {
        case 3:
          return b.apply(l[p]), l[p];
        case 4:
        case 9:
          this.$ = [];
          break;
        case 5:
        case 10:
          l[p - 1].push(l[p]), this.$ = l[p - 1];
          break;
        case 6:
        case 7:
        case 11:
        case 12:
          this.$ = l[p];
          break;
        case 8:
        case 13:
          this.$ = [];
          break;
        case 15:
          l[p].type = "createParticipant", this.$ = l[p];
          break;
        case 16:
          l[p - 1].unshift({ type: "boxStart", boxData: b.parseBoxData(l[p - 2]) }), l[p - 1].push({ type: "boxEnd", boxText: l[p - 2] }), this.$ = l[p - 1];
          break;
        case 18:
          this.$ = { type: "sequenceIndex", sequenceIndex: Number(l[p - 2]), sequenceIndexStep: Number(l[p - 1]), sequenceVisible: !0, signalType: b.LINETYPE.AUTONUMBER };
          break;
        case 19:
          this.$ = { type: "sequenceIndex", sequenceIndex: Number(l[p - 1]), sequenceIndexStep: 1, sequenceVisible: !0, signalType: b.LINETYPE.AUTONUMBER };
          break;
        case 20:
          this.$ = { type: "sequenceIndex", sequenceVisible: !1, signalType: b.LINETYPE.AUTONUMBER };
          break;
        case 21:
          this.$ = { type: "sequenceIndex", sequenceVisible: !0, signalType: b.LINETYPE.AUTONUMBER };
          break;
        case 22:
          this.$ = { type: "activeStart", signalType: b.LINETYPE.ACTIVE_START, actor: l[p - 1].actor };
          break;
        case 23:
          this.$ = { type: "activeEnd", signalType: b.LINETYPE.ACTIVE_END, actor: l[p - 1].actor };
          break;
        case 29:
          b.setDiagramTitle(l[p].substring(6)), this.$ = l[p].substring(6);
          break;
        case 30:
          b.setDiagramTitle(l[p].substring(7)), this.$ = l[p].substring(7);
          break;
        case 31:
          this.$ = l[p].trim(), b.setAccTitle(this.$);
          break;
        case 32:
        case 33:
          this.$ = l[p].trim(), b.setAccDescription(this.$);
          break;
        case 34:
          l[p - 1].unshift({ type: "loopStart", loopText: b.parseMessage(l[p - 2]), signalType: b.LINETYPE.LOOP_START }), l[p - 1].push({ type: "loopEnd", loopText: l[p - 2], signalType: b.LINETYPE.LOOP_END }), this.$ = l[p - 1];
          break;
        case 35:
          l[p - 1].unshift({ type: "rectStart", color: b.parseMessage(l[p - 2]), signalType: b.LINETYPE.RECT_START }), l[p - 1].push({ type: "rectEnd", color: b.parseMessage(l[p - 2]), signalType: b.LINETYPE.RECT_END }), this.$ = l[p - 1];
          break;
        case 36:
          l[p - 1].unshift({ type: "optStart", optText: b.parseMessage(l[p - 2]), signalType: b.LINETYPE.OPT_START }), l[p - 1].push({ type: "optEnd", optText: b.parseMessage(l[p - 2]), signalType: b.LINETYPE.OPT_END }), this.$ = l[p - 1];
          break;
        case 37:
          l[p - 1].unshift({ type: "altStart", altText: b.parseMessage(l[p - 2]), signalType: b.LINETYPE.ALT_START }), l[p - 1].push({ type: "altEnd", signalType: b.LINETYPE.ALT_END }), this.$ = l[p - 1];
          break;
        case 38:
          l[p - 1].unshift({ type: "parStart", parText: b.parseMessage(l[p - 2]), signalType: b.LINETYPE.PAR_START }), l[p - 1].push({ type: "parEnd", signalType: b.LINETYPE.PAR_END }), this.$ = l[p - 1];
          break;
        case 39:
          l[p - 1].unshift({ type: "parStart", parText: b.parseMessage(l[p - 2]), signalType: b.LINETYPE.PAR_OVER_START }), l[p - 1].push({ type: "parEnd", signalType: b.LINETYPE.PAR_END }), this.$ = l[p - 1];
          break;
        case 40:
          l[p - 1].unshift({ type: "criticalStart", criticalText: b.parseMessage(l[p - 2]), signalType: b.LINETYPE.CRITICAL_START }), l[p - 1].push({ type: "criticalEnd", signalType: b.LINETYPE.CRITICAL_END }), this.$ = l[p - 1];
          break;
        case 41:
          l[p - 1].unshift({ type: "breakStart", breakText: b.parseMessage(l[p - 2]), signalType: b.LINETYPE.BREAK_START }), l[p - 1].push({ type: "breakEnd", optText: b.parseMessage(l[p - 2]), signalType: b.LINETYPE.BREAK_END }), this.$ = l[p - 1];
          break;
        case 43:
          this.$ = l[p - 3].concat([{ type: "option", optionText: b.parseMessage(l[p - 1]), signalType: b.LINETYPE.CRITICAL_OPTION }, l[p]]);
          break;
        case 45:
          this.$ = l[p - 3].concat([{ type: "and", parText: b.parseMessage(l[p - 1]), signalType: b.LINETYPE.PAR_AND }, l[p]]);
          break;
        case 47:
          this.$ = l[p - 3].concat([{ type: "else", altText: b.parseMessage(l[p - 1]), signalType: b.LINETYPE.ALT_ELSE }, l[p]]);
          break;
        case 48:
          l[p - 3].draw = "participant", l[p - 3].type = "addParticipant", l[p - 3].description = b.parseMessage(l[p - 1]), this.$ = l[p - 3];
          break;
        case 49:
          l[p - 1].draw = "participant", l[p - 1].type = "addParticipant", this.$ = l[p - 1];
          break;
        case 50:
          l[p - 3].draw = "actor", l[p - 3].type = "addParticipant", l[p - 3].description = b.parseMessage(l[p - 1]), this.$ = l[p - 3];
          break;
        case 51:
          l[p - 1].draw = "actor", l[p - 1].type = "addParticipant", this.$ = l[p - 1];
          break;
        case 52:
          l[p - 1].type = "destroyParticipant", this.$ = l[p - 1];
          break;
        case 53:
          this.$ = [l[p - 1], { type: "addNote", placement: l[p - 2], actor: l[p - 1].actor, text: l[p] }];
          break;
        case 54:
          l[p - 2] = [].concat(l[p - 1], l[p - 1]).slice(0, 2), l[p - 2][0] = l[p - 2][0].actor, l[p - 2][1] = l[p - 2][1].actor, this.$ = [l[p - 1], { type: "addNote", placement: b.PLACEMENT.OVER, actor: l[p - 2].slice(0, 2), text: l[p] }];
          break;
        case 55:
          this.$ = [l[p - 1], { type: "addLinks", actor: l[p - 1].actor, text: l[p] }];
          break;
        case 56:
          this.$ = [l[p - 1], { type: "addALink", actor: l[p - 1].actor, text: l[p] }];
          break;
        case 57:
          this.$ = [l[p - 1], { type: "addProperties", actor: l[p - 1].actor, text: l[p] }];
          break;
        case 58:
          this.$ = [l[p - 1], { type: "addDetails", actor: l[p - 1].actor, text: l[p] }];
          break;
        case 61:
          this.$ = [l[p - 2], l[p]];
          break;
        case 62:
          this.$ = l[p];
          break;
        case 63:
          this.$ = b.PLACEMENT.LEFTOF;
          break;
        case 64:
          this.$ = b.PLACEMENT.RIGHTOF;
          break;
        case 65:
          this.$ = [
            l[p - 4],
            l[p - 1],
            { type: "addMessage", from: l[p - 4].actor, to: l[p - 1].actor, signalType: l[p - 3], msg: l[p], activate: !0 },
            { type: "activeStart", signalType: b.LINETYPE.ACTIVE_START, actor: l[p - 1].actor }
          ];
          break;
        case 66:
          this.$ = [
            l[p - 4],
            l[p - 1],
            { type: "addMessage", from: l[p - 4].actor, to: l[p - 1].actor, signalType: l[p - 3], msg: l[p] },
            { type: "activeEnd", signalType: b.LINETYPE.ACTIVE_END, actor: l[p - 4].actor }
          ];
          break;
        case 67:
          this.$ = [l[p - 3], l[p - 1], { type: "addMessage", from: l[p - 3].actor, to: l[p - 1].actor, signalType: l[p - 2], msg: l[p] }];
          break;
        case 68:
          this.$ = { type: "addParticipant", actor: l[p] };
          break;
        case 69:
          this.$ = b.LINETYPE.SOLID_OPEN;
          break;
        case 70:
          this.$ = b.LINETYPE.DOTTED_OPEN;
          break;
        case 71:
          this.$ = b.LINETYPE.SOLID;
          break;
        case 72:
          this.$ = b.LINETYPE.BIDIRECTIONAL_SOLID;
          break;
        case 73:
          this.$ = b.LINETYPE.DOTTED;
          break;
        case 74:
          this.$ = b.LINETYPE.BIDIRECTIONAL_DOTTED;
          break;
        case 75:
          this.$ = b.LINETYPE.SOLID_CROSS;
          break;
        case 76:
          this.$ = b.LINETYPE.DOTTED_CROSS;
          break;
        case 77:
          this.$ = b.LINETYPE.SOLID_POINT;
          break;
        case 78:
          this.$ = b.LINETYPE.DOTTED_POINT;
          break;
        case 79:
          this.$ = b.parseMessage(l[p].trim().substring(1));
          break;
      }
    }, "anonymous"),
    table: [{ 3: 1, 4: t, 5: o, 6: s }, { 1: [3] }, { 3: 5, 4: t, 5: o, 6: s }, { 3: 6, 4: t, 5: o, 6: s }, e([1, 4, 5, 13, 14, 18, 21, 23, 29, 30, 31, 33, 35, 36, 37, 38, 39, 41, 43, 44, 46, 50, 52, 53, 54, 59, 60, 61, 62, 70], a, { 7: 7 }), { 1: [2, 1] }, { 1: [2, 2] }, { 1: [2, 3], 4: i, 5: n, 8: 8, 9: 10, 12: 12, 13: h, 14: d, 17: 15, 18: r, 21: f, 22: 40, 23: y, 24: 19, 25: 20, 26: 21, 27: 22, 28: 23, 29: g, 30: T, 31: m, 33: v, 35: A, 36: C, 37: S, 38: B, 39: D, 41: F, 43: q, 44: X, 46: tt, 50: z, 52: H, 53: W, 54: M, 59: J, 60: U, 61: Q, 62: et, 70: N }, e(E, [2, 5]), { 9: 47, 12: 12, 13: h, 14: d, 17: 15, 18: r, 21: f, 22: 40, 23: y, 24: 19, 25: 20, 26: 21, 27: 22, 28: 23, 29: g, 30: T, 31: m, 33: v, 35: A, 36: C, 37: S, 38: B, 39: D, 41: F, 43: q, 44: X, 46: tt, 50: z, 52: H, 53: W, 54: M, 59: J, 60: U, 61: Q, 62: et, 70: N }, e(E, [2, 7]), e(E, [2, 8]), e(E, [2, 14]), { 12: 48, 50: z, 52: H, 53: W }, { 15: [1, 49] }, { 5: [1, 50] }, { 5: [1, 53], 19: [1, 51], 20: [1, 52] }, { 22: 54, 70: N }, { 22: 55, 70: N }, { 5: [1, 56] }, { 5: [1, 57] }, { 5: [1, 58] }, { 5: [1, 59] }, { 5: [1, 60] }, e(E, [2, 29]), e(E, [2, 30]), { 32: [1, 61] }, { 34: [1, 62] }, e(E, [2, 33]), { 15: [1, 63] }, { 15: [1, 64] }, { 15: [1, 65] }, { 15: [1, 66] }, { 15: [1, 67] }, { 15: [1, 68] }, { 15: [1, 69] }, { 15: [1, 70] }, { 22: 71, 70: N }, { 22: 72, 70: N }, { 22: 73, 70: N }, { 67: 74, 71: [1, 75], 72: [1, 76], 73: [1, 77], 74: [1, 78], 75: [1, 79], 76: [1, 80], 77: [1, 81], 78: [1, 82], 79: [1, 83], 80: [1, 84] }, { 55: 85, 57: [1, 86], 65: [1, 87], 66: [1, 88] }, { 22: 89, 70: N }, { 22: 90, 70: N }, { 22: 91, 70: N }, { 22: 92, 70: N }, e([5, 51, 64, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81], [2, 68]), e(E, [2, 6]), e(E, [2, 15]), e(_, [2, 9], { 10: 93 }), e(E, [2, 17]), { 5: [1, 95], 19: [1, 94] }, { 5: [1, 96] }, e(E, [2, 21]), { 5: [1, 97] }, { 5: [1, 98] }, e(E, [2, 24]), e(E, [2, 25]), e(E, [2, 26]), e(E, [2, 27]), e(E, [2, 28]), e(E, [2, 31]), e(E, [2, 32]), e(Z, a, { 7: 99 }), e(Z, a, { 7: 100 }), e(Z, a, { 7: 101 }), e(at, a, { 40: 102, 7: 103 }), e(k, a, { 42: 104, 7: 105 }), e(k, a, { 7: 105, 42: 106 }), e(qt, a, { 45: 107, 7: 108 }), e(Z, a, { 7: 109 }), { 5: [1, 111], 51: [1, 110] }, { 5: [1, 113], 51: [1, 112] }, { 5: [1, 114] }, { 22: 117, 68: [1, 115], 69: [1, 116], 70: N }, e(it, [2, 69]), e(it, [2, 70]), e(it, [2, 71]), e(it, [2, 72]), e(it, [2, 73]), e(it, [2, 74]), e(it, [2, 75]), e(it, [2, 76]), e(it, [2, 77]), e(it, [2, 78]), { 22: 118, 70: N }, { 22: 120, 58: 119, 70: N }, { 70: [2, 63] }, { 70: [2, 64] }, { 56: 121, 81: ct }, { 56: 123, 81: ct }, { 56: 124, 81: ct }, { 56: 125, 81: ct }, { 4: [1, 128], 5: [1, 130], 11: 127, 12: 129, 16: [1, 126], 50: z, 52: H, 53: W }, { 5: [1, 131] }, e(E, [2, 19]), e(E, [2, 20]), e(E, [2, 22]), e(E, [2, 23]), { 4: i, 5: n, 8: 8, 9: 10, 12: 12, 13: h, 14: d, 16: [1, 132], 17: 15, 18: r, 21: f, 22: 40, 23: y, 24: 19, 25: 20, 26: 21, 27: 22, 28: 23, 29: g, 30: T, 31: m, 33: v, 35: A, 36: C, 37: S, 38: B, 39: D, 41: F, 43: q, 44: X, 46: tt, 50: z, 52: H, 53: W, 54: M, 59: J, 60: U, 61: Q, 62: et, 70: N }, { 4: i, 5: n, 8: 8, 9: 10, 12: 12, 13: h, 14: d, 16: [1, 133], 17: 15, 18: r, 21: f, 22: 40, 23: y, 24: 19, 25: 20, 26: 21, 27: 22, 28: 23, 29: g, 30: T, 31: m, 33: v, 35: A, 36: C, 37: S, 38: B, 39: D, 41: F, 43: q, 44: X, 46: tt, 50: z, 52: H, 53: W, 54: M, 59: J, 60: U, 61: Q, 62: et, 70: N }, { 4: i, 5: n, 8: 8, 9: 10, 12: 12, 13: h, 14: d, 16: [1, 134], 17: 15, 18: r, 21: f, 22: 40, 23: y, 24: 19, 25: 20, 26: 21, 27: 22, 28: 23, 29: g, 30: T, 31: m, 33: v, 35: A, 36: C, 37: S, 38: B, 39: D, 41: F, 43: q, 44: X, 46: tt, 50: z, 52: H, 53: W, 54: M, 59: J, 60: U, 61: Q, 62: et, 70: N }, { 16: [1, 135] }, { 4: i, 5: n, 8: 8, 9: 10, 12: 12, 13: h, 14: d, 16: [2, 46], 17: 15, 18: r, 21: f, 22: 40, 23: y, 24: 19, 25: 20, 26: 21, 27: 22, 28: 23, 29: g, 30: T, 31: m, 33: v, 35: A, 36: C, 37: S, 38: B, 39: D, 41: F, 43: q, 44: X, 46: tt, 49: [1, 136], 50: z, 52: H, 53: W, 54: M, 59: J, 60: U, 61: Q, 62: et, 70: N }, { 16: [1, 137] }, { 4: i, 5: n, 8: 8, 9: 10, 12: 12, 13: h, 14: d, 16: [2, 44], 17: 15, 18: r, 21: f, 22: 40, 23: y, 24: 19, 25: 20, 26: 21, 27: 22, 28: 23, 29: g, 30: T, 31: m, 33: v, 35: A, 36: C, 37: S, 38: B, 39: D, 41: F, 43: q, 44: X, 46: tt, 48: [1, 138], 50: z, 52: H, 53: W, 54: M, 59: J, 60: U, 61: Q, 62: et, 70: N }, { 16: [1, 139] }, { 16: [1, 140] }, { 4: i, 5: n, 8: 8, 9: 10, 12: 12, 13: h, 14: d, 16: [2, 42], 17: 15, 18: r, 21: f, 22: 40, 23: y, 24: 19, 25: 20, 26: 21, 27: 22, 28: 23, 29: g, 30: T, 31: m, 33: v, 35: A, 36: C, 37: S, 38: B, 39: D, 41: F, 43: q, 44: X, 46: tt, 47: [1, 141], 50: z, 52: H, 53: W, 54: M, 59: J, 60: U, 61: Q, 62: et, 70: N }, { 4: i, 5: n, 8: 8, 9: 10, 12: 12, 13: h, 14: d, 16: [1, 142], 17: 15, 18: r, 21: f, 22: 40, 23: y, 24: 19, 25: 20, 26: 21, 27: 22, 28: 23, 29: g, 30: T, 31: m, 33: v, 35: A, 36: C, 37: S, 38: B, 39: D, 41: F, 43: q, 44: X, 46: tt, 50: z, 52: H, 53: W, 54: M, 59: J, 60: U, 61: Q, 62: et, 70: N }, { 15: [1, 143] }, e(E, [2, 49]), { 15: [1, 144] }, e(E, [2, 51]), e(E, [2, 52]), { 22: 145, 70: N }, { 22: 146, 70: N }, { 56: 147, 81: ct }, { 56: 148, 81: ct }, { 56: 149, 81: ct }, { 64: [1, 150], 81: [2, 62] }, { 5: [2, 55] }, { 5: [2, 79] }, { 5: [2, 56] }, { 5: [2, 57] }, { 5: [2, 58] }, e(E, [2, 16]), e(_, [2, 10]), { 12: 151, 50: z, 52: H, 53: W }, e(_, [2, 12]), e(_, [2, 13]), e(E, [2, 18]), e(E, [2, 34]), e(E, [2, 35]), e(E, [2, 36]), e(E, [2, 37]), { 15: [1, 152] }, e(E, [2, 38]), { 15: [1, 153] }, e(E, [2, 39]), e(E, [2, 40]), { 15: [1, 154] }, e(E, [2, 41]), { 5: [1, 155] }, { 5: [1, 156] }, { 56: 157, 81: ct }, { 56: 158, 81: ct }, { 5: [2, 67] }, { 5: [2, 53] }, { 5: [2, 54] }, { 22: 159, 70: N }, e(_, [2, 11]), e(at, a, { 7: 103, 40: 160 }), e(k, a, { 7: 105, 42: 161 }), e(qt, a, { 7: 108, 45: 162 }), e(E, [2, 48]), e(E, [2, 50]), { 5: [2, 65] }, { 5: [2, 66] }, { 81: [2, 61] }, { 16: [2, 47] }, { 16: [2, 45] }, { 16: [2, 43] }],
    defaultActions: { 5: [2, 1], 6: [2, 2], 87: [2, 63], 88: [2, 64], 121: [2, 55], 122: [2, 79], 123: [2, 56], 124: [2, 57], 125: [2, 58], 147: [2, 67], 148: [2, 53], 149: [2, 54], 157: [2, 65], 158: [2, 66], 159: [2, 61], 160: [2, 47], 161: [2, 45], 162: [2, 43] },
    parseError: /* @__PURE__ */ u(function(w, L) {
      if (L.recoverable)
        this.trace(w);
      else {
        var P = new Error(w);
        throw P.hash = L, P;
      }
    }, "parseError"),
    parse: /* @__PURE__ */ u(function(w) {
      var L = this, P = [0], b = [], R = [null], l = [], yt = this.table, p = "", wt = 0, zt = 0, pe = 2, Ht = 1, ue = l.slice.call(arguments, 1), V = Object.create(this.lexer), dt = { yy: {} };
      for (var St in this.yy)
        Object.prototype.hasOwnProperty.call(this.yy, St) && (dt.yy[St] = this.yy[St]);
      V.setInput(w, dt.yy), dt.yy.lexer = V, dt.yy.parser = this, typeof V.yylloc > "u" && (V.yylloc = {});
      var Mt = V.yylloc;
      l.push(Mt);
      var ge = V.options && V.options.ranges;
      typeof dt.yy.parseError == "function" ? this.parseError = dt.yy.parseError : this.parseError = Object.getPrototypeOf(this).parseError;
      function fe(j) {
        P.length = P.length - 2 * j, R.length = R.length - j, l.length = l.length - j;
      }
      u(fe, "popStack");
      function Ut() {
        var j;
        return j = b.pop() || V.lex() || Ht, typeof j != "number" && (j instanceof Array && (b = j, j = b.pop()), j = L.symbols_[j] || j), j;
      }
      u(Ut, "lex");
      for (var K, pt, st, Rt, ft = {}, vt, lt, Kt, It; ; ) {
        if (pt = P[P.length - 1], this.defaultActions[pt] ? st = this.defaultActions[pt] : ((K === null || typeof K > "u") && (K = Ut()), st = yt[pt] && yt[pt][K]), typeof st > "u" || !st.length || !st[0]) {
          var Dt = "";
          It = [];
          for (vt in yt[pt])
            this.terminals_[vt] && vt > pe && It.push("'" + this.terminals_[vt] + "'");
          V.showPosition ? Dt = "Parse error on line " + (wt + 1) + `:
` + V.showPosition() + `
Expecting ` + It.join(", ") + ", got '" + (this.terminals_[K] || K) + "'" : Dt = "Parse error on line " + (wt + 1) + ": Unexpected " + (K == Ht ? "end of input" : "'" + (this.terminals_[K] || K) + "'"), this.parseError(Dt, {
            text: V.match,
            token: this.terminals_[K] || K,
            line: V.yylineno,
            loc: Mt,
            expected: It
          });
        }
        if (st[0] instanceof Array && st.length > 1)
          throw new Error("Parse Error: multiple actions possible at state: " + pt + ", token: " + K);
        switch (st[0]) {
          case 1:
            P.push(K), R.push(V.yytext), l.push(V.yylloc), P.push(st[1]), K = null, zt = V.yyleng, p = V.yytext, wt = V.yylineno, Mt = V.yylloc;
            break;
          case 2:
            if (lt = this.productions_[st[1]][1], ft.$ = R[R.length - lt], ft._$ = {
              first_line: l[l.length - (lt || 1)].first_line,
              last_line: l[l.length - 1].last_line,
              first_column: l[l.length - (lt || 1)].first_column,
              last_column: l[l.length - 1].last_column
            }, ge && (ft._$.range = [
              l[l.length - (lt || 1)].range[0],
              l[l.length - 1].range[1]
            ]), Rt = this.performAction.apply(ft, [
              p,
              zt,
              wt,
              dt.yy,
              st[1],
              R,
              l
            ].concat(ue)), typeof Rt < "u")
              return Rt;
            lt && (P = P.slice(0, -1 * lt * 2), R = R.slice(0, -1 * lt), l = l.slice(0, -1 * lt)), P.push(this.productions_[st[1]][0]), R.push(ft.$), l.push(ft._$), Kt = yt[P[P.length - 2]][P[P.length - 1]], P.push(Kt);
            break;
          case 3:
            return !0;
        }
      }
      return !0;
    }, "parse")
  }, de = /* @__PURE__ */ function() {
    var ht = {
      EOF: 1,
      parseError: /* @__PURE__ */ u(function(L, P) {
        if (this.yy.parser)
          this.yy.parser.parseError(L, P);
        else
          throw new Error(L);
      }, "parseError"),
      // resets the lexer, sets new input
      setInput: /* @__PURE__ */ u(function(w, L) {
        return this.yy = L || this.yy || {}, this._input = w, this._more = this._backtrack = this.done = !1, this.yylineno = this.yyleng = 0, this.yytext = this.matched = this.match = "", this.conditionStack = ["INITIAL"], this.yylloc = {
          first_line: 1,
          first_column: 0,
          last_line: 1,
          last_column: 0
        }, this.options.ranges && (this.yylloc.range = [0, 0]), this.offset = 0, this;
      }, "setInput"),
      // consumes and returns one char from the input
      input: /* @__PURE__ */ u(function() {
        var w = this._input[0];
        this.yytext += w, this.yyleng++, this.offset++, this.match += w, this.matched += w;
        var L = w.match(/(?:\r\n?|\n).*/g);
        return L ? (this.yylineno++, this.yylloc.last_line++) : this.yylloc.last_column++, this.options.ranges && this.yylloc.range[1]++, this._input = this._input.slice(1), w;
      }, "input"),
      // unshifts one char (or a string) into the input
      unput: /* @__PURE__ */ u(function(w) {
        var L = w.length, P = w.split(/(?:\r\n?|\n)/g);
        this._input = w + this._input, this.yytext = this.yytext.substr(0, this.yytext.length - L), this.offset -= L;
        var b = this.match.split(/(?:\r\n?|\n)/g);
        this.match = this.match.substr(0, this.match.length - 1), this.matched = this.matched.substr(0, this.matched.length - 1), P.length - 1 && (this.yylineno -= P.length - 1);
        var R = this.yylloc.range;
        return this.yylloc = {
          first_line: this.yylloc.first_line,
          last_line: this.yylineno + 1,
          first_column: this.yylloc.first_column,
          last_column: P ? (P.length === b.length ? this.yylloc.first_column : 0) + b[b.length - P.length].length - P[0].length : this.yylloc.first_column - L
        }, this.options.ranges && (this.yylloc.range = [R[0], R[0] + this.yyleng - L]), this.yyleng = this.yytext.length, this;
      }, "unput"),
      // When called from action, caches matched text and appends it on next action
      more: /* @__PURE__ */ u(function() {
        return this._more = !0, this;
      }, "more"),
      // When called from action, signals the lexer that this rule fails to match the input, so the next matching rule (regex) should be tested instead.
      reject: /* @__PURE__ */ u(function() {
        if (this.options.backtrack_lexer)
          this._backtrack = !0;
        else
          return this.parseError("Lexical error on line " + (this.yylineno + 1) + `. You can only invoke reject() in the lexer when the lexer is of the backtracking persuasion (options.backtrack_lexer = true).
` + this.showPosition(), {
            text: "",
            token: null,
            line: this.yylineno
          });
        return this;
      }, "reject"),
      // retain first n characters of the match
      less: /* @__PURE__ */ u(function(w) {
        this.unput(this.match.slice(w));
      }, "less"),
      // displays already matched input, i.e. for error messages
      pastInput: /* @__PURE__ */ u(function() {
        var w = this.matched.substr(0, this.matched.length - this.match.length);
        return (w.length > 20 ? "..." : "") + w.substr(-20).replace(/\n/g, "");
      }, "pastInput"),
      // displays upcoming input, i.e. for error messages
      upcomingInput: /* @__PURE__ */ u(function() {
        var w = this.match;
        return w.length < 20 && (w += this._input.substr(0, 20 - w.length)), (w.substr(0, 20) + (w.length > 20 ? "..." : "")).replace(/\n/g, "");
      }, "upcomingInput"),
      // displays the character position where the lexing error occurred, i.e. for error messages
      showPosition: /* @__PURE__ */ u(function() {
        var w = this.pastInput(), L = new Array(w.length + 1).join("-");
        return w + this.upcomingInput() + `
` + L + "^";
      }, "showPosition"),
      // test the lexed token: return FALSE when not a match, otherwise return token
      test_match: /* @__PURE__ */ u(function(w, L) {
        var P, b, R;
        if (this.options.backtrack_lexer && (R = {
          yylineno: this.yylineno,
          yylloc: {
            first_line: this.yylloc.first_line,
            last_line: this.last_line,
            first_column: this.yylloc.first_column,
            last_column: this.yylloc.last_column
          },
          yytext: this.yytext,
          match: this.match,
          matches: this.matches,
          matched: this.matched,
          yyleng: this.yyleng,
          offset: this.offset,
          _more: this._more,
          _input: this._input,
          yy: this.yy,
          conditionStack: this.conditionStack.slice(0),
          done: this.done
        }, this.options.ranges && (R.yylloc.range = this.yylloc.range.slice(0))), b = w[0].match(/(?:\r\n?|\n).*/g), b && (this.yylineno += b.length), this.yylloc = {
          first_line: this.yylloc.last_line,
          last_line: this.yylineno + 1,
          first_column: this.yylloc.last_column,
          last_column: b ? b[b.length - 1].length - b[b.length - 1].match(/\r?\n?/)[0].length : this.yylloc.last_column + w[0].length
        }, this.yytext += w[0], this.match += w[0], this.matches = w, this.yyleng = this.yytext.length, this.options.ranges && (this.yylloc.range = [this.offset, this.offset += this.yyleng]), this._more = !1, this._backtrack = !1, this._input = this._input.slice(w[0].length), this.matched += w[0], P = this.performAction.call(this, this.yy, this, L, this.conditionStack[this.conditionStack.length - 1]), this.done && this._input && (this.done = !1), P)
          return P;
        if (this._backtrack) {
          for (var l in R)
            this[l] = R[l];
          return !1;
        }
        return !1;
      }, "test_match"),
      // return next match in input
      next: /* @__PURE__ */ u(function() {
        if (this.done)
          return this.EOF;
        this._input || (this.done = !0);
        var w, L, P, b;
        this._more || (this.yytext = "", this.match = "");
        for (var R = this._currentRules(), l = 0; l < R.length; l++)
          if (P = this._input.match(this.rules[R[l]]), P && (!L || P[0].length > L[0].length)) {
            if (L = P, b = l, this.options.backtrack_lexer) {
              if (w = this.test_match(P, R[l]), w !== !1)
                return w;
              if (this._backtrack) {
                L = !1;
                continue;
              } else
                return !1;
            } else if (!this.options.flex)
              break;
          }
        return L ? (w = this.test_match(L, R[b]), w !== !1 ? w : !1) : this._input === "" ? this.EOF : this.parseError("Lexical error on line " + (this.yylineno + 1) + `. Unrecognized text.
` + this.showPosition(), {
          text: "",
          token: null,
          line: this.yylineno
        });
      }, "next"),
      // return next match that has a token
      lex: /* @__PURE__ */ u(function() {
        var L = this.next();
        return L || this.lex();
      }, "lex"),
      // activates a new lexer condition state (pushes the new lexer condition state onto the condition stack)
      begin: /* @__PURE__ */ u(function(L) {
        this.conditionStack.push(L);
      }, "begin"),
      // pop the previously active lexer condition state off the condition stack
      popState: /* @__PURE__ */ u(function() {
        var L = this.conditionStack.length - 1;
        return L > 0 ? this.conditionStack.pop() : this.conditionStack[0];
      }, "popState"),
      // produce the lexer rule set which is active for the currently active lexer condition state
      _currentRules: /* @__PURE__ */ u(function() {
        return this.conditionStack.length && this.conditionStack[this.conditionStack.length - 1] ? this.conditions[this.conditionStack[this.conditionStack.length - 1]].rules : this.conditions.INITIAL.rules;
      }, "_currentRules"),
      // return the currently active lexer condition state; when an index argument is provided it produces the N-th previous condition state, if available
      topState: /* @__PURE__ */ u(function(L) {
        return L = this.conditionStack.length - 1 - Math.abs(L || 0), L >= 0 ? this.conditionStack[L] : "INITIAL";
      }, "topState"),
      // alias for begin(condition)
      pushState: /* @__PURE__ */ u(function(L) {
        this.begin(L);
      }, "pushState"),
      // return the number of states currently on the stack
      stateStackSize: /* @__PURE__ */ u(function() {
        return this.conditionStack.length;
      }, "stateStackSize"),
      options: { "case-insensitive": !0 },
      performAction: /* @__PURE__ */ u(function(L, P, b, R) {
        switch (b) {
          case 0:
            return 5;
          case 1:
            break;
          case 2:
            break;
          case 3:
            break;
          case 4:
            break;
          case 5:
            break;
          case 6:
            return 19;
          case 7:
            return this.begin("LINE"), 14;
          case 8:
            return this.begin("ID"), 50;
          case 9:
            return this.begin("ID"), 52;
          case 10:
            return 13;
          case 11:
            return this.begin("ID"), 53;
          case 12:
            return P.yytext = P.yytext.trim(), this.begin("ALIAS"), 70;
          case 13:
            return this.popState(), this.popState(), this.begin("LINE"), 51;
          case 14:
            return this.popState(), this.popState(), 5;
          case 15:
            return this.begin("LINE"), 36;
          case 16:
            return this.begin("LINE"), 37;
          case 17:
            return this.begin("LINE"), 38;
          case 18:
            return this.begin("LINE"), 39;
          case 19:
            return this.begin("LINE"), 49;
          case 20:
            return this.begin("LINE"), 41;
          case 21:
            return this.begin("LINE"), 43;
          case 22:
            return this.begin("LINE"), 48;
          case 23:
            return this.begin("LINE"), 44;
          case 24:
            return this.begin("LINE"), 47;
          case 25:
            return this.begin("LINE"), 46;
          case 26:
            return this.popState(), 15;
          case 27:
            return 16;
          case 28:
            return 65;
          case 29:
            return 66;
          case 30:
            return 59;
          case 31:
            return 60;
          case 32:
            return 61;
          case 33:
            return 62;
          case 34:
            return 57;
          case 35:
            return 54;
          case 36:
            return this.begin("ID"), 21;
          case 37:
            return this.begin("ID"), 23;
          case 38:
            return 29;
          case 39:
            return 30;
          case 40:
            return this.begin("acc_title"), 31;
          case 41:
            return this.popState(), "acc_title_value";
          case 42:
            return this.begin("acc_descr"), 33;
          case 43:
            return this.popState(), "acc_descr_value";
          case 44:
            this.begin("acc_descr_multiline");
            break;
          case 45:
            this.popState();
            break;
          case 46:
            return "acc_descr_multiline_value";
          case 47:
            return 6;
          case 48:
            return 18;
          case 49:
            return 20;
          case 50:
            return 64;
          case 51:
            return 5;
          case 52:
            return P.yytext = P.yytext.trim(), 70;
          case 53:
            return 73;
          case 54:
            return 74;
          case 55:
            return 75;
          case 56:
            return 76;
          case 57:
            return 71;
          case 58:
            return 72;
          case 59:
            return 77;
          case 60:
            return 78;
          case 61:
            return 79;
          case 62:
            return 80;
          case 63:
            return 81;
          case 64:
            return 81;
          case 65:
            return 68;
          case 66:
            return 69;
          case 67:
            return 5;
          case 68:
            return "INVALID";
        }
      }, "anonymous"),
      rules: [/^(?:[\n]+)/i, /^(?:\s+)/i, /^(?:((?!\n)\s)+)/i, /^(?:#[^\n]*)/i, /^(?:%(?!\{)[^\n]*)/i, /^(?:[^\}]%%[^\n]*)/i, /^(?:[0-9]+(?=[ \n]+))/i, /^(?:box\b)/i, /^(?:participant\b)/i, /^(?:actor\b)/i, /^(?:create\b)/i, /^(?:destroy\b)/i, /^(?:[^<\->\->:\n,;]+?([\-]*[^<\->\->:\n,;]+?)*?(?=((?!\n)\s)+as(?!\n)\s|[#\n;]|$))/i, /^(?:as\b)/i, /^(?:(?:))/i, /^(?:loop\b)/i, /^(?:rect\b)/i, /^(?:opt\b)/i, /^(?:alt\b)/i, /^(?:else\b)/i, /^(?:par\b)/i, /^(?:par_over\b)/i, /^(?:and\b)/i, /^(?:critical\b)/i, /^(?:option\b)/i, /^(?:break\b)/i, /^(?:(?:[:]?(?:no)?wrap)?[^#\n;]*)/i, /^(?:end\b)/i, /^(?:left of\b)/i, /^(?:right of\b)/i, /^(?:links\b)/i, /^(?:link\b)/i, /^(?:properties\b)/i, /^(?:details\b)/i, /^(?:over\b)/i, /^(?:note\b)/i, /^(?:activate\b)/i, /^(?:deactivate\b)/i, /^(?:title\s[^#\n;]+)/i, /^(?:title:\s[^#\n;]+)/i, /^(?:accTitle\s*:\s*)/i, /^(?:(?!\n||)*[^\n]*)/i, /^(?:accDescr\s*:\s*)/i, /^(?:(?!\n||)*[^\n]*)/i, /^(?:accDescr\s*\{\s*)/i, /^(?:[\}])/i, /^(?:[^\}]*)/i, /^(?:sequenceDiagram\b)/i, /^(?:autonumber\b)/i, /^(?:off\b)/i, /^(?:,)/i, /^(?:;)/i, /^(?:[^+<\->\->:\n,;]+((?!(-x|--x|-\)|--\)))[\-]*[^\+<\->\->:\n,;]+)*)/i, /^(?:->>)/i, /^(?:<<->>)/i, /^(?:-->>)/i, /^(?:<<-->>)/i, /^(?:->)/i, /^(?:-->)/i, /^(?:-[x])/i, /^(?:--[x])/i, /^(?:-[\)])/i, /^(?:--[\)])/i, /^(?::(?:(?:no)?wrap)?[^#\n;]*)/i, /^(?::)/i, /^(?:\+)/i, /^(?:-)/i, /^(?:$)/i, /^(?:.)/i],
      conditions: { acc_descr_multiline: { rules: [45, 46], inclusive: !1 }, acc_descr: { rules: [43], inclusive: !1 }, acc_title: { rules: [41], inclusive: !1 }, ID: { rules: [2, 3, 12], inclusive: !1 }, ALIAS: { rules: [2, 3, 13, 14], inclusive: !1 }, LINE: { rules: [2, 3, 26], inclusive: !1 }, INITIAL: { rules: [0, 1, 3, 4, 5, 6, 7, 8, 9, 10, 11, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 42, 44, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68], inclusive: !0 } }
    };
    return ht;
  }();
  Nt.lexer = de;
  function mt() {
    this.yy = {};
  }
  return u(mt, "Parser"), mt.prototype = Nt, Nt.Parser = mt, new mt();
}();
Ot.parser = Ot;
var Me = Ot, Re = {
  SOLID: 0,
  DOTTED: 1,
  NOTE: 2,
  SOLID_CROSS: 3,
  DOTTED_CROSS: 4,
  SOLID_OPEN: 5,
  DOTTED_OPEN: 6,
  LOOP_START: 10,
  LOOP_END: 11,
  ALT_START: 12,
  ALT_ELSE: 13,
  ALT_END: 14,
  OPT_START: 15,
  OPT_END: 16,
  ACTIVE_START: 17,
  ACTIVE_END: 18,
  PAR_START: 19,
  PAR_AND: 20,
  PAR_END: 21,
  RECT_START: 22,
  RECT_END: 23,
  SOLID_POINT: 24,
  DOTTED_POINT: 25,
  AUTONUMBER: 26,
  CRITICAL_START: 27,
  CRITICAL_OPTION: 28,
  CRITICAL_END: 29,
  BREAK_START: 30,
  BREAK_END: 31,
  PAR_OVER_START: 32,
  BIDIRECTIONAL_SOLID: 33,
  BIDIRECTIONAL_DOTTED: 34
}, De = {
  FILLED: 0,
  OPEN: 1
}, Ce = {
  LEFTOF: 0,
  RIGHTOF: 1,
  OVER: 2
}, Tt, Oe = (Tt = class {
  constructor() {
    this.state = new be(() => ({
      prevActor: void 0,
      actors: /* @__PURE__ */ new Map(),
      createdActors: /* @__PURE__ */ new Map(),
      destroyedActors: /* @__PURE__ */ new Map(),
      boxes: [],
      messages: [],
      notes: [],
      sequenceNumbersEnabled: !1,
      wrapEnabled: void 0,
      currentBox: void 0,
      lastCreated: void 0,
      lastDestroyed: void 0
    })), this.setAccTitle = Gt, this.setAccDescription = Ie, this.setDiagramTitle = Le, this.getAccTitle = _e, this.getAccDescription = Pe, this.getDiagramTitle = Ae, this.apply = this.apply.bind(this), this.parseBoxData = this.parseBoxData.bind(this), this.parseMessage = this.parseMessage.bind(this), this.clear(), this.setWrap($().wrap), this.LINETYPE = Re, this.ARROWTYPE = De, this.PLACEMENT = Ce;
  }
  addBox(t) {
    this.state.records.boxes.push({
      name: t.text,
      wrap: t.wrap ?? this.autoWrap(),
      fill: t.color,
      actorKeys: []
    }), this.state.records.currentBox = this.state.records.boxes.slice(-1)[0];
  }
  addActor(t, o, s, a) {
    let i = this.state.records.currentBox;
    const n = this.state.records.actors.get(t);
    if (n) {
      if (this.state.records.currentBox && n.box && this.state.records.currentBox !== n.box)
        throw new Error(
          `A same participant should only be defined in one Box: ${n.name} can't be in '${n.box.name}' and in '${this.state.records.currentBox.name}' at the same time.`
        );
      if (i = n.box ? n.box : this.state.records.currentBox, n.box = i, n && o === n.name && s == null)
        return;
    }
    if ((s == null ? void 0 : s.text) == null && (s = { text: o, type: a }), (a == null || s.text == null) && (s = { text: o, type: a }), this.state.records.actors.set(t, {
      box: i,
      name: o,
      description: s.text,
      wrap: s.wrap ?? this.autoWrap(),
      prevActor: this.state.records.prevActor,
      links: {},
      properties: {},
      actorCnt: null,
      rectData: null,
      type: a ?? "participant"
    }), this.state.records.prevActor) {
      const h = this.state.records.actors.get(this.state.records.prevActor);
      h && (h.nextActor = t);
    }
    this.state.records.currentBox && this.state.records.currentBox.actorKeys.push(t), this.state.records.prevActor = t;
  }
  activationCount(t) {
    let o, s = 0;
    if (!t)
      return 0;
    for (o = 0; o < this.state.records.messages.length; o++)
      this.state.records.messages[o].type === this.LINETYPE.ACTIVE_START && this.state.records.messages[o].from === t && s++, this.state.records.messages[o].type === this.LINETYPE.ACTIVE_END && this.state.records.messages[o].from === t && s--;
    return s;
  }
  addMessage(t, o, s, a) {
    this.state.records.messages.push({
      id: this.state.records.messages.length.toString(),
      from: t,
      to: o,
      message: s.text,
      wrap: s.wrap ?? this.autoWrap(),
      answer: a
    });
  }
  addSignal(t, o, s, a, i = !1) {
    if (a === this.LINETYPE.ACTIVE_END && this.activationCount(t ?? "") < 1) {
      const h = new Error("Trying to inactivate an inactive participant (" + t + ")");
      throw h.hash = {
        text: "->>-",
        token: "->>-",
        line: "1",
        loc: { first_line: 1, last_line: 1, first_column: 1, last_column: 1 },
        expected: ["'ACTIVE_PARTICIPANT'"]
      }, h;
    }
    return this.state.records.messages.push({
      id: this.state.records.messages.length.toString(),
      from: t,
      to: o,
      message: (s == null ? void 0 : s.text) ?? "",
      wrap: (s == null ? void 0 : s.wrap) ?? this.autoWrap(),
      type: a,
      activate: i
    }), !0;
  }
  hasAtLeastOneBox() {
    return this.state.records.boxes.length > 0;
  }
  hasAtLeastOneBoxWithTitle() {
    return this.state.records.boxes.some((t) => t.name);
  }
  getMessages() {
    return this.state.records.messages;
  }
  getBoxes() {
    return this.state.records.boxes;
  }
  getActors() {
    return this.state.records.actors;
  }
  getCreatedActors() {
    return this.state.records.createdActors;
  }
  getDestroyedActors() {
    return this.state.records.destroyedActors;
  }
  getActor(t) {
    return this.state.records.actors.get(t);
  }
  getActorKeys() {
    return [...this.state.records.actors.keys()];
  }
  enableSequenceNumbers() {
    this.state.records.sequenceNumbersEnabled = !0;
  }
  disableSequenceNumbers() {
    this.state.records.sequenceNumbersEnabled = !1;
  }
  showSequenceNumbers() {
    return this.state.records.sequenceNumbersEnabled;
  }
  setWrap(t) {
    this.state.records.wrapEnabled = t;
  }
  extractWrap(t) {
    if (t === void 0)
      return {};
    t = t.trim();
    const o = /^:?wrap:/.exec(t) !== null ? !0 : /^:?nowrap:/.exec(t) !== null ? !1 : void 0;
    return { cleanedText: (o === void 0 ? t : t.replace(/^:?(?:no)?wrap:/, "")).trim(), wrap: o };
  }
  autoWrap() {
    var t;
    return this.state.records.wrapEnabled !== void 0 ? this.state.records.wrapEnabled : ((t = $().sequence) == null ? void 0 : t.wrap) ?? !1;
  }
  clear() {
    this.state.reset(), ke();
  }
  parseMessage(t) {
    const o = t.trim(), { wrap: s, cleanedText: a } = this.extractWrap(o), i = {
      text: a,
      wrap: s
    };
    return G.debug(`parseMessage: ${JSON.stringify(i)}`), i;
  }
  // We expect the box statement to be color first then description
  // The color can be rgb,rgba,hsl,hsla, or css code names  #hex codes are not supported for now because of the way the char # is handled
  // We extract first segment as color, the rest of the line is considered as text
  parseBoxData(t) {
    const o = /^((?:rgba?|hsla?)\s*\(.*\)|\w*)(.*)$/.exec(t);
    let s = o != null && o[1] ? o[1].trim() : "transparent", a = o != null && o[2] ? o[2].trim() : void 0;
    if (window != null && window.CSS)
      window.CSS.supports("color", s) || (s = "transparent", a = t.trim());
    else {
      const h = new Option().style;
      h.color = s, h.color !== s && (s = "transparent", a = t.trim());
    }
    const { wrap: i, cleanedText: n } = this.extractWrap(a);
    return {
      text: n ? _t(n, $()) : void 0,
      color: s,
      wrap: i
    };
  }
  addNote(t, o, s) {
    const a = {
      actor: t,
      placement: o,
      message: s.text,
      wrap: s.wrap ?? this.autoWrap()
    }, i = [].concat(t, t);
    this.state.records.notes.push(a), this.state.records.messages.push({
      id: this.state.records.messages.length.toString(),
      from: i[0],
      to: i[1],
      message: s.text,
      wrap: s.wrap ?? this.autoWrap(),
      type: this.LINETYPE.NOTE,
      placement: o
    });
  }
  addLinks(t, o) {
    const s = this.getActor(t);
    try {
      let a = _t(o.text, $());
      a = a.replace(/&equals;/g, "="), a = a.replace(/&amp;/g, "&");
      const i = JSON.parse(a);
      this.insertLinks(s, i);
    } catch (a) {
      G.error("error while parsing actor link text", a);
    }
  }
  addALink(t, o) {
    const s = this.getActor(t);
    try {
      const a = {};
      let i = _t(o.text, $());
      const n = i.indexOf("@");
      i = i.replace(/&equals;/g, "="), i = i.replace(/&amp;/g, "&");
      const h = i.slice(0, n - 1).trim(), d = i.slice(n + 1).trim();
      a[h] = d, this.insertLinks(s, a);
    } catch (a) {
      G.error("error while parsing actor link text", a);
    }
  }
  insertLinks(t, o) {
    if (t.links == null)
      t.links = o;
    else
      for (const s in o)
        t.links[s] = o[s];
  }
  addProperties(t, o) {
    const s = this.getActor(t);
    try {
      const a = _t(o.text, $()), i = JSON.parse(a);
      this.insertProperties(s, i);
    } catch (a) {
      G.error("error while parsing actor properties text", a);
    }
  }
  insertProperties(t, o) {
    if (t.properties == null)
      t.properties = o;
    else
      for (const s in o)
        t.properties[s] = o[s];
  }
  boxEnd() {
    this.state.records.currentBox = void 0;
  }
  addDetails(t, o) {
    const s = this.getActor(t), a = document.getElementById(o.text);
    try {
      const i = a.innerHTML, n = JSON.parse(i);
      n.properties && this.insertProperties(s, n.properties), n.links && this.insertLinks(s, n.links);
    } catch (i) {
      G.error("error while parsing actor details text", i);
    }
  }
  getActorProperty(t, o) {
    if ((t == null ? void 0 : t.properties) !== void 0)
      return t.properties[o];
  }
  // eslint-disable-next-line @typescript-eslint/no-explicit-any, @typescript-eslint/no-redundant-type-constituents
  apply(t) {
    if (Array.isArray(t))
      t.forEach((o) => {
        this.apply(o);
      });
    else
      switch (t.type) {
        case "sequenceIndex":
          this.state.records.messages.push({
            id: this.state.records.messages.length.toString(),
            from: void 0,
            to: void 0,
            message: {
              start: t.sequenceIndex,
              step: t.sequenceIndexStep,
              visible: t.sequenceVisible
            },
            wrap: !1,
            type: t.signalType
          });
          break;
        case "addParticipant":
          this.addActor(t.actor, t.actor, t.description, t.draw);
          break;
        case "createParticipant":
          if (this.state.records.actors.has(t.actor))
            throw new Error(
              "It is not possible to have actors with the same id, even if one is destroyed before the next is created. Use 'AS' aliases to simulate the behavior"
            );
          this.state.records.lastCreated = t.actor, this.addActor(t.actor, t.actor, t.description, t.draw), this.state.records.createdActors.set(t.actor, this.state.records.messages.length);
          break;
        case "destroyParticipant":
          this.state.records.lastDestroyed = t.actor, this.state.records.destroyedActors.set(t.actor, this.state.records.messages.length);
          break;
        case "activeStart":
          this.addSignal(t.actor, void 0, void 0, t.signalType);
          break;
        case "activeEnd":
          this.addSignal(t.actor, void 0, void 0, t.signalType);
          break;
        case "addNote":
          this.addNote(t.actor, t.placement, t.text);
          break;
        case "addLinks":
          this.addLinks(t.actor, t.text);
          break;
        case "addALink":
          this.addALink(t.actor, t.text);
          break;
        case "addProperties":
          this.addProperties(t.actor, t.text);
          break;
        case "addDetails":
          this.addDetails(t.actor, t.text);
          break;
        case "addMessage":
          if (this.state.records.lastCreated) {
            if (t.to !== this.state.records.lastCreated)
              throw new Error(
                "The created participant " + this.state.records.lastCreated.name + " does not have an associated creating message after its declaration. Please check the sequence diagram."
              );
            this.state.records.lastCreated = void 0;
          } else if (this.state.records.lastDestroyed) {
            if (t.to !== this.state.records.lastDestroyed && t.from !== this.state.records.lastDestroyed)
              throw new Error(
                "The destroyed participant " + this.state.records.lastDestroyed.name + " does not have an associated destroying message after its declaration. Please check the sequence diagram."
              );
            this.state.records.lastDestroyed = void 0;
          }
          this.addSignal(t.from, t.to, t.msg, t.signalType, t.activate);
          break;
        case "boxStart":
          this.addBox(t.boxData);
          break;
        case "boxEnd":
          this.boxEnd();
          break;
        case "loopStart":
          this.addSignal(void 0, void 0, t.loopText, t.signalType);
          break;
        case "loopEnd":
          this.addSignal(void 0, void 0, void 0, t.signalType);
          break;
        case "rectStart":
          this.addSignal(void 0, void 0, t.color, t.signalType);
          break;
        case "rectEnd":
          this.addSignal(void 0, void 0, void 0, t.signalType);
          break;
        case "optStart":
          this.addSignal(void 0, void 0, t.optText, t.signalType);
          break;
        case "optEnd":
          this.addSignal(void 0, void 0, void 0, t.signalType);
          break;
        case "altStart":
          this.addSignal(void 0, void 0, t.altText, t.signalType);
          break;
        case "else":
          this.addSignal(void 0, void 0, t.altText, t.signalType);
          break;
        case "altEnd":
          this.addSignal(void 0, void 0, void 0, t.signalType);
          break;
        case "setAccTitle":
          Gt(t.text);
          break;
        case "parStart":
          this.addSignal(void 0, void 0, t.parText, t.signalType);
          break;
        case "and":
          this.addSignal(void 0, void 0, t.parText, t.signalType);
          break;
        case "parEnd":
          this.addSignal(void 0, void 0, void 0, t.signalType);
          break;
        case "criticalStart":
          this.addSignal(void 0, void 0, t.criticalText, t.signalType);
          break;
        case "option":
          this.addSignal(void 0, void 0, t.optionText, t.signalType);
          break;
        case "criticalEnd":
          this.addSignal(void 0, void 0, void 0, t.signalType);
          break;
        case "breakStart":
          this.addSignal(void 0, void 0, t.breakText, t.signalType);
          break;
        case "breakEnd":
          this.addSignal(void 0, void 0, void 0, t.signalType);
          break;
      }
  }
  getConfig() {
    return $().sequence;
  }
}, u(Tt, "SequenceDB"), Tt), Be = /* @__PURE__ */ u((e) => `.actor {
    stroke: ${e.actorBorder};
    fill: ${e.actorBkg};
  }

  text.actor > tspan {
    fill: ${e.actorTextColor};
    stroke: none;
  }

  .actor-line {
    stroke: ${e.actorLineColor};
  }

  .messageLine0 {
    stroke-width: 1.5;
    stroke-dasharray: none;
    stroke: ${e.signalColor};
  }

  .messageLine1 {
    stroke-width: 1.5;
    stroke-dasharray: 2, 2;
    stroke: ${e.signalColor};
  }

  #arrowhead path {
    fill: ${e.signalColor};
    stroke: ${e.signalColor};
  }

  .sequenceNumber {
    fill: ${e.sequenceNumberColor};
  }

  #sequencenumber {
    fill: ${e.signalColor};
  }

  #crosshead path {
    fill: ${e.signalColor};
    stroke: ${e.signalColor};
  }

  .messageText {
    fill: ${e.signalTextColor};
    stroke: none;
  }

  .labelBox {
    stroke: ${e.labelBoxBorderColor};
    fill: ${e.labelBoxBkgColor};
  }

  .labelText, .labelText > tspan {
    fill: ${e.labelTextColor};
    stroke: none;
  }

  .loopText, .loopText > tspan {
    fill: ${e.loopTextColor};
    stroke: none;
  }

  .loopLine {
    stroke-width: 2px;
    stroke-dasharray: 2, 2;
    stroke: ${e.labelBoxBorderColor};
    fill: ${e.labelBoxBorderColor};
  }

  .note {
    //stroke: #decc93;
    stroke: ${e.noteBorderColor};
    fill: ${e.noteBkgColor};
  }

  .noteText, .noteText > tspan {
    fill: ${e.noteTextColor};
    stroke: none;
  }

  .activation0 {
    fill: ${e.activationBkgColor};
    stroke: ${e.activationBorderColor};
  }

  .activation1 {
    fill: ${e.activationBkgColor};
    stroke: ${e.activationBorderColor};
  }

  .activation2 {
    fill: ${e.activationBkgColor};
    stroke: ${e.activationBorderColor};
  }

  .actorPopupMenu {
    position: absolute;
  }

  .actorPopupMenuPanel {
    position: absolute;
    fill: ${e.actorBkg};
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    filter: drop-shadow(3px 5px 2px rgb(0 0 0 / 0.4));
}
  .actor-man line {
    stroke: ${e.actorBorder};
    fill: ${e.actorBkg};
  }
  .actor-man circle, line {
    stroke: ${e.actorBorder};
    fill: ${e.actorBkg};
    stroke-width: 2px;
  }
`, "getStyles"), Ve = Be, ut = 18 * 2, $t = "actor-top", te = "actor-bottom", Ye = "actor-box", Xt = "actor-man", Wt = /* @__PURE__ */ u(function(e, t) {
  return Te(e, t);
}, "drawRect"), We = /* @__PURE__ */ u(function(e, t, o, s, a) {
  if (t.links === void 0 || t.links === null || Object.keys(t.links).length === 0)
    return { height: 0, width: 0 };
  const i = t.links, n = t.actorCnt, h = t.rectData;
  var d = "none";
  a && (d = "block !important");
  const r = e.append("g");
  r.attr("id", "actor" + n + "_popup"), r.attr("class", "actorPopupMenu"), r.attr("display", d);
  var f = "";
  h.class !== void 0 && (f = " " + h.class);
  let y = h.width > o ? h.width : o;
  const g = r.append("rect");
  if (g.attr("class", "actorPopupMenuPanel" + f), g.attr("x", h.x), g.attr("y", h.height), g.attr("fill", h.fill), g.attr("stroke", h.stroke), g.attr("width", y), g.attr("height", h.height), g.attr("rx", h.rx), g.attr("ry", h.ry), i != null) {
    var T = 20;
    for (let A in i) {
      var m = r.append("a"), v = Qt(i[A]);
      m.attr("xlink:href", v), m.attr("target", "_blank"), as(s)(
        A,
        m,
        h.x + 10,
        h.height + T,
        y,
        20,
        { class: "actor" },
        s
      ), T += 30;
    }
  }
  return g.attr("height", T), { height: h.height + T, width: y };
}, "drawPopup"), Fe = /* @__PURE__ */ u(function(e) {
  return "var pu = document.getElementById('" + e + "'); if (pu != null) { pu.style.display = pu.style.display == 'block' ? 'none' : 'block'; }";
}, "popupMenuToggle"), Pt = /* @__PURE__ */ u(async function(e, t, o = null) {
  let s = e.append("foreignObject");
  const a = await jt(t.text, Ct()), n = s.append("xhtml:div").attr("style", "width: fit-content;").attr("xmlns", "http://www.w3.org/1999/xhtml").html(a).node().getBoundingClientRect();
  if (s.attr("height", Math.round(n.height)).attr("width", Math.round(n.width)), t.class === "noteText") {
    const h = e.node().firstChild;
    h.setAttribute("height", n.height + 2 * t.textMargin);
    const d = h.getBBox();
    s.attr("x", Math.round(d.x + d.width / 2 - n.width / 2)).attr("y", Math.round(d.y + d.height / 2 - n.height / 2));
  } else if (o) {
    let { startx: h, stopx: d, starty: r } = o;
    if (h > d) {
      const f = h;
      h = d, d = f;
    }
    s.attr("x", Math.round(h + Math.abs(h - d) / 2 - n.width / 2)), t.class === "loopText" ? s.attr("y", Math.round(r)) : s.attr("y", Math.round(r - n.height));
  }
  return [s];
}, "drawKatex"), Et = /* @__PURE__ */ u(function(e, t) {
  let o = 0, s = 0;
  const a = t.text.split(I.lineBreakRegex), [i, n] = Zt(t.fontSize);
  let h = [], d = 0, r = /* @__PURE__ */ u(() => t.y, "yfunc");
  if (t.valign !== void 0 && t.textMargin !== void 0 && t.textMargin > 0)
    switch (t.valign) {
      case "top":
      case "start":
        r = /* @__PURE__ */ u(() => Math.round(t.y + t.textMargin), "yfunc");
        break;
      case "middle":
      case "center":
        r = /* @__PURE__ */ u(() => Math.round(t.y + (o + s + t.textMargin) / 2), "yfunc");
        break;
      case "bottom":
      case "end":
        r = /* @__PURE__ */ u(() => Math.round(
          t.y + (o + s + 2 * t.textMargin) - t.textMargin
        ), "yfunc");
        break;
    }
  if (t.anchor !== void 0 && t.textMargin !== void 0 && t.width !== void 0)
    switch (t.anchor) {
      case "left":
      case "start":
        t.x = Math.round(t.x + t.textMargin), t.anchor = "start", t.dominantBaseline = "middle", t.alignmentBaseline = "middle";
        break;
      case "middle":
      case "center":
        t.x = Math.round(t.x + t.width / 2), t.anchor = "middle", t.dominantBaseline = "middle", t.alignmentBaseline = "middle";
        break;
      case "right":
      case "end":
        t.x = Math.round(t.x + t.width - t.textMargin), t.anchor = "end", t.dominantBaseline = "middle", t.alignmentBaseline = "middle";
        break;
    }
  for (let [f, y] of a.entries()) {
    t.textMargin !== void 0 && t.textMargin === 0 && i !== void 0 && (d = f * i);
    const g = e.append("text");
    g.attr("x", t.x), g.attr("y", r()), t.anchor !== void 0 && g.attr("text-anchor", t.anchor).attr("dominant-baseline", t.dominantBaseline).attr("alignment-baseline", t.alignmentBaseline), t.fontFamily !== void 0 && g.style("font-family", t.fontFamily), n !== void 0 && g.style("font-size", n), t.fontWeight !== void 0 && g.style("font-weight", t.fontWeight), t.fill !== void 0 && g.attr("fill", t.fill), t.class !== void 0 && g.attr("class", t.class), t.dy !== void 0 ? g.attr("dy", t.dy) : d !== 0 && g.attr("dy", d);
    const T = y || Ne;
    if (t.tspan) {
      const m = g.append("tspan");
      m.attr("x", t.x), t.fill !== void 0 && m.attr("fill", t.fill), m.text(T);
    } else
      g.text(T);
    t.valign !== void 0 && t.textMargin !== void 0 && t.textMargin > 0 && (s += (g._groups || g)[0][0].getBBox().height, o = s), h.push(g);
  }
  return h;
}, "drawText"), ee = /* @__PURE__ */ u(function(e, t) {
  function o(a, i, n, h, d) {
    return a + "," + i + " " + (a + n) + "," + i + " " + (a + n) + "," + (i + h - d) + " " + (a + n - d * 1.2) + "," + (i + h) + " " + a + "," + (i + h);
  }
  u(o, "genPoints");
  const s = e.append("polygon");
  return s.attr("points", o(t.x, t.y, t.width, t.height, 7)), s.attr("class", "labelBox"), t.y = t.y + t.height / 2, Et(e, t), s;
}, "drawLabel"), nt = -1, se = /* @__PURE__ */ u((e, t, o, s) => {
  e.select && o.forEach((a) => {
    const i = t.get(a), n = e.select("#actor" + i.actorCnt);
    !s.mirrorActors && i.stopy ? n.attr("y2", i.stopy + i.height / 2) : s.mirrorActors && n.attr("y2", i.stopy);
  });
}, "fixLifeLineHeights"), qe = /* @__PURE__ */ u(function(e, t, o, s) {
  var T, m;
  const a = s ? t.stopy : t.starty, i = t.x + t.width / 2, n = a + t.height, h = e.append("g").lower();
  var d = h;
  s || (nt++, Object.keys(t.links || {}).length && !o.forceMenus && d.attr("onclick", Fe(`actor${nt}_popup`)).attr("cursor", "pointer"), d.append("line").attr("id", "actor" + nt).attr("x1", i).attr("y1", n).attr("x2", i).attr("y2", 2e3).attr("class", "actor-line 200").attr("stroke-width", "0.5px").attr("stroke", "#999").attr("name", t.name), d = h.append("g"), t.actorCnt = nt, t.links != null && d.attr("id", "root-" + nt));
  const r = At();
  var f = "actor";
  (T = t.properties) != null && T.class ? f = t.properties.class : r.fill = "#eaeaea", s ? f += ` ${te}` : f += ` ${$t}`, r.x = t.x, r.y = a, r.width = t.width, r.height = t.height, r.class = f, r.rx = 3, r.ry = 3, r.name = t.name;
  const y = Wt(d, r);
  if (t.rectData = r, (m = t.properties) != null && m.icon) {
    const v = t.properties.icon.trim();
    v.charAt(0) === "@" ? Ee(d, r.x + r.width - 20, r.y + 10, v.substr(1)) : ye(d, r.x + r.width - 20, r.y + 10, v);
  }
  Ft(o, ot(t.description))(
    t.description,
    d,
    r.x,
    r.y,
    r.width,
    r.height,
    { class: `actor ${Ye}` },
    o
  );
  let g = t.height;
  if (y.node) {
    const v = y.node().getBBox();
    t.height = v.height, g = v.height;
  }
  return g;
}, "drawActorTypeParticipant"), ze = /* @__PURE__ */ u(function(e, t, o, s) {
  const a = s ? t.stopy : t.starty, i = t.x + t.width / 2, n = a + 80, h = e.append("g").lower();
  s || (nt++, h.append("line").attr("id", "actor" + nt).attr("x1", i).attr("y1", n).attr("x2", i).attr("y2", 2e3).attr("class", "actor-line 200").attr("stroke-width", "0.5px").attr("stroke", "#999").attr("name", t.name), t.actorCnt = nt);
  const d = e.append("g");
  let r = Xt;
  s ? r += ` ${te}` : r += ` ${$t}`, d.attr("class", r), d.attr("name", t.name);
  const f = At();
  f.x = t.x, f.y = a, f.fill = "#eaeaea", f.width = t.width, f.height = t.height, f.class = "actor", f.rx = 3, f.ry = 3, d.append("line").attr("id", "actor-man-torso" + nt).attr("x1", i).attr("y1", a + 25).attr("x2", i).attr("y2", a + 45), d.append("line").attr("id", "actor-man-arms" + nt).attr("x1", i - ut / 2).attr("y1", a + 33).attr("x2", i + ut / 2).attr("y2", a + 33), d.append("line").attr("x1", i - ut / 2).attr("y1", a + 60).attr("x2", i).attr("y2", a + 45), d.append("line").attr("x1", i).attr("y1", a + 45).attr("x2", i + ut / 2 - 2).attr("y2", a + 60);
  const y = d.append("circle");
  y.attr("cx", t.x + t.width / 2), y.attr("cy", a + 10), y.attr("r", 15), y.attr("width", t.width), y.attr("height", t.height);
  const g = d.node().getBBox();
  return t.height = g.height, Ft(o, ot(t.description))(
    t.description,
    d,
    f.x,
    f.y + 35,
    f.width,
    f.height,
    { class: `actor ${Xt}` },
    o
  ), t.height;
}, "drawActorTypeActor"), He = /* @__PURE__ */ u(async function(e, t, o, s) {
  switch (t.type) {
    case "actor":
      return await ze(e, t, o, s);
    case "participant":
      return await qe(e, t, o, s);
  }
}, "drawActor"), Ue = /* @__PURE__ */ u(function(e, t, o) {
  const a = e.append("g");
  ae(a, t), t.name && Ft(o)(
    t.name,
    a,
    t.x,
    t.y + o.boxTextMargin + (t.textMaxHeight || 0) / 2,
    t.width,
    0,
    { class: "text" },
    o
  ), a.lower();
}, "drawBox"), Ke = /* @__PURE__ */ u(function(e) {
  return e.append("g");
}, "anchorElement"), Ge = /* @__PURE__ */ u(function(e, t, o, s, a) {
  const i = At(), n = t.anchored;
  i.x = t.startx, i.y = t.starty, i.class = "activation" + a % 3, i.width = t.stopx - t.startx, i.height = o - t.starty, Wt(n, i);
}, "drawActivation"), Xe = /* @__PURE__ */ u(async function(e, t, o, s) {
  const {
    boxMargin: a,
    boxTextMargin: i,
    labelBoxHeight: n,
    labelBoxWidth: h,
    messageFontFamily: d,
    messageFontSize: r,
    messageFontWeight: f
  } = s, y = e.append("g"), g = /* @__PURE__ */ u(function(v, A, C, S) {
    return y.append("line").attr("x1", v).attr("y1", A).attr("x2", C).attr("y2", S).attr("class", "loopLine");
  }, "drawLoopLine");
  g(t.startx, t.starty, t.stopx, t.starty), g(t.stopx, t.starty, t.stopx, t.stopy), g(t.startx, t.stopy, t.stopx, t.stopy), g(t.startx, t.starty, t.startx, t.stopy), t.sections !== void 0 && t.sections.forEach(function(v) {
    g(t.startx, v.y, t.stopx, v.y).style(
      "stroke-dasharray",
      "3, 3"
    );
  });
  let T = Yt();
  T.text = o, T.x = t.startx, T.y = t.starty, T.fontFamily = d, T.fontSize = r, T.fontWeight = f, T.anchor = "middle", T.valign = "middle", T.tspan = !1, T.width = h || 50, T.height = n || 20, T.textMargin = i, T.class = "labelText", ee(y, T), T = re(), T.text = t.title, T.x = t.startx + h / 2 + (t.stopx - t.startx) / 2, T.y = t.starty + a + i, T.anchor = "middle", T.valign = "middle", T.textMargin = i, T.class = "loopText", T.fontFamily = d, T.fontSize = r, T.fontWeight = f, T.wrap = !0;
  let m = ot(T.text) ? await Pt(y, T, t) : Et(y, T);
  if (t.sectionTitles !== void 0) {
    for (const [v, A] of Object.entries(t.sectionTitles))
      if (A.message) {
        T.text = A.message, T.x = t.startx + (t.stopx - t.startx) / 2, T.y = t.sections[v].y + a + i, T.class = "loopText", T.anchor = "middle", T.valign = "middle", T.tspan = !1, T.fontFamily = d, T.fontSize = r, T.fontWeight = f, T.wrap = t.wrap, ot(T.text) ? (t.starty = t.sections[v].y, await Pt(y, T, t)) : Et(y, T);
        let C = Math.round(
          m.map((S) => (S._groups || S)[0][0].getBBox().height).reduce((S, B) => S + B)
        );
        t.sections[v].height += C - (a + i);
      }
  }
  return t.height = Math.round(t.stopy - t.starty), y;
}, "drawLoop"), ae = /* @__PURE__ */ u(function(e, t) {
  xe(e, t);
}, "drawBackgroundRect"), Je = /* @__PURE__ */ u(function(e) {
  e.append("defs").append("symbol").attr("id", "database").attr("fill-rule", "evenodd").attr("clip-rule", "evenodd").append("path").attr("transform", "scale(.5)").attr(
    "d",
    "M12.258.001l.256.004.255.005.253.008.251.01.249.012.247.015.246.016.242.019.241.02.239.023.236.024.233.027.231.028.229.031.225.032.223.034.22.036.217.038.214.04.211.041.208.043.205.045.201.046.198.048.194.05.191.051.187.053.183.054.18.056.175.057.172.059.168.06.163.061.16.063.155.064.15.066.074.033.073.033.071.034.07.034.069.035.068.035.067.035.066.035.064.036.064.036.062.036.06.036.06.037.058.037.058.037.055.038.055.038.053.038.052.038.051.039.05.039.048.039.047.039.045.04.044.04.043.04.041.04.04.041.039.041.037.041.036.041.034.041.033.042.032.042.03.042.029.042.027.042.026.043.024.043.023.043.021.043.02.043.018.044.017.043.015.044.013.044.012.044.011.045.009.044.007.045.006.045.004.045.002.045.001.045v17l-.001.045-.002.045-.004.045-.006.045-.007.045-.009.044-.011.045-.012.044-.013.044-.015.044-.017.043-.018.044-.02.043-.021.043-.023.043-.024.043-.026.043-.027.042-.029.042-.03.042-.032.042-.033.042-.034.041-.036.041-.037.041-.039.041-.04.041-.041.04-.043.04-.044.04-.045.04-.047.039-.048.039-.05.039-.051.039-.052.038-.053.038-.055.038-.055.038-.058.037-.058.037-.06.037-.06.036-.062.036-.064.036-.064.036-.066.035-.067.035-.068.035-.069.035-.07.034-.071.034-.073.033-.074.033-.15.066-.155.064-.16.063-.163.061-.168.06-.172.059-.175.057-.18.056-.183.054-.187.053-.191.051-.194.05-.198.048-.201.046-.205.045-.208.043-.211.041-.214.04-.217.038-.22.036-.223.034-.225.032-.229.031-.231.028-.233.027-.236.024-.239.023-.241.02-.242.019-.246.016-.247.015-.249.012-.251.01-.253.008-.255.005-.256.004-.258.001-.258-.001-.256-.004-.255-.005-.253-.008-.251-.01-.249-.012-.247-.015-.245-.016-.243-.019-.241-.02-.238-.023-.236-.024-.234-.027-.231-.028-.228-.031-.226-.032-.223-.034-.22-.036-.217-.038-.214-.04-.211-.041-.208-.043-.204-.045-.201-.046-.198-.048-.195-.05-.19-.051-.187-.053-.184-.054-.179-.056-.176-.057-.172-.059-.167-.06-.164-.061-.159-.063-.155-.064-.151-.066-.074-.033-.072-.033-.072-.034-.07-.034-.069-.035-.068-.035-.067-.035-.066-.035-.064-.036-.063-.036-.062-.036-.061-.036-.06-.037-.058-.037-.057-.037-.056-.038-.055-.038-.053-.038-.052-.038-.051-.039-.049-.039-.049-.039-.046-.039-.046-.04-.044-.04-.043-.04-.041-.04-.04-.041-.039-.041-.037-.041-.036-.041-.034-.041-.033-.042-.032-.042-.03-.042-.029-.042-.027-.042-.026-.043-.024-.043-.023-.043-.021-.043-.02-.043-.018-.044-.017-.043-.015-.044-.013-.044-.012-.044-.011-.045-.009-.044-.007-.045-.006-.045-.004-.045-.002-.045-.001-.045v-17l.001-.045.002-.045.004-.045.006-.045.007-.045.009-.044.011-.045.012-.044.013-.044.015-.044.017-.043.018-.044.02-.043.021-.043.023-.043.024-.043.026-.043.027-.042.029-.042.03-.042.032-.042.033-.042.034-.041.036-.041.037-.041.039-.041.04-.041.041-.04.043-.04.044-.04.046-.04.046-.039.049-.039.049-.039.051-.039.052-.038.053-.038.055-.038.056-.038.057-.037.058-.037.06-.037.061-.036.062-.036.063-.036.064-.036.066-.035.067-.035.068-.035.069-.035.07-.034.072-.034.072-.033.074-.033.151-.066.155-.064.159-.063.164-.061.167-.06.172-.059.176-.057.179-.056.184-.054.187-.053.19-.051.195-.05.198-.048.201-.046.204-.045.208-.043.211-.041.214-.04.217-.038.22-.036.223-.034.226-.032.228-.031.231-.028.234-.027.236-.024.238-.023.241-.02.243-.019.245-.016.247-.015.249-.012.251-.01.253-.008.255-.005.256-.004.258-.001.258.001zm-9.258 20.499v.01l.001.021.003.021.004.022.005.021.006.022.007.022.009.023.01.022.011.023.012.023.013.023.015.023.016.024.017.023.018.024.019.024.021.024.022.025.023.024.024.025.052.049.056.05.061.051.066.051.07.051.075.051.079.052.084.052.088.052.092.052.097.052.102.051.105.052.11.052.114.051.119.051.123.051.127.05.131.05.135.05.139.048.144.049.147.047.152.047.155.047.16.045.163.045.167.043.171.043.176.041.178.041.183.039.187.039.19.037.194.035.197.035.202.033.204.031.209.03.212.029.216.027.219.025.222.024.226.021.23.02.233.018.236.016.24.015.243.012.246.01.249.008.253.005.256.004.259.001.26-.001.257-.004.254-.005.25-.008.247-.011.244-.012.241-.014.237-.016.233-.018.231-.021.226-.021.224-.024.22-.026.216-.027.212-.028.21-.031.205-.031.202-.034.198-.034.194-.036.191-.037.187-.039.183-.04.179-.04.175-.042.172-.043.168-.044.163-.045.16-.046.155-.046.152-.047.148-.048.143-.049.139-.049.136-.05.131-.05.126-.05.123-.051.118-.052.114-.051.11-.052.106-.052.101-.052.096-.052.092-.052.088-.053.083-.051.079-.052.074-.052.07-.051.065-.051.06-.051.056-.05.051-.05.023-.024.023-.025.021-.024.02-.024.019-.024.018-.024.017-.024.015-.023.014-.024.013-.023.012-.023.01-.023.01-.022.008-.022.006-.022.006-.022.004-.022.004-.021.001-.021.001-.021v-4.127l-.077.055-.08.053-.083.054-.085.053-.087.052-.09.052-.093.051-.095.05-.097.05-.1.049-.102.049-.105.048-.106.047-.109.047-.111.046-.114.045-.115.045-.118.044-.12.043-.122.042-.124.042-.126.041-.128.04-.13.04-.132.038-.134.038-.135.037-.138.037-.139.035-.142.035-.143.034-.144.033-.147.032-.148.031-.15.03-.151.03-.153.029-.154.027-.156.027-.158.026-.159.025-.161.024-.162.023-.163.022-.165.021-.166.02-.167.019-.169.018-.169.017-.171.016-.173.015-.173.014-.175.013-.175.012-.177.011-.178.01-.179.008-.179.008-.181.006-.182.005-.182.004-.184.003-.184.002h-.37l-.184-.002-.184-.003-.182-.004-.182-.005-.181-.006-.179-.008-.179-.008-.178-.01-.176-.011-.176-.012-.175-.013-.173-.014-.172-.015-.171-.016-.17-.017-.169-.018-.167-.019-.166-.02-.165-.021-.163-.022-.162-.023-.161-.024-.159-.025-.157-.026-.156-.027-.155-.027-.153-.029-.151-.03-.15-.03-.148-.031-.146-.032-.145-.033-.143-.034-.141-.035-.14-.035-.137-.037-.136-.037-.134-.038-.132-.038-.13-.04-.128-.04-.126-.041-.124-.042-.122-.042-.12-.044-.117-.043-.116-.045-.113-.045-.112-.046-.109-.047-.106-.047-.105-.048-.102-.049-.1-.049-.097-.05-.095-.05-.093-.052-.09-.051-.087-.052-.085-.053-.083-.054-.08-.054-.077-.054v4.127zm0-5.654v.011l.001.021.003.021.004.021.005.022.006.022.007.022.009.022.01.022.011.023.012.023.013.023.015.024.016.023.017.024.018.024.019.024.021.024.022.024.023.025.024.024.052.05.056.05.061.05.066.051.07.051.075.052.079.051.084.052.088.052.092.052.097.052.102.052.105.052.11.051.114.051.119.052.123.05.127.051.131.05.135.049.139.049.144.048.147.048.152.047.155.046.16.045.163.045.167.044.171.042.176.042.178.04.183.04.187.038.19.037.194.036.197.034.202.033.204.032.209.03.212.028.216.027.219.025.222.024.226.022.23.02.233.018.236.016.24.014.243.012.246.01.249.008.253.006.256.003.259.001.26-.001.257-.003.254-.006.25-.008.247-.01.244-.012.241-.015.237-.016.233-.018.231-.02.226-.022.224-.024.22-.025.216-.027.212-.029.21-.03.205-.032.202-.033.198-.035.194-.036.191-.037.187-.039.183-.039.179-.041.175-.042.172-.043.168-.044.163-.045.16-.045.155-.047.152-.047.148-.048.143-.048.139-.05.136-.049.131-.05.126-.051.123-.051.118-.051.114-.052.11-.052.106-.052.101-.052.096-.052.092-.052.088-.052.083-.052.079-.052.074-.051.07-.052.065-.051.06-.05.056-.051.051-.049.023-.025.023-.024.021-.025.02-.024.019-.024.018-.024.017-.024.015-.023.014-.023.013-.024.012-.022.01-.023.01-.023.008-.022.006-.022.006-.022.004-.021.004-.022.001-.021.001-.021v-4.139l-.077.054-.08.054-.083.054-.085.052-.087.053-.09.051-.093.051-.095.051-.097.05-.1.049-.102.049-.105.048-.106.047-.109.047-.111.046-.114.045-.115.044-.118.044-.12.044-.122.042-.124.042-.126.041-.128.04-.13.039-.132.039-.134.038-.135.037-.138.036-.139.036-.142.035-.143.033-.144.033-.147.033-.148.031-.15.03-.151.03-.153.028-.154.028-.156.027-.158.026-.159.025-.161.024-.162.023-.163.022-.165.021-.166.02-.167.019-.169.018-.169.017-.171.016-.173.015-.173.014-.175.013-.175.012-.177.011-.178.009-.179.009-.179.007-.181.007-.182.005-.182.004-.184.003-.184.002h-.37l-.184-.002-.184-.003-.182-.004-.182-.005-.181-.007-.179-.007-.179-.009-.178-.009-.176-.011-.176-.012-.175-.013-.173-.014-.172-.015-.171-.016-.17-.017-.169-.018-.167-.019-.166-.02-.165-.021-.163-.022-.162-.023-.161-.024-.159-.025-.157-.026-.156-.027-.155-.028-.153-.028-.151-.03-.15-.03-.148-.031-.146-.033-.145-.033-.143-.033-.141-.035-.14-.036-.137-.036-.136-.037-.134-.038-.132-.039-.13-.039-.128-.04-.126-.041-.124-.042-.122-.043-.12-.043-.117-.044-.116-.044-.113-.046-.112-.046-.109-.046-.106-.047-.105-.048-.102-.049-.1-.049-.097-.05-.095-.051-.093-.051-.09-.051-.087-.053-.085-.052-.083-.054-.08-.054-.077-.054v4.139zm0-5.666v.011l.001.02.003.022.004.021.005.022.006.021.007.022.009.023.01.022.011.023.012.023.013.023.015.023.016.024.017.024.018.023.019.024.021.025.022.024.023.024.024.025.052.05.056.05.061.05.066.051.07.051.075.052.079.051.084.052.088.052.092.052.097.052.102.052.105.051.11.052.114.051.119.051.123.051.127.05.131.05.135.05.139.049.144.048.147.048.152.047.155.046.16.045.163.045.167.043.171.043.176.042.178.04.183.04.187.038.19.037.194.036.197.034.202.033.204.032.209.03.212.028.216.027.219.025.222.024.226.021.23.02.233.018.236.017.24.014.243.012.246.01.249.008.253.006.256.003.259.001.26-.001.257-.003.254-.006.25-.008.247-.01.244-.013.241-.014.237-.016.233-.018.231-.02.226-.022.224-.024.22-.025.216-.027.212-.029.21-.03.205-.032.202-.033.198-.035.194-.036.191-.037.187-.039.183-.039.179-.041.175-.042.172-.043.168-.044.163-.045.16-.045.155-.047.152-.047.148-.048.143-.049.139-.049.136-.049.131-.051.126-.05.123-.051.118-.052.114-.051.11-.052.106-.052.101-.052.096-.052.092-.052.088-.052.083-.052.079-.052.074-.052.07-.051.065-.051.06-.051.056-.05.051-.049.023-.025.023-.025.021-.024.02-.024.019-.024.018-.024.017-.024.015-.023.014-.024.013-.023.012-.023.01-.022.01-.023.008-.022.006-.022.006-.022.004-.022.004-.021.001-.021.001-.021v-4.153l-.077.054-.08.054-.083.053-.085.053-.087.053-.09.051-.093.051-.095.051-.097.05-.1.049-.102.048-.105.048-.106.048-.109.046-.111.046-.114.046-.115.044-.118.044-.12.043-.122.043-.124.042-.126.041-.128.04-.13.039-.132.039-.134.038-.135.037-.138.036-.139.036-.142.034-.143.034-.144.033-.147.032-.148.032-.15.03-.151.03-.153.028-.154.028-.156.027-.158.026-.159.024-.161.024-.162.023-.163.023-.165.021-.166.02-.167.019-.169.018-.169.017-.171.016-.173.015-.173.014-.175.013-.175.012-.177.01-.178.01-.179.009-.179.007-.181.006-.182.006-.182.004-.184.003-.184.001-.185.001-.185-.001-.184-.001-.184-.003-.182-.004-.182-.006-.181-.006-.179-.007-.179-.009-.178-.01-.176-.01-.176-.012-.175-.013-.173-.014-.172-.015-.171-.016-.17-.017-.169-.018-.167-.019-.166-.02-.165-.021-.163-.023-.162-.023-.161-.024-.159-.024-.157-.026-.156-.027-.155-.028-.153-.028-.151-.03-.15-.03-.148-.032-.146-.032-.145-.033-.143-.034-.141-.034-.14-.036-.137-.036-.136-.037-.134-.038-.132-.039-.13-.039-.128-.041-.126-.041-.124-.041-.122-.043-.12-.043-.117-.044-.116-.044-.113-.046-.112-.046-.109-.046-.106-.048-.105-.048-.102-.048-.1-.05-.097-.049-.095-.051-.093-.051-.09-.052-.087-.052-.085-.053-.083-.053-.08-.054-.077-.054v4.153zm8.74-8.179l-.257.004-.254.005-.25.008-.247.011-.244.012-.241.014-.237.016-.233.018-.231.021-.226.022-.224.023-.22.026-.216.027-.212.028-.21.031-.205.032-.202.033-.198.034-.194.036-.191.038-.187.038-.183.04-.179.041-.175.042-.172.043-.168.043-.163.045-.16.046-.155.046-.152.048-.148.048-.143.048-.139.049-.136.05-.131.05-.126.051-.123.051-.118.051-.114.052-.11.052-.106.052-.101.052-.096.052-.092.052-.088.052-.083.052-.079.052-.074.051-.07.052-.065.051-.06.05-.056.05-.051.05-.023.025-.023.024-.021.024-.02.025-.019.024-.018.024-.017.023-.015.024-.014.023-.013.023-.012.023-.01.023-.01.022-.008.022-.006.023-.006.021-.004.022-.004.021-.001.021-.001.021.001.021.001.021.004.021.004.022.006.021.006.023.008.022.01.022.01.023.012.023.013.023.014.023.015.024.017.023.018.024.019.024.02.025.021.024.023.024.023.025.051.05.056.05.06.05.065.051.07.052.074.051.079.052.083.052.088.052.092.052.096.052.101.052.106.052.11.052.114.052.118.051.123.051.126.051.131.05.136.05.139.049.143.048.148.048.152.048.155.046.16.046.163.045.168.043.172.043.175.042.179.041.183.04.187.038.191.038.194.036.198.034.202.033.205.032.21.031.212.028.216.027.22.026.224.023.226.022.231.021.233.018.237.016.241.014.244.012.247.011.25.008.254.005.257.004.26.001.26-.001.257-.004.254-.005.25-.008.247-.011.244-.012.241-.014.237-.016.233-.018.231-.021.226-.022.224-.023.22-.026.216-.027.212-.028.21-.031.205-.032.202-.033.198-.034.194-.036.191-.038.187-.038.183-.04.179-.041.175-.042.172-.043.168-.043.163-.045.16-.046.155-.046.152-.048.148-.048.143-.048.139-.049.136-.05.131-.05.126-.051.123-.051.118-.051.114-.052.11-.052.106-.052.101-.052.096-.052.092-.052.088-.052.083-.052.079-.052.074-.051.07-.052.065-.051.06-.05.056-.05.051-.05.023-.025.023-.024.021-.024.02-.025.019-.024.018-.024.017-.023.015-.024.014-.023.013-.023.012-.023.01-.023.01-.022.008-.022.006-.023.006-.021.004-.022.004-.021.001-.021.001-.021-.001-.021-.001-.021-.004-.021-.004-.022-.006-.021-.006-.023-.008-.022-.01-.022-.01-.023-.012-.023-.013-.023-.014-.023-.015-.024-.017-.023-.018-.024-.019-.024-.02-.025-.021-.024-.023-.024-.023-.025-.051-.05-.056-.05-.06-.05-.065-.051-.07-.052-.074-.051-.079-.052-.083-.052-.088-.052-.092-.052-.096-.052-.101-.052-.106-.052-.11-.052-.114-.052-.118-.051-.123-.051-.126-.051-.131-.05-.136-.05-.139-.049-.143-.048-.148-.048-.152-.048-.155-.046-.16-.046-.163-.045-.168-.043-.172-.043-.175-.042-.179-.041-.183-.04-.187-.038-.191-.038-.194-.036-.198-.034-.202-.033-.205-.032-.21-.031-.212-.028-.216-.027-.22-.026-.224-.023-.226-.022-.231-.021-.233-.018-.237-.016-.241-.014-.244-.012-.247-.011-.25-.008-.254-.005-.257-.004-.26-.001-.26.001z"
  );
}, "insertDatabaseIcon"), Qe = /* @__PURE__ */ u(function(e) {
  e.append("defs").append("symbol").attr("id", "computer").attr("width", "24").attr("height", "24").append("path").attr("transform", "scale(.5)").attr(
    "d",
    "M2 2v13h20v-13h-20zm18 11h-16v-9h16v9zm-10.228 6l.466-1h3.524l.467 1h-4.457zm14.228 3h-24l2-6h2.104l-1.33 4h18.45l-1.297-4h2.073l2 6zm-5-10h-14v-7h14v7z"
  );
}, "insertComputerIcon"), Ze = /* @__PURE__ */ u(function(e) {
  e.append("defs").append("symbol").attr("id", "clock").attr("width", "24").attr("height", "24").append("path").attr("transform", "scale(.5)").attr(
    "d",
    "M12 2c5.514 0 10 4.486 10 10s-4.486 10-10 10-10-4.486-10-10 4.486-10 10-10zm0-2c-6.627 0-12 5.373-12 12s5.373 12 12 12 12-5.373 12-12-5.373-12-12-12zm5.848 12.459c.202.038.202.333.001.372-1.907.361-6.045 1.111-6.547 1.111-.719 0-1.301-.582-1.301-1.301 0-.512.77-5.447 1.125-7.445.034-.192.312-.181.343.014l.985 6.238 5.394 1.011z"
  );
}, "insertClockIcon"), je = /* @__PURE__ */ u(function(e) {
  e.append("defs").append("marker").attr("id", "arrowhead").attr("refX", 7.9).attr("refY", 5).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 12).attr("markerHeight", 12).attr("orient", "auto-start-reverse").append("path").attr("d", "M -1 0 L 10 5 L 0 10 z");
}, "insertArrowHead"), $e = /* @__PURE__ */ u(function(e) {
  e.append("defs").append("marker").attr("id", "filled-head").attr("refX", 15.5).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 28).attr("orient", "auto").append("path").attr("d", "M 18,7 L9,13 L14,7 L9,1 Z");
}, "insertArrowFilledHead"), ts = /* @__PURE__ */ u(function(e) {
  e.append("defs").append("marker").attr("id", "sequencenumber").attr("refX", 15).attr("refY", 15).attr("markerWidth", 60).attr("markerHeight", 40).attr("orient", "auto").append("circle").attr("cx", 15).attr("cy", 15).attr("r", 6);
}, "insertSequenceNumber"), es = /* @__PURE__ */ u(function(e) {
  e.append("defs").append("marker").attr("id", "crosshead").attr("markerWidth", 15).attr("markerHeight", 8).attr("orient", "auto").attr("refX", 4).attr("refY", 4.5).append("path").attr("fill", "none").attr("stroke", "#000000").style("stroke-dasharray", "0, 0").attr("stroke-width", "1pt").attr("d", "M 1,2 L 6,7 M 6,2 L 1,7");
}, "insertArrowCrossHead"), re = /* @__PURE__ */ u(function() {
  return {
    x: 0,
    y: 0,
    fill: void 0,
    anchor: void 0,
    style: "#666",
    width: void 0,
    height: void 0,
    textMargin: 0,
    rx: 0,
    ry: 0,
    tspan: !0,
    valign: void 0
  };
}, "getTextObj"), ss = /* @__PURE__ */ u(function() {
  return {
    x: 0,
    y: 0,
    fill: "#EDF2AE",
    stroke: "#666",
    width: 100,
    anchor: "start",
    height: 100,
    rx: 0,
    ry: 0
  };
}, "getNoteRect"), Ft = /* @__PURE__ */ function() {
  function e(i, n, h, d, r, f, y) {
    const g = n.append("text").attr("x", h + r / 2).attr("y", d + f / 2 + 5).style("text-anchor", "middle").text(i);
    a(g, y);
  }
  u(e, "byText");
  function t(i, n, h, d, r, f, y, g) {
    const { actorFontSize: T, actorFontFamily: m, actorFontWeight: v } = g, [A, C] = Zt(T), S = i.split(I.lineBreakRegex);
    for (let B = 0; B < S.length; B++) {
      const D = B * A - A * (S.length - 1) / 2, F = n.append("text").attr("x", h + r / 2).attr("y", d).style("text-anchor", "middle").style("font-size", C).style("font-weight", v).style("font-family", m);
      F.append("tspan").attr("x", h + r / 2).attr("dy", D).text(S[B]), F.attr("y", d + f / 2).attr("dominant-baseline", "central").attr("alignment-baseline", "central"), a(F, y);
    }
  }
  u(t, "byTspan");
  function o(i, n, h, d, r, f, y, g) {
    const T = n.append("switch"), v = T.append("foreignObject").attr("x", h).attr("y", d).attr("width", r).attr("height", f).append("xhtml:div").style("display", "table").style("height", "100%").style("width", "100%");
    v.append("div").style("display", "table-cell").style("text-align", "center").style("vertical-align", "middle").text(i), t(i, T, h, d, r, f, y, g), a(v, y);
  }
  u(o, "byFo");
  async function s(i, n, h, d, r, f, y, g) {
    const T = await bt(i, Ct()), m = n.append("switch"), A = m.append("foreignObject").attr("x", h + r / 2 - T.width / 2).attr("y", d + f / 2 - T.height / 2).attr("width", T.width).attr("height", T.height).append("xhtml:div").style("height", "100%").style("width", "100%");
    A.append("div").style("text-align", "center").style("vertical-align", "middle").html(await jt(i, Ct())), t(i, m, h, d, r, f, y, g), a(A, y);
  }
  u(s, "byKatex");
  function a(i, n) {
    for (const h in n)
      n.hasOwnProperty(h) && i.attr(h, n[h]);
  }
  return u(a, "_setTextAttrs"), function(i, n = !1) {
    return n ? s : i.textPlacement === "fo" ? o : i.textPlacement === "old" ? e : t;
  };
}(), as = /* @__PURE__ */ function() {
  function e(a, i, n, h, d, r, f) {
    const y = i.append("text").attr("x", n).attr("y", h).style("text-anchor", "start").text(a);
    s(y, f);
  }
  u(e, "byText");
  function t(a, i, n, h, d, r, f, y) {
    const { actorFontSize: g, actorFontFamily: T, actorFontWeight: m } = y, v = a.split(I.lineBreakRegex);
    for (let A = 0; A < v.length; A++) {
      const C = A * g - g * (v.length - 1) / 2, S = i.append("text").attr("x", n).attr("y", h).style("text-anchor", "start").style("font-size", g).style("font-weight", m).style("font-family", T);
      S.append("tspan").attr("x", n).attr("dy", C).text(v[A]), S.attr("y", h + r / 2).attr("dominant-baseline", "central").attr("alignment-baseline", "central"), s(S, f);
    }
  }
  u(t, "byTspan");
  function o(a, i, n, h, d, r, f, y) {
    const g = i.append("switch"), m = g.append("foreignObject").attr("x", n).attr("y", h).attr("width", d).attr("height", r).append("xhtml:div").style("display", "table").style("height", "100%").style("width", "100%");
    m.append("div").style("display", "table-cell").style("text-align", "center").style("vertical-align", "middle").text(a), t(a, g, n, h, d, r, f, y), s(m, f);
  }
  u(o, "byFo");
  function s(a, i) {
    for (const n in i)
      i.hasOwnProperty(n) && a.attr(n, i[n]);
  }
  return u(s, "_setTextAttrs"), function(a) {
    return a.textPlacement === "fo" ? o : a.textPlacement === "old" ? e : t;
  };
}(), O = {
  drawRect: Wt,
  drawText: Et,
  drawLabel: ee,
  drawActor: He,
  drawBox: Ue,
  drawPopup: We,
  anchorElement: Ke,
  drawActivation: Ge,
  drawLoop: Xe,
  drawBackgroundRect: ae,
  insertArrowHead: je,
  insertArrowFilledHead: $e,
  insertSequenceNumber: ts,
  insertArrowCrossHead: es,
  insertDatabaseIcon: Je,
  insertComputerIcon: Qe,
  insertClockIcon: Ze,
  getTextObj: re,
  getNoteRect: ss,
  fixLifeLineHeights: se,
  sanitizeUrl: Qt
}, c = {}, x = {
  data: {
    startx: void 0,
    stopx: void 0,
    starty: void 0,
    stopy: void 0
  },
  verticalPos: 0,
  sequenceItems: [],
  activations: [],
  models: {
    getHeight: /* @__PURE__ */ u(function() {
      return Math.max.apply(
        null,
        this.actors.length === 0 ? [0] : this.actors.map((e) => e.height || 0)
      ) + (this.loops.length === 0 ? 0 : this.loops.map((e) => e.height || 0).reduce((e, t) => e + t)) + (this.messages.length === 0 ? 0 : this.messages.map((e) => e.height || 0).reduce((e, t) => e + t)) + (this.notes.length === 0 ? 0 : this.notes.map((e) => e.height || 0).reduce((e, t) => e + t));
    }, "getHeight"),
    clear: /* @__PURE__ */ u(function() {
      this.actors = [], this.boxes = [], this.loops = [], this.messages = [], this.notes = [];
    }, "clear"),
    addBox: /* @__PURE__ */ u(function(e) {
      this.boxes.push(e);
    }, "addBox"),
    addActor: /* @__PURE__ */ u(function(e) {
      this.actors.push(e);
    }, "addActor"),
    addLoop: /* @__PURE__ */ u(function(e) {
      this.loops.push(e);
    }, "addLoop"),
    addMessage: /* @__PURE__ */ u(function(e) {
      this.messages.push(e);
    }, "addMessage"),
    addNote: /* @__PURE__ */ u(function(e) {
      this.notes.push(e);
    }, "addNote"),
    lastActor: /* @__PURE__ */ u(function() {
      return this.actors[this.actors.length - 1];
    }, "lastActor"),
    lastLoop: /* @__PURE__ */ u(function() {
      return this.loops[this.loops.length - 1];
    }, "lastLoop"),
    lastMessage: /* @__PURE__ */ u(function() {
      return this.messages[this.messages.length - 1];
    }, "lastMessage"),
    lastNote: /* @__PURE__ */ u(function() {
      return this.notes[this.notes.length - 1];
    }, "lastNote"),
    actors: [],
    boxes: [],
    loops: [],
    messages: [],
    notes: []
  },
  init: /* @__PURE__ */ u(function() {
    this.sequenceItems = [], this.activations = [], this.models.clear(), this.data = {
      startx: void 0,
      stopx: void 0,
      starty: void 0,
      stopy: void 0
    }, this.verticalPos = 0, oe($());
  }, "init"),
  updateVal: /* @__PURE__ */ u(function(e, t, o, s) {
    e[t] === void 0 ? e[t] = o : e[t] = s(o, e[t]);
  }, "updateVal"),
  updateBounds: /* @__PURE__ */ u(function(e, t, o, s) {
    const a = this;
    let i = 0;
    function n(h) {
      return /* @__PURE__ */ u(function(r) {
        i++;
        const f = a.sequenceItems.length - i + 1;
        a.updateVal(r, "starty", t - f * c.boxMargin, Math.min), a.updateVal(r, "stopy", s + f * c.boxMargin, Math.max), a.updateVal(x.data, "startx", e - f * c.boxMargin, Math.min), a.updateVal(x.data, "stopx", o + f * c.boxMargin, Math.max), h !== "activation" && (a.updateVal(r, "startx", e - f * c.boxMargin, Math.min), a.updateVal(r, "stopx", o + f * c.boxMargin, Math.max), a.updateVal(x.data, "starty", t - f * c.boxMargin, Math.min), a.updateVal(x.data, "stopy", s + f * c.boxMargin, Math.max));
      }, "updateItemBounds");
    }
    u(n, "updateFn"), this.sequenceItems.forEach(n()), this.activations.forEach(n("activation"));
  }, "updateBounds"),
  insert: /* @__PURE__ */ u(function(e, t, o, s) {
    const a = I.getMin(e, o), i = I.getMax(e, o), n = I.getMin(t, s), h = I.getMax(t, s);
    this.updateVal(x.data, "startx", a, Math.min), this.updateVal(x.data, "starty", n, Math.min), this.updateVal(x.data, "stopx", i, Math.max), this.updateVal(x.data, "stopy", h, Math.max), this.updateBounds(a, n, i, h);
  }, "insert"),
  newActivation: /* @__PURE__ */ u(function(e, t, o) {
    const s = o.get(e.from), a = kt(e.from).length || 0, i = s.x + s.width / 2 + (a - 1) * c.activationWidth / 2;
    this.activations.push({
      startx: i,
      starty: this.verticalPos + 2,
      stopx: i + c.activationWidth,
      stopy: void 0,
      actor: e.from,
      anchored: O.anchorElement(t)
    });
  }, "newActivation"),
  endActivation: /* @__PURE__ */ u(function(e) {
    const t = this.activations.map(function(o) {
      return o.actor;
    }).lastIndexOf(e.from);
    return this.activations.splice(t, 1)[0];
  }, "endActivation"),
  createLoop: /* @__PURE__ */ u(function(e = { message: void 0, wrap: !1, width: void 0 }, t) {
    return {
      startx: void 0,
      starty: this.verticalPos,
      stopx: void 0,
      stopy: void 0,
      title: e.message,
      wrap: e.wrap,
      width: e.width,
      height: 0,
      fill: t
    };
  }, "createLoop"),
  newLoop: /* @__PURE__ */ u(function(e = { message: void 0, wrap: !1, width: void 0 }, t) {
    this.sequenceItems.push(this.createLoop(e, t));
  }, "newLoop"),
  endLoop: /* @__PURE__ */ u(function() {
    return this.sequenceItems.pop();
  }, "endLoop"),
  isLoopOverlap: /* @__PURE__ */ u(function() {
    return this.sequenceItems.length ? this.sequenceItems[this.sequenceItems.length - 1].overlap : !1;
  }, "isLoopOverlap"),
  addSectionToLoop: /* @__PURE__ */ u(function(e) {
    const t = this.sequenceItems.pop();
    t.sections = t.sections || [], t.sectionTitles = t.sectionTitles || [], t.sections.push({ y: x.getVerticalPos(), height: 0 }), t.sectionTitles.push(e), this.sequenceItems.push(t);
  }, "addSectionToLoop"),
  saveVerticalPos: /* @__PURE__ */ u(function() {
    this.isLoopOverlap() && (this.savedVerticalPos = this.verticalPos);
  }, "saveVerticalPos"),
  resetVerticalPos: /* @__PURE__ */ u(function() {
    this.isLoopOverlap() && (this.verticalPos = this.savedVerticalPos);
  }, "resetVerticalPos"),
  bumpVerticalPos: /* @__PURE__ */ u(function(e) {
    this.verticalPos = this.verticalPos + e, this.data.stopy = I.getMax(this.data.stopy, this.verticalPos);
  }, "bumpVerticalPos"),
  getVerticalPos: /* @__PURE__ */ u(function() {
    return this.verticalPos;
  }, "getVerticalPos"),
  getBounds: /* @__PURE__ */ u(function() {
    return { bounds: this.data, models: this.models };
  }, "getBounds")
}, rs = /* @__PURE__ */ u(async function(e, t) {
  x.bumpVerticalPos(c.boxMargin), t.height = c.boxMargin, t.starty = x.getVerticalPos();
  const o = At();
  o.x = t.startx, o.y = t.starty, o.width = t.width || c.width, o.class = "note";
  const s = e.append("g"), a = O.drawRect(s, o), i = Yt();
  i.x = t.startx, i.y = t.starty, i.width = o.width, i.dy = "1em", i.text = t.message, i.class = "noteText", i.fontFamily = c.noteFontFamily, i.fontSize = c.noteFontSize, i.fontWeight = c.noteFontWeight, i.anchor = c.noteAlign, i.textMargin = c.noteMargin, i.valign = "center";
  const n = ot(i.text) ? await Pt(s, i) : Et(s, i), h = Math.round(
    n.map((d) => (d._groups || d)[0][0].getBBox().height).reduce((d, r) => d + r)
  );
  a.attr("height", h + 2 * c.noteMargin), t.height += h + 2 * c.noteMargin, x.bumpVerticalPos(h + 2 * c.noteMargin), t.stopy = t.starty + h + 2 * c.noteMargin, t.stopx = t.startx + o.width, x.insert(t.startx, t.starty, t.stopx, t.stopy), x.models.addNote(t);
}, "drawNote"), gt = /* @__PURE__ */ u((e) => ({
  fontFamily: e.messageFontFamily,
  fontSize: e.messageFontSize,
  fontWeight: e.messageFontWeight
}), "messageFont"), xt = /* @__PURE__ */ u((e) => ({
  fontFamily: e.noteFontFamily,
  fontSize: e.noteFontSize,
  fontWeight: e.noteFontWeight
}), "noteFont"), Bt = /* @__PURE__ */ u((e) => ({
  fontFamily: e.actorFontFamily,
  fontSize: e.actorFontSize,
  fontWeight: e.actorFontWeight
}), "actorFont");
async function ie(e, t) {
  x.bumpVerticalPos(10);
  const { startx: o, stopx: s, message: a } = t, i = I.splitBreaks(a).length, n = ot(a), h = n ? await bt(a, $()) : Y.calculateTextDimensions(a, gt(c));
  if (!n) {
    const y = h.height / i;
    t.height += y, x.bumpVerticalPos(y);
  }
  let d, r = h.height - 10;
  const f = h.width;
  if (o === s) {
    d = x.getVerticalPos() + r, c.rightAngles || (r += c.boxMargin, d = x.getVerticalPos() + r), r += 30;
    const y = I.getMax(f / 2, c.width / 2);
    x.insert(
      o - y,
      x.getVerticalPos() - 10 + r,
      s + y,
      x.getVerticalPos() + 30 + r
    );
  } else
    r += c.boxMargin, d = x.getVerticalPos() + r, x.insert(o, d - 10, s, d);
  return x.bumpVerticalPos(r), t.height += r, t.stopy = t.starty + t.height, x.insert(t.fromBounds, t.starty, t.toBounds, t.stopy), d;
}
u(ie, "boundMessage");
var is = /* @__PURE__ */ u(async function(e, t, o, s) {
  const { startx: a, stopx: i, starty: n, message: h, type: d, sequenceIndex: r, sequenceVisible: f } = t, y = Y.calculateTextDimensions(h, gt(c)), g = Yt();
  g.x = a, g.y = n + 10, g.width = i - a, g.class = "messageText", g.dy = "1em", g.text = h, g.fontFamily = c.messageFontFamily, g.fontSize = c.messageFontSize, g.fontWeight = c.messageFontWeight, g.anchor = c.messageAlign, g.valign = "center", g.textMargin = c.wrapPadding, g.tspan = !1, ot(g.text) ? await Pt(e, g, { startx: a, stopx: i, starty: o }) : Et(e, g);
  const T = y.width;
  let m;
  a === i ? c.rightAngles ? m = e.append("path").attr(
    "d",
    `M  ${a},${o} H ${a + I.getMax(c.width / 2, T / 2)} V ${o + 25} H ${a}`
  ) : m = e.append("path").attr(
    "d",
    "M " + a + "," + o + " C " + (a + 60) + "," + (o - 10) + " " + (a + 60) + "," + (o + 30) + " " + a + "," + (o + 20)
  ) : (m = e.append("line"), m.attr("x1", a), m.attr("y1", o), m.attr("x2", i), m.attr("y2", o)), d === s.db.LINETYPE.DOTTED || d === s.db.LINETYPE.DOTTED_CROSS || d === s.db.LINETYPE.DOTTED_POINT || d === s.db.LINETYPE.DOTTED_OPEN || d === s.db.LINETYPE.BIDIRECTIONAL_DOTTED ? (m.style("stroke-dasharray", "3, 3"), m.attr("class", "messageLine1")) : m.attr("class", "messageLine0");
  let v = "";
  c.arrowMarkerAbsolute && (v = Se(!0)), m.attr("stroke-width", 2), m.attr("stroke", "none"), m.style("fill", "none"), (d === s.db.LINETYPE.SOLID || d === s.db.LINETYPE.DOTTED) && m.attr("marker-end", "url(" + v + "#arrowhead)"), (d === s.db.LINETYPE.BIDIRECTIONAL_SOLID || d === s.db.LINETYPE.BIDIRECTIONAL_DOTTED) && (m.attr("marker-start", "url(" + v + "#arrowhead)"), m.attr("marker-end", "url(" + v + "#arrowhead)")), (d === s.db.LINETYPE.SOLID_POINT || d === s.db.LINETYPE.DOTTED_POINT) && m.attr("marker-end", "url(" + v + "#filled-head)"), (d === s.db.LINETYPE.SOLID_CROSS || d === s.db.LINETYPE.DOTTED_CROSS) && m.attr("marker-end", "url(" + v + "#crosshead)"), (f || c.showSequenceNumbers) && ((d === s.db.LINETYPE.BIDIRECTIONAL_SOLID || d === s.db.LINETYPE.BIDIRECTIONAL_DOTTED) && (a < i ? m.attr("x1", a + 2 * 6) : m.attr("x1", a + 6)), e.append("line").attr("x1", a).attr("y1", o).attr("x2", a).attr("y2", o).attr("stroke-width", 0).attr("marker-start", "url(" + v + "#sequencenumber)"), e.append("text").attr("x", a).attr("y", o + 4).attr("font-family", "sans-serif").attr("font-size", "12px").attr("text-anchor", "middle").attr("class", "sequenceNumber").text(r));
}, "drawMessage"), ns = /* @__PURE__ */ u(function(e, t, o, s, a, i, n) {
  let h = 0, d = 0, r, f = 0;
  for (const y of s) {
    const g = t.get(y), T = g.box;
    r && r != T && (n || x.models.addBox(r), d += c.boxMargin + r.margin), T && T != r && (n || (T.x = h + d, T.y = a), d += T.margin), g.width = g.width || c.width, g.height = I.getMax(g.height || c.height, c.height), g.margin = g.margin || c.actorMargin, f = I.getMax(f, g.height), o.get(g.name) && (d += g.width / 2), g.x = h + d, g.starty = x.getVerticalPos(), x.insert(g.x, a, g.x + g.width, g.height), h += g.width + d, g.box && (g.box.width = h + T.margin - g.box.x), d = g.margin, r = g.box, x.models.addActor(g);
  }
  r && !n && x.models.addBox(r), x.bumpVerticalPos(f);
}, "addActorRenderingData"), Vt = /* @__PURE__ */ u(async function(e, t, o, s) {
  if (s) {
    let a = 0;
    x.bumpVerticalPos(c.boxMargin * 2);
    for (const i of o) {
      const n = t.get(i);
      n.stopy || (n.stopy = x.getVerticalPos());
      const h = await O.drawActor(e, n, c, !0);
      a = I.getMax(a, h);
    }
    x.bumpVerticalPos(a + c.boxMargin);
  } else
    for (const a of o) {
      const i = t.get(a);
      await O.drawActor(e, i, c, !1);
    }
}, "drawActors"), ne = /* @__PURE__ */ u(function(e, t, o, s) {
  let a = 0, i = 0;
  for (const n of o) {
    const h = t.get(n), d = cs(h), r = O.drawPopup(
      e,
      h,
      d,
      c,
      c.forceMenus,
      s
    );
    r.height > a && (a = r.height), r.width + h.x > i && (i = r.width + h.x);
  }
  return { maxHeight: a, maxWidth: i };
}, "drawActorsPopup"), oe = /* @__PURE__ */ u(function(e) {
  ve(c, e), e.fontFamily && (c.actorFontFamily = c.noteFontFamily = c.messageFontFamily = e.fontFamily), e.fontSize && (c.actorFontSize = c.noteFontSize = c.messageFontSize = e.fontSize), e.fontWeight && (c.actorFontWeight = c.noteFontWeight = c.messageFontWeight = e.fontWeight);
}, "setConf"), kt = /* @__PURE__ */ u(function(e) {
  return x.activations.filter(function(t) {
    return t.actor === e;
  });
}, "actorActivations"), Jt = /* @__PURE__ */ u(function(e, t) {
  const o = t.get(e), s = kt(e), a = s.reduce(
    function(n, h) {
      return I.getMin(n, h.startx);
    },
    o.x + o.width / 2 - 1
  ), i = s.reduce(
    function(n, h) {
      return I.getMax(n, h.stopx);
    },
    o.x + o.width / 2 + 1
  );
  return [a, i];
}, "activationBounds");
function rt(e, t, o, s, a) {
  x.bumpVerticalPos(o);
  let i = s;
  if (t.id && t.message && e[t.id]) {
    const n = e[t.id].width, h = gt(c);
    t.message = Y.wrapLabel(`[${t.message}]`, n - 2 * c.wrapPadding, h), t.width = n, t.wrap = !0;
    const d = Y.calculateTextDimensions(t.message, h), r = I.getMax(d.height, c.labelBoxHeight);
    i = s + r, G.debug(`${r} - ${t.message}`);
  }
  a(t), x.bumpVerticalPos(i);
}
u(rt, "adjustLoopHeightForWrap");
function ce(e, t, o, s, a, i, n) {
  function h(r, f) {
    r.x < a.get(e.from).x ? (x.insert(
      t.stopx - f,
      t.starty,
      t.startx,
      t.stopy + r.height / 2 + c.noteMargin
    ), t.stopx = t.stopx + f) : (x.insert(
      t.startx,
      t.starty,
      t.stopx + f,
      t.stopy + r.height / 2 + c.noteMargin
    ), t.stopx = t.stopx - f);
  }
  u(h, "receiverAdjustment");
  function d(r, f) {
    r.x < a.get(e.to).x ? (x.insert(
      t.startx - f,
      t.starty,
      t.stopx,
      t.stopy + r.height / 2 + c.noteMargin
    ), t.startx = t.startx + f) : (x.insert(
      t.stopx,
      t.starty,
      t.startx + f,
      t.stopy + r.height / 2 + c.noteMargin
    ), t.startx = t.startx - f);
  }
  if (u(d, "senderAdjustment"), i.get(e.to) == s) {
    const r = a.get(e.to), f = r.type == "actor" ? ut / 2 + 3 : r.width / 2 + 3;
    h(r, f), r.starty = o - r.height / 2, x.bumpVerticalPos(r.height / 2);
  } else if (n.get(e.from) == s) {
    const r = a.get(e.from);
    if (c.mirrorActors) {
      const f = r.type == "actor" ? ut / 2 : r.width / 2;
      d(r, f);
    }
    r.stopy = o - r.height / 2, x.bumpVerticalPos(r.height / 2);
  } else if (n.get(e.to) == s) {
    const r = a.get(e.to);
    if (c.mirrorActors) {
      const f = r.type == "actor" ? ut / 2 + 3 : r.width / 2 + 3;
      h(r, f);
    }
    r.stopy = o - r.height / 2, x.bumpVerticalPos(r.height / 2);
  }
}
u(ce, "adjustCreatedDestroyedData");
var os = /* @__PURE__ */ u(async function(e, t, o, s) {
  const { securityLevel: a, sequence: i } = $();
  c = i;
  let n;
  a === "sandbox" && (n = Lt("#i" + t));
  const h = a === "sandbox" ? Lt(n.nodes()[0].contentDocument.body) : Lt("body"), d = a === "sandbox" ? n.nodes()[0].contentDocument : document;
  x.init(), G.debug(s.db);
  const r = a === "sandbox" ? h.select(`[id="${t}"]`) : Lt(`[id="${t}"]`), f = s.db.getActors(), y = s.db.getCreatedActors(), g = s.db.getDestroyedActors(), T = s.db.getBoxes();
  let m = s.db.getActorKeys();
  const v = s.db.getMessages(), A = s.db.getDiagramTitle(), C = s.db.hasAtLeastOneBox(), S = s.db.hasAtLeastOneBoxWithTitle(), B = await le(f, v, s);
  if (c.height = await he(f, B, T), O.insertComputerIcon(r), O.insertDatabaseIcon(r), O.insertClockIcon(r), C && (x.bumpVerticalPos(c.boxMargin), S && x.bumpVerticalPos(T[0].textMaxHeight)), c.hideUnusedParticipants === !0) {
    const E = /* @__PURE__ */ new Set();
    v.forEach((_) => {
      E.add(_.from), E.add(_.to);
    }), m = m.filter((_) => E.has(_));
  }
  ns(r, f, y, m, 0, v, !1);
  const D = await ds(v, f, B, s);
  O.insertArrowHead(r), O.insertArrowCrossHead(r), O.insertArrowFilledHead(r), O.insertSequenceNumber(r);
  function F(E, _) {
    const Z = x.endActivation(E);
    Z.starty + 18 > _ && (Z.starty = _ - 6, _ += 12), O.drawActivation(
      r,
      Z,
      _,
      c,
      kt(E.from).length
    ), x.insert(Z.startx, _ - 10, Z.stopx, _);
  }
  u(F, "activeEnd");
  let q = 1, X = 1;
  const tt = [], z = [];
  let H = 0;
  for (const E of v) {
    let _, Z, at;
    switch (E.type) {
      case s.db.LINETYPE.NOTE:
        x.resetVerticalPos(), Z = E.noteModel, await rs(r, Z);
        break;
      case s.db.LINETYPE.ACTIVE_START:
        x.newActivation(E, r, f);
        break;
      case s.db.LINETYPE.ACTIVE_END:
        F(E, x.getVerticalPos());
        break;
      case s.db.LINETYPE.LOOP_START:
        rt(
          D,
          E,
          c.boxMargin,
          c.boxMargin + c.boxTextMargin,
          (k) => x.newLoop(k)
        );
        break;
      case s.db.LINETYPE.LOOP_END:
        _ = x.endLoop(), await O.drawLoop(r, _, "loop", c), x.bumpVerticalPos(_.stopy - x.getVerticalPos()), x.models.addLoop(_);
        break;
      case s.db.LINETYPE.RECT_START:
        rt(
          D,
          E,
          c.boxMargin,
          c.boxMargin,
          (k) => x.newLoop(void 0, k.message)
        );
        break;
      case s.db.LINETYPE.RECT_END:
        _ = x.endLoop(), z.push(_), x.models.addLoop(_), x.bumpVerticalPos(_.stopy - x.getVerticalPos());
        break;
      case s.db.LINETYPE.OPT_START:
        rt(
          D,
          E,
          c.boxMargin,
          c.boxMargin + c.boxTextMargin,
          (k) => x.newLoop(k)
        );
        break;
      case s.db.LINETYPE.OPT_END:
        _ = x.endLoop(), await O.drawLoop(r, _, "opt", c), x.bumpVerticalPos(_.stopy - x.getVerticalPos()), x.models.addLoop(_);
        break;
      case s.db.LINETYPE.ALT_START:
        rt(
          D,
          E,
          c.boxMargin,
          c.boxMargin + c.boxTextMargin,
          (k) => x.newLoop(k)
        );
        break;
      case s.db.LINETYPE.ALT_ELSE:
        rt(
          D,
          E,
          c.boxMargin + c.boxTextMargin,
          c.boxMargin,
          (k) => x.addSectionToLoop(k)
        );
        break;
      case s.db.LINETYPE.ALT_END:
        _ = x.endLoop(), await O.drawLoop(r, _, "alt", c), x.bumpVerticalPos(_.stopy - x.getVerticalPos()), x.models.addLoop(_);
        break;
      case s.db.LINETYPE.PAR_START:
      case s.db.LINETYPE.PAR_OVER_START:
        rt(
          D,
          E,
          c.boxMargin,
          c.boxMargin + c.boxTextMargin,
          (k) => x.newLoop(k)
        ), x.saveVerticalPos();
        break;
      case s.db.LINETYPE.PAR_AND:
        rt(
          D,
          E,
          c.boxMargin + c.boxTextMargin,
          c.boxMargin,
          (k) => x.addSectionToLoop(k)
        );
        break;
      case s.db.LINETYPE.PAR_END:
        _ = x.endLoop(), await O.drawLoop(r, _, "par", c), x.bumpVerticalPos(_.stopy - x.getVerticalPos()), x.models.addLoop(_);
        break;
      case s.db.LINETYPE.AUTONUMBER:
        q = E.message.start || q, X = E.message.step || X, E.message.visible ? s.db.enableSequenceNumbers() : s.db.disableSequenceNumbers();
        break;
      case s.db.LINETYPE.CRITICAL_START:
        rt(
          D,
          E,
          c.boxMargin,
          c.boxMargin + c.boxTextMargin,
          (k) => x.newLoop(k)
        );
        break;
      case s.db.LINETYPE.CRITICAL_OPTION:
        rt(
          D,
          E,
          c.boxMargin + c.boxTextMargin,
          c.boxMargin,
          (k) => x.addSectionToLoop(k)
        );
        break;
      case s.db.LINETYPE.CRITICAL_END:
        _ = x.endLoop(), await O.drawLoop(r, _, "critical", c), x.bumpVerticalPos(_.stopy - x.getVerticalPos()), x.models.addLoop(_);
        break;
      case s.db.LINETYPE.BREAK_START:
        rt(
          D,
          E,
          c.boxMargin,
          c.boxMargin + c.boxTextMargin,
          (k) => x.newLoop(k)
        );
        break;
      case s.db.LINETYPE.BREAK_END:
        _ = x.endLoop(), await O.drawLoop(r, _, "break", c), x.bumpVerticalPos(_.stopy - x.getVerticalPos()), x.models.addLoop(_);
        break;
      default:
        try {
          at = E.msgModel, at.starty = x.getVerticalPos(), at.sequenceIndex = q, at.sequenceVisible = s.db.showSequenceNumbers();
          const k = await ie(r, at);
          ce(
            E,
            at,
            k,
            H,
            f,
            y,
            g
          ), tt.push({ messageModel: at, lineStartY: k }), x.models.addMessage(at);
        } catch (k) {
          G.error("error while drawing message", k);
        }
    }
    [
      s.db.LINETYPE.SOLID_OPEN,
      s.db.LINETYPE.DOTTED_OPEN,
      s.db.LINETYPE.SOLID,
      s.db.LINETYPE.DOTTED,
      s.db.LINETYPE.SOLID_CROSS,
      s.db.LINETYPE.DOTTED_CROSS,
      s.db.LINETYPE.SOLID_POINT,
      s.db.LINETYPE.DOTTED_POINT,
      s.db.LINETYPE.BIDIRECTIONAL_SOLID,
      s.db.LINETYPE.BIDIRECTIONAL_DOTTED
    ].includes(E.type) && (q = q + X), H++;
  }
  G.debug("createdActors", y), G.debug("destroyedActors", g), await Vt(r, f, m, !1);
  for (const E of tt)
    await is(r, E.messageModel, E.lineStartY, s);
  c.mirrorActors && await Vt(r, f, m, !0), z.forEach((E) => O.drawBackgroundRect(r, E)), se(r, f, m, c);
  for (const E of x.models.boxes)
    E.height = x.getVerticalPos() - E.y, x.insert(E.x, E.y, E.x + E.width, E.height), E.startx = E.x, E.starty = E.y, E.stopx = E.startx + E.width, E.stopy = E.starty + E.height, E.stroke = "rgb(0,0,0, 0.5)", O.drawBox(r, E, c);
  C && x.bumpVerticalPos(c.boxMargin);
  const W = ne(r, f, m, d), { bounds: M } = x.getBounds();
  M.startx === void 0 && (M.startx = 0), M.starty === void 0 && (M.starty = 0), M.stopx === void 0 && (M.stopx = 0), M.stopy === void 0 && (M.stopy = 0);
  let J = M.stopy - M.starty;
  J < W.maxHeight && (J = W.maxHeight);
  let U = J + 2 * c.diagramMarginY;
  c.mirrorActors && (U = U - c.boxMargin + c.bottomMarginAdj);
  let Q = M.stopx - M.startx;
  Q < W.maxWidth && (Q = W.maxWidth);
  const et = Q + 2 * c.diagramMarginX;
  A && r.append("text").text(A).attr("x", (M.stopx - M.startx) / 2 - 2 * c.diagramMarginX).attr("y", -25), we(r, U, et, c.useMaxWidth);
  const N = A ? 40 : 0;
  r.attr(
    "viewBox",
    M.startx - c.diagramMarginX + " -" + (c.diagramMarginY + N) + " " + et + " " + (U + N)
  ), G.debug("models:", x.models);
}, "draw");
async function le(e, t, o) {
  const s = {};
  for (const a of t)
    if (e.get(a.to) && e.get(a.from)) {
      const i = e.get(a.to);
      if (a.placement === o.db.PLACEMENT.LEFTOF && !i.prevActor || a.placement === o.db.PLACEMENT.RIGHTOF && !i.nextActor)
        continue;
      const n = a.placement !== void 0, h = !n, d = n ? xt(c) : gt(c), r = a.wrap ? Y.wrapLabel(a.message, c.width - 2 * c.wrapPadding, d) : a.message, y = (ot(r) ? await bt(a.message, $()) : Y.calculateTextDimensions(r, d)).width + 2 * c.wrapPadding;
      h && a.from === i.nextActor ? s[a.to] = I.getMax(
        s[a.to] || 0,
        y
      ) : h && a.from === i.prevActor ? s[a.from] = I.getMax(
        s[a.from] || 0,
        y
      ) : h && a.from === a.to ? (s[a.from] = I.getMax(
        s[a.from] || 0,
        y / 2
      ), s[a.to] = I.getMax(
        s[a.to] || 0,
        y / 2
      )) : a.placement === o.db.PLACEMENT.RIGHTOF ? s[a.from] = I.getMax(
        s[a.from] || 0,
        y
      ) : a.placement === o.db.PLACEMENT.LEFTOF ? s[i.prevActor] = I.getMax(
        s[i.prevActor] || 0,
        y
      ) : a.placement === o.db.PLACEMENT.OVER && (i.prevActor && (s[i.prevActor] = I.getMax(
        s[i.prevActor] || 0,
        y / 2
      )), i.nextActor && (s[a.from] = I.getMax(
        s[a.from] || 0,
        y / 2
      )));
    }
  return G.debug("maxMessageWidthPerActor:", s), s;
}
u(le, "getMaxMessageWidthPerActor");
var cs = /* @__PURE__ */ u(function(e) {
  let t = 0;
  const o = Bt(c);
  for (const s in e.links) {
    const i = Y.calculateTextDimensions(s, o).width + 2 * c.wrapPadding + 2 * c.boxMargin;
    t < i && (t = i);
  }
  return t;
}, "getRequiredPopupWidth");
async function he(e, t, o) {
  let s = 0;
  for (const i of e.keys()) {
    const n = e.get(i);
    n.wrap && (n.description = Y.wrapLabel(
      n.description,
      c.width - 2 * c.wrapPadding,
      Bt(c)
    ));
    const h = ot(n.description) ? await bt(n.description, $()) : Y.calculateTextDimensions(n.description, Bt(c));
    n.width = n.wrap ? c.width : I.getMax(c.width, h.width + 2 * c.wrapPadding), n.height = n.wrap ? I.getMax(h.height, c.height) : c.height, s = I.getMax(s, n.height);
  }
  for (const i in t) {
    const n = e.get(i);
    if (!n)
      continue;
    const h = e.get(n.nextActor);
    if (!h) {
      const y = t[i] + c.actorMargin - n.width / 2;
      n.margin = I.getMax(y, c.actorMargin);
      continue;
    }
    const r = t[i] + c.actorMargin - n.width / 2 - h.width / 2;
    n.margin = I.getMax(r, c.actorMargin);
  }
  let a = 0;
  return o.forEach((i) => {
    const n = gt(c);
    let h = i.actorKeys.reduce((f, y) => f += e.get(y).width + (e.get(y).margin || 0), 0);
    h -= 2 * c.boxTextMargin, i.wrap && (i.name = Y.wrapLabel(i.name, h - 2 * c.wrapPadding, n));
    const d = Y.calculateTextDimensions(i.name, n);
    a = I.getMax(d.height, a);
    const r = I.getMax(h, d.width + 2 * c.wrapPadding);
    if (i.margin = c.boxTextMargin, h < r) {
      const f = (r - h) / 2;
      i.margin += f;
    }
  }), o.forEach((i) => i.textMaxHeight = a), I.getMax(s, c.height);
}
u(he, "calculateActorMargins");
var ls = /* @__PURE__ */ u(async function(e, t, o) {
  const s = t.get(e.from), a = t.get(e.to), i = s.x, n = a.x, h = e.wrap && e.message;
  let d = ot(e.message) ? await bt(e.message, $()) : Y.calculateTextDimensions(
    h ? Y.wrapLabel(e.message, c.width, xt(c)) : e.message,
    xt(c)
  );
  const r = {
    width: h ? c.width : I.getMax(c.width, d.width + 2 * c.noteMargin),
    height: 0,
    startx: s.x,
    stopx: 0,
    starty: 0,
    stopy: 0,
    message: e.message
  };
  return e.placement === o.db.PLACEMENT.RIGHTOF ? (r.width = h ? I.getMax(c.width, d.width) : I.getMax(
    s.width / 2 + a.width / 2,
    d.width + 2 * c.noteMargin
  ), r.startx = i + (s.width + c.actorMargin) / 2) : e.placement === o.db.PLACEMENT.LEFTOF ? (r.width = h ? I.getMax(c.width, d.width + 2 * c.noteMargin) : I.getMax(
    s.width / 2 + a.width / 2,
    d.width + 2 * c.noteMargin
  ), r.startx = i - r.width + (s.width - c.actorMargin) / 2) : e.to === e.from ? (d = Y.calculateTextDimensions(
    h ? Y.wrapLabel(e.message, I.getMax(c.width, s.width), xt(c)) : e.message,
    xt(c)
  ), r.width = h ? I.getMax(c.width, s.width) : I.getMax(s.width, c.width, d.width + 2 * c.noteMargin), r.startx = i + (s.width - r.width) / 2) : (r.width = Math.abs(i + s.width / 2 - (n + a.width / 2)) + c.actorMargin, r.startx = i < n ? i + s.width / 2 - c.actorMargin / 2 : n + a.width / 2 - c.actorMargin / 2), h && (r.message = Y.wrapLabel(
    e.message,
    r.width - 2 * c.wrapPadding,
    xt(c)
  )), G.debug(
    `NM:[${r.startx},${r.stopx},${r.starty},${r.stopy}:${r.width},${r.height}=${e.message}]`
  ), r;
}, "buildNoteModel"), hs = /* @__PURE__ */ u(function(e, t, o) {
  if (![
    o.db.LINETYPE.SOLID_OPEN,
    o.db.LINETYPE.DOTTED_OPEN,
    o.db.LINETYPE.SOLID,
    o.db.LINETYPE.DOTTED,
    o.db.LINETYPE.SOLID_CROSS,
    o.db.LINETYPE.DOTTED_CROSS,
    o.db.LINETYPE.SOLID_POINT,
    o.db.LINETYPE.DOTTED_POINT,
    o.db.LINETYPE.BIDIRECTIONAL_SOLID,
    o.db.LINETYPE.BIDIRECTIONAL_DOTTED
  ].includes(e.type))
    return {};
  const [s, a] = Jt(e.from, t), [i, n] = Jt(e.to, t), h = s <= i;
  let d = h ? a : s, r = h ? i : n;
  const f = Math.abs(i - n) > 2, y = /* @__PURE__ */ u((v) => h ? -v : v, "adjustValue");
  e.from === e.to ? r = d : (e.activate && !f && (r += y(c.activationWidth / 2 - 1)), [o.db.LINETYPE.SOLID_OPEN, o.db.LINETYPE.DOTTED_OPEN].includes(e.type) || (r += y(3)), [o.db.LINETYPE.BIDIRECTIONAL_SOLID, o.db.LINETYPE.BIDIRECTIONAL_DOTTED].includes(
    e.type
  ) && (d -= y(3)));
  const g = [s, a, i, n], T = Math.abs(d - r);
  e.wrap && e.message && (e.message = Y.wrapLabel(
    e.message,
    I.getMax(T + 2 * c.wrapPadding, c.width),
    gt(c)
  ));
  const m = Y.calculateTextDimensions(e.message, gt(c));
  return {
    width: I.getMax(
      e.wrap ? 0 : m.width + 2 * c.wrapPadding,
      T + 2 * c.wrapPadding,
      c.width
    ),
    height: 0,
    startx: d,
    stopx: r,
    starty: 0,
    stopy: 0,
    message: e.message,
    type: e.type,
    wrap: e.wrap,
    fromBounds: Math.min.apply(null, g),
    toBounds: Math.max.apply(null, g)
  };
}, "buildMessageModel"), ds = /* @__PURE__ */ u(async function(e, t, o, s) {
  const a = {}, i = [];
  let n, h, d;
  for (const r of e) {
    switch (r.type) {
      case s.db.LINETYPE.LOOP_START:
      case s.db.LINETYPE.ALT_START:
      case s.db.LINETYPE.OPT_START:
      case s.db.LINETYPE.PAR_START:
      case s.db.LINETYPE.PAR_OVER_START:
      case s.db.LINETYPE.CRITICAL_START:
      case s.db.LINETYPE.BREAK_START:
        i.push({
          id: r.id,
          msg: r.message,
          from: Number.MAX_SAFE_INTEGER,
          to: Number.MIN_SAFE_INTEGER,
          width: 0
        });
        break;
      case s.db.LINETYPE.ALT_ELSE:
      case s.db.LINETYPE.PAR_AND:
      case s.db.LINETYPE.CRITICAL_OPTION:
        r.message && (n = i.pop(), a[n.id] = n, a[r.id] = n, i.push(n));
        break;
      case s.db.LINETYPE.LOOP_END:
      case s.db.LINETYPE.ALT_END:
      case s.db.LINETYPE.OPT_END:
      case s.db.LINETYPE.PAR_END:
      case s.db.LINETYPE.CRITICAL_END:
      case s.db.LINETYPE.BREAK_END:
        n = i.pop(), a[n.id] = n;
        break;
      case s.db.LINETYPE.ACTIVE_START:
        {
          const y = t.get(r.from ? r.from : r.to.actor), g = kt(r.from ? r.from : r.to.actor).length, T = y.x + y.width / 2 + (g - 1) * c.activationWidth / 2, m = {
            startx: T,
            stopx: T + c.activationWidth,
            actor: r.from,
            enabled: !0
          };
          x.activations.push(m);
        }
        break;
      case s.db.LINETYPE.ACTIVE_END:
        {
          const y = x.activations.map((g) => g.actor).lastIndexOf(r.from);
          x.activations.splice(y, 1).splice(0, 1);
        }
        break;
    }
    r.placement !== void 0 ? (h = await ls(r, t, s), r.noteModel = h, i.forEach((y) => {
      n = y, n.from = I.getMin(n.from, h.startx), n.to = I.getMax(n.to, h.startx + h.width), n.width = I.getMax(n.width, Math.abs(n.from - n.to)) - c.labelBoxWidth;
    })) : (d = hs(r, t, s), r.msgModel = d, d.startx && d.stopx && i.length > 0 && i.forEach((y) => {
      if (n = y, d.startx === d.stopx) {
        const g = t.get(r.from), T = t.get(r.to);
        n.from = I.getMin(
          g.x - d.width / 2,
          g.x - g.width / 2,
          n.from
        ), n.to = I.getMax(
          T.x + d.width / 2,
          T.x + g.width / 2,
          n.to
        ), n.width = I.getMax(n.width, Math.abs(n.to - n.from)) - c.labelBoxWidth;
      } else
        n.from = I.getMin(d.startx, n.from), n.to = I.getMax(d.stopx, n.to), n.width = I.getMax(n.width, d.width) - c.labelBoxWidth;
    }));
  }
  return x.activations = [], G.debug("Loop type widths:", a), a;
}, "calculateLoopBounds"), ps = {
  bounds: x,
  drawActors: Vt,
  drawActorsPopup: ne,
  setConf: oe,
  draw: os
}, xs = {
  parser: Me,
  get db() {
    return new Oe();
  },
  renderer: ps,
  styles: Ve,
  init: /* @__PURE__ */ u((e) => {
    e.sequence || (e.sequence = {}), e.wrap && (e.sequence.wrap = e.wrap, me({ sequence: { wrap: e.wrap } }));
  }, "init")
};
export {
  xs as diagram
};
