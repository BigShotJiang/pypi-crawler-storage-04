from .build import CeobeCanteenTheme

__theme_meta__ = CeobeCanteenTheme()
