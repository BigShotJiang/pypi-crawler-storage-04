from .build import ArknightsTheme

__theme_meta__ = ArknightsTheme()
