from .build import BriefTheme

__theme_meta__ = BriefTheme()
