from .build import Ht2iTheme

__theme_meta__ = Ht2iTheme()
