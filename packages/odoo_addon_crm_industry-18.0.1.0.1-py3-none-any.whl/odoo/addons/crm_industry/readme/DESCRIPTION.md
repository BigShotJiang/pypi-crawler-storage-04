This module adds industries for leads and opportunities.
