from .frontend import App  # noqa: F401
