"""
Algorithm modules for BioSynth.
""" 