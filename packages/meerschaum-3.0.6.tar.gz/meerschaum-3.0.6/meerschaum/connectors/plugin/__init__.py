#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8

"""
Allow pipes to source data from installed plugins.
"""

from meerschaum.connectors.plugin.PluginConnector import PluginConnector
