#! /usr/bin/env python3
# vim:fenc=utf-8

"""
Define internal utilities for interacting with the CLI daemons.
"""
