#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8

"""
Define default configuration for the mosquitto broker
"""

default_mosquitto_config = {
    'mosquitto.conf' : '',
}
