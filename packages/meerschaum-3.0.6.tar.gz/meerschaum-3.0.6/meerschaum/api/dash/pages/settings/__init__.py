#! /usr/bin/env python3
# vim:fenc=utf-8

"""
Define the layouts for the `settings` pages.
"""

import meerschaum.api.dash.pages.settings.password_reset
