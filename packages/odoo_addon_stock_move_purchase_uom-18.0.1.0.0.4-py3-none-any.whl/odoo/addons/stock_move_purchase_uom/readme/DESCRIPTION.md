This module adds a check in the operation types form that allows users
to decide if they want to use the purchase UoM for the moves of that
operation type.
