# Auto-generated telemetry keys module.
# This file is intended to be updated by build scripts (populate_telemetry_keys.py)
# and cleared by clear_telemetry_keys.py. Keep values as empty strings in the repo.
#
# WARNING: Do NOT commit real production keys to the repository.

AMPLITUDE_API_KEY = "2a7b4bd93a772ef00c74b8ed69830c41"
POSTHOG_API_KEY = "phc_AS788x1ftlVzRCJ5NlnaKIPkJ4PyXKKejsAb8x6dl5X"
