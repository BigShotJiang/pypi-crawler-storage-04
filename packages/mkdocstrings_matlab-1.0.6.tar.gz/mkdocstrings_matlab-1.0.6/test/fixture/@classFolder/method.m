function method(obj) 
    % Docstring for method.
end
