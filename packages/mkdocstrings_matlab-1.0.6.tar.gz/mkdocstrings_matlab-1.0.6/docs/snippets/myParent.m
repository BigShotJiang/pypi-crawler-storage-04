classdef (Abstract) myParent < handle & double
    % An abstract class that defines the interface for a parent class
end
