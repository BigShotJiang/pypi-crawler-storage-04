Docstring of module.

Functions:
    do_something: Do something.

Classes:
    aClass: Summary

Namespaces:
    submodule: This is a submodule
