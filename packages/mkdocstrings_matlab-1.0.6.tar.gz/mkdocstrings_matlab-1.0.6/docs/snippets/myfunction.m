function myfunction(x, y)
    % Example function
    arguments
        x myClass % An instance of myClass
        y string 
    end
end
