function value = do_output()
% Do something.
%
% outputs:
%     value: Some value.
end
