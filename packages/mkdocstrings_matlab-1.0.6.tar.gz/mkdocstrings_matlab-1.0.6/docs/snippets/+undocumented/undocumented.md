??? code "Source files"

    === ":material-file-tree: tree"

        ```tree
        +undocumented
            ClassWithoutDocstring.m
            function_with_docstring.m
            function_without_docstring.m
        ```

    === ":material-file-code: `ClassWithoutDocstring.m`"

        ```matlab
        --8<-- "docs/snippets/+undocumented/ClassWithoutDocstring.m"
        ```
    
    === ":material-file-code: `function_with_docstring.m`"

        ```matlab
        --8<-- "docs/snippets/+undocumented/function_with_docstring.m"
        ```

    === ":material-file-code: `function_without_docstring.m`"

        ```matlab
        --8<-- "docs/snippets/+undocumented/function_without_docstring.m"
        ```
