function function_without_docstring()
end
