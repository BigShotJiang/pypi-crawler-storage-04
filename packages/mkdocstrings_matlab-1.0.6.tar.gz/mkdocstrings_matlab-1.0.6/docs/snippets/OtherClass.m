classdef OtherClass
    % Summary.
    %
    % Long description.
    %
    % Methods:
    %     foo: Some method.

    methods
        function foo()
            % Summary.
        end
    end
end
