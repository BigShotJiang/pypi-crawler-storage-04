from .registry import assistant_registry

assistants = assistant_registry

__all__ = [
    "assistants",
]
