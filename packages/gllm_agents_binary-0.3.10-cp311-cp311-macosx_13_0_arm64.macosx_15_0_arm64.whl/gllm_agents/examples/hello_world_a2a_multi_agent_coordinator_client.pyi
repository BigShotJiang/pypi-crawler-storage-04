from gllm_agents.agent import LangGraphAgent as LangGraphAgent
from gllm_agents.agent.types import A2AClientConfig as A2AClientConfig

async def main() -> None:
    """Main function demonstrating the Multi-Agent Coordinator client."""
async def test_combined_request(client_agent, coordinator_card) -> None:
    """Test a request that requires both image and table generation."""
def handle_artifacts(result, test_name) -> None:
    """Handle and display information about artifacts from the result."""
def print_artifact_info(artifact: dict) -> None:
    """Print information about an artifact.

    Args:
        artifact: Dictionary containing artifact information.
    """
