def Yes():
    pass