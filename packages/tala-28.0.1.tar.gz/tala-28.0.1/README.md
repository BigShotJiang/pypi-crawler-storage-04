This is a command line SDK for managing TDM-based dialogue domain descriptions (DDDs). For further information, see [talkamatic.se](http://talkamatic.se).

# Install dependencies

### Ubuntu

```bash
apt install libxml2-dev libxslt-dev
```

# Installation

Install the latest version of Tala with pip:

```bash
pip3 install tala
```
