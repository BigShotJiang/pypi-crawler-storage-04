
class DatabaseException(Exception):
    pass
