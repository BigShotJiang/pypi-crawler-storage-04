# League-Data-MCP

A Model Context Protocol (MCP) server that provides access to League of Legends game data through the Riot Games API.

## Features

- **Player's PUUID Lookup**: Get player's PUUID using game names and tag lines
- **Match History List**: Retrieve match lists for players with optional filtering
- **Match Details**: Get detailed match information including statistics and game data
- **Match Summary List**: Get truncated match data with player-specific context (optimized for large datasets)

## Prerequisites

- Python 3.13+
- Riot Games API key (get one from [Riot Developer Portal](https://developer.riotgames.com/))
- MCP-compatible client (like Claude Desktop)

## Installation

### Method 1: Install from PyPI (Recommended)

```bash
pip install league-data-mcp
```

### Method 2: Install with uvx

```bash
uvx install league-data-mcp
```

### Method 3: Development Installation

1. **Clone the repository**
   ```bash
   git clone https://github.com/yshi50/league-data-mcp.git
   cd league-data-mcp
   ```

2. **Install dependencies**
   ```bash
   uv sync
   ```

3. **Set environment variable**
   ```bash
   export API="Your Riot API key here"
   ```

## Configuration

### For Claude Desktop/Cherry Studio etc.

4. **Configure MCP Client**
   Add the server configuration to your MCP client:
   ```json
   {
   "mcpServers": {
      "League-Data-MCP": {
         "command": "uvx",
         "args": ["league-data-mcp@latest"],
         "env": {
         "API": "Your Riot API key here"
         }
      }
   }
   }
   ```

## Available Tools

### `get_puuid`
Get player PUUIDs by their game names and tag lines (supports batch queries).

**Parameters:**
- `players` (List[dict]): List of player dictionaries with `game_name` and `tag_line` keys

**Example:**
```python
get_puuid([
    {"game_name": "Faker", "tag_line": "KR1"},
    {"game_name": "Untargetable", "tag_line": "666"}
])
```

### `get_match_list`
Get a list of matches for a player by their PUUID.

**Parameters:**
- `puuid` (str): Player's PUUID
- `type` (str, optional): Match type filter (normal, ranked, etc.)
- `count` (str, optional): Number of matches to return

**Example:**
```python
get_match_list(
    puuid="Player's Puuid",
    type="ranked",
    count="20"
)
```

### `get_match_detail`
Get detailed match data by match ID.

**Parameters:**
- `match_id` (str): Match ID (e.g., "NA1_5354690210")

**Example:**
```python
get_match_detail(match_id="NA1_5354690210")
```

### `get_match_summary`
Get truncated match summaries for multiple matches (max 10 matches) with player-specific context.

**Parameters:**
- `match_ids` (List[str]): List of match IDs
- `game_name` (str): Player's game name to search for additional context

**Example:**
```python
get_match_summary(
    match_ids=["NA1_5354690210", "NA1_5354690211"],
    game_name="Faker"
)
```

## Rate Limiting

The server respects Riot Games API rate limits. If you encounter rate limiting issues, consider implementing additional retry logic or request throttling.

## Error Handling

The server includes comprehensive error handling:
- API errors are logged with status codes and error messages
- Network failures are caught and logged
- Invalid requests return `None` values

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Disclaimer

This project is not affiliated with Riot Games. League of Legends is a trademark of Riot Games, Inc.

## Support

For issues and questions:
- Check the [Riot Games API documentation](https://developer.riotgames.com/)
- Open an issue in this [repository](https://github.com/yshi50/league-data-mcp)