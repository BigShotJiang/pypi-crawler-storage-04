"""Google Docs MCP package entry points and version."""

__all__ = ["main"]


def main() -> None:
    pass
