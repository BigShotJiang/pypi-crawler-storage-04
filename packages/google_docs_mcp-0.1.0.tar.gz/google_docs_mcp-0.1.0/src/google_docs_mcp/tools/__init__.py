"""Tools registry for MCP server."""
