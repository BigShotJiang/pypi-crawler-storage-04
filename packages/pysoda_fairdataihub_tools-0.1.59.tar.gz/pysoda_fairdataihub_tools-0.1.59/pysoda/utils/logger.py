# filepath: c:\Users\aaron\pysoda\pysoda\utils\logger.py
import logging

# Create a logger for the package
logger = logging.getLogger("pysoda.utils")
logger.setLevel(logging.WARNING)  # Set the default log level