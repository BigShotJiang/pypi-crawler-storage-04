# `timecopilot.models.ensembles`

::: timecopilot.models.ensembles.median
    options:
        members:
            - MedianEnsemble