# `timecopilot.models.utils.forecaster`

::: timecopilot.models.utils.forecaster
    options:
        members:
            - get_seasonality
            - maybe_infer_freq
            - Forecaster