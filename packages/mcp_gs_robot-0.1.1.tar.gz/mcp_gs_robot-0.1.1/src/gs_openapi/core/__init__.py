"""
Core modules for Gausium OpenAPI.
"""