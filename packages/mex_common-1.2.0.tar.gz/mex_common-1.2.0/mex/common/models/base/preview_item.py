from mex.common.models.base.model import BaseModel


class PreviewItem(BaseModel, extra="forbid"):
    """Base model for previews of merged items."""
