"""
Task execution workflows for Gausium robots.
"""