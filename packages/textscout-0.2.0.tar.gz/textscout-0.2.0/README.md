# TextScout

`textscout` is a simple and lightweight Python library for basic text analysis. It provides quick statistics like word count, character count, sentence count, and estimated reading time.

## Installation

You can install `textscout` via pip:

```bash
pip install textscout