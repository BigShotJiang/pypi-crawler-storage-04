from virtool.models import BaseModel


class UserNested(BaseModel):
    id: str
    handle: str
