"""
App stand-in used to generate API docs.
"""

from virtool.app import create_app_without_startup

app = create_app_without_startup()
