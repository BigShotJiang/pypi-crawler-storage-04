from pathlib import Path

example_path = Path(__file__).parent.parent / "assets" / "example"
