"""
Version strings
"""

# Current version tag
__version__ = "9.0.0"
