"""
Errors module
"""


class SerializeError(Exception):
    """
    Raised when data serialization fails
    """
