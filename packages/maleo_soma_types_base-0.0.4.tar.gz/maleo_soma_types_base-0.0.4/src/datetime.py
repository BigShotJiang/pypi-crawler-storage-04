from datetime import date, datetime
from typing import Optional


OptionalDate = Optional[date]
OptionalDatetime = Optional[datetime]
