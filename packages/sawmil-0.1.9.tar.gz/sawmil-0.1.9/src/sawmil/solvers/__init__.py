from ._gurobi import quadprog_gurobi
from ._osqp import quadprog_osqp

__all__ = ["quadprog_gurobi", "quadprog_osqp"]