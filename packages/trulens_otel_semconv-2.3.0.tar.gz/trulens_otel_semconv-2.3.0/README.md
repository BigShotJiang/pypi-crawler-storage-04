# Semantic Conventions for TruLens Spans

This package describes the conventions for attribute names and some attribute values present in spans produced or interpreted by TruLens.
