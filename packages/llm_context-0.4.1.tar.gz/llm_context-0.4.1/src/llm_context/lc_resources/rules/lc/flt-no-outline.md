---
description: Excludes all files from outline selection using gitignore patterns. Use to focus context on full file content without structural summaries.
gitignores:
  outline-files: ["**/*"]
---
