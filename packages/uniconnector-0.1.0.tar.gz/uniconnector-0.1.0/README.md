# UniConnector

A simple library to connect to multiple database types with a single function.

## Installation

Install the base library:
```bash
pip install uniconnector