# uniconnector/__init__.py

from .connector import connect