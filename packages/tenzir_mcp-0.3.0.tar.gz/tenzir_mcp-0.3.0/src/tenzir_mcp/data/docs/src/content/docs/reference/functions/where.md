---
title: where
category: List
example: 'xs.where(x => x > 5)'
---

Filters list elements based on a predicate.

```tql
where(xs:list, any->bool) -> list
```

## Description

The `where` function keeps only elements of a list for which a predicate
evaluates to `true`.

### `xs: list`

A list of values.

### `function: any -> bool`

A lambda function that is evaluated for each list element.

## Examples

### Keep only elements greater than 3

```tql
from {
  xs: [1, 2, 3, 4, 5]
}
xs = xs.where(x => x > 3)
```

```tql
{
  xs: [4, 5]
}
```

## See Also

[`map`](/reference/functions/map)
