"""Tenzir MCP Server."""

__version__ = "0.1.0"
__author__ = "Tenzir"
__email__ = "engineering@tenzir.com"

__all__ = [
    "__version__",
    "__author__",
    "__email__",
]
