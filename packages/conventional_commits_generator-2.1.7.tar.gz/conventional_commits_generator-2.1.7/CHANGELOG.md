# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [2.1.7] - 2025-08-29

### Added
- Version 2.1.7 release

### Changed

### Fixed


## [2.1.6] - 2025-08-29

### Added
- Version 2.1.6 release

### Changed

### Fixed


## [2.1.5] - 2025-08-29

### Added
- Version 2.1.5 release

### Changed

### Fixed


## [2.1.4] - 2025-08-29

### Added
- Version 2.1.4 release

### Changed

### Fixed


## [2.1.3] - 2025-08-29

### Added
- Automatic version bumping and release process

### Changed
- Improved CI/CD pipeline with automated PyPI deployment

### Fixed
- Version consistency across all project files
