"""Entry point for executing the module directly."""

from ccg.cli import main

if __name__ == "__main__":
    main()
