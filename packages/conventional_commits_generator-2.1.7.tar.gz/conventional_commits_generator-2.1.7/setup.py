#!/usr/bin/env python3
"""Setup script for backward compatibility."""

from setuptools import setup

# This file is for backward compatibility only.
# We're using pyproject.toml.
setup()
