"""
Data package containing resources for Rootly MCP Server.
This package includes the OpenAPI (Swagger) specification for the Rootly API.
""" 