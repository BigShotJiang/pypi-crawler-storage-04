"""Prompt management module for MCP Composer."""

from .prompt_manager import MCPPromptManager

__all__ = ["MCPPromptManager"]
