from mcp_composer.core.utils.cli import main

if __name__ == "__main__":
    main()
