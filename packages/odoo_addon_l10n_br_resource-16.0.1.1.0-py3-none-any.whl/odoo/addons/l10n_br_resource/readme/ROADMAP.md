\[ Enumerate known caveats and future potential improvements.  
It is mostly intended for end-users, and can also help potential new
contributors discovering new features to implement. \]

1.  Remove pybrasil from dependencies;
2.  Review parent_id many2one field to handle better relation with Odoo
    core;
