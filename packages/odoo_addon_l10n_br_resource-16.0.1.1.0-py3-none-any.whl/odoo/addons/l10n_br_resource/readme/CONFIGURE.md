Após a instalação do módulo acesse Configurações \> Técnico \> Recursos
\> Importar calendário brasileiro. Definir um intervalo, selecionando o
seu tipo e intervalo para que o calendário seja carregado.
