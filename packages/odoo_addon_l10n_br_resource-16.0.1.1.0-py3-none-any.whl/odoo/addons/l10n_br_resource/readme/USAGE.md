To use this module, you need to:

1.  Call your methods in modules inherited from it;
2.  Add manual calendar leaves manualy if you need;
