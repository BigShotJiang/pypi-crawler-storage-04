This module extends the core resource module to add data for Brazil. It
defines a Brazilian calendar and some tools to compute dates used in
financial and payroll modules.
