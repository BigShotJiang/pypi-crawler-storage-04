To install this module, you need to:

1.  Install <https://github.com/peopledoc/workalendar>
