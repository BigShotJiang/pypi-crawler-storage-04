"""Luma CLI tests."""
