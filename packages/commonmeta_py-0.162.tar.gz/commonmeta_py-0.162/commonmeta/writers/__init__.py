"""Writers for different metadata formats"""
