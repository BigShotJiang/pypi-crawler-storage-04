"""Matrice data processing module."""

from matrice.utils import dependencies_check

dependencies_check("opencv-python")