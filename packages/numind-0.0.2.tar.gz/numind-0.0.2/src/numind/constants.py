"""Constants for the NuMind package."""

NUMIND_API_KEY_ENV_VAR_NAME = "NUMIND_API_KEY"
TMP_PROJECT_NAME = "tmp_project_api"
