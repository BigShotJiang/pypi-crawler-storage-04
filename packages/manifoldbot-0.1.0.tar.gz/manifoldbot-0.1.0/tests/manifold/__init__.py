"""Tests for ManifoldBot manifold module."""
