from .metrics import GraphNeuralNetworkMetric

__all__ = [
    'GraphNeuralNetworkMetric',
]
