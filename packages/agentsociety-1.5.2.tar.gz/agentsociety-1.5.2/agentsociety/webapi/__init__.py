"""
AgentSociety Web API
=================

AgentSociety Web API is a FastAPI-based web API for AgentSociety.
"""
