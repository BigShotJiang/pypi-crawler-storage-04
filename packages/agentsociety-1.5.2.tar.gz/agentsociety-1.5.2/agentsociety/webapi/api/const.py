__all__ = ["DEMO_USER_ID"]

DEMO_USER_ID = "DEMO"
