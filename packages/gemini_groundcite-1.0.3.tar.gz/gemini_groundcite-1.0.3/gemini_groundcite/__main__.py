"""Entry point for python -m text_analyzer."""

from .cli import main

if __name__ == "__main__":
    main()
