"""
CLI module unit tests
"""
