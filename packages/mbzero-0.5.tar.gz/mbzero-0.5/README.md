# mbzero: simple python bindings for Musicbrainz

mbzero is a simple library to provide bindings to the musicbrainz ws/2 API.

More documentation is available at
[Read the Docs](https://mbzero.readthedocs.io).

## License

The license is BSD-2 to give the maximum permission for hacking and sharing.

## Requirements

This requires `python3`, `python-request`, `python-requests-oauthlib`

## Manual build/installation

Manual build and install requires `python-build` and `python-installer`

You can build the library using `python -m build` and install with `python -m
installer --dest=<destination>` or `python -m installer --prefix=<prefix>`.

## Contribute

Feel free to fork or contribute on
<https://gitlab.com/Louson-public/personal/python-mbzero>. Issues and PR are
welcome as much as much I can support them.

### Developper Certificate of Origin

The `-s` option of `git commit` adds a `“Signed-off-by:”` line to your commit
message. There is the same requirement for contributing to the Linux
kernel. Adding such a line signifies that you, the submitter, have agreed to the
[Developer’s Certificate of Origin 1.1](https://developercertificate.org) as
follows:

```
Developer's Certificate of Origin 1.1

By making a contribution to this project, I certify that:

(a) The contribution was created in whole or in part by me and I
    have the right to submit it under the open source license
    indicated in the file; or

(b) The contribution is based upon previous work that, to the best
    of my knowledge, is covered under an appropriate open source
    license and I have the right under that license to submit that
    work with modifications, whether created in whole or in part
    by me, under the same open source license (unless I am
    permitted to submit under a different license), as indicated
    in the file; or

(c) The contribution was provided directly to me by some other
    person who certified (a), (b) or (c) and I have not modified
    it.

(d) I understand and agree that this project and the contribution
    are public and that a record of the contribution (including all
    personal information I submit with it, including my sign-off) is
    maintained indefinitely and may be redistributed consistent with
    this project or the open source license(s) involved.
```

## Code formatting & linting

Code is formatted using `ruff format`.
Code is linted using `ruff check`.
Type information is verified using `ty check`.

## Test

Test the library with `pytest -v`

## Authors

mbzero is by [Louis Rannou](https://gitlab.com/louson). Contributions had been
made by:

* [Further Lin](https://gitlab.com/i.further)
* [Nicolas Mémeint](https://github.com/nicomem)

### 2023 Musicbrainzngs authors

These bindings is a fork from the python-musicbrainzngs project written by
[Alastair Porter](http://github.com/alastair). Contributions had been made
by:

* [Adrian Sampson](https://github.com/sampsyo)
* [Corey Farwell](https://github.com/frewsxcv)
* [Galen Hazelwood](https://github.com/galenhz)
* [Greg Ward](https://github.com/gward)
* [Ian McEwen](https://github.com/ianmcorvidae)
* [Jérémie Detrey](https://github.com/jdetrey)
* [Johannes Dewender](https://github.com/JonnyJD)
* [Michael Marineau](https://github.com/marineam)
* [Patrick Speiser](https://github.com/doskir)
* [Pavan Chander](https://github.com/navap)
* [Paul Bailey](https://github.com/paulbailey)
* [Rui Gonçalves](https://github.com/ruippeixotog)
* [Ryan Helinski](https://github.com/rlhelinski)
* [Sam Doshi](https://github.com/samdoshi)
* [Shadab Zafar](https://github.com/dufferzafar)
* [Simon Chopin](https://github.com/laarmen)
* [Thomas Vander Stichele](https://github.com/thomasvs)
* [Wieland Hoffmann](https://github.com/mineo)
