# Common utilities for nestbox-ai-functions-python
