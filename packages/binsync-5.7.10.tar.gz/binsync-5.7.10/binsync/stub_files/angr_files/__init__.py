from binsync.interface_overrides.angr import BinsyncPlugin

__all__ = ["BinsyncPlugin"]