"""
Streaming support for EncypherAI metadata encoding.
"""

from encypher.streaming.handlers import StreamingHandler

__all__ = ["StreamingHandler"]
