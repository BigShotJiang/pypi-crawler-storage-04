"""
Tests for the interoperability utilities.
"""
