"""
Tests for EncypherAI Core package.
"""
