Janitor.GiveChore()
Janitor.Clean()