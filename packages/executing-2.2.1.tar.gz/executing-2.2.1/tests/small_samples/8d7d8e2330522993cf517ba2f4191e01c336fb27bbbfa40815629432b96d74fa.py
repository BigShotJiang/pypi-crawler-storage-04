class SupportsAbs[T]:
    pass