dict_of_parts = {
    "DC-gearboxed-motor-12V-120RPM": "proposed, not used.",
    "dc-motor-12-VDC-45W": "type 2, 2 x right + 2 x left",
    "ultrasonic-sensor": "4 x",
    "resistor": "4 x 1 kΩ + 4 x 2 kΩ + 4 x 330-470 Ω",
    "LED": "4 x blue",
}
