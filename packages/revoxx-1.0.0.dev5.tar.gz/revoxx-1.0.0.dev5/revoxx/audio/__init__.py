"""Audio processing and I/O modules."""

# Empty __init__.py to allow selective imports without forcing dependencies
