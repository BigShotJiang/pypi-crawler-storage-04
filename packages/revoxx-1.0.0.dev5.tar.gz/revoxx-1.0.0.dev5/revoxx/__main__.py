"""Main entry point for running revoxx as a module."""

from .app import main

if __name__ == "__main__":
    main()
