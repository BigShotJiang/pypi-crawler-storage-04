# Dialog Status
YES = True
NO = False
CANCEL = None
NULL = 0
EXIT = 1
OK = 2
UPDATED = 3
ERROR = 4

# Modes
VIEW = 0
NEW = 1
EDIT = 2
DELETE = 3
