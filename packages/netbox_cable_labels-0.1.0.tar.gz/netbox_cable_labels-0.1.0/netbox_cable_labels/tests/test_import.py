"""Test that the module can be imported."""
from netbox_cable_labels import *  # pylint: disable=wildcard-import,unused-wildcard-import
