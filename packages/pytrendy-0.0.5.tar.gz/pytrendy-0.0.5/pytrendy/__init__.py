from .detect_trends import detect_trends
from .plot_pytrendy import plot_pytrendy
from .simpledtw import dtw