# SweatStack Python client library


This is the official Python client library for SweatStack.

Documentation can be found [here](https://developer.sweatstack.no/getting-started/).