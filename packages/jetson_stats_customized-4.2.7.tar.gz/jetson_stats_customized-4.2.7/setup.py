from setuptools import setup, find_packages

setup(
    name="jetson-stats-customized",
    version="4.2.7",
    description="Modified jetson-stats",
    packages=find_packages(),
    install_requires=[
        "distro",
        "smbus2"
    ],
    python_requires=">=3.6",
)
