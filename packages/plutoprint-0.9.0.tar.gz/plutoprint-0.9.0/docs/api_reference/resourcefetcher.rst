ResourceFetcher
===============

.. currentmodule:: plutoprint

.. autoclass:: ResourceFetcher
    :members:

.. autoclass:: DefaultResourceFetcher
    :members:

.. autodata:: default_resource_fetcher
