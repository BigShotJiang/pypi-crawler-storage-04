PDFMetadata
===========

.. currentmodule:: plutoprint

.. autoclass:: PDFMetadata

.. autodata:: PDF_METADATA_TITLE

.. autodata:: PDF_METADATA_AUTHOR

.. autodata:: PDF_METADATA_SUBJECT

.. autodata:: PDF_METADATA_KEYWORDS

.. autodata:: PDF_METADATA_CREATOR

.. autodata:: PDF_METADATA_CREATION_DATE

.. autodata:: PDF_METADATA_MODIFICATION_DATE
