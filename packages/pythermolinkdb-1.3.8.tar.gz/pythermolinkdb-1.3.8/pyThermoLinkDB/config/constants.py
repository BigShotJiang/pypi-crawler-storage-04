# CONSTANTS

# SECTION: default rules
DEFAULT_RULES_KEY = "ALL"
