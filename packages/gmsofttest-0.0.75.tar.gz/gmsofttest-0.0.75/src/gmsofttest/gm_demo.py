"""
Name : gm_demo.py.py
Author  : 写上自己的名字
Contact : 邮箱地址
Time    : 2023-12-07 16:08
Desc:
"""

def my_add(int1, int2):
	result = int1 + int2
	return result


if __name__ == '__main__':
	print(f"相加结果是：{my_add(1, 5)}")

