* Alessandro Camilli <alessandrocamilli@openforce.it>
* Silvio Gregorini <silviogregorini@openforce.it>
* Stefano Pezzini <stefanopezzini@openforce.it>
* Lorenzo Battistini <lb@takobi.online>
* `TAKOBI <https://takobi.online>`_:

  * Simone Rubino <sir@takobi.online>
* `Aion Tech <https://aiontech.company/>`_:

  * Simone Rubino <simone.rubino@aion-tech.it>

Base icon made by `surang <https://www.flaticon.com/authors/surang>`_ from `www.flaticon.com <https://www.flaticon.com/>`_.
