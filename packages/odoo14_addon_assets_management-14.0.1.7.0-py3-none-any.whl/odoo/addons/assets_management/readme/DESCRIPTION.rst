This modules allows account management of companies' assets.
