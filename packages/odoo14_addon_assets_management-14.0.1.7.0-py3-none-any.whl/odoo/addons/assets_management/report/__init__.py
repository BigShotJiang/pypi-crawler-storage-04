# Author(s): Silvio Gregorini (silviogregorini@openforce.it)
# Copyright 2019 Openforce Srls Unipersonale (www.openforce.it)
# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl).

from . import asset_journal
from . import asset_journal_xlsx
from . import asset_previsional
from . import asset_previsional_xlsx
