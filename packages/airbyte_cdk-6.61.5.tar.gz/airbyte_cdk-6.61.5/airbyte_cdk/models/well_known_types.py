#
# Copyright (c) 2023 Airbyte, Inc., all rights reserved.
#

from airbyte_protocol_dataclasses.models.well_known_types import *  # noqa: F403  # Allow '*'
