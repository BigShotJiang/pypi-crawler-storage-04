########################
# LOG
########################

# The callable to use to configure logging
LOGGING_CONFIG = "logging.config.dictConfig"

# Custom logging configuration.
LOGGING = {}

LOG_LEVEL = "INFO"
