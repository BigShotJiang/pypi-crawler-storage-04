# dblite

A simple Python library to quickly connect to MySQL, SQLite, and MongoDB databases.

## Installation
```bash
pip install dbmini
