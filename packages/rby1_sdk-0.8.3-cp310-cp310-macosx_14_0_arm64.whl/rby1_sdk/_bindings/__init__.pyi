"""

RBY1-SDK Python bindings.

This module provides high-level APIs for RB-Y1 communication, control, modeling, etc.
It includes mathematical operations, dynamics calculations, robot control,
and various utility functions for working with RB-Y1 robots.

Submodules
----------
math : Mathematical operations and Lie group utilities
dynamics : Robot dynamics calculations
upc : Utilities for controlling and communicating with devices on the user PC
"""
from __future__ import annotations
import datetime
import numpy
import pybind11_stubgen.typing_ext
import typing
from . import dynamics
from . import math
from . import upc
__all__: list[str] = ['ArmCommandBuilder', 'ArmCommandFeedback', 'BatteryInfo', 'BatteryState', 'BodyCommandBuilder', 'BodyCommandFeedback', 'BodyComponentBasedCommandBuilder', 'BodyComponentBasedCommandFeedback', 'CartesianCommandBuilder', 'CartesianCommandFeedback', 'CartesianImpedanceControlCommandBuilder', 'CartesianImpedanceControlCommandFeedback', 'Color', 'CommandFeedback', 'CommandHeaderBuilder', 'CommandHeaderFeedback', 'ComponentBasedCommandBuilder', 'ComponentBasedCommandFeedback', 'ControlManagerState', 'DynamixelBus', 'EMOInfo', 'EMOState', 'FTSensorData', 'Feedback', 'GravityCompensationCommandBuilder', 'GravityCompensationCommandFeedback', 'HeadCommandBuilder', 'HeadCommandFeedback', 'ImpedanceControlCommandBuilder', 'ImpedanceControlCommandFeedback', 'JogCommandBuilder', 'JogCommandFeedback', 'JointGroupPositionCommandBuilder', 'JointGroupPositionCommandFeedback', 'JointImpedanceControlCommandBuilder', 'JointImpedanceControlCommandFeedback', 'JointInfo', 'JointPositionCommandBuilder', 'JointPositionCommandFeedback', 'JointState', 'JointVelocityCommandBuilder', 'JointVelocityCommandFeedback', 'Log', 'MobilityCommandBuilder', 'MobilityCommandFeedback', 'Model_A', 'Model_M', 'Model_T5', 'Model_UB', 'OptimalControlCommandBuilder', 'OptimalControlCommandFeedback', 'PIDGain', 'PowerInfo', 'PowerState', 'RobotCommandBuilder', 'RobotCommandFeedback', 'RobotInfo', 'RobotState_A', 'RobotState_M', 'RobotState_T5', 'RobotState_UB', 'Robot_A', 'Robot_A_CommandHandler', 'Robot_A_CommandStreamHandler', 'Robot_A_ControlInput', 'Robot_A_ControlState', 'Robot_M', 'Robot_M_CommandHandler', 'Robot_M_CommandStreamHandler', 'Robot_M_ControlInput', 'Robot_M_ControlState', 'Robot_T5', 'Robot_T5_CommandHandler', 'Robot_T5_CommandStreamHandler', 'Robot_T5_ControlInput', 'Robot_T5_ControlState', 'Robot_UB', 'Robot_UB_CommandHandler', 'Robot_UB_CommandStreamHandler', 'Robot_UB_ControlInput', 'Robot_UB_ControlState', 'SE2VelocityCommandBuilder', 'SE2VelocityCommandFeedback', 'SerialDevice', 'SerialStream', 'StopCommandBuilder', 'StopCommandFeedback', 'SystemStat', 'ToolFlangeState', 'TorsoCommandBuilder', 'TorsoCommandFeedback', 'WholeBodyCommandBuilder', 'WholeBodyCommandFeedback', 'WifiNetwork', 'WifiStatus', 'create_robot_a', 'create_robot_m', 'create_robot_t5', 'create_robot_ub', 'dynamics', 'math', 'printoptions', 'set_printoptions', 'upc']
class ArmCommandBuilder:
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, arg0: JointPositionCommandBuilder) -> None:
        ...
    @typing.overload
    def __init__(self, arg0: GravityCompensationCommandBuilder) -> None:
        ...
    @typing.overload
    def __init__(self, arg0: CartesianCommandBuilder) -> None:
        ...
    @typing.overload
    def __init__(self, arg0: ImpedanceControlCommandBuilder) -> None:
        ...
    @typing.overload
    def __init__(self, arg0: JointImpedanceControlCommandBuilder) -> None:
        ...
    @typing.overload
    def __init__(self, arg0: CartesianImpedanceControlCommandBuilder) -> None:
        ...
    @typing.overload
    def set_command(self, joint_position_command_builder: JointPositionCommandBuilder) -> ArmCommandBuilder:
        ...
    @typing.overload
    def set_command(self, gravity_compensation_command_builder: GravityCompensationCommandBuilder) -> ArmCommandBuilder:
        ...
    @typing.overload
    def set_command(self, cartesian_command_builder: CartesianCommandBuilder) -> ArmCommandBuilder:
        ...
    @typing.overload
    def set_command(self, impedance_control_command_builder: ImpedanceControlCommandBuilder) -> ArmCommandBuilder:
        ...
    @typing.overload
    def set_command(self, joint_impedance_control_command_builder: JointImpedanceControlCommandBuilder) -> ArmCommandBuilder:
        ...
    @typing.overload
    def set_command(self, cartesian_impedance_control_command_builder: CartesianImpedanceControlCommandBuilder) -> ArmCommandBuilder:
        ...
class ArmCommandFeedback(CommandFeedback):
    def __init__(self) -> None:
        ...
    @property
    def cartesian_command(self) -> CartesianCommandFeedback:
        ...
    @property
    def cartesian_impedance_control_command(self) -> CartesianImpedanceControlCommandFeedback:
        ...
    @property
    def gravity_compensation_command(self) -> GravityCompensationCommandFeedback:
        ...
    @property
    def impedance_control_command(self) -> ImpedanceControlCommandFeedback:
        ...
    @property
    def joint_impedance_control_command(self) -> JointImpedanceControlCommandFeedback:
        ...
    @property
    def joint_position_command(self) -> JointPositionCommandFeedback:
        ...
class BatteryInfo:
    """
    
    Battery information.
    
    This class represents battery information for the robot.
    **Currently contains no specific attributes.**
    """
    def __init__(self) -> None:
        ...
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
class BatteryState:
    """
    
    Battery state information.
    
    Provides information about battery status including voltage, current, and charge level.
    
    Attributes
    ----------
    voltage : float
        Battery voltage in volts.
    current : float
        Battery current in amperes.
    level_percent : float
        Battery charge level percentage (0.0 to 100.0).
      
    """
    def __init__(self) -> None:
        """
              Construct a BatteryState instance.
        """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    @property
    def current(self) -> float:
        """
        Battery current.
        
        Type
        ----
        float
            Battery current in amperes.
        """
    @property
    def level_percent(self) -> float:
        """
        Battery charge level.
        
        Type
        ----
        float
            Battery charge level percentage (0.0 to 100.0).
        """
    @property
    def voltage(self) -> float:
        """
        Battery voltage.
        
        Type
        ----
        float
            Battery voltage in volts.
        """
class BodyCommandBuilder:
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, arg0: JointPositionCommandBuilder) -> None:
        ...
    @typing.overload
    def __init__(self, arg0: OptimalControlCommandBuilder) -> None:
        ...
    @typing.overload
    def __init__(self, arg0: GravityCompensationCommandBuilder) -> None:
        ...
    @typing.overload
    def __init__(self, arg0: CartesianCommandBuilder) -> None:
        ...
    @typing.overload
    def __init__(self, arg0: BodyComponentBasedCommandBuilder) -> None:
        ...
    @typing.overload
    def __init__(self, arg0: JointImpedanceControlCommandBuilder) -> None:
        ...
    @typing.overload
    def __init__(self, arg0: CartesianImpedanceControlCommandBuilder) -> None:
        ...
    @typing.overload
    def set_command(self, joint_position_command_builder: JointPositionCommandBuilder) -> BodyCommandBuilder:
        ...
    @typing.overload
    def set_command(self, optimal_control_command_builder: OptimalControlCommandBuilder) -> BodyCommandBuilder:
        ...
    @typing.overload
    def set_command(self, gravity_compensation_command_builder: GravityCompensationCommandBuilder) -> BodyCommandBuilder:
        ...
    @typing.overload
    def set_command(self, cartesian_command_builder: CartesianCommandBuilder) -> BodyCommandBuilder:
        ...
    @typing.overload
    def set_command(self, body_component_based_command_builder: BodyComponentBasedCommandBuilder) -> BodyCommandBuilder:
        ...
    @typing.overload
    def set_command(self, joint_impedance_control_command_builder: JointImpedanceControlCommandBuilder) -> BodyCommandBuilder:
        ...
    @typing.overload
    def set_command(self, cartesian_impedance_control_command_builder: CartesianImpedanceControlCommandBuilder) -> BodyCommandBuilder:
        ...
class BodyCommandFeedback(CommandFeedback):
    def __init__(self) -> None:
        ...
    @property
    def body_component_based_command(self) -> BodyComponentBasedCommandFeedback:
        ...
    @property
    def cartesian_command(self) -> CartesianCommandFeedback:
        ...
    @property
    def cartesian_impedance_control_command(self) -> CartesianImpedanceControlCommandFeedback:
        ...
    @property
    def gravity_compensation_command(self) -> GravityCompensationCommandFeedback:
        ...
    @property
    def joint_impedance_control_command(self) -> JointImpedanceControlCommandFeedback:
        ...
    @property
    def joint_position_command(self) -> JointPositionCommandFeedback:
        ...
    @property
    def optimal_control_command(self) -> OptimalControlCommandFeedback:
        ...
class BodyComponentBasedCommandBuilder:
    def __init__(self) -> None:
        ...
    def set_left_arm_command(self, arm_command_builder: ArmCommandBuilder) -> BodyComponentBasedCommandBuilder:
        ...
    def set_right_arm_command(self, arm_command_builder: ArmCommandBuilder) -> BodyComponentBasedCommandBuilder:
        ...
    def set_torso_command(self, torso_command_builder: TorsoCommandBuilder) -> BodyComponentBasedCommandBuilder:
        ...
class BodyComponentBasedCommandFeedback(CommandFeedback):
    def __init__(self) -> None:
        ...
    @property
    def left_arm_command(self) -> ArmCommandFeedback:
        ...
    @property
    def right_arm_command(self) -> ArmCommandFeedback:
        ...
    @property
    def torso_command(self) -> TorsoCommandFeedback:
        ...
class CartesianCommandBuilder:
    def __init__(self) -> None:
        ...
    def add_joint_position_target(self, joint_name: str, target_position: float, velocity_limit: float | None = None, acceleration_limit: float | None = None) -> CartesianCommandBuilder:
        ...
    def add_target(self, ref_link_name: str, link_name: str, T: numpy.ndarray[tuple[typing.Literal[4], typing.Literal[4]], numpy.dtype[numpy.float64]], linear_velocity_limit: float, angular_velocity_limit: float, acceleration_limit_scaling: float) -> CartesianCommandBuilder:
        ...
    def set_command_header(self, command_header_builder: CommandHeaderBuilder) -> CartesianCommandBuilder:
        ...
    def set_minimum_time(self, minimum_time: float) -> CartesianCommandBuilder:
        ...
    def set_stop_joint_position_tracking_error(self, stop_joint_position_tracking_error: float) -> CartesianCommandBuilder:
        ...
    def set_stop_orientation_tracking_error(self, stop_orientation_tracking_error: float) -> CartesianCommandBuilder:
        ...
    def set_stop_position_tracking_error(self, stop_position_tracking_error: float) -> CartesianCommandBuilder:
        ...
class CartesianCommandFeedback(CommandFeedback):
    class TrackingError:
        def __init__(self) -> None:
            ...
        @property
        def orientation_error(self) -> float:
            ...
        @property
        def position_error(self) -> float:
            ...
    def __init__(self) -> None:
        ...
    @property
    def joint_position_tracking_errors(self) -> list[float]:
        ...
    @property
    def manipulability(self) -> float:
        ...
    @property
    def remain_time(self) -> float:
        ...
    @property
    def se3_pose_tracking_errors(self) -> list[CartesianCommandFeedback.TrackingError]:
        ...
class CartesianImpedanceControlCommandBuilder:
    def __init__(self) -> None:
        ...
    def add_joint_limit(self, joint_name: str, lower: float, upper: float) -> CartesianImpedanceControlCommandBuilder:
        ...
    def add_joint_position_target(self, joint_name: str, target_position: float, velocity_limit: float | None = None, acceleration_limit: float | None = None) -> CartesianImpedanceControlCommandBuilder:
        ...
    def add_target(self, ref_link_name: str, link_name: str, T: numpy.ndarray[tuple[typing.Literal[4], typing.Literal[4]], numpy.dtype[numpy.float64]], linear_velocity_limit: float | None = None, angular_velocity_limit: float | None = None, linear_acceleration_limit: float | None = None, angular_acceleration_limit: float | None = None) -> CartesianImpedanceControlCommandBuilder:
        ...
    def set_command_header(self, command_header_builder: CommandHeaderBuilder) -> CartesianImpedanceControlCommandBuilder:
        ...
    def set_joint_damping_ratio(self, damping_ratio: float) -> CartesianImpedanceControlCommandBuilder:
        ...
    def set_joint_stiffness(self, stiffness: numpy.ndarray[tuple[M, typing.Literal[1]], numpy.dtype[numpy.float64]]) -> CartesianImpedanceControlCommandBuilder:
        ...
    def set_joint_torque_limit(self, torque_limit: numpy.ndarray[tuple[M, typing.Literal[1]], numpy.dtype[numpy.float64]]) -> CartesianImpedanceControlCommandBuilder:
        ...
    def set_minimum_time(self, minimum_time: float) -> CartesianImpedanceControlCommandBuilder:
        ...
    def set_reset_reference(self, reset_reference: bool) -> CartesianImpedanceControlCommandBuilder:
        ...
    def set_stop_joint_position_tracking_error(self, stop_joint_position_tracking_error: float) -> CartesianImpedanceControlCommandBuilder:
        ...
    def set_stop_orientation_tracking_error(self, stop_orientation_tracking_error: float) -> CartesianImpedanceControlCommandBuilder:
        ...
    def set_stop_position_tracking_error(self, stop_position_tracking_error: float) -> CartesianImpedanceControlCommandBuilder:
        ...
class CartesianImpedanceControlCommandFeedback(CommandFeedback):
    def __init__(self) -> None:
        ...
    @property
    def manipulability(self) -> float:
        ...
    @property
    def remain_time(self) -> float:
        ...
    @property
    def set_position(self) -> numpy.ndarray[tuple[M, typing.Literal[1]], numpy.dtype[numpy.float64]]:
        ...
class Color:
    """
    
    RGB color representation.
    
    Represents a color using red, green, and blue components.
    
    Attributes
    ----------
    r : int
        Red component (0-255).
    g : int
        Green component (0-255).
    b : int
        Blue component (0-255).
    """
    @typing.overload
    def __init__(self) -> None:
        """
        Construct a Color instance with default values (0, 0, 0).
        """
    @typing.overload
    def __init__(self, r: int, g: int, b: int) -> None:
        """
        Construct a Color instance with specified RGB values.
        
        Parameters
        ----------
        r : int
            Red component (0-255).
        g : int
            Green component (0-255).
        b : int
            Blue component (0-255).
        """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    @property
    def b(self) -> int:
        """
        Blue component.
        
        Type
        ----
        int
            Blue component value (0-255).
        """
    @b.setter
    def b(self, arg0: int) -> None:
        ...
    @property
    def g(self) -> int:
        """
        Green component.
        
        Type
        ----
        int
            Green component value (0-255).
        """
    @g.setter
    def g(self, arg0: int) -> None:
        ...
    @property
    def r(self) -> int:
        """
        Red component.
        
        Type
        ----
        int
            Red component value (0-255).
        """
    @r.setter
    def r(self, arg0: int) -> None:
        ...
class CommandFeedback(Feedback):
    def __init__(self) -> None:
        ...
    @property
    def command_header(self) -> CommandHeaderFeedback:
        ...
class CommandHeaderBuilder:
    """
    
    Command header builder.
    
    Builds command headers with control hold time settings.
    
    Attributes
    ----------
    control_hold_time : float
        Control hold time in seconds.
    """
    def __init__(self) -> None:
        """
              Construct a CommandHeaderBuilder instance.
        """
    def set_control_hold_time(self, control_hold_time: float) -> CommandHeaderBuilder:
        """
        set_control_hold_time(control_hold_time)
        
        Set the control hold time.
        
        Parameters
        ----------
        control_hold_time : float
            Control hold time in seconds.
        
        Returns
        -------
        CommandHeaderBuilder
            Self reference for method chaining.
        
        Examples
        --------
        >>> from rby1_sdk import CommandHeaderBuilder
        >>> # Create command header with control hold time
        >>> header = CommandHeaderBuilder().set_control_hold_time(5.0)
        >>> # Use in command builders
        >>> command = JointPositionCommandBuilder().set_command_header(header)
        >>> # Control hold time keeps the command active for 5 seconds
        """
class CommandHeaderFeedback(Feedback):
    def __init__(self) -> None:
        ...
    @property
    def finished(self) -> bool:
        ...
class ComponentBasedCommandBuilder:
    def __init__(self) -> None:
        ...
    def set_body_command(self, body_command_builder: BodyCommandBuilder) -> ComponentBasedCommandBuilder:
        ...
    def set_head_command(self, head_command_builder: HeadCommandBuilder) -> ComponentBasedCommandBuilder:
        ...
    def set_mobility_command(self, mobility_command_builder: MobilityCommandBuilder) -> ComponentBasedCommandBuilder:
        ...
class ComponentBasedCommandFeedback(CommandFeedback):
    def __init__(self) -> None:
        ...
    @property
    def body_command(self) -> BodyCommandFeedback:
        ...
    @property
    def head_command(self) -> HeadCommandFeedback:
        ...
    @property
    def mobility_command(self) -> MobilityCommandFeedback:
        ...
class ControlManagerState:
    """
    
    Control manager state information.
    
    This class represents the current state of the robot's control manager,
    including operational status, time scaling, and joint enablement.
    
    Attributes
    ----------
    state : State
        Current operational state of the control manager.
    time_scale : float
        Time scaling factor for motion execution (0.0 to 1.0).
    control_state : ControlState
        Current control execution state.
    enabled_joint_idx : list[int]
        Indices of currently enabled joints.
    unlimited_mode_enabled : bool
        Whether unlimited mode is currently enabled.
    """
    class ControlState:
        """
        
        Control execution state enumeration.
        
        Defines the current state of control execution within the control manager.
        
        Members
        -------
        Unknown : int
            Control state is unknown or undefined.
        Idle : int
            No control commands are being executed.
        Executing : int
            Control commands are actively being executed.
        Switching : int
            Control is switching between different modes or commands.
        
        
        Members:
        
          Unknown : 
        Control state is unknown or undefined.
        
        
          Idle : 
        No control commands are being executed.
        
        
          Executing : 
        Control commands are actively being executed.
        
        
          Switching : 
        Control is switching between different modes or commands.
        """
        Executing: typing.ClassVar[ControlManagerState.ControlState]  # value = <ControlState.Executing: 2>
        Idle: typing.ClassVar[ControlManagerState.ControlState]  # value = <ControlState.Idle: 1>
        Switching: typing.ClassVar[ControlManagerState.ControlState]  # value = <ControlState.Switching: 3>
        Unknown: typing.ClassVar[ControlManagerState.ControlState]  # value = <ControlState.Unknown: 0>
        __members__: typing.ClassVar[dict[str, ControlManagerState.ControlState]]  # value = {'Unknown': <ControlState.Unknown: 0>, 'Idle': <ControlState.Idle: 1>, 'Executing': <ControlState.Executing: 2>, 'Switching': <ControlState.Switching: 3>}
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: int) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: int) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    class State:
        """
        
        Control manager operational state enumeration.
        
        Defines the possible operational states of the control manager,
        from normal operation to various fault conditions.
        
        Members
        -------
        Unknown : int
            State is unknown or undefined.
        Idle : int
            Control manager is idle and ready for commands.
        Enabled : int
            Control manager is enabled and actively controlling.
        MinorFault : int
            Minor fault condition detected.
        MajorFault : int
            Major fault condition detected.
        
        
        Members:
        
          Unknown : 
        State is unknown or undefined.
        
        
          Idle : 
        Control manager is idle and ready for commands.
        
        
          Enabled : 
        Control manager is enabled and actively controlling.
        
        
          MinorFault : 
        Minor fault condition detected.
        
        
          MajorFault : 
        Major fault condition detected.
        """
        Enabled: typing.ClassVar[ControlManagerState.State]  # value = <State.Enabled: 2>
        Idle: typing.ClassVar[ControlManagerState.State]  # value = <State.Idle: 1>
        MajorFault: typing.ClassVar[ControlManagerState.State]  # value = <State.MajorFault: 4>
        MinorFault: typing.ClassVar[ControlManagerState.State]  # value = <State.MinorFault: 3>
        Unknown: typing.ClassVar[ControlManagerState.State]  # value = <State.Unknown: 0>
        __members__: typing.ClassVar[dict[str, ControlManagerState.State]]  # value = {'Unknown': <State.Unknown: 0>, 'Idle': <State.Idle: 1>, 'Enabled': <State.Enabled: 2>, 'MinorFault': <State.MinorFault: 3>, 'MajorFault': <State.MajorFault: 4>}
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: int) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: int) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    def __init__(self) -> None:
        """
        Construct a ControlManagerState instance with default values.
        """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    @property
    def control_state(self) -> ControlManagerState.ControlState:
        """
        Current control execution state.
        
        Type
        ----
        ControlState
            Enumeration value indicating the control execution state.
        """
    @property
    def enabled_joint_idx(self) -> list[int]:
        """
        Indices of currently enabled joints.
        
        Type
        ----
        list[int]
            List of joint indices that are currently enabled for control.
        """
    @property
    def state(self) -> ControlManagerState.State:
        """
        Current operational state of the control manager.
        
        Type
        ----
        State
            Enumeration value indicating the operational state.
        """
    @property
    def time_scale(self) -> float:
        """
        Time scaling factor for motion execution.
        
        Type
        ----
        float
            Time scaling factor from 0.0 (stopped) to 1.0 (normal speed).
        """
    @property
    def unlimited_mode_enabled(self) -> bool:
        """
        Whether unlimited mode is currently enabled.
        
        Type
        ----
        bool
            ``True`` if unlimited mode is enabled, ``False`` otherwise.
        """
class DynamixelBus:
    """
    
    Dynamixel bus communication interface.
    
    This class provides low-level communication with Dynamixel servos
    including motor control, PID tuning, and status monitoring.
    
    Attributes
    ----------
    ProtocolVersion : float
        Dynamixel protocol version (2.0).
    DefaultBaudrate : int
        Default communication baudrate (2000000).
    AddrTorqueEnable : int
        Memory address for torque enable/disable.
    AddrPresentCurrent : int
        Memory address for current reading.
    AddrPresentVelocity : int
        Memory address for velocity reading.
    AddrPresentPosition : int
        Memory address for position reading.
    AddrGoalCurrent : int
        Memory address for current goal setting.
    AddrGoalPosition : int
        Memory address for position goal setting.
    AddrOperatingMode : int
        Memory address for operating mode setting.
    AddrPresentButtonState : int
        Memory address for button state reading.
    AddrGoalVibrationLevel : int
        Memory address for vibration level setting.
    AddrPositionPGain : int
        Memory address for position P gain.
    AddrPositionIGain : int
        Memory address for position I gain.
    AddrPositionDGain : int
        Memory address for position D gain.
    TorqueEnable : int
        Value to enable torque (1).
    TorqueDisable : int
        Value to disable torque (0).
    CurrentControlMode : int
        Operating mode for current control (0).
    CurrentBasedPositionControlMode : int
        Operating mode for current-based position control (5).
    AddrCurrentTemperature : int
        Memory address for temperature reading.
    """
    class ButtonState:
        """
        
        Button state information for gripper devices.
        
        This class represents the state of buttons and triggers
        on gripper or tool devices.
        
        Attributes
        ----------
        button : int
            Button state (0 or 1).
        trigger : int
            Trigger value (0-255).
        """
        def __init__(self) -> None:
            """
            Construct a ButtonState instance with default values.
            """
        def __repr__(self) -> str:
            ...
        def __str__(self) -> str:
            ...
        @property
        def button(self) -> int:
            """
            Button state.
            
            Type
            ----
            int
                Button state: 0 (released) or 1 (pressed).
            """
        @property
        def trigger(self) -> int:
            """
            Trigger value.
            
            Type
            ----
            int
            Trigger value ranging from 0 to 255.
            """
    class MotorState:
        """
        
        Motor state information.
        
        This class represents the current state of a Dynamixel motor
        including position, velocity, current, and temperature.
        
        Attributes
        ----------
        torque_enable : bool
            Whether torque is currently enabled.
        position : float
            Current position in radians.
        velocity : float
            Current velocity in rad/s.
        current : float
            Current current in amperes.
        torque : float
            Current torque in Nm.
        temperature : int
            Current temperature in degrees Celsius.
        """
        def __init__(self) -> None:
            """
            Construct a MotorState instance with default values.
            """
        def __repr__(self) -> str:
            ...
        def __str__(self) -> str:
            ...
        @property
        def current(self) -> float:
            """
            Current current.
            
            Type
            ----
            float
                Current current in amperes.
            """
        @property
        def position(self) -> float:
            """
            Current position.
            
            Type
            ----
            float
                Current position in radians.
            """
        @property
        def temperature(self) -> int:
            """
            Current temperature.
            
            Type
            ----
            int
                Current temperature in degrees Celsius.
            """
        @property
        def torque(self) -> float:
            """
            Current torque.
            
            Type
            ----
            float
                Current torque in Nm.
            """
        @property
        def torque_enable(self) -> bool:
            """
            Whether torque is currently enabled.
            
            Type
            ----
            bool
                True if torque is enabled, False otherwise.
            """
        @property
        def velocity(self) -> float:
            """
            Current velocity.
            
            Type
            ----
            float
                Current velocity in rad/s.
            """
    class PIDGain:
        """
        
        PID gain parameters for position control.
        
        This class represents the proportional, integral, and derivative
        gains used for position control of Dynamixel motors.
        
        Attributes
        ----------
        p_gain : int
            Proportional gain (0-65535).
        i_gain : int
            Integral gain (0-65535).
        d_gain : int
            Derivative gain (0-65535).
        """
        def __init__(self) -> None:
            """
            Construct a PIDGain instance with default values.
            """
        @property
        def d_gain(self) -> int:
            """
            Derivative gain.
            
            Type
            ----
            int
                Derivative gain value (0-65535).
            """
        @d_gain.setter
        def d_gain(self, arg0: int) -> None:
            ...
        @property
        def i_gain(self) -> int:
            """
            Integral gain.
            
            Type
            ----
            int
                Integral gain value (0-65535).
            """
        @i_gain.setter
        def i_gain(self, arg0: int) -> None:
            ...
        @property
        def p_gain(self) -> int:
            """
            Proportional gain.
            
            Type
            ----
            int
                Proportional gain value (0-65535).
            """
        @p_gain.setter
        def p_gain(self, arg0: int) -> None:
            ...
    AddrCurrentTemperature: typing.ClassVar[int] = 146
    AddrGoalCurrent: typing.ClassVar[int] = 102
    AddrGoalPosition: typing.ClassVar[int] = 116
    AddrGoalVibrationLevel: typing.ClassVar[int] = 102
    AddrOperatingMode: typing.ClassVar[int] = 11
    AddrPositionDGain: typing.ClassVar[int] = 80
    AddrPositionIGain: typing.ClassVar[int] = 82
    AddrPositionPGain: typing.ClassVar[int] = 84
    AddrPresentButtonState: typing.ClassVar[int] = 132
    AddrPresentCurrent: typing.ClassVar[int] = 126
    AddrPresentPosition: typing.ClassVar[int] = 132
    AddrPresentVelocity: typing.ClassVar[int] = 128
    AddrTorqueEnable: typing.ClassVar[int] = 64
    CurrentBasedPositionControlMode: typing.ClassVar[int] = 5
    CurrentControlMode: typing.ClassVar[int] = 0
    DefaultBaudrate: typing.ClassVar[int] = 2000000
    ProtocolVersion: typing.ClassVar[float] = 2.0
    TorqueDisable: typing.ClassVar[int] = 0
    TorqueEnable: typing.ClassVar[int] = 1
    def __init__(self, dev_name: str) -> None:
        """
        Construct a DynamixelBus instance.
        
        Parameters
        ----------
        dev_name : str
            Device name (e.g., "/dev/ttyUSB0" on Linux).
        """
    def get_motor_states(self, ids: list[int]) -> list[tuple[int, DynamixelBus.MotorState]] | None:
        """
        get_motor_states(ids)
        
        Get motor states for multiple motors.
        
        Parameters
        ----------
        ids : list[int]
            List of motor IDs.
        
        Returns
        -------
        list[tuple[int, MotorState]] or None
            List of (id, motor_state) tuples if successful, None otherwise.
        """
    def get_position_d_gain(self, id: int) -> int | None:
        """
        get_position_d_gain(id)
        
        Get position D gain for a motor.
        
        Parameters
        ----------
        id : int
            Motor ID.
        
        Returns
        -------
        int or None
            D gain value if successful, None otherwise.
        """
    def get_position_i_gain(self, id: int) -> int | None:
        """
        get_position_i_gain(id)
        
        Get position I gain for a motor.
        
        Parameters
        ----------
        id : int
            Motor ID.
        
        Returns
        -------
        int or None
            I gain value if successful, None otherwise.
        """
    def get_position_p_gain(self, id: int) -> int | None:
        """
        get_position_p_gain(id)
        
        Get position P gain for a motor.
        
        Parameters
        ----------
        id : int
            Motor ID.
        
        Returns
        -------
        int or None
            P gain value if successful, None otherwise.
        """
    def get_position_pid_gain(self, id: int) -> DynamixelBus.PIDGain | None:
        """
        get_position_pid_gain(id)
        
        Get position PID gains for a motor.
        
        Parameters
        ----------
        id : int
            Motor ID.
        
        Returns
        -------
        PIDGain or None
            PIDGain struct if successful, None otherwise.
        """
    def group_fast_sync_read(self, ids: list[int], addr: int, len: int) -> list[tuple[int, int]] | None:
        """
        group_fast_sync_read(ids, addr, len)
        
        Perform fast synchronous read for multiple motors.
        
        Parameters
        ----------
        ids : list[int]
            List of motor IDs.
        addr : int
            Memory address to read from.
        len : int
            Number of bytes to read.
        
        Returns
        -------
        list[tuple[int, int]] or None
            List of (id, value) tuples if successful, None otherwise.
        """
    def group_fast_sync_read_encoder(self, ids: list[int]) -> list[tuple[int, float]] | None:
        """
        group_fast_sync_read_encoder(ids)
        
        Perform fast synchronous read of encoder values.
        
        Parameters
        ----------
        ids : list[int]
            List of motor IDs.
        
        Returns
        -------
        list[tuple[int, float]] or None
            List of (id, encoder_value) tuples if successful, None otherwise.
        """
    def group_fast_sync_read_operating_mode(self, ids: list[int], use_cache: bool) -> list[tuple[int, int]] | None:
        """
        group_fast_sync_read_operating_mode(ids, use_cache)
        
        Perform fast synchronous read of operating modes.
        
        Parameters
        ----------
        ids : list[int]
            List of motor IDs.
        use_cache : bool, optional
            Whether to use cached values. Default is False.
        
        Returns
        -------
        list[tuple[int, int]] or None
            List of (id, operating_mode) tuples if successful, None otherwise.
        """
    def group_fast_sync_read_torque_enable(self, ids: list[int]) -> list[tuple[int, int]] | None:
        """
        group_fast_sync_read_torque_enable(ids)
        
        Perform fast synchronous read of torque enable states.
        
        Parameters
        ----------
        ids : list[int]
            List of motor IDs.
        
        Returns
        -------
        list[tuple[int, int]] or None
            List of (id, torque_enable) tuples if successful, None otherwise.
        """
    def group_sync_write_operating_mode(self, id_and_mode_vector: list[tuple[int, int]]) -> None:
        """
        group_sync_write_operating_mode(id_and_mode_vector)
        
        Perform synchronous write of operating modes.
        
        Parameters
        ----------
        id_and_mode_vector : list[tuple[int, int]]
            List of (id, mode) tuples.
        """
    def group_sync_write_send_position(self, id_and_position_vector: list[tuple[int, float]]) -> None:
        """
        group_sync_write_send_position(id_and_position_vector)
        
        Perform synchronous write of goal positions.
        
        Parameters
        ----------
        id_and_position_vector : list[tuple[int, int]]
            List of (id, position) tuples.
        """
    def group_sync_write_send_torque(self, id_and_torque_vector: list[tuple[int, float]]) -> None:
        """
        group_sync_write_send_torque(id_and_torque_vector)
        
        Perform synchronous write of torque commands.
        
        Parameters
        ----------
        id_and_torque_vector : list[tuple[int, float]]
            List of (id, torque) tuples.
        """
    @typing.overload
    def group_sync_write_torque_enable(self, id_and_enable_vector: list[tuple[int, int]]) -> None:
        """
        group_sync_write_torque_enable(id_and_enable_vector)
        
        Perform synchronous write of torque enable states.
        
        Parameters
        ----------
        id_and_enable_vector : list[tuple[int, int]]
            List of (id, enable) tuples.
        """
    @typing.overload
    def group_sync_write_torque_enable(self, ids: list[int], enable: int) -> None:
        """
        group_sync_write_torque_enable(ids, enable)
        
        Perform synchronous write of torque enable states.
        
        Parameters
        ----------
        ids : list[int]
            List of motor IDs.
        enable : int
            Enable value (1=enabled, 0=disabled).
        """
    def open_port(self) -> bool:
        """
        open_port()
        
        Open the communication port.
        
        Returns
        -------
        bool
            True if port opened successfully, False otherwise.
        """
    def ping(self, id: int) -> bool:
        """
        ping()
        
        Ping a motor to check if it's responding.
        
        Parameters
        ----------
        id : int
            Motor ID to ping.
        
        Returns
        -------
        bool
            True if motor responds, False otherwise.
        """
    def read_button_status(self, arg0: int) -> tuple[int, DynamixelBus.ButtonState] | None:
        """
        Read button status from a device.
        
        Parameters
        ----------
        id : int
            Device ID to read from.
        
        Returns
        -------
        tuple[int, ButtonState] or None
            Tuple of (id, button_state) if successful, None otherwise.
        """
    def read_encoder(self, id: int) -> float | None:
        """
        read_encoder(id)
        
        Read encoder position for a motor.
        
        Parameters
        ----------
        id : int
            Motor ID.
        
        Returns
        -------
        float or None
            Encoder position in radians if successful, None otherwise.
        """
    def read_operating_mode(self, id: int, use_cache: bool) -> int | None:
        """
        read_operating_mode(id, use_cache)
        
        Read operating mode for a motor.
        
        Parameters
        ----------
        id : int
            Motor ID.
        use_cache : bool, optional
            Whether to use cached value. Default is False.
        
        Returns
        -------
        int or None
            Operating mode value if successful, None otherwise.
        """
    def read_temperature(self, id: int) -> int | None:
        """
        read_temperature(id)
        
        Read temperature for a motor.
        
        Parameters
        ----------
        id : int
            Motor ID.
        
        Returns
        -------
        int or None
            Temperature in degrees Celsius if successful, None otherwise.
        """
    def read_torque_enable(self, id: int) -> int | None:
        """
        read_torque_enable(id)
        
        Read torque enable state for a motor.
        
        Parameters
        ----------
        id : int
            Motor ID.
        
        Returns
        -------
        int or None
            Torque state (1=enabled, 0=disabled) if successful, None otherwise.
        """
    def send_current(self, id: int, current: float) -> None:
        """
        send_current(id, current)
        
        Send current command to a motor.
        
        Parameters
        ----------
        id : int
            Motor ID.
        current : float
            Current value in amperes.
        """
    def send_goal_position(self, id: int, goal_position: int) -> None:
        """
        send_goal_position(id, goal_position)
        
        Send goal position to a motor.
        
        Parameters
        ----------
        id : int
            Motor ID.
        goal_position : int
            Goal position in encoder units.
        """
    def send_operating_mode(self, id: int, operating_mode: int) -> bool:
        """
        send_operating_mode(id, mode)
        
        Send operating mode to a motor.
        
        Parameters
        ----------
        id : int
            Motor ID.
        mode : int
            Operating mode value.
        
        Returns
        -------
        bool
            True if successful, False otherwise.
        """
    def send_torque(self, id: int, torque: float) -> None:
        """
        send_torque(id, torque)
        
        Send torque command to a motor.
        
        Parameters
        ----------
        id : int
            Motor ID.
        joint_torque : float
            Torque value in Nm.
        """
    def send_torque_enable(self, id: int, onoff: int) -> None:
        """
        send_torque_enable(id, onoff)
        
        Enable or disable torque for a motor.
        
        Parameters
        ----------
        id : int
            Motor ID.
        onoff : int
            Torque state: 1 (enable) or 0 (disable).
        """
    def send_vibration(self, id: int, vibration: int) -> None:
        """
        send_vibration(id, vibration)
        
        Send vibration command to a device.
        
        Parameters
        ----------
        id : int
            Device ID.
        level : int
            Vibration level (0-255).
        """
    def set_baud_rate(self, baudrate: int) -> bool:
        """
        set_baud_rate(baudrate)
        
        Set the communication baudrate.
        
        Parameters
        ----------
        baudrate : int
            Baudrate value (e.g., 2000000).
        
        Returns
        -------
        bool
            True if baudrate set successfully, False otherwise.
        """
    def set_position_d_gain(self, id: int, d_gain: int) -> None:
        """
        set_position_d_gain(id, d_gain)
        
        Set position D gain for a motor.
        
        Parameters
        ----------
        id : int
            Motor ID.
        d_gain : int
            D gain value (0-65535).
        """
    def set_position_i_gain(self, id: int, i_gain: int) -> None:
        """
        set_position_i_gain(id, i_gain)
        
        Set position I gain for a motor.
        
        Parameters
        ----------
        id : int
            Motor ID.
        i_gain : int
            I gain value (0-65535).
        """
    def set_position_p_gain(self, id: int, p_gain: int) -> None:
        """
        set_position_p_gain(id, p_gain)
        
        Set position P gain for a motor.
        
        Parameters
        ----------
        id : int
            Motor ID.
        p_gain : int
            P gain value (0-65535).
        """
    @typing.overload
    def set_position_pid_gain(self, id: int, p_gain: int | None, i_gain: int | None, d_gain: int | None) -> None:
        """
        set_position_pid_gain(id, p_gain, i_gain, d_gain)
        
        Set position PID gains for a motor.
        
        Parameters
        ----------
        id : int
            Motor ID.
        p_gain : int or None, optional
            P gain value (0-65535). If None, current value is preserved.
        i_gain : int or None, optional
            I gain value (0-65535). If None, current value is preserved.
        d_gain : int or None, optional
            D gain value (0-65535). If None, current value is preserved.
        """
    @typing.overload
    def set_position_pid_gain(self, id: int, pid_gain: DynamixelBus.PIDGain) -> None:
        """
        set_position_pid_gain(id, pid_gain)
        
        Set position PID gains for a motor using PIDGain struct.
        
        Parameters
        ----------
        id : int
            Motor ID.
        pid_gain : PIDGain
            PIDGain struct containing P, I, and D values.
        """
    def set_torque_constant(self, torque_constant: list[float]) -> None:
        """
        set_torque_constant(torque_constant)
        
        Set torque constants for motors.
        
        Parameters
        ----------
        torque_constant : list[float]
            List of torque constants for each motor.
        """
class EMOInfo:
    """
    
    Emergency stop button information.
    
    This class represents information about an emergency stop
    button connected to the robot.
    
    Attributes
    ----------
    name : str
        Name identifier for the emergency stop button.
    """
    def __init__(self) -> None:
        """
        Construct an EMOInfo instance with default values.
        """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        """
        Name identifier for the emergency stop button.
        
        Type
        ----
        str
            Name of the emergency stop button.
        """
class EMOState:
    """
    
    Emergency stop button state.
    
    Provides information about emergency stop button status.
    
    Attributes
    ----------
    state : State
        Current emergency stop button state.
    """
    class State:
        """
        
        Emergency stop button state enumeration.
        
        Defines the possible emergency stop button states.
        
        Members
        -------
        Released : int
            Emergency stop button is released.
        Pressed : int
            Emergency stop button is pressed.
        
        
        Members:
        
          Released : 
        Emergency stop button is released.
        
        
          Pressed : 
        Emergency stop button is pressed.
        """
        Pressed: typing.ClassVar[EMOState.State]  # value = <State.Pressed: 1>
        Released: typing.ClassVar[EMOState.State]  # value = <State.Released: 0>
        __members__: typing.ClassVar[dict[str, EMOState.State]]  # value = {'Released': <State.Released: 0>, 'Pressed': <State.Pressed: 1>}
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: int) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: int) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    def __init__(self) -> None:
        ...
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    @property
    def state(self) -> EMOState.State:
        ...
class FTSensorData:
    """
    
    Force/Torque sensor data.
    
    Provides information about force and torque measurements from a sensor.
    
    Attributes
    ----------
    time_since_last_update : datetime.timedelta
        Time since last update as a Python timedelta.
    force : numpy.ndarray
        Force readings in N.
    torque : numpy.ndarray
        Torque readings in Nm.
    """
    def __init__(self) -> None:
        """
        Construct a FTSensorData instance.
        """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    @property
    def force(self) -> numpy.ndarray[tuple[typing.Literal[3], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        """
        Force readings.
        
        Type
        ----
        numpy.ndarray
            Force readings in N.
        """
    @property
    def time_since_last_update(self) -> datetime.timedelta:
        """
        Time since last update.
        
        Type
        ----
        datetime.timedelta
            Time since last update as a Python timedelta.
        """
    @property
    def torque(self) -> numpy.ndarray[tuple[typing.Literal[3], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        """
        Torque readings.
        
        Type
        ----
        numpy.ndarray
            Torque readings in Nm.
        """
class Feedback:
    def __init__(self) -> None:
        ...
    @property
    def valid(self) -> bool:
        ...
class GravityCompensationCommandBuilder:
    def __init__(self) -> None:
        ...
    def set_command_header(self, gravity_compensation_command_builder: CommandHeaderBuilder) -> GravityCompensationCommandBuilder:
        ...
    def set_on(self, on: bool) -> GravityCompensationCommandBuilder:
        ...
class GravityCompensationCommandFeedback(CommandFeedback):
    def __init__(self) -> None:
        ...
class HeadCommandBuilder:
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, arg0: JointPositionCommandBuilder) -> None:
        ...
    def set_command(self, joint_position_command_builder: JointPositionCommandBuilder) -> HeadCommandBuilder:
        ...
class HeadCommandFeedback(CommandFeedback):
    def __init__(self) -> None:
        ...
    @property
    def joint_position_command(self) -> JointPositionCommandFeedback:
        ...
class ImpedanceControlCommandBuilder:
    def __init__(self) -> None:
        ...
    def set_command_header(self, command_header_builder: CommandHeaderBuilder) -> ImpedanceControlCommandBuilder:
        ...
    def set_damping_ratio(self, damping_ratio: float) -> ImpedanceControlCommandBuilder:
        ...
    def set_link_name(self, link_name: str) -> ImpedanceControlCommandBuilder:
        ...
    def set_reference_link_name(self, reference_link_name: str) -> ImpedanceControlCommandBuilder:
        ...
    def set_rotation_weight(self, weight: numpy.ndarray[tuple[typing.Literal[3], typing.Literal[1]], numpy.dtype[numpy.float64]]) -> ImpedanceControlCommandBuilder:
        ...
    def set_transformation(self, T: numpy.ndarray[tuple[typing.Literal[4], typing.Literal[4]], numpy.dtype[numpy.float64]]) -> ImpedanceControlCommandBuilder:
        ...
    def set_translation_weight(self, weight: numpy.ndarray[tuple[typing.Literal[3], typing.Literal[1]], numpy.dtype[numpy.float64]]) -> ImpedanceControlCommandBuilder:
        ...
class ImpedanceControlCommandFeedback(CommandFeedback):
    class TrackingError:
        def __init__(self) -> None:
            ...
        @property
        def position_error(self) -> float:
            ...
        @property
        def rotation_error(self) -> float:
            ...
    def __init__(self) -> None:
        ...
    @property
    def tracking_error(self) -> ImpedanceControlCommandFeedback.TrackingError:
        ...
class JogCommandBuilder:
    class AbsolutePosition:
        def __init__(self, arg0: float) -> None:
            ...
        def value(self) -> float:
            ...
    class OneStep:
        def __init__(self, arg0: float) -> None:
            ...
        def value(self) -> bool:
            ...
    class RelativePosition:
        def __init__(self, arg0: float) -> None:
            ...
        def value(self) -> float:
            ...
    def __init__(self) -> None:
        ...
    def set_acceleration_limit(self, acceleration_limit: float) -> JogCommandBuilder:
        ...
    @typing.overload
    def set_command(self, absolute_position: JogCommandBuilder.AbsolutePosition) -> JogCommandBuilder:
        ...
    @typing.overload
    def set_command(self, relative_position: JogCommandBuilder.RelativePosition) -> JogCommandBuilder:
        ...
    @typing.overload
    def set_command(self, one_step: JogCommandBuilder.OneStep) -> JogCommandBuilder:
        ...
    def set_command_header(self, command_header_builder: CommandHeaderBuilder) -> JogCommandBuilder:
        ...
    def set_joint_name(self, joint_name: str) -> JogCommandBuilder:
        ...
    def set_velocity_limit(self, velocity_limit: float) -> JogCommandBuilder:
        ...
class JogCommandFeedback(CommandFeedback):
    def __init__(self) -> None:
        ...
    @property
    def target_joint_name(self) -> str:
        ...
class JointGroupPositionCommandBuilder:
    def __init__(self) -> None:
        ...
    def set_acceleration_limit(self, acceleration_limit: numpy.ndarray[tuple[M, typing.Literal[1]], numpy.dtype[numpy.float64]]) -> JointGroupPositionCommandBuilder:
        ...
    def set_command_header(self, command_header_builder: CommandHeaderBuilder) -> JointGroupPositionCommandBuilder:
        ...
    def set_joint_names(self, joint_names: list[str]) -> JointGroupPositionCommandBuilder:
        ...
    def set_minimum_time(self, minimum_time: float) -> JointGroupPositionCommandBuilder:
        ...
    def set_position(self, position: numpy.ndarray[tuple[M, typing.Literal[1]], numpy.dtype[numpy.float64]]) -> JointGroupPositionCommandBuilder:
        ...
    def set_velocity_limit(self, velocity_limit: numpy.ndarray[tuple[M, typing.Literal[1]], numpy.dtype[numpy.float64]]) -> JointGroupPositionCommandBuilder:
        ...
class JointGroupPositionCommandFeedback(CommandFeedback):
    def __init__(self) -> None:
        ...
    @property
    def joint_indices(self) -> list[int]:
        ...
    @property
    def position_based_progress(self) -> float:
        ...
    @property
    def time_based_progress(self) -> float:
        ...
class JointImpedanceControlCommandBuilder:
    def __init__(self) -> None:
        ...
    def set_acceleration_limit(self, acceleration_limit: numpy.ndarray[tuple[M, typing.Literal[1]], numpy.dtype[numpy.float64]]) -> JointImpedanceControlCommandBuilder:
        ...
    def set_command_header(self, command_header_builder: CommandHeaderBuilder) -> JointImpedanceControlCommandBuilder:
        ...
    def set_damping_ratio(self, damping_ratio: float) -> JointImpedanceControlCommandBuilder:
        ...
    def set_minimum_time(self, minimum_time: float) -> JointImpedanceControlCommandBuilder:
        ...
    def set_position(self, position: numpy.ndarray[tuple[M, typing.Literal[1]], numpy.dtype[numpy.float64]]) -> JointImpedanceControlCommandBuilder:
        ...
    def set_stiffness(self, stiffness: numpy.ndarray[tuple[M, typing.Literal[1]], numpy.dtype[numpy.float64]]) -> JointImpedanceControlCommandBuilder:
        ...
    def set_torque_limit(self, torque_limit: numpy.ndarray[tuple[M, typing.Literal[1]], numpy.dtype[numpy.float64]]) -> JointImpedanceControlCommandBuilder:
        ...
    def set_velocity_limit(self, velocity_limit: numpy.ndarray[tuple[M, typing.Literal[1]], numpy.dtype[numpy.float64]]) -> JointImpedanceControlCommandBuilder:
        ...
class JointImpedanceControlCommandFeedback(CommandFeedback):
    def __init__(self) -> None:
        ...
    @property
    def error(self) -> list[float]:
        ...
    @property
    def set_position(self) -> list[float]:
        ...
class JointInfo:
    """
    
    Joint information.
    
    Stores hardware/firmware metadata for a single joint.
    
    Attributes
    ----------
    name : str
        Joint name (e.g., "right_arm_2").
    has_brake : bool
        Whether the joint includes a brake.
    product_name : str
        Actuator/driver product name.
    firmware_version : str
        Firmware revision running on the motor driver / servo drive.
    """
    def __init__(self) -> None:
        """
        Construct a JointInfo with default-initialized fields.
        """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    @property
    def firmware_version(self) -> str:
        """
        Firmware revision running on the motor driver / servo drive.
        
        Type
        ----
        str
            Firmware version string.
        """
    @property
    def has_brake(self) -> bool:
        """
        Whether the joint includes a brake.
        
        Type
        ----
        bool
            True if the joint has a brake; False otherwise.
        """
    @property
    def name(self) -> str:
        """
        Joint name.
        
        Type
        ----
        str
            Human-readable joint name.
        """
    @property
    def product_name(self) -> str:
        """
        Actuator/driver product name.
        
        Type
        ----
        str
            Hardware model identifier.
        """
class JointPositionCommandBuilder:
    """
    
    Joint position command builder.
    
    Builds joint position commands with position, velocity, and acceleration limits.
    
    Attributes
    ----------
    command_header : CommandHeaderBuilder
        Command header configuration.
    minimum_time : float
        Minimum execution time in seconds.
    position : numpy.ndarray
        Target joint positions in radians.
    velocity_limit : numpy.ndarray
        Joint velocity limits in rad/s.
    acceleration_limit : numpy.ndarray
        Joint acceleration limits in rad/s².
    
    Examples
    --------
    >>> def movej(robot, torso=None, right_arm=None, left_arm=None, minimum_time=0):
    ...     rc = rby.BodyComponentBasedCommandBuilder()
    ...     if torso is not None:
    ...         rc.set_torso_command(
    ...             rby.JointPositionCommandBuilder()
    ...             .set_minimum_time(minimum_time)
    ...             .set_position(torso)
    ...         )
    ...     if right_arm is not None:
    ...         rc.set_right_arm_command(
    ...             rby.JointPositionCommandBuilder()
    ...             .set_minimum_time(minimum_time)
    ...             .set_position(right_arm)
    ...         )
    ...     if left_arm is not None:
    ...         rc.set_left_arm_command(
    ...             rby.JointPositionCommandBuilder()
    ...             .set_minimum_time(minimum_time)
    ...             .set_position(left_arm)
    ...         )
    ...     handler = robot.send_command(
    ...         rby.RobotCommandBuilder().set_command(
    ...             rby.ComponentBasedCommandBuilder().set_body_command(rc)
    ...         ),
    ...         1,
    ...     )
    ...     rv = handler.get()
    ...     if rv.finish_code != rby.RobotCommandFeedback.FinishCode.Ok:
    ...         logging.error("Failed to conduct movej.")
    ...         return False
    ...     return True
    >>> movej(
    ...     robot,
    ...     torso=np.array([0.0, 0.0, 0.0, 0.0, 0.0, 0.0]),
    ...     right_arm=np.array([0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]),
    ...     left_arm=np.array([0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]),
    ...     minimum_time=5.0
    ... )
    """
    def __init__(self) -> None:
        """
              Construct a JointPositionCommandBuilder instance.
        """
    def set_acceleration_limit(self, acceleration_limit: numpy.ndarray[tuple[M, typing.Literal[1]], numpy.dtype[numpy.float64]]) -> JointPositionCommandBuilder:
        """
        set_acceleration_limit(acceleration_limit)
        
        Set the joint acceleration limits.
        
        Parameters
        ----------
        acceleration_limit : numpy.ndarray
            Acceleration limits in rad/s².
        
        Returns
        -------
        JointPositionCommandBuilder
            Self reference for method chaining.
        """
    def set_command_header(self, command_header_builder: CommandHeaderBuilder) -> JointPositionCommandBuilder:
        """
        set_command_header(command_header_builder)
        
        Set the command header.
        
        Parameters
        ----------
        command_header_builder : CommandHeaderBuilder
            Command header configuration.
        
        Returns
        -------
        JointPositionCommandBuilder
            Self reference for method chaining.
        """
    def set_minimum_time(self, minimum_time: float) -> JointPositionCommandBuilder:
        """
        set_minimum_time(minimum_time)
        
        Set the minimum execution time.
        
        Parameters
        ----------
        minimum_time : float
            Minimum time in seconds. This parameter provides an additional degree
            of freedom to control the arrival time to a target. Instead of relying
            solely on velocity/acceleration limits, you can set high limits and
            control the arrival time using minimum_time. For streaming commands,
            this helps ensure continuous motion by preventing the robot from
            stopping if it arrives too early before the next command.
        
        Returns
        -------
        JointPositionCommandBuilder
            Self reference for method chaining.
        """
    def set_position(self, position: numpy.ndarray[tuple[M, typing.Literal[1]], numpy.dtype[numpy.float64]]) -> JointPositionCommandBuilder:
        """
        set_position(position)
        
        Set the target joint positions.
        The size of the array must match the number of joints in the corresponding component.
        
        Parameters
        ----------
        position : numpy.ndarray
            Target positions in radians.
        
        Returns
        -------
        JointPositionCommandBuilder
            Self reference for method chaining.
        
        Examples
        --------
        >>> right_arm_command = (
        ...     JointPositionCommandBuilder()
        ...     .set_position(np.array([0, 0, 0, 0, 0, 0, 0]))
        ...     .set_velocity_limit(np.array([np.pi] * 7))
        ...     .set_acceleration_limit(np.array([1.0] * 7))
        ...     .set_minimum_time(3.0)
        ... )
        >>> robot.send_command(
        ...      RobotCommandBuilder().set_command(
        ...           ComponentBasedCommandBuilder().set_body_command(
        ...                BodyComponentBasedCommandBuilder()
        ...                .set_right_arm_command(right_arm_command)
        ...           )
        ...      ),
        ...      10,
        ... )
        """
    def set_velocity_limit(self, velocity_limit: numpy.ndarray[tuple[M, typing.Literal[1]], numpy.dtype[numpy.float64]]) -> JointPositionCommandBuilder:
        """
        set_velocity_limit(velocity_limit)
        
        Set the joint velocity limits.
        
        Parameters
        ----------
        velocity_limit : numpy.ndarray
            Velocity limits in rad/s.
        
        Returns
        -------
        JointPositionCommandBuilder
            Self reference for method chaining.
        """
class JointPositionCommandFeedback(CommandFeedback):
    def __init__(self) -> None:
        ...
    @property
    def position_based_progress(self) -> float:
        ...
    @property
    def time_based_progress(self) -> float:
        ...
class JointState:
    """
    
    Joint state information.
    
    Provides information about the state of a single joint, including its readiness,
    FET state, run state, initialization state, motor type, motor state, power,
    position, velocity, current, torque, and target values.
    
    Attributes
    ----------
    time_since_last_update : datetime.timedelta
        Time since last update as a Python timedelta.
    is_ready : bool
        Indicates if the joint is ready to operate.
    fet_state : FETState
        Current FET state of the joint.
    run_state : RunState
        Current run state of the joint.
    init_state : InitializationState
        Current initialization state of the joint.
    motor_type : str
        Type of the joint's motor.
    motor_state : str
        Current state of the joint's motor.
    power_on : bool
        Indicates if the joint's power is on.
    position : float
        Current position of the joint in rad.
    velocity : float
        Current velocity of the joint in rad/s.
    current : float
        Current current of the joint in A.
    torque : float
        Current torque of the joint in Nm.
    target_position : float
        Target position of the joint in rad.
    target_velocity : float
        Target velocity of the joint in rad/s.
    target_feedback_gain : float
        Target feedback gain of the joint.
    target_feedforward_torque : float
        Target feedforward torque of the joint.
    temperature : float
        Current temperature of the joint in °C.
    """
    class FETState:
        """
        
        FET (power stage) state.
        
        
        Members:
        
          Unknown : 
        State is unknown or not reported.
        
        
          On : 
        Power stage is enabled.
        
        
          Off : 
        Power stage is disabled.
        """
        Off: typing.ClassVar[JointState.FETState]  # value = <FETState.Off: 2>
        On: typing.ClassVar[JointState.FETState]  # value = <FETState.On: 1>
        Unknown: typing.ClassVar[JointState.FETState]  # value = <FETState.Unknown: 0>
        __members__: typing.ClassVar[dict[str, JointState.FETState]]  # value = {'Unknown': <FETState.Unknown: 0>, 'On': <FETState.On: 1>, 'Off': <FETState.Off: 2>}
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: int) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: int) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    class InitializationState:
        """
        
        Initialization state of the joint.
        
        
        Members:
        
          Unknown : 
        Initialization state is unknown.
        
        
          Initialized : 
        Joint has been initialized/homed.
        
        
          Uninitialized : 
        Joint has not been initialized/homed yet.
        """
        Initialized: typing.ClassVar[JointState.InitializationState]  # value = <InitializationState.Initialized: 1>
        Uninitialized: typing.ClassVar[JointState.InitializationState]  # value = <InitializationState.Uninitialized: 2>
        Unknown: typing.ClassVar[JointState.InitializationState]  # value = <InitializationState.Unknown: 0>
        __members__: typing.ClassVar[dict[str, JointState.InitializationState]]  # value = {'Unknown': <InitializationState.Unknown: 0>, 'Initialized': <InitializationState.Initialized: 1>, 'Uninitialized': <InitializationState.Uninitialized: 2>}
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: int) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: int) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    class RunState:
        """
        
        Current run state of the joint.
        
        
        Members:
        
          Unknown : 
        State is unknown or not reported.
        
        
          ControlOn : 
        Closed-loop control is enabled (actively controlling).
        
        
          ControlOff : 
        Closed-loop control is disabled.
        """
        ControlOff: typing.ClassVar[JointState.RunState]  # value = <RunState.ControlOff: 2>
        ControlOn: typing.ClassVar[JointState.RunState]  # value = <RunState.ControlOn: 1>
        Unknown: typing.ClassVar[JointState.RunState]  # value = <RunState.Unknown: 0>
        __members__: typing.ClassVar[dict[str, JointState.RunState]]  # value = {'Unknown': <RunState.Unknown: 0>, 'ControlOn': <RunState.ControlOn: 1>, 'ControlOff': <RunState.ControlOff: 2>}
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: int) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: int) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    def __init__(self) -> None:
        ...
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    @property
    def current(self) -> float:
        """
        Current current.
        
        Type
        ----
        float
            Current current of the joint in amperes.
        """
    @property
    def fet_state(self) -> JointState.FETState:
        """
        FET state.
        
        Type
        ----
        FETState
            Current FET state enumeration value.
        """
    @property
    def init_state(self) -> JointState.InitializationState:
        """
        Initialization state.
        
        Type
        ----
        InitializationState
            Current initialization state enumeration value.
        """
    @property
    def is_ready(self) -> bool:
        """
        Joint readiness.
        
        Type
        ----
        bool
            Indicates if the joint is ready to operate.
        """
    @property
    def motor_state(self) -> int:
        """
        Motor state.
        
        Type
        ----
        str
            Current state of the joint's motor.
        """
    @property
    def motor_type(self) -> int:
        """
        Motor type.
        
        Type
        ----
        str
            Type of the joint's motor.
        """
    @property
    def position(self) -> float:
        """
        Current position.
        
        Type
        ----
        float
            Current position of the joint in rad.
        """
    @property
    def power_on(self) -> bool:
        """
        Power on status.
        
        Type
        ----
        bool
            Indicates if the joint's power is on.
        """
    @property
    def run_state(self) -> JointState.RunState:
        """
        Run state.
        
        Type
        ----
        RunState
            Current run state enumeration value.
        """
    @property
    def target_feedback_gain(self) -> int:
        """
        Target feedback gain.
        
        Type
        ----
        float
            Target feedback gain of the joint. Range is [0, 10].
        """
    @property
    def target_feedforward_torque(self) -> float:
        """
        Target feedforward torque.
        
        Type
        ----
        float
            Target feedforward torque of the joint in Nm.
        """
    @property
    def target_position(self) -> float:
        """
        Target position.
        
        Type
        ----
        float
            Target position of the joint in rad.
        """
    @property
    def target_velocity(self) -> float:
        """
        Target velocity.
        
        Type
        ----
        float
            Target velocity of the joint in rad/s.
        """
    @property
    def temperature(self) -> int:
        """
        Current temperature.
        
        Type
        ----
        float
            Current temperature of the joint in °C.
        """
    @property
    def time_since_last_update(self) -> datetime.timedelta:
        """
        Time since last update.
        
        Type
        ----
        datetime.timedelta
            Time since last update as a Python timedelta.
        """
    @property
    def torque(self) -> float:
        """
        Current torque.
        
        Type
        ----
        float
            Current torque of the joint in Nm.
        """
    @property
    def velocity(self) -> float:
        """
        Current velocity.
        
        Type
        ----
        float
            Current velocity of the joint in rad/s.
        """
class JointVelocityCommandBuilder:
    def __init__(self) -> None:
        ...
    def set_acceleration_limit(self, acceleration_limit: numpy.ndarray[tuple[M, typing.Literal[1]], numpy.dtype[numpy.float64]]) -> JointVelocityCommandBuilder:
        ...
    def set_command_header(self, command_header_builder: CommandHeaderBuilder) -> JointVelocityCommandBuilder:
        ...
    def set_minimum_time(self, minimum_time: float) -> JointVelocityCommandBuilder:
        ...
    def set_velocity(self, velocity: numpy.ndarray[tuple[M, typing.Literal[1]], numpy.dtype[numpy.float64]]) -> JointVelocityCommandBuilder:
        ...
class JointVelocityCommandFeedback(CommandFeedback):
    def __init__(self) -> None:
        ...
class Log:
    """
    
    Robot log entry with timestamp and message.
    
    This class represents a single log entry from the robot system,
    including timestamps, log level, and message content.
    
    Attributes
    ----------
    timestamp : datetime.datetime
        Timestamp when the log was created (client system time).
    robot_system_timestamp : datetime.datetime
        Timestamp when the log was created (robot system time).
    level : Level
        Log level indicating the severity of the message.
    message : str
        The log message content.
    """
    class Level:
        """
        
        Log level enumeration.
        
        Defines the severity levels for log messages, from least to most severe.
        
        Members
        -------
        Trace : int
            Trace level for detailed debugging information.
        Debug : int
            Debug level for debugging information.
        Info : int
            Info level for general information messages.
        Warn : int
            Warning level for warning messages.
        Error : int
            Error level for error messages.
        Critical : int
            Critical level for critical error messages.
        
        
        Members:
        
          Trace : 
        Trace level for detailed debugging information.
        
        
          Debug : 
        Debug level for debugging information.
        
        
          Info : 
        Info level for general information messages.
        
        
          Warn : 
        Warning level for warning messages.
        
        
          Error : 
        Error level for error messages.
        
        
          Critical : 
        Critical level for critical error messages.
        """
        Critical: typing.ClassVar[Log.Level]  # value = <Level.Critical: 5>
        Debug: typing.ClassVar[Log.Level]  # value = <Level.Debug: 1>
        Error: typing.ClassVar[Log.Level]  # value = <Level.Error: 4>
        Info: typing.ClassVar[Log.Level]  # value = <Level.Info: 2>
        Trace: typing.ClassVar[Log.Level]  # value = <Level.Trace: 0>
        Warn: typing.ClassVar[Log.Level]  # value = <Level.Warn: 3>
        __members__: typing.ClassVar[dict[str, Log.Level]]  # value = {'Trace': <Level.Trace: 0>, 'Debug': <Level.Debug: 1>, 'Info': <Level.Info: 2>, 'Warn': <Level.Warn: 3>, 'Error': <Level.Error: 4>, 'Critical': <Level.Critical: 5>}
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: int) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: int) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    def __init__(self) -> None:
        """
        Construct a Log instance with default values.
        """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    @property
    def level(self) -> Log.Level:
        """
        Log level indicating the severity of the message.
        
        Type
        ----
        Level
            Enumeration value indicating the log severity level.
        """
    @property
    def message(self) -> str:
        """
        The log message content.
        
        Type
        ----
        str
            Human-readable log message describing the event or condition.
        """
    @property
    def robot_system_timestamp(self) -> datetime.datetime:
        """
        Timestamp when the log was created (robot system time).
        
        Type
        ----
        datetime.datetime
            Robot system timestamp when the log entry was created.
        """
    @property
    def timestamp(self) -> datetime.datetime:
        """
        Timestamp when the log was created (client system time).
        
        Type
        ----
        datetime.datetime
            Client system timestamp when the log entry was created.
        """
class MobilityCommandBuilder:
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, arg0: JointVelocityCommandBuilder) -> None:
        ...
    @typing.overload
    def __init__(self, arg0: SE2VelocityCommandBuilder) -> None:
        ...
    @typing.overload
    def set_command(self, joint_velocity_command_builder: JointVelocityCommandBuilder) -> MobilityCommandBuilder:
        ...
    @typing.overload
    def set_command(self, se2_velocity_command_builder: SE2VelocityCommandBuilder) -> MobilityCommandBuilder:
        ...
class MobilityCommandFeedback(CommandFeedback):
    def __init__(self) -> None:
        ...
    @property
    def joint_velocity_command(self) -> JointVelocityCommandFeedback:
        ...
    @property
    def se2_velocity_command(self) -> SE2VelocityCommandFeedback:
        ...
class Model_A:
    """
    
    Robot model configuration class.
    
    This class provides access to robot model specifications including
    joint configurations, degrees of freedom, and component indices.
    
    Attributes
    ----------
    model_name : str
        Name identifier for the robot model.
    robot_dof : int
        Total degrees of freedom for the robot.
    robot_joint_names : list[str]
        Names of all robot joints in order of their indices.
    mobility_idx : list[int]
        Indices of mobility components (e.g., wheels).
    body_idx : list[int]
        Indices of main body components (excluding mobility and head).
    head_idx : list[int]
        Indices of head components.
    right_arm_idx : list[int]
        Indices of right arm components.
    left_arm_idx : list[int]
        Indices of left arm components.
    torso_idx : list[int]
        Indices of torso components.
    velocity_estimation_required_idx : list[int]
        Indices of joints requiring velocity estimation.
    control_period : float
        Control update period in seconds.
    """
    def __init__(self) -> None:
        """
        Construct a model instance.
        """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    @property
    def body_idx(self) -> typing.Annotated[list[int], pybind11_stubgen.typing_ext.FixedSize(20)]:
        """
        Get indices of body components.
        
        Returns
        -------
        list[int]
            Indices of main body joints (excluding mobility and head).
        """
    @property
    def control_period(self) -> float:
        """
        Get the control update period.
        
        Returns
        -------
        float
            Control period in seconds (typically 0.002).
        """
    @property
    def head_idx(self) -> typing.Annotated[list[int], pybind11_stubgen.typing_ext.FixedSize(2)]:
        """
        Get indices of head components.
        
        Returns
        -------
        list[int]
            Indices of head joints.
        """
    @property
    def left_arm_idx(self) -> typing.Annotated[list[int], pybind11_stubgen.typing_ext.FixedSize(7)]:
        """
        Get indices of left arm components.
        
        Returns
        -------
        list[int]
            Indices of left arm joints.
        """
    @property
    def mobility_idx(self) -> typing.Annotated[list[int], pybind11_stubgen.typing_ext.FixedSize(2)]:
        """
        Get indices of mobility components.
        
        Returns
        -------
        list[int]
            Indices of wheels or other mobility joints.
        """
    @property
    def model_name(self) -> str:
        """
        Get the model name identifier.
        
        Returns
        -------
        str
            Model name (e.g., "A", "T5", "M", "UB").
        """
    @property
    def right_arm_idx(self) -> typing.Annotated[list[int], pybind11_stubgen.typing_ext.FixedSize(7)]:
        """
        Get indices of right arm components.
        
        Returns
        -------
        list[int]
            Indices of right arm joints.
        """
    @property
    def robot_dof(self) -> int:
        """
        Get the total degrees of freedom.
        
        Returns
        -------
        int
            Total number of joints in the robot.
        """
    @property
    def robot_joint_names(self) -> typing.Annotated[list[str], pybind11_stubgen.typing_ext.FixedSize(24)]:
        """
        Get the names of all robot joints.
        
        Returns
        -------
        list[str]
            List of joint names in order of their indices.
        """
    @property
    def torso_idx(self) -> typing.Annotated[list[int], pybind11_stubgen.typing_ext.FixedSize(6)]:
        """
        Get indices of torso components.
        
        Returns
        -------
        list[int]
            Indices of torso joints.
        """
    @property
    def velocity_estimation_required_idx(self) -> typing.Annotated[list[int], pybind11_stubgen.typing_ext.FixedSize(20)]:
        """
        Get indices of joints requiring velocity estimation.
        
        Returns
        -------
        list[int]
            Indices of joints where velocity estimation is essential.
        """
class Model_M:
    """
    
    Robot model configuration class.
    
    This class provides access to robot model specifications including
    joint configurations, degrees of freedom, and component indices.
    
    Attributes
    ----------
    model_name : str
        Name identifier for the robot model.
    robot_dof : int
        Total degrees of freedom for the robot.
    robot_joint_names : list[str]
        Names of all robot joints in order of their indices.
    mobility_idx : list[int]
        Indices of mobility components (e.g., wheels).
    body_idx : list[int]
        Indices of main body components (excluding mobility and head).
    head_idx : list[int]
        Indices of head components.
    right_arm_idx : list[int]
        Indices of right arm components.
    left_arm_idx : list[int]
        Indices of left arm components.
    torso_idx : list[int]
        Indices of torso components.
    velocity_estimation_required_idx : list[int]
        Indices of joints requiring velocity estimation.
    control_period : float
        Control update period in seconds.
    """
    def __init__(self) -> None:
        """
        Construct a model instance.
        """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    @property
    def body_idx(self) -> typing.Annotated[list[int], pybind11_stubgen.typing_ext.FixedSize(20)]:
        """
        Get indices of body components.
        
        Returns
        -------
        list[int]
            Indices of main body joints (excluding mobility and head).
        """
    @property
    def control_period(self) -> float:
        """
        Get the control update period.
        
        Returns
        -------
        float
            Control period in seconds (typically 0.002).
        """
    @property
    def head_idx(self) -> typing.Annotated[list[int], pybind11_stubgen.typing_ext.FixedSize(2)]:
        """
        Get indices of head components.
        
        Returns
        -------
        list[int]
            Indices of head joints.
        """
    @property
    def left_arm_idx(self) -> typing.Annotated[list[int], pybind11_stubgen.typing_ext.FixedSize(7)]:
        """
        Get indices of left arm components.
        
        Returns
        -------
        list[int]
            Indices of left arm joints.
        """
    @property
    def mobility_idx(self) -> typing.Annotated[list[int], pybind11_stubgen.typing_ext.FixedSize(4)]:
        """
        Get indices of mobility components.
        
        Returns
        -------
        list[int]
            Indices of wheels or other mobility joints.
        """
    @property
    def model_name(self) -> str:
        """
        Get the model name identifier.
        
        Returns
        -------
        str
            Model name (e.g., "A", "T5", "M", "UB").
        """
    @property
    def right_arm_idx(self) -> typing.Annotated[list[int], pybind11_stubgen.typing_ext.FixedSize(7)]:
        """
        Get indices of right arm components.
        
        Returns
        -------
        list[int]
            Indices of right arm joints.
        """
    @property
    def robot_dof(self) -> int:
        """
        Get the total degrees of freedom.
        
        Returns
        -------
        int
            Total number of joints in the robot.
        """
    @property
    def robot_joint_names(self) -> typing.Annotated[list[str], pybind11_stubgen.typing_ext.FixedSize(26)]:
        """
        Get the names of all robot joints.
        
        Returns
        -------
        list[str]
            List of joint names in order of their indices.
        """
    @property
    def torso_idx(self) -> typing.Annotated[list[int], pybind11_stubgen.typing_ext.FixedSize(6)]:
        """
        Get indices of torso components.
        
        Returns
        -------
        list[int]
            Indices of torso joints.
        """
    @property
    def velocity_estimation_required_idx(self) -> typing.Annotated[list[int], pybind11_stubgen.typing_ext.FixedSize(20)]:
        """
        Get indices of joints requiring velocity estimation.
        
        Returns
        -------
        list[int]
            Indices of joints where velocity estimation is essential.
        """
class Model_T5:
    """
    
    Robot model configuration class.
    
    This class provides access to robot model specifications including
    joint configurations, degrees of freedom, and component indices.
    
    Attributes
    ----------
    model_name : str
        Name identifier for the robot model.
    robot_dof : int
        Total degrees of freedom for the robot.
    robot_joint_names : list[str]
        Names of all robot joints in order of their indices.
    mobility_idx : list[int]
        Indices of mobility components (e.g., wheels).
    body_idx : list[int]
        Indices of main body components (excluding mobility and head).
    head_idx : list[int]
        Indices of head components.
    right_arm_idx : list[int]
        Indices of right arm components.
    left_arm_idx : list[int]
        Indices of left arm components.
    torso_idx : list[int]
        Indices of torso components.
    velocity_estimation_required_idx : list[int]
        Indices of joints requiring velocity estimation.
    control_period : float
        Control update period in seconds.
    """
    def __init__(self) -> None:
        """
        Construct a model instance.
        """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    @property
    def body_idx(self) -> typing.Annotated[list[int], pybind11_stubgen.typing_ext.FixedSize(19)]:
        """
        Get indices of body components.
        
        Returns
        -------
        list[int]
            Indices of main body joints (excluding mobility and head).
        """
    @property
    def control_period(self) -> float:
        """
        Get the control update period.
        
        Returns
        -------
        float
            Control period in seconds (typically 0.002).
        """
    @property
    def head_idx(self) -> typing.Annotated[list[int], pybind11_stubgen.typing_ext.FixedSize(2)]:
        """
        Get indices of head components.
        
        Returns
        -------
        list[int]
            Indices of head joints.
        """
    @property
    def left_arm_idx(self) -> typing.Annotated[list[int], pybind11_stubgen.typing_ext.FixedSize(7)]:
        """
        Get indices of left arm components.
        
        Returns
        -------
        list[int]
            Indices of left arm joints.
        """
    @property
    def mobility_idx(self) -> typing.Annotated[list[int], pybind11_stubgen.typing_ext.FixedSize(2)]:
        """
        Get indices of mobility components.
        
        Returns
        -------
        list[int]
            Indices of wheels or other mobility joints.
        """
    @property
    def model_name(self) -> str:
        """
        Get the model name identifier.
        
        Returns
        -------
        str
            Model name (e.g., "A", "T5", "M", "UB").
        """
    @property
    def right_arm_idx(self) -> typing.Annotated[list[int], pybind11_stubgen.typing_ext.FixedSize(7)]:
        """
        Get indices of right arm components.
        
        Returns
        -------
        list[int]
            Indices of right arm joints.
        """
    @property
    def robot_dof(self) -> int:
        """
        Get the total degrees of freedom.
        
        Returns
        -------
        int
            Total number of joints in the robot.
        """
    @property
    def robot_joint_names(self) -> typing.Annotated[list[str], pybind11_stubgen.typing_ext.FixedSize(23)]:
        """
        Get the names of all robot joints.
        
        Returns
        -------
        list[str]
            List of joint names in order of their indices.
        """
    @property
    def torso_idx(self) -> typing.Annotated[list[int], pybind11_stubgen.typing_ext.FixedSize(5)]:
        """
        Get indices of torso components.
        
        Returns
        -------
        list[int]
            Indices of torso joints.
        """
    @property
    def velocity_estimation_required_idx(self) -> typing.Annotated[list[int], pybind11_stubgen.typing_ext.FixedSize(19)]:
        """
        Get indices of joints requiring velocity estimation.
        
        Returns
        -------
        list[int]
            Indices of joints where velocity estimation is essential.
        """
class Model_UB:
    """
    
    Robot model configuration class.
    
    This class provides access to robot model specifications including
    joint configurations, degrees of freedom, and component indices.
    
    Attributes
    ----------
    model_name : str
        Name identifier for the robot model.
    robot_dof : int
        Total degrees of freedom for the robot.
    robot_joint_names : list[str]
        Names of all robot joints in order of their indices.
    mobility_idx : list[int]
        Indices of mobility components (e.g., wheels).
    body_idx : list[int]
        Indices of main body components (excluding mobility and head).
    head_idx : list[int]
        Indices of head components.
    right_arm_idx : list[int]
        Indices of right arm components.
    left_arm_idx : list[int]
        Indices of left arm components.
    torso_idx : list[int]
        Indices of torso components.
    velocity_estimation_required_idx : list[int]
        Indices of joints requiring velocity estimation.
    control_period : float
        Control update period in seconds.
    """
    def __init__(self) -> None:
        """
        Construct a model instance.
        """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    @property
    def body_idx(self) -> typing.Annotated[list[int], pybind11_stubgen.typing_ext.FixedSize(16)]:
        """
        Get indices of body components.
        
        Returns
        -------
        list[int]
            Indices of main body joints (excluding mobility and head).
        """
    @property
    def control_period(self) -> float:
        """
        Get the control update period.
        
        Returns
        -------
        float
            Control period in seconds (typically 0.002).
        """
    @property
    def head_idx(self) -> typing.Annotated[list[int], pybind11_stubgen.typing_ext.FixedSize(2)]:
        """
        Get indices of head components.
        
        Returns
        -------
        list[int]
            Indices of head joints.
        """
    @property
    def left_arm_idx(self) -> typing.Annotated[list[int], pybind11_stubgen.typing_ext.FixedSize(7)]:
        """
        Get indices of left arm components.
        
        Returns
        -------
        list[int]
            Indices of left arm joints.
        """
    @property
    def mobility_idx(self) -> typing.Annotated[list[int], pybind11_stubgen.typing_ext.FixedSize(0)]:
        """
        Get indices of mobility components.
        
        Returns
        -------
        list[int]
            Indices of wheels or other mobility joints.
        """
    @property
    def model_name(self) -> str:
        """
        Get the model name identifier.
        
        Returns
        -------
        str
            Model name (e.g., "A", "T5", "M", "UB").
        """
    @property
    def right_arm_idx(self) -> typing.Annotated[list[int], pybind11_stubgen.typing_ext.FixedSize(7)]:
        """
        Get indices of right arm components.
        
        Returns
        -------
        list[int]
            Indices of right arm joints.
        """
    @property
    def robot_dof(self) -> int:
        """
        Get the total degrees of freedom.
        
        Returns
        -------
        int
            Total number of joints in the robot.
        """
    @property
    def robot_joint_names(self) -> typing.Annotated[list[str], pybind11_stubgen.typing_ext.FixedSize(18)]:
        """
        Get the names of all robot joints.
        
        Returns
        -------
        list[str]
            List of joint names in order of their indices.
        """
    @property
    def torso_idx(self) -> typing.Annotated[list[int], pybind11_stubgen.typing_ext.FixedSize(2)]:
        """
        Get indices of torso components.
        
        Returns
        -------
        list[int]
            Indices of torso joints.
        """
    @property
    def velocity_estimation_required_idx(self) -> typing.Annotated[list[int], pybind11_stubgen.typing_ext.FixedSize(16)]:
        """
        Get indices of joints requiring velocity estimation.
        
        Returns
        -------
        list[int]
            Indices of joints where velocity estimation is essential.
        """
class OptimalControlCommandBuilder:
    def __init__(self) -> None:
        ...
    def add_cartesian_target(self, ref_link_name: str, link_name: str, T: numpy.ndarray[tuple[typing.Literal[4], typing.Literal[4]], numpy.dtype[numpy.float64]], translation_weight: float, rotation_weight: float) -> OptimalControlCommandBuilder:
        ...
    def add_joint_position_target(self, joint_name: str, target_position: float, weight: float) -> OptimalControlCommandBuilder:
        ...
    def set_acceleration_limit_scaling(self, acceleration_limit_scaling: float) -> OptimalControlCommandBuilder:
        ...
    def set_center_of_mass_target(self, ref_link_name: str, pose: numpy.ndarray[tuple[typing.Literal[3], typing.Literal[1]], numpy.dtype[numpy.float64]], weight: float) -> OptimalControlCommandBuilder:
        ...
    def set_command_header(self, command_header_builder: CommandHeaderBuilder) -> OptimalControlCommandBuilder:
        ...
    def set_error_scaling(self, error_scaling: float) -> OptimalControlCommandBuilder:
        ...
    def set_min_delta_cost(self, min_delta_cost: float) -> OptimalControlCommandBuilder:
        ...
    def set_patience(self, patience: int) -> OptimalControlCommandBuilder:
        ...
    def set_stop_cost(self, stop_cost: float) -> OptimalControlCommandBuilder:
        ...
    def set_velocity_limit_scaling(self, velocity_limit_scaling: float) -> OptimalControlCommandBuilder:
        ...
class OptimalControlCommandFeedback(CommandFeedback):
    def __init__(self) -> None:
        ...
    @property
    def cartesian_costs(self) -> list[float]:
        ...
    @property
    def center_of_mass_cost(self) -> float:
        ...
    @property
    def joint_position_costs(self) -> list[float]:
        ...
    @property
    def total_cost(self) -> float:
        ...
class PIDGain:
    """
    
    PID gain configuration.
    
    Represents proportional, integral, and derivative gains for PID control.
    
    Attributes
    ----------
    p_gain : int
        Proportional gain value.
    i_gain : int
        Integral gain value.
    d_gain : int
        Derivative gain value.
    """
    @typing.overload
    def __init__(self) -> None:
        """
        Construct a PIDGain instance with default values.
        """
    @typing.overload
    def __init__(self, arg0: int, arg1: int, arg2: int) -> None:
        """
        Construct a PIDGain instance with specified values.
        
        Parameters
        ----------
        p_gain : int
            Proportional gain value.
        i_gain : int
            Integral gain value.
        d_gain : int
            Derivative gain value.
        """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    @property
    def d_gain(self) -> int:
        """
        Derivative gain value.
        
        Type
        ----
        int
            Derivative gain for PID control.
        """
    @property
    def i_gain(self) -> int:
        """
        Integral gain value.
        
        Type
        ----
        int
            Integral gain for PID control.
        """
    @property
    def p_gain(self) -> int:
        """
        Proportional gain value.
        
        Type
        ----
        int
            Proportional gain for PID control.
        """
class PowerInfo:
    """
    
    Power information
    
    Information about robot-controlled external (auxiliary) power outputs.
    
    Attributes
    ----------
    name : str
        Name/label of an externally controllable power output (e.g., "5v", "12v", "24v").
    """
    def __init__(self) -> None:
        ...
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        """
        Name/label identifying the power output this object describes.
        
        Type
        ----
        str
            Human-readable identifier for the output (e.g., "5v", "12v", "24v"). Read-only.
        """
class PowerState:
    """
    
      Power state information.
    
      Provides information about power supply status and voltage.
    
      Attributes
      ----------
      state : State
          Current power state.
      voltage : float
          Power supply voltage in volts.
      
    """
    class State:
        """
        
        Power state enumeration.
        
        Defines the possible power states.
        
        Members
        -------
        Unknown : int
            Power state is unknown.
        PowerOff : int
            Power is off.
        PowerOn : int
            Power is on.
        
        
        Members:
        
          Unknown : 
        Power state is unknown.
        
        
          PowerOff : 
        Power is off.
        
        
          PowerOn : 
        Power is on.
        """
        PowerOff: typing.ClassVar[PowerState.State]  # value = <State.PowerOff: 2>
        PowerOn: typing.ClassVar[PowerState.State]  # value = <State.PowerOn: 1>
        Unknown: typing.ClassVar[PowerState.State]  # value = <State.Unknown: 0>
        __members__: typing.ClassVar[dict[str, PowerState.State]]  # value = {'Unknown': <State.Unknown: 0>, 'PowerOff': <State.PowerOff: 2>, 'PowerOn': <State.PowerOn: 1>}
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: int) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: int) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    def __init__(self) -> None:
        """
        Construct a PowerState instance.
        """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    @property
    def state(self) -> PowerState.State:
        """
        Current power state.
        
        Type
        ----
        State
            Current power state enumeration value.
        """
    @property
    def voltage(self) -> float:
        """
        Power supply voltage.
        
        Type
        ----
        float
            Power supply voltage in volts.
        """
class RobotCommandBuilder:
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, arg0: WholeBodyCommandBuilder) -> None:
        ...
    @typing.overload
    def __init__(self, arg0: ComponentBasedCommandBuilder) -> None:
        ...
    @typing.overload
    def __init__(self, arg0: JogCommandBuilder) -> None:
        ...
    @typing.overload
    def set_command(self, whole_body_command_builder: WholeBodyCommandBuilder) -> RobotCommandBuilder:
        ...
    @typing.overload
    def set_command(self, component_based_command_builder: ComponentBasedCommandBuilder) -> RobotCommandBuilder:
        ...
    @typing.overload
    def set_command(self, jog_command_builder: JogCommandBuilder) -> RobotCommandBuilder:
        ...
class RobotCommandFeedback(CommandFeedback):
    class FinishCode:
        """
        Members:
        
          Unknown
        
          Ok
        
          Canceled
        
          Preempted
        
          InitializationFailed
        
          ControlManagerIdle
        
          ControlManagerFault
        
          UnexpectedState
        """
        Canceled: typing.ClassVar[RobotCommandFeedback.FinishCode]  # value = <FinishCode.Canceled: 2>
        ControlManagerFault: typing.ClassVar[RobotCommandFeedback.FinishCode]  # value = <FinishCode.ControlManagerFault: 6>
        ControlManagerIdle: typing.ClassVar[RobotCommandFeedback.FinishCode]  # value = <FinishCode.ControlManagerIdle: 5>
        InitializationFailed: typing.ClassVar[RobotCommandFeedback.FinishCode]  # value = <FinishCode.InitializationFailed: 4>
        Ok: typing.ClassVar[RobotCommandFeedback.FinishCode]  # value = <FinishCode.Ok: 1>
        Preempted: typing.ClassVar[RobotCommandFeedback.FinishCode]  # value = <FinishCode.Preempted: 3>
        UnexpectedState: typing.ClassVar[RobotCommandFeedback.FinishCode]  # value = <FinishCode.UnexpectedState: 7>
        Unknown: typing.ClassVar[RobotCommandFeedback.FinishCode]  # value = <FinishCode.Unknown: 0>
        __members__: typing.ClassVar[dict[str, RobotCommandFeedback.FinishCode]]  # value = {'Unknown': <FinishCode.Unknown: 0>, 'Ok': <FinishCode.Ok: 1>, 'Canceled': <FinishCode.Canceled: 2>, 'Preempted': <FinishCode.Preempted: 3>, 'InitializationFailed': <FinishCode.InitializationFailed: 4>, 'ControlManagerIdle': <FinishCode.ControlManagerIdle: 5>, 'ControlManagerFault': <FinishCode.ControlManagerFault: 6>, 'UnexpectedState': <FinishCode.UnexpectedState: 7>}
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: int) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: int) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    class Status:
        """
        Members:
        
          Idle
        
          Initializing
        
          Running
        
          Finished
        """
        Finished: typing.ClassVar[RobotCommandFeedback.Status]  # value = <Status.Finished: 3>
        Idle: typing.ClassVar[RobotCommandFeedback.Status]  # value = <Status.Idle: 0>
        Initializing: typing.ClassVar[RobotCommandFeedback.Status]  # value = <Status.Initializing: 1>
        Running: typing.ClassVar[RobotCommandFeedback.Status]  # value = <Status.Running: 2>
        __members__: typing.ClassVar[dict[str, RobotCommandFeedback.Status]]  # value = {'Idle': <Status.Idle: 0>, 'Initializing': <Status.Initializing: 1>, 'Running': <Status.Running: 2>, 'Finished': <Status.Finished: 3>}
        def __eq__(self, other: typing.Any) -> bool:
            ...
        def __getstate__(self) -> int:
            ...
        def __hash__(self) -> int:
            ...
        def __index__(self) -> int:
            ...
        def __init__(self, value: int) -> None:
            ...
        def __int__(self) -> int:
            ...
        def __ne__(self, other: typing.Any) -> bool:
            ...
        def __repr__(self) -> str:
            ...
        def __setstate__(self, state: int) -> None:
            ...
        def __str__(self) -> str:
            ...
        @property
        def name(self) -> str:
            ...
        @property
        def value(self) -> int:
            ...
    def __init__(self) -> None:
        ...
    @property
    def component_based_command(self) -> ComponentBasedCommandFeedback:
        ...
    @property
    def finish_code(self) -> RobotCommandFeedback.FinishCode:
        ...
    @property
    def jog_command(self) -> JogCommandFeedback:
        ...
    @property
    def status(self) -> RobotCommandFeedback.Status:
        ...
    @property
    def whole_body_command(self) -> WholeBodyCommandFeedback:
        ...
class RobotInfo:
    """
    
    Robot information and configuration.
    
    This class provides comprehensive information about the robot
    including version details, hardware configuration, and joint
    specifications.
    
    Attributes
    ----------
    version : str
        Robot software version.
    sdk_version : str
        SDK version.
    robot_version : str
        Robot version (deprecated, use robot_model_name instead).
    robot_model_name : str
        Name of the robot model.
    robot_model_version : str
        Version of the robot model.
    sdk_commit_id : str
        SDK commit identifier (deprecated, use sdk_version instead).
    battery_info : BatteryInfo
        Battery information.
    power_infos : list[PowerInfo]
        Robot-controlled external (auxiliary) power outputs (e.g., "5V", "12V", "24V").
    emo_infos : list[EMOInfo]
        List of emergency stop button information.
    degree_of_freedom : int
        Total number of degrees of freedom.
    joint_infos : list[JointInfo]
        List of joint information.
    mobility_joint_idx : list[int]
        Indices of mobility joints (e.g., wheels).
    body_joint_idx : list[int]
        Indices of body joints.
    head_joint_idx : list[int]
        Indices of head joints.
    torso_joint_idx : list[int]
        Indices of torso joints.
    right_arm_joint_idx : list[int]
        Indices of right arm joints.
    left_arm_joint_idx : list[int]
        Indices of left arm joints.
    """
    def __init__(self) -> None:
        """
        Construct a RobotInfo instance with default values.
        """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    @property
    def battery_info(self) -> BatteryInfo:
        """
        Battery information.
        
        Type
        ----
        BatteryInfo
            Battery information object.
        """
    @property
    def body_joint_idx(self) -> list[int]:
        """
        Indices of body joints.
        
        Type
        ----
        list[int]
            Indices of body joints.
        """
    @property
    def degree_of_freedom(self) -> int:
        """
        Total number of degrees of freedom.
        
        Type
        ----
        int
            Total number of joints in the robot.
        """
    @property
    def emo_infos(self) -> list[EMOInfo]:
        """
        List of emergency stop button information.
        
        Type
        ----
        list[EMOInfo]
            List of emergency stop button information objects.
        """
    @property
    def head_joint_idx(self) -> list[int]:
        """
        Indices of head joints.
        
        Type
        ----
        list[int]
            Indices of head joints.
        """
    @property
    def joint_infos(self) -> list[JointInfo]:
        """
        List of joint information.
        
        Type
        ----
        list[JointInfo]
            List of joint information objects.
        """
    @property
    def left_arm_joint_idx(self) -> list[int]:
        """
        Indices of left arm joints.
        
        Type
        ----
        list[int]
            Indices of left arm joints.
        """
    @property
    def mobility_joint_idx(self) -> list[int]:
        """
        Indices of mobility joints.
        
        Type
        ----
        list[int]
            Indices of mobility joints (e.g., wheels).
        """
    @property
    def power_infos(self) -> list[PowerInfo]:
        """
        Robot-controlled external (auxiliary) power outputs.
        
        Type
        ----
        list[PowerInfo]
            Each item describes an externally controllable output rail/port
            (e.g., "5V", "12V", "24V"). This is distinct from battery status.
        """
    @property
    def right_arm_joint_idx(self) -> list[int]:
        """
        Indices of right arm joints.
        
        Type
        ----
        list[int]
            Indices of right arm joints.
        """
    @property
    def robot_model_name(self) -> str:
        """
        Name of the robot model.
        
        Type
        ----
        str
            Name of the robot model (e.g., "A", "T5", "M", "UB").
        """
    @property
    def robot_model_version(self) -> str:
        """
        Version of the robot model.
        
        Type
        ----
        str
            Version string of the robot model (e.g., "v1.0", "v1.2")
        """
    @property
    def robot_version(self) -> str:
        """
        Robot version.
        
        Type
        ----
        str
            Version string of the robot (deprecated, use robot_model_name instead).
        """
    @property
    def sdk_commit_id(self) -> str:
        """
        SDK commit identifier.
        
        Type
        ----
        str
            Commit identifier of the SDK (deprecated, use sdk_version instead).
        """
    @property
    def sdk_version(self) -> str:
        """
        SDK version.
        
        Type
        ----
        str
            Version string of the SDK.
        """
    @property
    def torso_joint_idx(self) -> list[int]:
        """
        Indices of torso joints.
        
        Type
        ----
        list[int]
            Indices of torso joints.
        """
    @property
    def version(self) -> str:
        """
        Robot software version.
        
        Type
        ----
        str
            Version string of the robot software.
        """
class RobotState_A:
    """
    
    Robot state information.
    
    Provides information about the overall state of the robot, including system
    statistics, battery state, power states, emergency stop button states, joint
    states, tool flange states, force/torque sensor data, and odometry.
    
    Attributes
    ----------
    timestamp : datetime.datetime
        Timestamp of the robot state (system clock).
    system_stat : SystemStat
        System statistics (CPU, memory, uptimes).
    battery_state : BatteryState
        Battery voltage/current/level.
    power_states : list of PowerState
        Power supply states for each module.
    emo_states : list of EMOState
        Emergency-stop button states for each module.
    joint_states : list of JointState
        Per-joint status and measurements.
    
    tool_flange_right : ToolFlangeState
        Tool flange sensor and IO state for the right arm.
    tool_flange_left : ToolFlangeState
        Tool flange sensor and IO state for the left arm.
    ft_sensor_right : FTSensorData
        Force/torque readings on the right arm.
    ft_sensor_left : FTSensorData
        Force/torque readings on the left arm.
    
    is_ready : numpy.ndarray of bool, shape (DOF,)
        Whether each joint is ready.
    position : numpy.ndarray, shape (DOF,)
        Joint positions [rad].
    velocity : numpy.ndarray, shape (DOF,)
        Joint velocities [rad/s].
    current : numpy.ndarray, shape (DOF,)
        Joint currents [A].
    torque : numpy.ndarray, shape (DOF,)
        Joint torques [Nm].
    
    target_position : numpy.ndarray, shape (DOF,)
        Target joint positions [rad].
    target_velocity : numpy.ndarray, shape (DOF,)
        Target joint velocities [rad/s].
    target_feedback_gain : numpy.ndarray, shape (DOF,)
        Target feedback gains per joint. Range is [0, 10].
    target_feedforward_torque : numpy.ndarray, shape (DOF,)
        Target feedforward torques per joint [Nm].
    
    odometry : numpy.ndarray, shape (3, 3)
        Base pose as a 2D homogeneous transform (SE(2)): rotation (R) and translation (t).
    center_of_mass : numpy.ndarray, shape (3,)
        Center of mass position in base frame [m].
    
    collisions : list of CollisionResult
        Detected collisions or nearest link pairs (links, closest points, signed distance).
    temperature : numpy.ndarray, shape (DOF,)
        Joint temperatures [°C].
    gravity : numpy.ndarray, shape (DOF,)
        Gravity compensation torques per joint [Nm].
    
    Notes
    -----
    Unless noted otherwise, joint-wise vectors are NumPy arrays with shape ``(DOF,)``,
    where ``DOF = robot.model().robot_dof``.
    ``odometry`` uses a 2D homogeneous transform (SE(2)).
    ``signed distance`` is negative when penetrating.
    """
    def __init__(self) -> None:
        """
        Construct a RobotState instance.
        """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    @property
    def battery_state(self) -> BatteryState:
        """
        Battery state.
        
        Type
        ----
        BatteryState
            Battery state information, including voltage, current, and charge level.
        """
    @property
    def center_of_mass(self) -> numpy.ndarray[tuple[typing.Literal[3], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        """
        Center of mass.
        
        Type
        ----
        numpy.ndarray, shape (3,)
            Center of mass position in the base frame (meters).
        """
    @property
    def collisions(self) -> list[dynamics.CollisionResult]:
        """
        Detected collisions or nearest link pairs.
        
        Type
        ----
        list of CollisionResult
            Detected collisions or nearest link pairs (links, closest points, signed distance).
        """
    @property
    def current(self) -> numpy.ndarray[tuple[typing.Literal[24], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        """
        Current joint currents.
        
        Type
        ----
        numpy.ndarray, shape (DOF,)
            Current joint currents in A.
        """
    @property
    def emo_states(self) -> list[EMOState]:
        """
        Emergency stop button states.
        
        Type
        ----
        list of EMOState
            List of emergency stop button states for each module.
        """
    @property
    def ft_sensor_left(self) -> FTSensorData:
        """
        Force/Torque sensor data on the left arm.
        
        Type
        ----
        FTSensorData
            Force/Torque sensor readings for the left arm.
        """
    @property
    def ft_sensor_right(self) -> FTSensorData:
        """
        Force/Torque sensor data on the right arm.
        
        Type
        ----
        FTSensorData
            Force/Torque sensor readings for the right arm.
        """
    @property
    def gravity(self) -> numpy.ndarray[tuple[typing.Literal[24], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        """
        Gravity compensation torque.
        
        Type
        ----
        numpy.ndarray, shape (DOF,)
            Gravity compensation torque for each joint in Nm.
        """
    @property
    def is_ready(self) -> numpy.ndarray[tuple[typing.Literal[24], typing.Literal[1]], numpy.dtype[numpy.bool_]]:
        """
        Robot readiness.
        
        Type
        ----
        numpy.ndarray of bool, shape (DOF,)
            Indicates if each joint of the robot is ready to operate.
        """
    @property
    def joint_states(self) -> typing.Annotated[list[JointState], pybind11_stubgen.typing_ext.FixedSize(24)]:
        """
        Joint states.
        
        Type
        ----
        list of JointState
            List of joint states, each describing the status and measurements of a single joint.
        """
    @property
    def odometry(self) -> numpy.ndarray[tuple[typing.Literal[3], typing.Literal[3]], numpy.dtype[numpy.float64]]:
        """
        Odometry data.
        
        Type
        ----
        numpy.ndarray, shape (3, 3)
            Base pose as a 2D homogeneous transform (SE(2)): rotation (R) and translation (t).
        """
    @property
    def position(self) -> numpy.ndarray[tuple[typing.Literal[24], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        """
        Current joint positions.
        
        Type
        ----
        numpy.ndarray, shape (DOF,)
            Current joint positions in rad.
        """
    @property
    def power_states(self) -> list[PowerState]:
        """
        Power states.
        
        Type
        ----
        list of PowerState
            List of power supply states for each module.
        """
    @property
    def system_stat(self) -> SystemStat:
        """
        System statistics.
        
        Type
        ----
        SystemStat
            System statistics information, including CPU and memory usage.
        """
    @property
    def target_feedback_gain(self) -> numpy.ndarray[tuple[typing.Literal[24], typing.Literal[1]], numpy.dtype[numpy.uint32]]:
        """
        Target feedback gain.
        
        Type
        ----
        numpy.ndarray, shape (DOF,)
            Target feedback gain for each joint. Range is [0, 10].
        """
    @property
    def target_feedforward_torque(self) -> numpy.ndarray[tuple[typing.Literal[24], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        """
        Target feedforward torque.
        
        Type
        ----
        numpy.ndarray, shape (DOF,)
            Target feedforward torque for each joint in Nm.
        """
    @property
    def target_position(self) -> numpy.ndarray[tuple[typing.Literal[24], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        """
        Target joint positions.
        
        Type
        ----
        numpy.ndarray, shape (DOF,)
            Target joint positions in rad.
        """
    @property
    def target_velocity(self) -> numpy.ndarray[tuple[typing.Literal[24], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        """
        Target joint velocities.
        
        Type
        ----
        numpy.ndarray, shape (DOF,)
            Target joint velocities in rad/s.
        """
    @property
    def temperature(self) -> numpy.ndarray[tuple[typing.Literal[24], typing.Literal[1]], numpy.dtype[numpy.int32]]:
        """
        Joint temperatures.
        
        Type
        ----
        numpy.ndarray, shape (DOF,)
            Current temperature of each joint in °C.
        """
    @property
    def timestamp(self) -> datetime.datetime:
        """
        Timestamp of the robot state.
        
        Type
        ----
        datetime.datetime
            Timestamp of the robot state.
        """
    @property
    def tool_flange_left(self) -> ToolFlangeState:
        """
        Tool flange state on the left arm.
        
        Type
        ----
        ToolFlangeState
            Tool flange sensor and IO state for the left arm.
        """
    @property
    def tool_flange_right(self) -> ToolFlangeState:
        """
        Tool flange state on the right arm.
        
        Type
        ----
        ToolFlangeState
            Tool flange sensor and IO state for the right arm.
        """
    @property
    def torque(self) -> numpy.ndarray[tuple[typing.Literal[24], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        """
        Current joint torques.
        
        Type
        ----
        numpy.ndarray, shape (DOF,)
            Current joint torques in Nm.
        """
    @property
    def velocity(self) -> numpy.ndarray[tuple[typing.Literal[24], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        """
        Current joint velocities.
        
        Type
        ----
        numpy.ndarray, shape (DOF,)
            Current joint velocities in rad/s.
        """
class RobotState_M:
    """
    
    Robot state information.
    
    Provides information about the overall state of the robot, including system
    statistics, battery state, power states, emergency stop button states, joint
    states, tool flange states, force/torque sensor data, and odometry.
    
    Attributes
    ----------
    timestamp : datetime.datetime
        Timestamp of the robot state (system clock).
    system_stat : SystemStat
        System statistics (CPU, memory, uptimes).
    battery_state : BatteryState
        Battery voltage/current/level.
    power_states : list of PowerState
        Power supply states for each module.
    emo_states : list of EMOState
        Emergency-stop button states for each module.
    joint_states : list of JointState
        Per-joint status and measurements.
    
    tool_flange_right : ToolFlangeState
        Tool flange sensor and IO state for the right arm.
    tool_flange_left : ToolFlangeState
        Tool flange sensor and IO state for the left arm.
    ft_sensor_right : FTSensorData
        Force/torque readings on the right arm.
    ft_sensor_left : FTSensorData
        Force/torque readings on the left arm.
    
    is_ready : numpy.ndarray of bool, shape (DOF,)
        Whether each joint is ready.
    position : numpy.ndarray, shape (DOF,)
        Joint positions [rad].
    velocity : numpy.ndarray, shape (DOF,)
        Joint velocities [rad/s].
    current : numpy.ndarray, shape (DOF,)
        Joint currents [A].
    torque : numpy.ndarray, shape (DOF,)
        Joint torques [Nm].
    
    target_position : numpy.ndarray, shape (DOF,)
        Target joint positions [rad].
    target_velocity : numpy.ndarray, shape (DOF,)
        Target joint velocities [rad/s].
    target_feedback_gain : numpy.ndarray, shape (DOF,)
        Target feedback gains per joint. Range is [0, 10].
    target_feedforward_torque : numpy.ndarray, shape (DOF,)
        Target feedforward torques per joint [Nm].
    
    odometry : numpy.ndarray, shape (3, 3)
        Base pose as a 2D homogeneous transform (SE(2)): rotation (R) and translation (t).
    center_of_mass : numpy.ndarray, shape (3,)
        Center of mass position in base frame [m].
    
    collisions : list of CollisionResult
        Detected collisions or nearest link pairs (links, closest points, signed distance).
    temperature : numpy.ndarray, shape (DOF,)
        Joint temperatures [°C].
    gravity : numpy.ndarray, shape (DOF,)
        Gravity compensation torques per joint [Nm].
    
    Notes
    -----
    Unless noted otherwise, joint-wise vectors are NumPy arrays with shape ``(DOF,)``,
    where ``DOF = robot.model().robot_dof``.
    ``odometry`` uses a 2D homogeneous transform (SE(2)).
    ``signed distance`` is negative when penetrating.
    """
    def __init__(self) -> None:
        """
        Construct a RobotState instance.
        """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    @property
    def battery_state(self) -> BatteryState:
        """
        Battery state.
        
        Type
        ----
        BatteryState
            Battery state information, including voltage, current, and charge level.
        """
    @property
    def center_of_mass(self) -> numpy.ndarray[tuple[typing.Literal[3], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        """
        Center of mass.
        
        Type
        ----
        numpy.ndarray, shape (3,)
            Center of mass position in the base frame (meters).
        """
    @property
    def collisions(self) -> list[dynamics.CollisionResult]:
        """
        Detected collisions or nearest link pairs.
        
        Type
        ----
        list of CollisionResult
            Detected collisions or nearest link pairs (links, closest points, signed distance).
        """
    @property
    def current(self) -> numpy.ndarray[tuple[typing.Literal[26], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        """
        Current joint currents.
        
        Type
        ----
        numpy.ndarray, shape (DOF,)
            Current joint currents in A.
        """
    @property
    def emo_states(self) -> list[EMOState]:
        """
        Emergency stop button states.
        
        Type
        ----
        list of EMOState
            List of emergency stop button states for each module.
        """
    @property
    def ft_sensor_left(self) -> FTSensorData:
        """
        Force/Torque sensor data on the left arm.
        
        Type
        ----
        FTSensorData
            Force/Torque sensor readings for the left arm.
        """
    @property
    def ft_sensor_right(self) -> FTSensorData:
        """
        Force/Torque sensor data on the right arm.
        
        Type
        ----
        FTSensorData
            Force/Torque sensor readings for the right arm.
        """
    @property
    def gravity(self) -> numpy.ndarray[tuple[typing.Literal[26], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        """
        Gravity compensation torque.
        
        Type
        ----
        numpy.ndarray, shape (DOF,)
            Gravity compensation torque for each joint in Nm.
        """
    @property
    def is_ready(self) -> numpy.ndarray[tuple[typing.Literal[26], typing.Literal[1]], numpy.dtype[numpy.bool_]]:
        """
        Robot readiness.
        
        Type
        ----
        numpy.ndarray of bool, shape (DOF,)
            Indicates if each joint of the robot is ready to operate.
        """
    @property
    def joint_states(self) -> typing.Annotated[list[JointState], pybind11_stubgen.typing_ext.FixedSize(26)]:
        """
        Joint states.
        
        Type
        ----
        list of JointState
            List of joint states, each describing the status and measurements of a single joint.
        """
    @property
    def odometry(self) -> numpy.ndarray[tuple[typing.Literal[3], typing.Literal[3]], numpy.dtype[numpy.float64]]:
        """
        Odometry data.
        
        Type
        ----
        numpy.ndarray, shape (3, 3)
            Base pose as a 2D homogeneous transform (SE(2)): rotation (R) and translation (t).
        """
    @property
    def position(self) -> numpy.ndarray[tuple[typing.Literal[26], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        """
        Current joint positions.
        
        Type
        ----
        numpy.ndarray, shape (DOF,)
            Current joint positions in rad.
        """
    @property
    def power_states(self) -> list[PowerState]:
        """
        Power states.
        
        Type
        ----
        list of PowerState
            List of power supply states for each module.
        """
    @property
    def system_stat(self) -> SystemStat:
        """
        System statistics.
        
        Type
        ----
        SystemStat
            System statistics information, including CPU and memory usage.
        """
    @property
    def target_feedback_gain(self) -> numpy.ndarray[tuple[typing.Literal[26], typing.Literal[1]], numpy.dtype[numpy.uint32]]:
        """
        Target feedback gain.
        
        Type
        ----
        numpy.ndarray, shape (DOF,)
            Target feedback gain for each joint. Range is [0, 10].
        """
    @property
    def target_feedforward_torque(self) -> numpy.ndarray[tuple[typing.Literal[26], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        """
        Target feedforward torque.
        
        Type
        ----
        numpy.ndarray, shape (DOF,)
            Target feedforward torque for each joint in Nm.
        """
    @property
    def target_position(self) -> numpy.ndarray[tuple[typing.Literal[26], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        """
        Target joint positions.
        
        Type
        ----
        numpy.ndarray, shape (DOF,)
            Target joint positions in rad.
        """
    @property
    def target_velocity(self) -> numpy.ndarray[tuple[typing.Literal[26], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        """
        Target joint velocities.
        
        Type
        ----
        numpy.ndarray, shape (DOF,)
            Target joint velocities in rad/s.
        """
    @property
    def temperature(self) -> numpy.ndarray[tuple[typing.Literal[26], typing.Literal[1]], numpy.dtype[numpy.int32]]:
        """
        Joint temperatures.
        
        Type
        ----
        numpy.ndarray, shape (DOF,)
            Current temperature of each joint in °C.
        """
    @property
    def timestamp(self) -> datetime.datetime:
        """
        Timestamp of the robot state.
        
        Type
        ----
        datetime.datetime
            Timestamp of the robot state.
        """
    @property
    def tool_flange_left(self) -> ToolFlangeState:
        """
        Tool flange state on the left arm.
        
        Type
        ----
        ToolFlangeState
            Tool flange sensor and IO state for the left arm.
        """
    @property
    def tool_flange_right(self) -> ToolFlangeState:
        """
        Tool flange state on the right arm.
        
        Type
        ----
        ToolFlangeState
            Tool flange sensor and IO state for the right arm.
        """
    @property
    def torque(self) -> numpy.ndarray[tuple[typing.Literal[26], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        """
        Current joint torques.
        
        Type
        ----
        numpy.ndarray, shape (DOF,)
            Current joint torques in Nm.
        """
    @property
    def velocity(self) -> numpy.ndarray[tuple[typing.Literal[26], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        """
        Current joint velocities.
        
        Type
        ----
        numpy.ndarray, shape (DOF,)
            Current joint velocities in rad/s.
        """
class RobotState_T5:
    """
    
    Robot state information.
    
    Provides information about the overall state of the robot, including system
    statistics, battery state, power states, emergency stop button states, joint
    states, tool flange states, force/torque sensor data, and odometry.
    
    Attributes
    ----------
    timestamp : datetime.datetime
        Timestamp of the robot state (system clock).
    system_stat : SystemStat
        System statistics (CPU, memory, uptimes).
    battery_state : BatteryState
        Battery voltage/current/level.
    power_states : list of PowerState
        Power supply states for each module.
    emo_states : list of EMOState
        Emergency-stop button states for each module.
    joint_states : list of JointState
        Per-joint status and measurements.
    
    tool_flange_right : ToolFlangeState
        Tool flange sensor and IO state for the right arm.
    tool_flange_left : ToolFlangeState
        Tool flange sensor and IO state for the left arm.
    ft_sensor_right : FTSensorData
        Force/torque readings on the right arm.
    ft_sensor_left : FTSensorData
        Force/torque readings on the left arm.
    
    is_ready : numpy.ndarray of bool, shape (DOF,)
        Whether each joint is ready.
    position : numpy.ndarray, shape (DOF,)
        Joint positions [rad].
    velocity : numpy.ndarray, shape (DOF,)
        Joint velocities [rad/s].
    current : numpy.ndarray, shape (DOF,)
        Joint currents [A].
    torque : numpy.ndarray, shape (DOF,)
        Joint torques [Nm].
    
    target_position : numpy.ndarray, shape (DOF,)
        Target joint positions [rad].
    target_velocity : numpy.ndarray, shape (DOF,)
        Target joint velocities [rad/s].
    target_feedback_gain : numpy.ndarray, shape (DOF,)
        Target feedback gains per joint. Range is [0, 10].
    target_feedforward_torque : numpy.ndarray, shape (DOF,)
        Target feedforward torques per joint [Nm].
    
    odometry : numpy.ndarray, shape (3, 3)
        Base pose as a 2D homogeneous transform (SE(2)): rotation (R) and translation (t).
    center_of_mass : numpy.ndarray, shape (3,)
        Center of mass position in base frame [m].
    
    collisions : list of CollisionResult
        Detected collisions or nearest link pairs (links, closest points, signed distance).
    temperature : numpy.ndarray, shape (DOF,)
        Joint temperatures [°C].
    gravity : numpy.ndarray, shape (DOF,)
        Gravity compensation torques per joint [Nm].
    
    Notes
    -----
    Unless noted otherwise, joint-wise vectors are NumPy arrays with shape ``(DOF,)``,
    where ``DOF = robot.model().robot_dof``.
    ``odometry`` uses a 2D homogeneous transform (SE(2)).
    ``signed distance`` is negative when penetrating.
    """
    def __init__(self) -> None:
        """
        Construct a RobotState instance.
        """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    @property
    def battery_state(self) -> BatteryState:
        """
        Battery state.
        
        Type
        ----
        BatteryState
            Battery state information, including voltage, current, and charge level.
        """
    @property
    def center_of_mass(self) -> numpy.ndarray[tuple[typing.Literal[3], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        """
        Center of mass.
        
        Type
        ----
        numpy.ndarray, shape (3,)
            Center of mass position in the base frame (meters).
        """
    @property
    def collisions(self) -> list[dynamics.CollisionResult]:
        """
        Detected collisions or nearest link pairs.
        
        Type
        ----
        list of CollisionResult
            Detected collisions or nearest link pairs (links, closest points, signed distance).
        """
    @property
    def current(self) -> numpy.ndarray[tuple[typing.Literal[23], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        """
        Current joint currents.
        
        Type
        ----
        numpy.ndarray, shape (DOF,)
            Current joint currents in A.
        """
    @property
    def emo_states(self) -> list[EMOState]:
        """
        Emergency stop button states.
        
        Type
        ----
        list of EMOState
            List of emergency stop button states for each module.
        """
    @property
    def ft_sensor_left(self) -> FTSensorData:
        """
        Force/Torque sensor data on the left arm.
        
        Type
        ----
        FTSensorData
            Force/Torque sensor readings for the left arm.
        """
    @property
    def ft_sensor_right(self) -> FTSensorData:
        """
        Force/Torque sensor data on the right arm.
        
        Type
        ----
        FTSensorData
            Force/Torque sensor readings for the right arm.
        """
    @property
    def gravity(self) -> numpy.ndarray[tuple[typing.Literal[23], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        """
        Gravity compensation torque.
        
        Type
        ----
        numpy.ndarray, shape (DOF,)
            Gravity compensation torque for each joint in Nm.
        """
    @property
    def is_ready(self) -> numpy.ndarray[tuple[typing.Literal[23], typing.Literal[1]], numpy.dtype[numpy.bool_]]:
        """
        Robot readiness.
        
        Type
        ----
        numpy.ndarray of bool, shape (DOF,)
            Indicates if each joint of the robot is ready to operate.
        """
    @property
    def joint_states(self) -> typing.Annotated[list[JointState], pybind11_stubgen.typing_ext.FixedSize(23)]:
        """
        Joint states.
        
        Type
        ----
        list of JointState
            List of joint states, each describing the status and measurements of a single joint.
        """
    @property
    def odometry(self) -> numpy.ndarray[tuple[typing.Literal[3], typing.Literal[3]], numpy.dtype[numpy.float64]]:
        """
        Odometry data.
        
        Type
        ----
        numpy.ndarray, shape (3, 3)
            Base pose as a 2D homogeneous transform (SE(2)): rotation (R) and translation (t).
        """
    @property
    def position(self) -> numpy.ndarray[tuple[typing.Literal[23], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        """
        Current joint positions.
        
        Type
        ----
        numpy.ndarray, shape (DOF,)
            Current joint positions in rad.
        """
    @property
    def power_states(self) -> list[PowerState]:
        """
        Power states.
        
        Type
        ----
        list of PowerState
            List of power supply states for each module.
        """
    @property
    def system_stat(self) -> SystemStat:
        """
        System statistics.
        
        Type
        ----
        SystemStat
            System statistics information, including CPU and memory usage.
        """
    @property
    def target_feedback_gain(self) -> numpy.ndarray[tuple[typing.Literal[23], typing.Literal[1]], numpy.dtype[numpy.uint32]]:
        """
        Target feedback gain.
        
        Type
        ----
        numpy.ndarray, shape (DOF,)
            Target feedback gain for each joint. Range is [0, 10].
        """
    @property
    def target_feedforward_torque(self) -> numpy.ndarray[tuple[typing.Literal[23], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        """
        Target feedforward torque.
        
        Type
        ----
        numpy.ndarray, shape (DOF,)
            Target feedforward torque for each joint in Nm.
        """
    @property
    def target_position(self) -> numpy.ndarray[tuple[typing.Literal[23], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        """
        Target joint positions.
        
        Type
        ----
        numpy.ndarray, shape (DOF,)
            Target joint positions in rad.
        """
    @property
    def target_velocity(self) -> numpy.ndarray[tuple[typing.Literal[23], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        """
        Target joint velocities.
        
        Type
        ----
        numpy.ndarray, shape (DOF,)
            Target joint velocities in rad/s.
        """
    @property
    def temperature(self) -> numpy.ndarray[tuple[typing.Literal[23], typing.Literal[1]], numpy.dtype[numpy.int32]]:
        """
        Joint temperatures.
        
        Type
        ----
        numpy.ndarray, shape (DOF,)
            Current temperature of each joint in °C.
        """
    @property
    def timestamp(self) -> datetime.datetime:
        """
        Timestamp of the robot state.
        
        Type
        ----
        datetime.datetime
            Timestamp of the robot state.
        """
    @property
    def tool_flange_left(self) -> ToolFlangeState:
        """
        Tool flange state on the left arm.
        
        Type
        ----
        ToolFlangeState
            Tool flange sensor and IO state for the left arm.
        """
    @property
    def tool_flange_right(self) -> ToolFlangeState:
        """
        Tool flange state on the right arm.
        
        Type
        ----
        ToolFlangeState
            Tool flange sensor and IO state for the right arm.
        """
    @property
    def torque(self) -> numpy.ndarray[tuple[typing.Literal[23], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        """
        Current joint torques.
        
        Type
        ----
        numpy.ndarray, shape (DOF,)
            Current joint torques in Nm.
        """
    @property
    def velocity(self) -> numpy.ndarray[tuple[typing.Literal[23], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        """
        Current joint velocities.
        
        Type
        ----
        numpy.ndarray, shape (DOF,)
            Current joint velocities in rad/s.
        """
class RobotState_UB:
    """
    
    Robot state information.
    
    Provides information about the overall state of the robot, including system
    statistics, battery state, power states, emergency stop button states, joint
    states, tool flange states, force/torque sensor data, and odometry.
    
    Attributes
    ----------
    timestamp : datetime.datetime
        Timestamp of the robot state (system clock).
    system_stat : SystemStat
        System statistics (CPU, memory, uptimes).
    battery_state : BatteryState
        Battery voltage/current/level.
    power_states : list of PowerState
        Power supply states for each module.
    emo_states : list of EMOState
        Emergency-stop button states for each module.
    joint_states : list of JointState
        Per-joint status and measurements.
    
    tool_flange_right : ToolFlangeState
        Tool flange sensor and IO state for the right arm.
    tool_flange_left : ToolFlangeState
        Tool flange sensor and IO state for the left arm.
    ft_sensor_right : FTSensorData
        Force/torque readings on the right arm.
    ft_sensor_left : FTSensorData
        Force/torque readings on the left arm.
    
    is_ready : numpy.ndarray of bool, shape (DOF,)
        Whether each joint is ready.
    position : numpy.ndarray, shape (DOF,)
        Joint positions [rad].
    velocity : numpy.ndarray, shape (DOF,)
        Joint velocities [rad/s].
    current : numpy.ndarray, shape (DOF,)
        Joint currents [A].
    torque : numpy.ndarray, shape (DOF,)
        Joint torques [Nm].
    
    target_position : numpy.ndarray, shape (DOF,)
        Target joint positions [rad].
    target_velocity : numpy.ndarray, shape (DOF,)
        Target joint velocities [rad/s].
    target_feedback_gain : numpy.ndarray, shape (DOF,)
        Target feedback gains per joint. Range is [0, 10].
    target_feedforward_torque : numpy.ndarray, shape (DOF,)
        Target feedforward torques per joint [Nm].
    
    odometry : numpy.ndarray, shape (3, 3)
        Base pose as a 2D homogeneous transform (SE(2)): rotation (R) and translation (t).
    center_of_mass : numpy.ndarray, shape (3,)
        Center of mass position in base frame [m].
    
    collisions : list of CollisionResult
        Detected collisions or nearest link pairs (links, closest points, signed distance).
    temperature : numpy.ndarray, shape (DOF,)
        Joint temperatures [°C].
    gravity : numpy.ndarray, shape (DOF,)
        Gravity compensation torques per joint [Nm].
    
    Notes
    -----
    Unless noted otherwise, joint-wise vectors are NumPy arrays with shape ``(DOF,)``,
    where ``DOF = robot.model().robot_dof``.
    ``odometry`` uses a 2D homogeneous transform (SE(2)).
    ``signed distance`` is negative when penetrating.
    """
    def __init__(self) -> None:
        """
        Construct a RobotState instance.
        """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    @property
    def battery_state(self) -> BatteryState:
        """
        Battery state.
        
        Type
        ----
        BatteryState
            Battery state information, including voltage, current, and charge level.
        """
    @property
    def center_of_mass(self) -> numpy.ndarray[tuple[typing.Literal[3], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        """
        Center of mass.
        
        Type
        ----
        numpy.ndarray, shape (3,)
            Center of mass position in the base frame (meters).
        """
    @property
    def collisions(self) -> list[dynamics.CollisionResult]:
        """
        Detected collisions or nearest link pairs.
        
        Type
        ----
        list of CollisionResult
            Detected collisions or nearest link pairs (links, closest points, signed distance).
        """
    @property
    def current(self) -> numpy.ndarray[tuple[typing.Literal[18], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        """
        Current joint currents.
        
        Type
        ----
        numpy.ndarray, shape (DOF,)
            Current joint currents in A.
        """
    @property
    def emo_states(self) -> list[EMOState]:
        """
        Emergency stop button states.
        
        Type
        ----
        list of EMOState
            List of emergency stop button states for each module.
        """
    @property
    def ft_sensor_left(self) -> FTSensorData:
        """
        Force/Torque sensor data on the left arm.
        
        Type
        ----
        FTSensorData
            Force/Torque sensor readings for the left arm.
        """
    @property
    def ft_sensor_right(self) -> FTSensorData:
        """
        Force/Torque sensor data on the right arm.
        
        Type
        ----
        FTSensorData
            Force/Torque sensor readings for the right arm.
        """
    @property
    def gravity(self) -> numpy.ndarray[tuple[typing.Literal[18], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        """
        Gravity compensation torque.
        
        Type
        ----
        numpy.ndarray, shape (DOF,)
            Gravity compensation torque for each joint in Nm.
        """
    @property
    def is_ready(self) -> numpy.ndarray[tuple[typing.Literal[18], typing.Literal[1]], numpy.dtype[numpy.bool_]]:
        """
        Robot readiness.
        
        Type
        ----
        numpy.ndarray of bool, shape (DOF,)
            Indicates if each joint of the robot is ready to operate.
        """
    @property
    def joint_states(self) -> typing.Annotated[list[JointState], pybind11_stubgen.typing_ext.FixedSize(18)]:
        """
        Joint states.
        
        Type
        ----
        list of JointState
            List of joint states, each describing the status and measurements of a single joint.
        """
    @property
    def odometry(self) -> numpy.ndarray[tuple[typing.Literal[3], typing.Literal[3]], numpy.dtype[numpy.float64]]:
        """
        Odometry data.
        
        Type
        ----
        numpy.ndarray, shape (3, 3)
            Base pose as a 2D homogeneous transform (SE(2)): rotation (R) and translation (t).
        """
    @property
    def position(self) -> numpy.ndarray[tuple[typing.Literal[18], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        """
        Current joint positions.
        
        Type
        ----
        numpy.ndarray, shape (DOF,)
            Current joint positions in rad.
        """
    @property
    def power_states(self) -> list[PowerState]:
        """
        Power states.
        
        Type
        ----
        list of PowerState
            List of power supply states for each module.
        """
    @property
    def system_stat(self) -> SystemStat:
        """
        System statistics.
        
        Type
        ----
        SystemStat
            System statistics information, including CPU and memory usage.
        """
    @property
    def target_feedback_gain(self) -> numpy.ndarray[tuple[typing.Literal[18], typing.Literal[1]], numpy.dtype[numpy.uint32]]:
        """
        Target feedback gain.
        
        Type
        ----
        numpy.ndarray, shape (DOF,)
            Target feedback gain for each joint. Range is [0, 10].
        """
    @property
    def target_feedforward_torque(self) -> numpy.ndarray[tuple[typing.Literal[18], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        """
        Target feedforward torque.
        
        Type
        ----
        numpy.ndarray, shape (DOF,)
            Target feedforward torque for each joint in Nm.
        """
    @property
    def target_position(self) -> numpy.ndarray[tuple[typing.Literal[18], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        """
        Target joint positions.
        
        Type
        ----
        numpy.ndarray, shape (DOF,)
            Target joint positions in rad.
        """
    @property
    def target_velocity(self) -> numpy.ndarray[tuple[typing.Literal[18], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        """
        Target joint velocities.
        
        Type
        ----
        numpy.ndarray, shape (DOF,)
            Target joint velocities in rad/s.
        """
    @property
    def temperature(self) -> numpy.ndarray[tuple[typing.Literal[18], typing.Literal[1]], numpy.dtype[numpy.int32]]:
        """
        Joint temperatures.
        
        Type
        ----
        numpy.ndarray, shape (DOF,)
            Current temperature of each joint in °C.
        """
    @property
    def timestamp(self) -> datetime.datetime:
        """
        Timestamp of the robot state.
        
        Type
        ----
        datetime.datetime
            Timestamp of the robot state.
        """
    @property
    def tool_flange_left(self) -> ToolFlangeState:
        """
        Tool flange state on the left arm.
        
        Type
        ----
        ToolFlangeState
            Tool flange sensor and IO state for the left arm.
        """
    @property
    def tool_flange_right(self) -> ToolFlangeState:
        """
        Tool flange state on the right arm.
        
        Type
        ----
        ToolFlangeState
            Tool flange sensor and IO state for the right arm.
        """
    @property
    def torque(self) -> numpy.ndarray[tuple[typing.Literal[18], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        """
        Current joint torques.
        
        Type
        ----
        numpy.ndarray, shape (DOF,)
            Current joint torques in Nm.
        """
    @property
    def velocity(self) -> numpy.ndarray[tuple[typing.Literal[18], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        """
        Current joint velocities.
        
        Type
        ----
        numpy.ndarray, shape (DOF,)
            Current joint velocities in rad/s.
        """
class Robot_A:
    """
    
    Robot control interface.
    
    Provides high-level control interface for robot operations including
    connection management, power control, and command execution.
    
    Attributes
    ----------
    model : PyModel
        Robot model configuration.
    """
    @staticmethod
    def create(address: str) -> Robot_A:
        """
        create(address)
        
        Create a robot instance.
        
        Parameters
        ----------
        address : str
            Robot network address, e.g. "192.168.1.100:50051".
        
        Returns
        -------
        Robot
            Robot instance.
        
        Examples
        --------
        >>> import rby1_sdk
        >>> robot = rby.Robot_A.create("192.168.30.1:50051")
        >>> robot.connect()
        >>> if robot.is_connected():
        ...     print("Robot connected successfully")
        ...     robot_info = robot.get_robot_info()
        ...     print(f"Robot model: {robot.model().model_name}")
        ...     # Note: Model A has mobile base (2-DOF) + torso (6-DOF) + right arm (7-DOF) + left arm (7-DOF) + head (2-DOF)
        ...     # Total joints: 2 + 6 + 7 + 7 + 2 = 24 DOF for model A
        """
    @staticmethod
    def model() -> Model_A:
        """
        model()
        
        Get the robot model configuration.
        
        Returns
        -------
        PyModel
            Robot model configuration object.
        """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    def break_engage(self, dev_name: str) -> bool:
        """
        break_engage(dev_name)
        
        Engage the brake for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name (joint name) to engage brake. Supports regex patterns.
        
        Examples
        --------
        >>> # Engage brake for manitance
        >>> robot.break_engage("right_arm_0")
        """
    def break_release(self, dev_name: str) -> bool:
        """
        break_release(dev_name)
        
        Release the brake for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name (joint name) to release brake. Supports regex patterns.
        
        Examples
        --------
        >>> # Release brake to allow movement
        >>> robot.break_release("right_arm_0")
        """
    def cancel_control(self) -> bool:
        """
        cancel_control()
        
        Cancel current control operation.
        """
    def connect(self, max_retries: int = 5, timeout_ms: int = 1000) -> bool:
        """
        connect(max_retries=5, timeout_ms=1000)
        
        Attempts to establish a connection with the robot.
        
        Parameters
        ----------
        max_retries : int, optional
            Maximum number of retries to connect. Default is 5.
        timeout_ms : int, optional
            Timeout in milliseconds for each connection attempt. Default is 1000.
        
        Returns
        -------
        bool
            ``True`` if the connection was successful, ``False`` otherwise.
        
        Examples
        --------
        >>> robot = rby1_sdk.create_robot("192.168.1.100", "a")
        >>> if robot.connect():
        ...     print("Connected to robot")
        ... else:
        ...     print("Failed to connect")
        >>> # Default: max_retries=5, timeout_ms=1000
        >>> # Custom: robot.connect(max_retries=10, timeout_ms=2000)
        """
    def connect_wifi(self, ssid: str, password: str = '', use_dhcp: bool = True, ip_address: str = '', gateway: str = '', dns: list[str] = []) -> bool:
        """
        connect_wifi(ssid, password='', use_dhcp=True, ip_address='', gateway='', dns=[])
        
        Connect to WiFi network.
        
        Parameters
        ----------
        ssid : str
            WiFi network name.
        password : str, optional
            WiFi password. Default is empty string.
        use_dhcp : bool, optional
            Use DHCP. Default is True.
        ip_address : str, optional
            Static IP address. Default is empty string.
        gateway : str, optional
            Gateway address. Default is empty string.
        dns : list[str], optional
            DNS servers. Default is empty string.
        
        Examples
        --------
        >>> # Connect using DHCP (automatic IP)
        >>> robot.connect_wifi("MyWiFi", "mypassword123")
        >>> # Connect with static IP configuration
        >>> robot.connect_wifi("MyWiFi", "mypassword123", use_dhcp=False,
        ...                    ip_address="192.168.1.100/24", gateway="192.168.1.1")
        >>> # Connect to open network
        >>> robot.connect_wifi("OpenNetwork")
        >>> # Check connection status
        >>> status = robot.get_wifi_status()
        >>> print(f"Connected: {status.connected}, SSID: {status.ssid}")
        """
    def control(self, control: typing.Callable[[Robot_A_ControlState], Robot_A_ControlInput], port: int = 0, priority: int = 1) -> bool:
        """
        control(control, port=0, priority=1)
        
        Start a **blocking** real-time control loop using a custom control callback.
        
        This function runs a UDP-based real-time loop that repeatedly calls the user-provided
        ``control(ControlState) -> ControlInput``. The loop exits when the callback returns a
        ``ControlInput`` with ``finish=True``, or when an error/abort occurs. The function
        returns ``True`` only if it finished via ``finish=True``; otherwise ``False``.
        
        Parameters
        ----------
        control : callable
            A callable that accepts a ``ControlState`` and returns a ``ControlInput``.
            The callback is invoked for each received RT state packet.
        port : int, optional
            UDP port to bind for the RT server. Use ``0`` to let the OS choose an available port
            (recommended). Default is ``0``.
        priority : int, optional
            Command priority sent with the RT control request. Default is ``1``.
        
        Returns
        -------
        bool
            ``True`` if the loop terminated because the callback set ``finish=True`` in
            ``ControlInput``. ``False`` if the loop ended due to an error or abort
            (e.g., UDP bind failure, connection issue).
        
        Notes
        -----
        - **Blocking:** This call blocks until the control loop ends. There is no handler for
          external cancellation. Design the callback to set ``finish=True`` when you want to stop.
        - **GIL behavior:** The function releases the Python GIL around I/O and reacquires it
          only when invoking your Python callback, allowing other Python threads to run between
          callbacks.
        - **Performance:** Keep the callback lightweight—avoid long computations or blocking I/O
          inside the callback to maintain RT responsiveness.
        - **State fields:** The provided ``ControlState`` includes timestamp ``t``, and arrays 
          such as ``position``, ``velocity``, ``current``, and ``torque`` for all DoFs of the robot.
        - **Errors:** If the UDP server fails to bind (e.g., port unavailable), the function
          returns ``False`` immediately (and prints the error to ``stderr``).
        
        Examples
        --------
        >>> import numpy as np
        >>> 
        >>> # Stop after ~2 seconds using state.t
        >>> t0 = {"t": None}
        >>> def control_fn(state):
        ...     if t0["t"] is None:
        ...         t0["t"] = state.t
        ...     finish = (state.t - t0["t"]) >= 2.0
        ...     i = ControlInput()
        ...     i.mode.fill(rby.ControlMode.Position)
        ...     i.target = np.zeros_like(state.position)   # hold home
        ...     i.feedback_gain.fill(10)                   # simple P gain
        ...     i.feedforward_torque.fill(0)               # no torque feedforward
        ...     i.finish = finish
        ...     return i
        >>> ok = robot.control(control_fn)
        >>> print(ok)   # True if finished via finish=True
        """
    def create_command_stream(self, priority: int = 1) -> Robot_A_CommandStreamHandler:
        """
        create_command_stream(priority=1)
        
        Create a command stream for continuous command sending.
        
        Parameters
        ----------
        priority : int, optional
            Command priority. Default is 1.
        
        Returns
        -------
        RobotCommandStreamHandler
            Command stream handler.
        
        Examples
        --------
        >>> # Create command stream for continuous operation
        >>> stream_handler = robot.create_command_stream(priority=1)
        >>> # Send commands continuously
        >>> for i in range(10):
        ...     command_builder = create_command(i)
        ...     stream_handler.send_command(command_builder, timeout_ms=1000)
        ...     time.sleep(1)
        >>> # Through the handler, you can terminate control or check the current state
        >>> stream_handler.cancel()
        >>> # See examples/python/cartesian_command_stream.py for complete usage
        """
    def disable_control_manager(self) -> bool:
        """
        disable_control_manager()
        
        Disable the control manager.
        """
    def disconnect(self) -> None:
        """
        disconnect()
        
        Disconnects from the robot.
        """
    def disconnect_wifi(self) -> bool:
        """
        disconnect_wifi()
        
        Disconnect from WiFi network.
        """
    def download_file(self, path: str, file_like: typing.Any) -> bool:
        """
        download_file(path, file_like)
        
        Downloads a file from the robot and writes it into a file-like object.
        
        Parameters
        ----------
        path : str
            Relative path to the file on the robot's file system.
            The base directory is defined by the `RBY1_HOME` environment variable (default: `/root/.rby1`).
        file_like : file-like object
            Any object with a `.write(bytes)` method (e.g., `io.BytesIO`, a real file).
        
        Returns
        -------
        bool
            ``True`` if the file was downloaded successfully.
        
        Raises
        ------
        RuntimeError
            If the gRPC call fails (e.g., network issue, file not found, internal error).
        """
    def enable_control_manager(self, unlimited_mode_enabled: bool = False) -> bool:
        """
        Enable the control manager.
        
        Parameters
        ----------
        unlimited_mode_enabled : bool, optional
            Whether to enable unlimited mode. Default is False.
        
        Examples
        --------
        >>> # Enable control manager for robot control
        >>> robot.enable_control_manager()
        >>> # Enable with unlimited mode (use with caution)
        >>> robot.enable_control_manager(unlimited_mode_enabled=True)
        >>> # Must be called before sending commands
        """
    def factory_reset_all_parameters(self) -> None:
        """
        factory_reset_all_parameters()
        
        Factory reset all parameters to their default values.
        """
    def factory_reset_parameter(self, name: str) -> bool:
        """
        factory_reset_parameter(name)
        
        Factory reset a parameter to its default value.
        
        Parameters
        ----------
        name : str
            Parameter name.
        """
    def get_control_manager_state(self) -> ControlManagerState:
        """
        get_control_manager_state()
        
        Get control manager state.
        
        Returns
        -------
        ControlManagerState
            Current control manager state.
        
        Examples
        --------
        >>> # Get control manager state
        >>> ctrl_state = robot.get_control_manager_state()
        >>> print(f"Control Manager state: {ctrl_state.state}")
        >>> print(f"Control state: {ctrl_state.control_state}")
        >>> # Check if control manager is enabled
        >>> if ctrl_state.state == rby1_sdk.ControlManagerState.State.Enabled:
        ...     print("Control manager is enabled")
        """
    def get_dynamics(self, urdf_model: str = '') -> dynamics.Robot_24:
        """
        get_dynamics(urdf_model='')
        
        Get robot dynamics model.
        
        Parameters
        ----------
        urdf_model : str, optional
            URDF model path. Default is empty string.
        
        Returns
        -------
        dyn.Robot
            Robot dynamics model.
        
        Examples
        --------
        >>> # Get dynamics model with the model from connected robot
        >>> dynamics_robot = robot.get_dynamics()
        >>> # Get dynamics model with custom URDF
        >>> dynamics_robot = robot.get_dynamics("/path/to/custom.urdf")
        >>> # Useful for advanced control algorithms
        """
    def get_fault_log_list(self) -> list[str]:
        """
        get_fault_log_list()
        
        Get fault log list.
        
        Returns
        -------
        list
            List of fault log entries.
        """
    def get_head_position_pid_gains(self) -> list[PIDGain]:
        """
        get_head_position_pid_gains()
        
        Get head position PID gains.
        
        Returns
        -------
        PIDGain
            Head position PID gains.
        """
    def get_last_log(self, count: int) -> list[Log]:
        """
        get_last_log(count)
        
        Get last log entries.
        
        Parameters
        ----------
        count : int
            Number of log entries to retrieve.
        
        Returns
        -------
        list
            List of log entries.
        """
    def get_left_arm_position_pid_gains(self) -> list[PIDGain]:
        """
        get_left_arm_position_pid_gains()
        
        Get left arm position PID gains.
        
        Returns
        -------
        PIDGain
            Left arm position PID gains.
        """
    def get_parameter(self, name: str) -> str:
        """
        get_parameter(name)
        
        Retrieve a robot parameter.
        
        Parameters
        ----------
        name : str
            Name of the parameter to retrieve.
        
        Returns
        -------
        any
            Parameter value.
            Returned as a JSON value: numeric values are returned as-is, strings are enclosed in quotes ("...").
        
        Examples
        --------
        >>> # Retrieve current parameter values
        >>> acc_scaling = robot.get_parameter("default.acceleration_limit_scaling")
        >>> cutoff_freq = robot.get_parameter("joint_position_command.cutoff_frequency")
        >>> model_name = robot.get_parameter("robot_model_name")
        >>> print(f"Acceleration scaling: {acc_scaling}")
        >>> print(f"Cutoff frequency: {cutoff_freq}")
        >>> print(f"Model name: {model_name}")
        """
    def get_parameter_list(self) -> list[tuple[str, int]]:
        """
        get_parameter_list()
        
        Get list of available parameters.
        
        Returns
        -------
        list
            List of parameter names.
        
        Examples
        --------
        >>> # Get all available parameters
        >>> param_list = robot.get_parameter_list()
        >>> print(f"Total parameters: {len(param_list)}")
        >>> # List common parameter categories
        >>> for param in param_list:
        ...     if param[0].startswith("default."):
        ...         print(f"Default param: {param}")
        ...     elif param[0].startswith("joint_position_command."):
        ...         print(f"Joint position param: {param}")
        >>> # Common categories: default.*, joint_position_command.*, cartesian_command.*
        """
    def get_position_pid_gain(self, dev_name: str) -> PIDGain:
        """
        get_position_pid_gain(dev_name)
        
        Get position PID gains for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name.
        
        Returns
        -------
        PIDGain
            Position PID gains for the device.
        
        Examples
        --------
        >>> # Get PID gains for specific device
        >>> torso_pid = robot.get_position_pid_gain("torso_5")
        >>> print(f"Torso 5 P: {torso_pid.p_gain}, I: {torso_pid.i_gain}, D: {torso_pid.d_gain}")
        >>> # Get PID gains for arm
        >>> arm_pid = robot.get_position_pid_gain("right_arm_0")
        >>> print(f"Right arm 0 P: {arm_pid.p_gain}")
        >>> devices = ["torso_5", "right_arm_0", "left_arm_1", "head_0"]
        >>> for device in devices:
        ...     pid = robot.get_position_pid_gain(device)
        ...     print(f"{device}: P={pid.p_gain}, I={pid.i_gain}, D={pid.d_gain}")
        """
    def get_right_arm_position_pid_gains(self) -> list[PIDGain]:
        """
        get_right_arm_position_pid_gains()
        
        Get right arm position PID gains.
        
        Returns
        -------
        PIDGain
            Right arm position PID gains.
        """
    def get_robot_info(self) -> RobotInfo:
        """
        get_robot_info()
        
        Retrieves static information about the robot, such as model name, SDK version, and joint configuration.
        
        Returns
        -------
        RobotInfo
            Structured metadata including joint details, device names, and robot model information.
        
        Examples
        --------
        >>> # Get robot information
        >>> robot_info = robot.get_robot_info()
        >>> print(f"SDK version: {robot_info.sdk_version}")
        >>> print(f"Robot model name: {robot_info.robot_model_name}")
        >>> print(f"Robot model version: {robot_info.robot_model_version}")
        >>> print(f"Joint count: {len(robot_info.joint_infos)}")
        >>> # Access joint information
        >>> for joint in robot_info.joint_infos:
        ...     print(f"Joint: {joint.name}, Brake: {joint.has_brake}, Product name: {joint.product_name}, Firmware version: {joint.firmware_version}")
        """
    def get_robot_model(self) -> str:
        """
        get_robot_model()
        
        Get the current robot model.
        
        Returns
        -------
        RobotModel
            Current robot model.
        """
    def get_serial_device_list(self) -> list[SerialDevice]:
        """
        get_serial_device_list()
        
        Get list of available serial devices on the robot.
        
        Returns
        -------
        list
            List of available serial devices.
        
        Examples
        --------
        >>> # Get available serial devices
        >>> devices = robot.get_serial_device_list()
        >>> print(f"Found {len(devices)} serial devices")
        >>> # List device information
        >>> for device in devices:
        ...     print(f"Path: {device.path}, Description: {device.description}")
        >>> # Open serial stream to first device
        >>> if devices:
        ...     stream = robot.open_serial_stream(devices[0].path, 115200)
        >>> # Common device paths: /dev/ttyUSB0, /dev/ttyACM0, COM1, COM2
        """
    def get_state(self) -> RobotState_A:
        """
        get_state()
        
        Get current robot state.
        
        Returns
        -------
        RobotState
            Current robot state.
        
        Examples
        --------
        >>> robot_state = robot.get_state()
        >>> model = robot.model()
        >>> print(f"Joint positions: {robot_state.position}")
        >>> print(f"Right arm position: {robot_state.position[model.right_arm_idx]}")
        >>> # Note: Joint positions include mobile base (2-DOF) + torso (6-DOF) + right arm (7-DOF) + left arm (7-DOF) + head (2-DOF)
        >>> # Total: 24 DOF for model A, 23 DOF for model M, 26 DOF for model M, 18 DOF for model UB
        """
    def get_system_time(self) -> tuple[typing.Any, str]:
        """
        Get robot system time.
        
        Returns
        -------
        tuple
            (datetime, str): Robot system time and local time string.
        """
    def get_time_scale(self) -> float:
        """
        get_time_scale()
        
        Get the current time scale.
        
        Returns
        -------
        float
            Current time scale value.
        
        Examples
        --------
        >>> # Get current time scale
        >>> current_scale = robot.get_time_scale()
        >>> print(f"Current time scale: {current_scale}")
        >>> # Check if robot is running at full speed
        >>> if current_scale == 1.0:
        ...     print("Robot running at full speed")
        >>> # Check if robot is slowed down
        >>> elif current_scale < 1.0:
        ...     print(f"Robot running at {current_scale * 100}% speed")
        """
    def get_torso_position_pid_gains(self) -> list[PIDGain]:
        """
        get_torso_position_pid_gains()
        
        Get torso position PID gains.
        
        Returns
        -------
        PIDGain
            Torso position PID gains.
        
        Examples
        --------
        >>> # Get current PID gains for torso
        >>> torso_pid = robot.get_torso_position_pid_gains()[0]  # Get first (and only) torso device
        >>> print(f"Torso P: {torso_pid.p_gain}, I: {torso_pid.i_gain}, D: {torso_pid.d_gain}")
        >>> right_arm_pid = robot.get_right_arm_position_pid_gains()[0]
        >>> print(f"Right arm: {right_arm_pid}")
        """
    def get_wifi_status(self) -> WifiStatus | None:
        """
        get_wifi_status()
        
        Get WiFi connection status.
        
        Returns
        -------
        WifiStatus
            Current WiFi status.
        """
    def has_established_time_sync(self) -> bool:
        """
        Check if time synchronization is established.
        
        Returns
        -------
        bool
            True if time sync is established, False otherwise.
        """
    def home_offset_reset(self, dev_name: str) -> bool:
        """
        home_offset_reset(dev_name)
        
        Reset home offset for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name to reset home offset. Supports regex patterns.
        """
    def import_robot_model(self, name: str, model: str) -> bool:
        """
        import_robot_model(name, model)
        
        Import a robot model.
        
        Parameters
        ----------
        name : str
            Model name.
        model : RobotModel
            Robot model to import.
        """
    def is_connected(self) -> bool:
        """
        is_connected()
        
        Checks whether the robot is currently connected.
        
        Returns
        -------
        bool
            ``True`` if the robot is connected to the robot, ``False`` otherwise.
        """
    def is_power_on(self, dev_name: str) -> bool:
        """
        is_power_on(dev_name)
        
        Check if a device is powered on.
        
        Parameters
        ----------
        dev_name : str
            Device name to check. Supports regex patterns.
        
        Returns
        -------
        bool
            ``True`` if device is powered on, ``False`` otherwise.
        """
    def is_servo_on(self, dev_name: str) -> bool:
        """
        is_servo_on(dev_name)
        
        Check if servo control is enabled for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name to check. Supports regex patterns.
        
        Returns
        -------
        bool
            ``True`` if servo control is enabled, ``False`` otherwise.
        """
    def open_serial_stream(self, device_path: str, baudrate: int, bytesize: int = 8, parity: str = 'N', stopbits: int = 1) -> SerialStream:
        """
        open_serial_stream(device_path, baudrate, bytesize=8, parity='N', stopbits=1)
        
        Open a serial stream.
        
        Parameters
        ----------
        device_path : str
            Path to serial device.
        baudrate : int
            Baud rate.
        bytesize : int, optional
            Data bits. Default is 8.
        parity : str, optional
            Parity setting. Default is 'N'.
        stopbits : int, optional
            Stop bits. Default is 1.
        
        Returns
        -------
        SerialStream
            Serial stream object.
        
        Examples
        --------
        >>> # Open serial stream with default settings
        >>> stream = robot.open_serial_stream("/dev/ttyUSB0", 115200)
        >>> # Open with custom settings
        >>> stream = robot.open_serial_stream("/dev/ttyUSB1", 9600, bytesize=7, parity='E', stopbits=2)
        >>> # Common baudrates: 9600, 19200, 38400, 57600, 115200
        >>> # Parity: 'N' (none), 'E' (even), 'O' (odd)
        >>> # Stop bits: 1, 2
        """
    def power_off(self, dev_name: str) -> bool:
        """
        power_off(dev_name)
        
        Power off a device.
        
        Parameters
        ----------
        dev_name : str
            Device name to power off. Supports regex patterns.
        """
    def power_on(self, dev_name: str) -> bool:
        """
        power_on(dev_name)
        
        Power on a device.
        
        Parameters
        ----------
        dev_name : str
            Device name to power on. Supports regex patterns.
        
        Examples
        --------
        >>> robot.connect()
        >>> if not robot.is_power_on(".*"):
        ...     robot.power_on(".*")
        ...     print("Robot powered on")
        >>> # Pattern ".*" powers on all devices
        >>> # Specific device: robot.power_on("12v"), robot.power_on("24v"), etc.
        """
    def reset_all_parameters(self) -> None:
        """
        reset_all_parameters()
        
        Reset all parameters to their current values.
        """
    def reset_all_parameters_to_default(self) -> None:
        """
        reset_all_parameters_to_default()
        
        Reset all parameters to their default values (deprecated).
        
        .. deprecated:: 0.6.0
           Use :meth:`factory_reset_all_parameters` instead.
        
        Note
        ----
        This method is deprecated. Use factory_reset_all_parameters() instead.
        """
    def reset_battery_config(self) -> bool:
        """
        reset_battery_config()
        
        Reset battery configuration to default.
        """
    def reset_fault_control_manager(self) -> bool:
        """
        reset_fault_control_manager()
        
        Reset fault in the control manager.
        """
    def reset_network_setting(self) -> bool:
        """
        reset_network_setting()
        
        Reset network settings to default.
        """
    def reset_odometry(self, angle: float, position: numpy.ndarray[tuple[typing.Literal[2], typing.Literal[1]], numpy.dtype[numpy.float64]]) -> bool:
        """
        reset_odometry(angle, position)
        
        Reset odometry to specified values.
        
        Parameters
        ----------
        angle : float
            New angle in rad.
        position : numpy.ndarray
            New position in meters.
        
        Examples
        --------
        >>> import numpy as np
        >>> # Reset odometry to origin
        >>> robot.reset_odometry(angle=0.0, position=np.array([0.0, 0.0]))
        >>> # Reset to specific position and orientation
        >>> robot.reset_odometry(angle=np.pi/2, position=np.array([1.0, 2.0]))
        >>> # Useful for mobile base navigation
        >>> # Position is [x, y] in meters, angle is yaw in rad
        """
    def reset_parameter(self, name: str) -> bool:
        """
        reset_parameter(name)
        
        Reset a parameter to its current value.
        
        Parameters
        ----------
        name : str
            Parameter name.
        """
    def reset_parameter_to_default(self, name: str) -> bool:
        """
        reset_parameter_to_default(name)
        
        Reset a parameter to its default value (deprecated).
        
        Parameters
        ----------
        name : str
            Parameter name.
        
        .. deprecated:: 0.6.0
           Use :meth:`factory_reset_parameter` instead.
        
        Note
        ----
        This method is deprecated. Use factory_reset_parameter() instead.
        """
    def scan_wifi(self) -> list[WifiNetwork]:
        """
        scan_wifi()
        
        Scan for available WiFi networks.
        
        Returns
        -------
        list
            List of available WiFi networks.
        
        Examples
        --------
        >>> # Scan for available WiFi networks
        >>> networks = robot.scan_wifi()
        >>> print(f"Found {len(networks)} networks")
        >>> # List network information
        >>> for network in networks:
        ...     print(f"SSID: {network.ssid}, Signal: {network.signal_strength}")
        >>> # Connect to a network
        >>> if networks:
        ...     robot.connect_wifi(networks[0].ssid, "password")
        """
    def send_command(self, builder: RobotCommandBuilder, priority: int = 1) -> Robot_A_CommandHandler:
        """
        send_command(builder, priority=1)
        
        Send a command to the robot.
        
        Parameters
        ----------
        builder : CommandBuilder
            Command builder to send.
        priority : int, optional
            Command priority. Default is 1.
        
        Returns
        -------
        RobotCommandHandler
            Command handler for monitoring execution.
        
        Examples
        --------
        >>> from rby1_sdk import RobotCommandBuilder, ComponentBasedCommandBuilder
        >>> from rby1_sdk import BodyComponentBasedCommandBuilder, JointPositionCommandBuilder
        >>> # Create command with method chaining (standard pattern)
        >>> command = RobotCommandBuilder().set_command(
        ...     ComponentBasedCommandBuilder().set_body_command(
        ...         BodyComponentBasedCommandBuilder()
        ...             .set_torso_command(
        ...                 JointPositionCommandBuilder()
        ...                     .set_position([0, 0, 0, 0, 0, 0])  # 6-DOF torso
        ...                     .set_minimum_time(2.0)
        ...             )
        ...     )
        ... )
        >>> handler = robot.send_command(command)
        >>> handler.wait()  # Wait for completion
        >>> # This pattern is used in most examples: examples/python/07_impedance_control.py, 09_demo_motion.py, etc.
        """
    def servo_off(self, dev_name: str) -> bool:
        """
        servo_off(dev_name)
        
        Disable servo control for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name to disable servo control. Supports regex patterns.
        
        Examples
        --------
        >>> # Disable servo control for safety
        >>> robot.servo_off(".*")  # All motor drivers
        >>> # Specific device: robot.servo_off("^torso_.*")
        """
    def servo_on(self, dev_name: str) -> bool:
        """
        servo_on(dev_name)
        
        Enable servo control for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name to enable servo control. Supports regex patterns.
        
        Examples
        --------
        >>> robot.connect()
        >>> if not robot.is_servo_on(".*"):
        ...     robot.servo_on(".*")  # Servo on all devices
        ...     print("All devices servoed on")
        >>> # Specific device: robot.servo_on("^torso_.*"), robot.servo_on("^right_arm_.*"), etc.
        """
    def set_battery_config(self, cutoff_voltage: float, fully_charged_voltage: float, coefficients: typing.Annotated[list[float], pybind11_stubgen.typing_ext.FixedSize(4)]) -> bool:
        """
        set_battery_config(cutoff_voltage, fully_charged_voltage, coefficients)
                   
        Set battery configuration.
        """
    def set_battery_level(self, arg0: float) -> bool:
        """
        Set battery level.
        
        Parameters
        ----------
        level : float
            Battery level percentage (0.0 to 100.0).
        
        Examples
        --------
        >>> # Set battery level for testing
        >>> robot.set_battery_level(100.0)  # Full battery
        >>> robot.set_battery_level(50.0)   # Half battery
        >>> robot.set_battery_level(25.0)   # Quarter battery
        >>> robot.set_battery_level(0.0)    # Empty battery
        >>> # Range: 0.0 to 100.0
        >>> # Useful for using custom battery
        """
    def set_led_color(self, color: Color, duration: float = 1, transition_time: float = 0, blinking: bool = False, blinking_freq: float = 1) -> bool:
        """
        set_led_color(color, duration=1.0, transition_time=0.0, blinking=False, blinking_freq=1.0)
        
        Set LED color.
        
        Parameters
        ----------
        color : Color
            LED color.
        duration : float, optional
            Duration in seconds. Default is 1.
        transition_time : float, optional
            Transition time in seconds. Default is 0.
        blinking : bool, optional
            Whether to blink. Default is False.
        blinking_freq : float, optional
            Blinking frequency in Hz. Default is 1.
        
        Examples
        --------
        >>> from rby1_sdk import Color
        >>> # Set LED to red for 5 seconds
        >>> robot.set_led_color(Color(255, 0, 0), duration=5.0)
        >>> # Set LED to green with 1 second transition
        >>> robot.set_led_color(Color(0, 255, 0), transition_time=1.0)
        >>> # Set LED to blue with blinking
        >>> robot.set_led_color(Color(0, 0, 255), blinking=True, blinking_freq=2.0)
        >>> # Set LED to white with custom duration and transition
        >>> robot.set_led_color(Color(255, 255, 255), duration=10.0, transition_time=2.0)
        """
    def set_parameter(self, name: str, value: str, write_db: bool = True) -> bool:
        """
        set_parameter(name, value, write_db=True)
        
        Set a robot parameter.
        
        Parameters
        ----------
        name : str
            Parameter name.
        value : any
            Parameter value.
        write_db : bool, optional
            Whether to write to database. Default is True.
        
        Examples
        --------
        >>> # Set acceleration limit scaling
        >>> robot.set_parameter("default.acceleration_limit_scaling", "0.8")
        >>> # Set joint position command cutoff frequency
        >>> robot.set_parameter("joint_position_command.cutoff_frequency", "5")
        >>> # Set hotspot SSID name
        >>> robot.set_parameter("hotspot.ssid", "\\"RBY1_HOTSPOT\\"") # For str value, use escaped quotes
        >>> # Set without writing to database (Return ``False`` if matching parameter not found)
        >>> robot.set_parameter("temp.parameter", "value", write_db=False)
        False
        """
    def set_position_d_gain(self, dev_name: str, d_gain: int) -> bool:
        """
        set_position_d_gain(dev_name, d_gain)
        
        Set position D gain for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name.
        d_gain : int
            D gain value.
        
        Examples
        --------
        >>> # Set D gain for specific devices
        >>> robot.set_position_d_gain("torso_5", 400)
        """
    def set_position_i_gain(self, dev_name: str, i_gain: int) -> bool:
        """
        set_position_i_gain(dev_name, i_gain)
        
        Set position I gain for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name.
        i_gain : int
            I gain value.
        
        Examples
        --------
        >>> # Set I gain for specific devices
        >>> robot.set_position_i_gain("torso_5", 40)
        """
    def set_position_p_gain(self, dev_name: str, p_gain: int) -> bool:
        """
        set_position_p_gain(dev_name, p_gain)
        
        Set position P gain for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name.
        p_gain : int
            P gain value.
        
        Examples
        --------
        >>> # Set P gain for specific devices
        >>> robot.set_position_p_gain("torso_5", 220)
        """
    @typing.overload
    def set_position_pid_gain(self, dev_name: str, p_gain: int, i_gain: int, d_gain: int) -> bool:
        """
        set_position_pid_gain(dev_name, p_gain, i_gain, d_gain)
        
        Set position PID gains for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name.
        p_gain : int
            P gain value.
        i_gain : int
            I gain value.
        d_gain : int
            D gain value.
        
        Examples
        --------
        >>> # Set all PID gains at once for a device
        >>> robot.set_position_pid_gain("right_arm_0", 80, 15, 200)
        >>> robot.set_position_pid_gain("right_arm_1", 80, 15, 200)
        >>> robot.set_position_pid_gain("right_arm_2", 80, 15, 200)
        >>> robot.set_position_pid_gain("right_arm_3", 35, 5, 80)
        >>> robot.set_position_pid_gain("right_arm_4", 30, 5, 70)
        >>> robot.set_position_pid_gain("right_arm_5", 30, 5, 70)
        >>> robot.set_position_pid_gain("right_arm_6", 100, 5, 120)
        """
    @typing.overload
    def set_position_pid_gain(self, dev_name: str, pid_gain: PIDGain) -> bool:
        """
        set_position_pid_gain(dev_name, pid_gain)
        
        Set position PID gains for a device using PIDGain object.
        
        Parameters
        ----------
        dev_name : str
            Device name.
        pid_gain : PIDGain
            PID gain object.
        """
    def set_preset_position(self, joint_name: str) -> bool:
        """
        set_preset_position(joint_name)
        
        Set preset position for a joint (only available for PVL-based motors).
        
        Parameters
        ----------
        joint_name : str
            Joint name to set preset position.
        
        Examples
        --------
        >>> # Set preset position for specific joints
        >>> robot.set_preset_position("right_arm_6")  # Right arm joint 6
        >>> # Preset position is used as reference for home offset
        """
    @typing.overload
    def set_system_time(self, datetime: typing.Any) -> bool:
        """
        set_system_time(datetime)
        
        Set robot system time.
        
        Parameters
        ----------
        datetime : datetime.datetime
            New system time.
        """
    @typing.overload
    def set_system_time(self, datetime: typing.Any, time_zone: str) -> bool:
        """
        set_system_time(datetime, time_zone)
        
        Set robot system time with timezone.
        
        Parameters
        ----------
        datetime : datetime.datetime
            New system time.
        time_zone : str
            Timezone string.
        """
    def set_time_scale(self, time_scale: float) -> float:
        """
        set_time_scale(time_scale)
        
        Set the time scale for motion execution.
        
        Parameters
        ----------
        time_scale : float
            Time scale value (0.0 to 1.0).
        
        Examples
        --------
        >>> # Set time scale for motion execution
        >>> robot.set_time_scale(1.0)   # Normal speed (100%)
        >>> robot.set_time_scale(0.5)   # Half speed (50%)
        >>> robot.set_time_scale(0.25)  # Quarter speed (25%)
        >>> # Range: 0.0 (stopped) to 1.0 (full speed)
        >>> # Useful for testing and safety
        """
    def set_tool_flange_digital_output(self, name: str, channel: int, state: bool) -> bool:
        """
        set_tool_flange_digital_output(name, channel, state)
        
        Set the digital output state of a specific channel on the tool flange
        of the specified arm.
        
        Parameters
        ----------
        name : str
            Arm identifier. Must be either `"right"` or `"left"`,
            indicating the tool flange of the right or left arm.
        channel : int
            Digital output channel index.
        state : bool
            Desired state of the digital output (``True`` = ON, ``False`` = OFF).
        
        Returns
        -------
        bool
            ``True`` if the command was successfully sent, ``False`` otherwise.
        
        Examples
        --------
        >>> # Turn on channel 0 on the right arm tool flange
        >>> robot.set_tool_flange_digital_output("right", 0, True)
        """
    def set_tool_flange_digital_output_dual(self, name: str, state_0: bool, state_1: bool) -> bool:
        """
        set_tool_flange_digital_output_dual(name, state_0, state_1)
        
        Set the digital output states of two channels on the tool flange
        of the specified arm simultaneously.
        
        Parameters
        ----------
        name : str
            Arm identifier. Must be either `"right"` or `"left"`,
            indicating the tool flange of the right or left arm.
        state_0 : bool
            Desired state for digital output channel 0 (True = ON, False = OFF).
        state_1 : bool
            Desired state for digital output channel 1 (True = ON, False = OFF).
        
        Returns
        -------
        bool
            ``True`` if the command was successfully sent, ``False`` otherwise.
        
        Examples
        --------
        >>> # Turn on channel 0 and turn off channel 1 on the left arm tool flange
        >>> robot.set_tool_flange_digital_output_dual("left", True, False)
        """
    def set_tool_flange_output_voltage(self, name: str, voltage: int) -> bool:
        """
        set_tool_flange_output_voltage(name, voltage)
        
        Set tool flange output voltage.
        
        Parameters
        ----------
        name : str
            Tool flange name `"right"` or `"left"`.
        
        voltage : int
            Output voltage in volts.
        
        Examples
        --------
        >>> # Set tool flange output voltage
        >>> robot.set_tool_flange_output_voltage("right", 12)  # 12V output
        >>> robot.set_tool_flange_output_voltage("left", 24)  # 24V output
        >>> # Common voltages: 12V, 24V
        >>> # Use 0V to turn off output
        >>> # Note: This method sets voltage for both tool flanges (right and left)
        """
    def start_log_stream(self, cb: typing.Callable[[list[Log]], None], rate: float) -> None:
        """
        start_log_stream(cb, rate)
                
        Start log stream callback.
        
        Parameters
        ----------
        cb : callable
            Callback function for log updates.
        rate : float
            Update rate in Hz.
        
        Examples
        --------
        >>> def log_callback(log_entries):
        ...     for log in log_entries:
        ...         print(f"{log.timestamp} - {log.level} - {log.message}")
        >>> # Start log stream at 10 Hz
        >>> robot.start_log_stream(log_callback, 10.0)
        >>> # Stop when done: robot.stop_log_stream()
        """
    def start_state_update(self, cb: typing.Callable, rate: float) -> None:
        """
        start_state_update(cb, rate)
        
        Start state update callback.
        
        Parameters
        ----------
        cb : callable
            Callback function with 1 or 2 parameters:
            - cb(robot_state) or cb(robot_state, control_manager_state)
        rate : float
            Update rate in Hz.
        
        Examples
        --------
        >>> def state_callback(robot_state):
        ...     print(f"Timestamp: {robot_state.timestamp}, Joint positions: {robot_state.position}")
        >>> # Start state updates at 100 Hz
        >>> robot.start_state_update(state_callback, 100.0)
        >>> # Stop when done: robot.stop_state_update()
        """
    def start_time_sync(self, period_sec: int) -> bool:
        """
        start_time_sync(period_sec)
        
        Start time synchronization.
        
        Parameters
        ----------
        period_sec : float
            Synchronization period in seconds.
        """
    def stop_log_stream(self) -> None:
        """
        stop_log_stream()
        
        Stop log stream callback.
        """
    def stop_state_update(self) -> None:
        """
        stop_state_update()
        
        Stop state update callback.
        """
    def stop_time_sync(self) -> bool:
        """
        stop_time_sync()
        
        Stop time synchronization.
        """
    def sync_time(self) -> bool:
        """
        sync_time()
        
        Synchronizes the timestamp of ``RobotState`` to UPC time instead of UTC. 
        Useful when synchronizing multiple devices to UPC time.
        """
    def wait_for_control_ready(self, timeout_ms: int) -> bool:
        """
        wait_for_control_ready(timeout_ms)
        
        Wait until the robot is ready to accept control commands.
        
        Parameters
        ----------
        timeout_ms : int
            Timeout in milliseconds.
        
        Returns
        -------
        bool
            ``True`` if the robot is ready to accept control (you can now set control).
            ``False`` if the timeout expired before the robot became ready.
        
        Examples
        --------
        >>> # Wait for control to be ready
        >>> if robot.wait_for_control_ready(timeout_ms=5000):
        ...     print("Control is ready, you can now set control commands.")
        ... else:
        ...     print("Timeout: control is not ready.")
        >>> # Call after servo_on() and before sending control commands
        """
class Robot_A_CommandHandler:
    """
    
    Robot command handler.
    
    Handles robot command execution and provides status monitoring.
    
    Attributes
    ----------
    is_done : bool
        Whether the command execution is complete.
    """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    def cancel(self) -> None:
        """
        cancel()
        
        Cancel the command execution.
        """
    def get(self) -> RobotCommandFeedback:
        """
        get()
        
        Wait for the command execution and get feedback
        
        Returns
        -------
        RobotCommandFeedback
            Current feedback information.
        """
    def get_status(self) -> bool:
        """
        get_status()
        
        Get gRPC status
        """
    def is_done(self) -> bool:
        """
        Check if the command execution is complete.
        
        Returns
        -------
        bool
            ``True`` if command is complete, ``False`` otherwise.
        """
    def wait(self) -> None:
        """
        wait()
        
        Wait for the command execution to complete.
        
        This method blocks until the command is done or cancelled.
        """
    def wait_for(self, timeout_ms: int) -> bool:
        """
        wait_for(timeout_ms)
        
        Wait for the command execution with timeout.
        
        Parameters
        ----------
        timeout_ms : int
            Timeout in milliseconds.
        
        Returns
        -------
        bool
            ``True`` if command completed, ``False`` if timeout.
        """
class Robot_A_CommandStreamHandler:
    """
    
    Robot command stream handler.
    
    Handles robot command execution through streaming with send and feedback capabilities.
    
    Attributes
    ----------
    is_done : bool
        Whether the command execution is complete.
    """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    def cancel(self) -> None:
        """
        cancel()
        
        Cancel the current command execution.
        """
    def is_done(self) -> bool:
        """
        Check if the command execution is complete.
        
        Returns
        -------
        bool
            True if command is complete, False otherwise.
        """
    def request_feedback(self, timeout_ms: int = 1000) -> RobotCommandFeedback:
        """
        request_feedback(timeout_ms)
        
        Request feedback from the robot.
        
        Parameters
        ----------
        timeout_ms : int, optional
            Timeout in milliseconds. Default is 1000.
        
        Returns
        -------
        RobotCommandFeedback
            Current feedback information.
        """
    def send_command(self, builder: RobotCommandBuilder, timeout_ms: int = 1000) -> RobotCommandFeedback:
        """
        send_command(builder, timeout_ms=1000)
        
        Send a command through the stream.
        
        Parameters
        ----------
        builder : CommandBuilder
            Command builder to send.
        timeout_ms : int, optional
            Timeout in milliseconds. Default is 1000.
        
        Returns
        -------
        RobotCommandFeedback
            Current feedback information.
        """
    def wait(self) -> None:
        ...
    def wait_for(self, timeout_ms: int) -> bool:
        """
        Wait for the command execution to complete.
        
        This method blocks until the command is done or cancelled.
        """
class Robot_A_ControlInput:
    """
    
    Robot control input.
    
    Represents control input parameters for robot real-time control including mode, target, and gains.
    
    Attributes
    ----------
    mode : numpy.ndarray
        Control mode for each joint (boolean array).
    target : numpy.ndarray
        Target positions for each joint in rad.
    feedback_gain : numpy.ndarray
        Feedback gains for each joint.
    feedforward_torque : numpy.ndarray
        Feedforward torque for each joint in Nm.
    finish : bool
        Whether to finish the current control operation.
    """
    def __init__(self) -> None:
        """
        Construct a ``ControlInput`` instance.
        """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    @property
    def feedback_gain(self) -> numpy.ndarray[tuple[typing.Literal[24], typing.Literal[1]], numpy.dtype[numpy.uint32]]:
        """
        Feedback gains for each joint.
        
        Type
        ----
        numpy.ndarray
            Feedback gain values for each joint.
        """
    @feedback_gain.setter
    def feedback_gain(self, arg1: numpy.ndarray[tuple[typing.Literal[24], typing.Literal[1]], numpy.dtype[numpy.uint32]]) -> None:
        ...
    @property
    def feedforward_torque(self) -> numpy.ndarray[tuple[typing.Literal[24], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        """
        Feedforward torque for each joint.
        
        Type
        ----
        numpy.ndarray
            Feedforward torque values in Nm for each joint.
        """
    @feedforward_torque.setter
    def feedforward_torque(self, arg1: numpy.ndarray[tuple[typing.Literal[24], typing.Literal[1]], numpy.dtype[numpy.float64]]) -> None:
        ...
    @property
    def finish(self) -> bool:
        """
        Finish control operation flag.
        
        Type
        ----
        bool
            Whether to finish the current control operation.
        """
    @finish.setter
    def finish(self, arg0: bool) -> None:
        ...
    @property
    def mode(self) -> numpy.ndarray[tuple[typing.Literal[24], typing.Literal[1]], numpy.dtype[numpy.bool_]]:
        """
        Control mode for each joint.
        
        Type
        ----
        numpy.ndarray
            Boolean array indicating control mode for each joint.
        """
    @mode.setter
    def mode(self, arg1: numpy.ndarray[tuple[typing.Literal[24], typing.Literal[1]], numpy.dtype[numpy.bool_]]) -> None:
        ...
    @property
    def target(self) -> numpy.ndarray[tuple[typing.Literal[24], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        """
        Target positions for each joint.
        
        Type
        ----
        numpy.ndarray
            Target positions in rad for each joint.
        """
    @target.setter
    def target(self, arg1: numpy.ndarray[tuple[typing.Literal[24], typing.Literal[1]], numpy.dtype[numpy.float64]]) -> None:
        ...
class Robot_A_ControlState:
    """
    
    Robot control state.
    
    Represents the current state of robot real-time control including position, velocity, and torque.
    
    Attributes
    ----------
    t : float
        Current time in seconds.
    is_ready : numpy.ndarray
        Whether the joint is ready for control.
    position : numpy.ndarray
        Current joint positions in rad.
    velocity : numpy.ndarray
        Current joint velocities in rad/s.
    current : numpy.ndarray
        Current joint currents in A.
    torque : numpy.ndarray
        Current joint torques in Nm.
    """
    def __init__(self) -> None:
        """
        Construct a ControlState instance.
        """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    @property
    def current(self) -> numpy.ndarray[tuple[typing.Literal[24], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        """
        Joint currents.
        
        Type
        ----
        numpy.ndarray
            Current joint currents in A.
        """
    @property
    def is_ready(self) -> numpy.ndarray[tuple[typing.Literal[24], typing.Literal[1]], numpy.dtype[numpy.bool_]]:
        """
        Robot readiness status.
        
        Type
        ----
        bool
            Whether the robot is ready for control.
        """
    @property
    def position(self) -> numpy.ndarray[tuple[typing.Literal[24], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        """
        Joint positions.
        
        Type
        ----
        numpy.ndarray
            Current joint positions in rad.
        """
    @property
    def t(self) -> float:
        """
        Current time.
        
        Type
        ----
        float
            Current time in seconds.
        """
    @property
    def torque(self) -> numpy.ndarray[tuple[typing.Literal[24], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        """
        Joint torques.
        
        Type
        ----
        numpy.ndarray
            Current joint torques in Nm.
        """
    @property
    def velocity(self) -> numpy.ndarray[tuple[typing.Literal[24], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        """
        Joint velocities.
        
        Type
        ----
        numpy.ndarray
            Current joint velocities in rad/s.
        """
class Robot_M:
    """
    
    Robot control interface.
    
    Provides high-level control interface for robot operations including
    connection management, power control, and command execution.
    
    Attributes
    ----------
    model : PyModel
        Robot model configuration.
    """
    @staticmethod
    def create(address: str) -> Robot_M:
        """
        create(address)
        
        Create a robot instance.
        
        Parameters
        ----------
        address : str
            Robot network address, e.g. "192.168.1.100:50051".
        
        Returns
        -------
        Robot
            Robot instance.
        
        Examples
        --------
        >>> import rby1_sdk
        >>> robot = rby.Robot_A.create("192.168.30.1:50051")
        >>> robot.connect()
        >>> if robot.is_connected():
        ...     print("Robot connected successfully")
        ...     robot_info = robot.get_robot_info()
        ...     print(f"Robot model: {robot.model().model_name}")
        ...     # Note: Model A has mobile base (2-DOF) + torso (6-DOF) + right arm (7-DOF) + left arm (7-DOF) + head (2-DOF)
        ...     # Total joints: 2 + 6 + 7 + 7 + 2 = 24 DOF for model A
        """
    @staticmethod
    def model() -> Model_M:
        """
        model()
        
        Get the robot model configuration.
        
        Returns
        -------
        PyModel
            Robot model configuration object.
        """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    def break_engage(self, dev_name: str) -> bool:
        """
        break_engage(dev_name)
        
        Engage the brake for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name (joint name) to engage brake. Supports regex patterns.
        
        Examples
        --------
        >>> # Engage brake for manitance
        >>> robot.break_engage("right_arm_0")
        """
    def break_release(self, dev_name: str) -> bool:
        """
        break_release(dev_name)
        
        Release the brake for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name (joint name) to release brake. Supports regex patterns.
        
        Examples
        --------
        >>> # Release brake to allow movement
        >>> robot.break_release("right_arm_0")
        """
    def cancel_control(self) -> bool:
        """
        cancel_control()
        
        Cancel current control operation.
        """
    def connect(self, max_retries: int = 5, timeout_ms: int = 1000) -> bool:
        """
        connect(max_retries=5, timeout_ms=1000)
        
        Attempts to establish a connection with the robot.
        
        Parameters
        ----------
        max_retries : int, optional
            Maximum number of retries to connect. Default is 5.
        timeout_ms : int, optional
            Timeout in milliseconds for each connection attempt. Default is 1000.
        
        Returns
        -------
        bool
            ``True`` if the connection was successful, ``False`` otherwise.
        
        Examples
        --------
        >>> robot = rby1_sdk.create_robot("192.168.1.100", "a")
        >>> if robot.connect():
        ...     print("Connected to robot")
        ... else:
        ...     print("Failed to connect")
        >>> # Default: max_retries=5, timeout_ms=1000
        >>> # Custom: robot.connect(max_retries=10, timeout_ms=2000)
        """
    def connect_wifi(self, ssid: str, password: str = '', use_dhcp: bool = True, ip_address: str = '', gateway: str = '', dns: list[str] = []) -> bool:
        """
        connect_wifi(ssid, password='', use_dhcp=True, ip_address='', gateway='', dns=[])
        
        Connect to WiFi network.
        
        Parameters
        ----------
        ssid : str
            WiFi network name.
        password : str, optional
            WiFi password. Default is empty string.
        use_dhcp : bool, optional
            Use DHCP. Default is True.
        ip_address : str, optional
            Static IP address. Default is empty string.
        gateway : str, optional
            Gateway address. Default is empty string.
        dns : list[str], optional
            DNS servers. Default is empty string.
        
        Examples
        --------
        >>> # Connect using DHCP (automatic IP)
        >>> robot.connect_wifi("MyWiFi", "mypassword123")
        >>> # Connect with static IP configuration
        >>> robot.connect_wifi("MyWiFi", "mypassword123", use_dhcp=False,
        ...                    ip_address="192.168.1.100/24", gateway="192.168.1.1")
        >>> # Connect to open network
        >>> robot.connect_wifi("OpenNetwork")
        >>> # Check connection status
        >>> status = robot.get_wifi_status()
        >>> print(f"Connected: {status.connected}, SSID: {status.ssid}")
        """
    def control(self, control: typing.Callable[[Robot_M_ControlState], Robot_M_ControlInput], port: int = 0, priority: int = 1) -> bool:
        """
        control(control, port=0, priority=1)
        
        Start a **blocking** real-time control loop using a custom control callback.
        
        This function runs a UDP-based real-time loop that repeatedly calls the user-provided
        ``control(ControlState) -> ControlInput``. The loop exits when the callback returns a
        ``ControlInput`` with ``finish=True``, or when an error/abort occurs. The function
        returns ``True`` only if it finished via ``finish=True``; otherwise ``False``.
        
        Parameters
        ----------
        control : callable
            A callable that accepts a ``ControlState`` and returns a ``ControlInput``.
            The callback is invoked for each received RT state packet.
        port : int, optional
            UDP port to bind for the RT server. Use ``0`` to let the OS choose an available port
            (recommended). Default is ``0``.
        priority : int, optional
            Command priority sent with the RT control request. Default is ``1``.
        
        Returns
        -------
        bool
            ``True`` if the loop terminated because the callback set ``finish=True`` in
            ``ControlInput``. ``False`` if the loop ended due to an error or abort
            (e.g., UDP bind failure, connection issue).
        
        Notes
        -----
        - **Blocking:** This call blocks until the control loop ends. There is no handler for
          external cancellation. Design the callback to set ``finish=True`` when you want to stop.
        - **GIL behavior:** The function releases the Python GIL around I/O and reacquires it
          only when invoking your Python callback, allowing other Python threads to run between
          callbacks.
        - **Performance:** Keep the callback lightweight—avoid long computations or blocking I/O
          inside the callback to maintain RT responsiveness.
        - **State fields:** The provided ``ControlState`` includes timestamp ``t``, and arrays 
          such as ``position``, ``velocity``, ``current``, and ``torque`` for all DoFs of the robot.
        - **Errors:** If the UDP server fails to bind (e.g., port unavailable), the function
          returns ``False`` immediately (and prints the error to ``stderr``).
        
        Examples
        --------
        >>> import numpy as np
        >>> 
        >>> # Stop after ~2 seconds using state.t
        >>> t0 = {"t": None}
        >>> def control_fn(state):
        ...     if t0["t"] is None:
        ...         t0["t"] = state.t
        ...     finish = (state.t - t0["t"]) >= 2.0
        ...     i = ControlInput()
        ...     i.mode.fill(rby.ControlMode.Position)
        ...     i.target = np.zeros_like(state.position)   # hold home
        ...     i.feedback_gain.fill(10)                   # simple P gain
        ...     i.feedforward_torque.fill(0)               # no torque feedforward
        ...     i.finish = finish
        ...     return i
        >>> ok = robot.control(control_fn)
        >>> print(ok)   # True if finished via finish=True
        """
    def create_command_stream(self, priority: int = 1) -> Robot_M_CommandStreamHandler:
        """
        create_command_stream(priority=1)
        
        Create a command stream for continuous command sending.
        
        Parameters
        ----------
        priority : int, optional
            Command priority. Default is 1.
        
        Returns
        -------
        RobotCommandStreamHandler
            Command stream handler.
        
        Examples
        --------
        >>> # Create command stream for continuous operation
        >>> stream_handler = robot.create_command_stream(priority=1)
        >>> # Send commands continuously
        >>> for i in range(10):
        ...     command_builder = create_command(i)
        ...     stream_handler.send_command(command_builder, timeout_ms=1000)
        ...     time.sleep(1)
        >>> # Through the handler, you can terminate control or check the current state
        >>> stream_handler.cancel()
        >>> # See examples/python/cartesian_command_stream.py for complete usage
        """
    def disable_control_manager(self) -> bool:
        """
        disable_control_manager()
        
        Disable the control manager.
        """
    def disconnect(self) -> None:
        """
        disconnect()
        
        Disconnects from the robot.
        """
    def disconnect_wifi(self) -> bool:
        """
        disconnect_wifi()
        
        Disconnect from WiFi network.
        """
    def download_file(self, path: str, file_like: typing.Any) -> bool:
        """
        download_file(path, file_like)
        
        Downloads a file from the robot and writes it into a file-like object.
        
        Parameters
        ----------
        path : str
            Relative path to the file on the robot's file system.
            The base directory is defined by the `RBY1_HOME` environment variable (default: `/root/.rby1`).
        file_like : file-like object
            Any object with a `.write(bytes)` method (e.g., `io.BytesIO`, a real file).
        
        Returns
        -------
        bool
            ``True`` if the file was downloaded successfully.
        
        Raises
        ------
        RuntimeError
            If the gRPC call fails (e.g., network issue, file not found, internal error).
        """
    def enable_control_manager(self, unlimited_mode_enabled: bool = False) -> bool:
        """
        Enable the control manager.
        
        Parameters
        ----------
        unlimited_mode_enabled : bool, optional
            Whether to enable unlimited mode. Default is False.
        
        Examples
        --------
        >>> # Enable control manager for robot control
        >>> robot.enable_control_manager()
        >>> # Enable with unlimited mode (use with caution)
        >>> robot.enable_control_manager(unlimited_mode_enabled=True)
        >>> # Must be called before sending commands
        """
    def factory_reset_all_parameters(self) -> None:
        """
        factory_reset_all_parameters()
        
        Factory reset all parameters to their default values.
        """
    def factory_reset_parameter(self, name: str) -> bool:
        """
        factory_reset_parameter(name)
        
        Factory reset a parameter to its default value.
        
        Parameters
        ----------
        name : str
            Parameter name.
        """
    def get_control_manager_state(self) -> ControlManagerState:
        """
        get_control_manager_state()
        
        Get control manager state.
        
        Returns
        -------
        ControlManagerState
            Current control manager state.
        
        Examples
        --------
        >>> # Get control manager state
        >>> ctrl_state = robot.get_control_manager_state()
        >>> print(f"Control Manager state: {ctrl_state.state}")
        >>> print(f"Control state: {ctrl_state.control_state}")
        >>> # Check if control manager is enabled
        >>> if ctrl_state.state == rby1_sdk.ControlManagerState.State.Enabled:
        ...     print("Control manager is enabled")
        """
    def get_dynamics(self, urdf_model: str = '') -> dynamics.Robot_26:
        """
        get_dynamics(urdf_model='')
        
        Get robot dynamics model.
        
        Parameters
        ----------
        urdf_model : str, optional
            URDF model path. Default is empty string.
        
        Returns
        -------
        dyn.Robot
            Robot dynamics model.
        
        Examples
        --------
        >>> # Get dynamics model with the model from connected robot
        >>> dynamics_robot = robot.get_dynamics()
        >>> # Get dynamics model with custom URDF
        >>> dynamics_robot = robot.get_dynamics("/path/to/custom.urdf")
        >>> # Useful for advanced control algorithms
        """
    def get_fault_log_list(self) -> list[str]:
        """
        get_fault_log_list()
        
        Get fault log list.
        
        Returns
        -------
        list
            List of fault log entries.
        """
    def get_head_position_pid_gains(self) -> list[PIDGain]:
        """
        get_head_position_pid_gains()
        
        Get head position PID gains.
        
        Returns
        -------
        PIDGain
            Head position PID gains.
        """
    def get_last_log(self, count: int) -> list[Log]:
        """
        get_last_log(count)
        
        Get last log entries.
        
        Parameters
        ----------
        count : int
            Number of log entries to retrieve.
        
        Returns
        -------
        list
            List of log entries.
        """
    def get_left_arm_position_pid_gains(self) -> list[PIDGain]:
        """
        get_left_arm_position_pid_gains()
        
        Get left arm position PID gains.
        
        Returns
        -------
        PIDGain
            Left arm position PID gains.
        """
    def get_parameter(self, name: str) -> str:
        """
        get_parameter(name)
        
        Retrieve a robot parameter.
        
        Parameters
        ----------
        name : str
            Name of the parameter to retrieve.
        
        Returns
        -------
        any
            Parameter value.
            Returned as a JSON value: numeric values are returned as-is, strings are enclosed in quotes ("...").
        
        Examples
        --------
        >>> # Retrieve current parameter values
        >>> acc_scaling = robot.get_parameter("default.acceleration_limit_scaling")
        >>> cutoff_freq = robot.get_parameter("joint_position_command.cutoff_frequency")
        >>> model_name = robot.get_parameter("robot_model_name")
        >>> print(f"Acceleration scaling: {acc_scaling}")
        >>> print(f"Cutoff frequency: {cutoff_freq}")
        >>> print(f"Model name: {model_name}")
        """
    def get_parameter_list(self) -> list[tuple[str, int]]:
        """
        get_parameter_list()
        
        Get list of available parameters.
        
        Returns
        -------
        list
            List of parameter names.
        
        Examples
        --------
        >>> # Get all available parameters
        >>> param_list = robot.get_parameter_list()
        >>> print(f"Total parameters: {len(param_list)}")
        >>> # List common parameter categories
        >>> for param in param_list:
        ...     if param[0].startswith("default."):
        ...         print(f"Default param: {param}")
        ...     elif param[0].startswith("joint_position_command."):
        ...         print(f"Joint position param: {param}")
        >>> # Common categories: default.*, joint_position_command.*, cartesian_command.*
        """
    def get_position_pid_gain(self, dev_name: str) -> PIDGain:
        """
        get_position_pid_gain(dev_name)
        
        Get position PID gains for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name.
        
        Returns
        -------
        PIDGain
            Position PID gains for the device.
        
        Examples
        --------
        >>> # Get PID gains for specific device
        >>> torso_pid = robot.get_position_pid_gain("torso_5")
        >>> print(f"Torso 5 P: {torso_pid.p_gain}, I: {torso_pid.i_gain}, D: {torso_pid.d_gain}")
        >>> # Get PID gains for arm
        >>> arm_pid = robot.get_position_pid_gain("right_arm_0")
        >>> print(f"Right arm 0 P: {arm_pid.p_gain}")
        >>> devices = ["torso_5", "right_arm_0", "left_arm_1", "head_0"]
        >>> for device in devices:
        ...     pid = robot.get_position_pid_gain(device)
        ...     print(f"{device}: P={pid.p_gain}, I={pid.i_gain}, D={pid.d_gain}")
        """
    def get_right_arm_position_pid_gains(self) -> list[PIDGain]:
        """
        get_right_arm_position_pid_gains()
        
        Get right arm position PID gains.
        
        Returns
        -------
        PIDGain
            Right arm position PID gains.
        """
    def get_robot_info(self) -> RobotInfo:
        """
        get_robot_info()
        
        Retrieves static information about the robot, such as model name, SDK version, and joint configuration.
        
        Returns
        -------
        RobotInfo
            Structured metadata including joint details, device names, and robot model information.
        
        Examples
        --------
        >>> # Get robot information
        >>> robot_info = robot.get_robot_info()
        >>> print(f"SDK version: {robot_info.sdk_version}")
        >>> print(f"Robot model name: {robot_info.robot_model_name}")
        >>> print(f"Robot model version: {robot_info.robot_model_version}")
        >>> print(f"Joint count: {len(robot_info.joint_infos)}")
        >>> # Access joint information
        >>> for joint in robot_info.joint_infos:
        ...     print(f"Joint: {joint.name}, Brake: {joint.has_brake}, Product name: {joint.product_name}, Firmware version: {joint.firmware_version}")
        """
    def get_robot_model(self) -> str:
        """
        get_robot_model()
        
        Get the current robot model.
        
        Returns
        -------
        RobotModel
            Current robot model.
        """
    def get_serial_device_list(self) -> list[SerialDevice]:
        """
        get_serial_device_list()
        
        Get list of available serial devices on the robot.
        
        Returns
        -------
        list
            List of available serial devices.
        
        Examples
        --------
        >>> # Get available serial devices
        >>> devices = robot.get_serial_device_list()
        >>> print(f"Found {len(devices)} serial devices")
        >>> # List device information
        >>> for device in devices:
        ...     print(f"Path: {device.path}, Description: {device.description}")
        >>> # Open serial stream to first device
        >>> if devices:
        ...     stream = robot.open_serial_stream(devices[0].path, 115200)
        >>> # Common device paths: /dev/ttyUSB0, /dev/ttyACM0, COM1, COM2
        """
    def get_state(self) -> RobotState_M:
        """
        get_state()
        
        Get current robot state.
        
        Returns
        -------
        RobotState
            Current robot state.
        
        Examples
        --------
        >>> robot_state = robot.get_state()
        >>> model = robot.model()
        >>> print(f"Joint positions: {robot_state.position}")
        >>> print(f"Right arm position: {robot_state.position[model.right_arm_idx]}")
        >>> # Note: Joint positions include mobile base (2-DOF) + torso (6-DOF) + right arm (7-DOF) + left arm (7-DOF) + head (2-DOF)
        >>> # Total: 24 DOF for model A, 23 DOF for model M, 26 DOF for model M, 18 DOF for model UB
        """
    def get_system_time(self) -> tuple[typing.Any, str]:
        """
        Get robot system time.
        
        Returns
        -------
        tuple
            (datetime, str): Robot system time and local time string.
        """
    def get_time_scale(self) -> float:
        """
        get_time_scale()
        
        Get the current time scale.
        
        Returns
        -------
        float
            Current time scale value.
        
        Examples
        --------
        >>> # Get current time scale
        >>> current_scale = robot.get_time_scale()
        >>> print(f"Current time scale: {current_scale}")
        >>> # Check if robot is running at full speed
        >>> if current_scale == 1.0:
        ...     print("Robot running at full speed")
        >>> # Check if robot is slowed down
        >>> elif current_scale < 1.0:
        ...     print(f"Robot running at {current_scale * 100}% speed")
        """
    def get_torso_position_pid_gains(self) -> list[PIDGain]:
        """
        get_torso_position_pid_gains()
        
        Get torso position PID gains.
        
        Returns
        -------
        PIDGain
            Torso position PID gains.
        
        Examples
        --------
        >>> # Get current PID gains for torso
        >>> torso_pid = robot.get_torso_position_pid_gains()[0]  # Get first (and only) torso device
        >>> print(f"Torso P: {torso_pid.p_gain}, I: {torso_pid.i_gain}, D: {torso_pid.d_gain}")
        >>> right_arm_pid = robot.get_right_arm_position_pid_gains()[0]
        >>> print(f"Right arm: {right_arm_pid}")
        """
    def get_wifi_status(self) -> WifiStatus | None:
        """
        get_wifi_status()
        
        Get WiFi connection status.
        
        Returns
        -------
        WifiStatus
            Current WiFi status.
        """
    def has_established_time_sync(self) -> bool:
        """
        Check if time synchronization is established.
        
        Returns
        -------
        bool
            True if time sync is established, False otherwise.
        """
    def home_offset_reset(self, dev_name: str) -> bool:
        """
        home_offset_reset(dev_name)
        
        Reset home offset for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name to reset home offset. Supports regex patterns.
        """
    def import_robot_model(self, name: str, model: str) -> bool:
        """
        import_robot_model(name, model)
        
        Import a robot model.
        
        Parameters
        ----------
        name : str
            Model name.
        model : RobotModel
            Robot model to import.
        """
    def is_connected(self) -> bool:
        """
        is_connected()
        
        Checks whether the robot is currently connected.
        
        Returns
        -------
        bool
            ``True`` if the robot is connected to the robot, ``False`` otherwise.
        """
    def is_power_on(self, dev_name: str) -> bool:
        """
        is_power_on(dev_name)
        
        Check if a device is powered on.
        
        Parameters
        ----------
        dev_name : str
            Device name to check. Supports regex patterns.
        
        Returns
        -------
        bool
            ``True`` if device is powered on, ``False`` otherwise.
        """
    def is_servo_on(self, dev_name: str) -> bool:
        """
        is_servo_on(dev_name)
        
        Check if servo control is enabled for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name to check. Supports regex patterns.
        
        Returns
        -------
        bool
            ``True`` if servo control is enabled, ``False`` otherwise.
        """
    def open_serial_stream(self, device_path: str, baudrate: int, bytesize: int = 8, parity: str = 'N', stopbits: int = 1) -> SerialStream:
        """
        open_serial_stream(device_path, baudrate, bytesize=8, parity='N', stopbits=1)
        
        Open a serial stream.
        
        Parameters
        ----------
        device_path : str
            Path to serial device.
        baudrate : int
            Baud rate.
        bytesize : int, optional
            Data bits. Default is 8.
        parity : str, optional
            Parity setting. Default is 'N'.
        stopbits : int, optional
            Stop bits. Default is 1.
        
        Returns
        -------
        SerialStream
            Serial stream object.
        
        Examples
        --------
        >>> # Open serial stream with default settings
        >>> stream = robot.open_serial_stream("/dev/ttyUSB0", 115200)
        >>> # Open with custom settings
        >>> stream = robot.open_serial_stream("/dev/ttyUSB1", 9600, bytesize=7, parity='E', stopbits=2)
        >>> # Common baudrates: 9600, 19200, 38400, 57600, 115200
        >>> # Parity: 'N' (none), 'E' (even), 'O' (odd)
        >>> # Stop bits: 1, 2
        """
    def power_off(self, dev_name: str) -> bool:
        """
        power_off(dev_name)
        
        Power off a device.
        
        Parameters
        ----------
        dev_name : str
            Device name to power off. Supports regex patterns.
        """
    def power_on(self, dev_name: str) -> bool:
        """
        power_on(dev_name)
        
        Power on a device.
        
        Parameters
        ----------
        dev_name : str
            Device name to power on. Supports regex patterns.
        
        Examples
        --------
        >>> robot.connect()
        >>> if not robot.is_power_on(".*"):
        ...     robot.power_on(".*")
        ...     print("Robot powered on")
        >>> # Pattern ".*" powers on all devices
        >>> # Specific device: robot.power_on("12v"), robot.power_on("24v"), etc.
        """
    def reset_all_parameters(self) -> None:
        """
        reset_all_parameters()
        
        Reset all parameters to their current values.
        """
    def reset_all_parameters_to_default(self) -> None:
        """
        reset_all_parameters_to_default()
        
        Reset all parameters to their default values (deprecated).
        
        .. deprecated:: 0.6.0
           Use :meth:`factory_reset_all_parameters` instead.
        
        Note
        ----
        This method is deprecated. Use factory_reset_all_parameters() instead.
        """
    def reset_battery_config(self) -> bool:
        """
        reset_battery_config()
        
        Reset battery configuration to default.
        """
    def reset_fault_control_manager(self) -> bool:
        """
        reset_fault_control_manager()
        
        Reset fault in the control manager.
        """
    def reset_network_setting(self) -> bool:
        """
        reset_network_setting()
        
        Reset network settings to default.
        """
    def reset_odometry(self, angle: float, position: numpy.ndarray[tuple[typing.Literal[2], typing.Literal[1]], numpy.dtype[numpy.float64]]) -> bool:
        """
        reset_odometry(angle, position)
        
        Reset odometry to specified values.
        
        Parameters
        ----------
        angle : float
            New angle in rad.
        position : numpy.ndarray
            New position in meters.
        
        Examples
        --------
        >>> import numpy as np
        >>> # Reset odometry to origin
        >>> robot.reset_odometry(angle=0.0, position=np.array([0.0, 0.0]))
        >>> # Reset to specific position and orientation
        >>> robot.reset_odometry(angle=np.pi/2, position=np.array([1.0, 2.0]))
        >>> # Useful for mobile base navigation
        >>> # Position is [x, y] in meters, angle is yaw in rad
        """
    def reset_parameter(self, name: str) -> bool:
        """
        reset_parameter(name)
        
        Reset a parameter to its current value.
        
        Parameters
        ----------
        name : str
            Parameter name.
        """
    def reset_parameter_to_default(self, name: str) -> bool:
        """
        reset_parameter_to_default(name)
        
        Reset a parameter to its default value (deprecated).
        
        Parameters
        ----------
        name : str
            Parameter name.
        
        .. deprecated:: 0.6.0
           Use :meth:`factory_reset_parameter` instead.
        
        Note
        ----
        This method is deprecated. Use factory_reset_parameter() instead.
        """
    def scan_wifi(self) -> list[WifiNetwork]:
        """
        scan_wifi()
        
        Scan for available WiFi networks.
        
        Returns
        -------
        list
            List of available WiFi networks.
        
        Examples
        --------
        >>> # Scan for available WiFi networks
        >>> networks = robot.scan_wifi()
        >>> print(f"Found {len(networks)} networks")
        >>> # List network information
        >>> for network in networks:
        ...     print(f"SSID: {network.ssid}, Signal: {network.signal_strength}")
        >>> # Connect to a network
        >>> if networks:
        ...     robot.connect_wifi(networks[0].ssid, "password")
        """
    def send_command(self, builder: RobotCommandBuilder, priority: int = 1) -> Robot_M_CommandHandler:
        """
        send_command(builder, priority=1)
        
        Send a command to the robot.
        
        Parameters
        ----------
        builder : CommandBuilder
            Command builder to send.
        priority : int, optional
            Command priority. Default is 1.
        
        Returns
        -------
        RobotCommandHandler
            Command handler for monitoring execution.
        
        Examples
        --------
        >>> from rby1_sdk import RobotCommandBuilder, ComponentBasedCommandBuilder
        >>> from rby1_sdk import BodyComponentBasedCommandBuilder, JointPositionCommandBuilder
        >>> # Create command with method chaining (standard pattern)
        >>> command = RobotCommandBuilder().set_command(
        ...     ComponentBasedCommandBuilder().set_body_command(
        ...         BodyComponentBasedCommandBuilder()
        ...             .set_torso_command(
        ...                 JointPositionCommandBuilder()
        ...                     .set_position([0, 0, 0, 0, 0, 0])  # 6-DOF torso
        ...                     .set_minimum_time(2.0)
        ...             )
        ...     )
        ... )
        >>> handler = robot.send_command(command)
        >>> handler.wait()  # Wait for completion
        >>> # This pattern is used in most examples: examples/python/07_impedance_control.py, 09_demo_motion.py, etc.
        """
    def servo_off(self, dev_name: str) -> bool:
        """
        servo_off(dev_name)
        
        Disable servo control for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name to disable servo control. Supports regex patterns.
        
        Examples
        --------
        >>> # Disable servo control for safety
        >>> robot.servo_off(".*")  # All motor drivers
        >>> # Specific device: robot.servo_off("^torso_.*")
        """
    def servo_on(self, dev_name: str) -> bool:
        """
        servo_on(dev_name)
        
        Enable servo control for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name to enable servo control. Supports regex patterns.
        
        Examples
        --------
        >>> robot.connect()
        >>> if not robot.is_servo_on(".*"):
        ...     robot.servo_on(".*")  # Servo on all devices
        ...     print("All devices servoed on")
        >>> # Specific device: robot.servo_on("^torso_.*"), robot.servo_on("^right_arm_.*"), etc.
        """
    def set_battery_config(self, cutoff_voltage: float, fully_charged_voltage: float, coefficients: typing.Annotated[list[float], pybind11_stubgen.typing_ext.FixedSize(4)]) -> bool:
        """
        set_battery_config(cutoff_voltage, fully_charged_voltage, coefficients)
                   
        Set battery configuration.
        """
    def set_battery_level(self, arg0: float) -> bool:
        """
        Set battery level.
        
        Parameters
        ----------
        level : float
            Battery level percentage (0.0 to 100.0).
        
        Examples
        --------
        >>> # Set battery level for testing
        >>> robot.set_battery_level(100.0)  # Full battery
        >>> robot.set_battery_level(50.0)   # Half battery
        >>> robot.set_battery_level(25.0)   # Quarter battery
        >>> robot.set_battery_level(0.0)    # Empty battery
        >>> # Range: 0.0 to 100.0
        >>> # Useful for using custom battery
        """
    def set_led_color(self, color: Color, duration: float = 1, transition_time: float = 0, blinking: bool = False, blinking_freq: float = 1) -> bool:
        """
        set_led_color(color, duration=1.0, transition_time=0.0, blinking=False, blinking_freq=1.0)
        
        Set LED color.
        
        Parameters
        ----------
        color : Color
            LED color.
        duration : float, optional
            Duration in seconds. Default is 1.
        transition_time : float, optional
            Transition time in seconds. Default is 0.
        blinking : bool, optional
            Whether to blink. Default is False.
        blinking_freq : float, optional
            Blinking frequency in Hz. Default is 1.
        
        Examples
        --------
        >>> from rby1_sdk import Color
        >>> # Set LED to red for 5 seconds
        >>> robot.set_led_color(Color(255, 0, 0), duration=5.0)
        >>> # Set LED to green with 1 second transition
        >>> robot.set_led_color(Color(0, 255, 0), transition_time=1.0)
        >>> # Set LED to blue with blinking
        >>> robot.set_led_color(Color(0, 0, 255), blinking=True, blinking_freq=2.0)
        >>> # Set LED to white with custom duration and transition
        >>> robot.set_led_color(Color(255, 255, 255), duration=10.0, transition_time=2.0)
        """
    def set_parameter(self, name: str, value: str, write_db: bool = True) -> bool:
        """
        set_parameter(name, value, write_db=True)
        
        Set a robot parameter.
        
        Parameters
        ----------
        name : str
            Parameter name.
        value : any
            Parameter value.
        write_db : bool, optional
            Whether to write to database. Default is True.
        
        Examples
        --------
        >>> # Set acceleration limit scaling
        >>> robot.set_parameter("default.acceleration_limit_scaling", "0.8")
        >>> # Set joint position command cutoff frequency
        >>> robot.set_parameter("joint_position_command.cutoff_frequency", "5")
        >>> # Set hotspot SSID name
        >>> robot.set_parameter("hotspot.ssid", "\\"RBY1_HOTSPOT\\"") # For str value, use escaped quotes
        >>> # Set without writing to database (Return ``False`` if matching parameter not found)
        >>> robot.set_parameter("temp.parameter", "value", write_db=False)
        False
        """
    def set_position_d_gain(self, dev_name: str, d_gain: int) -> bool:
        """
        set_position_d_gain(dev_name, d_gain)
        
        Set position D gain for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name.
        d_gain : int
            D gain value.
        
        Examples
        --------
        >>> # Set D gain for specific devices
        >>> robot.set_position_d_gain("torso_5", 400)
        """
    def set_position_i_gain(self, dev_name: str, i_gain: int) -> bool:
        """
        set_position_i_gain(dev_name, i_gain)
        
        Set position I gain for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name.
        i_gain : int
            I gain value.
        
        Examples
        --------
        >>> # Set I gain for specific devices
        >>> robot.set_position_i_gain("torso_5", 40)
        """
    def set_position_p_gain(self, dev_name: str, p_gain: int) -> bool:
        """
        set_position_p_gain(dev_name, p_gain)
        
        Set position P gain for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name.
        p_gain : int
            P gain value.
        
        Examples
        --------
        >>> # Set P gain for specific devices
        >>> robot.set_position_p_gain("torso_5", 220)
        """
    @typing.overload
    def set_position_pid_gain(self, dev_name: str, p_gain: int, i_gain: int, d_gain: int) -> bool:
        """
        set_position_pid_gain(dev_name, p_gain, i_gain, d_gain)
        
        Set position PID gains for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name.
        p_gain : int
            P gain value.
        i_gain : int
            I gain value.
        d_gain : int
            D gain value.
        
        Examples
        --------
        >>> # Set all PID gains at once for a device
        >>> robot.set_position_pid_gain("right_arm_0", 80, 15, 200)
        >>> robot.set_position_pid_gain("right_arm_1", 80, 15, 200)
        >>> robot.set_position_pid_gain("right_arm_2", 80, 15, 200)
        >>> robot.set_position_pid_gain("right_arm_3", 35, 5, 80)
        >>> robot.set_position_pid_gain("right_arm_4", 30, 5, 70)
        >>> robot.set_position_pid_gain("right_arm_5", 30, 5, 70)
        >>> robot.set_position_pid_gain("right_arm_6", 100, 5, 120)
        """
    @typing.overload
    def set_position_pid_gain(self, dev_name: str, pid_gain: PIDGain) -> bool:
        """
        set_position_pid_gain(dev_name, pid_gain)
        
        Set position PID gains for a device using PIDGain object.
        
        Parameters
        ----------
        dev_name : str
            Device name.
        pid_gain : PIDGain
            PID gain object.
        """
    def set_preset_position(self, joint_name: str) -> bool:
        """
        set_preset_position(joint_name)
        
        Set preset position for a joint (only available for PVL-based motors).
        
        Parameters
        ----------
        joint_name : str
            Joint name to set preset position.
        
        Examples
        --------
        >>> # Set preset position for specific joints
        >>> robot.set_preset_position("right_arm_6")  # Right arm joint 6
        >>> # Preset position is used as reference for home offset
        """
    @typing.overload
    def set_system_time(self, datetime: typing.Any) -> bool:
        """
        set_system_time(datetime)
        
        Set robot system time.
        
        Parameters
        ----------
        datetime : datetime.datetime
            New system time.
        """
    @typing.overload
    def set_system_time(self, datetime: typing.Any, time_zone: str) -> bool:
        """
        set_system_time(datetime, time_zone)
        
        Set robot system time with timezone.
        
        Parameters
        ----------
        datetime : datetime.datetime
            New system time.
        time_zone : str
            Timezone string.
        """
    def set_time_scale(self, time_scale: float) -> float:
        """
        set_time_scale(time_scale)
        
        Set the time scale for motion execution.
        
        Parameters
        ----------
        time_scale : float
            Time scale value (0.0 to 1.0).
        
        Examples
        --------
        >>> # Set time scale for motion execution
        >>> robot.set_time_scale(1.0)   # Normal speed (100%)
        >>> robot.set_time_scale(0.5)   # Half speed (50%)
        >>> robot.set_time_scale(0.25)  # Quarter speed (25%)
        >>> # Range: 0.0 (stopped) to 1.0 (full speed)
        >>> # Useful for testing and safety
        """
    def set_tool_flange_digital_output(self, name: str, channel: int, state: bool) -> bool:
        """
        set_tool_flange_digital_output(name, channel, state)
        
        Set the digital output state of a specific channel on the tool flange
        of the specified arm.
        
        Parameters
        ----------
        name : str
            Arm identifier. Must be either `"right"` or `"left"`,
            indicating the tool flange of the right or left arm.
        channel : int
            Digital output channel index.
        state : bool
            Desired state of the digital output (``True`` = ON, ``False`` = OFF).
        
        Returns
        -------
        bool
            ``True`` if the command was successfully sent, ``False`` otherwise.
        
        Examples
        --------
        >>> # Turn on channel 0 on the right arm tool flange
        >>> robot.set_tool_flange_digital_output("right", 0, True)
        """
    def set_tool_flange_digital_output_dual(self, name: str, state_0: bool, state_1: bool) -> bool:
        """
        set_tool_flange_digital_output_dual(name, state_0, state_1)
        
        Set the digital output states of two channels on the tool flange
        of the specified arm simultaneously.
        
        Parameters
        ----------
        name : str
            Arm identifier. Must be either `"right"` or `"left"`,
            indicating the tool flange of the right or left arm.
        state_0 : bool
            Desired state for digital output channel 0 (True = ON, False = OFF).
        state_1 : bool
            Desired state for digital output channel 1 (True = ON, False = OFF).
        
        Returns
        -------
        bool
            ``True`` if the command was successfully sent, ``False`` otherwise.
        
        Examples
        --------
        >>> # Turn on channel 0 and turn off channel 1 on the left arm tool flange
        >>> robot.set_tool_flange_digital_output_dual("left", True, False)
        """
    def set_tool_flange_output_voltage(self, name: str, voltage: int) -> bool:
        """
        set_tool_flange_output_voltage(name, voltage)
        
        Set tool flange output voltage.
        
        Parameters
        ----------
        name : str
            Tool flange name `"right"` or `"left"`.
        
        voltage : int
            Output voltage in volts.
        
        Examples
        --------
        >>> # Set tool flange output voltage
        >>> robot.set_tool_flange_output_voltage("right", 12)  # 12V output
        >>> robot.set_tool_flange_output_voltage("left", 24)  # 24V output
        >>> # Common voltages: 12V, 24V
        >>> # Use 0V to turn off output
        >>> # Note: This method sets voltage for both tool flanges (right and left)
        """
    def start_log_stream(self, cb: typing.Callable[[list[Log]], None], rate: float) -> None:
        """
        start_log_stream(cb, rate)
                
        Start log stream callback.
        
        Parameters
        ----------
        cb : callable
            Callback function for log updates.
        rate : float
            Update rate in Hz.
        
        Examples
        --------
        >>> def log_callback(log_entries):
        ...     for log in log_entries:
        ...         print(f"{log.timestamp} - {log.level} - {log.message}")
        >>> # Start log stream at 10 Hz
        >>> robot.start_log_stream(log_callback, 10.0)
        >>> # Stop when done: robot.stop_log_stream()
        """
    def start_state_update(self, cb: typing.Callable, rate: float) -> None:
        """
        start_state_update(cb, rate)
        
        Start state update callback.
        
        Parameters
        ----------
        cb : callable
            Callback function with 1 or 2 parameters:
            - cb(robot_state) or cb(robot_state, control_manager_state)
        rate : float
            Update rate in Hz.
        
        Examples
        --------
        >>> def state_callback(robot_state):
        ...     print(f"Timestamp: {robot_state.timestamp}, Joint positions: {robot_state.position}")
        >>> # Start state updates at 100 Hz
        >>> robot.start_state_update(state_callback, 100.0)
        >>> # Stop when done: robot.stop_state_update()
        """
    def start_time_sync(self, period_sec: int) -> bool:
        """
        start_time_sync(period_sec)
        
        Start time synchronization.
        
        Parameters
        ----------
        period_sec : float
            Synchronization period in seconds.
        """
    def stop_log_stream(self) -> None:
        """
        stop_log_stream()
        
        Stop log stream callback.
        """
    def stop_state_update(self) -> None:
        """
        stop_state_update()
        
        Stop state update callback.
        """
    def stop_time_sync(self) -> bool:
        """
        stop_time_sync()
        
        Stop time synchronization.
        """
    def sync_time(self) -> bool:
        """
        sync_time()
        
        Synchronizes the timestamp of ``RobotState`` to UPC time instead of UTC. 
        Useful when synchronizing multiple devices to UPC time.
        """
    def wait_for_control_ready(self, timeout_ms: int) -> bool:
        """
        wait_for_control_ready(timeout_ms)
        
        Wait until the robot is ready to accept control commands.
        
        Parameters
        ----------
        timeout_ms : int
            Timeout in milliseconds.
        
        Returns
        -------
        bool
            ``True`` if the robot is ready to accept control (you can now set control).
            ``False`` if the timeout expired before the robot became ready.
        
        Examples
        --------
        >>> # Wait for control to be ready
        >>> if robot.wait_for_control_ready(timeout_ms=5000):
        ...     print("Control is ready, you can now set control commands.")
        ... else:
        ...     print("Timeout: control is not ready.")
        >>> # Call after servo_on() and before sending control commands
        """
class Robot_M_CommandHandler:
    """
    
    Robot command handler.
    
    Handles robot command execution and provides status monitoring.
    
    Attributes
    ----------
    is_done : bool
        Whether the command execution is complete.
    """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    def cancel(self) -> None:
        """
        cancel()
        
        Cancel the command execution.
        """
    def get(self) -> RobotCommandFeedback:
        """
        get()
        
        Wait for the command execution and get feedback
        
        Returns
        -------
        RobotCommandFeedback
            Current feedback information.
        """
    def get_status(self) -> bool:
        """
        get_status()
        
        Get gRPC status
        """
    def is_done(self) -> bool:
        """
        Check if the command execution is complete.
        
        Returns
        -------
        bool
            ``True`` if command is complete, ``False`` otherwise.
        """
    def wait(self) -> None:
        """
        wait()
        
        Wait for the command execution to complete.
        
        This method blocks until the command is done or cancelled.
        """
    def wait_for(self, timeout_ms: int) -> bool:
        """
        wait_for(timeout_ms)
        
        Wait for the command execution with timeout.
        
        Parameters
        ----------
        timeout_ms : int
            Timeout in milliseconds.
        
        Returns
        -------
        bool
            ``True`` if command completed, ``False`` if timeout.
        """
class Robot_M_CommandStreamHandler:
    """
    
    Robot command stream handler.
    
    Handles robot command execution through streaming with send and feedback capabilities.
    
    Attributes
    ----------
    is_done : bool
        Whether the command execution is complete.
    """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    def cancel(self) -> None:
        """
        cancel()
        
        Cancel the current command execution.
        """
    def is_done(self) -> bool:
        """
        Check if the command execution is complete.
        
        Returns
        -------
        bool
            True if command is complete, False otherwise.
        """
    def request_feedback(self, timeout_ms: int = 1000) -> RobotCommandFeedback:
        """
        request_feedback(timeout_ms)
        
        Request feedback from the robot.
        
        Parameters
        ----------
        timeout_ms : int, optional
            Timeout in milliseconds. Default is 1000.
        
        Returns
        -------
        RobotCommandFeedback
            Current feedback information.
        """
    def send_command(self, builder: RobotCommandBuilder, timeout_ms: int = 1000) -> RobotCommandFeedback:
        """
        send_command(builder, timeout_ms=1000)
        
        Send a command through the stream.
        
        Parameters
        ----------
        builder : CommandBuilder
            Command builder to send.
        timeout_ms : int, optional
            Timeout in milliseconds. Default is 1000.
        
        Returns
        -------
        RobotCommandFeedback
            Current feedback information.
        """
    def wait(self) -> None:
        ...
    def wait_for(self, timeout_ms: int) -> bool:
        """
        Wait for the command execution to complete.
        
        This method blocks until the command is done or cancelled.
        """
class Robot_M_ControlInput:
    """
    
    Robot control input.
    
    Represents control input parameters for robot real-time control including mode, target, and gains.
    
    Attributes
    ----------
    mode : numpy.ndarray
        Control mode for each joint (boolean array).
    target : numpy.ndarray
        Target positions for each joint in rad.
    feedback_gain : numpy.ndarray
        Feedback gains for each joint.
    feedforward_torque : numpy.ndarray
        Feedforward torque for each joint in Nm.
    finish : bool
        Whether to finish the current control operation.
    """
    def __init__(self) -> None:
        """
        Construct a ``ControlInput`` instance.
        """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    @property
    def feedback_gain(self) -> numpy.ndarray[tuple[typing.Literal[26], typing.Literal[1]], numpy.dtype[numpy.uint32]]:
        """
        Feedback gains for each joint.
        
        Type
        ----
        numpy.ndarray
            Feedback gain values for each joint.
        """
    @feedback_gain.setter
    def feedback_gain(self, arg1: numpy.ndarray[tuple[typing.Literal[26], typing.Literal[1]], numpy.dtype[numpy.uint32]]) -> None:
        ...
    @property
    def feedforward_torque(self) -> numpy.ndarray[tuple[typing.Literal[26], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        """
        Feedforward torque for each joint.
        
        Type
        ----
        numpy.ndarray
            Feedforward torque values in Nm for each joint.
        """
    @feedforward_torque.setter
    def feedforward_torque(self, arg1: numpy.ndarray[tuple[typing.Literal[26], typing.Literal[1]], numpy.dtype[numpy.float64]]) -> None:
        ...
    @property
    def finish(self) -> bool:
        """
        Finish control operation flag.
        
        Type
        ----
        bool
            Whether to finish the current control operation.
        """
    @finish.setter
    def finish(self, arg0: bool) -> None:
        ...
    @property
    def mode(self) -> numpy.ndarray[tuple[typing.Literal[26], typing.Literal[1]], numpy.dtype[numpy.bool_]]:
        """
        Control mode for each joint.
        
        Type
        ----
        numpy.ndarray
            Boolean array indicating control mode for each joint.
        """
    @mode.setter
    def mode(self, arg1: numpy.ndarray[tuple[typing.Literal[26], typing.Literal[1]], numpy.dtype[numpy.bool_]]) -> None:
        ...
    @property
    def target(self) -> numpy.ndarray[tuple[typing.Literal[26], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        """
        Target positions for each joint.
        
        Type
        ----
        numpy.ndarray
            Target positions in rad for each joint.
        """
    @target.setter
    def target(self, arg1: numpy.ndarray[tuple[typing.Literal[26], typing.Literal[1]], numpy.dtype[numpy.float64]]) -> None:
        ...
class Robot_M_ControlState:
    """
    
    Robot control state.
    
    Represents the current state of robot real-time control including position, velocity, and torque.
    
    Attributes
    ----------
    t : float
        Current time in seconds.
    is_ready : numpy.ndarray
        Whether the joint is ready for control.
    position : numpy.ndarray
        Current joint positions in rad.
    velocity : numpy.ndarray
        Current joint velocities in rad/s.
    current : numpy.ndarray
        Current joint currents in A.
    torque : numpy.ndarray
        Current joint torques in Nm.
    """
    def __init__(self) -> None:
        """
        Construct a ControlState instance.
        """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    @property
    def current(self) -> numpy.ndarray[tuple[typing.Literal[26], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        """
        Joint currents.
        
        Type
        ----
        numpy.ndarray
            Current joint currents in A.
        """
    @property
    def is_ready(self) -> numpy.ndarray[tuple[typing.Literal[26], typing.Literal[1]], numpy.dtype[numpy.bool_]]:
        """
        Robot readiness status.
        
        Type
        ----
        bool
            Whether the robot is ready for control.
        """
    @property
    def position(self) -> numpy.ndarray[tuple[typing.Literal[26], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        """
        Joint positions.
        
        Type
        ----
        numpy.ndarray
            Current joint positions in rad.
        """
    @property
    def t(self) -> float:
        """
        Current time.
        
        Type
        ----
        float
            Current time in seconds.
        """
    @property
    def torque(self) -> numpy.ndarray[tuple[typing.Literal[26], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        """
        Joint torques.
        
        Type
        ----
        numpy.ndarray
            Current joint torques in Nm.
        """
    @property
    def velocity(self) -> numpy.ndarray[tuple[typing.Literal[26], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        """
        Joint velocities.
        
        Type
        ----
        numpy.ndarray
            Current joint velocities in rad/s.
        """
class Robot_T5:
    """
    
    Robot control interface.
    
    Provides high-level control interface for robot operations including
    connection management, power control, and command execution.
    
    Attributes
    ----------
    model : PyModel
        Robot model configuration.
    """
    @staticmethod
    def create(address: str) -> Robot_T5:
        """
        create(address)
        
        Create a robot instance.
        
        Parameters
        ----------
        address : str
            Robot network address, e.g. "192.168.1.100:50051".
        
        Returns
        -------
        Robot
            Robot instance.
        
        Examples
        --------
        >>> import rby1_sdk
        >>> robot = rby.Robot_A.create("192.168.30.1:50051")
        >>> robot.connect()
        >>> if robot.is_connected():
        ...     print("Robot connected successfully")
        ...     robot_info = robot.get_robot_info()
        ...     print(f"Robot model: {robot.model().model_name}")
        ...     # Note: Model A has mobile base (2-DOF) + torso (6-DOF) + right arm (7-DOF) + left arm (7-DOF) + head (2-DOF)
        ...     # Total joints: 2 + 6 + 7 + 7 + 2 = 24 DOF for model A
        """
    @staticmethod
    def model() -> Model_T5:
        """
        model()
        
        Get the robot model configuration.
        
        Returns
        -------
        PyModel
            Robot model configuration object.
        """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    def break_engage(self, dev_name: str) -> bool:
        """
        break_engage(dev_name)
        
        Engage the brake for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name (joint name) to engage brake. Supports regex patterns.
        
        Examples
        --------
        >>> # Engage brake for manitance
        >>> robot.break_engage("right_arm_0")
        """
    def break_release(self, dev_name: str) -> bool:
        """
        break_release(dev_name)
        
        Release the brake for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name (joint name) to release brake. Supports regex patterns.
        
        Examples
        --------
        >>> # Release brake to allow movement
        >>> robot.break_release("right_arm_0")
        """
    def cancel_control(self) -> bool:
        """
        cancel_control()
        
        Cancel current control operation.
        """
    def connect(self, max_retries: int = 5, timeout_ms: int = 1000) -> bool:
        """
        connect(max_retries=5, timeout_ms=1000)
        
        Attempts to establish a connection with the robot.
        
        Parameters
        ----------
        max_retries : int, optional
            Maximum number of retries to connect. Default is 5.
        timeout_ms : int, optional
            Timeout in milliseconds for each connection attempt. Default is 1000.
        
        Returns
        -------
        bool
            ``True`` if the connection was successful, ``False`` otherwise.
        
        Examples
        --------
        >>> robot = rby1_sdk.create_robot("192.168.1.100", "a")
        >>> if robot.connect():
        ...     print("Connected to robot")
        ... else:
        ...     print("Failed to connect")
        >>> # Default: max_retries=5, timeout_ms=1000
        >>> # Custom: robot.connect(max_retries=10, timeout_ms=2000)
        """
    def connect_wifi(self, ssid: str, password: str = '', use_dhcp: bool = True, ip_address: str = '', gateway: str = '', dns: list[str] = []) -> bool:
        """
        connect_wifi(ssid, password='', use_dhcp=True, ip_address='', gateway='', dns=[])
        
        Connect to WiFi network.
        
        Parameters
        ----------
        ssid : str
            WiFi network name.
        password : str, optional
            WiFi password. Default is empty string.
        use_dhcp : bool, optional
            Use DHCP. Default is True.
        ip_address : str, optional
            Static IP address. Default is empty string.
        gateway : str, optional
            Gateway address. Default is empty string.
        dns : list[str], optional
            DNS servers. Default is empty string.
        
        Examples
        --------
        >>> # Connect using DHCP (automatic IP)
        >>> robot.connect_wifi("MyWiFi", "mypassword123")
        >>> # Connect with static IP configuration
        >>> robot.connect_wifi("MyWiFi", "mypassword123", use_dhcp=False,
        ...                    ip_address="192.168.1.100/24", gateway="192.168.1.1")
        >>> # Connect to open network
        >>> robot.connect_wifi("OpenNetwork")
        >>> # Check connection status
        >>> status = robot.get_wifi_status()
        >>> print(f"Connected: {status.connected}, SSID: {status.ssid}")
        """
    def control(self, control: typing.Callable[[Robot_T5_ControlState], Robot_T5_ControlInput], port: int = 0, priority: int = 1) -> bool:
        """
        control(control, port=0, priority=1)
        
        Start a **blocking** real-time control loop using a custom control callback.
        
        This function runs a UDP-based real-time loop that repeatedly calls the user-provided
        ``control(ControlState) -> ControlInput``. The loop exits when the callback returns a
        ``ControlInput`` with ``finish=True``, or when an error/abort occurs. The function
        returns ``True`` only if it finished via ``finish=True``; otherwise ``False``.
        
        Parameters
        ----------
        control : callable
            A callable that accepts a ``ControlState`` and returns a ``ControlInput``.
            The callback is invoked for each received RT state packet.
        port : int, optional
            UDP port to bind for the RT server. Use ``0`` to let the OS choose an available port
            (recommended). Default is ``0``.
        priority : int, optional
            Command priority sent with the RT control request. Default is ``1``.
        
        Returns
        -------
        bool
            ``True`` if the loop terminated because the callback set ``finish=True`` in
            ``ControlInput``. ``False`` if the loop ended due to an error or abort
            (e.g., UDP bind failure, connection issue).
        
        Notes
        -----
        - **Blocking:** This call blocks until the control loop ends. There is no handler for
          external cancellation. Design the callback to set ``finish=True`` when you want to stop.
        - **GIL behavior:** The function releases the Python GIL around I/O and reacquires it
          only when invoking your Python callback, allowing other Python threads to run between
          callbacks.
        - **Performance:** Keep the callback lightweight—avoid long computations or blocking I/O
          inside the callback to maintain RT responsiveness.
        - **State fields:** The provided ``ControlState`` includes timestamp ``t``, and arrays 
          such as ``position``, ``velocity``, ``current``, and ``torque`` for all DoFs of the robot.
        - **Errors:** If the UDP server fails to bind (e.g., port unavailable), the function
          returns ``False`` immediately (and prints the error to ``stderr``).
        
        Examples
        --------
        >>> import numpy as np
        >>> 
        >>> # Stop after ~2 seconds using state.t
        >>> t0 = {"t": None}
        >>> def control_fn(state):
        ...     if t0["t"] is None:
        ...         t0["t"] = state.t
        ...     finish = (state.t - t0["t"]) >= 2.0
        ...     i = ControlInput()
        ...     i.mode.fill(rby.ControlMode.Position)
        ...     i.target = np.zeros_like(state.position)   # hold home
        ...     i.feedback_gain.fill(10)                   # simple P gain
        ...     i.feedforward_torque.fill(0)               # no torque feedforward
        ...     i.finish = finish
        ...     return i
        >>> ok = robot.control(control_fn)
        >>> print(ok)   # True if finished via finish=True
        """
    def create_command_stream(self, priority: int = 1) -> Robot_T5_CommandStreamHandler:
        """
        create_command_stream(priority=1)
        
        Create a command stream for continuous command sending.
        
        Parameters
        ----------
        priority : int, optional
            Command priority. Default is 1.
        
        Returns
        -------
        RobotCommandStreamHandler
            Command stream handler.
        
        Examples
        --------
        >>> # Create command stream for continuous operation
        >>> stream_handler = robot.create_command_stream(priority=1)
        >>> # Send commands continuously
        >>> for i in range(10):
        ...     command_builder = create_command(i)
        ...     stream_handler.send_command(command_builder, timeout_ms=1000)
        ...     time.sleep(1)
        >>> # Through the handler, you can terminate control or check the current state
        >>> stream_handler.cancel()
        >>> # See examples/python/cartesian_command_stream.py for complete usage
        """
    def disable_control_manager(self) -> bool:
        """
        disable_control_manager()
        
        Disable the control manager.
        """
    def disconnect(self) -> None:
        """
        disconnect()
        
        Disconnects from the robot.
        """
    def disconnect_wifi(self) -> bool:
        """
        disconnect_wifi()
        
        Disconnect from WiFi network.
        """
    def download_file(self, path: str, file_like: typing.Any) -> bool:
        """
        download_file(path, file_like)
        
        Downloads a file from the robot and writes it into a file-like object.
        
        Parameters
        ----------
        path : str
            Relative path to the file on the robot's file system.
            The base directory is defined by the `RBY1_HOME` environment variable (default: `/root/.rby1`).
        file_like : file-like object
            Any object with a `.write(bytes)` method (e.g., `io.BytesIO`, a real file).
        
        Returns
        -------
        bool
            ``True`` if the file was downloaded successfully.
        
        Raises
        ------
        RuntimeError
            If the gRPC call fails (e.g., network issue, file not found, internal error).
        """
    def enable_control_manager(self, unlimited_mode_enabled: bool = False) -> bool:
        """
        Enable the control manager.
        
        Parameters
        ----------
        unlimited_mode_enabled : bool, optional
            Whether to enable unlimited mode. Default is False.
        
        Examples
        --------
        >>> # Enable control manager for robot control
        >>> robot.enable_control_manager()
        >>> # Enable with unlimited mode (use with caution)
        >>> robot.enable_control_manager(unlimited_mode_enabled=True)
        >>> # Must be called before sending commands
        """
    def factory_reset_all_parameters(self) -> None:
        """
        factory_reset_all_parameters()
        
        Factory reset all parameters to their default values.
        """
    def factory_reset_parameter(self, name: str) -> bool:
        """
        factory_reset_parameter(name)
        
        Factory reset a parameter to its default value.
        
        Parameters
        ----------
        name : str
            Parameter name.
        """
    def get_control_manager_state(self) -> ControlManagerState:
        """
        get_control_manager_state()
        
        Get control manager state.
        
        Returns
        -------
        ControlManagerState
            Current control manager state.
        
        Examples
        --------
        >>> # Get control manager state
        >>> ctrl_state = robot.get_control_manager_state()
        >>> print(f"Control Manager state: {ctrl_state.state}")
        >>> print(f"Control state: {ctrl_state.control_state}")
        >>> # Check if control manager is enabled
        >>> if ctrl_state.state == rby1_sdk.ControlManagerState.State.Enabled:
        ...     print("Control manager is enabled")
        """
    def get_dynamics(self, urdf_model: str = '') -> dynamics.Robot_23:
        """
        get_dynamics(urdf_model='')
        
        Get robot dynamics model.
        
        Parameters
        ----------
        urdf_model : str, optional
            URDF model path. Default is empty string.
        
        Returns
        -------
        dyn.Robot
            Robot dynamics model.
        
        Examples
        --------
        >>> # Get dynamics model with the model from connected robot
        >>> dynamics_robot = robot.get_dynamics()
        >>> # Get dynamics model with custom URDF
        >>> dynamics_robot = robot.get_dynamics("/path/to/custom.urdf")
        >>> # Useful for advanced control algorithms
        """
    def get_fault_log_list(self) -> list[str]:
        """
        get_fault_log_list()
        
        Get fault log list.
        
        Returns
        -------
        list
            List of fault log entries.
        """
    def get_head_position_pid_gains(self) -> list[PIDGain]:
        """
        get_head_position_pid_gains()
        
        Get head position PID gains.
        
        Returns
        -------
        PIDGain
            Head position PID gains.
        """
    def get_last_log(self, count: int) -> list[Log]:
        """
        get_last_log(count)
        
        Get last log entries.
        
        Parameters
        ----------
        count : int
            Number of log entries to retrieve.
        
        Returns
        -------
        list
            List of log entries.
        """
    def get_left_arm_position_pid_gains(self) -> list[PIDGain]:
        """
        get_left_arm_position_pid_gains()
        
        Get left arm position PID gains.
        
        Returns
        -------
        PIDGain
            Left arm position PID gains.
        """
    def get_parameter(self, name: str) -> str:
        """
        get_parameter(name)
        
        Retrieve a robot parameter.
        
        Parameters
        ----------
        name : str
            Name of the parameter to retrieve.
        
        Returns
        -------
        any
            Parameter value.
            Returned as a JSON value: numeric values are returned as-is, strings are enclosed in quotes ("...").
        
        Examples
        --------
        >>> # Retrieve current parameter values
        >>> acc_scaling = robot.get_parameter("default.acceleration_limit_scaling")
        >>> cutoff_freq = robot.get_parameter("joint_position_command.cutoff_frequency")
        >>> model_name = robot.get_parameter("robot_model_name")
        >>> print(f"Acceleration scaling: {acc_scaling}")
        >>> print(f"Cutoff frequency: {cutoff_freq}")
        >>> print(f"Model name: {model_name}")
        """
    def get_parameter_list(self) -> list[tuple[str, int]]:
        """
        get_parameter_list()
        
        Get list of available parameters.
        
        Returns
        -------
        list
            List of parameter names.
        
        Examples
        --------
        >>> # Get all available parameters
        >>> param_list = robot.get_parameter_list()
        >>> print(f"Total parameters: {len(param_list)}")
        >>> # List common parameter categories
        >>> for param in param_list:
        ...     if param[0].startswith("default."):
        ...         print(f"Default param: {param}")
        ...     elif param[0].startswith("joint_position_command."):
        ...         print(f"Joint position param: {param}")
        >>> # Common categories: default.*, joint_position_command.*, cartesian_command.*
        """
    def get_position_pid_gain(self, dev_name: str) -> PIDGain:
        """
        get_position_pid_gain(dev_name)
        
        Get position PID gains for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name.
        
        Returns
        -------
        PIDGain
            Position PID gains for the device.
        
        Examples
        --------
        >>> # Get PID gains for specific device
        >>> torso_pid = robot.get_position_pid_gain("torso_5")
        >>> print(f"Torso 5 P: {torso_pid.p_gain}, I: {torso_pid.i_gain}, D: {torso_pid.d_gain}")
        >>> # Get PID gains for arm
        >>> arm_pid = robot.get_position_pid_gain("right_arm_0")
        >>> print(f"Right arm 0 P: {arm_pid.p_gain}")
        >>> devices = ["torso_5", "right_arm_0", "left_arm_1", "head_0"]
        >>> for device in devices:
        ...     pid = robot.get_position_pid_gain(device)
        ...     print(f"{device}: P={pid.p_gain}, I={pid.i_gain}, D={pid.d_gain}")
        """
    def get_right_arm_position_pid_gains(self) -> list[PIDGain]:
        """
        get_right_arm_position_pid_gains()
        
        Get right arm position PID gains.
        
        Returns
        -------
        PIDGain
            Right arm position PID gains.
        """
    def get_robot_info(self) -> RobotInfo:
        """
        get_robot_info()
        
        Retrieves static information about the robot, such as model name, SDK version, and joint configuration.
        
        Returns
        -------
        RobotInfo
            Structured metadata including joint details, device names, and robot model information.
        
        Examples
        --------
        >>> # Get robot information
        >>> robot_info = robot.get_robot_info()
        >>> print(f"SDK version: {robot_info.sdk_version}")
        >>> print(f"Robot model name: {robot_info.robot_model_name}")
        >>> print(f"Robot model version: {robot_info.robot_model_version}")
        >>> print(f"Joint count: {len(robot_info.joint_infos)}")
        >>> # Access joint information
        >>> for joint in robot_info.joint_infos:
        ...     print(f"Joint: {joint.name}, Brake: {joint.has_brake}, Product name: {joint.product_name}, Firmware version: {joint.firmware_version}")
        """
    def get_robot_model(self) -> str:
        """
        get_robot_model()
        
        Get the current robot model.
        
        Returns
        -------
        RobotModel
            Current robot model.
        """
    def get_serial_device_list(self) -> list[SerialDevice]:
        """
        get_serial_device_list()
        
        Get list of available serial devices on the robot.
        
        Returns
        -------
        list
            List of available serial devices.
        
        Examples
        --------
        >>> # Get available serial devices
        >>> devices = robot.get_serial_device_list()
        >>> print(f"Found {len(devices)} serial devices")
        >>> # List device information
        >>> for device in devices:
        ...     print(f"Path: {device.path}, Description: {device.description}")
        >>> # Open serial stream to first device
        >>> if devices:
        ...     stream = robot.open_serial_stream(devices[0].path, 115200)
        >>> # Common device paths: /dev/ttyUSB0, /dev/ttyACM0, COM1, COM2
        """
    def get_state(self) -> RobotState_T5:
        """
        get_state()
        
        Get current robot state.
        
        Returns
        -------
        RobotState
            Current robot state.
        
        Examples
        --------
        >>> robot_state = robot.get_state()
        >>> model = robot.model()
        >>> print(f"Joint positions: {robot_state.position}")
        >>> print(f"Right arm position: {robot_state.position[model.right_arm_idx]}")
        >>> # Note: Joint positions include mobile base (2-DOF) + torso (6-DOF) + right arm (7-DOF) + left arm (7-DOF) + head (2-DOF)
        >>> # Total: 24 DOF for model A, 23 DOF for model M, 26 DOF for model M, 18 DOF for model UB
        """
    def get_system_time(self) -> tuple[typing.Any, str]:
        """
        Get robot system time.
        
        Returns
        -------
        tuple
            (datetime, str): Robot system time and local time string.
        """
    def get_time_scale(self) -> float:
        """
        get_time_scale()
        
        Get the current time scale.
        
        Returns
        -------
        float
            Current time scale value.
        
        Examples
        --------
        >>> # Get current time scale
        >>> current_scale = robot.get_time_scale()
        >>> print(f"Current time scale: {current_scale}")
        >>> # Check if robot is running at full speed
        >>> if current_scale == 1.0:
        ...     print("Robot running at full speed")
        >>> # Check if robot is slowed down
        >>> elif current_scale < 1.0:
        ...     print(f"Robot running at {current_scale * 100}% speed")
        """
    def get_torso_position_pid_gains(self) -> list[PIDGain]:
        """
        get_torso_position_pid_gains()
        
        Get torso position PID gains.
        
        Returns
        -------
        PIDGain
            Torso position PID gains.
        
        Examples
        --------
        >>> # Get current PID gains for torso
        >>> torso_pid = robot.get_torso_position_pid_gains()[0]  # Get first (and only) torso device
        >>> print(f"Torso P: {torso_pid.p_gain}, I: {torso_pid.i_gain}, D: {torso_pid.d_gain}")
        >>> right_arm_pid = robot.get_right_arm_position_pid_gains()[0]
        >>> print(f"Right arm: {right_arm_pid}")
        """
    def get_wifi_status(self) -> WifiStatus | None:
        """
        get_wifi_status()
        
        Get WiFi connection status.
        
        Returns
        -------
        WifiStatus
            Current WiFi status.
        """
    def has_established_time_sync(self) -> bool:
        """
        Check if time synchronization is established.
        
        Returns
        -------
        bool
            True if time sync is established, False otherwise.
        """
    def home_offset_reset(self, dev_name: str) -> bool:
        """
        home_offset_reset(dev_name)
        
        Reset home offset for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name to reset home offset. Supports regex patterns.
        """
    def import_robot_model(self, name: str, model: str) -> bool:
        """
        import_robot_model(name, model)
        
        Import a robot model.
        
        Parameters
        ----------
        name : str
            Model name.
        model : RobotModel
            Robot model to import.
        """
    def is_connected(self) -> bool:
        """
        is_connected()
        
        Checks whether the robot is currently connected.
        
        Returns
        -------
        bool
            ``True`` if the robot is connected to the robot, ``False`` otherwise.
        """
    def is_power_on(self, dev_name: str) -> bool:
        """
        is_power_on(dev_name)
        
        Check if a device is powered on.
        
        Parameters
        ----------
        dev_name : str
            Device name to check. Supports regex patterns.
        
        Returns
        -------
        bool
            ``True`` if device is powered on, ``False`` otherwise.
        """
    def is_servo_on(self, dev_name: str) -> bool:
        """
        is_servo_on(dev_name)
        
        Check if servo control is enabled for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name to check. Supports regex patterns.
        
        Returns
        -------
        bool
            ``True`` if servo control is enabled, ``False`` otherwise.
        """
    def open_serial_stream(self, device_path: str, baudrate: int, bytesize: int = 8, parity: str = 'N', stopbits: int = 1) -> SerialStream:
        """
        open_serial_stream(device_path, baudrate, bytesize=8, parity='N', stopbits=1)
        
        Open a serial stream.
        
        Parameters
        ----------
        device_path : str
            Path to serial device.
        baudrate : int
            Baud rate.
        bytesize : int, optional
            Data bits. Default is 8.
        parity : str, optional
            Parity setting. Default is 'N'.
        stopbits : int, optional
            Stop bits. Default is 1.
        
        Returns
        -------
        SerialStream
            Serial stream object.
        
        Examples
        --------
        >>> # Open serial stream with default settings
        >>> stream = robot.open_serial_stream("/dev/ttyUSB0", 115200)
        >>> # Open with custom settings
        >>> stream = robot.open_serial_stream("/dev/ttyUSB1", 9600, bytesize=7, parity='E', stopbits=2)
        >>> # Common baudrates: 9600, 19200, 38400, 57600, 115200
        >>> # Parity: 'N' (none), 'E' (even), 'O' (odd)
        >>> # Stop bits: 1, 2
        """
    def power_off(self, dev_name: str) -> bool:
        """
        power_off(dev_name)
        
        Power off a device.
        
        Parameters
        ----------
        dev_name : str
            Device name to power off. Supports regex patterns.
        """
    def power_on(self, dev_name: str) -> bool:
        """
        power_on(dev_name)
        
        Power on a device.
        
        Parameters
        ----------
        dev_name : str
            Device name to power on. Supports regex patterns.
        
        Examples
        --------
        >>> robot.connect()
        >>> if not robot.is_power_on(".*"):
        ...     robot.power_on(".*")
        ...     print("Robot powered on")
        >>> # Pattern ".*" powers on all devices
        >>> # Specific device: robot.power_on("12v"), robot.power_on("24v"), etc.
        """
    def reset_all_parameters(self) -> None:
        """
        reset_all_parameters()
        
        Reset all parameters to their current values.
        """
    def reset_all_parameters_to_default(self) -> None:
        """
        reset_all_parameters_to_default()
        
        Reset all parameters to their default values (deprecated).
        
        .. deprecated:: 0.6.0
           Use :meth:`factory_reset_all_parameters` instead.
        
        Note
        ----
        This method is deprecated. Use factory_reset_all_parameters() instead.
        """
    def reset_battery_config(self) -> bool:
        """
        reset_battery_config()
        
        Reset battery configuration to default.
        """
    def reset_fault_control_manager(self) -> bool:
        """
        reset_fault_control_manager()
        
        Reset fault in the control manager.
        """
    def reset_network_setting(self) -> bool:
        """
        reset_network_setting()
        
        Reset network settings to default.
        """
    def reset_odometry(self, angle: float, position: numpy.ndarray[tuple[typing.Literal[2], typing.Literal[1]], numpy.dtype[numpy.float64]]) -> bool:
        """
        reset_odometry(angle, position)
        
        Reset odometry to specified values.
        
        Parameters
        ----------
        angle : float
            New angle in rad.
        position : numpy.ndarray
            New position in meters.
        
        Examples
        --------
        >>> import numpy as np
        >>> # Reset odometry to origin
        >>> robot.reset_odometry(angle=0.0, position=np.array([0.0, 0.0]))
        >>> # Reset to specific position and orientation
        >>> robot.reset_odometry(angle=np.pi/2, position=np.array([1.0, 2.0]))
        >>> # Useful for mobile base navigation
        >>> # Position is [x, y] in meters, angle is yaw in rad
        """
    def reset_parameter(self, name: str) -> bool:
        """
        reset_parameter(name)
        
        Reset a parameter to its current value.
        
        Parameters
        ----------
        name : str
            Parameter name.
        """
    def reset_parameter_to_default(self, name: str) -> bool:
        """
        reset_parameter_to_default(name)
        
        Reset a parameter to its default value (deprecated).
        
        Parameters
        ----------
        name : str
            Parameter name.
        
        .. deprecated:: 0.6.0
           Use :meth:`factory_reset_parameter` instead.
        
        Note
        ----
        This method is deprecated. Use factory_reset_parameter() instead.
        """
    def scan_wifi(self) -> list[WifiNetwork]:
        """
        scan_wifi()
        
        Scan for available WiFi networks.
        
        Returns
        -------
        list
            List of available WiFi networks.
        
        Examples
        --------
        >>> # Scan for available WiFi networks
        >>> networks = robot.scan_wifi()
        >>> print(f"Found {len(networks)} networks")
        >>> # List network information
        >>> for network in networks:
        ...     print(f"SSID: {network.ssid}, Signal: {network.signal_strength}")
        >>> # Connect to a network
        >>> if networks:
        ...     robot.connect_wifi(networks[0].ssid, "password")
        """
    def send_command(self, builder: RobotCommandBuilder, priority: int = 1) -> Robot_T5_CommandHandler:
        """
        send_command(builder, priority=1)
        
        Send a command to the robot.
        
        Parameters
        ----------
        builder : CommandBuilder
            Command builder to send.
        priority : int, optional
            Command priority. Default is 1.
        
        Returns
        -------
        RobotCommandHandler
            Command handler for monitoring execution.
        
        Examples
        --------
        >>> from rby1_sdk import RobotCommandBuilder, ComponentBasedCommandBuilder
        >>> from rby1_sdk import BodyComponentBasedCommandBuilder, JointPositionCommandBuilder
        >>> # Create command with method chaining (standard pattern)
        >>> command = RobotCommandBuilder().set_command(
        ...     ComponentBasedCommandBuilder().set_body_command(
        ...         BodyComponentBasedCommandBuilder()
        ...             .set_torso_command(
        ...                 JointPositionCommandBuilder()
        ...                     .set_position([0, 0, 0, 0, 0, 0])  # 6-DOF torso
        ...                     .set_minimum_time(2.0)
        ...             )
        ...     )
        ... )
        >>> handler = robot.send_command(command)
        >>> handler.wait()  # Wait for completion
        >>> # This pattern is used in most examples: examples/python/07_impedance_control.py, 09_demo_motion.py, etc.
        """
    def servo_off(self, dev_name: str) -> bool:
        """
        servo_off(dev_name)
        
        Disable servo control for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name to disable servo control. Supports regex patterns.
        
        Examples
        --------
        >>> # Disable servo control for safety
        >>> robot.servo_off(".*")  # All motor drivers
        >>> # Specific device: robot.servo_off("^torso_.*")
        """
    def servo_on(self, dev_name: str) -> bool:
        """
        servo_on(dev_name)
        
        Enable servo control for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name to enable servo control. Supports regex patterns.
        
        Examples
        --------
        >>> robot.connect()
        >>> if not robot.is_servo_on(".*"):
        ...     robot.servo_on(".*")  # Servo on all devices
        ...     print("All devices servoed on")
        >>> # Specific device: robot.servo_on("^torso_.*"), robot.servo_on("^right_arm_.*"), etc.
        """
    def set_battery_config(self, cutoff_voltage: float, fully_charged_voltage: float, coefficients: typing.Annotated[list[float], pybind11_stubgen.typing_ext.FixedSize(4)]) -> bool:
        """
        set_battery_config(cutoff_voltage, fully_charged_voltage, coefficients)
                   
        Set battery configuration.
        """
    def set_battery_level(self, arg0: float) -> bool:
        """
        Set battery level.
        
        Parameters
        ----------
        level : float
            Battery level percentage (0.0 to 100.0).
        
        Examples
        --------
        >>> # Set battery level for testing
        >>> robot.set_battery_level(100.0)  # Full battery
        >>> robot.set_battery_level(50.0)   # Half battery
        >>> robot.set_battery_level(25.0)   # Quarter battery
        >>> robot.set_battery_level(0.0)    # Empty battery
        >>> # Range: 0.0 to 100.0
        >>> # Useful for using custom battery
        """
    def set_led_color(self, color: Color, duration: float = 1, transition_time: float = 0, blinking: bool = False, blinking_freq: float = 1) -> bool:
        """
        set_led_color(color, duration=1.0, transition_time=0.0, blinking=False, blinking_freq=1.0)
        
        Set LED color.
        
        Parameters
        ----------
        color : Color
            LED color.
        duration : float, optional
            Duration in seconds. Default is 1.
        transition_time : float, optional
            Transition time in seconds. Default is 0.
        blinking : bool, optional
            Whether to blink. Default is False.
        blinking_freq : float, optional
            Blinking frequency in Hz. Default is 1.
        
        Examples
        --------
        >>> from rby1_sdk import Color
        >>> # Set LED to red for 5 seconds
        >>> robot.set_led_color(Color(255, 0, 0), duration=5.0)
        >>> # Set LED to green with 1 second transition
        >>> robot.set_led_color(Color(0, 255, 0), transition_time=1.0)
        >>> # Set LED to blue with blinking
        >>> robot.set_led_color(Color(0, 0, 255), blinking=True, blinking_freq=2.0)
        >>> # Set LED to white with custom duration and transition
        >>> robot.set_led_color(Color(255, 255, 255), duration=10.0, transition_time=2.0)
        """
    def set_parameter(self, name: str, value: str, write_db: bool = True) -> bool:
        """
        set_parameter(name, value, write_db=True)
        
        Set a robot parameter.
        
        Parameters
        ----------
        name : str
            Parameter name.
        value : any
            Parameter value.
        write_db : bool, optional
            Whether to write to database. Default is True.
        
        Examples
        --------
        >>> # Set acceleration limit scaling
        >>> robot.set_parameter("default.acceleration_limit_scaling", "0.8")
        >>> # Set joint position command cutoff frequency
        >>> robot.set_parameter("joint_position_command.cutoff_frequency", "5")
        >>> # Set hotspot SSID name
        >>> robot.set_parameter("hotspot.ssid", "\\"RBY1_HOTSPOT\\"") # For str value, use escaped quotes
        >>> # Set without writing to database (Return ``False`` if matching parameter not found)
        >>> robot.set_parameter("temp.parameter", "value", write_db=False)
        False
        """
    def set_position_d_gain(self, dev_name: str, d_gain: int) -> bool:
        """
        set_position_d_gain(dev_name, d_gain)
        
        Set position D gain for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name.
        d_gain : int
            D gain value.
        
        Examples
        --------
        >>> # Set D gain for specific devices
        >>> robot.set_position_d_gain("torso_5", 400)
        """
    def set_position_i_gain(self, dev_name: str, i_gain: int) -> bool:
        """
        set_position_i_gain(dev_name, i_gain)
        
        Set position I gain for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name.
        i_gain : int
            I gain value.
        
        Examples
        --------
        >>> # Set I gain for specific devices
        >>> robot.set_position_i_gain("torso_5", 40)
        """
    def set_position_p_gain(self, dev_name: str, p_gain: int) -> bool:
        """
        set_position_p_gain(dev_name, p_gain)
        
        Set position P gain for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name.
        p_gain : int
            P gain value.
        
        Examples
        --------
        >>> # Set P gain for specific devices
        >>> robot.set_position_p_gain("torso_5", 220)
        """
    @typing.overload
    def set_position_pid_gain(self, dev_name: str, p_gain: int, i_gain: int, d_gain: int) -> bool:
        """
        set_position_pid_gain(dev_name, p_gain, i_gain, d_gain)
        
        Set position PID gains for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name.
        p_gain : int
            P gain value.
        i_gain : int
            I gain value.
        d_gain : int
            D gain value.
        
        Examples
        --------
        >>> # Set all PID gains at once for a device
        >>> robot.set_position_pid_gain("right_arm_0", 80, 15, 200)
        >>> robot.set_position_pid_gain("right_arm_1", 80, 15, 200)
        >>> robot.set_position_pid_gain("right_arm_2", 80, 15, 200)
        >>> robot.set_position_pid_gain("right_arm_3", 35, 5, 80)
        >>> robot.set_position_pid_gain("right_arm_4", 30, 5, 70)
        >>> robot.set_position_pid_gain("right_arm_5", 30, 5, 70)
        >>> robot.set_position_pid_gain("right_arm_6", 100, 5, 120)
        """
    @typing.overload
    def set_position_pid_gain(self, dev_name: str, pid_gain: PIDGain) -> bool:
        """
        set_position_pid_gain(dev_name, pid_gain)
        
        Set position PID gains for a device using PIDGain object.
        
        Parameters
        ----------
        dev_name : str
            Device name.
        pid_gain : PIDGain
            PID gain object.
        """
    def set_preset_position(self, joint_name: str) -> bool:
        """
        set_preset_position(joint_name)
        
        Set preset position for a joint (only available for PVL-based motors).
        
        Parameters
        ----------
        joint_name : str
            Joint name to set preset position.
        
        Examples
        --------
        >>> # Set preset position for specific joints
        >>> robot.set_preset_position("right_arm_6")  # Right arm joint 6
        >>> # Preset position is used as reference for home offset
        """
    @typing.overload
    def set_system_time(self, datetime: typing.Any) -> bool:
        """
        set_system_time(datetime)
        
        Set robot system time.
        
        Parameters
        ----------
        datetime : datetime.datetime
            New system time.
        """
    @typing.overload
    def set_system_time(self, datetime: typing.Any, time_zone: str) -> bool:
        """
        set_system_time(datetime, time_zone)
        
        Set robot system time with timezone.
        
        Parameters
        ----------
        datetime : datetime.datetime
            New system time.
        time_zone : str
            Timezone string.
        """
    def set_time_scale(self, time_scale: float) -> float:
        """
        set_time_scale(time_scale)
        
        Set the time scale for motion execution.
        
        Parameters
        ----------
        time_scale : float
            Time scale value (0.0 to 1.0).
        
        Examples
        --------
        >>> # Set time scale for motion execution
        >>> robot.set_time_scale(1.0)   # Normal speed (100%)
        >>> robot.set_time_scale(0.5)   # Half speed (50%)
        >>> robot.set_time_scale(0.25)  # Quarter speed (25%)
        >>> # Range: 0.0 (stopped) to 1.0 (full speed)
        >>> # Useful for testing and safety
        """
    def set_tool_flange_digital_output(self, name: str, channel: int, state: bool) -> bool:
        """
        set_tool_flange_digital_output(name, channel, state)
        
        Set the digital output state of a specific channel on the tool flange
        of the specified arm.
        
        Parameters
        ----------
        name : str
            Arm identifier. Must be either `"right"` or `"left"`,
            indicating the tool flange of the right or left arm.
        channel : int
            Digital output channel index.
        state : bool
            Desired state of the digital output (``True`` = ON, ``False`` = OFF).
        
        Returns
        -------
        bool
            ``True`` if the command was successfully sent, ``False`` otherwise.
        
        Examples
        --------
        >>> # Turn on channel 0 on the right arm tool flange
        >>> robot.set_tool_flange_digital_output("right", 0, True)
        """
    def set_tool_flange_digital_output_dual(self, name: str, state_0: bool, state_1: bool) -> bool:
        """
        set_tool_flange_digital_output_dual(name, state_0, state_1)
        
        Set the digital output states of two channels on the tool flange
        of the specified arm simultaneously.
        
        Parameters
        ----------
        name : str
            Arm identifier. Must be either `"right"` or `"left"`,
            indicating the tool flange of the right or left arm.
        state_0 : bool
            Desired state for digital output channel 0 (True = ON, False = OFF).
        state_1 : bool
            Desired state for digital output channel 1 (True = ON, False = OFF).
        
        Returns
        -------
        bool
            ``True`` if the command was successfully sent, ``False`` otherwise.
        
        Examples
        --------
        >>> # Turn on channel 0 and turn off channel 1 on the left arm tool flange
        >>> robot.set_tool_flange_digital_output_dual("left", True, False)
        """
    def set_tool_flange_output_voltage(self, name: str, voltage: int) -> bool:
        """
        set_tool_flange_output_voltage(name, voltage)
        
        Set tool flange output voltage.
        
        Parameters
        ----------
        name : str
            Tool flange name `"right"` or `"left"`.
        
        voltage : int
            Output voltage in volts.
        
        Examples
        --------
        >>> # Set tool flange output voltage
        >>> robot.set_tool_flange_output_voltage("right", 12)  # 12V output
        >>> robot.set_tool_flange_output_voltage("left", 24)  # 24V output
        >>> # Common voltages: 12V, 24V
        >>> # Use 0V to turn off output
        >>> # Note: This method sets voltage for both tool flanges (right and left)
        """
    def start_log_stream(self, cb: typing.Callable[[list[Log]], None], rate: float) -> None:
        """
        start_log_stream(cb, rate)
                
        Start log stream callback.
        
        Parameters
        ----------
        cb : callable
            Callback function for log updates.
        rate : float
            Update rate in Hz.
        
        Examples
        --------
        >>> def log_callback(log_entries):
        ...     for log in log_entries:
        ...         print(f"{log.timestamp} - {log.level} - {log.message}")
        >>> # Start log stream at 10 Hz
        >>> robot.start_log_stream(log_callback, 10.0)
        >>> # Stop when done: robot.stop_log_stream()
        """
    def start_state_update(self, cb: typing.Callable, rate: float) -> None:
        """
        start_state_update(cb, rate)
        
        Start state update callback.
        
        Parameters
        ----------
        cb : callable
            Callback function with 1 or 2 parameters:
            - cb(robot_state) or cb(robot_state, control_manager_state)
        rate : float
            Update rate in Hz.
        
        Examples
        --------
        >>> def state_callback(robot_state):
        ...     print(f"Timestamp: {robot_state.timestamp}, Joint positions: {robot_state.position}")
        >>> # Start state updates at 100 Hz
        >>> robot.start_state_update(state_callback, 100.0)
        >>> # Stop when done: robot.stop_state_update()
        """
    def start_time_sync(self, period_sec: int) -> bool:
        """
        start_time_sync(period_sec)
        
        Start time synchronization.
        
        Parameters
        ----------
        period_sec : float
            Synchronization period in seconds.
        """
    def stop_log_stream(self) -> None:
        """
        stop_log_stream()
        
        Stop log stream callback.
        """
    def stop_state_update(self) -> None:
        """
        stop_state_update()
        
        Stop state update callback.
        """
    def stop_time_sync(self) -> bool:
        """
        stop_time_sync()
        
        Stop time synchronization.
        """
    def sync_time(self) -> bool:
        """
        sync_time()
        
        Synchronizes the timestamp of ``RobotState`` to UPC time instead of UTC. 
        Useful when synchronizing multiple devices to UPC time.
        """
    def wait_for_control_ready(self, timeout_ms: int) -> bool:
        """
        wait_for_control_ready(timeout_ms)
        
        Wait until the robot is ready to accept control commands.
        
        Parameters
        ----------
        timeout_ms : int
            Timeout in milliseconds.
        
        Returns
        -------
        bool
            ``True`` if the robot is ready to accept control (you can now set control).
            ``False`` if the timeout expired before the robot became ready.
        
        Examples
        --------
        >>> # Wait for control to be ready
        >>> if robot.wait_for_control_ready(timeout_ms=5000):
        ...     print("Control is ready, you can now set control commands.")
        ... else:
        ...     print("Timeout: control is not ready.")
        >>> # Call after servo_on() and before sending control commands
        """
class Robot_T5_CommandHandler:
    """
    
    Robot command handler.
    
    Handles robot command execution and provides status monitoring.
    
    Attributes
    ----------
    is_done : bool
        Whether the command execution is complete.
    """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    def cancel(self) -> None:
        """
        cancel()
        
        Cancel the command execution.
        """
    def get(self) -> RobotCommandFeedback:
        """
        get()
        
        Wait for the command execution and get feedback
        
        Returns
        -------
        RobotCommandFeedback
            Current feedback information.
        """
    def get_status(self) -> bool:
        """
        get_status()
        
        Get gRPC status
        """
    def is_done(self) -> bool:
        """
        Check if the command execution is complete.
        
        Returns
        -------
        bool
            ``True`` if command is complete, ``False`` otherwise.
        """
    def wait(self) -> None:
        """
        wait()
        
        Wait for the command execution to complete.
        
        This method blocks until the command is done or cancelled.
        """
    def wait_for(self, timeout_ms: int) -> bool:
        """
        wait_for(timeout_ms)
        
        Wait for the command execution with timeout.
        
        Parameters
        ----------
        timeout_ms : int
            Timeout in milliseconds.
        
        Returns
        -------
        bool
            ``True`` if command completed, ``False`` if timeout.
        """
class Robot_T5_CommandStreamHandler:
    """
    
    Robot command stream handler.
    
    Handles robot command execution through streaming with send and feedback capabilities.
    
    Attributes
    ----------
    is_done : bool
        Whether the command execution is complete.
    """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    def cancel(self) -> None:
        """
        cancel()
        
        Cancel the current command execution.
        """
    def is_done(self) -> bool:
        """
        Check if the command execution is complete.
        
        Returns
        -------
        bool
            True if command is complete, False otherwise.
        """
    def request_feedback(self, timeout_ms: int = 1000) -> RobotCommandFeedback:
        """
        request_feedback(timeout_ms)
        
        Request feedback from the robot.
        
        Parameters
        ----------
        timeout_ms : int, optional
            Timeout in milliseconds. Default is 1000.
        
        Returns
        -------
        RobotCommandFeedback
            Current feedback information.
        """
    def send_command(self, builder: RobotCommandBuilder, timeout_ms: int = 1000) -> RobotCommandFeedback:
        """
        send_command(builder, timeout_ms=1000)
        
        Send a command through the stream.
        
        Parameters
        ----------
        builder : CommandBuilder
            Command builder to send.
        timeout_ms : int, optional
            Timeout in milliseconds. Default is 1000.
        
        Returns
        -------
        RobotCommandFeedback
            Current feedback information.
        """
    def wait(self) -> None:
        ...
    def wait_for(self, timeout_ms: int) -> bool:
        """
        Wait for the command execution to complete.
        
        This method blocks until the command is done or cancelled.
        """
class Robot_T5_ControlInput:
    """
    
    Robot control input.
    
    Represents control input parameters for robot real-time control including mode, target, and gains.
    
    Attributes
    ----------
    mode : numpy.ndarray
        Control mode for each joint (boolean array).
    target : numpy.ndarray
        Target positions for each joint in rad.
    feedback_gain : numpy.ndarray
        Feedback gains for each joint.
    feedforward_torque : numpy.ndarray
        Feedforward torque for each joint in Nm.
    finish : bool
        Whether to finish the current control operation.
    """
    def __init__(self) -> None:
        """
        Construct a ``ControlInput`` instance.
        """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    @property
    def feedback_gain(self) -> numpy.ndarray[tuple[typing.Literal[23], typing.Literal[1]], numpy.dtype[numpy.uint32]]:
        """
        Feedback gains for each joint.
        
        Type
        ----
        numpy.ndarray
            Feedback gain values for each joint.
        """
    @feedback_gain.setter
    def feedback_gain(self, arg1: numpy.ndarray[tuple[typing.Literal[23], typing.Literal[1]], numpy.dtype[numpy.uint32]]) -> None:
        ...
    @property
    def feedforward_torque(self) -> numpy.ndarray[tuple[typing.Literal[23], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        """
        Feedforward torque for each joint.
        
        Type
        ----
        numpy.ndarray
            Feedforward torque values in Nm for each joint.
        """
    @feedforward_torque.setter
    def feedforward_torque(self, arg1: numpy.ndarray[tuple[typing.Literal[23], typing.Literal[1]], numpy.dtype[numpy.float64]]) -> None:
        ...
    @property
    def finish(self) -> bool:
        """
        Finish control operation flag.
        
        Type
        ----
        bool
            Whether to finish the current control operation.
        """
    @finish.setter
    def finish(self, arg0: bool) -> None:
        ...
    @property
    def mode(self) -> numpy.ndarray[tuple[typing.Literal[23], typing.Literal[1]], numpy.dtype[numpy.bool_]]:
        """
        Control mode for each joint.
        
        Type
        ----
        numpy.ndarray
            Boolean array indicating control mode for each joint.
        """
    @mode.setter
    def mode(self, arg1: numpy.ndarray[tuple[typing.Literal[23], typing.Literal[1]], numpy.dtype[numpy.bool_]]) -> None:
        ...
    @property
    def target(self) -> numpy.ndarray[tuple[typing.Literal[23], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        """
        Target positions for each joint.
        
        Type
        ----
        numpy.ndarray
            Target positions in rad for each joint.
        """
    @target.setter
    def target(self, arg1: numpy.ndarray[tuple[typing.Literal[23], typing.Literal[1]], numpy.dtype[numpy.float64]]) -> None:
        ...
class Robot_T5_ControlState:
    """
    
    Robot control state.
    
    Represents the current state of robot real-time control including position, velocity, and torque.
    
    Attributes
    ----------
    t : float
        Current time in seconds.
    is_ready : numpy.ndarray
        Whether the joint is ready for control.
    position : numpy.ndarray
        Current joint positions in rad.
    velocity : numpy.ndarray
        Current joint velocities in rad/s.
    current : numpy.ndarray
        Current joint currents in A.
    torque : numpy.ndarray
        Current joint torques in Nm.
    """
    def __init__(self) -> None:
        """
        Construct a ControlState instance.
        """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    @property
    def current(self) -> numpy.ndarray[tuple[typing.Literal[23], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        """
        Joint currents.
        
        Type
        ----
        numpy.ndarray
            Current joint currents in A.
        """
    @property
    def is_ready(self) -> numpy.ndarray[tuple[typing.Literal[23], typing.Literal[1]], numpy.dtype[numpy.bool_]]:
        """
        Robot readiness status.
        
        Type
        ----
        bool
            Whether the robot is ready for control.
        """
    @property
    def position(self) -> numpy.ndarray[tuple[typing.Literal[23], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        """
        Joint positions.
        
        Type
        ----
        numpy.ndarray
            Current joint positions in rad.
        """
    @property
    def t(self) -> float:
        """
        Current time.
        
        Type
        ----
        float
            Current time in seconds.
        """
    @property
    def torque(self) -> numpy.ndarray[tuple[typing.Literal[23], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        """
        Joint torques.
        
        Type
        ----
        numpy.ndarray
            Current joint torques in Nm.
        """
    @property
    def velocity(self) -> numpy.ndarray[tuple[typing.Literal[23], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        """
        Joint velocities.
        
        Type
        ----
        numpy.ndarray
            Current joint velocities in rad/s.
        """
class Robot_UB:
    """
    
    Robot control interface.
    
    Provides high-level control interface for robot operations including
    connection management, power control, and command execution.
    
    Attributes
    ----------
    model : PyModel
        Robot model configuration.
    """
    @staticmethod
    def create(address: str) -> Robot_UB:
        """
        create(address)
        
        Create a robot instance.
        
        Parameters
        ----------
        address : str
            Robot network address, e.g. "192.168.1.100:50051".
        
        Returns
        -------
        Robot
            Robot instance.
        
        Examples
        --------
        >>> import rby1_sdk
        >>> robot = rby.Robot_A.create("192.168.30.1:50051")
        >>> robot.connect()
        >>> if robot.is_connected():
        ...     print("Robot connected successfully")
        ...     robot_info = robot.get_robot_info()
        ...     print(f"Robot model: {robot.model().model_name}")
        ...     # Note: Model A has mobile base (2-DOF) + torso (6-DOF) + right arm (7-DOF) + left arm (7-DOF) + head (2-DOF)
        ...     # Total joints: 2 + 6 + 7 + 7 + 2 = 24 DOF for model A
        """
    @staticmethod
    def model() -> Model_UB:
        """
        model()
        
        Get the robot model configuration.
        
        Returns
        -------
        PyModel
            Robot model configuration object.
        """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    def break_engage(self, dev_name: str) -> bool:
        """
        break_engage(dev_name)
        
        Engage the brake for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name (joint name) to engage brake. Supports regex patterns.
        
        Examples
        --------
        >>> # Engage brake for manitance
        >>> robot.break_engage("right_arm_0")
        """
    def break_release(self, dev_name: str) -> bool:
        """
        break_release(dev_name)
        
        Release the brake for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name (joint name) to release brake. Supports regex patterns.
        
        Examples
        --------
        >>> # Release brake to allow movement
        >>> robot.break_release("right_arm_0")
        """
    def cancel_control(self) -> bool:
        """
        cancel_control()
        
        Cancel current control operation.
        """
    def connect(self, max_retries: int = 5, timeout_ms: int = 1000) -> bool:
        """
        connect(max_retries=5, timeout_ms=1000)
        
        Attempts to establish a connection with the robot.
        
        Parameters
        ----------
        max_retries : int, optional
            Maximum number of retries to connect. Default is 5.
        timeout_ms : int, optional
            Timeout in milliseconds for each connection attempt. Default is 1000.
        
        Returns
        -------
        bool
            ``True`` if the connection was successful, ``False`` otherwise.
        
        Examples
        --------
        >>> robot = rby1_sdk.create_robot("192.168.1.100", "a")
        >>> if robot.connect():
        ...     print("Connected to robot")
        ... else:
        ...     print("Failed to connect")
        >>> # Default: max_retries=5, timeout_ms=1000
        >>> # Custom: robot.connect(max_retries=10, timeout_ms=2000)
        """
    def connect_wifi(self, ssid: str, password: str = '', use_dhcp: bool = True, ip_address: str = '', gateway: str = '', dns: list[str] = []) -> bool:
        """
        connect_wifi(ssid, password='', use_dhcp=True, ip_address='', gateway='', dns=[])
        
        Connect to WiFi network.
        
        Parameters
        ----------
        ssid : str
            WiFi network name.
        password : str, optional
            WiFi password. Default is empty string.
        use_dhcp : bool, optional
            Use DHCP. Default is True.
        ip_address : str, optional
            Static IP address. Default is empty string.
        gateway : str, optional
            Gateway address. Default is empty string.
        dns : list[str], optional
            DNS servers. Default is empty string.
        
        Examples
        --------
        >>> # Connect using DHCP (automatic IP)
        >>> robot.connect_wifi("MyWiFi", "mypassword123")
        >>> # Connect with static IP configuration
        >>> robot.connect_wifi("MyWiFi", "mypassword123", use_dhcp=False,
        ...                    ip_address="192.168.1.100/24", gateway="192.168.1.1")
        >>> # Connect to open network
        >>> robot.connect_wifi("OpenNetwork")
        >>> # Check connection status
        >>> status = robot.get_wifi_status()
        >>> print(f"Connected: {status.connected}, SSID: {status.ssid}")
        """
    def control(self, control: typing.Callable[[Robot_UB_ControlState], Robot_UB_ControlInput], port: int = 0, priority: int = 1) -> bool:
        """
        control(control, port=0, priority=1)
        
        Start a **blocking** real-time control loop using a custom control callback.
        
        This function runs a UDP-based real-time loop that repeatedly calls the user-provided
        ``control(ControlState) -> ControlInput``. The loop exits when the callback returns a
        ``ControlInput`` with ``finish=True``, or when an error/abort occurs. The function
        returns ``True`` only if it finished via ``finish=True``; otherwise ``False``.
        
        Parameters
        ----------
        control : callable
            A callable that accepts a ``ControlState`` and returns a ``ControlInput``.
            The callback is invoked for each received RT state packet.
        port : int, optional
            UDP port to bind for the RT server. Use ``0`` to let the OS choose an available port
            (recommended). Default is ``0``.
        priority : int, optional
            Command priority sent with the RT control request. Default is ``1``.
        
        Returns
        -------
        bool
            ``True`` if the loop terminated because the callback set ``finish=True`` in
            ``ControlInput``. ``False`` if the loop ended due to an error or abort
            (e.g., UDP bind failure, connection issue).
        
        Notes
        -----
        - **Blocking:** This call blocks until the control loop ends. There is no handler for
          external cancellation. Design the callback to set ``finish=True`` when you want to stop.
        - **GIL behavior:** The function releases the Python GIL around I/O and reacquires it
          only when invoking your Python callback, allowing other Python threads to run between
          callbacks.
        - **Performance:** Keep the callback lightweight—avoid long computations or blocking I/O
          inside the callback to maintain RT responsiveness.
        - **State fields:** The provided ``ControlState`` includes timestamp ``t``, and arrays 
          such as ``position``, ``velocity``, ``current``, and ``torque`` for all DoFs of the robot.
        - **Errors:** If the UDP server fails to bind (e.g., port unavailable), the function
          returns ``False`` immediately (and prints the error to ``stderr``).
        
        Examples
        --------
        >>> import numpy as np
        >>> 
        >>> # Stop after ~2 seconds using state.t
        >>> t0 = {"t": None}
        >>> def control_fn(state):
        ...     if t0["t"] is None:
        ...         t0["t"] = state.t
        ...     finish = (state.t - t0["t"]) >= 2.0
        ...     i = ControlInput()
        ...     i.mode.fill(rby.ControlMode.Position)
        ...     i.target = np.zeros_like(state.position)   # hold home
        ...     i.feedback_gain.fill(10)                   # simple P gain
        ...     i.feedforward_torque.fill(0)               # no torque feedforward
        ...     i.finish = finish
        ...     return i
        >>> ok = robot.control(control_fn)
        >>> print(ok)   # True if finished via finish=True
        """
    def create_command_stream(self, priority: int = 1) -> Robot_UB_CommandStreamHandler:
        """
        create_command_stream(priority=1)
        
        Create a command stream for continuous command sending.
        
        Parameters
        ----------
        priority : int, optional
            Command priority. Default is 1.
        
        Returns
        -------
        RobotCommandStreamHandler
            Command stream handler.
        
        Examples
        --------
        >>> # Create command stream for continuous operation
        >>> stream_handler = robot.create_command_stream(priority=1)
        >>> # Send commands continuously
        >>> for i in range(10):
        ...     command_builder = create_command(i)
        ...     stream_handler.send_command(command_builder, timeout_ms=1000)
        ...     time.sleep(1)
        >>> # Through the handler, you can terminate control or check the current state
        >>> stream_handler.cancel()
        >>> # See examples/python/cartesian_command_stream.py for complete usage
        """
    def disable_control_manager(self) -> bool:
        """
        disable_control_manager()
        
        Disable the control manager.
        """
    def disconnect(self) -> None:
        """
        disconnect()
        
        Disconnects from the robot.
        """
    def disconnect_wifi(self) -> bool:
        """
        disconnect_wifi()
        
        Disconnect from WiFi network.
        """
    def download_file(self, path: str, file_like: typing.Any) -> bool:
        """
        download_file(path, file_like)
        
        Downloads a file from the robot and writes it into a file-like object.
        
        Parameters
        ----------
        path : str
            Relative path to the file on the robot's file system.
            The base directory is defined by the `RBY1_HOME` environment variable (default: `/root/.rby1`).
        file_like : file-like object
            Any object with a `.write(bytes)` method (e.g., `io.BytesIO`, a real file).
        
        Returns
        -------
        bool
            ``True`` if the file was downloaded successfully.
        
        Raises
        ------
        RuntimeError
            If the gRPC call fails (e.g., network issue, file not found, internal error).
        """
    def enable_control_manager(self, unlimited_mode_enabled: bool = False) -> bool:
        """
        Enable the control manager.
        
        Parameters
        ----------
        unlimited_mode_enabled : bool, optional
            Whether to enable unlimited mode. Default is False.
        
        Examples
        --------
        >>> # Enable control manager for robot control
        >>> robot.enable_control_manager()
        >>> # Enable with unlimited mode (use with caution)
        >>> robot.enable_control_manager(unlimited_mode_enabled=True)
        >>> # Must be called before sending commands
        """
    def factory_reset_all_parameters(self) -> None:
        """
        factory_reset_all_parameters()
        
        Factory reset all parameters to their default values.
        """
    def factory_reset_parameter(self, name: str) -> bool:
        """
        factory_reset_parameter(name)
        
        Factory reset a parameter to its default value.
        
        Parameters
        ----------
        name : str
            Parameter name.
        """
    def get_control_manager_state(self) -> ControlManagerState:
        """
        get_control_manager_state()
        
        Get control manager state.
        
        Returns
        -------
        ControlManagerState
            Current control manager state.
        
        Examples
        --------
        >>> # Get control manager state
        >>> ctrl_state = robot.get_control_manager_state()
        >>> print(f"Control Manager state: {ctrl_state.state}")
        >>> print(f"Control state: {ctrl_state.control_state}")
        >>> # Check if control manager is enabled
        >>> if ctrl_state.state == rby1_sdk.ControlManagerState.State.Enabled:
        ...     print("Control manager is enabled")
        """
    def get_dynamics(self, urdf_model: str = '') -> dynamics.Robot_18:
        """
        get_dynamics(urdf_model='')
        
        Get robot dynamics model.
        
        Parameters
        ----------
        urdf_model : str, optional
            URDF model path. Default is empty string.
        
        Returns
        -------
        dyn.Robot
            Robot dynamics model.
        
        Examples
        --------
        >>> # Get dynamics model with the model from connected robot
        >>> dynamics_robot = robot.get_dynamics()
        >>> # Get dynamics model with custom URDF
        >>> dynamics_robot = robot.get_dynamics("/path/to/custom.urdf")
        >>> # Useful for advanced control algorithms
        """
    def get_fault_log_list(self) -> list[str]:
        """
        get_fault_log_list()
        
        Get fault log list.
        
        Returns
        -------
        list
            List of fault log entries.
        """
    def get_head_position_pid_gains(self) -> list[PIDGain]:
        """
        get_head_position_pid_gains()
        
        Get head position PID gains.
        
        Returns
        -------
        PIDGain
            Head position PID gains.
        """
    def get_last_log(self, count: int) -> list[Log]:
        """
        get_last_log(count)
        
        Get last log entries.
        
        Parameters
        ----------
        count : int
            Number of log entries to retrieve.
        
        Returns
        -------
        list
            List of log entries.
        """
    def get_left_arm_position_pid_gains(self) -> list[PIDGain]:
        """
        get_left_arm_position_pid_gains()
        
        Get left arm position PID gains.
        
        Returns
        -------
        PIDGain
            Left arm position PID gains.
        """
    def get_parameter(self, name: str) -> str:
        """
        get_parameter(name)
        
        Retrieve a robot parameter.
        
        Parameters
        ----------
        name : str
            Name of the parameter to retrieve.
        
        Returns
        -------
        any
            Parameter value.
            Returned as a JSON value: numeric values are returned as-is, strings are enclosed in quotes ("...").
        
        Examples
        --------
        >>> # Retrieve current parameter values
        >>> acc_scaling = robot.get_parameter("default.acceleration_limit_scaling")
        >>> cutoff_freq = robot.get_parameter("joint_position_command.cutoff_frequency")
        >>> model_name = robot.get_parameter("robot_model_name")
        >>> print(f"Acceleration scaling: {acc_scaling}")
        >>> print(f"Cutoff frequency: {cutoff_freq}")
        >>> print(f"Model name: {model_name}")
        """
    def get_parameter_list(self) -> list[tuple[str, int]]:
        """
        get_parameter_list()
        
        Get list of available parameters.
        
        Returns
        -------
        list
            List of parameter names.
        
        Examples
        --------
        >>> # Get all available parameters
        >>> param_list = robot.get_parameter_list()
        >>> print(f"Total parameters: {len(param_list)}")
        >>> # List common parameter categories
        >>> for param in param_list:
        ...     if param[0].startswith("default."):
        ...         print(f"Default param: {param}")
        ...     elif param[0].startswith("joint_position_command."):
        ...         print(f"Joint position param: {param}")
        >>> # Common categories: default.*, joint_position_command.*, cartesian_command.*
        """
    def get_position_pid_gain(self, dev_name: str) -> PIDGain:
        """
        get_position_pid_gain(dev_name)
        
        Get position PID gains for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name.
        
        Returns
        -------
        PIDGain
            Position PID gains for the device.
        
        Examples
        --------
        >>> # Get PID gains for specific device
        >>> torso_pid = robot.get_position_pid_gain("torso_5")
        >>> print(f"Torso 5 P: {torso_pid.p_gain}, I: {torso_pid.i_gain}, D: {torso_pid.d_gain}")
        >>> # Get PID gains for arm
        >>> arm_pid = robot.get_position_pid_gain("right_arm_0")
        >>> print(f"Right arm 0 P: {arm_pid.p_gain}")
        >>> devices = ["torso_5", "right_arm_0", "left_arm_1", "head_0"]
        >>> for device in devices:
        ...     pid = robot.get_position_pid_gain(device)
        ...     print(f"{device}: P={pid.p_gain}, I={pid.i_gain}, D={pid.d_gain}")
        """
    def get_right_arm_position_pid_gains(self) -> list[PIDGain]:
        """
        get_right_arm_position_pid_gains()
        
        Get right arm position PID gains.
        
        Returns
        -------
        PIDGain
            Right arm position PID gains.
        """
    def get_robot_info(self) -> RobotInfo:
        """
        get_robot_info()
        
        Retrieves static information about the robot, such as model name, SDK version, and joint configuration.
        
        Returns
        -------
        RobotInfo
            Structured metadata including joint details, device names, and robot model information.
        
        Examples
        --------
        >>> # Get robot information
        >>> robot_info = robot.get_robot_info()
        >>> print(f"SDK version: {robot_info.sdk_version}")
        >>> print(f"Robot model name: {robot_info.robot_model_name}")
        >>> print(f"Robot model version: {robot_info.robot_model_version}")
        >>> print(f"Joint count: {len(robot_info.joint_infos)}")
        >>> # Access joint information
        >>> for joint in robot_info.joint_infos:
        ...     print(f"Joint: {joint.name}, Brake: {joint.has_brake}, Product name: {joint.product_name}, Firmware version: {joint.firmware_version}")
        """
    def get_robot_model(self) -> str:
        """
        get_robot_model()
        
        Get the current robot model.
        
        Returns
        -------
        RobotModel
            Current robot model.
        """
    def get_serial_device_list(self) -> list[SerialDevice]:
        """
        get_serial_device_list()
        
        Get list of available serial devices on the robot.
        
        Returns
        -------
        list
            List of available serial devices.
        
        Examples
        --------
        >>> # Get available serial devices
        >>> devices = robot.get_serial_device_list()
        >>> print(f"Found {len(devices)} serial devices")
        >>> # List device information
        >>> for device in devices:
        ...     print(f"Path: {device.path}, Description: {device.description}")
        >>> # Open serial stream to first device
        >>> if devices:
        ...     stream = robot.open_serial_stream(devices[0].path, 115200)
        >>> # Common device paths: /dev/ttyUSB0, /dev/ttyACM0, COM1, COM2
        """
    def get_state(self) -> RobotState_UB:
        """
        get_state()
        
        Get current robot state.
        
        Returns
        -------
        RobotState
            Current robot state.
        
        Examples
        --------
        >>> robot_state = robot.get_state()
        >>> model = robot.model()
        >>> print(f"Joint positions: {robot_state.position}")
        >>> print(f"Right arm position: {robot_state.position[model.right_arm_idx]}")
        >>> # Note: Joint positions include mobile base (2-DOF) + torso (6-DOF) + right arm (7-DOF) + left arm (7-DOF) + head (2-DOF)
        >>> # Total: 24 DOF for model A, 23 DOF for model M, 26 DOF for model M, 18 DOF for model UB
        """
    def get_system_time(self) -> tuple[typing.Any, str]:
        """
        Get robot system time.
        
        Returns
        -------
        tuple
            (datetime, str): Robot system time and local time string.
        """
    def get_time_scale(self) -> float:
        """
        get_time_scale()
        
        Get the current time scale.
        
        Returns
        -------
        float
            Current time scale value.
        
        Examples
        --------
        >>> # Get current time scale
        >>> current_scale = robot.get_time_scale()
        >>> print(f"Current time scale: {current_scale}")
        >>> # Check if robot is running at full speed
        >>> if current_scale == 1.0:
        ...     print("Robot running at full speed")
        >>> # Check if robot is slowed down
        >>> elif current_scale < 1.0:
        ...     print(f"Robot running at {current_scale * 100}% speed")
        """
    def get_torso_position_pid_gains(self) -> list[PIDGain]:
        """
        get_torso_position_pid_gains()
        
        Get torso position PID gains.
        
        Returns
        -------
        PIDGain
            Torso position PID gains.
        
        Examples
        --------
        >>> # Get current PID gains for torso
        >>> torso_pid = robot.get_torso_position_pid_gains()[0]  # Get first (and only) torso device
        >>> print(f"Torso P: {torso_pid.p_gain}, I: {torso_pid.i_gain}, D: {torso_pid.d_gain}")
        >>> right_arm_pid = robot.get_right_arm_position_pid_gains()[0]
        >>> print(f"Right arm: {right_arm_pid}")
        """
    def get_wifi_status(self) -> WifiStatus | None:
        """
        get_wifi_status()
        
        Get WiFi connection status.
        
        Returns
        -------
        WifiStatus
            Current WiFi status.
        """
    def has_established_time_sync(self) -> bool:
        """
        Check if time synchronization is established.
        
        Returns
        -------
        bool
            True if time sync is established, False otherwise.
        """
    def home_offset_reset(self, dev_name: str) -> bool:
        """
        home_offset_reset(dev_name)
        
        Reset home offset for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name to reset home offset. Supports regex patterns.
        """
    def import_robot_model(self, name: str, model: str) -> bool:
        """
        import_robot_model(name, model)
        
        Import a robot model.
        
        Parameters
        ----------
        name : str
            Model name.
        model : RobotModel
            Robot model to import.
        """
    def is_connected(self) -> bool:
        """
        is_connected()
        
        Checks whether the robot is currently connected.
        
        Returns
        -------
        bool
            ``True`` if the robot is connected to the robot, ``False`` otherwise.
        """
    def is_power_on(self, dev_name: str) -> bool:
        """
        is_power_on(dev_name)
        
        Check if a device is powered on.
        
        Parameters
        ----------
        dev_name : str
            Device name to check. Supports regex patterns.
        
        Returns
        -------
        bool
            ``True`` if device is powered on, ``False`` otherwise.
        """
    def is_servo_on(self, dev_name: str) -> bool:
        """
        is_servo_on(dev_name)
        
        Check if servo control is enabled for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name to check. Supports regex patterns.
        
        Returns
        -------
        bool
            ``True`` if servo control is enabled, ``False`` otherwise.
        """
    def open_serial_stream(self, device_path: str, baudrate: int, bytesize: int = 8, parity: str = 'N', stopbits: int = 1) -> SerialStream:
        """
        open_serial_stream(device_path, baudrate, bytesize=8, parity='N', stopbits=1)
        
        Open a serial stream.
        
        Parameters
        ----------
        device_path : str
            Path to serial device.
        baudrate : int
            Baud rate.
        bytesize : int, optional
            Data bits. Default is 8.
        parity : str, optional
            Parity setting. Default is 'N'.
        stopbits : int, optional
            Stop bits. Default is 1.
        
        Returns
        -------
        SerialStream
            Serial stream object.
        
        Examples
        --------
        >>> # Open serial stream with default settings
        >>> stream = robot.open_serial_stream("/dev/ttyUSB0", 115200)
        >>> # Open with custom settings
        >>> stream = robot.open_serial_stream("/dev/ttyUSB1", 9600, bytesize=7, parity='E', stopbits=2)
        >>> # Common baudrates: 9600, 19200, 38400, 57600, 115200
        >>> # Parity: 'N' (none), 'E' (even), 'O' (odd)
        >>> # Stop bits: 1, 2
        """
    def power_off(self, dev_name: str) -> bool:
        """
        power_off(dev_name)
        
        Power off a device.
        
        Parameters
        ----------
        dev_name : str
            Device name to power off. Supports regex patterns.
        """
    def power_on(self, dev_name: str) -> bool:
        """
        power_on(dev_name)
        
        Power on a device.
        
        Parameters
        ----------
        dev_name : str
            Device name to power on. Supports regex patterns.
        
        Examples
        --------
        >>> robot.connect()
        >>> if not robot.is_power_on(".*"):
        ...     robot.power_on(".*")
        ...     print("Robot powered on")
        >>> # Pattern ".*" powers on all devices
        >>> # Specific device: robot.power_on("12v"), robot.power_on("24v"), etc.
        """
    def reset_all_parameters(self) -> None:
        """
        reset_all_parameters()
        
        Reset all parameters to their current values.
        """
    def reset_all_parameters_to_default(self) -> None:
        """
        reset_all_parameters_to_default()
        
        Reset all parameters to their default values (deprecated).
        
        .. deprecated:: 0.6.0
           Use :meth:`factory_reset_all_parameters` instead.
        
        Note
        ----
        This method is deprecated. Use factory_reset_all_parameters() instead.
        """
    def reset_battery_config(self) -> bool:
        """
        reset_battery_config()
        
        Reset battery configuration to default.
        """
    def reset_fault_control_manager(self) -> bool:
        """
        reset_fault_control_manager()
        
        Reset fault in the control manager.
        """
    def reset_network_setting(self) -> bool:
        """
        reset_network_setting()
        
        Reset network settings to default.
        """
    def reset_odometry(self, angle: float, position: numpy.ndarray[tuple[typing.Literal[2], typing.Literal[1]], numpy.dtype[numpy.float64]]) -> bool:
        """
        reset_odometry(angle, position)
        
        Reset odometry to specified values.
        
        Parameters
        ----------
        angle : float
            New angle in rad.
        position : numpy.ndarray
            New position in meters.
        
        Examples
        --------
        >>> import numpy as np
        >>> # Reset odometry to origin
        >>> robot.reset_odometry(angle=0.0, position=np.array([0.0, 0.0]))
        >>> # Reset to specific position and orientation
        >>> robot.reset_odometry(angle=np.pi/2, position=np.array([1.0, 2.0]))
        >>> # Useful for mobile base navigation
        >>> # Position is [x, y] in meters, angle is yaw in rad
        """
    def reset_parameter(self, name: str) -> bool:
        """
        reset_parameter(name)
        
        Reset a parameter to its current value.
        
        Parameters
        ----------
        name : str
            Parameter name.
        """
    def reset_parameter_to_default(self, name: str) -> bool:
        """
        reset_parameter_to_default(name)
        
        Reset a parameter to its default value (deprecated).
        
        Parameters
        ----------
        name : str
            Parameter name.
        
        .. deprecated:: 0.6.0
           Use :meth:`factory_reset_parameter` instead.
        
        Note
        ----
        This method is deprecated. Use factory_reset_parameter() instead.
        """
    def scan_wifi(self) -> list[WifiNetwork]:
        """
        scan_wifi()
        
        Scan for available WiFi networks.
        
        Returns
        -------
        list
            List of available WiFi networks.
        
        Examples
        --------
        >>> # Scan for available WiFi networks
        >>> networks = robot.scan_wifi()
        >>> print(f"Found {len(networks)} networks")
        >>> # List network information
        >>> for network in networks:
        ...     print(f"SSID: {network.ssid}, Signal: {network.signal_strength}")
        >>> # Connect to a network
        >>> if networks:
        ...     robot.connect_wifi(networks[0].ssid, "password")
        """
    def send_command(self, builder: RobotCommandBuilder, priority: int = 1) -> Robot_UB_CommandHandler:
        """
        send_command(builder, priority=1)
        
        Send a command to the robot.
        
        Parameters
        ----------
        builder : CommandBuilder
            Command builder to send.
        priority : int, optional
            Command priority. Default is 1.
        
        Returns
        -------
        RobotCommandHandler
            Command handler for monitoring execution.
        
        Examples
        --------
        >>> from rby1_sdk import RobotCommandBuilder, ComponentBasedCommandBuilder
        >>> from rby1_sdk import BodyComponentBasedCommandBuilder, JointPositionCommandBuilder
        >>> # Create command with method chaining (standard pattern)
        >>> command = RobotCommandBuilder().set_command(
        ...     ComponentBasedCommandBuilder().set_body_command(
        ...         BodyComponentBasedCommandBuilder()
        ...             .set_torso_command(
        ...                 JointPositionCommandBuilder()
        ...                     .set_position([0, 0, 0, 0, 0, 0])  # 6-DOF torso
        ...                     .set_minimum_time(2.0)
        ...             )
        ...     )
        ... )
        >>> handler = robot.send_command(command)
        >>> handler.wait()  # Wait for completion
        >>> # This pattern is used in most examples: examples/python/07_impedance_control.py, 09_demo_motion.py, etc.
        """
    def servo_off(self, dev_name: str) -> bool:
        """
        servo_off(dev_name)
        
        Disable servo control for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name to disable servo control. Supports regex patterns.
        
        Examples
        --------
        >>> # Disable servo control for safety
        >>> robot.servo_off(".*")  # All motor drivers
        >>> # Specific device: robot.servo_off("^torso_.*")
        """
    def servo_on(self, dev_name: str) -> bool:
        """
        servo_on(dev_name)
        
        Enable servo control for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name to enable servo control. Supports regex patterns.
        
        Examples
        --------
        >>> robot.connect()
        >>> if not robot.is_servo_on(".*"):
        ...     robot.servo_on(".*")  # Servo on all devices
        ...     print("All devices servoed on")
        >>> # Specific device: robot.servo_on("^torso_.*"), robot.servo_on("^right_arm_.*"), etc.
        """
    def set_battery_config(self, cutoff_voltage: float, fully_charged_voltage: float, coefficients: typing.Annotated[list[float], pybind11_stubgen.typing_ext.FixedSize(4)]) -> bool:
        """
        set_battery_config(cutoff_voltage, fully_charged_voltage, coefficients)
                   
        Set battery configuration.
        """
    def set_battery_level(self, arg0: float) -> bool:
        """
        Set battery level.
        
        Parameters
        ----------
        level : float
            Battery level percentage (0.0 to 100.0).
        
        Examples
        --------
        >>> # Set battery level for testing
        >>> robot.set_battery_level(100.0)  # Full battery
        >>> robot.set_battery_level(50.0)   # Half battery
        >>> robot.set_battery_level(25.0)   # Quarter battery
        >>> robot.set_battery_level(0.0)    # Empty battery
        >>> # Range: 0.0 to 100.0
        >>> # Useful for using custom battery
        """
    def set_led_color(self, color: Color, duration: float = 1, transition_time: float = 0, blinking: bool = False, blinking_freq: float = 1) -> bool:
        """
        set_led_color(color, duration=1.0, transition_time=0.0, blinking=False, blinking_freq=1.0)
        
        Set LED color.
        
        Parameters
        ----------
        color : Color
            LED color.
        duration : float, optional
            Duration in seconds. Default is 1.
        transition_time : float, optional
            Transition time in seconds. Default is 0.
        blinking : bool, optional
            Whether to blink. Default is False.
        blinking_freq : float, optional
            Blinking frequency in Hz. Default is 1.
        
        Examples
        --------
        >>> from rby1_sdk import Color
        >>> # Set LED to red for 5 seconds
        >>> robot.set_led_color(Color(255, 0, 0), duration=5.0)
        >>> # Set LED to green with 1 second transition
        >>> robot.set_led_color(Color(0, 255, 0), transition_time=1.0)
        >>> # Set LED to blue with blinking
        >>> robot.set_led_color(Color(0, 0, 255), blinking=True, blinking_freq=2.0)
        >>> # Set LED to white with custom duration and transition
        >>> robot.set_led_color(Color(255, 255, 255), duration=10.0, transition_time=2.0)
        """
    def set_parameter(self, name: str, value: str, write_db: bool = True) -> bool:
        """
        set_parameter(name, value, write_db=True)
        
        Set a robot parameter.
        
        Parameters
        ----------
        name : str
            Parameter name.
        value : any
            Parameter value.
        write_db : bool, optional
            Whether to write to database. Default is True.
        
        Examples
        --------
        >>> # Set acceleration limit scaling
        >>> robot.set_parameter("default.acceleration_limit_scaling", "0.8")
        >>> # Set joint position command cutoff frequency
        >>> robot.set_parameter("joint_position_command.cutoff_frequency", "5")
        >>> # Set hotspot SSID name
        >>> robot.set_parameter("hotspot.ssid", "\\"RBY1_HOTSPOT\\"") # For str value, use escaped quotes
        >>> # Set without writing to database (Return ``False`` if matching parameter not found)
        >>> robot.set_parameter("temp.parameter", "value", write_db=False)
        False
        """
    def set_position_d_gain(self, dev_name: str, d_gain: int) -> bool:
        """
        set_position_d_gain(dev_name, d_gain)
        
        Set position D gain for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name.
        d_gain : int
            D gain value.
        
        Examples
        --------
        >>> # Set D gain for specific devices
        >>> robot.set_position_d_gain("torso_5", 400)
        """
    def set_position_i_gain(self, dev_name: str, i_gain: int) -> bool:
        """
        set_position_i_gain(dev_name, i_gain)
        
        Set position I gain for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name.
        i_gain : int
            I gain value.
        
        Examples
        --------
        >>> # Set I gain for specific devices
        >>> robot.set_position_i_gain("torso_5", 40)
        """
    def set_position_p_gain(self, dev_name: str, p_gain: int) -> bool:
        """
        set_position_p_gain(dev_name, p_gain)
        
        Set position P gain for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name.
        p_gain : int
            P gain value.
        
        Examples
        --------
        >>> # Set P gain for specific devices
        >>> robot.set_position_p_gain("torso_5", 220)
        """
    @typing.overload
    def set_position_pid_gain(self, dev_name: str, p_gain: int, i_gain: int, d_gain: int) -> bool:
        """
        set_position_pid_gain(dev_name, p_gain, i_gain, d_gain)
        
        Set position PID gains for a device.
        
        Parameters
        ----------
        dev_name : str
            Device name.
        p_gain : int
            P gain value.
        i_gain : int
            I gain value.
        d_gain : int
            D gain value.
        
        Examples
        --------
        >>> # Set all PID gains at once for a device
        >>> robot.set_position_pid_gain("right_arm_0", 80, 15, 200)
        >>> robot.set_position_pid_gain("right_arm_1", 80, 15, 200)
        >>> robot.set_position_pid_gain("right_arm_2", 80, 15, 200)
        >>> robot.set_position_pid_gain("right_arm_3", 35, 5, 80)
        >>> robot.set_position_pid_gain("right_arm_4", 30, 5, 70)
        >>> robot.set_position_pid_gain("right_arm_5", 30, 5, 70)
        >>> robot.set_position_pid_gain("right_arm_6", 100, 5, 120)
        """
    @typing.overload
    def set_position_pid_gain(self, dev_name: str, pid_gain: PIDGain) -> bool:
        """
        set_position_pid_gain(dev_name, pid_gain)
        
        Set position PID gains for a device using PIDGain object.
        
        Parameters
        ----------
        dev_name : str
            Device name.
        pid_gain : PIDGain
            PID gain object.
        """
    def set_preset_position(self, joint_name: str) -> bool:
        """
        set_preset_position(joint_name)
        
        Set preset position for a joint (only available for PVL-based motors).
        
        Parameters
        ----------
        joint_name : str
            Joint name to set preset position.
        
        Examples
        --------
        >>> # Set preset position for specific joints
        >>> robot.set_preset_position("right_arm_6")  # Right arm joint 6
        >>> # Preset position is used as reference for home offset
        """
    @typing.overload
    def set_system_time(self, datetime: typing.Any) -> bool:
        """
        set_system_time(datetime)
        
        Set robot system time.
        
        Parameters
        ----------
        datetime : datetime.datetime
            New system time.
        """
    @typing.overload
    def set_system_time(self, datetime: typing.Any, time_zone: str) -> bool:
        """
        set_system_time(datetime, time_zone)
        
        Set robot system time with timezone.
        
        Parameters
        ----------
        datetime : datetime.datetime
            New system time.
        time_zone : str
            Timezone string.
        """
    def set_time_scale(self, time_scale: float) -> float:
        """
        set_time_scale(time_scale)
        
        Set the time scale for motion execution.
        
        Parameters
        ----------
        time_scale : float
            Time scale value (0.0 to 1.0).
        
        Examples
        --------
        >>> # Set time scale for motion execution
        >>> robot.set_time_scale(1.0)   # Normal speed (100%)
        >>> robot.set_time_scale(0.5)   # Half speed (50%)
        >>> robot.set_time_scale(0.25)  # Quarter speed (25%)
        >>> # Range: 0.0 (stopped) to 1.0 (full speed)
        >>> # Useful for testing and safety
        """
    def set_tool_flange_digital_output(self, name: str, channel: int, state: bool) -> bool:
        """
        set_tool_flange_digital_output(name, channel, state)
        
        Set the digital output state of a specific channel on the tool flange
        of the specified arm.
        
        Parameters
        ----------
        name : str
            Arm identifier. Must be either `"right"` or `"left"`,
            indicating the tool flange of the right or left arm.
        channel : int
            Digital output channel index.
        state : bool
            Desired state of the digital output (``True`` = ON, ``False`` = OFF).
        
        Returns
        -------
        bool
            ``True`` if the command was successfully sent, ``False`` otherwise.
        
        Examples
        --------
        >>> # Turn on channel 0 on the right arm tool flange
        >>> robot.set_tool_flange_digital_output("right", 0, True)
        """
    def set_tool_flange_digital_output_dual(self, name: str, state_0: bool, state_1: bool) -> bool:
        """
        set_tool_flange_digital_output_dual(name, state_0, state_1)
        
        Set the digital output states of two channels on the tool flange
        of the specified arm simultaneously.
        
        Parameters
        ----------
        name : str
            Arm identifier. Must be either `"right"` or `"left"`,
            indicating the tool flange of the right or left arm.
        state_0 : bool
            Desired state for digital output channel 0 (True = ON, False = OFF).
        state_1 : bool
            Desired state for digital output channel 1 (True = ON, False = OFF).
        
        Returns
        -------
        bool
            ``True`` if the command was successfully sent, ``False`` otherwise.
        
        Examples
        --------
        >>> # Turn on channel 0 and turn off channel 1 on the left arm tool flange
        >>> robot.set_tool_flange_digital_output_dual("left", True, False)
        """
    def set_tool_flange_output_voltage(self, name: str, voltage: int) -> bool:
        """
        set_tool_flange_output_voltage(name, voltage)
        
        Set tool flange output voltage.
        
        Parameters
        ----------
        name : str
            Tool flange name `"right"` or `"left"`.
        
        voltage : int
            Output voltage in volts.
        
        Examples
        --------
        >>> # Set tool flange output voltage
        >>> robot.set_tool_flange_output_voltage("right", 12)  # 12V output
        >>> robot.set_tool_flange_output_voltage("left", 24)  # 24V output
        >>> # Common voltages: 12V, 24V
        >>> # Use 0V to turn off output
        >>> # Note: This method sets voltage for both tool flanges (right and left)
        """
    def start_log_stream(self, cb: typing.Callable[[list[Log]], None], rate: float) -> None:
        """
        start_log_stream(cb, rate)
                
        Start log stream callback.
        
        Parameters
        ----------
        cb : callable
            Callback function for log updates.
        rate : float
            Update rate in Hz.
        
        Examples
        --------
        >>> def log_callback(log_entries):
        ...     for log in log_entries:
        ...         print(f"{log.timestamp} - {log.level} - {log.message}")
        >>> # Start log stream at 10 Hz
        >>> robot.start_log_stream(log_callback, 10.0)
        >>> # Stop when done: robot.stop_log_stream()
        """
    def start_state_update(self, cb: typing.Callable, rate: float) -> None:
        """
        start_state_update(cb, rate)
        
        Start state update callback.
        
        Parameters
        ----------
        cb : callable
            Callback function with 1 or 2 parameters:
            - cb(robot_state) or cb(robot_state, control_manager_state)
        rate : float
            Update rate in Hz.
        
        Examples
        --------
        >>> def state_callback(robot_state):
        ...     print(f"Timestamp: {robot_state.timestamp}, Joint positions: {robot_state.position}")
        >>> # Start state updates at 100 Hz
        >>> robot.start_state_update(state_callback, 100.0)
        >>> # Stop when done: robot.stop_state_update()
        """
    def start_time_sync(self, period_sec: int) -> bool:
        """
        start_time_sync(period_sec)
        
        Start time synchronization.
        
        Parameters
        ----------
        period_sec : float
            Synchronization period in seconds.
        """
    def stop_log_stream(self) -> None:
        """
        stop_log_stream()
        
        Stop log stream callback.
        """
    def stop_state_update(self) -> None:
        """
        stop_state_update()
        
        Stop state update callback.
        """
    def stop_time_sync(self) -> bool:
        """
        stop_time_sync()
        
        Stop time synchronization.
        """
    def sync_time(self) -> bool:
        """
        sync_time()
        
        Synchronizes the timestamp of ``RobotState`` to UPC time instead of UTC. 
        Useful when synchronizing multiple devices to UPC time.
        """
    def wait_for_control_ready(self, timeout_ms: int) -> bool:
        """
        wait_for_control_ready(timeout_ms)
        
        Wait until the robot is ready to accept control commands.
        
        Parameters
        ----------
        timeout_ms : int
            Timeout in milliseconds.
        
        Returns
        -------
        bool
            ``True`` if the robot is ready to accept control (you can now set control).
            ``False`` if the timeout expired before the robot became ready.
        
        Examples
        --------
        >>> # Wait for control to be ready
        >>> if robot.wait_for_control_ready(timeout_ms=5000):
        ...     print("Control is ready, you can now set control commands.")
        ... else:
        ...     print("Timeout: control is not ready.")
        >>> # Call after servo_on() and before sending control commands
        """
class Robot_UB_CommandHandler:
    """
    
    Robot command handler.
    
    Handles robot command execution and provides status monitoring.
    
    Attributes
    ----------
    is_done : bool
        Whether the command execution is complete.
    """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    def cancel(self) -> None:
        """
        cancel()
        
        Cancel the command execution.
        """
    def get(self) -> RobotCommandFeedback:
        """
        get()
        
        Wait for the command execution and get feedback
        
        Returns
        -------
        RobotCommandFeedback
            Current feedback information.
        """
    def get_status(self) -> bool:
        """
        get_status()
        
        Get gRPC status
        """
    def is_done(self) -> bool:
        """
        Check if the command execution is complete.
        
        Returns
        -------
        bool
            ``True`` if command is complete, ``False`` otherwise.
        """
    def wait(self) -> None:
        """
        wait()
        
        Wait for the command execution to complete.
        
        This method blocks until the command is done or cancelled.
        """
    def wait_for(self, timeout_ms: int) -> bool:
        """
        wait_for(timeout_ms)
        
        Wait for the command execution with timeout.
        
        Parameters
        ----------
        timeout_ms : int
            Timeout in milliseconds.
        
        Returns
        -------
        bool
            ``True`` if command completed, ``False`` if timeout.
        """
class Robot_UB_CommandStreamHandler:
    """
    
    Robot command stream handler.
    
    Handles robot command execution through streaming with send and feedback capabilities.
    
    Attributes
    ----------
    is_done : bool
        Whether the command execution is complete.
    """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    def cancel(self) -> None:
        """
        cancel()
        
        Cancel the current command execution.
        """
    def is_done(self) -> bool:
        """
        Check if the command execution is complete.
        
        Returns
        -------
        bool
            True if command is complete, False otherwise.
        """
    def request_feedback(self, timeout_ms: int = 1000) -> RobotCommandFeedback:
        """
        request_feedback(timeout_ms)
        
        Request feedback from the robot.
        
        Parameters
        ----------
        timeout_ms : int, optional
            Timeout in milliseconds. Default is 1000.
        
        Returns
        -------
        RobotCommandFeedback
            Current feedback information.
        """
    def send_command(self, builder: RobotCommandBuilder, timeout_ms: int = 1000) -> RobotCommandFeedback:
        """
        send_command(builder, timeout_ms=1000)
        
        Send a command through the stream.
        
        Parameters
        ----------
        builder : CommandBuilder
            Command builder to send.
        timeout_ms : int, optional
            Timeout in milliseconds. Default is 1000.
        
        Returns
        -------
        RobotCommandFeedback
            Current feedback information.
        """
    def wait(self) -> None:
        ...
    def wait_for(self, timeout_ms: int) -> bool:
        """
        Wait for the command execution to complete.
        
        This method blocks until the command is done or cancelled.
        """
class Robot_UB_ControlInput:
    """
    
    Robot control input.
    
    Represents control input parameters for robot real-time control including mode, target, and gains.
    
    Attributes
    ----------
    mode : numpy.ndarray
        Control mode for each joint (boolean array).
    target : numpy.ndarray
        Target positions for each joint in rad.
    feedback_gain : numpy.ndarray
        Feedback gains for each joint.
    feedforward_torque : numpy.ndarray
        Feedforward torque for each joint in Nm.
    finish : bool
        Whether to finish the current control operation.
    """
    def __init__(self) -> None:
        """
        Construct a ``ControlInput`` instance.
        """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    @property
    def feedback_gain(self) -> numpy.ndarray[tuple[typing.Literal[18], typing.Literal[1]], numpy.dtype[numpy.uint32]]:
        """
        Feedback gains for each joint.
        
        Type
        ----
        numpy.ndarray
            Feedback gain values for each joint.
        """
    @feedback_gain.setter
    def feedback_gain(self, arg1: numpy.ndarray[tuple[typing.Literal[18], typing.Literal[1]], numpy.dtype[numpy.uint32]]) -> None:
        ...
    @property
    def feedforward_torque(self) -> numpy.ndarray[tuple[typing.Literal[18], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        """
        Feedforward torque for each joint.
        
        Type
        ----
        numpy.ndarray
            Feedforward torque values in Nm for each joint.
        """
    @feedforward_torque.setter
    def feedforward_torque(self, arg1: numpy.ndarray[tuple[typing.Literal[18], typing.Literal[1]], numpy.dtype[numpy.float64]]) -> None:
        ...
    @property
    def finish(self) -> bool:
        """
        Finish control operation flag.
        
        Type
        ----
        bool
            Whether to finish the current control operation.
        """
    @finish.setter
    def finish(self, arg0: bool) -> None:
        ...
    @property
    def mode(self) -> numpy.ndarray[tuple[typing.Literal[18], typing.Literal[1]], numpy.dtype[numpy.bool_]]:
        """
        Control mode for each joint.
        
        Type
        ----
        numpy.ndarray
            Boolean array indicating control mode for each joint.
        """
    @mode.setter
    def mode(self, arg1: numpy.ndarray[tuple[typing.Literal[18], typing.Literal[1]], numpy.dtype[numpy.bool_]]) -> None:
        ...
    @property
    def target(self) -> numpy.ndarray[tuple[typing.Literal[18], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        """
        Target positions for each joint.
        
        Type
        ----
        numpy.ndarray
            Target positions in rad for each joint.
        """
    @target.setter
    def target(self, arg1: numpy.ndarray[tuple[typing.Literal[18], typing.Literal[1]], numpy.dtype[numpy.float64]]) -> None:
        ...
class Robot_UB_ControlState:
    """
    
    Robot control state.
    
    Represents the current state of robot real-time control including position, velocity, and torque.
    
    Attributes
    ----------
    t : float
        Current time in seconds.
    is_ready : numpy.ndarray
        Whether the joint is ready for control.
    position : numpy.ndarray
        Current joint positions in rad.
    velocity : numpy.ndarray
        Current joint velocities in rad/s.
    current : numpy.ndarray
        Current joint currents in A.
    torque : numpy.ndarray
        Current joint torques in Nm.
    """
    def __init__(self) -> None:
        """
        Construct a ControlState instance.
        """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    @property
    def current(self) -> numpy.ndarray[tuple[typing.Literal[18], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        """
        Joint currents.
        
        Type
        ----
        numpy.ndarray
            Current joint currents in A.
        """
    @property
    def is_ready(self) -> numpy.ndarray[tuple[typing.Literal[18], typing.Literal[1]], numpy.dtype[numpy.bool_]]:
        """
        Robot readiness status.
        
        Type
        ----
        bool
            Whether the robot is ready for control.
        """
    @property
    def position(self) -> numpy.ndarray[tuple[typing.Literal[18], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        """
        Joint positions.
        
        Type
        ----
        numpy.ndarray
            Current joint positions in rad.
        """
    @property
    def t(self) -> float:
        """
        Current time.
        
        Type
        ----
        float
            Current time in seconds.
        """
    @property
    def torque(self) -> numpy.ndarray[tuple[typing.Literal[18], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        """
        Joint torques.
        
        Type
        ----
        numpy.ndarray
            Current joint torques in Nm.
        """
    @property
    def velocity(self) -> numpy.ndarray[tuple[typing.Literal[18], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        """
        Joint velocities.
        
        Type
        ----
        numpy.ndarray
            Current joint velocities in rad/s.
        """
class SE2VelocityCommandBuilder:
    def __init__(self) -> None:
        ...
    def set_acceleration_limit(self, linear: numpy.ndarray[tuple[typing.Literal[2], typing.Literal[1]], numpy.dtype[numpy.float64]], angular: float) -> SE2VelocityCommandBuilder:
        ...
    def set_command_header(self, command_header_builder: CommandHeaderBuilder) -> SE2VelocityCommandBuilder:
        ...
    def set_minimum_time(self, minimum_time: float) -> SE2VelocityCommandBuilder:
        ...
    def set_velocity(self, linear: numpy.ndarray[tuple[typing.Literal[2], typing.Literal[1]], numpy.dtype[numpy.float64]], angular: float) -> SE2VelocityCommandBuilder:
        ...
class SE2VelocityCommandFeedback(CommandFeedback):
    def __init__(self) -> None:
        ...
class SerialDevice:
    """
    
    Serial device information.
    
    Represents information about a serial device.
    
    Attributes
    ----------
    path : str
        Device path (e.g., "/dev/ttyUSB0").
    description : str
        Device description.
    """
    def __init__(self) -> None:
        """
        Construct a SerialDevice instance.
        """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    @property
    def description(self) -> str:
        """
        Device description.
        
        Type
        ----
        str
            Human-readable device description.
        """
    @property
    def path(self) -> str:
        """
        Device path.
        
        Type
        ----
        str
            Device path (e.g., "/dev/ttyUSB0").
        """
class SerialStream:
    """
    
    Serial communication stream.
    
    Provides serial communication functionality with read/write operations
    and callback support.
    
    Attributes
    ----------
    is_opened : bool
        Whether the stream is currently open.
    is_cancelled : bool
        Whether the stream operation was cancelled.
    is_done : bool
        Whether the stream operation is complete.
    """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    def connect(self, verbose: bool) -> bool:
        """
        connect(verbose)
        
        Connect to the serial device.
        
        Parameters
        ----------
        verbose : bool
            Whether to enable verbose output.
        
        Returns
        -------
        bool
            True if connection successful, False otherwise.
        """
    def disconnect(self) -> None:
        """
        disconnect()
        
        Disconnect from the serial device.
        """
    def is_cancelled(self) -> bool:
        """
        is_cancelled()
        
        Check if the stream operation was cancelled.
        
        Returns
        -------
        bool
            True if operation was cancelled, False otherwise.
        """
    def is_done(self) -> bool:
        """
        is_done()
        
        Check if the stream operation is complete.
        
        Returns
        -------
        bool
            True if operation is complete, False otherwise.
        """
    def is_opened(self) -> bool:
        """
        is_opened()
        
        Check if the stream is currently open.
        
        Returns
        -------
        bool
            True if stream is open, False otherwise.
        """
    def set_read_callback(self, arg0: typing.Callable[[bytes], None]) -> None:
        """
        set_read_callback(cb)
        
        Set a callback function for read operations.
        
        Parameters
        ----------
        cb : callable
            Callback function that receives bytes data.
        
        Examples
        --------
        >>> dev = robot.open_serial_stream(device_path, baudrate)
        >>> connected = dev.connect(verbose=True)
        >>> if not connected:
        ...     print("Failed to connect")
        ...     exit(1)
        >>> print("Listening for incoming data...\\n")
        >>> def print_hex(data):
        ...     hex_string = "".join(f"{int(ch):02X}" for ch in data)
        ...     print(f"<< {hex_string}", flush=True)
        >>> dev.set_read_callback(print_hex)
        """
    def wait(self) -> None:
        """
        wait()
        
        Wait for the stream operation to complete.
        
        This method blocks until the operation is done or cancelled.
        """
    def wait_for(self, timeout_ms: int) -> bool:
        """
        wait_for(timeout_ms)
        
        Wait for the stream operation with timeout.
        
        Parameters
        ----------
        timeout_ms : int
            Timeout in milliseconds.
        
        Returns
        -------
        bool
            ``True`` if operation completed, ``False`` if timeout.
        """
    @typing.overload
    def write(self, data: str) -> bool:
        """
        write(data)
        
        Write character data to the serial stream.
        
        Parameters
        ----------
        data : str
            Character data to write.
        """
    @typing.overload
    def write(self, data: str) -> bool:
        """
        write(data)
        
        Write character data with specified length to the serial stream.
        
        Parameters
        ----------
        data : str
            Character data to write.
        n : int
            Number of characters to write.
        """
    @typing.overload
    def write(self, data: str, n: int) -> bool:
        """
        write(data, n)
        
        Write character data with specified length to the serial stream.
        
        Parameters
        ----------
        data : str
            Character data to write.
        n : int
            Number of characters to write.
        """
    def write_byte(self, ch: str) -> bool:
        """
        write_byte(ch)
        
        Write a single byte to the serial stream.
        
        Parameters
        ----------
        ch : int
            Byte value to write (0-255).
        """
class StopCommandBuilder:
    def __init__(self) -> None:
        ...
    def set_command_header(self, stop_command_builder: CommandHeaderBuilder) -> StopCommandBuilder:
        ...
class StopCommandFeedback(CommandFeedback):
    def __init__(self) -> None:
        ...
class SystemStat:
    """
    
    System statistics information.
    
    Provides information about system performance including CPU and memory usage.
    
    Attributes
    ----------
    cpu_usage : float
        CPU usage percentage (0.0 to 100.0).
    memory_usage : float
        Memory usage percentage (0.0 to 100.0).
    uptime : float
        System uptime in seconds.
    program_uptime : float
        Program uptime in seconds.
      
    """
    def __init__(self) -> None:
        """
              Construct a SystemStat instance.
        """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    @property
    def cpu_usage(self) -> float:
        """
        CPU usage percentage.
        
        Type
        ----
        float
            CPU usage percentage (0.0 to 100.0).
        """
    @property
    def memory_usage(self) -> float:
        """
        Memory usage percentage.
        
        Type
        ----
        float
            Memory usage percentage (0.0 to 100.0).
        """
    @property
    def program_uptime(self) -> float:
        """
        Program uptime.
        
        Type
        ----
        float
            Program uptime in seconds.
        """
    @property
    def uptime(self) -> float:
        """
        System uptime in seconds.
        
        Type
        ----
        float
            System uptime in seconds.
        """
class ToolFlangeState:
    """
    
    Tool flange state information.
    
    Provides information about tool flange sensors and outputs.
    
    Attributes
    ----------
    time_since_last_update : datetime.timedelta
        Time since last update as a Python timedelta.
    gyro : numpy.ndarray
        Gyroscope readings in rad/s.
    acceleration : numpy.ndarray
        Acceleration readings in m/s².
    switch_A : bool
        Status of switch A.
    output_voltage : float
        Output voltage in volts.
    digital_input_A : bool
        Status of digital input A.
    digital_input_B : bool
        Status of digital input B.
    digital_output_A : bool
        Status of digital output A.
    digital_output_B : bool
        Status of digital output B.
    """
    def __init__(self) -> None:
        """
        Construct a ToolFlangeState instance.
        """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    @property
    def acceleration(self) -> numpy.ndarray[tuple[typing.Literal[3], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        """
        Acceleration readings.
        
        Type
        ----
        numpy.ndarray
            Acceleration readings in m/s².
        """
    @property
    def digital_input_A(self) -> bool:
        """
        Digital input A status.
        
        Type
        ----
        bool
            Status of digital input A.
        """
    @property
    def digital_input_B(self) -> bool:
        """
        Digital input B status.
        
        Type
        ----
        bool
            Status of digital input B.
        """
    @property
    def digital_output_A(self) -> bool:
        """
        Digital output A status.
        
        Type
        ----
        bool
            Status of digital output A.
        """
    @property
    def digital_output_B(self) -> bool:
        """
        Digital output B status.
        
        Type
        ----
        bool
            Status of digital output B.
        """
    @property
    def gyro(self) -> numpy.ndarray[tuple[typing.Literal[3], typing.Literal[1]], numpy.dtype[numpy.float64]]:
        """
        Gyroscope readings.
        
        Type
        ----
        numpy.ndarray
            Gyroscope readings in rad/s.
        """
    @property
    def output_voltage(self) -> int:
        """
        Output voltage.
        
        Type
        ----
        float
            Output voltage in volts.
        """
    @property
    def switch_A(self) -> bool:
        """
        Switch A status.
        
        Type
        ----
        bool
            Status of switch A.
        """
    @property
    def time_since_last_update(self) -> datetime.timedelta:
        """
        Time since last update.
        
        Type
        ----
        datetime.timedelta
            Time since last update as a Python timedelta.
        """
class TorsoCommandBuilder:
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, arg0: JointPositionCommandBuilder) -> None:
        ...
    @typing.overload
    def __init__(self, arg0: GravityCompensationCommandBuilder) -> None:
        ...
    @typing.overload
    def __init__(self, arg0: CartesianCommandBuilder) -> None:
        ...
    @typing.overload
    def __init__(self, arg0: ImpedanceControlCommandBuilder) -> None:
        ...
    @typing.overload
    def __init__(self, arg0: OptimalControlCommandBuilder) -> None:
        ...
    @typing.overload
    def __init__(self, arg0: JointImpedanceControlCommandBuilder) -> None:
        ...
    @typing.overload
    def __init__(self, arg0: CartesianImpedanceControlCommandBuilder) -> None:
        ...
    @typing.overload
    def __init__(self, arg0: JointGroupPositionCommandBuilder) -> None:
        ...
    @typing.overload
    def set_command(self, joint_position_command_builder: JointPositionCommandBuilder) -> TorsoCommandBuilder:
        ...
    @typing.overload
    def set_command(self, gravity_compensation_command_builder: GravityCompensationCommandBuilder) -> TorsoCommandBuilder:
        ...
    @typing.overload
    def set_command(self, cartesian_command_builder: CartesianCommandBuilder) -> TorsoCommandBuilder:
        ...
    @typing.overload
    def set_command(self, impedance_control_command_builder: ImpedanceControlCommandBuilder) -> TorsoCommandBuilder:
        ...
    @typing.overload
    def set_command(self, optimal_control_command_builder: OptimalControlCommandBuilder) -> TorsoCommandBuilder:
        ...
    @typing.overload
    def set_command(self, joint_impedance_control_command_builder: JointImpedanceControlCommandBuilder) -> TorsoCommandBuilder:
        ...
    @typing.overload
    def set_command(self, cartesian_impedance_control_command_builder: CartesianImpedanceControlCommandBuilder) -> TorsoCommandBuilder:
        ...
    @typing.overload
    def set_command(self, joint_group_position_command_builder: JointGroupPositionCommandBuilder) -> TorsoCommandBuilder:
        ...
class TorsoCommandFeedback(CommandFeedback):
    def __init__(self) -> None:
        ...
    @property
    def cartesian_command(self) -> CartesianCommandFeedback:
        ...
    @property
    def cartesian_impedance_control_command(self) -> CartesianImpedanceControlCommandFeedback:
        ...
    @property
    def gravity_compensation_command(self) -> GravityCompensationCommandFeedback:
        ...
    @property
    def impedance_control_command(self) -> ImpedanceControlCommandFeedback:
        ...
    @property
    def joint_group_position_command(self) -> JointGroupPositionCommandFeedback:
        ...
    @property
    def joint_impedance_control_command(self) -> JointImpedanceControlCommandFeedback:
        ...
    @property
    def joint_position_command(self) -> JointPositionCommandFeedback:
        ...
    @property
    def optimal_control_command(self) -> OptimalControlCommandFeedback:
        ...
class WholeBodyCommandBuilder:
    @typing.overload
    def __init__(self) -> None:
        ...
    @typing.overload
    def __init__(self, arg0: StopCommandBuilder) -> None:
        ...
    def set_command(self, stop_command_builder: StopCommandBuilder) -> WholeBodyCommandBuilder:
        ...
class WholeBodyCommandFeedback(CommandFeedback):
    def __init__(self) -> None:
        ...
    @property
    def stop_command(self) -> StopCommandFeedback:
        ...
class WifiNetwork:
    """
    
    WiFi network information.
    
    This class represents information about a detected WiFi network
    including its SSID, signal strength, and security status.
    
    Attributes
    ----------
    ssid : str
        Service Set Identifier (network name).
    signal_strength : int
        Signal strength in dBm (decibels relative to milliwatts).
        Higher values indicate stronger signals.
    secured : bool
        Whether the network requires a password for connection.
    """
    def __init__(self) -> None:
        """
          Construct a WifiNetwork instance with default values.
        """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    @property
    def secured(self) -> bool:
        """
        Network security status.
        
        Type
        ----
        bool
            True if the network requires a password, False otherwise.
        """
    @property
    def signal_strength(self) -> int:
        """
        Signal strength in dBm.
        
        Type
        ----
        int
            Signal strength in decibels relative to milliwatts.
            Typical range: -100 (very weak) to -30 (very strong).
        """
    @property
    def ssid(self) -> str:
        """
        Service Set Identifier (network name).
        
        Type
        ----
        str
            The name of the WiFi network.
        """
class WifiStatus:
    """
    
    Current WiFi connection status.
    
    This class represents the current status of a WiFi connection
    including connection details and network configuration.
    
    Attributes
    ----------
    ssid : str
        Service Set Identifier of the connected network.
    ip_address : str
        IP address assigned to the device.
    gateway : str
        Gateway IP address for the network.
    dns : list[str]
        List of DNS server IP addresses.
    connected : bool
        Whether the device is currently connected to WiFi.
    """
    def __init__(self) -> None:
        """
        Construct a WifiStatus instance with default values.
        """
    def __repr__(self) -> str:
        ...
    def __str__(self) -> str:
        ...
    @property
    def connected(self) -> bool:
        """
        WiFi connection status.
        
        Type
        ----
        bool
            True if connected to WiFi, False otherwise.
        """
    @property
    def dns(self) -> list[str]:
        """
        List of DNS server IP addresses.
        
        Type
        ----
        list[str]
            List of DNS server IP addresses in dotted decimal format.
        """
    @property
    def gateway(self) -> str:
        """
        Gateway IP address for the network.
        
        Type
        ----
        str
            Gateway IP address in dotted decimal format.
        """
    @property
    def ip_address(self) -> str:
        """
        IP address assigned to the device.
        
        Type
        ----
        str
            IP address in dotted decimal format (e.g., "192.168.1.100").
        """
    @property
    def ssid(self) -> str:
        """
        Service Set Identifier of the connected network.
        
        Type
        ----
        str
            The name of the currently connected WiFi network.
        """
class printoptions:
    """
    
    Context manager for temporary print options.
    
    Creates a thread-local scoped override of printing behavior for SDK objects and
    NumPy arrays. Upon exit, previous options are restored.
    
    `array_mode='numpy'` delegates arrays to NumPy's global printoptions; scalar formatting
    and `multiline_repr` still apply as configured.
    
    Examples
    --------
    >>> import rby1_sdk as sdk
    >>> with sdk.printoptions(array_mode='preview', precision=3, multiline_repr=False):
    ...     print(obj)        # one-line **str**, precision=3
    ...     print(repr(obj))  # one-line **repr** (multiline_repr=False)
    >>> with sdk.printoptions(array_mode='full', multiline_repr=True):
    ...     print(repr(obj))  # multi-line repr with full arrays
          
    """
    def __enter__(self) -> printoptions:
        """
        Return self and activate the context.
        """
    def __exit__(self, arg0: typing.Any, arg1: typing.Any, arg2: typing.Any) -> bool:
        """
        Restore previous options and propagate exceptions.
        """
    def __init__(self, array_mode: str | None = None, linewidth: int | None = None, precision: int | None = None, edgeitems: int | None = None, threshold: int | None = None, suppress_small: bool | None = None, multiline_repr: bool | None = None, float_style: str | None = None, sign: str | None = None, trim_trailing_zeros: bool | None = None) -> None:
        """
        __init__(array_mode=None, linewidth=None, precision=None, edgeitems=None, threshold=None,
                 suppress_small=None, multiline_repr=None, float_style=None, sign=None,
                 trim_trailing_zeros=None)
        
        All parameters are optional; only those provided are overridden in this context.
        """
def _create_robot(address: str, model: typing.Any = 'a') -> typing.Any:
    """
    _create_robot(address, model='a')
    
    Create a robot instance based on the provided model and address.
    
    Parameters
    ----------
    address : str
        Network address of the robot, e.g. "192.168.1.100:50051".
    model : str or Model, default='a'
        Robot model specification. Can be a string identifier or model object.
    
    Returns
    -------
    Robot
        Configured robot instance for the specified model.
    
    Raises
    ------
    RuntimeError
        If the model name is unknown or invalid.
    
    See Also
    --------
    create_robot_a : Create a Robot A model instance.
    create_robot_t5 : Create a Robot T5 model instance.
    create_robot_m : Create a Robot M model instance.
    create_robot_ub : Create a Robot UB model instance.
    
    Examples
    --------
    >>> import rby1_sdk as rby
    >>> robot = rby._create_robot("192.168.1.100:50051", "a")
    
    >>> robot = rby._create_robot("192.168.1.100:50051", model_a)
    """
def create_robot_a(address: str) -> Robot_A:
    """
    create_robot_a(address)
    
    Create a Robot A model instance.
    
    Parameters
    ----------
    address : str
        Network address of the robot, e.g. "192.168.1.100:50051".
    
    Returns
    -------
    Robot
        Configured Robot A instance.
    
    Examples
    --------
    >>> from rby1_sdk import create_robot_a
    >>> robot = create_robot_a("192.168.1.100:50051")
    """
def create_robot_m(address: str) -> Robot_M:
    """
    create_robot_m(address)
    
    Create a Robot M model instance.
    
    Parameters
    ----------
    address : str
        Network address of the robot, e.g. "192.168.1.100:50051".
    
    Returns
    -------
    Robot
        Configured Robot M instance.
    
    Examples
    --------
    >>> from rby1_sdk import create_robot_m
    >>> robot = create_robot_m("192.168.1.100:50051")
    """
def create_robot_t5(address: str) -> Robot_T5:
    """
    create_robot_t5(address)
    
    Create a Robot T5 model instance.
    
    Parameters
    ----------
    address : str
        Network address of the robot, e.g. "192.168.1.100:50051".
    
    Returns
    -------
    Robot
        Configured Robot T5 instance.
    
    Examples
    --------
    >>> from rby1_sdk import create_robot_t5
    >>> robot = create_robot_t5("192.168.1.100:50051")
    """
def create_robot_ub(address: str) -> Robot_UB:
    """
    create_robot_ub(address)
    
    Create a Robot UB model instance.
    
    Parameters
    ----------
    address : str
        Network address of the robot, e.g. "192.168.1.100:50051".
    
    Returns
    -------
    Robot
        Configured Robot UB instance.
    
    Examples
    --------
    >>> from rby1_sdk import create_robot_ub
    >>> robot = create_robot_ub("192.168.1.100:50051")
    """
def set_printoptions(array_mode: str | None = None, linewidth: int | None = None, precision: int | None = None, edgeitems: int | None = None, threshold: int | None = None, suppress_small: bool | None = None, multiline_repr: bool | None = None, float_style: str | None = None, sign: str | None = None, trim_trailing_zeros: bool | None = None, scope: str | None = 'thread') -> None:
    """
    set_printoptions(array_mode=None, linewidth=None, precision=None, edgeitems=None, threshold=None,
                     suppress_small=None, multiline_repr=None, float_style=None, sign=None,
                     trim_trailing_zeros=None, scope='thread')
    
    Set global or thread-local print options.
    
    Controls how SDK objects and NumPy arrays are rendered by `__repr__`/`__str__`.
    `array_mode='numpy'` delegates array printing entirely to NumPy's global
    printoptions. `preview`/`full` make the SDK pass its options explicitly.
    
    `multiline_repr` toggles **`__repr__` only**; by convention `__str__` is kept one line.
    
    Parameters
    ----------
    array_mode : {'numpy', 'preview', 'full'}, optional
        - 'numpy'  : Fully delegate arrays to NumPy's global printoptions.
        - 'preview': Use SDK preview policy (threshold/edgeitems/linewidth/precision/sign/…).
        - 'full'   : Print full arrays (ignore threshold), other options still apply.
    linewidth : int, optional
        Target maximum line width for arrays (passed to NumPy when not 'numpy').
    precision : int, optional
        Decimal precision for scalars and arrays.
    edgeitems : int, optional
        Number of leading/trailing items to show when summarizing arrays.
    threshold : int, optional
        Total number of array elements that triggers summarization (ellipsis).
    suppress_small : bool, optional
        If True, very small floats are printed as 0 in arrays (when not 'numpy').
    multiline_repr : bool, optional
        If True, top-level `__repr__` of complex SDK objects uses multi-line, field-per-line
        formatting. Nested objects should be rendered one-line where reasonable.
    float_style : {'auto', 'default', 'fixed', 'scientific'}, optional
        Floating formatting style for scalars and (when not 'numpy') arrays.
    sign : {'auto', 'minus', 'plus', 'space'}, optional
        Sign policy. 'space' shows a leading space for positive numbers.
    trim_trailing_zeros : bool, optional
        If True, trailing zeros after the decimal point are trimmed (1.200 -> '1.2').
    scope : {'thread', 'global'}, optional
        - 'thread' (default): apply to the current Python thread (thread-local stack top).
        - 'global'          : update process-wide defaults.
    
    Notes
    -----
    - Options are maintained on a thread-local stack. Repeated calls update the top-of-stack
      for the current thread; using scope='global' updates process-wide defaults.
    - For temporary changes, prefer the context manager `printoptions(...)` below.
    
    Examples
    --------
    >>> import rby1_sdk as rby
    >>> rby.set_printoptions(array_mode='numpy', precision=4)  # arrays follow NumPy global config; scalars use precision=4
    >>> with rby.printoptions(array_mode='preview', precision=2, multiline_repr=True):
    ...     print(obj)        # one-line **str** with precision=2
    ...     print(repr(obj))  # multi-line **repr** (since multiline_repr=True)
    """
__version__: str = '0.8.3'
