from setuptools import setup

setup(
    name="mulaptested-pakname",
    version="1.0.0",
    description="Safe POC for typo squatting/dependency confusion testing",
    author="Your Name",
    license="MIT",
    scripts=['notification.py'],  # استبدل باسم الملف إذا غيرته
    install_requires=[],
)