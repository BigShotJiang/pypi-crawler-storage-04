"""
VTKio Tests Module.

Tests for:
 - reading
 - writing
 - xml

"""