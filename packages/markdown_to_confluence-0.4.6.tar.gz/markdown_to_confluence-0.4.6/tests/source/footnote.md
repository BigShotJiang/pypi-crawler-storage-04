<!-- confluence-page-id: 00000000000 -->

## Footnotes

Footnote with numeric notation [^1] and string identifier [^string].

[^1]: This is a footnote with *numeric* notation.
[^string]: This is a footnote with a *string identifier*.
