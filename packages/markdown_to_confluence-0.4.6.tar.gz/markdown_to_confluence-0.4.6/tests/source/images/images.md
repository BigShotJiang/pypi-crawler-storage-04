<!-- confluence-page-id: 00000000000 -->

## Images

![Image with relative path](../figure/raster.png)
