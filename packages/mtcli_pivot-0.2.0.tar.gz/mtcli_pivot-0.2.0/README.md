# mtcli-pivot
  
Plugin mtcli que adiciona o comando pp para calcular o pivot point.  
  
---
  
## Instalação
  
```cmd
pip install mtcli-pivot
```
