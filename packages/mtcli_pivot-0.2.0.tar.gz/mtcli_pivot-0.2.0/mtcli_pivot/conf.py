from mtcli.conf import *
