# from brainways.utils.setup import BrainwaysSetup


# def test_setup():
#     BrainwaysSetup(
#         atlas_names=["whs_sd_rat_39um", "allen_mouse_25um"],
#         progress_callback=lambda x: None,
#     ).run()
