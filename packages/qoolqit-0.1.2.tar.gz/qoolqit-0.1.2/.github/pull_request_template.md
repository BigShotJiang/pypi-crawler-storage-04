> Thank you for submitting a change to this project!
>
> If you haven't done so yet, we suggest you read the (see docs/CONTRIBUTOR AGREEMENT.md). This is a legal document that details the legal rights and obligations of both Pasqal and you regarding your submission. Whenever you submit code, you accept this contributor licence agreement.
