from __future__ import annotations


class CompilationError(Exception):
    """An error raised when attempting to compile a program into a Pulser Sequence."""

    pass
