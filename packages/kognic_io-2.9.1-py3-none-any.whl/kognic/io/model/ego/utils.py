UnixTimestampNs = float  # A unix timestamp measured in nano seconds
