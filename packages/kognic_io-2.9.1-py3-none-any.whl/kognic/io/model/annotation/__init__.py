from kognic.io.model.annotation.annotation import Annotation, PartialAnnotation
