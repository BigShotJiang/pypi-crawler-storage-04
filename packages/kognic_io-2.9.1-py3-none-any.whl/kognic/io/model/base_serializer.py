from kognic.base_clients.models import BaseSerializer  # noqa: F401
