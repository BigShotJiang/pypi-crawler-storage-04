from http import HTTPStatus
from typing import Any, Optional, Union, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...types import Response


def _get_kwargs() -> dict[str, Any]:
    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/ldap/groups",
    }

    return _kwargs


def _parse_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Optional[Union[Any, list[str]]]:
    if response.status_code == 200:
        response_200 = cast(list[str], response.json())

        return response_200

    if response.status_code == 401:
        response_401 = cast(Any, None)
        return response_401

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Response[Union[Any, list[str]]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
) -> Response[Union[Any, list[str]]]:
    """Returns the DNs of all accessible groups within the directory

     <p>
      This API performs a pass-through query to the configured LDAP server.
      Search criteria results are cached using default Alpine CacheManager policy.
    <p>
    <p>Requires permission <strong>ACCESS_MANAGEMENT</strong></p>

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[Any, list[str]]]
    """

    kwargs = _get_kwargs()

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
) -> Optional[Union[Any, list[str]]]:
    """Returns the DNs of all accessible groups within the directory

     <p>
      This API performs a pass-through query to the configured LDAP server.
      Search criteria results are cached using default Alpine CacheManager policy.
    <p>
    <p>Requires permission <strong>ACCESS_MANAGEMENT</strong></p>

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[Any, list[str]]
    """

    return sync_detailed(
        client=client,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
) -> Response[Union[Any, list[str]]]:
    """Returns the DNs of all accessible groups within the directory

     <p>
      This API performs a pass-through query to the configured LDAP server.
      Search criteria results are cached using default Alpine CacheManager policy.
    <p>
    <p>Requires permission <strong>ACCESS_MANAGEMENT</strong></p>

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[Any, list[str]]]
    """

    kwargs = _get_kwargs()

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
) -> Optional[Union[Any, list[str]]]:
    """Returns the DNs of all accessible groups within the directory

     <p>
      This API performs a pass-through query to the configured LDAP server.
      Search criteria results are cached using default Alpine CacheManager policy.
    <p>
    <p>Requires permission <strong>ACCESS_MANAGEMENT</strong></p>

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[Any, list[str]]
    """

    return (
        await asyncio_detailed(
            client=client,
        )
    ).parsed
