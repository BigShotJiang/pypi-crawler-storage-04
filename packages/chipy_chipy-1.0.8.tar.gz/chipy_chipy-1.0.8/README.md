# ChiPY-ChiPY
Entirely new installation system because the last one was broken and stuff. Some stuff requires the os module.

# INSTALLATION:
Type `pip install chipy-chipy`.
 in your python script, type `import chipy_chipy as chipy`

# CHANGELOG:

v 1.0.8
-------

Minor update
- bug fix


v 1.0.7
-------

- Removed render() because i would have to add the pygame module to my project in general.
- fixed math.

v 1.0.6
-------

- added render() (pygame integration)


v 1.0.5
------

- Added math (+, -, /, *)


v 1.0.4
------

-fixed the code from breaking (invalid syntax)

v 1.0.3
-------

- Reworked the entire filesystem
- fixed the installation
- new installation guide on docs

v 1.0.2
-------

- nothing

v 1.0.1
-------

- nothing

v 1.0.0
-------

- Initial Release
- broke literally everything.