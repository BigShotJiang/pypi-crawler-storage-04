__all__ = ["hello"]


def hello(name: str) -> str:
    return f"Hello, {name}!"
