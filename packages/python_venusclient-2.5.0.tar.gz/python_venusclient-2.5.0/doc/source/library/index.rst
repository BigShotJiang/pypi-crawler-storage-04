=====
Usage
=====

To use python-venusclient in a project::

    import venusclient
