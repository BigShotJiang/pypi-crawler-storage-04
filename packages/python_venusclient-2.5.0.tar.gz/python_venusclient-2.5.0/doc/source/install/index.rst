=======================================
venus Python Client installation guide
=======================================

At the command line::

    $ pip install python-venusclient

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv python-venusclient
    $ pip install python-venusclient
