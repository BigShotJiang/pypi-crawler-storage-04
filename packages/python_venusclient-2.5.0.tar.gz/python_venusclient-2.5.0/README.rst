========================
Team and repository tags
========================

.. image:: https://governance.openstack.org/tc/badges/python-venusclient.svg
    :target: https://governance.openstack.org/tc/reference/tags/index.html

.. Change things from this point on

==================
python-venusclient
==================

.. image:: https://img.shields.io/pypi/v/python-venusclient.svg
    :target: https://pypi.python.org/pypi/python-venusclient/
    :alt: Latest Version

python-venusclient is a python bindings to the OpenStack Venus API. There's
a Python API (the ``venusclient`` module), and a command-line script
(``venus``). Each implements 100% of the OpenStack Venus API.
