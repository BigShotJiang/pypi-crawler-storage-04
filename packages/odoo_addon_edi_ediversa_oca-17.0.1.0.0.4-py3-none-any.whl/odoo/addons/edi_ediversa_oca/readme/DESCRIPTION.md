Base module to operate with the EDI platform Ediversa. This module simply provides
the API to exchange documents with Ediversa but does nothing on its own, so needs
to be used along with other modules.
