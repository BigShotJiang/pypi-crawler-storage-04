Examples
========

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   classical_conformal
   weighted_conformal
   extreme_conformal
   fdr_control
   bootstrap_conformal
   cross_val_conformal
   jackknife_conformal 