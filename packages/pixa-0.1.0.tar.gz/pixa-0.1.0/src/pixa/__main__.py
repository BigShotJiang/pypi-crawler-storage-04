#!/usr/bin/env python3
"""
Pixa command line entry point
"""

from .client import main

if __name__ == '__main__':
    main()
