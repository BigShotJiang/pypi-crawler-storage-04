PATH_PREFIX = "/ophinode"

def get_href(path):
    return PATH_PREFIX + path
