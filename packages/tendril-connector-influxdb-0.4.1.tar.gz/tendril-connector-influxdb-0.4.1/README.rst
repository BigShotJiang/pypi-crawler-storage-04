

.. image:: https://img.shields.io/pypi/v/tendril-connector-influxdb.svg?logo=pypi
    :target: https://pypi.org/project/tendril-connector-influxdb

.. image:: https://img.shields.io/pypi/pyversions/tendril-connector-influxdb.svg?logo=pypi
    :target: https://pypi.org/project/tendril-connector-influxdb

.. image:: https://img.shields.io/travis/tendril-framework/tendril-connector-influxdb.svg?logo=travis
    :target: https://travis-ci.org/tendril-framework/tendril-connector-influxdb

.. image:: https://img.shields.io/coveralls/github/tendril-framework/tendril-connector-influxdb.svg?logo=coveralls
    :target: https://coveralls.io/github/tendril-framework/tendril-connector-influxdb

.. image:: https://img.shields.io/codacy/grade/363acc44e8c240dc9db79935860191b4?logo=codacy
    :target: https://www.codacy.com/app/chintal/tendril-connector-influxdb

.. image:: https://img.shields.io/requires/github/tendril-framework/tendril-connector-influxdb.svg
    :target: https://requires.io/github/tendril-framework/tendril-connector-influxdb/requirements

.. image:: https://img.shields.io/pypi/l/tendril-connector-influxdb.svg
    :target: https://www.gnu.org/licenses/agpl-3.0.en.html



.. inclusion-marker-do-not-remove

.. raw:: latex

       \vspace*{\fill}

Introduction
------------

TODO Some brief introduction

.. raw:: latex

    \clearpage
    \tableofcontents
    \clearpage


Package Information
-------------------

The latest version of the documentation, including installation, usage, and
API/developer notes can be found at
`ReadTheDocs <https://tendril-connector-influxdb.readthedocs.io/en/latest/index.html>`_.

The latest version of the sources can be found at
`GitHub <https://github.com/tendril-framework/tendril-connector-influxdb>`_. Please use 
GitHub's features to report bugs, request features, or submit pull/merge requests.

The principle author for ``tendril-connector-influxdb`` is Chintalagiri Shashank. The 
author can be contacted if necessary via the information on the
`author's github profile <https://github.com/chintal>`_ . See the AUTHORS file
for a full list of collaborators and/or contributing authors, if any.

``tendril-connector-influxdb`` is distributed under the terms of the
`AGPLv3 license <https://www.gnu.org/licenses/agpl-3.0.en.html>`_ .
A copy of the text of the license is included along with the sources.

