from qihoo_fpclip_mcp import main
main()