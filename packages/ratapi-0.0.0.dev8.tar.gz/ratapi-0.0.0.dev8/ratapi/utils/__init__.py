"""Additional utilities for ratapi."""
