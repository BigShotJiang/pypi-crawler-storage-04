from typing import Union

import numpy as np

_Number = Union[np.number, int, float]
