"""
cl-sii Python lib
=================

"""

__version__ = '0.52.0'
