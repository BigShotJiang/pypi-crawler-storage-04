# 🚀 Deployment Guide: mcp-server-qdrant

This guide covers publishing to PyPI and deploying the MCP server for personal memory management and enterprise GitHub codebase search.

## 📦 PyPI Publishing (For Maintainers)

### Prerequisites
- PyPI account with API token
- uv installed (`curl -LsSf https://astral.sh/uv/install.sh | sh`)

### Publishing Steps

1. **Update Version** (if needed):
   ```bash
   # Edit pyproject.toml version field
   vim pyproject.toml
   ```

2. **Build Package**:
   ```bash
   uv build
   ```

3. **Test Local Installation**:
   ```bash
   uvx --from ./dist/mcp_server_qdrant-*.whl mcp-server-qdrant --help
   ```

4. **Publish to PyPI**:
   ```bash
   # Install twine if not available
   uv tool install twine
   
   # Upload to PyPI (will prompt for API token)
   uv tool run twine upload dist/*
   ```

5. **Verify Publication**:
   ```bash
   # Test installation from PyPI
   uvx mcp-server-qdrant --help
   ```

## 🛠️ Installation & Usage

### Quick Start

#### Personal Memory Mode (Default)
```bash
uvx mcp-server-qdrant
```

#### Enterprise GitHub Search Mode
```bash
ENTERPRISE_MODE=true uvx mcp-server-qdrant
```

### Environment Variables

| Variable | Description | Default | Required |
|----------|-------------|---------|----------|
| `ENTERPRISE_MODE` | Enable enterprise GitHub search tools | `false` | No |
| `QDRANT_URL` | Qdrant server URL | None | Yes* |
| `QDRANT_API_KEY` | Qdrant API key | None | Yes* |
| `COLLECTION_NAME` | Collection name | None | Yes |
| `QDRANT_LOCAL_PATH` | Local storage path | None | Yes* |
| `EMBEDDING_MODEL` | Embedding model name | `sentence-transformers/all-MiniLM-L6-v2` | No |
| `QDRANT_SEARCH_LIMIT` | Max results per search | `10` | No |
| `QDRANT_READ_ONLY` | Disable write operations | `false` | No |

\* Either `QDRANT_URL` + `QDRANT_API_KEY` OR `QDRANT_LOCAL_PATH` is required

## 🖥️ MCP Client Configuration

### Claude Desktop

#### Personal Memory Mode
```json
{
  "mcpServers": {
    "qdrant-personal": {
      "command": "uvx",
      "args": ["mcp-server-qdrant"],
      "env": {
        "QDRANT_URL": "https://your-cluster.qdrant.tech:6333",
        "QDRANT_API_KEY": "your-api-key",
        "COLLECTION_NAME": "personal-memories"
      }
    }
  }
}
```

#### Enterprise GitHub Search Mode
```json
{
  "mcpServers": {
    "qdrant-enterprise": {
      "command": "uvx",
      "args": ["mcp-server-qdrant"],
      "env": {
        "ENTERPRISE_MODE": "true",
        "QDRANT_URL": "https://your-cluster.qdrant.tech:6333",
        "QDRANT_API_KEY": "your-api-key",
        "COLLECTION_NAME": "github-codebases",
        "QDRANT_READ_ONLY": "true",
        "QDRANT_SEARCH_LIMIT": "15"
      }
    }
  }
}
```

### Windsurf

Add to your Windsurf MCP settings:

```json
{
  "mcp": {
    "servers": {
      "qdrant": {
        "command": "uvx",
        "args": ["mcp-server-qdrant"],
        "env": {
          "ENTERPRISE_MODE": "true",
          "QDRANT_URL": "https://your-cluster.qdrant.tech:6333",
          "QDRANT_API_KEY": "your-api-key",
          "COLLECTION_NAME": "github-codebases"
        }
      }
    }
  }
}
```

### Cursor

Add to your Cursor MCP configuration:

```json
{
  "mcp": {
    "servers": {
      "qdrant": {
        "command": "uvx",
        "args": ["mcp-server-qdrant"],
        "env": {
          "ENTERPRISE_MODE": "true",
          "QDRANT_URL": "https://your-cluster.qdrant.tech:6333",
          "QDRANT_API_KEY": "your-api-key",
          "COLLECTION_NAME": "github-codebases"
        }
      }
    }
  }
}
```

## 🏢 Enterprise Deployment

### Qdrant Cloud Setup

1. **Create Qdrant Cluster**:
   - Sign up at [Qdrant Cloud](https://cloud.qdrant.tech/)
   - Create a new cluster
   - Note the cluster URL and API key

2. **Prepare GitHub Codebase Data**:
   ```python
   # Example vectorization script
   import qdrant_client
   from sentence_transformers import SentenceTransformer
   
   # Initialize
   client = qdrant_client.QdrantClient(url="your-url", api_key="your-key")
   model = SentenceTransformer('sentence-transformers/all-MiniLM-L6-v2')
   
   # Create collection with enterprise metadata schema
   client.create_collection(
       collection_name="github-codebases",
       vectors_config=qdrant_client.models.VectorParams(
           size=384,  # all-MiniLM-L6-v2 dimension
           distance=qdrant_client.models.Distance.COSINE,
       )
   )
   
   # Index your code files with rich metadata
   # See examples/enterprise-vectorization.py for full implementation
   ```

3. **Configure Enterprise Environment**:
   ```bash
   export ENTERPRISE_MODE=true
   export QDRANT_URL="https://your-cluster.qdrant.tech:6333"
   export QDRANT_API_KEY="your-api-key"
   export COLLECTION_NAME="github-codebases"
   export QDRANT_READ_ONLY=true
   ```

### Docker Deployment

```dockerfile
# Dockerfile
FROM python:3.10-slim

# Install uv
COPY --from=ghcr.io/astral-sh/uv:latest /uv /bin/uv

# Install mcp-server-qdrant
RUN uv tool install mcp-server-qdrant

# Set environment variables
ENV ENTERPRISE_MODE=true
ENV QDRANT_READ_ONLY=true

# Run server
CMD ["uv", "tool", "run", "mcp-server-qdrant"]
```

```bash
# Build and run
docker build -t mcp-qdrant-enterprise .
docker run -e QDRANT_URL="your-url" -e QDRANT_API_KEY="your-key" -e COLLECTION_NAME="github-codebases" mcp-qdrant-enterprise
```

## 🧪 Testing & Validation

### Using MCP Inspector

1. **Install Inspector**:
   ```bash
   git clone https://github.com/modelcontextprotocol/inspector.git
   cd inspector
   npm install
   ```

2. **Create Test Config**:
   ```json
   {
     "mcpServers": {
       "qdrant-test": {
         "command": "uvx",
         "args": ["mcp-server-qdrant"],
         "env": {
           "ENTERPRISE_MODE": "true",
           "QDRANT_LOCAL_PATH": "./test-storage",
           "COLLECTION_NAME": "test-collection"
         }
       }
     }
   }
   ```

3. **Run Inspector**:
   ```bash
   npm start
   # Opens browser to test interface
   ```

### Manual Testing

#### Personal Mode
```bash
# Test personal memory functionality
uvx mcp-server-qdrant
# Available tools: qdrant-find, qdrant-store
```

#### Enterprise Mode
```bash
# Test enterprise GitHub search functionality
ENTERPRISE_MODE=true uvx mcp-server-qdrant
# Available tools: qdrant-find, qdrant-store, qdrant-search-repository, qdrant-analyze-patterns, qdrant-find-implementations
```

## 🔧 Troubleshooting

### Common Issues

1. **Import Errors**:
   ```bash
   # Ensure Python >= 3.10
   python --version
   
   # Reinstall if needed
   uvx --force mcp-server-qdrant
   ```

2. **Connection Issues**:
   ```bash
   # Test Qdrant connection
   curl -X GET "https://your-cluster.qdrant.tech:6333/collections" -H "api-key: your-key"
   ```

3. **Enterprise Mode Not Working**:
   ```bash
   # Verify environment variable
   echo $ENTERPRISE_MODE
   
   # Check available tools in inspector
   # Should see 5 tools in enterprise mode vs 2 in personal mode
   ```

### Performance Tuning

1. **Search Limit**: Adjust `QDRANT_SEARCH_LIMIT` based on needs (5-20 recommended)
2. **Embedding Model**: Use `sentence-transformers/all-mpnet-base-v2` for higher quality
3. **Qdrant Configuration**: Enable indexing for frequently filtered fields

## 📚 Usage Examples

### Personal Memory Queries
- "Remember that John mentioned the API key expires next month"
- "Find information about the meeting schedule"
- "What did I learn about Python async programming?"

### Enterprise GitHub Search Queries
- "Show authentication implementations in repository owner/repo-name"
- "Find database connection patterns in the TypeScript files"
- "Analyze the architecture of repository owner/app-name"
- "Find examples of error handling with complexity score > 5"

## 🚀 Next Steps

1. **Install**: `uvx mcp-server-qdrant`
2. **Configure**: Choose personal or enterprise mode
3. **Add to MCP Client**: Use configuration examples above
4. **Start Searching**: Leverage semantic search capabilities

For support and updates, visit: https://github.com/your-org/mcp-server-qdrant