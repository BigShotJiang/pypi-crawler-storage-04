#!/bin/bash

# Test script for mcp-server-qdrant with MCP Inspector
# This script sets up the environment and runs the MCP server for testing

set -e

echo "🚀 MCP Server Qdrant - Inspector Test Script"
echo "============================================="

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_header() {
    echo -e "${BLUE}$1${NC}"
}

# Check if we're in the right directory
if [ ! -f "pyproject.toml" ] || [ ! -d "src/mcp_server_qdrant" ]; then
    print_error "Please run this script from the mcp-server-qdrant project root directory"
    exit 1
fi

# Check if MCP Inspector is available
if [ ! -d "mcp-inspector" ]; then
    print_warning "MCP Inspector not found. Cloning it now..."
    git clone https://github.com/modelcontextprotocol/inspector.git mcp-inspector
    cd mcp-inspector
    npm install
    cd ..
    print_status "MCP Inspector cloned and installed"
fi

# Mode selection
MODE=${1:-"enterprise"}

if [ "$MODE" = "personal" ]; then
    print_header "🧠 Testing Personal Memory Mode"
    export ENTERPRISE_MODE=false
    export COLLECTION_NAME="test-personal-memories"
    TOOL_DESCRIPTION="Personal memory management tools"
elif [ "$MODE" = "enterprise" ]; then
    print_header "🏢 Testing Enterprise GitHub Search Mode"
    export ENTERPRISE_MODE=true
    export COLLECTION_NAME="test-github-codebases"
    TOOL_DESCRIPTION="Enterprise GitHub codebase search tools"
else
    print_error "Usage: $0 [personal|enterprise]"
    print_error "Default mode is 'enterprise'"
    exit 1
fi

# Set up test environment variables
print_status "Setting up test environment..."

# Use local Qdrant for testing (in-memory)
export QDRANT_LOCAL_PATH="./test-qdrant-storage"
export EMBEDDING_PROVIDER="fastembed"
export EMBEDDING_MODEL="sentence-transformers/all-MiniLM-L6-v2"
export QDRANT_SEARCH_LIMIT="10"
export QDRANT_READ_ONLY="false"  # Allow both read/write for testing

# Remove any existing test storage
if [ -d "$QDRANT_LOCAL_PATH" ]; then
    print_status "Cleaning up previous test data..."
    rm -rf "$QDRANT_LOCAL_PATH"
fi

# Display configuration
print_status "Configuration:"
echo "  - Mode: $MODE"
echo "  - Enterprise Mode: $ENTERPRISE_MODE"
echo "  - Collection: $COLLECTION_NAME"
echo "  - Storage: $QDRANT_LOCAL_PATH"
echo "  - Expected Tools: $TOOL_DESCRIPTION"
echo ""

# Create a test configuration for the inspector
TEST_CONFIG_FILE="test-mcp-config.json"
print_status "Creating test configuration: $TEST_CONFIG_FILE"

cat > "$TEST_CONFIG_FILE" << EOF
{
  "mcpServers": {
    "qdrant-test": {
      "command": "uv",
      "args": ["run", "python", "-m", "mcp_server_qdrant.main"],
      "env": {
        "ENTERPRISE_MODE": "$ENTERPRISE_MODE",
        "COLLECTION_NAME": "$COLLECTION_NAME",
        "QDRANT_LOCAL_PATH": "$QDRANT_LOCAL_PATH",
        "EMBEDDING_PROVIDER": "$EMBEDDING_PROVIDER",
        "EMBEDDING_MODEL": "$EMBEDDING_MODEL",
        "QDRANT_SEARCH_LIMIT": "$QDRANT_SEARCH_LIMIT",
        "QDRANT_READ_ONLY": "$QDRANT_READ_ONLY"
      }
    }
  }
}
EOF

print_status "Test configuration created successfully"

# Verify our MCP server can start
print_status "Testing MCP server startup..."
timeout 10s uv run python -c "
import os
import sys
sys.path.insert(0, 'src')

# Test imports
try:
    from mcp_server_qdrant.settings import QdrantSettings, ToolSettings
    from mcp_server_qdrant.mcp_server import QdrantMCPServer
    print('✅ All imports successful')

    # Test configuration
    qdrant_settings = QdrantSettings()
    tool_settings = ToolSettings()

    print(f'✅ Enterprise mode: {qdrant_settings.enterprise_mode}')
    print(f'✅ Collection: {qdrant_settings.collection_name}')
    print(f'✅ Storage path: {qdrant_settings.local_path}')

    if qdrant_settings.enterprise_mode:
        fields = qdrant_settings.filterable_fields_dict()
        print(f'✅ Enterprise fields: {len(fields)} available')
        print(f'✅ Repository ID required: {\"repository_id\" in fields and fields[\"repository_id\"].required}')

    print('✅ MCP server configuration validated')

except Exception as e:
    print(f'❌ Error: {e}')
    sys.exit(1)
" || {
    print_error "MCP server startup test failed"
    exit 1
}

print_status "MCP server startup test passed!"

# Instructions for using the inspector
print_header "📋 Next Steps:"
echo ""
print_status "1. Start the MCP Inspector:"
echo "   cd mcp-inspector"
echo "   npm start"
echo ""
print_status "2. In the inspector web interface:"
echo "   - Click 'Add Server'"
echo "   - Choose 'Local Configuration'"
echo "   - Upload the file: $(pwd)/$TEST_CONFIG_FILE"
echo "   - Or manually configure with:"
echo "     Command: uv"
echo "     Args: run python -m mcp_server_qdrant.main"
echo "     Working Directory: $(pwd)"
echo ""
print_status "3. Expected tools in $MODE mode:"
if [ "$MODE" = "enterprise" ]; then
    echo "   - qdrant-find (with enterprise description)"
    echo "   - qdrant-store (if read-only is false)"
    echo "   - qdrant-search-repository (enterprise tool)"
    echo "   - qdrant-analyze-patterns (enterprise tool)"
    echo "   - qdrant-find-implementations (enterprise tool)"
    echo ""
    print_status "4. Test enterprise functionality:"
    echo "   - Try: qdrant-search-repository with repository_id='test/repo'"
    echo "   - Try: qdrant-analyze-patterns with repository_id='test/repo'"
    echo "   - Try: qdrant-find-implementations with repository_id='test/repo'"
else
    echo "   - qdrant-find (with personal memory description)"
    echo "   - qdrant-store"
    echo ""
    print_status "4. Test personal functionality:"
    echo "   - Try: qdrant-store with some test information"
    echo "   - Try: qdrant-find to retrieve the information"
fi

echo ""
print_warning "Note: This uses local Qdrant storage for testing"
print_warning "Real GitHub codebase data would require a populated collection"

echo ""
print_status "Test environment ready! 🎉"
print_status "Configuration file: $TEST_CONFIG_FILE"
print_status "Storage directory: $QDRANT_LOCAL_PATH"

# Keep the script available for cleanup
echo ""
print_status "To clean up test data later, run:"
echo "   rm -rf $QDRANT_LOCAL_PATH $TEST_CONFIG_FILE"
