(function () {
    window.formHelper = {
        confirm: function (msg) {
            return confirm(msg) ? true : false;
        }
    };
})();
