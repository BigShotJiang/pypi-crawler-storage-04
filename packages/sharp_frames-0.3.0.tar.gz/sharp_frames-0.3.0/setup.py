"""Setup script for sharp-frames package."""

from setuptools import setup

# Use setup.py for compatibility with older tools
# Most configuration is now in pyproject.toml
setup() 