"""
Data models for Sharp Frames processing components.
"""