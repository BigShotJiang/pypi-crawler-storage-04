#  This file is part of Pynguin.
#
#  SPDX-FileCopyrightText: 2019–2025 Pynguin Contributors
#
#  SPDX-License-Identifier: MIT
#
def return_tuple():
    return 1, 2


def return_list():
    return [1, 2]


def return_dict():
    return {"foo": 2}


def return_set():
    return {"foo"}


def return_int():
    return 42


def return_none():
    return None
