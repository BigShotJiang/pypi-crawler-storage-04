This is the prompt from a file.
