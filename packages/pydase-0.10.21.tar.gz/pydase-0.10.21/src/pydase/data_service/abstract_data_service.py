from __future__ import annotations

from pydase.observer_pattern.observable.observable import Observable


class AbstractDataService(Observable):
    pass
