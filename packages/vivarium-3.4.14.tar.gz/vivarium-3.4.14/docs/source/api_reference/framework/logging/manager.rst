.. automodule:: vivarium.framework.logging.manager
