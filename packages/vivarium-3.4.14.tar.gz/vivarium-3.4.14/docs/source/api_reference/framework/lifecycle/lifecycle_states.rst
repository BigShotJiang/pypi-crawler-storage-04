.. automodule:: vivarium.framework.lifecycle.lifecycle_states
