.. automodule:: vivarium.framework.state_machine
