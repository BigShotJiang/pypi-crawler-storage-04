from .facade import extract_text

__all__ = [
    "extract_text",
]
