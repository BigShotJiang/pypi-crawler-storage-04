from .plain_text import PlainText

__all__ = [
    "PlainText",
]
