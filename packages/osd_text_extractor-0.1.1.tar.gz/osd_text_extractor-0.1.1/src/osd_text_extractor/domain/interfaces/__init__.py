from .text_extractor import TextExtractor

__all__ = [
    "TextExtractor",
]
