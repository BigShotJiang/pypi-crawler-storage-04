from .exceptions import TextLengthError

__all__ = ["TextLengthError"]
