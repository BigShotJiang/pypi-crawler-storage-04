from enum import Enum

class HeapType(Enum):
    MINIMUM = "min"
    MAXIMUM = "max"