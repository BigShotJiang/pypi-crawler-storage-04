# generated file used by package versioning placeholder
__version__ = "0.1.0"
