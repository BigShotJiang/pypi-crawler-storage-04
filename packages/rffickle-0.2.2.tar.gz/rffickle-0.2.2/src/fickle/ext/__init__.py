"""
This package contains extension modules that are not part of the core
functionality of the library, but that might be useful to users.
"""
