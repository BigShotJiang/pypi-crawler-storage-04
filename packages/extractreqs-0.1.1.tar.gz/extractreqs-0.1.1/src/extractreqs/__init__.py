
from .extractreqs import extract_requirements as extractreq

__author__ = """hasanaliozkan"""
__email__ = 'hasanaliozkan@mu.edu.tr'
