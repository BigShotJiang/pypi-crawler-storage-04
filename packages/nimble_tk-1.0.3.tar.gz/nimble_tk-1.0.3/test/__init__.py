"""
This package contains automated code tests.
"""