::: asmu.effect
