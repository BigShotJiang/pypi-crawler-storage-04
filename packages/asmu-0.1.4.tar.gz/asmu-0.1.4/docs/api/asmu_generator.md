::: asmu.generator
