"""This is a simple demonstration on how to identify your audio devices and which one to use."""
import asmu

print(asmu.query_devices())
