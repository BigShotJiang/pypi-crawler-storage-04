

class DeviceError(Exception):
    """Used if something is wrong with the device specified."""
    pass
