Services for Google Cloud Logging v2 API
========================================
.. toctree::
    :maxdepth: 2

    config_service_v2
    logging_service_v2
    metrics_service_v2
