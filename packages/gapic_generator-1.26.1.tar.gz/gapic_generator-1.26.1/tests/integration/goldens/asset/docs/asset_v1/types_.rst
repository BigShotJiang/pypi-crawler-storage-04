Types for Google Cloud Asset v1 API
===================================

.. automodule:: google.cloud.asset_v1.types
    :members:
    :show-inheritance:
