# Django Logger

Un módulo de Django para auditoría y seguimiento de cambios en modelos, diseñado específicamente para trabajar con sistemas de autenticación externos.

## Características

- Registro detallado de cambios en modelos (Create, Update, Delete)
- Compatibilidad con sistemas de autenticación externos
- Almacenamiento de información del usuario externo (username, email, is_staff)
- Sistema de auditoría con niveles de importancia (LOW, MEDIUM, HIGH, CRITICAL)
- Seguimiento detallado de cambios en campos específicos
- Registro de metadatos adicionales (IP, user agent, timestamp)

## Instalación

```bash
pip install unergy-logger-django
```

## Configuración

1. Agregar 'django_logger' a INSTALLED_APPS en settings.py:

```python
INSTALLED_APPS = [
    ...
    'django_logger',
]
```

2. Ejecutar las migraciones:

```bash
pythn manage.py makemigrations
python manage.py migrate django_logger
```

## Uso

### Decorador para Modelos

```python
from django_logger.decorators import auditable

@auditable(
    tracked_fields=['campo1', 'campo2'],
    audit_creates=True,
    audit_updates=True,
    audit_deletes=True,
    level=AuditLevel.MEDIUM
)
class MiModelo(models.Model):
    campo1 = models.CharField(max_length=100)
    campo2 = models.IntegerField()
```

### Configuración del Usuario Externo

El módulo está diseñado para trabajar con el usuario actual del sistema de autenticación externo. Los datos del usuario se obtienen automáticamente del middleware de autenticación.

### Consulta de Auditoría

Los logs de auditoría se pueden consultar a través del admin de Django o directamente mediante el modelo:

```python
from django_logger.models import AuditLog

# Consultar cambios de un objeto específico
logs = AuditLog.objects.filter(
    content_type__model='mimodelo',
    object_id=objeto_id
)

# Consultar cambios por usuario
logs = AuditLog.objects.filter(username='usuario_externo')
```

### Niveles de Auditoría

- LOW: Cambios de bajo impacto
- MEDIUM: Cambios significativos en datos
- HIGH: Cambios importantes en configuraciones
- CRITICAL: Cambios críticos del sistema

## Campos Registrados

Cada registro de auditoría incluye:

- Información del objeto modificado (modelo y ID)
- Tipo de acción (CREATE, UPDATE, DELETE)
- Nivel de importancia
- Usuario que realizó la acción (username, email, is_staff)
- Cambios realizados (valores anteriores y nuevos)
- Información de la sesión (IP, user agent)
- Timestamp del cambio

## Contribución

Las contribuciones son bienvenidas. Por favor, abre un issue para discutir los cambios propuestos.

## Licencia

MIT License - ver archivo LICENSE para más detalles.
