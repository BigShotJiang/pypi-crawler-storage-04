"""
Test suite for Sentinel Python SDK
"""