'''
    #################################################################################################################################################################################################
    # This code library is an adaptation of the original Transformers and was designed, developed and programmed by Sapiens Technology®.                                                            #
    # Any alteration and/or disclosure of this code without prior authorization is strictly prohibited and is subject to legal action that will be forwarded by the Sapiens Technology® legal team. #
    # This set of algorithms aims to download, train, fine-tune and/or infer large language models from various sources and slopes.                                                                 #
    #################################################################################################################################################################################################
'''
deps = {'Pillow': 'Pillow', 'sapiens_accelerator': 'sapiens_accelerator>=0.31.0', 'compel': 'compel==0.1.8', 'datasets': 'datasets', 'filelock': 'filelock', 'flax': 'flax>=0.4.1',
'hf-doc-builder': 'hf-doc-builder>=0.3.0', 'huggingface-hub': 'huggingface-hub>=0.23.2', 'requests-mock': 'requests-mock==1.10.0', 'importlib_metadata': 'importlib_metadata',
'invisible-watermark': 'invisible-watermark>=0.2.0', 'isort': 'isort>=5.5.4', 'jax': 'jax>=0.4.1', 'jaxlib': 'jaxlib>=0.4.1', 'Jinja2': 'Jinja2', 'k-diffusion': 'k-diffusion>=0.0.12',
'torchsde': 'torchsde', 'note_seq': 'note_seq', 'librosa': 'librosa', 'numpy': 'numpy', 'parameterized': 'parameterized', 'peft': 'peft>=0.6.0', 'protobuf': 'protobuf>=3.20.3,<4',
'pytest': 'pytest', 'pytest-timeout': 'pytest-timeout', 'pytest-xdist': 'pytest-xdist', 'python': 'python>=3.8.0', 'ruff': 'ruff==0.1.5', 'safetensors': 'safetensors>=0.3.1',
'sentencepiece': 'sentencepiece>=0.1.91,!=0.1.92', 'GitPython': 'GitPython<3.1.19', 'scipy': 'scipy', 'onnx': 'onnx', 'regex': 'regex!=2019.12.17', 'requests': 'requests',
'tensorboard': 'tensorboard', 'torch': 'torch>=1.4', 'torchvision': 'torchvision', 'sapiens_transformers': 'sapiens_transformers>=1.0.0', 'urllib3': 'urllib3<=2.0.0', 'black': 'black'}
'''
    #################################################################################################################################################################################################
    # This code library is an adaptation of the original Transformers and was designed, developed and programmed by Sapiens Technology®.                                                            #
    # Any alteration and/or disclosure of this code without prior authorization is strictly prohibited and is subject to legal action that will be forwarded by the Sapiens Technology® legal team. #
    # This set of algorithms aims to download, train, fine-tune and/or infer large language models from various sources and slopes.                                                                 #
    #################################################################################################################################################################################################
'''
