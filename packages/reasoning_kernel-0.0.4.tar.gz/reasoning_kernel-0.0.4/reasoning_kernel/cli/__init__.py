"""
CLI package for MSA Reasoning Engine
"""