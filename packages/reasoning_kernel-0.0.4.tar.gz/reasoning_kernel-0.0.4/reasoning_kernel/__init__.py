"""
MSA Reasoning Engine - Model Synthesis Architecture
A two-mode AI reasoning system combining Semantic Kernel and NumPyro
"""

__version__ = "1.0.0"
__author__ = "ReasoningFleet Team"
