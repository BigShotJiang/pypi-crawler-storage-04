# API Responses

::: gotenberg_client.SingleFileResponse
    handler: python

::: gotenberg_client.ZipFileResponse
    handler: python

::: gotenberg_client.HealthStatus
    handler: python

::: gotenberg_client._health.ModuleStatus
    handler: python

::: gotenberg_client._health.ModuleOptions
    handler: python

::: gotenberg_client._health.StatusOptions
    handler: python
