"""
Core functionality for MBX AI.
"""

def hello_world() -> str:
    """
    Returns a greeting message.
    
    Returns:
        str: A greeting message
    """
    return "Hello from MBX AI!" 