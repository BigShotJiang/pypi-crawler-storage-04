To use this module, you need to:

- Run the core contract flow normally
