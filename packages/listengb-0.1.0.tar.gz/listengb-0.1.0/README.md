# listengb

一个简单的UDP广播监听库，用于接收并解析UDP广播消息。

## 安装

```bash
pip install listengb