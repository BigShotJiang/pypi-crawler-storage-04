"""
Unit tests for the mcp_microservice package.
""" 