"""Version information for MCP Microservice."""

__version__ = "6.1.0"

