- Iván Todorovich \<<ivan.todorovich@camptocamp.com>\>
  (<https://www.camptocamp.com/>)
- Thierry Ducrest \<<thierry.ducrest@camptocamp.com>\>

## Design

- Jacques-Etienne Baudoux (BCIM) \<<je@bcim.be>\>
