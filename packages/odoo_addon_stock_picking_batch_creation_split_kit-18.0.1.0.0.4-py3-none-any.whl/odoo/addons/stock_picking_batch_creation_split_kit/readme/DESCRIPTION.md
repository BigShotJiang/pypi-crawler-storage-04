Extends the `stock_picking_batch_creation` module to split pickings to fit
in the device `nbr_bins` limit.

To do so, it uses the `stock_split_picking_kit` module.
