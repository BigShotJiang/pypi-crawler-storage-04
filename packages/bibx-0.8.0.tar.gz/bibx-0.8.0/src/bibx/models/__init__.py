"""Models for the bibx package."""
