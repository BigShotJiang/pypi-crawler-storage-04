"""Clients to talk to external services."""
