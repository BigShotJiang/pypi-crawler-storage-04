"""Algorithm implementations."""
