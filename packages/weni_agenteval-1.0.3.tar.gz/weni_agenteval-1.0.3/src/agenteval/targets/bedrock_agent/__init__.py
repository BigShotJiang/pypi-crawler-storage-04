# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: Apache-2.0

from .target import BedrockAgentTarget

__all__ = ["BedrockAgentTarget"]
