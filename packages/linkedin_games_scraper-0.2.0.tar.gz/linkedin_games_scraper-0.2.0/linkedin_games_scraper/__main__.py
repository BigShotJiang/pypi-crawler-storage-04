"""Main entry point for the LinkedIn Games Scraper package."""

from .solver import main

if __name__ == "__main__":
    main()
