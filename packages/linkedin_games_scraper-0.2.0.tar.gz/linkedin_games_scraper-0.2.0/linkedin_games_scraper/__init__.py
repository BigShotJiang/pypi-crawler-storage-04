"""LinkedIn Games Scraper - A package to solve LinkedIn games by extracting solutions."""

from .solver import GameSolver

__version__ = "0.2.0"
