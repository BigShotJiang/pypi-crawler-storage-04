"""Tests for the LinkedIn Games Scraper package."""
