# geochunk

Unified access protocol for geospatiotemporal data sources.

**Status: Early development - API will change**

Coming soon.