"""Unified access protocol for geospatiotemporal data sources - early development version."""

__version__ = "0.0.1"

def placeholder():
    """Placeholder function for initial release."""
    return f"geochunk v{__version__} - unified data access coming soon"