"""Shared interfaces package."""
