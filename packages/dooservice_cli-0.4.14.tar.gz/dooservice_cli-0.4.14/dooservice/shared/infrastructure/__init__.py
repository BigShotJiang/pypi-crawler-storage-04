"""Shared infrastructure implementations package."""
