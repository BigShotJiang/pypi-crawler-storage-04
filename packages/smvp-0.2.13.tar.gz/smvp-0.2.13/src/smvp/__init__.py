from smvp.engine import process_args


def main() -> None:
    """Entry point.

    Pass control to process commandline arguments.
    """
    process_args()
