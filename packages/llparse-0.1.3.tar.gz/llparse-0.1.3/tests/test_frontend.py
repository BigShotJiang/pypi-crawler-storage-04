
from llparse import LLParse



def test_build_tables():
    # There was a bug with 1.2 of our version that doesn't affect the node-js one where
    # it wouldn't building tables, this attempts to simulate the problem Currenlty this 
    # bug is patched now :)
    p = LLParse("lltable")
    start = p.node('start')
    loop = p.node('loop')
    loop.skipTo(start)
    start.match(
        [48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 
65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 58, 
59, 60, 61, 62, 63, 64, 91, 92, 93, 94, 95, 96, 123, 124, 125, 126, 32, 9, 10, 13, 11, 12],
        loop
    ).otherwise(p.error(0, 'im a little teapot'))

    # If there is not a lookup_table this then it has failed me ;-;
    assert "lookup_table" in p.build(start).c



