RAD by Parslet
==============

The ``parslet rad`` command executes a small diagnostic pipeline that runs
lightweight models on an image. Results are written to ``rad_results`` by
default. Use ``--simulate`` to preview the DAG without executing it.
