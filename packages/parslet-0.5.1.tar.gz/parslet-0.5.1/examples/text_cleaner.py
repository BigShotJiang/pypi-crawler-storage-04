"""Example: Clean a text file.
This demo shows how Parslet can read a text file, normalize it,
and save the word counts to a new file.
"""
