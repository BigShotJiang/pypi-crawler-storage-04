"""CLI commands for scryptorum."""
