# -*- coding: utf-8 -*-
from .text_to_sentences import sentences_to_n_words, split_text_into_sentences

__all__ = ["sentences_to_n_words", "split_text_into_sentences"]
