export * from './dark-pallette-setter';
export * from './light-pallette-setter';
