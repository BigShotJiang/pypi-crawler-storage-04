When a production order is completed, automatically trigger the printing of some documents.
