from pathlib import Path

DEFAULT_INPUT_DIR = Path("..") / ".." / "input"

DEFAULT_OUTPUT_DIR = Path("..") / ".." / "output"
