from .validate_html import validate_html

__all__ = ["validate_html"]
