# PII Masking Library

This library provides functionality for masking Personally Identifiable Information (PII) to ensure data privacy and compliance with regulations.

## Features

- Mask various types of PII such as names, email addresses, and phone numbers.
- Customizable masking strategies.
- Easy integration with existing applications.

## Installation

You can install the library using pip:

```bash
pip install piidata-masker
```

## Usage

```python
from pii_masking import PIIMasker, MaskConfig

# Create a masker with default configuration
masker = PIIMasker()

# Mask an email
masked_email = masker.mask_email("john.doe@example.com")
print(masked_email)  # Output: jo******@example.com

# Mask a phone number
masked_phone = masker.mask_phone("555-123-4567")
print(masked_phone)  # Output: ******4567

# Mask PII in a text paragraph
text = """
Please contact John Doe at john.doe@example.com or call him at 555-123-4567.
His alternate email is johndoe@company.com and backup phone is +1-444-555-6666.
"""
masked_text = masker.mask_text(text)
print(masked_text)
# Output:
# Please contact John Doe at jo******@example.com or call him at ******4567.
# His alternate email is jo******@company.com and backup phone is ******6666.

# Use custom configuration
config = MaskConfig(
    email_show_chars=3,    # Show first 3 chars of email username
    phone_show_chars=4,    # Show last 4 digits of phone
    mask_char="#",         # Use # for masking
    mask_domains=True      # Also mask email domains
)
masker = PIIMasker(config)

# Now masking will use your custom configuration
masked_email = masker.mask_email("john.doe@example.com")
print(masked_email)  # Output: joh#####@ex#####.com
```

## Contributing

Contributions are welcome! Please read the [CONTRIBUTING.md](docs/CONTRIBUTING.md) for more information.

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.