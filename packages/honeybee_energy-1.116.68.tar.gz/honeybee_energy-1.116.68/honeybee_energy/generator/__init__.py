"""honeybee-energy electricity generator definitions.

This includes photovoltaic panels, wind/hydro turbines, battery storage devices,
and combustion engines.
"""
