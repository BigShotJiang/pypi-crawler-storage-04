"""JDER FastAPI: A response builder for FastAPI"""
