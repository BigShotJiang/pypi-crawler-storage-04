"""
Enterprise heartbeat related code.
"""
