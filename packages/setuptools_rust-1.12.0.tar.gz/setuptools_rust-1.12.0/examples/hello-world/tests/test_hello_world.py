import hello_world


def test_sum_as_string():
    assert hello_world.sum_as_string(5, 20) == "25"
