This text should be included.

.. raw:: html

    <p> This text should be skipped. </p>

This text should also be included.
