.. attention:: This is a attention.
.. caution:: This is a caution.
.. danger:: This is a danger.
.. error:: This is a error.
.. important:: This is a important.
.. note:: This is a note.
.. tip:: This is a tip.
.. hint:: This is a hint.
.. warning:: This is a warning.
.. admonition:: This is a admonition.


This is text.