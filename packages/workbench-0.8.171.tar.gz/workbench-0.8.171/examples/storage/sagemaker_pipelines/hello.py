print(f"Hello from Sagemaker Pipeline")
