# ModelCore
!!! tip inline end "API Classes"
    Found a method here you want to use? The [API Classes](../../api_classes/overview.md) have method pass-through so just call the method on the Model API Class and voilà it works the same.
    
::: workbench.core.artifacts.model_core