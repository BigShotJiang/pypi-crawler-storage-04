"""The application's Globals object"""

__all__ = ["Globals"]


class Globals:
    """
    Container for objects available throughout the life of the application.

    One instance of Globals is created during application initialization and
    is available during requests via the ``app_globals`` variable.
    """

    def __init__(self):
        pass
