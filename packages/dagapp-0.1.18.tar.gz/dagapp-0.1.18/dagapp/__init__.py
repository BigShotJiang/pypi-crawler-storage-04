"""Making apps from DAGs"""

from dagapp.base import dag_app
