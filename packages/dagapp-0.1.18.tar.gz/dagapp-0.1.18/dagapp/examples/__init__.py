"""
Various dagapp examples:

- simple_example
- configs_example
- classification_metric_factory
- infection
- vectorized_example
- rent_or_buy
"""
