There is a wizard (sign.oca.template.generate.multi) that can be used
for any model needed. If there is a template without a linked model or
linked to a model (res.partner for example) an action will be
automatically displayed in the tree and form view (only for users with
Sign permissions).
