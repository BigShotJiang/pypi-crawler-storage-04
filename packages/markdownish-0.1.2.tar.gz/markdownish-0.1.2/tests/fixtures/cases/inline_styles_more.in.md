Hello **bold** and *it* and ~~gone~~ and `code`.
