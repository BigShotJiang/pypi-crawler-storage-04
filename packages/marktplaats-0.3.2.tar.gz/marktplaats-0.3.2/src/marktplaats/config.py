from __future__ import annotations


ISSUE_LINK = "https://github.com/jensjeflensje/marktplaats-py/issues"
