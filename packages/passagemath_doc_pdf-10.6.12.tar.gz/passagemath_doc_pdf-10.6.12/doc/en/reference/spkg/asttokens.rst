.. _spkg_asttokens:

asttokens: Annotate AST trees with source code positions
========================================================

Description
-----------

Annotate AST trees with source code positions

License
-------

Apache 2.0

Upstream Contact
----------------

https://pypi.org/project/asttokens/



Type
----

standard


Dependencies
------------

- $(PYTHON)
- :ref:`spkg_pip`
- :ref:`spkg_six`

Version Information
-------------------

package-version.txt::

    2.4.1

version_requirements.txt::

    asttokens

Equivalent System Packages
--------------------------

.. tab:: conda-forge:

   .. CODE-BLOCK:: bash

       $ conda install asttokens

.. tab:: Gentoo Linux:

   .. CODE-BLOCK:: bash

       $ sudo emerge dev-python/asttokens


If the system package is installed and if the (experimental) option
``--enable-system-site-packages`` is passed to ``./configure``, then ``./configure`` will check if the system package can be used.
