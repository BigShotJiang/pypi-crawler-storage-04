# Changelog

See the project’s `CHANGELOG.md` for detailed release notes.

