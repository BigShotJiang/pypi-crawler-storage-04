# License

PyZaplinePlus is released under the MIT License.

See the root `LICENSE` file for the full text.

