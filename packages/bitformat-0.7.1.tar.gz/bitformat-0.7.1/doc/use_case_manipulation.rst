.. currentmodule:: bitformat
.. _use_case_manipulation:


Manipulating binary data
------------------------

The :class:`Bits` class represents an immutable container of bits. In much the same way as a standard Python ``bytes`` contains immutable bytes and ``str`` contains immutable characters.

TODO

