.. currentmodule:: bitformat
.. _reader:

Reader
======

The :class:`Reader` class allows binary data to be read and parsed as a stream of bits with a bit position.

----

.. autoclass:: bitformat.Reader
   :members:
   :member-order: groupwise
   :undoc-members: