# flashplot

```
pip install flashplot
```
