from __future__ import annotations

from .app import create_app

# TODO add routers for layered API

app = create_app()
