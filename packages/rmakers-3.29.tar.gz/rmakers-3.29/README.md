rmakers 3.29
============

[![Python 3.12](
    https://img.shields.io/badge/python-3.12-blue.svg)](
    https://www.python.org/downloads/release/python-312/)
[![Python 3.13](
    https://img.shields.io/badge/python-3.13-blue.svg)](
    https://www.python.org/downloads/release/python-313/)
![Build Status](
    https://github.com/Abjad/rmakers/actions/workflows/main.yml/badge.svg)
[![Code style: black](
    https://img.shields.io/badge/code%20style-black-000000.svg)](
    https://github.com/ambv/black)

Trevor Bača's rhythm-maker package for Abjad.
