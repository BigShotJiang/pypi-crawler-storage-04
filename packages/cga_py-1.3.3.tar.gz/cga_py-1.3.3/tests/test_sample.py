def test_my_function():
    result = 1
    assert result == 1
