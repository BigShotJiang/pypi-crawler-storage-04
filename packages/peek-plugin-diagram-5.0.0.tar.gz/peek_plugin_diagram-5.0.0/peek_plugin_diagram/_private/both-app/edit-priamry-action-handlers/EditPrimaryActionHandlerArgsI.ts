import { EditTextPrimaryActionComponent } from "../edit-primary-action-components/edit-text-primary-action-component/edit-text-primary-action.component";

export interface EditPrimaryActionHandlerArgsI {
    textActionComponent: EditTextPrimaryActionComponent;
}
