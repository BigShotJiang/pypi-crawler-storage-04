export enum DrawModeE {
    ForView = 1,
    ForEdit = 2,
    ForSuggestion = 3,
}
