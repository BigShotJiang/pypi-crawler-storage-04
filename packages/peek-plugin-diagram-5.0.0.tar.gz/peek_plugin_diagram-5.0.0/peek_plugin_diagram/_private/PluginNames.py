diagramFilt = {"plugin": "peek_plugin_diagram"}
diagramTuplePrefix = "peek_plugin_diagram."
diagramObservableName = "peek_plugin_diagram"
# This is an additional observable on the client, used to access the caches in the client
diagramActionProcessorName = "peek_plugin_diagram"
diagramTupleOfflineServiceName = "peek_plugin_diagram"
