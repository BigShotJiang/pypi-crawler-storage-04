==========
User Guide
==========

The diagram plugin allows users to view diagrams.

TODO.