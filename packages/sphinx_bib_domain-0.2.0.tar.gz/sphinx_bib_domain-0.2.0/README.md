# sphinx_bib_domain

## Overview

A Bibtex domain for sphinx, to add various indices to generated documentation.

## Examples
