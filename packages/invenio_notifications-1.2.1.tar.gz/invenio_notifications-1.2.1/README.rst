..
    Copyright (C) 2023 CERN.

    Invenio-Notifications is free software; you can redistribute it and/or
    modify it under the terms of the MIT License; see LICENSE file for more
    details.

=======================
 Invenio-Notifications
=======================

.. image:: https://github.com/inveniosoftware/invenio-notifications/workflows/CI/badge.svg
        :target: https://github.com/inveniosoftware/invenio-notifications/actions?query=workflow%3ACI

.. image:: https://img.shields.io/github/tag/inveniosoftware/invenio-notifications.svg
        :target: https://github.com/inveniosoftware/invenio-notifications/releases

.. image:: https://img.shields.io/pypi/dm/invenio-notifications.svg
        :target: https://pypi.python.org/pypi/invenio-notifications

.. image:: https://img.shields.io/github/license/inveniosoftware/invenio-notifications.svg
        :target: https://github.com/inveniosoftware/invenio-notifications/blob/master/LICENSE

Invenio module for notifications support.

Further documentation is available on
https://invenio-notifications.readthedocs.io/
