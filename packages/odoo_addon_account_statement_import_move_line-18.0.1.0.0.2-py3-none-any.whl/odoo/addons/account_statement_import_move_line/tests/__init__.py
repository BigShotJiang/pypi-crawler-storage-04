# License AGPL-3 - See http://www.gnu.org/licenses/agpl-3.0

from . import test_account_bank_statement_import_move_line
