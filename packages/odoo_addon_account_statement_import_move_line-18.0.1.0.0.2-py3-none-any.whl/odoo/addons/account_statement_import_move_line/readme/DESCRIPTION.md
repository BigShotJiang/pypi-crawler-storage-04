This module adds a button to bank statement form view to open a wizard
to allow filtering, selecting and importing lines form journal items
into the bank statement.
