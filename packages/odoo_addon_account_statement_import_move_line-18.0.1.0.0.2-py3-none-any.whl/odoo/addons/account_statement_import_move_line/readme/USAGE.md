Journal entries can be imported in two ways, from a new bank statement or from an existing bank statement.
1. Go to Invoicing > Dashboard.
2. To import to a new statement, in the relevant bank journal click on ‘Import journal items’. To import from an existing bank statement, open the statement form and click on ‘Import journal items’.
3. Select the filtering options.
5. Click on the ‘Add all transaction lines’ button to automatically select the transaction lines matching the selected criteria or click on Add an item to manually select the transaction lines filtered by the criteria.
6. Click the ‘Create extract lines’ button.
