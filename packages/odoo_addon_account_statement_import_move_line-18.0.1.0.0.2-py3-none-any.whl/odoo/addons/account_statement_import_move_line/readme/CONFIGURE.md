To configure this module, you need to:

1.  Go to *Settings \> Users & Companies \> Groups*.
2.  Search for the group *Show Full Accounting Features*.
3.  Add the user who needs to use this function.
