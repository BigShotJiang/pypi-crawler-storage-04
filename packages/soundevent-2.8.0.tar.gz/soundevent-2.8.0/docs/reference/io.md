# IO Module

::: soundevent.io
    options:
        group_by_category: false
        members:
        - DataCollections
        - save
        - load

::: soundevent.io.crowsetta
