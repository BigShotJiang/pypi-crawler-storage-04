def test_runner_works():
    expected = 1
    assert expected == 1
