from .base import IMemoryBackend

__all__ = [
    "IMemoryBackend",
]
