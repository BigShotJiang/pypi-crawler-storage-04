# l6e forge types

This type documentation is a work in progress.

```
l6e_forge/types/
├── __init__.py          # Main exports
├── core.py              # Core data types (Message, Context, Response)
├── config.py            # All configuration types  
├── agent.py             # Agent-specific types
├── model.py             # Model and LLM types
├── memory.py            # Memory system types
├── tool.py              # Tool system types
├── event.py             # Event system types
├── error.py             # Error handling types
├── workspace.py         # Workspace and template types
├── testing.py           # Testing framework types
├── ecosystem.py         # Package distribution types
```