from l6e_forge.logging.base import ILogger
from l6e_forge.logging.get_logger import get_logger

__all__ = ["ILogger", "get_logger"]
