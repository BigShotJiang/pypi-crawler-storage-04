"""
Web interface for cuti.
"""