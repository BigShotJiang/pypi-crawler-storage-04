1.  Create a new transfer with a product with 'Barcode'.
2.  Validate it.
3.  Click on 'Print \> Print Barcode Labels'.
4.  Select how many labels do you want for each product.
5.  Click on 'Print' and open the pdf with the labels.
