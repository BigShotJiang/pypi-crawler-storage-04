"""Example CrewAI workflows using AgentUp integration."""

__all__ = ["basic_crew", "multi_agent_flow", "streaming_example"]
