"""AgentUp integrations with external agent frameworks."""

__all__ = ["crewai"]
