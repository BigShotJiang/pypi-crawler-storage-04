class SolverSign:
    EQ = 'eq'
    NOT_EQ = 'not_eq'
    GTE = 'gte'
    LTE = 'lte'
