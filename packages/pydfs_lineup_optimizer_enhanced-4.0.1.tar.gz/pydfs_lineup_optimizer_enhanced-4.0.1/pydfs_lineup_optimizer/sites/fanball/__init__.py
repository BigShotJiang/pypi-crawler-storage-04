from pydfs_lineup_optimizer.sites.fanball.settings import FanBallFootballSettings

__all__ = [
    'FanBallFootballSettings',
]
