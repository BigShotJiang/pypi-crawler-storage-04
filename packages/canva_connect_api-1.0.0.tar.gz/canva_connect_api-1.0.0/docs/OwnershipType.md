# OwnershipType


## Enum

* `ANY` (value: `'any'`)

* `OWNED` (value: `'owned'`)

* `SHARED` (value: `'shared'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


