# Grizabella database layers - common components
