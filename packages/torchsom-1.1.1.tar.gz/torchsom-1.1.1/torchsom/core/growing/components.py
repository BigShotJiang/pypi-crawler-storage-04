"""Components for growing SOMs."""
