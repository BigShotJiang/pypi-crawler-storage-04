"""Attribute helpers for OpenAI API instrumentation.

This package contains helpers for extracting attributes from OpenAI API responses
for use in OpenTelemetry spans.
"""

# Will contain attribute extraction helpers in the future
