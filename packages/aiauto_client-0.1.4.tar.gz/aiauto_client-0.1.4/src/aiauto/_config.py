# For Connect RPC over HTTP
# This will be converted to https://api.aiauto.pangyo.ainode.ai in production
AIAUTO_API_TARGET = "api.aiauto.pangyo.ainode.ai:443"