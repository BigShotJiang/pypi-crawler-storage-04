from openinference.instrumentation.openlit._span_processor import (
    OpenInferenceSpanProcessor,
)

__all__ = ["OpenInferenceSpanProcessor"]
