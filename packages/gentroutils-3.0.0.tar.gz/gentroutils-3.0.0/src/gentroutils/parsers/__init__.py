"""Module for parsing and handling data in gentroutils."""
