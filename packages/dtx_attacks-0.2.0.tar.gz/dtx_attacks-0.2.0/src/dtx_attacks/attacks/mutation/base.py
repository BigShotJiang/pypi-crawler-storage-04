class BaseMutation:
    def __init__(self):
        pass