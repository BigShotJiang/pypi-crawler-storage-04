HEADER = b"PGCOPY\n\xff\r\n\x00"
NULLABLE = b"\xff\xff\xff\xff"
