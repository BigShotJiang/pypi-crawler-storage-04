#!/usr/bin/env python
#
# for documenteer 1.0

from documenteer.conf.guide import *
