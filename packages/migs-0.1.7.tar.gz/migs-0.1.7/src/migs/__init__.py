"""migs - CLI tool for managing Google Cloud Managed Instance Groups"""

__version__ = "0.1.7"