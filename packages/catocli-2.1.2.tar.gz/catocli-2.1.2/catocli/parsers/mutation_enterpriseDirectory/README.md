
## CATO-CLI - mutation.enterpriseDirectory:
[Click here](https://api.catonetworks.com/documentation/#mutation-enterpriseDirectory) for documentation on this operation.

### Usage for mutation.enterpriseDirectory:

`catocli mutation enterpriseDirectory -h`
