
# Say hello

```python
    from hack4u import list_courses

    for course in list_courses():
        print(course)
```
