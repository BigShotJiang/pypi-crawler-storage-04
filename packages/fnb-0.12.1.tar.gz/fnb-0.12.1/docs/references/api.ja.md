# API リファレンス

APIリファレンスは英語版のみで提供しています。

**[English API Reference](../api/) をご覧ください。**

---

*API documentation is available in English only. Please refer to the English version for complete technical details.*
