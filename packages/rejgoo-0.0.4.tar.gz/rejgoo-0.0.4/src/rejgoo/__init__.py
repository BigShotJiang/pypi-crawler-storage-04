"""Top-level package for equation solver."""

__author__ = """Mahdi Hajebi"""
__email__ = 'merto071@yahoo.com'
__version__ = '0.0.4'
