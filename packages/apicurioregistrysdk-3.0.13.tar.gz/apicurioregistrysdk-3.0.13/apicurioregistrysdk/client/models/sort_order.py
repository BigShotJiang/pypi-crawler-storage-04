from enum import Enum

class SortOrder(str, Enum):
    Asc = "asc",
    Desc = "desc",

