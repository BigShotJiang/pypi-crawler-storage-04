# imPYP

Python library installer and uninstaller

## Install

Para instalar localmente (teste):

```bash
pip install .