from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Optional, Union

from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter

if TYPE_CHECKING:
    from .entity import Entity

from .entity import Entity


@dataclass
class AiInteractionContext(Entity, Parsable):
    # The full file URL where the interaction happened.
    context_reference: Optional[str] = None
    # The type of the file.
    context_type: Optional[str] = None
    # The name of the file.
    display_name: Optional[str] = None
    # The OdataType property
    odata_type: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> AiInteractionContext:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: AiInteractionContext
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return AiInteractionContext()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .entity import Entity

        fields: dict[str, Callable[[Any], None]] = {
            "contextReference": lambda n : setattr(self, 'context_reference', n.get_str_value()),
            "contextType": lambda n : setattr(self, 'context_type', n.get_str_value()),
            "displayName": lambda n : setattr(self, 'display_name', n.get_str_value()),
        }
        super_fields = super().get_field_deserializers()
        fields.update(super_fields)
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        super().serialize(writer)
        writer.write_str_value("contextReference", self.context_reference)
        writer.write_str_value("contextType", self.context_type)
        writer.write_str_value("displayName", self.display_name)
    

