from miniform.core.process.interface import MiniInterfaceProc
from miniform.core.process.render import MiniRenderProc
from miniform.core.process.camera import MiniCameraProc
from miniform.core.process.world import MiniWorldProc
from miniform.core.process.light import MiniLightProc
