MINI_MAJOR: int = 0
MINI_MINOR: int = 1
MINI_PATCH: int = 2