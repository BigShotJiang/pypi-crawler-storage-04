"""Minimal CSV diff tool for data validation."""

__version__ = "0.1.0"
