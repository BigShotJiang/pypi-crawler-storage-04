console.log('Hello from example.js')
