def test_homepage(driver):
    pass
