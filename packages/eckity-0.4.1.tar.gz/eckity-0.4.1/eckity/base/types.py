t_argmax = type("argmax", (int,), {})
