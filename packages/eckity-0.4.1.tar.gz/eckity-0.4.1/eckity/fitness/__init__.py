from .fitness import Fitness
from .simple_fitness import SimpleFitness
from .gp_fitness import GPFitness
