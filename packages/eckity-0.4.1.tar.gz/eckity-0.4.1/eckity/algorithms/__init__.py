from .algorithm import Algorithm
from .simple_evolution import SimpleEvolution
