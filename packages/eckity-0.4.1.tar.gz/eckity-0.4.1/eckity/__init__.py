"""
EC-KitY: Evolutionary Computation Tool Kit in Python
"""

__version__ = "0.4.1"
