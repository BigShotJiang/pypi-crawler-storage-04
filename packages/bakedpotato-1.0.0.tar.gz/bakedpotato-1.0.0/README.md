# BakedPotato

To install

```bash
pip install git+https://github.com/wilf-phasecraft/BakedPotato.git
```

To run

```bash
bakedpotato
```

