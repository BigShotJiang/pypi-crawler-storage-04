# pwnkit
I tried to keep things simple. But finally I will have to create this repo for pwn templates, utils and scripts for PoCs. Project under construction
