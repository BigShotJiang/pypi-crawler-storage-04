# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]
## [16.0.1.0.4] - 2025-09-03
### Added
- [#1583](https://git.coopdevs.org/coopdevs/som-connexio/odoo-somconnexio/-/merge_requests/1583) add source param o crm-lead and create lead wizard

## [16.0.1.0.3] - 2025-08-26
### Fixed
- [#1573](https://git.coopdevs.org/coopdevs/som-connexio/odoo-somconnexio/-/merge_requests/1573) Fix contract views

## [16.0.1.0.2] - 2025-07-04
### Added
- [#1556](https://git.coopdevs.org/coopdevs/som-connexio/odoo-somconnexio/-/merge_requests/1556) Raise error if lead wizards create a lead line with filmin product and partners that already have had filmin services.

### Fixed
- [#1550](https://git.coopdevs.org/coopdevs/som-connexio/odoo-somconnexio/-/merge_requests/1550) Filmin hook demo installation is_dev

## [16.0.1.0.1] - 2025-06-26
### Added
- [#1548](https://git.coopdevs.org/coopdevs/som-connexio/odoo-somconnexio/-/merge_requests/1548) Filmin CRMLeads validated at creation

## [16.0.1.0.0] - 2025-06-25
### Added
- [#1405](https://git.coopdevs.org/coopdevs/som-connexio/odoo-somconnexio/-/merge_requests/1405) Add filmin_somconnexio module
