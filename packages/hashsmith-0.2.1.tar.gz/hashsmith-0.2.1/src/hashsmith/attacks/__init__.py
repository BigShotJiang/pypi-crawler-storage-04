"""
Dictionary attack module for hashcat wordlist-based attacks.
"""

from .dictionary_attack import DictionaryAttack

__all__ = ["DictionaryAttack"]
