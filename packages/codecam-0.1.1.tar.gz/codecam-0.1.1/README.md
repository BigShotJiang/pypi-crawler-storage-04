# codecam

A tiny tool to select files from a project and produce a single text snapshot for sharing with LLMs.

## Usage

```bash
pipx install codecam
codecam .
```

