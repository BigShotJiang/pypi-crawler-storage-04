from payload_generator import generate_payloads

if __name__ == "__main__":
    generate_payloads()