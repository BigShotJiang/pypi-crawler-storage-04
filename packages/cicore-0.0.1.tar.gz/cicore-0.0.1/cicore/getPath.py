import wtfami

def getPath():
    return wtfami.getPath()