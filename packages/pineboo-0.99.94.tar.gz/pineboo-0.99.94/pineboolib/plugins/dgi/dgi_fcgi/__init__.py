"""Dgi_fcgi package."""
