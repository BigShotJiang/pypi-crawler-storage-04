"""Dlg_about package."""
