"""
Tests for metadata package.
"""
