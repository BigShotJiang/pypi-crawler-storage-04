"""
Tests for qsatypes package.
"""
