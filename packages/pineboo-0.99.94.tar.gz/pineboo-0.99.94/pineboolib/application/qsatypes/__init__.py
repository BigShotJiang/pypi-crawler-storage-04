"""
Data Types for QSA.
"""
