"""
Translator tests package.
"""
