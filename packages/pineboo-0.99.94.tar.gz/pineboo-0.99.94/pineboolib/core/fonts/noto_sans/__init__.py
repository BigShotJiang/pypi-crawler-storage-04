"""NotoSans package."""
