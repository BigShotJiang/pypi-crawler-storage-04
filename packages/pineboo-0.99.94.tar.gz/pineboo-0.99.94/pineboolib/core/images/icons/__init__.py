"""Icons package."""
