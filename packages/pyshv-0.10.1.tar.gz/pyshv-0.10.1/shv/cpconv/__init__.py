"""Simple conversion between Cpon and Chainpack."""

from .cpconv import CPFormat, convert

__all__ = [
    "CPFormat",
    "convert",
]
