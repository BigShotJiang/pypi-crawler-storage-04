from .scaffold import run_scaffold

if __name__ == "__main__":
    run_scaffold()