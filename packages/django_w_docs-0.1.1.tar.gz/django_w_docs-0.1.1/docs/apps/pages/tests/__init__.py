"""Tests for docs.section"""
