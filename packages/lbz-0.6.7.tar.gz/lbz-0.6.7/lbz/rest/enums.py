class ContentType:
    JSON = "application/json"
    TEXT = "text/plain"
