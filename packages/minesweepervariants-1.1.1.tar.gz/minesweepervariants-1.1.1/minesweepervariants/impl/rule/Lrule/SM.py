#!/usr/bin/env python3
# -*- coding:utf-8 -*-
#
# @Time    : 2025/06/11 14:25
# @Author  : xxx
# @FileName: 1D.py
"""
[SM]神秘: 这是一条会让男娘感到困惑的规则
"""

from ....abs.Lrule import AbstractMinesRule


class Rule1D(AbstractMinesRule):
    name = ["SM", "???", "神秘"]
    doc = "这是一条会让男娘感到困惑的规则"
