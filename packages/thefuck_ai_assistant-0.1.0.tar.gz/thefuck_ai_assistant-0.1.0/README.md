﻿# TheFuck AI Assistant

TheFuck AI Assistant 鏄竴涓熀浜?AI 鐨勫懡浠や慨姝ｆ彃浠讹紝涓?[thefuck](https://github.com/nvbn/thefuck) 宸ュ叿鎻愪緵鏅鸿兘鍛戒护淇鍔熻兘銆?

## 鍔熻兘鐗圭偣

- 浣跨敤 AI 妯″瀷鍒嗘瀽鍛戒护閿欒骞舵彁渚涗慨澶嶅缓璁?
- 鏀寔澶氱 AI 妯″瀷鍜?API 鏈嶅姟
- 鑷姩鐜妫€娴嬪拰閰嶇疆
- 绠€鍗曟槗鐢ㄧ殑瀹夎鍜岃缃祦绋?

## 瀹夎

```bash
pip install thefuck-ai-assistant
```

鎴栬€呯洿鎺ヤ粠 GitHub 瀹夎:

```bash
pip install git+https://github.com/yourusername/thefuck-ai-assistant.git
```

## 鑷姩瀹夎鍜岄厤缃?

瀹夎鍚庯紝杩愯浠ヤ笅鍛戒护瀹屾垚鍒濆鍖栭厤缃?

```bash
thefuck-ai-install
```

姝ゅ懡浠ゅ皢:
1. 妫€鏌ユ槸鍚﹀畨瑁呬簡 thefuck
2. 鑷姩璇嗗埆鎮ㄧ殑鎿嶄綔绯荤粺
3. 灏嗚鍒欐枃浠跺鍒跺埌閫傚綋鐨勪綅缃?
4. 甯姪鎮ㄩ厤缃繀瑕佺殑 API 瀵嗛挜鍜岃缃?

## 鎵嬪姩閰嶇疆

鎮ㄥ彲浠ユ墜鍔ㄨ缃互涓嬬幆澧冨彉閲?

- `THEFUCK_AI_API_URL`: AI API 鐨?URL (榛樿: https://api.siliconflow.cn/v1/chat/completions)
- `THEFUCK_AI_API_KEY`: 鎮ㄧ殑 AI API 瀵嗛挜
- `THEFUCK_AI_MODEL`: 瑕佷娇鐢ㄧ殑 AI 妯″瀷 (榛樿: Qwen/QwQ-32B)

## 浣跨敤鏂规硶

瀹夎鍜岄厤缃畬鎴愬悗锛屾甯镐娇鐢?thefuck 鍛戒护鍗冲彲銆傚綋鎮ㄨ緭鍏ラ敊璇懡浠ゅ悗:

```bash
$ apt-get install vim  # 閿欒鍛戒护
E: Could not open lock file...
$ fuck  # 璋冪敤 thefuck
sudo apt-get install vim [enter/鈫?鈫?ctrl+c]
```

AI Assistant 瑙勫垯灏嗗皾璇曚娇鐢?AI 鏉ュ垎鏋愬拰淇鎮ㄧ殑鍛戒护銆?

## 璁稿彲璇?

MIT
