"""
Nova CI-Rescue tools package.
"""
