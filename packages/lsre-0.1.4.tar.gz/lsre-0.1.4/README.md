# Learn Simple Regular Expressions

[![pr-checks](https://github.com/rohit1998/lsre/actions/workflows/pr-checks.yml/badge.svg)](https://github.com/rohit1998/lsre/actions/workflows/pr-checks.yml)
[![Documentation](https://img.shields.io/badge/docs-latest-blue.svg)](https://rohit1998.github.io/lsre/)
[![PyPI version](https://img.shields.io/pypi/v/lsre.svg?color=blue)](https://pypi.org/project/lsre/)
[![Python versions](https://img.shields.io/pypi/pyversions/lsre.svg?color=blue)](https://pypi.org/project/lsre/)


A project to learn simple regular expressions. Checkout [docs](https://rohit1998.github.io/lsre/) for details.

## License

This project is licensed under the MIT License - see the LICENSE file for details.
