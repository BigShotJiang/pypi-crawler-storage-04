from .manager import WindowManager

__all__ = ["WindowManager"]
