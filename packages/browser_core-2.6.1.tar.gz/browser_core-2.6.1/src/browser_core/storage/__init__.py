# Torna a classe StorageEngine acessível a partir do pacote 'storage'.

from .engine import StorageEngine

__all__ = ["StorageEngine"]
