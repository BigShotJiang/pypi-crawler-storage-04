"""opensearch submodule."""
