# Placeholder SVG files for documentation

These are placeholder SVG files for the documentation site. In a real deployment, these would be replaced with proper illustrations.

## Files needed:
- undraw_speed.svg
- undraw_programming.svg  
- undraw_lightweight.svg
- undraw_memory.svg
- undraw_safety.svg
- undraw_analytics.svg