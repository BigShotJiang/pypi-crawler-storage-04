// Quality module stub
