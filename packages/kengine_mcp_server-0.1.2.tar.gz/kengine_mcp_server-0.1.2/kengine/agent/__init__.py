"""
Agent package for KEngine.

This package contains shared agent components and tools.
"""