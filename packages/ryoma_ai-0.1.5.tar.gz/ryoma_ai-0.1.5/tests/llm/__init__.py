"""
Tests for LLM provider functionality.
"""
