This module extends the base edi_ediversa_oca module to fetch and process Ediversa sale
order files.
