# TQML License

For a full and updated view on the license, please take a look [here](https://terraquantum.io/content/legal/eula-tq42-tqml/).
