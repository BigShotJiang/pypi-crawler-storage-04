from fastchat import TerminalChat

chat = TerminalChat(logger_lv="INFO")
chat.open()
