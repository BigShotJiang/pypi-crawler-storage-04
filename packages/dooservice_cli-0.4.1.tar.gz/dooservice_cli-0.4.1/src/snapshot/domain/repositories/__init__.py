"""Snapshot repositories."""
