"""Snapshot module for dooservice-cli."""
