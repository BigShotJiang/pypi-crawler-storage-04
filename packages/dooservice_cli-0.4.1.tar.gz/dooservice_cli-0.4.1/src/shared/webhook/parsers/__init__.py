"""Webhook payload parsers for different providers."""
