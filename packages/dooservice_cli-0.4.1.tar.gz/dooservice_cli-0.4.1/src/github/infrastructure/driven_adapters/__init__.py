"""GitHub infrastructure driven adapters."""
