You need to click the list view setting (the last column in the list view) and enable "Amount to Invoice" to show this filed in the list view. Same thing for the quotation order lines.
