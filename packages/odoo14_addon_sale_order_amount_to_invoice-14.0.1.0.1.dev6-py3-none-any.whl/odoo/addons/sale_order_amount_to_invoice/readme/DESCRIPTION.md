This module adds "Amount to Invoice" for quotations/sales orders. It is displayed:

- In order lines. You need to show this field because it's hidden by default
- In the quotation form view
- In the quotation list view. You need to show this field because it's hidden by default 
