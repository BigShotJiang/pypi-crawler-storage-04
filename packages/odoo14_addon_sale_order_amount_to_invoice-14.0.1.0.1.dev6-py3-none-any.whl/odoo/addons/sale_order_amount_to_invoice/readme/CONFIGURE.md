No configuration is required.
