Sometimes you would like to see total amount to invoice for all your sales orders.
