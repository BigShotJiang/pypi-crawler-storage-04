This module allows to enforce default reminders on meeting activity types.
