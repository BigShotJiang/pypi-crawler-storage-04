def main() -> None:
    print("Hello from authmint!")
