# See LICENSE file for full copyright and licensing details.

from . import test_hotel_reservation
