"""
Callbacks integration for Neatlogs.
"""
