---
height: 2
---

## Job Assessment Summary
[documentation](https://databrickslabs.github.io/ucx/docs/reference/workflows/#assessment-workflow)
