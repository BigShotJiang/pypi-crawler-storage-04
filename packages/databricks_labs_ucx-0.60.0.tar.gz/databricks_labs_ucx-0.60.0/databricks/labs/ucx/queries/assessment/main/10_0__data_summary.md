## Data summary

- "Asset Replication Required" means that data must be copied into Unity Catalog tables (CTAS or DEEP CLONE)

- "In Place Sync" means that tables can be migrated by syncing the metadata only! The data remains in place.

[documentation](https://databrickslabs.github.io/ucx/docs/reference/workflows/#assessment-workflow)
