---
height: 4
---

# Other
Global Init Scripts
- Object permissions
- Delta Live Tables
- Global Init Scripts
- Warning messages

[documentation](https://databrickslabs.github.io/ucx/docs/reference/workflows/#assessment-workflow)
