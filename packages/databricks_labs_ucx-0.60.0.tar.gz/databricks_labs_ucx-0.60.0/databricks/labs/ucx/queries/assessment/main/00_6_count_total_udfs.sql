/* --title 'Total UDFs' */
SELECT
  COUNT(*) AS count_total_udfs
FROM inventory.udfs