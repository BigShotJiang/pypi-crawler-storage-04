---
height: 2
---

## Compute summary
[documentation](https://databrickslabs.github.io/ucx/docs/reference/workflows/#assessment-workflow)
