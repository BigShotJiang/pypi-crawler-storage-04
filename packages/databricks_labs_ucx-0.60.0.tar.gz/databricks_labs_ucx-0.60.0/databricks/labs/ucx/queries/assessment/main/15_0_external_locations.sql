/* --title 'External Locations' --width 3 --height 6 --type table */
SELECT
  location
FROM inventory.external_locations