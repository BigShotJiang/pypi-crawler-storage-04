# DO NOT MODIFY THIS FILE
__version__ = "0.60.0"
