# Speed Skydiving Scoring has moved!

### You may score your jumps and analyze your performance at:

# [speedskydiving.app](https://speedskydiving.app)

### See you there!

---
Copyright &copy; 2019-2025 by Eugene Ciurana DBA **pr3d4t0r Speed Skydiving
Team**, and CIME Sofware Ltd.

**<a href='https://github.com/pr3d4t0r/SSScoring' target='_blank'>SSScore</a>** and all its components are released under the BSD-3 open source license.

This product includes Streamlit software developed by Snowflake, Inc. used
under the Apache 2.0 license.


