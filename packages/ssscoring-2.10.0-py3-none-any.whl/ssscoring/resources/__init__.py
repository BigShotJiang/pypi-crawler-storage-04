# See: https://github.com/pr3d4t0r/SSScoring/blob/master/LICENSE.txt

# Module / namespace initializer for the resource.

