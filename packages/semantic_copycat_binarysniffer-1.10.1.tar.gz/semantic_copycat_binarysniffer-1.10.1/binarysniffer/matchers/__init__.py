"""
Matching algorithms for signature detection
"""

from .progressive import ProgressiveMatcher

__all__ = ["ProgressiveMatcher"]