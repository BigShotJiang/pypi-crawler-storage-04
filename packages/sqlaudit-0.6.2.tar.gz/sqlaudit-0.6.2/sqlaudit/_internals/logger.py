import logging

logger = logging.getLogger("SQLAudit")
