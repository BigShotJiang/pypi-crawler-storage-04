# langchain_parquet_logger/__init__.py
from .logger import ParquetLogger

__version__ = "0.1.5"

__all__ = ['ParquetLogger', '__version__']