from .core import get_configer

__all__ = ['get_configer']
