from .serve import InferServer, JobDescription

__all__ = [
    'InferServer',
    "JobDescription"
]
