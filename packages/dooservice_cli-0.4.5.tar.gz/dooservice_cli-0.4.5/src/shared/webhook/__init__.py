"""Shared webhook infrastructure for multi-provider webhooks."""
