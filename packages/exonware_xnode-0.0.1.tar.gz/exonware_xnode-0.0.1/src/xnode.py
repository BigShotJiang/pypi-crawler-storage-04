"""
Convenience module for importing xnode.

This allows users to import the library in two ways:
1. import exonware.xnode
2. import xnode  # This convenience import

Company: eXonware.com
Author: Eng. Muhammad AlShehri
Email: connect@exonware.com
Version: 0.0.1
Generation Date: February 2, 2025
"""

# Import everything from the main package
from exonware.xnode import *  # noqa: F401, F403

# Preserve the version
__version__ = "0.0.1"