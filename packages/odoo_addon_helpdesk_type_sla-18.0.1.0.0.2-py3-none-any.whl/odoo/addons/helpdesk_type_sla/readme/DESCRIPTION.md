This module adds an option for the user to select help desk ticket types
as an argument to the SLA functionality in the Helpdesk SLA module.
