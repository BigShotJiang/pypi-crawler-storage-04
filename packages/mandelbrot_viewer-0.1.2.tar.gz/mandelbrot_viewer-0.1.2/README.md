# mandelbrot-set-viewer
An interactive arbitrary precision Mandelbrot set viewer using my [taichi_big_float](https://github.com/balazs-szalai/taichi-bigfloat) package.

## Usage
You have to have the taichi-bigfloat package installed and then you just have to launch the mandlebrot_viewer_main.py.
