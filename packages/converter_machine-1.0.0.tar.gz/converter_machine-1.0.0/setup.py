from setuptools import setup, find_packages

setup(
    name='Converter_machine',
    version='1.0.0',
    description='A unit conversion library for time, mass, length, temperature, and more',
    author='Amir M. Kimiaei',
    author_email="a.m.kimiaei84@email.com",
    url="https://github.com/AmirKimiaei/converter_machine",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[],
    classifiers=[
        'Programming Language :: Python :: 3',
         "License :: OSI Approved :: MIT License",
        'Operating System :: OS Independent',
    ],
)
