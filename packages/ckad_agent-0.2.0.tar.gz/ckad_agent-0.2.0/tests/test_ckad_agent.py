"""Tests for ckad_agent package."""

def test_version():
    """Test that the package version is set."""
    import ckad_agent
    assert ckad_agent.__version__ == "0.1.0"
