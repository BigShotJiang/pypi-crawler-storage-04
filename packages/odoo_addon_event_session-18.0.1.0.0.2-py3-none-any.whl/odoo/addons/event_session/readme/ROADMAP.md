- In the sessions form view, for now is possible to modify multiple
  sessions at the same time. This can be a bit weird for the user
  without having the "SAVE" button, as it's difficult to know when the
  record is going to be saved exactly. This feature is inspired by a
  core feature from recurring Calendar Events. And it seems that Odoo
  hasn't handle this dissaperance of the "SAVE" button .
  With this in mind, where propossed thre solutions:  
  1.  Keep it as-is
  2.  Deprecate/ remove this feature
  3.  Find a better way, in terms of UX
