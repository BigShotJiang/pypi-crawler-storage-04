def hi():
    print("Hi!")
