::: easydiffraction.experiments
