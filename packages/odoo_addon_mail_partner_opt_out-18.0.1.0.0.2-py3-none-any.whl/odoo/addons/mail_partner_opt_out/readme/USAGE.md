Go to a partner. Next to the partner's email address you will see a plus
symbol. Once you press it the partner's email address will be
blacklisted and then a ban will appear. If you click that ban the email
address will be removed from the blacklist.

You can also filter for the Blacklist attribute, to see all the
partner's that their email has been added to the blacklist.
