This module adds the capability for a user to add a partner's email
address to the blackmail list so that she will not receive any emails
from mass mailing campaigns
