// C++ header
