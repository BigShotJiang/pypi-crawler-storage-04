"""Aplicativo de linha de comando para exibir graficos do MetaTrader 5 em texto."""

from . import bars, conf, data, logger, models, views
