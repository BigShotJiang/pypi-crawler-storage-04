"""Webhook interface definitions."""
