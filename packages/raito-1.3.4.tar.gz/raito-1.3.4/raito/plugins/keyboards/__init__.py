from .dynamic import dynamic_keyboard as dynamic
from .static import static_keyboard as static

__all__ = (
    "dynamic",
    "static",
)
