from pathlib import Path

__all__ = ("StrOrPath",)

StrOrPath = str | Path
