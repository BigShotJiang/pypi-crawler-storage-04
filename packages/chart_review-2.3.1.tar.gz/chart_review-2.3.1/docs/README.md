# Chart Review Documentation

These documents are meant to be built as one part of the larger body of
[Cumulus documentation](https://docs.smarthealthit.org/cumulus).

To test changes here locally, read more at the [Cumulus docs repo](https://github.com/smart-on-fhir/cumulus).
