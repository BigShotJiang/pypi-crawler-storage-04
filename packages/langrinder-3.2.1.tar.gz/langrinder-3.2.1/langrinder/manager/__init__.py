from .manager import LocaleManager
