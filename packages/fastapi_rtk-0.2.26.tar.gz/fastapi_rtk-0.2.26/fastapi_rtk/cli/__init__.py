import fastapi_cli.cli

from .cli import main
