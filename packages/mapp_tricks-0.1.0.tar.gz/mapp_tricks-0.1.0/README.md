# mapp-tricks
Reusable code developed during my PhD in the Medical Applications of Particle Physics group at the University of Bern.


