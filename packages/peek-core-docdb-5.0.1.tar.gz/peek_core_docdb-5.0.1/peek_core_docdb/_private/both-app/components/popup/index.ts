export * from "./popup.component";
