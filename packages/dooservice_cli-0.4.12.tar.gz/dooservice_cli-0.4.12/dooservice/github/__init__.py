"""GitHub integration domain."""
