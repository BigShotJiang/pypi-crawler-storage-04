"""Snapshot driven adapters."""
