"""Snapshot application layer."""
