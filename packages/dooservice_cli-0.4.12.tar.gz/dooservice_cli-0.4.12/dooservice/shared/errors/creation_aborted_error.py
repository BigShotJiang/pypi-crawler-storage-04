class CreationAbortedError(Exception):
    """Raised when the user aborts the creation process."""
