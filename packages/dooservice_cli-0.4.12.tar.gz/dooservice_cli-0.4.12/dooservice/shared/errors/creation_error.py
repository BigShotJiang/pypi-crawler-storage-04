class CreationError(Exception):
    """Raised when a generic error occurs during instance creation."""
