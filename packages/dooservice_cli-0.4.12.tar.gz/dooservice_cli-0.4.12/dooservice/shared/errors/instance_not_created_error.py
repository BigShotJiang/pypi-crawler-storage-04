class InstanceNotCreatedError(Exception):
    """Raised when trying to sync an instance that has not been created yet."""
