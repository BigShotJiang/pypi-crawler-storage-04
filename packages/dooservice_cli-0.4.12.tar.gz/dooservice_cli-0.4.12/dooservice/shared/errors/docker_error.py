class DockerError(Exception):
    """Custom exception for Docker-related errors."""
