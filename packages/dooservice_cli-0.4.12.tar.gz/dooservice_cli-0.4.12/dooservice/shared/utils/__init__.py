"""General utility functions and helpers."""
