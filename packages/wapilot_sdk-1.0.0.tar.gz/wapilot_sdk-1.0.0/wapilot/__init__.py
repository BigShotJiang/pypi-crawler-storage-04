from .client import WapilotSDK

__version__ = '1.0.0'
__all__ = ['WapilotSDK']
