from rich.console import Console
console = Console()
"""Qdrant vector database client implementation."""