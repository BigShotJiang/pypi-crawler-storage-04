from rich.console import Console
console = Console()
"""Optional imports for RAG configuration providers."""