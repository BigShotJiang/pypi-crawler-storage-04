from rich.console import Console
console = Console()
from rich.console import Console
from rich.table import Table
from jaygoga_orchestra.v1.cli.command import BaseCommand
from jaygoga_orchestra.v1.cli.config import Settings, READONLY_SETTINGS_KEYS, HIDDEN_SETTINGS_KEYS
from typing import Any

console = Console()

class SettingsCommand(BaseCommand):
    """A class to handle CLI configuration commands."""

    def __init__(self, settings_kwargs: dict[str, Any] = {}):
        super().__init__()
        self.settings = Settings(**settings_kwargs)

    def list(self) -> None:
        """List all CLI configuration parameters."""
        table = Table(title="Govinda CLI Configuration")
        table.add_column("Setting", style="cyan", no_wrap=True)
        table.add_column("Value", style="green")
        table.add_column("Description", style="yellow")

        # Add all settings to the table
        for field_name, field_info in Settings.model_fields.items():
            if field_name in HIDDEN_SETTINGS_KEYS:
                # Do not display hidden settings
                continue

            current_value = getattr(self.settings, field_name)
            description = field_info.description or "No description available"
            display_value = (
                str(current_value) if current_value is not None else "Not set"
            )

            table.add_row(field_name, display_value, description)

        print(table)

    def set(self, key: str, value: str) -> None:
        """Set a CLI configuration parameter."""

        readonly_settings = READONLY_SETTINGS_KEYS + HIDDEN_SETTINGS_KEYS

        if not hasattr(self.settings, key) or key in readonly_settings:
            print(
                f"Error: Unknown or readonly configuration key '{key}'",
                style="bold red",
            )
            print("Available keys:", style="yellow")
            for field_name in Settings.model_fields.keys():
                if field_name not in readonly_settings:
                    print(f"  - {field_name}", style="yellow")
            raise SystemExit(1)

        setattr(self.settings, key, value)
        self.settings.dump()

        print(f"Successfully set '{key}' to '{value}'", style="bold green")

    def reset_all_settings(self) -> None:
        """Reset all CLI configuration parameters to default values."""
        self.settings.reset()
        print(
            "Successfully reset all configuration parameters to default values. It is recommended to run [bold yellow]'jaygoga_orchestra.v1 login'[/bold yellow] to re-authenticate.",
            style="bold green",
        )