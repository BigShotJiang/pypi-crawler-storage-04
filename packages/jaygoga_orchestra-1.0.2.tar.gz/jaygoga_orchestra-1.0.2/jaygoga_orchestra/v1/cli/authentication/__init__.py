from rich.console import Console
console = Console()
from .main import AuthenticationCommand

__all__ = ["AuthenticationCommand"]