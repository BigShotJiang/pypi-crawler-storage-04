from rich.console import Console
console = Console()
"""Event utilities for crewAI."""