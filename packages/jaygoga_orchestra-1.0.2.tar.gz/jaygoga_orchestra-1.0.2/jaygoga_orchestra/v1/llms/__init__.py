from rich.console import Console
console = Console()
"""LLM implementations for crewAI."""