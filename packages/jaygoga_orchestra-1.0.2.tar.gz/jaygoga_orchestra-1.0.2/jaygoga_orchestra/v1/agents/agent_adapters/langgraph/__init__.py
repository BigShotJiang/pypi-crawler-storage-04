from rich.console import Console
console = Console()
"""LangGraph adapter for crewAI."""