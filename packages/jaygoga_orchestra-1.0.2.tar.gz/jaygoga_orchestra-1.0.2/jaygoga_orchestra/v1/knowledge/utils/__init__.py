from rich.console import Console
console = Console()
"""Knowledge utilities for crewAI."""