from rich.console import Console
console = Console()
from jaygoga_orchestra.v2.embedder.base import Embedder

__all__ = [
    "Embedder",
]