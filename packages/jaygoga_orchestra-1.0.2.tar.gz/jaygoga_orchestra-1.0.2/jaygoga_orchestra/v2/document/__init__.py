from rich.console import Console
console = Console()
from jaygoga_orchestra.v2.document.base import Document

__all__ = [
    "Document",
]