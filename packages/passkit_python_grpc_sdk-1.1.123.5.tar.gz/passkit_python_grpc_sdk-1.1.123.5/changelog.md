## [1.1.123.5] - 2025-08-28
### Breaking Changes
The project’s package structure has been reorganized to simplify imports and align modules consistently:

- The **`passkit_io`** folder has been renamed to **`io`**.  
- The **`io`** folder and the existing **`ct`** folder are now contained inside the **`passkit`** package. 