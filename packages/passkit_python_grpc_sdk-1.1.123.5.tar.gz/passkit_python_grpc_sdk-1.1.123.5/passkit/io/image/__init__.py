def get_image_pb2():
    import io.image.image_pb2
    return io.image.image_pb2


def get_image_pb2_grpc():
    import io.image.image_pb2_grpc
    return io.image.image_pb2_grpc
