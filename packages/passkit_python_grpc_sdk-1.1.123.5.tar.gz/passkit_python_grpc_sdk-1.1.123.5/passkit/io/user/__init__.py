def get_user_pb2():
    import io.user.user_pb2
    return io.user.user_pb2


def get_user_pb2_grpc():
    import io.user.user_pb2_grpc
    return io.user.user_pb2_grpc
