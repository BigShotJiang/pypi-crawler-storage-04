def get_a_rpc_pb2():
    import io.flights.a_rpc_pb2
    return io.flights.a_rpc_pb2


def get_a_rpc_pb2_grpc():
    import io.flights.a_rpc_pb2_grpc
    return io.flights.a_rpc_pb2_grpc


def get_airport_pb2():
    import io.flights.airport_pb2
    return io.flights.airport_pb2


def get_airport_pb2_grpc():
    import io.flights.airport_pb2_grpc
    return io.flights.airport_pb2_grpc


def get_barcode_pb2():
    import io.flights.barcode_pb2
    return io.flights.barcode_pb2


def get_barcode_pb2_grpc():
    import io.flights.barcode_pb2_grpc
    return io.flights.barcode_pb2_grpc


def get_boarding_pass_pb2():
    import io.flights.boarding_pass_pb2
    return io.flights.boarding_pass_pb2


def get_boarding_pass_pb2_grpc():
    import io.flights.boarding_pass_pb2_grpc
    return io.flights.boarding_pass_pb2_grpc


def get_cabin_codes():
    import io.flights.cabin_codes
    return io.flights.cabin_codes


def get_carrier_pb2():
    import io.flights.carrier_pb2
    return io.flights.carrier_pb2


def get_carrier_pb2_grpc():
    import io.flights.carrier_pb2_grpc
    return io.flights.carrier_pb2_grpc


def get_flight_designator_pb2():
    import io.flights.flight_designator_pb2
    return io.flights.flight_designator_pb2


def get_flight_designator_pb2_grpc():
    import io.flights.flight_designator_pb2_grpc
    return io.flights.flight_designator_pb2_grpc


def get_flight_pb2():
    import io.flights.flight_pb2
    return io.flights.flight_pb2


def get_flight_pb2_grpc():
    import io.flights.flight_pb2_grpc
    return io.flights.flight_pb2_grpc


def get_passenger_pb2():
    import io.flights.passenger_pb2
    return io.flights.passenger_pb2


def get_passenger_pb2_grpc():
    import io.flights.passenger_pb2_grpc
    return io.flights.passenger_pb2_grpc
