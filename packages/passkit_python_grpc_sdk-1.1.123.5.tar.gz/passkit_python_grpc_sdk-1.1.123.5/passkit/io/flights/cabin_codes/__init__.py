def get_cabin_codes_pb2():
    import io.flights.cabin_codes.cabin_codes_pb2
    return io.flights.cabin_codes.cabin_codes_pb2


def get_cabin_codes_pb2_grpc():
    import io.flights.cabin_codes.cabin_codes_pb2_grpc
    return io.flights.cabin_codes.cabin_codes_pb2_grpc
