def get_a_rpc_pb2():
    import io.raw.a_rpc_pb2
    return io.raw.a_rpc_pb2


def get_a_rpc_pb2_grpc():
    import io.raw.a_rpc_pb2_grpc
    return io.raw.a_rpc_pb2_grpc


def get_pass_pb2():
    import io.raw.pass_pb2
    return io.raw.pass_pb2


def get_pass_pb2_grpc():
    import io.raw.pass_pb2_grpc
    return io.raw.pass_pb2_grpc


def get_project_pb2():
    import io.raw.project_pb2
    return io.raw.project_pb2


def get_project_pb2_grpc():
    import io.raw.project_pb2_grpc
    return io.raw.project_pb2_grpc
