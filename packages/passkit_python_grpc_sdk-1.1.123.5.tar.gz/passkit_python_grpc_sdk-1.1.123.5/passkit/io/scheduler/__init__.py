def get_a_rpc_pb2():
    import io.scheduler.a_rpc_pb2
    return io.scheduler.a_rpc_pb2


def get_a_rpc_pb2_grpc():
    import io.scheduler.a_rpc_pb2_grpc
    return io.scheduler.a_rpc_pb2_grpc


def get_scheduler_pb2():
    import io.scheduler.scheduler_pb2
    return io.scheduler.scheduler_pb2


def get_scheduler_pb2_grpc():
    import io.scheduler.scheduler_pb2_grpc
    return io.scheduler.scheduler_pb2_grpc
