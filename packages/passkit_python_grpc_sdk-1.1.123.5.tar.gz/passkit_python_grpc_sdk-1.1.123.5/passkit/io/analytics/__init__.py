def get_a_rpc_pb2():
    import io.analytics.a_rpc_pb2
    return io.analytics.a_rpc_pb2


def get_a_rpc_pb2_grpc():
    import io.analytics.a_rpc_pb2_grpc
    return io.analytics.a_rpc_pb2_grpc
