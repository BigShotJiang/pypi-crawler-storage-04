def get_certificate_pb2():
    import io.certificate.certificate_pb2
    return io.certificate.certificate_pb2


def get_certificate_pb2_grpc():
    import io.certificate.certificate_pb2_grpc
    return io.certificate.certificate_pb2_grpc
