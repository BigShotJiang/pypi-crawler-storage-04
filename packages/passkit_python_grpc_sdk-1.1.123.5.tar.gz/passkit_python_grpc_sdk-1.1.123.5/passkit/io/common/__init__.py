def get_operation_pb2():
    import io.common.operation_pb2
    return io.common.operation_pb2


def get_operation_pb2_grpc():
    import io.common.operation_pb2_grpc
    return io.common.operation_pb2_grpc


def get_attributes_pb2():
    import io.common.attributes_pb2
    return io.common.attributes_pb2


def get_attributes_pb2_grpc():
    import io.common.attributes_pb2_grpc
    return io.common.attributes_pb2_grpc


def get_billing_pb2():
    import io.common.billing_pb2
    return io.common.billing_pb2


def get_billing_pb2_grpc():
    import io.common.billing_pb2_grpc
    return io.common.billing_pb2_grpc


def get_pagination_pb2():
    import io.common.pagination_pb2
    return io.common.pagination_pb2


def get_pagination_pb2_grpc():
    import io.common.pagination_pb2_grpc
    return io.common.pagination_pb2_grpc


def get_pass_pb2():
    import io.common.pass_pb2
    return io.common.pass_pb2


def get_pass_pb2_grpc():
    import io.common.pass_pb2_grpc
    return io.common.pass_pb2_grpc


def get_common_objects_pb2():
    import io.common.common_objects_pb2
    return io.common.common_objects_pb2


def get_common_objects_pb2_grpc():
    import io.common.common_objects_pb2_grpc
    return io.common.common_objects_pb2_grpc


def get_distribution_pb2():
    import io.common.distribution_pb2
    return io.common.distribution_pb2


def get_distribution_pb2_grpc():
    import io.common.distribution_pb2_grpc
    return io.common.distribution_pb2_grpc


def get_personal_pb2():
    import io.common.personal_pb2
    return io.common.personal_pb2


def get_personal_pb2_grpc():
    import io.common.personal_pb2_grpc
    return io.common.personal_pb2_grpc


def get_project_pb2():
    import io.common.project_pb2
    return io.common.project_pb2


def get_project_pb2_grpc():
    import io.common.project_pb2_grpc
    return io.common.project_pb2_grpc


def get_protocols_pb2():
    import io.common.protocols_pb2
    return io.common.protocols_pb2


def get_protocols_pb2_grpc():
    import io.common.protocols_pb2_grpc
    return io.common.protocols_pb2_grpc


def get_proximity_pb2():
    import io.common.proximity_pb2
    return io.common.proximity_pb2


def get_proximity_pb2_grpc():
    import io.common.proximity_pb2_grpc
    return io.common.proximity_pb2_grpc


def get_reporting_pb2():
    import io.common.reporting_pb2
    return io.common.reporting_pb2


def get_reporting_pb2_grpc():
    import io.common.reporting_pb2_grpc
    return io.common.reporting_pb2_grpc


def get_template_pb2():
    import io.common.template_pb2
    return io.common.template_pb2


def get_template_pb2_grpc():
    import io.common.template_pb2_grpc
    return io.common.template_pb2_grpc


def get_tracking_pb2():
    import io.common.tracking_pb2
    return io.common.tracking_pb2


def get_tracking_pb2_grpc():
    import io.common.tracking_pb2_grpc
    return io.common.tracking_pb2_grpc


def get_transaction_pb2():
    import io.common.transaction_pb2
    return io.common.transaction_pb2


def get_transaction_pb2_grpc():
    import io.common.transaction_pb2_grpc
    return io.common.transaction_pb2_grpc


def get_useragent_pb2():
    import io.common.useragent_pb2
    return io.common.useragent_pb2


def get_useragent_pb2_grpc():
    import io.common.useragent_pb2_grpc
    return io.common.useragent_pb2_grpc


def get_links_pb2():
    import io.common.links_pb2
    return io.common.links_pb2


def get_links_pb2_grpc():
    import io.common.links_pb2_grpc
    return io.common.links_pb2_grpc


def get_localization_pb2():
    import io.common.localization_pb2
    return io.common.localization_pb2


def get_localization_pb2_grpc():
    import io.common.localization_pb2_grpc
    return io.common.localization_pb2_grpc


def get_message_pb2():
    import io.common.message_pb2
    return io.common.message_pb2


def get_message_pb2_grpc():
    import io.common.message_pb2_grpc
    return io.common.message_pb2_grpc


def get_metrics_pb2():
    import io.common.metrics_pb2
    return io.common.metrics_pb2


def get_metrics_pb2_grpc():
    import io.common.metrics_pb2_grpc
    return io.common.metrics_pb2_grpc


def get_note_pb2():
    import io.common.note_pb2
    return io.common.note_pb2


def get_note_pb2_grpc():
    import io.common.note_pb2_grpc
    return io.common.note_pb2_grpc


def get_semantics_pb2():
    import io.common.semantics_pb2
    return io.common.semantics_pb2


def get_semantics_pb2_grpc():
    import io.common.semantics_pb2_grpc
    return io.common.semantics_pb2_grpc
