# passkit/__init__.py

def get_io():
    import passkit.io
    return passkit.io


def get_ct():
    import passkit.ct
    return passkit.ct
