from typing import Any, Dict

BaseParameterSpace = Dict[str, Any]
