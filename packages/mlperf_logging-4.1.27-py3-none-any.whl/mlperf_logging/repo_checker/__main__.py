from . import repo_checker

repo_checker.main()
