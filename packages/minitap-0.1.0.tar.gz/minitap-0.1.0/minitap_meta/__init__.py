"""
No content is needed since it's simply a meta-package.
Only the dependencies matter!
"""