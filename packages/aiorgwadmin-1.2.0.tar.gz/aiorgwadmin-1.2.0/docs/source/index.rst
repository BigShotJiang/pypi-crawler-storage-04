rgwadmin
========

rgwadmin is a Python library to access the Ceph Object Storage Admin API.

http://docs.ceph.com/docs/master/radosgw/adminops/


Contents:
---------

.. toctree::
   :maxdepth: 1
   :glob:

   rgwadmin/installation
   rgwadmin/user-guide
   api


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
