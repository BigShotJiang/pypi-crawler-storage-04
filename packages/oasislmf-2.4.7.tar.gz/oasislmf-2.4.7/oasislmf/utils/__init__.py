"""
Utils for stuff
"""
