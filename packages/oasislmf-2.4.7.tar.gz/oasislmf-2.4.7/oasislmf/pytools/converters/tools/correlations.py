from oasislmf.pytools.common.data import correlations_headers, correlations_dtype, correlations_fmt


headers = correlations_headers
dtype = correlations_dtype
fmt = correlations_fmt
cli_support = ['bintocsv', 'csvtobin']
