from oasislmf.pytools.common.data import gul_headers, gul_dtype, gul_fmt


headers = gul_headers
dtype = gul_dtype
fmt = gul_fmt
cli_support = ['bintocsv', 'csvtobin']
