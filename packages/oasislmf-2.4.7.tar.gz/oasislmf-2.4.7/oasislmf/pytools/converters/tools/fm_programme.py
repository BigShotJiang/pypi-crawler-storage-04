from oasislmf.pytools.common.data import fm_programme_headers, fm_programme_dtype, fm_programme_fmt


headers = fm_programme_headers
dtype = fm_programme_dtype
fmt = fm_programme_fmt
cli_support = ['bintocsv', 'csvtobin']
