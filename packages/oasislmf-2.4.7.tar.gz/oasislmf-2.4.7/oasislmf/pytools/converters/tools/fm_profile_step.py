from oasislmf.pytools.common.data import fm_profile_step_headers, fm_profile_step_dtype, fm_profile_step_fmt


headers = fm_profile_step_headers
dtype = fm_profile_step_dtype
fmt = fm_profile_step_fmt
cli_support = ['bintocsv', 'csvtobin']
