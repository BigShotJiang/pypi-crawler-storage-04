from oasislmf.pytools.lec.data import EPT_headers, EPT_dtype, EPT_fmt


headers = EPT_headers
dtype = EPT_dtype
fmt = EPT_fmt
cli_support = ['bintocsv', 'csvtobin', 'bintoparquet', 'parquettobin']
