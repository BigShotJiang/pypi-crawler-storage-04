from oasislmf.pytools.common.data import lossfactors_headers, lossfactors_dtype, lossfactors_fmt


headers = lossfactors_headers
dtype = lossfactors_dtype
fmt = lossfactors_fmt
cli_support = ['bintocsv', 'csvtobin']
