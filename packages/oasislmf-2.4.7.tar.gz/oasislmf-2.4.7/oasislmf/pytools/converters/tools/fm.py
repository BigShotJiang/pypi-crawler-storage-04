from oasislmf.pytools.common.data import fm_headers, fm_dtype, fm_fmt


headers = fm_headers
dtype = fm_dtype
fmt = fm_fmt
cli_support = ['bintocsv', 'csvtobin']
