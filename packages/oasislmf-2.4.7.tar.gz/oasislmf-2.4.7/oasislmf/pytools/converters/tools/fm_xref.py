from oasislmf.pytools.common.data import fm_xref_headers, fm_xref_dtype, fm_xref_fmt


headers = fm_xref_headers
dtype = fm_xref_dtype
fmt = fm_xref_fmt
cli_support = ['bintocsv', 'csvtobin']
