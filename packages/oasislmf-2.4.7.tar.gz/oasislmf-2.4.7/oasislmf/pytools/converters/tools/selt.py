from oasislmf.pytools.elt.data import SELT_headers, SELT_dtype, SELT_fmt


headers = SELT_headers
dtype = SELT_dtype
fmt = SELT_fmt
cli_support = ['bintocsv', 'csvtobin', 'bintoparquet', 'parquettobin']
