from oasislmf.pytools.common.data import occurrence_headers, occurrence_dtype, occurrence_fmt


headers = occurrence_headers
dtype = occurrence_dtype
fmt = occurrence_fmt
cli_support = ['bintocsv', 'csvtobin']
