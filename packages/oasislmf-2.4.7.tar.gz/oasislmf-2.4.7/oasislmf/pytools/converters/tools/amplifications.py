from oasislmf.pytools.common.data import amplifications_headers, amplifications_dtype, amplifications_fmt


headers = amplifications_headers
dtype = amplifications_dtype
fmt = amplifications_fmt
cli_support = ['bintocsv', 'csvtobin']
