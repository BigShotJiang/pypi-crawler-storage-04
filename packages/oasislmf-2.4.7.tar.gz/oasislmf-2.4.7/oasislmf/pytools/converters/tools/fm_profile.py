from oasislmf.pytools.common.data import fm_profile_headers, fm_profile_dtype, fm_profile_fmt


headers = fm_profile_headers
dtype = fm_profile_dtype
fmt = fm_profile_fmt
cli_support = ['bintocsv', 'csvtobin']
