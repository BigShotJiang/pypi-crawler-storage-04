from oasislmf.pytools.common.data import damagebin_headers, damagebin_dtype, damagebin_fmt


headers = damagebin_headers
dtype = damagebin_dtype
fmt = damagebin_fmt
cli_support = ['bintocsv', 'csvtobin']
