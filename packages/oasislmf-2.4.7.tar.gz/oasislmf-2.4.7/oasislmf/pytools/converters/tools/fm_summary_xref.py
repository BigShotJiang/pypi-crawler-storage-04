from oasislmf.pytools.common.data import fm_summary_xref_headers, fm_summary_xref_dtype, fm_summary_xref_fmt


headers = fm_summary_xref_headers
dtype = fm_summary_xref_dtype
fmt = fm_summary_xref_fmt
cli_support = ['bintocsv', 'csvtobin']
