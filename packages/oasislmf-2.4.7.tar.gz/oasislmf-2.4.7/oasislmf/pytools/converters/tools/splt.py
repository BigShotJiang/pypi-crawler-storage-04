from oasislmf.pytools.plt.data import SPLT_headers, SPLT_dtype, SPLT_fmt


headers = SPLT_headers
dtype = SPLT_dtype
fmt = SPLT_fmt
cli_support = ['bintocsv', 'csvtobin', 'bintoparquet', 'parquettobin']
