from oasislmf.pytools.lec.data import PSEPT_headers, PSEPT_dtype, PSEPT_fmt


headers = PSEPT_headers
dtype = PSEPT_dtype
fmt = PSEPT_fmt
cli_support = ['bintocsv', 'csvtobin', 'bintoparquet', 'parquettobin']
