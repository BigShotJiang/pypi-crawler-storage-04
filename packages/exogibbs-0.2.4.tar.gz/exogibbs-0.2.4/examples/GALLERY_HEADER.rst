|:art:| More Practical Samples
================================