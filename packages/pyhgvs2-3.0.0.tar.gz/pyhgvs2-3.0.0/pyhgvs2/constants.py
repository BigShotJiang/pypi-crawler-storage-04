CHROM_PREFIX = "chr"
CDNA_START_CODON = "cdna_start"
CDNA_STOP_CODON = "cdna_stop"
