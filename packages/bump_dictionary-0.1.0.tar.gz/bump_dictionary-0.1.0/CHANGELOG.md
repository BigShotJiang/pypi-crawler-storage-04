# v0.1.0 (Thu Aug 28 2025)

:tada: This release contains work from a new contributor! :tada:

Thank you, Alyssa Dai ([@alyssadai](https://github.com/alyssadai)), for all your work!

#### 🚀 Enhancements

- [ENH] Typer app to remove deprecated `Identifies` and add `VariableType` to old data dictionaries [#3](https://github.com/neurobagel/bump-dictionary/pull/3) ([@alyssadai](https://github.com/alyssadai))

#### ⚠️ Pushed to `main`

- Initial commit ([@alyssadai](https://github.com/alyssadai))

#### Authors: 1

- Alyssa Dai ([@alyssadai](https://github.com/alyssadai))
