from django.test import TestCase


class SpireChildAppTransformationServiceTestCase(TestCase):
    def setUp(self):
        super().setUp()
