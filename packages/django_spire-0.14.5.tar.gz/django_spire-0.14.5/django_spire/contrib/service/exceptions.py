from django_spire.exceptions import DjangoSpireException


class ServiceException(DjangoSpireException):
    pass