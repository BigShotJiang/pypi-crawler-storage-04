from .processor import process_file, process_directory
