# AI-Mem Backend API

FastAPI backend service for AI-Mem system.