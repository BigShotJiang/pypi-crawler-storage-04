MF_MAJOR: int = 1
MF_MINOR: int = 0
MF_PATCH: int = 0