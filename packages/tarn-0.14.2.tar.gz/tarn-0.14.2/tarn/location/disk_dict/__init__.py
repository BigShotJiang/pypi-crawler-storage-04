from .location import DiskDict
