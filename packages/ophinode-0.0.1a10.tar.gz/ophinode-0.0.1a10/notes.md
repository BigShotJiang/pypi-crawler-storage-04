1. Devise some way to distinguish options that are not set in order to respect page group options.
2. finish create_subcontext()


add render options
- add newline or no newline at the end of render
- how many indents
- auto newline / auto indent controls
