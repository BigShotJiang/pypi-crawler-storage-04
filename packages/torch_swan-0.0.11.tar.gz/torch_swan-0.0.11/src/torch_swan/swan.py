class Swan:
    def sing(self):
        return "Swan song"
