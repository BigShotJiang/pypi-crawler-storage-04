"""HeHe Noob CLI - A command-line interface for noobs"""

__version__ = "1.0.0"
__author__ = "Tur Za"
__email__ = "write2turza@gmail.com"

from .cli import HeHeNoobCLI, main

__all__ = ["HeHeNoobCLI", "main"]