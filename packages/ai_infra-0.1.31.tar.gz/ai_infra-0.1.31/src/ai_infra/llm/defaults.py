from ai_infra import Providers
from ai_infra.llm import Models

MODEL = Models.openai.default.value
PROVIDER = Providers.openai