console.log("JavaScript loaded");
