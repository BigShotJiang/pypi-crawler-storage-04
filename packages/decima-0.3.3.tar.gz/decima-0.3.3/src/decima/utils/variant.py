def process_variants(variants, ad=None, min_from_end=0):
    raise DeprecationWarning("process_variants is deprecated. Use `VariantDataset.overlap_genes` instead.")
