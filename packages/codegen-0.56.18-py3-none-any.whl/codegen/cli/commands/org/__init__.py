"""Organization management command."""

from .main import org

__all__ = ["org"]