"""Agent command module."""
