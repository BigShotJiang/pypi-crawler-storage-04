class APINotApplicableForLanguageError(Exception):
    pass
