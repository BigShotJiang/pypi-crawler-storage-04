from . import res_config_settings
from . import ir_actions_report
from . import product_packaging
from . import res_company
