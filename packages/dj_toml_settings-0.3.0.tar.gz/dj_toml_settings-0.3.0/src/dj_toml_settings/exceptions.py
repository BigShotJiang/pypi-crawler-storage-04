class InvalidActionError(Exception):
    pass
