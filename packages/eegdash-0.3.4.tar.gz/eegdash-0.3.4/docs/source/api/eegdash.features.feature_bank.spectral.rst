eegdash.features.feature\_bank.spectral module
==============================================

.. automodule:: eegdash.features.feature_bank.spectral
   :members:
   :undoc-members:
   :show-inheritance:
