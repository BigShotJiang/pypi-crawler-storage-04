eegdash.features package
========================

.. automodule:: eegdash.features
   :members:
   :undoc-members:
   :show-inheritance:

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   eegdash.features.feature_bank

Submodules
----------

.. toctree::
   :maxdepth: 4

   eegdash.features.datasets
   eegdash.features.decorators
   eegdash.features.extractors
   eegdash.features.inspect
   eegdash.features.serialization
   eegdash.features.utils
