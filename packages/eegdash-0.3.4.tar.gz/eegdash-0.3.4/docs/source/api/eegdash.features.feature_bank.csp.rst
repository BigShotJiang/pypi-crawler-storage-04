eegdash.features.feature\_bank.csp module
=========================================

.. automodule:: eegdash.features.feature_bank.csp
   :members:
   :undoc-members:
   :show-inheritance:
