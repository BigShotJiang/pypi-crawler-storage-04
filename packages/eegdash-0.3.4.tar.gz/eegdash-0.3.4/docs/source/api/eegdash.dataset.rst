eegdash.dataset module
======================

.. automodule:: eegdash.dataset
   :members:
   :undoc-members:
   :show-inheritance:
