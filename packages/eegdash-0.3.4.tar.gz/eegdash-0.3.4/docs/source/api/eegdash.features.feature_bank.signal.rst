eegdash.features.feature\_bank.signal module
============================================

.. automodule:: eegdash.features.feature_bank.signal
   :members:
   :undoc-members:
   :show-inheritance:
