eegdash.data\_config module
===========================

.. automodule:: eegdash.data_config
   :members:
   :undoc-members:
   :show-inheritance:
