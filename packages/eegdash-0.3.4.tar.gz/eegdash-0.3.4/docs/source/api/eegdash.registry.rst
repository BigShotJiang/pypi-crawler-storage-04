eegdash.registry module
=======================

.. automodule:: eegdash.registry
   :members:
   :undoc-members:
   :show-inheritance:
