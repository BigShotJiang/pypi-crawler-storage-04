__version__ = "0.2.0"
__author__ = "Carl Viggo Gravenhorst-Lövenstierne"

from .core import FundamentalDataFetcher

__all__ = ["FundamentalDataFetcher"] 