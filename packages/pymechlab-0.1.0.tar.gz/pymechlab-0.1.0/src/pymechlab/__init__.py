from .classes.batchresult import batch_from_json as batch_from_json
