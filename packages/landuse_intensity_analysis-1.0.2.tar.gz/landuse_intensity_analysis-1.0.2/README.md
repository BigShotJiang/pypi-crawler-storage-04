# LandUse-Intensity-Analysis

[![Python](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![PyPI](https://img.shields.io/pypi/v/landuse-intensity-analysis.svg)](https://pypi.org/project/landuse-intensity-analysis/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Code style: black](https://img.shields.io/badge/code%20style-black-000000.svg)](https://github.com/psf/black)
[![Ruff](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/ruff/main/assets/badge/v2.json)](https://github.com/astral-sh/ruff)

A modern Python package for quantitative analysis of land use and cover change (LUCC) implementing the **Pontius-Aldwaik intensity analysis methodology**.

## 🔬 Scientific Foundation

This package implements the scientifically rigorous methodology developed by:

- **Aldwaik, S. Z., & Pontius Jr, R. G.** (2012). *Intensity analysis to unify measurements of size and stationarity of land changes by interval, category, and transition.* Landscape and Urban Planning, 106(1), 103-114. [DOI: 10.1016/j.landurbplan.2012.02.007](https://doi.org/10.1016/j.landurbplan.2012.02.007)

## 🚀 Key Features

### 🎯 **Pontius Intensity Analysis**

- **Interval-level analysis**: Detect periods of fast/slow change
- **Category-level analysis**: Identify active/dormant land use categories  
- **Transition-level analysis**: Systematic vs. random change patterns
- **Quantity vs. Allocation disagreement** analysis

### 📊 **Scientific Visualizations**

- Publication-ready charts and statistical plots
- Interactive Sankey diagrams for transition flows
- Chord diagrams for change pattern visualization
- Customizable plotting with scientific color schemes

### 🗺️ **Spatial Analysis**

- Efficient raster data processing
- Multi-temporal landscape analysis
- Change detection and validation tools
- Landscape pattern metrics

## 📦 Installation

```bash
# Install from PyPI (recommended)
pip install landuse-intensity-analysis

# Install with visualization dependencies
pip install landuse-intensity-analysis[viz]

# Install development version
pip install git+https://github.com/ils15/LandUse-Intensity-Analysis.git
```

## 🔧 Quick Start

```python
import landuse_intensity as lui
import numpy as np

# Load demo data
landscape_t1 = lui.demo_landscape()
landscape_t2 = landscape_t1.copy()
landscape_t2[0:2, 0:2] = 3  # Simulate urban expansion

# Create transition matrix
transition_matrix = lui.get_transition_matrix(landscape_t1, landscape_t2)
print("Transition Matrix:")
print(transition_matrix)

# Calculate change metrics
metrics = lui.calculate_change_metrics(transition_matrix)
print(f"Total change: {metrics['change_ratio']:.1%}")

# Perform intensity analysis
results = lui.intensity_analysis(landscape_t1, landscape_t2, 
                                area_km2=100, time_periods=[2000, 2010])

# Visualize transitions
lui.plot_sankey(transition_matrix, 
                category_names={1: "Forest", 2: "Agriculture", 3: "Urban"})
```

## 📈 Core Functionality

### **Data Processing**

```python
# Load raster data
rasters = lui.load_rasters(['map_2000.tif', 'map_2010.tif'])

# Validate data consistency
lui.check_data_consistency(landscape_t1, landscape_t2)

# Calculate area statistics  
stats = lui.calculate_area_stats(landscape_t1, pixel_area=0.25)
```

### **Intensity Analysis**

```python
# Complete Pontius analysis
analysis = lui.IntensityAnalysis(transition_matrix, [2000, 2010])
interval_results = analysis.interval_level()
category_results = analysis.category_level()
transition_results = analysis.transition_level(from_cat=1, to_cat=3)
```

### **Visualization**

```python
# Create publication-ready plots
lui.plot_bar(metrics['net_change'], title="Net Change by Category")
lui.plot_chord_diagram(transition_matrix)
lui.netgross_plot(transition_matrix)
```

## 🏗️ Package Structure

```text
landuse_intensity/
├── __init__.py          # Main package interface
├── analysis.py          # Statistical analysis functions
├── intensity.py         # Pontius intensity analysis implementation
├── raster.py           # Spatial data processing
├── utils.py            # Utility functions and validation
└── visualization.py    # Scientific plotting functions
```

## 📚 Documentation

- **Scientific Background**: See `CITATION.cff` for complete references
- **API Documentation**: Available at [ReadTheDocs](https://landuse-intensity-analysis.readthedocs.io)
- **Examples**: Check the `examples/` directory
- **Contributing**: See `CONTRIBUTING.md`

## 🤝 Contributing

We welcome contributions! Please see our [Contributing Guidelines](CONTRIBUTING.md) for details.

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🏛️ Citation

If you use this package in your research, please cite:

```bibtex
@software{landuse_intensity_analysis,
  title = {LandUse-Intensity-Analysis: Python package for Pontius intensity analysis},
  author = {LandUse-Intensity-Analysis Contributors},
  year = {2025},
  url = {https://github.com/ils15/LandUse-Intensity-Analysis},
  version = {1.0.1}
}
```

## 🔗 Related Work

- [Original Pontius paper](https://doi.org/10.1016/j.landurbplan.2012.02.007)
- [Intensity Analysis methodology](https://www.clarku.edu/faculty/rpontius/)
- [Land change science community](https://www.gfc.unesp.br/#!/en/)

## ⭐ Acknowledgments

This package implements the pioneering methodology developed by **Robert Gilmore Pontius Jr.** and **Safaa Zakaria Aldwaik**. We acknowledge their fundamental contributions to land change science and intensity analysis.

---

Made with ❤️ for the land change science community
