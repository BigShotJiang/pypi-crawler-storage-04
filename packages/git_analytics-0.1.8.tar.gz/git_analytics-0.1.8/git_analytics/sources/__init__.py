from .git_commit_adapter import GitCommitSource

__all__ = [
    "GitCommitSource",
]
