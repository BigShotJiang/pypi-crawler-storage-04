On desktop, the user will be able to show and hide the search input in
the website header. While on mobile our searchbox will behave by
default.
