This module adds a search bar in the header of your website
