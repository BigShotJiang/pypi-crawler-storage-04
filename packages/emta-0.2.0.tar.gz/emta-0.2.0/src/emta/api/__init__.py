"""API module for the Eastmoney Trading Library."""
