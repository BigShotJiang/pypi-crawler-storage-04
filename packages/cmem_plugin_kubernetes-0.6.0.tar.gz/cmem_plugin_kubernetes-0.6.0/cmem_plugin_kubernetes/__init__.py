"""cmem-plugin-kubernetes"""
