# SPDX-FileCopyrightText: 2024-present Frank Hoffmann <15r10nk-git@polarbit.de>
#
# SPDX-License-Identifier: MIT
__version__ = "0.5.2"
