from ._codegen import generate

__all__ = ("generate",)

__version__ = "0.7.1"
