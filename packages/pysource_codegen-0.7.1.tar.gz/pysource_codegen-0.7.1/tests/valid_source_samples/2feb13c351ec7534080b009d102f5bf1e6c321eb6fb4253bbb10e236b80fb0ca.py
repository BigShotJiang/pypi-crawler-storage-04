def f(x):
    class c:
        nonlocal x
