match 0:
    case x if x:
        pass
    case _:
        pass
