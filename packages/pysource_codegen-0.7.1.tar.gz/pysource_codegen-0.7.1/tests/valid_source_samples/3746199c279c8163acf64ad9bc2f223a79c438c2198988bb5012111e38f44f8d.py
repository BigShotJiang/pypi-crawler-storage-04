name_2[name_1]: name_1 = name_0
