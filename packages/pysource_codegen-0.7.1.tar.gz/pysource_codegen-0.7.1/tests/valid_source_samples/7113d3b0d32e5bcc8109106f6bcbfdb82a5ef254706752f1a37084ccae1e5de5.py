match 0:
    case 0:
        pass
