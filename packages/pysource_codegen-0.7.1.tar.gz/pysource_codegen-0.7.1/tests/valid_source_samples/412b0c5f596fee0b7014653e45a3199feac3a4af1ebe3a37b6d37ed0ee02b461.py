del foo().e
