match x:
    case -0:
        pass
