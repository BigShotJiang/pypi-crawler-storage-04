class name_0(name_1 := something):
    pass
