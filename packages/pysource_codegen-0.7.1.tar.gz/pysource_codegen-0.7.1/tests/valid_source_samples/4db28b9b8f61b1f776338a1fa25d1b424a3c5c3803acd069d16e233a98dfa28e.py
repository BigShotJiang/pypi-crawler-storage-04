class name_1({name_0: name_1 for name_1 in name_5}):
    pass
