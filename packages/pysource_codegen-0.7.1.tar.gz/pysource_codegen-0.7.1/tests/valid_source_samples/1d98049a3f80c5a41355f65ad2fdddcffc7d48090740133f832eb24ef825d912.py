class TestSuper:
    class X:
        nonlocal __class__
