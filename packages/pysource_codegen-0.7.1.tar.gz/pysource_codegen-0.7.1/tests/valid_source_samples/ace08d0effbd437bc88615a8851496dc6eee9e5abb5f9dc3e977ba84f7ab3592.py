del foo()[1]
