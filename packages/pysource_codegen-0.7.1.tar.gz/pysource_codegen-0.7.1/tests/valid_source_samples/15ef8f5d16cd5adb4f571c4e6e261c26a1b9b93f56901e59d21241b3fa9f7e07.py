del _squeue[operator.indexOf()]
