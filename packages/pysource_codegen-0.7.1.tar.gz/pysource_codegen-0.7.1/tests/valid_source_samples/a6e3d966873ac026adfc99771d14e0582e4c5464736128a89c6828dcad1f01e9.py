del _squeue[something]
