async def name_4(name_2: {name_5 for name_1()[{*()}] in something}, /):
    pass
