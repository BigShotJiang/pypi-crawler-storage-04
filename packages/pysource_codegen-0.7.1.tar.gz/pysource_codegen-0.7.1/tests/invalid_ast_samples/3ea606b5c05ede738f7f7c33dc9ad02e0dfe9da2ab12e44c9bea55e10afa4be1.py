from ast import *

tree = Module(body=[Delete(targets=[])], type_ignores=[])

# version: 3.9.15
# seed = 4634023
#
# Source:
# del
#
#
# Error:
#     SyntaxError('invalid syntax', ('<file>', 1, 5, 'del \n'))
