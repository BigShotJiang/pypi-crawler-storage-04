from ai_infra.llm import Models, Providers

MODEL = Models.openai.default.value
PROVIDER = Providers.openai