class InstanceExistsError(Exception):
    """Raised when trying to create an instance that already exists."""
