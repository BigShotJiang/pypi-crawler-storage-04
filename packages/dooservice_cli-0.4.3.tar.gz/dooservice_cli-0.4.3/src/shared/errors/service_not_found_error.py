class ServiceNotFoundError(Exception):
    """Raised when a specific service is not found for an instance."""
