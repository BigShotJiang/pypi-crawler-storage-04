#ifndef QPS_CONVERSION_H
#define QPS_CONVERSION_H

char* convert_qps_to_new_format(const char* filename);

#endif