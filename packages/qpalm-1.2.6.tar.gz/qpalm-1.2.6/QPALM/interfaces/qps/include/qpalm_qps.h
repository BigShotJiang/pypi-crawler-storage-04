#ifndef QPALM_QPS_H
#define QPALM_QPS_H

#include <stdio.h>
int get_next_command(char* command, char next_char, FILE* fp);


#endif