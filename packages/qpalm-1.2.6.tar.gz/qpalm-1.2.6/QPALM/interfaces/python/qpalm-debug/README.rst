Debug symbols for the `qpalm <https://pypi.org/project/qpalm>`_ package.
