# 默认导入一次，避免使用时多一级
from .dingtalkrobot import DingTalkRobot