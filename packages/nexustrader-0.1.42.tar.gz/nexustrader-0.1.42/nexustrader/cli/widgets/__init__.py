"""CLI widgets for the NexusTrader monitoring interface."""
