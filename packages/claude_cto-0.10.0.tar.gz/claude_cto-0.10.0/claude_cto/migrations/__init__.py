"""Database migrations module for claude-cto."""
