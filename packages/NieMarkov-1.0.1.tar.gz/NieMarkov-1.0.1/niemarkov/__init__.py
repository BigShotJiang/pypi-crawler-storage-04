#!/usr/bin/env python3
from niemarkov.niemarkov import MarkovChain
__all__ = ['MarkovChain']
