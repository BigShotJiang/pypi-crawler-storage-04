# Changelog

## [0.0.7] - 2025-08-29
### Fixed
- Now you can retrieve existing old data from database using load_data method

### Updated
- Updated tests

## [0.0.6] - 2025-08-28
### Updated
- Added @db_exists decorator instead of repeating same code in every function

## [0.0.5] - 2025-08-26
### Added
- Column type 'BLOB' (class bytes)
- New exception -> EncodeError
- CHANGELOG.md

### Fixed
- Some annotations bugs
- edit_table inappropriate name check
- Other small issues
- Copyright text
- README.MD

### Updated
- Annotations. Now project supports Python of 3.5 or higher version
- Required aiosqlite version

### Removed
- Documentation href

## [0.0.4] - 2025-08-08
### Added
- License

### Fixed
- Some annotations bugs
