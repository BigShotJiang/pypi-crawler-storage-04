# Fullscreen Alert Module

A simple Python module to display fullscreen alert windows using tkinter.

## Installation

```bash
pip install fullscreen-alert