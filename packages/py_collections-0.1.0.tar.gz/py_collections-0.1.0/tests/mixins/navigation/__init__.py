"""Tests for NavigationMixin."""
