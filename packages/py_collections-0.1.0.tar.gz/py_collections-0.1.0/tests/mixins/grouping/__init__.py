"""Tests for GroupingMixin."""
