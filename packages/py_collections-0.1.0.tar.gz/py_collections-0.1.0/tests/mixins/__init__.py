"""Tests for mixin classes."""
