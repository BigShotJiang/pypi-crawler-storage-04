"""Tests for RemovalMixin."""
