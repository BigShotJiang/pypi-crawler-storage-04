# Advanced usage guide

In this guide, we'll describe some of the more advanced `viadot` concepts and workflows, such as:

- working in a containerized environment
- using secrets stores instead of the config file
- etc.
