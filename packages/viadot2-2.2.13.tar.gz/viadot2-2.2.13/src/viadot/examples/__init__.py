"""Examples of viadot usage."""
