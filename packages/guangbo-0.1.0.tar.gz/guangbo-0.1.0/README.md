# guangbo

一个简单的UDP广播发送库，用于向多个IP地址发送消息。

## 安装

```bash
pip install guangbo