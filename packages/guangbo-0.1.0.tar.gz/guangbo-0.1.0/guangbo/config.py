# 配置文件 - 广播模块

# 默认IP地址
DEFAULT_IP1 = "10.141.10.18"
DEFAULT_IP2 = "10.141.10.15"

# 端口号
PORT = 10130

# 消息内容
MESSAGE = b'runing'

# 地址文件路径
ADDRESS_FILE1 = "D:/NDF/不良载具/临时文件/广播地址.txt"
ADDRESS_FILE2 = "D:/NDF/不良载具/临时文件/广播地址2.txt"