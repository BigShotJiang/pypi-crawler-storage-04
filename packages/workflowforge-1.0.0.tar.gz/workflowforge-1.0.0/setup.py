from setuptools import find_packages, setup

setup(
    name="workflowforge",
    use_scm_version=True,
    setup_requires=["setuptools_scm"],
)
