export let docDbFilt = { plugin: "peek_core_docdb" };
export let docDbTuplePrefix = "peek_core_docdb.";

export let docDbObservableName = "peek_core_docdb";
export let docDbActionProcessorName = "peek_core_docdb";
export let docDbTupleOfflineServiceName = "peek_core_docdb";

export let docDbBaseUrl = "peek_core_docdb";

export let docDbCacheStorageName = "peek_core_docdb.cache";
