==============
Administration
==============

DocDB stores JSON like objects for use by other plugins.

For example, The diagram generic menu plugin search DocDB for additional properties
when presenting a menu to the user.


.. toctree::
    :maxdepth: 3
    :caption: Contents:

    overview
    status/status
    admin_tasks/admin_tasks

