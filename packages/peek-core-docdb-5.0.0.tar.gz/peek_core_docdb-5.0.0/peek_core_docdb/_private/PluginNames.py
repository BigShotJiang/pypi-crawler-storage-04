docDbFilt = {"plugin": "peek_core_docdb"}
docDbTuplePrefix = "peek_core_docdb."
docDbObservableName = "peek_core_docdb"
docDbActionProcessorName = "peek_core_docdb"
docDbTupleOfflineServiceName = "peek_core_docdb"
