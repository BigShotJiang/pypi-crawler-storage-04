from .dictature import Dictature
