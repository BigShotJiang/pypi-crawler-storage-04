"""
Tests package for pydantic2django.
"""

default_app_config = "tests.apps.TestsConfig"
