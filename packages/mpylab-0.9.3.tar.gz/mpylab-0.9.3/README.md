This is MpyLab. MpyLab is a framework for automatic measurement application and 
hardware device drivers (TCP/IP, GPIB, serial, USB).

This software is distributed unter GPL-3 or higher. See LICENCE for details.
