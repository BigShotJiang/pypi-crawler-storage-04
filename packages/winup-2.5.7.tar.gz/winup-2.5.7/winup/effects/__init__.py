# winup/effects/__init__.py
# This module is intended for non-animation visual effects.
# Currently empty, ready for future expansion. 