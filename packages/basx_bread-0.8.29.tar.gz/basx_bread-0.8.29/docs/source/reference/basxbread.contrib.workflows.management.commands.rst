basxbread.contrib.workflows.management.commands package
=======================================================

.. automodule:: basxbread.contrib.workflows.management.commands
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

basxbread.contrib.workflows.management.commands.activity\_diagram module
------------------------------------------------------------------------

.. automodule:: basxbread.contrib.workflows.management.commands.activity_diagram
   :members:
   :undoc-members:
   :show-inheritance:

basxbread.contrib.workflows.management.commands.dot\_diagram module
-------------------------------------------------------------------

.. automodule:: basxbread.contrib.workflows.management.commands.dot_diagram
   :members:
   :undoc-members:
   :show-inheritance:
