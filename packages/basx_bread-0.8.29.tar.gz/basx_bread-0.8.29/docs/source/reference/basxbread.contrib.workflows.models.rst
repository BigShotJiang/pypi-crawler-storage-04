basxbread.contrib.workflows.models package
==========================================

.. automodule:: basxbread.contrib.workflows.models
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

basxbread.contrib.workflows.models.base module
----------------------------------------------

.. automodule:: basxbread.contrib.workflows.models.base
   :members:
   :undoc-members:
   :show-inheritance:

basxbread.contrib.workflows.models.nodes module
-----------------------------------------------

.. automodule:: basxbread.contrib.workflows.models.nodes
   :members:
   :undoc-members:
   :show-inheritance:
