basxbread.contrib.workflows package
===================================

.. automodule:: basxbread.contrib.workflows
   :members:
   :undoc-members:
   :show-inheritance:

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   basxbread.contrib.workflows.management
   basxbread.contrib.workflows.models

Submodules
----------

basxbread.contrib.workflows.settings module
-------------------------------------------

.. automodule:: basxbread.contrib.workflows.settings
   :members:
   :undoc-members:
   :show-inheritance:

basxbread.contrib.workflows.urls module
---------------------------------------

.. automodule:: basxbread.contrib.workflows.urls
   :members:
   :undoc-members:
   :show-inheritance:

basxbread.contrib.workflows.views module
----------------------------------------

.. automodule:: basxbread.contrib.workflows.views
   :members:
   :undoc-members:
   :show-inheritance:
