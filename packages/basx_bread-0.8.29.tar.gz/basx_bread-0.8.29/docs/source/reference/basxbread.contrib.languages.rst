basxbread.contrib.languages package
===================================

.. automodule:: basxbread.contrib.languages
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

basxbread.contrib.languages.fields module
-----------------------------------------

.. automodule:: basxbread.contrib.languages.fields
   :members:
   :undoc-members:
   :show-inheritance:

basxbread.contrib.languages.languages module
--------------------------------------------

.. automodule:: basxbread.contrib.languages.languages
   :members:
   :undoc-members:
   :show-inheritance:

basxbread.contrib.languages.regenerate module
---------------------------------------------

.. automodule:: basxbread.contrib.languages.regenerate
   :members:
   :undoc-members:
   :show-inheritance:

basxbread.contrib.languages.urls module
---------------------------------------

.. automodule:: basxbread.contrib.languages.urls
   :members:
   :undoc-members:
   :show-inheritance:
