basxbread.contrib.modeledit package
===================================

.. automodule:: basxbread.contrib.modeledit
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

basxbread.contrib.modeledit.parser module
-----------------------------------------

.. automodule:: basxbread.contrib.modeledit.parser
   :members:
   :undoc-members:
   :show-inheritance:

basxbread.contrib.modeledit.urls module
---------------------------------------

.. automodule:: basxbread.contrib.modeledit.urls
   :members:
   :undoc-members:
   :show-inheritance:

basxbread.contrib.modeledit.views module
----------------------------------------

.. automodule:: basxbread.contrib.modeledit.views
   :members:
   :undoc-members:
   :show-inheritance:
