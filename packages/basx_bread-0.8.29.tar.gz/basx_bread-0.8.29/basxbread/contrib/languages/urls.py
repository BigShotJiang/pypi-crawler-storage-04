from typing import List

urlpatterns: List[None] = []
