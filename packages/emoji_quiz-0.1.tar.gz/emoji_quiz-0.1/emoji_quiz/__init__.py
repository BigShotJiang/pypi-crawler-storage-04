"""Emoji Movie Quiz module."""
