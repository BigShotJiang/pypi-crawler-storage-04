STATE = "state"
DATA = "data"
CONTEXT = "context"
TEMPLATE = "template"

SHARED_DATA = '/sessions'

STOP_COMMAND = "stop"

IMAGE_ANNOTATION_EVENTS = ["manual_selected_figure_changed"]