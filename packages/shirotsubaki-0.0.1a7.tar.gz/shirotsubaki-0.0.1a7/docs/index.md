# Shirotsubaki

Shirotsubaki is a package designed to help you generate beautiful reports.  
You can install it from [PyPI](https://pypi.org/project/shirotsubaki/).
```
pip install shirotsubaki
```

Examples:

- [Examples](examples.md)

API References:

- [Reference (Main Report Class)](reference_report.md)
- [Reference (Utility Functions)](reference_utils.md)
