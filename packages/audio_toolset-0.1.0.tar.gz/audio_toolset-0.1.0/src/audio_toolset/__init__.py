def main() -> None:
    print("Hello from audio-toolset!")
