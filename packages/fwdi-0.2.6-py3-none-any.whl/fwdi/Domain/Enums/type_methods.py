from enum import Enum

class TypeMethod(Enum):
    Instance = 0
    Static = 1
    Classmethod = 2