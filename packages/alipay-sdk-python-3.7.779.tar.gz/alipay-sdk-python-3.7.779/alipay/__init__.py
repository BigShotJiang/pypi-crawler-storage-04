#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
    __inti__.py
"""
name = "alipay-sdk-python"
__version__ = "3.7.779"