from __future__ import annotations

parallel = 4
job_timeout = 80
checkout_blocks_and_plots = True
