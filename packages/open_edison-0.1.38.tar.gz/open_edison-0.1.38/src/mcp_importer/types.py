"""Type helpers for MCP importer."""

from __future__ import annotations

# This module intentionally minimal to avoid unused code flags.
