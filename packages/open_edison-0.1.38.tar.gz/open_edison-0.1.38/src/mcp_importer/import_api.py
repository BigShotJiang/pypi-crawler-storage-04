from __future__ import annotations

# legacy helpers were removed to satisfy deadcode scanning
