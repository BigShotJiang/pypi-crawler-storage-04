"""
Main package for shap toolbox plugin.
"""
