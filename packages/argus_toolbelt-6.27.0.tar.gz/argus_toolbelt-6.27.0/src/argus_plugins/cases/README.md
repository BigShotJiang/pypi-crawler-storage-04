# Cases plugin
This folder contains commands for the *cases* plugin.