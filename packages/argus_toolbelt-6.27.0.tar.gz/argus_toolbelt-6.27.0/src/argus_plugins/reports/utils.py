"""Constants and common functions related to reports"""

PERIOD = (
    "day",
    "week",
    "custom",
    "month",
    "quarter",
    "year",
    "last_hour",
    "last_24hours",
    "last_7days",
)
STATUS = ("new", "assigned", "in_progress", "completed")
