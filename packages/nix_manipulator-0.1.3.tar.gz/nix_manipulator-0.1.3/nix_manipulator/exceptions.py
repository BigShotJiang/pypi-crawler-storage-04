class NixSyntaxError(SyntaxError):
    pass
