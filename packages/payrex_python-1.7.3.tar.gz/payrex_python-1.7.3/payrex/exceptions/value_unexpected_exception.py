class ValueUnexpectedException(Exception):
    pass
