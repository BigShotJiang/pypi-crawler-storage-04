class SignatureInvalidException(Exception):
    pass
