from pathlib import Path

_dir = Path(__file__).parent.parent.parent / 'testdata'
TESTDATA_FILE_ROUTES = _dir / 'plugin_translate_linux_routes.json'
TESTDATA_FILE_ROUTE_RULES = _dir / 'plugin_translate_linux_route-rules.json'
TESTDATA_FILE_NIS = _dir / 'plugin_translate_linux_interfaces.json'
TESTDATA_FILE_NF_RULESET = _dir / 'plugin_translate_netfilter_ruleset.json'

TEST_WAN_IP4 = '10.255.255.48'
TEST_WAN_IP6 = '2001:4bc9:1f9a:cfe6:aaaa:11e2:5f14:1793'
