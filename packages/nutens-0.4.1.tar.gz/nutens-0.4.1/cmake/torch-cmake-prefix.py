import torch

print(torch.utils.cmake_prefix_path, end="")
