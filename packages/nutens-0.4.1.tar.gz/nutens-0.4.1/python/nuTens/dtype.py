from ._pyNuTens import dtype
from ._pyNuTens.dtype import *