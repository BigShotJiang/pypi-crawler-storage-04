from ._pyNuTens import propagator
from ._pyNuTens.propagator import *