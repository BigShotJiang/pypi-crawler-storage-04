from ._pyNuTens import tensor
from ._pyNuTens.tensor import *