/* This is not really the Linux config program. */

int main(int argc, char** argv) {
  return 0;
}
