
class ModelState(dict):
    pass


