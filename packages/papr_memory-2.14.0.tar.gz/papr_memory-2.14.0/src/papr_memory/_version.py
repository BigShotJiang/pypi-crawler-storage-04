# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

__title__ = "papr_memory"
__version__ = "2.14.0"  # x-release-please-version
