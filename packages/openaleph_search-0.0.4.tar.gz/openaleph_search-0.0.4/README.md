# openaleph-search

OpenAleph index & search module
