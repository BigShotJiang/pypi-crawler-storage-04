from .small_logger import Logger
