# Copyright (c) 2024–2025, TeleCMI
# SPDX-License-Identifier: BSD 2-Clause License

# Put your signaling URL here (no trailing slash)
SIGNALING_URL = "https://signaling.piopiy.com"
