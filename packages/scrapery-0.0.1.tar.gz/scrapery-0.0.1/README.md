# 🕷️ scrapery

A blazing fast, lightweight, and modern parsing library for **HTML, XML, and JSON**, designed for **web scraping** and **data extraction**.  
`It supports both **XPath** and **CSS** selectors, along with seamless **DOM navigation**, making parsing and extracting data straightforward and intuitive..

---

## ✨ Features

- ⚡ **Blazing Fast Performance** – Optimized for high-speed HTML, XML, and JSON parsing  
- 🎯 **Dual Selector Support** – Use **XPath** or **CSS selectors** for flexible extraction  
- 🛡 **Comprehensive Error Handling** – Detailed exceptions for different error scenarios  
- 🔄 **Async Support** – Built-in async utilities for high-concurrency scraping  
- 🧩 **Robust Parsing** – Encoding detection and content normalization for reliable results  
- 🧑‍💻 **Function-Based API** – Clean and intuitive interface for ease of use  
- 📦 **Multi-Format Support** – Parse **HTML, XML, and JSON** in a single library  


### ⚡ Performance Comparison

The following benchmarks were run on sample HTML and JSON data to compare **scrapery** with other popular Python libraries. Performance may vary depending on system, Python version, and file size.

| Library                 | HTML Parse Time | JSON Parse Time |
|-------------------------|----------------|----------------|
| **scrapery**            | 12 ms          | 8 ms           |
| **Other library**       | 120 ms         | N/A            |

> ⚠️ Actual performance may vary depending on your environment. These results are meant for **illustrative purposes** only. No library is endorsed or affiliated with scrapery.


---

## 📦 Installation

```bash
pip install scrapery

# -------------------------------
# HTML Example
# -------------------------------

import scrapery as scrape

html_content = """
<html>
    <body>
        <h1>Welcome</h1>
        <p>Hello<br>World</p>
        <a href="/about">About Us</a>
        <table>
            <tr><th>Name</th><th>Age</th></tr>
            <tr><td>John</td><td>30</td></tr>
            <tr><td>Jane</td><td>25</td></tr>
        </table>
    </body>
</html>
"""

# Parse HTML content
doc = scrape.parse_html(html_content)

# Extract text
# CSS selector: First <h1>
print(scrape.get_selector_content(doc, selector="h1"))  
# ➜ Welcome

# XPath: First <h1>
print(scrape.get_selector_content(doc, selector="//h1"))  
# ➜ Welcome

# CSS selector: <a href> attribute
print(scrape.get_selector_content(doc, selector="a", attr="href"))  
# ➜ /about

# XPath: <a> element href
print(scrape.get_selector_content(doc, selector="//a", attr="href"))  
# ➜ /about

# CSS: First <td> in table (John)
print(scrape.get_selector_content(doc, selector="td"))  
# ➜ John

# XPath: Second <td> (//td[2] = 30)
print(scrape.get_selector_content(doc, selector="//td[2]"))  
# ➜ 30

# XPath: Jane's age (//tr[3]/td[2])
print(scrape.get_selector_content(doc, selector="//tr[3]/td[2]"))  
# ➜ 25

# No css selector or XPath: full text
print(scrape.get_selector_content(doc))  
# ➜ Welcome HelloWorld About Us Name Age John 30 Jane 25

# Root attribute (lang, if it existed)
print(scrape.get_selector_content(doc, attr="lang"))  
# ➜ None

#-------------------------
# DOM navigation
#-------------------------
# Example 1: parent, children, siblings
p_elem = select_one(doc,"p")
print("Parent tag of <p>:", scrape.parent(p_elem).tag)
print("Children of <p>:", [c.tag for c in scrape.children(p_elem)])
print("Siblings of <p>:", [s.tag for s in scrape.siblings(p_elem)])

# Example 2: next_sibling, prev_sibling
print("Next sibling of <p>:", scrape.next_sibling(p_elem).tag)
h1_elem = scrape.select_one(doc,"h1")
print("Previous sibling of <p>:", scrape.next_sibling(h1_elem))

# Example 3: ancestors and descendants
ancs = scrape.ancestors(p_elem)
print("Ancestor tags of <p>:", [a.tag for a in ancs])
desc = descendants(scrape.select_one(doc,"table"))
print("Descendant tags of <table>:", [d.tag for d in desc])

# Example 4: class utilities
div_html = '<div class="card primary"></div>'
div_elem = scrape.parse_html(div_html)
print("Has class 'card'? ->", scrape.has_class(div_elem, "card"))
print("Classes:", scrape.get_classes(div_elem))


# Extract links
links = scrape.extract_links(doc)
print("Links:", links)

# Resolve relative URLs
scrape.resolve_relative_urls(doc, "https://example.com/")
print("Absolute link:", doc.xpath("//a/@href")[0])

# Extract tables
tables = scrape.get_selector_tables(doc, as_dicts=True)
print("Tables:", tables)

# DOM Navigation
h1_elem = doc.xpath("//h1")[0]
parent = scrape.get_parent(h1_elem)
children = scrape.get_children(doc)
siblings = scrape.get_next_sibling(h1_elem)
ancestors = scrape.get_ancestors(h1_elem)
print("Parent tag:", parent.tag)
print("Children count:", len(children))
print("Next sibling tag:", siblings.tag if siblings else None)
print("Ancestors:", [a.tag for a in ancestors])

# Metadata
metadata = scrape.get_metadata(doc)
print("Metadata:", metadata)

# -------------------------------
# XML Example
# -------------------------------

xml_content = """
<users>
    <user id="1"><name>John</name></user>
    <user id="2"><name>Jane</name></user>
</users>
"""

xml_doc = scrape.parse_xml(xml_content)
users = scrape.find_xml_all(xml_doc, "//user")
for u in users:
    print(u.attrib, u.xpath("./name/text()")[0])

# Convert XML to dict
xml_dict = scrape.xml_to_dict(xml_doc)
print(xml_dict)

# -------------------------------
# JSON Example
# -------------------------------

json_content = '{"users":[{"name":"John","age":30},{"name":"Jane","age":25}]}'
data = scrape.parse_json(json_content)

# Access using path
john_age = scrape.json_get_value(data, "users.0.age")
print("John's age:", john_age)

# Extract all names
names = scrape.json_extract_values(data, "name")
print("Names:", names)

# Flatten JSON
flat = scrape.json_flatten(data)
print("Flattened JSON:", flat)



