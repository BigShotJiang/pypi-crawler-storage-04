"""FakeGRPC server implementation"""
