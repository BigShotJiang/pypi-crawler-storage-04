Welcome to Observability Client Release Notes documentation!
============================================================

Contents
========

.. toctree::
   :maxdepth: 2

   unreleased
   2025.1

Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
