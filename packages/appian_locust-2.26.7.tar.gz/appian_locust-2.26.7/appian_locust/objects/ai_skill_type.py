from enum import Enum


class AISkillObjectType(Enum):
    DOCUMENT_CLASSIFICATION = 2
    DOCUMENT_EXTRACTION = 5
    EMAIL_CLASSIFICATION = 8
