"""Configuration module for BERNN."""

from .training_config import TrainingConfig

__all__ = ['TrainingConfig']
