# Whitebox Plugin - GPS Simulator

This is a plugin for [whitebox](https://gitlab.com/whitebox-aero) that simulates GPS data.

## Installation

Simply install the plugin to whitebox:

```
poetry add whitebox-plugin-gps-simulator
```

## Additional Instructions

- [Plugin Development Guide](https://docs.whitebox.aero/plugin_guide/#plugin-development-workflow)
- [Plugin Testing Guide](https://docs.whitebox.aero/plugin_guide/#testing-plugins)
- [Contributing Guidelines](https://docs.whitebox.aero/development_guide/#contributing)
