from dataclasses import dataclass


@dataclass
class RemoveUserReportTicketRequest:
    user_report_ticket_id: str
