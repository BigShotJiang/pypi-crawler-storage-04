from dataclasses import dataclass


@dataclass
class GetOwnersFiatWithdrawRequest:
    cbu: str
