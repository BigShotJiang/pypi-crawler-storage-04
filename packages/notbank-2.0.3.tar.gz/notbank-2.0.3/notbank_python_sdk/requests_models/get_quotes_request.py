from dataclasses import dataclass


@dataclass
class GetQuotesRequest:
    mode: str

