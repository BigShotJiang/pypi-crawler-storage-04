def main() -> None:
    print("Hello from solidbox!")
