# solidbox

Composable building blocks for Python backends.

## Installation

```
pip install solidbox
```

## Documentation

https://aliev.me/solidbox
