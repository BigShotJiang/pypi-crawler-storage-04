"""
LeVibes - Motivational Image Caption Generator

A tool for generating motivational captions and adding them to images.
"""

__version__ = "0.1.0"
__author__ = "makors"
