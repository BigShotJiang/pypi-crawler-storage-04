"""
Utility functions for LeVibes
"""
