# Install

```
pip install mlflow-fr
```

# Tests

```
pytest test.py
```