# Copyright (c) 2016 Taylor Marks
# Copyright (c) 2016 Adam Karpierz
# SPDX-License-Identifier: MIT

__import__("pkg_about").about("let3")
