from .ElectricBlind import ElectricBlind

"""Class for Electrically operated window class Objects"""


class ElectricWindow(ElectricBlind):
    EOJCC = 0x65
