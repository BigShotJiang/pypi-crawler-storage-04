from .ElectricBlind import ElectricBlind

"""Class for Electrically operated shutter Objects"""


class ElectricShutter(ElectricBlind):
    EOJCC = 0x61
