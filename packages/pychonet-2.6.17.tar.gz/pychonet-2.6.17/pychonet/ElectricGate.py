from .ElectricBlind import ElectricBlind

"""Class for Electrically operated gate Objects"""


class ElectricGate(ElectricBlind):
    EOJCC = 0x64
