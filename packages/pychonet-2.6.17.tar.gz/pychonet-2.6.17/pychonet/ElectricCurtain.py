from .ElectricBlind import ElectricBlind

"""Class for Electrically operated curtain Objects"""


class ElectricCurtain(ElectricBlind):
    EOJCC = 0x62
