from enum import Enum


class ArtesianMetadataFacetType(Enum):
    Property = 0
    Tag = 1
