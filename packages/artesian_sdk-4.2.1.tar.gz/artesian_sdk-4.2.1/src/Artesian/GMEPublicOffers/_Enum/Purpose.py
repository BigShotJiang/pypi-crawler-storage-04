from enum import Enum


class Purpose(Enum):
    BID = 1
    OFF = 2
