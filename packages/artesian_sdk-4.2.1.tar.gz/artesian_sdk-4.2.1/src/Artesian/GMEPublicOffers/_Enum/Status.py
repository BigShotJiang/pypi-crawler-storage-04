from enum import Enum


class Status(Enum):
    ACC = 1
    INC = 2
    REJ = 3
    REP = 4
    REV = 5
    SUB = 6
    COM = 7
    PCOM = 8
