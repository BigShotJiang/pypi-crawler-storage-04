"""
Classes and decorators to configure heuristics.
"""
from ._nearby_selection import *
