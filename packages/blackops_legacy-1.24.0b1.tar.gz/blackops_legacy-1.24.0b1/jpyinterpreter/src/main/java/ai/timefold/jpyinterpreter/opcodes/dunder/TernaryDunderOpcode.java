package ai.timefold.jpyinterpreter.opcodes.dunder;

public class TernaryDunderOpcode {

}
