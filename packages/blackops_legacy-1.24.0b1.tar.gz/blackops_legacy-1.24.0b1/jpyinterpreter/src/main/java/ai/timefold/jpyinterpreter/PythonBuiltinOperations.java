package ai.timefold.jpyinterpreter;

public class PythonBuiltinOperations {
}
