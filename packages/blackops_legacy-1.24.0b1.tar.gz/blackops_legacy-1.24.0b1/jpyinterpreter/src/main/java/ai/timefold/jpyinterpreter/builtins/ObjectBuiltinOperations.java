package ai.timefold.jpyinterpreter.builtins;

public class ObjectBuiltinOperations {
}
