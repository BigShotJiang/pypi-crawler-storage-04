# -*- coding: utf-8 -*-
"""
---------------------------------------------
Created on 2025/6/8 13:24
@author: ZhangYundi
@email: yundi.xxii@outlook.com
@description: 
---------------------------------------------
"""

import sys
import quda

if __name__ == '__main__':
    quda.update()