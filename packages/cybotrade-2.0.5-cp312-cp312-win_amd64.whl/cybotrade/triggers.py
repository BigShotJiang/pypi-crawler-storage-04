import apscheduler.triggers.cron
import apscheduler.triggers.interval
import apscheduler.triggers.calendarinterval
import apscheduler.triggers.date

CronTrigger = apscheduler.triggers.cron.CronTrigger
IntervalTrigger = apscheduler.triggers.interval.IntervalTrigger
CalendarIntervalTrigger = apscheduler.triggers.calendarinterval.CalendarIntervalTrigger
DateTrigger = apscheduler.triggers.date.DateTrigger
