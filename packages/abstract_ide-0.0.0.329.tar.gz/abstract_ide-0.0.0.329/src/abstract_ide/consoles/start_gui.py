from reactRunnerTab import reactRunnerTab

from abstract_gui.QT6 import  startConsole

startConsole(reactRunnerTab)
