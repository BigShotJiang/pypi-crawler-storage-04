from .logTab import logTab,startLogConsole
from .consoles import *
