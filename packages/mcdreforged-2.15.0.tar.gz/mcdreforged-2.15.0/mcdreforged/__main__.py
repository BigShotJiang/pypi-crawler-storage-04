"""
Entrypoint for the mcdreforged module
"""
from mcdreforged import mcdr_entrypoint


def main():
	return mcdr_entrypoint.entrypoint()


if __name__ == '__main__':
	main()
