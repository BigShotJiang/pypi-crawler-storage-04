class RequirementCheckFailure(Exception):
	pass
