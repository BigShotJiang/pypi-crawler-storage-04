### Added
- Optional solvation step that adds an explicit water box when none is present.

### Changed
- Water molecules are now preserved during protein preparation by default.
