# IEEE Std. 1685-2022

Source: http://www.accellera.org/XMLSchema/IPXACT/1685-2022/

[License file](LICENSE)  
[Notice file](NOTICE)
