# VideoSDK Neuphonic Plugin

Agent Framework plugin for TTS services from Neuphonic.

## Installation

```bash
pip install videosdk-plugins-neuphonic
```
