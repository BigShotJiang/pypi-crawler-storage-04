# Datahub Dagster Plugin

See the [DataHub Dagster docs](https://docs.datahub.com/docs/lineage/dagster/) for details.
