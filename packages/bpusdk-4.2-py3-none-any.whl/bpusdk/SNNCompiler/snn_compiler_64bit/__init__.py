"""SNN 模型编译成 SMT 64 语句
"""
from . import *