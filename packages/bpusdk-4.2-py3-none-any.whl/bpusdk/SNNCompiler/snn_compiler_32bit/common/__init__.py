"""公共资源
"""

from typing import Union

Number = Union[int, float]
"""数字类型
"""
