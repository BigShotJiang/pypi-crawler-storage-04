"""SNN 模型编译成 SMT 96 语句
"""
from . import *
