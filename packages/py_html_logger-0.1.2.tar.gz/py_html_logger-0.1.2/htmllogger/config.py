# Configuration settings for the HTML logger | py-html-logger.config()

max_files = 15
max_size = 5_000_000   # 5 MB
main_filename = "log.html"
log_dir = "logs"
