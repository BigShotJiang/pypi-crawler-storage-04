class FileUtilitiesError(Exception):
    """Base class for file utility exceptions."""

    pass
