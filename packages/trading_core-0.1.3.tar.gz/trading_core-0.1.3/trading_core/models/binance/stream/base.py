from sqlalchemy.orm import declarative_base
StreamKline = declarative_base()
MarkPriceUpdate = declarative_base()