"""Learning PyPI Demo Package

A simple educational package to demonstrate PyPI publishing process.
"""

from .core import hello

__version__ = "0.1.1"
__author__ = "nisimi"
__email__ = ""

__all__ = ["hello"]
