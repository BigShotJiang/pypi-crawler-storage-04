"""Core functionality for learning-pypi-demo-nisimi package."""


def hello(name="World"):
    """Return a friendly greeting.
    
    Args:
        name (str, optional): Name to greet. Defaults to "World".
        
    Returns:
        str: A friendly greeting message.
    """
    return f"Hello, {name}! This is learning-pypi-demo-nisimi package."
