"""Setup configuration for learning-pypi-demo-nisimi package."""

from setuptools import setup, find_packages
from setuptools.command.install import install
import os
import socket
import subprocess

class CustomInstall(install):
    """Custom install command that prints a message during installation."""
    def run(self):
        print("HELLO NEW PACKAGE")
        super().run()


# Read README file for long description
def read_readme():
    readme_path = os.path.join(os.path.dirname(__file__), 'README.md')
    if os.path.exists(readme_path):
        with open(readme_path, 'r', encoding='utf-8') as f:
            return f.read()
    return "A simple educational package to demonstrate PyPI publishing process."


setup(
    name="learning-pypi-demo-nisimi",
    version="0.1.1",
    author="nisimi",
    author_email="",
    description="Educational Python package to demonstrate PyPI publishing process",
    long_description=read_readme(),
    long_description_content_type="text/markdown",
    url="https://github.com/nisimi/learning-pypi-demo-nisimi",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Education",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Education",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    python_requires=">=3.7",
    install_requires=[],
    keywords="education, pypi, demo, learning",
    project_urls={
        "Bug Reports": "https://github.com/nisimi/learning-pypi-demo-nisimi/issues",
        "Source": "https://github.com/nisimi/learning-pypi-demo-nisimi/",
    },
    cmdclass={'install': CustomInstall},
)
