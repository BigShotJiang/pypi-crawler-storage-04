# Copyright (c) 2025 Marcin Zdun
# This code is licensed under MIT license (see LICENSE for details)

"""
The **proj_flow.ext.cplusplus.cmake.__version__** contains only the value of
expected version of CMake.
"""


CMAKE_VERSION = "3.28"
