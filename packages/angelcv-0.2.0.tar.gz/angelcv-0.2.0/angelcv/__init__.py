from angelcv.interface.object_detection import ObjectDetectionModel

__all__ = ["ObjectDetectionModel"]
