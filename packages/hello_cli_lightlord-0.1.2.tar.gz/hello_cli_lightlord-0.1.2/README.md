# hello-cli-pkg

```bash
pip install .
hello-cli --help
hello-cli --name Alice --caps