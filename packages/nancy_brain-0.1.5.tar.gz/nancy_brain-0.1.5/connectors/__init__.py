"""Connectors package for Nancy RAG core."""
