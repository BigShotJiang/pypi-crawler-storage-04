"""Conventional Commits Generator - A CLI tool for standardized commit messages."""

__version__ = "2.2.4"
