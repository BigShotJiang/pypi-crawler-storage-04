from ..handlers.txt_file_store import TxtMethods


class LaTeXMethods(TxtMethods):
    pass
