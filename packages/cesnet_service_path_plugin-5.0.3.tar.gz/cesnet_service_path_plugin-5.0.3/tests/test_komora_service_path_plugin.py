#!/usr/bin/env python

"""Tests for `cesnet_service_path_plugin` package."""

from cesnet_service_path_plugin import cesnet_service_path_plugin
