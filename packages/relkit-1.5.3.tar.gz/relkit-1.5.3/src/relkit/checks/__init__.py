"""Check modules for relkit."""
