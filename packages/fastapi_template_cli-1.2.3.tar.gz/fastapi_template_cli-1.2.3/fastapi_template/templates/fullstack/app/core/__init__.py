"""Core application components."""
