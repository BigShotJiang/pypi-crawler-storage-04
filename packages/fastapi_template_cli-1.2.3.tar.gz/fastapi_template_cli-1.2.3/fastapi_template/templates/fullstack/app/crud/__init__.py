"""CRUD operations package."""
