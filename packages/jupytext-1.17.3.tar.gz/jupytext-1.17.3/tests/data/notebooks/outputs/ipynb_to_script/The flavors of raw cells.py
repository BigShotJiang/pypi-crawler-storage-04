# ---
# jupyter:
#   kernelspec:
#     display_name: Python 3
#     language: python
#     name: python3
# ---

# + raw_mimetype="text/latex" active=""
# $1+1$

# + raw_mimetype="text/restructuredtext" active=""
# :math:`1+1`

# + raw_mimetype="text/html" active=""
# <b>Bold text<b>

# + raw_mimetype="text/markdown" active=""
# **Bold text**

# + raw_mimetype="text/x-python" active=""
# 1 + 1

# + active=""
# Not formatted
