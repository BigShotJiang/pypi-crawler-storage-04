---
jupyter:
  kernelspec:
    display_name: Python 3
    language: python
    name: python3
  nbformat: 4
  nbformat_minor: 2
---

::: {.cell .markdown slideshow="{\"slide_type\":\"slide\"}"}
A markdown cell
:::

::: {#cell-1 .cell .code slideshow="{\"slide_type\":\"\"}"}
``` python
1+1
```
:::

::: {.cell .markdown cell_style="center" slideshow="{\"slide_type\":\"fragment\"}"}
Markdown cell two
:::
