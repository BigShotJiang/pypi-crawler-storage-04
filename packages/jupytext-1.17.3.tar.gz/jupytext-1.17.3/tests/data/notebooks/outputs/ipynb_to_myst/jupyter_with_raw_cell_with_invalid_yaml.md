---
kernelspec:
  display_name: Python 3 (ipykernel)
  language: python
  name: python3
---

```{raw-cell}

---
title: Exception: Test
---
```

```{code-cell} ipython3
1 + 2 + 3
```
