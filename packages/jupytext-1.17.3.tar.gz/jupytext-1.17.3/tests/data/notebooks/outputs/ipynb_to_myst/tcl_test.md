---
kernelspec:
  display_name: Tcl
  language: tcl
  name: tcljupyter
---

# Assign Values

```{code-cell}
set a 1
puts "a = $a"
```

# Loop

```{code-cell}
for {set i 0} {$i < 10} {incr i} {
    puts "I inside first loop: $i"
}
```

```{code-cell}

```
