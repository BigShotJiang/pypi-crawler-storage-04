---
kernelspec:
  display_name: ROOT C++
  language: c++
  name: root
---

```{code-cell}
#include <iostream>
#include <string>
```

```{code-cell}
int k = 4;
std::string foo = "This string says \"foo\"";
```

```{code-cell}
std::cout << "k = " << k << '\n' << foo << '\n';
```
