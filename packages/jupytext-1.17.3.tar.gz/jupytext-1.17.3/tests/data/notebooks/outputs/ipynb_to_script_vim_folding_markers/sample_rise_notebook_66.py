# ---
# jupyter:
#   jupytext:
#     cell_markers: '{{{,}}}'
#   kernelspec:
#     display_name: Python 3
#     language: python
#     name: python3
# ---

# {{{ [markdown] slideshow={"slide_type": "slide"}
# A markdown cell
# }}}

# {{{ slideshow={"slide_type": ""}
1+1
# }}}

# {{{ [markdown] cell_style="center" slideshow={"slide_type": "fragment"}
# Markdown cell two
# }}}
