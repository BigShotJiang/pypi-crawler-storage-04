"""
Application of the Random Immigrants Concept in chromosomes
"""
