"""
Crossover functionality
"""
