"""
Functionality to execute cost function and find costs.
"""
