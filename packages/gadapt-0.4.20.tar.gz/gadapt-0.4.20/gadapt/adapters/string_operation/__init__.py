"""
String functions based on the GA model. Transformation of GA objects to strings.
"""
