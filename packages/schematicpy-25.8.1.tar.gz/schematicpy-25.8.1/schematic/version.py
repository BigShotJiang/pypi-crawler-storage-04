"""Sets the version of the package"""
# Version hardcoded see https://sagebionetworks.jira.com/browse/SCHEMATIC-229
__version__ = "25.8.1"
