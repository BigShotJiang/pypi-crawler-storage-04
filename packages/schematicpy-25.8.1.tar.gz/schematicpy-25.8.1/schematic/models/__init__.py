from schematic.models.metadata import MetadataModel
