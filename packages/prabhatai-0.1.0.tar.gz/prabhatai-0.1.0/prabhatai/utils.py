# Utility functions for PrabhatAI
