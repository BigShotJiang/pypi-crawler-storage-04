__author__ = ["Li Chen"]
__copyright__ = "ETH Zurich"
__license__ = "MIT License"
__email__ = "li.chen@arch.ethz.ch"
__version__ = "0.4.0"
