from .parallel import parallel_map  # noqa: F401
