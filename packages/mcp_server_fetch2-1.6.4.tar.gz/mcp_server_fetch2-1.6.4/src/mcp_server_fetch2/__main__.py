# __main__.py

from mcp_server_fetch2 import main

main()
