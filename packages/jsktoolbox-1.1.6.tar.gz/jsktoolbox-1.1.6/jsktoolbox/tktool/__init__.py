# -*- coding: UTF-8 -*-
"""
  __init__.py
  Author : Jacek 'Szumak' Kotlarski --<szumak@virthost.pl>
  Created: 15.01.2024, 10:41:26
"""
