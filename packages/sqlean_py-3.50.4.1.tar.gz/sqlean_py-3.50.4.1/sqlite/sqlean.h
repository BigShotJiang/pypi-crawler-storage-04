// Copyright (c) 2023 Anton Zhiyanov, MIT License
// https://github.com/nalgeon/sqlean

#ifndef SQLEAN_H
#define SQLEAN_H

#ifndef SQLEAN_VERSION
#define SQLEAN_VERSION "main"
#endif

#endif /* SQLEAN_H */
