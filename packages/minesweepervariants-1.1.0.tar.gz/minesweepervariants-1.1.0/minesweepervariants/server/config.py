
github_web = "https://minesweepervariants-fanmade.github.io/MinesweeperVariants-Vue/"

CORS_resources = {r"/*": {"origins": "*"}}

HOT_RELOAD = True

MULTIPLAYER = True

QUEUE_SIZE = 1