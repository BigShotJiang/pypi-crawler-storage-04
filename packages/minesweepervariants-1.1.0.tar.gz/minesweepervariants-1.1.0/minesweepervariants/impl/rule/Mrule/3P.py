#!/usr/bin/env python3
# -*- coding:utf-8 -*-
#
# @Time    : 2025/07/07 20:43
# @Author  : Wu_RH
# @FileName: 3S.py
