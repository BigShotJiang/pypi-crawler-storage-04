default_app_config = "pulp_webhook.app.PulpWebhookPluginAppConfig"
