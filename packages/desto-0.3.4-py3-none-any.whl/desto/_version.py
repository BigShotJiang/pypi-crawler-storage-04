"""Version information for desto package."""

__version__ = "0.3.4"
