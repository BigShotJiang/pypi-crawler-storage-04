from mcp_server_time_allenash_pypi_test import main

main()
