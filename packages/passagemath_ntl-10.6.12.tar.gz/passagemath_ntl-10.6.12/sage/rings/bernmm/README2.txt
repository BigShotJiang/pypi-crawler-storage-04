This directory contains the bernmm library, by David Harvey.

bernmm is maintained as a separate project, see my website dharvey.net.

If you make any changes/improvements, please tell me about it!
I might want to merge those changes into the upstream version.
