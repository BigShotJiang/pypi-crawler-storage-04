"""Schemas representing the Common Smart Inverter Profile for Australia"""
