"""Schemas representing IEEE 2030.5 (smart energy profile 2)"""
