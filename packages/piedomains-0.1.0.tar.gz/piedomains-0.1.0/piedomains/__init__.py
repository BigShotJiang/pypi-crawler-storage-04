from .domain import pred_shalla_cat
from .domain import pred_shalla_cat_with_images
from .domain import pred_shalla_cat_with_text

__all__ = ["pred_shalla_cat", "pred_shalla_cat_with_text", "pred_shalla_cat_with_images"]
