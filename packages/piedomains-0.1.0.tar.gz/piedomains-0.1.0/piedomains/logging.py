import logging


"""
Logging
"""


def get_logger():
    logger = logging.getLogger("piedomains")
    return logger
