# 🧠 API Reference

## CLI

::: azure_functions_doctor.cli

## Doctor

::: azure_functions_doctor.doctor

## Handlers

::: azure_functions_doctor.handlers

## Configuration

::: azure_functions_doctor.config

## Target Resolver

::: azure_functions_doctor.target_resolver

## Utility

::: azure_functions_doctor.utils
