from . import test_sale_terms_template, test_sale_order
