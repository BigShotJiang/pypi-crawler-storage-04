- add a post_init_hook and / or a uninstall_hook to handle correctly the
  conversion (Text \<--\> Html).
- support qweb report templating engine
