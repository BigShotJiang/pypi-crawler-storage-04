from paddleOCRONNX.predict.predict_system import PredictSystem
from paddleOCRONNX.models_enum import *
from paddleOCRONNX.predict.predict_cls import TextLineOrientationDetector
from paddleOCRONNX.predict.predict_det import TextDetector
from paddleOCRONNX.predict.predict_rec import OCRRecognizer
from paddleOCRONNX.predict.predict_doc_cls import DocumentOrientationDetector
from paddleOCRONNX.predict.predict_uvdoc import DocumentRectifier

__author__ = 'wyy-holding'
__version__ = '0.0.1'
__all__ = [
    "TextLineOrientationDetector",
    "TextDetector",
    "OCRRecognizer",
    "DocumentOrientationDetector",
    "DocumentRectifier",
    "TextLineModels",
    "DetModels",
    "RecModels",
    "TableModels",
    "ImageModels"
]
