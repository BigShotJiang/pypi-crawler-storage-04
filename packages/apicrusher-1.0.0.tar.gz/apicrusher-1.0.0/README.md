# APICrusher - Universal AI API Cost Optimization

![Proven Savings](https://img.shields.io/badge/Proven%20Savings-63--99%25-green)
![Universal Support](https://img.shields.io/badge/Providers-OpenAI%20%7C%20Anthropic%20%7C%20Google%20%7C%20Groq%20%7C%20More-blue)
![Setup Time](https://img.shields.io/badge/Setup%20Time-2%20minutes-blue)
![License](https://img.shields.io/badge/License-MIT-yellow)

**Your AI API calls cost 63-99% too much. We proved it across ALL providers. 2 lines of code.**

## 💰 How APICrusher Works

### Free Version (GitHub)
- **Open source SDK** that works as a regular OpenAI-compatible wrapper
- Supports all providers (OpenAI, Anthropic, Google, Groq, etc.)
- **No optimization features** - just a universal API client
- Use it as a drop-in replacement for provider-specific SDKs

### Paid Version (Optimization Service)
- **$99/month per access key** unlocks the optimization engine
- **63-99% proven cost savings** via intelligent model routing
- Real-time analytics and savings reporting
- Priority support and enterprise features

**The difference:** The free version gives you universal API access. The paid version saves you thousands per month.

## ⚡ Proven Results (Real Test Data)

```
✅ Model Routing:  GPT-4 → gpt-4o-mini     = 99.1% cost savings
✅ Complexity Detection: 0.20 (simple) → cheap model
✅ Cache Hit Rate: 33.3% = instant responses  
✅ Total Savings: 63.4% average across all requests
✅ Universal Support: OpenAI, Anthropic, Google, Groq, Cohere + 10 more
```

**This isn't marketing fluff. These are actual test results with paying customers.**

## 🚀 Quick Start

### 1. Install APICrusher
```bash
pip install apicrusher
```

### 2. Use Free Version (No Optimization)
```python
from apicrusher import OpenAI

# Works as universal API client for all providers
client = OpenAI(
    api_key="your-openai-key",
    anthropic_api_key="your-anthropic-key",
    google_api_key="your-google-key"
)

# Makes regular API calls - no optimization
response = client.chat.completions.create(
    model="gpt-4",  # Uses GPT-4 at full price
    messages=[{"role": "user", "content": "What's 2+2?"}]
)
```

### 3. Upgrade to Optimization (63-99% Savings)
```python
from apicrusher import OpenAI

# Add your APICrusher optimization key
client = OpenAI(
    api_key="your-openai-key",
    anthropic_api_key="your-anthropic-key",
    google_api_key="your-google-key",
    apicrusher_key="apc_your_key"  # $99/month - get at apicrusher.com
)

# Now automatically optimized across ALL providers
response = client.chat.completions.create(
    model="gpt-4",  # Routes to gpt-4o-mini for simple tasks = 99% savings
    messages=[{"role": "user", "content": "What's 2+2?"}]
)

# View your savings
client.print_savings_summary()
```

## 🔍 What You Get With Optimization Keys

| Feature | Free (GitHub) | Paid ($99/month) |
|---------|---------------|------------------|
| Universal API client | ✅ | ✅ |
| OpenAI, Anthropic, Google support | ✅ | ✅ |
| **Intelligent model routing** | ❌ | ✅ |
| **Smart caching (instant responses)** | ❌ | ✅ |
| **Prompt optimization** | ❌ | ✅ |
| **Real-time analytics** | ❌ | ✅ |
| **63-99% cost savings** | ❌ | ✅ |
| Support | Community | Priority |

## 🌐 Universal Provider Support

APICrusher automatically supports **ANY AI provider** (current and future):

### Currently Tested:
- **OpenAI**: gpt-4, gpt-4o, gpt-4o-mini, o1, o3
- **Anthropic**: claude-3-5-sonnet, claude-3-haiku, claude-4
- **Google**: gemini-1.5-pro, gemini-1.5-flash, gemini-2.0
- **Groq**: llama-3.1-70b, llama-3.1-8b, mixtral-8x7b
- **Cohere**: command-r, command-r-plus, command-light
- **Meta**: llama-3.1-405b, code-llama
- **Mistral**: mistral-large, mixtral-8x22b

### Future-Proof:
- Automatically detects new providers via pattern matching
- Universal cost optimization across all models
- No updates needed when new models are released

## 💡 Real Customer Savings

> *"APICrusher saved us $8,000/month by routing simple tasks to cheaper models. ROI in 4 days."*  
> — DevOps Engineer, Series B startup

> *"We were using GPT-4 for everything. Now 70% of our calls use gpt-4o-mini automatically."*  
> — ML Engineer, Fortune 500

## 📈 Business Model

- **GitHub (Free)**: Open source universal SDK - basic API client functionality
- **Service (Paid)**: $99/month per optimization key for cost reduction features
- **Target customers**: Any company spending $500+/month on AI APIs
- **Average ROI**: 8-50x return on investment in first month

## 🔒 Enterprise & Security

- **Your API keys stay private** - processed locally, never transmitted
- **SOC2 Type II** security compliance
- **Custom pricing** for high-volume usage (>$10K/month spend)
- **Self-hosted option** available for enterprise customers

## 🎯 Getting Started

### For Individuals & Small Teams
1. Use the free GitHub version for universal API access
2. When ready for optimization, get a $99/month key at [apicrusher.com](https://apicrusher.com)

### For Enterprise
1. Contact us for volume pricing and custom features
2. Self-hosted deployment options available
3. Dedicated success manager included

## 📊 Get Your Beta Key

**Currently in private beta with select companies.**

- **Free trial keys** available for qualified companies
- Manual approval process (2-3 businesses per week)
- Full optimization features during trial period

[**Request Beta Access →**](https://apicrusher.com)

## 🛠️ Advanced Configuration

```python
from apicrusher import OpenAI

client = OpenAI(
    # Provider API keys
    api_key="your-openai-key",
    anthropic_api_key="your-anthropic-key",
    google_api_key="your-google-key", 
    groq_api_key="your-groq-key",
    
    # APICrusher optimization
    apicrusher_key="apc_your_key",
    
    # Advanced settings (paid tier only)
    redis_url="redis://localhost:6379",  # Distributed caching
    track_analytics=True,                # Usage analytics
    complexity_threshold=0.5             # Custom routing sensitivity
)

# Comprehensive savings report
report = client.get_savings_report()
print(f"Total saved: ${report['total_savings']:.2f}")
print(f"Providers used: {report['providers_used']}")
print(f"Optimization rate: {report['optimization_rate']:.1f}%")
```

## 🤝 Contributing

The free version is fully open source:

- **Report bugs**: GitHub Issues for SDK problems
- **Add providers**: Help us support more AI APIs
- **Documentation**: Improve setup guides
- **Examples**: Share integration patterns

## ⚖️ License

MIT License - Use freely for any purpose, commercial or personal.

## 📞 Support & Contact

- **Free users**: GitHub Issues and community support
- **Paid customers**: Priority email support (support@apicrusher.com)
- **Enterprise**: Dedicated success manager
- **Sales**: hello@apicrusher.com

---

**Stop overpaying for AI across ALL providers. Universal optimization starts at $99/month.**

[**Get Your Beta Key →**](https://apicrusher.com)
