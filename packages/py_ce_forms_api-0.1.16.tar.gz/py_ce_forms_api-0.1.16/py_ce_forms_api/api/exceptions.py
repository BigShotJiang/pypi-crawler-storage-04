class APIError(Exception):
    """Handle API error requests"""
    pass
