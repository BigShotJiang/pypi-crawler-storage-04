# 首先导入 setuptools 中的 setup 函数
from setuptools import setup
setup(
    name='wecommsg',  # 库的名称（必填）
    # 这是别人安装时用的名字，比如 pip install wecom
    # 注意：PyPI 上的库名是唯一的，如果若已被占用需要换一个

    version='1.0.0',  # 版本号（必填）
    # 遵循语义化版本规范：主版本.次版本.修订号（如 1.0.0 → 1.0.1 → 1.1.0）
    # 每次更新库时必须修改版本号，否则无法再次上传到 PyPI

    author='DongYang',  # 作者名称（可选）
    # 会显示在 PyPI 库的页面上，方便用户了解开发者

    author_email='649898871@qq.com',  # 作者邮箱（可选）
    # 用于用户遇到问题时联系你

    description='发送企业微信消息的程序',  # 库的简短描述（可选）
    # 会显示在 PyPI 搜索结果和库首页的简介处，建议简洁明了
    # 例如："企业微信机器人消息发送工具"

    packages=['wecommsg'],  # 要打包的 Python 包列表（必填）
    # 这里需要填写你的实际包文件夹名称（即包含 __init__.py 的文件夹）
    # 比如你的代码放在 "wecom_sdk" 文件夹下，就改成 packages=['wecom_sdk']
    # 若有多个包，用逗号分隔：packages=['pkg1', 'pkg2']

    install_requires=[  # 库的依赖列表（可选）
        'requests>=2.25.0'

    ],
    # 当别人安装你的库时，会自动安装这些依赖
    # 例如你的库用到了 requests，就写成 install_requires=['requests>=2.25.0']
    # 版本号可加限制（>= 最低版本，== 固定版本）
)