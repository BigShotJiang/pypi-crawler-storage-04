# wecommsg 库
这是一个用于 [说明你的库功能，比如“企业微信相关操作”] 的 Python 库。

## 安装方式
```bash
# 本地安装（从 dist 文件夹安装）
pip install dist/wecommsg-1.0.0-py3-none-any.whl