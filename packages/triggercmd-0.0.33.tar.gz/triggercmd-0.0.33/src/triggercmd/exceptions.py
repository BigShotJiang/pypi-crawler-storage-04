"""Exceptions for TRIGGERcmd."""

class TRIGGERcmdConnectionError(Exception):
    """Connection error exception."""