Converting and upgrading
========================

.. toctree::
   :maxdepth: 1

   haiku_migration_guide
   convert_pytorch_to_flax
   orbax_upgrade_guide
   optax_update_guide
   linen_upgrade_guide
   rnncell_upgrade_guide
   regular_dict_upgrade_guide