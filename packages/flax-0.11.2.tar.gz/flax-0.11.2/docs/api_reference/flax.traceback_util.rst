flax.traceback_util package
============================

.. currentmodule:: flax.traceback_util

.. automodule:: flax.traceback_util


Traceback filtering utils
--------------------------

.. autofunction:: hide_flax_in_tracebacks

.. autofunction:: show_flax_in_tracebacks
