
flax.struct package
=====================

.. currentmodule:: flax.struct

.. automodule:: flax.struct


.. autofunction:: dataclass


.. autoclass:: PyTreeNode