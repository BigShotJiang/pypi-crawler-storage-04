API Reference
=============

.. toctree::
   :maxdepth: 4

   flax.config
   flax.core.frozen_dict
   flax.cursor
   flax.errors
   flax.jax_utils
   flax.linen/index
   flax.serialization
   flax.struct
   flax.traceback_util
   flax.training
   flax.traverse_util