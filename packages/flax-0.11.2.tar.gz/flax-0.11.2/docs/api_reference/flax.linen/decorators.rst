Decorators
----------------------

.. currentmodule:: flax.linen

.. autofunction:: compact
.. autofunction:: nowrap
