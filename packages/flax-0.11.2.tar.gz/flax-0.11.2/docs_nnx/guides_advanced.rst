Advanced Guides
======

.. toctree::
   :maxdepth: 1
   :caption: Advanced

   guides/flax_gspmd
   guides/performance
   guides/bridge_guide
   guides/surgery
