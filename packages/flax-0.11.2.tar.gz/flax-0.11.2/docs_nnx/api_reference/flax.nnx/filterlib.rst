filterlib
------------------------

.. automodule:: flax.nnx
.. currentmodule:: flax.nnx


.. autofunction:: flax.nnx.filterlib.to_predicate
.. autoclass:: WithTag
.. autoclass:: PathContains
.. autoclass:: OfType
.. autoclass:: Any
.. autoclass:: All
.. autoclass:: Not
.. autoclass:: Everything
.. autoclass:: Nothing