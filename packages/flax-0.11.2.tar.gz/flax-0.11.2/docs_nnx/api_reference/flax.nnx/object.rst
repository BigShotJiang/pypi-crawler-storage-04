object
------------------------

.. automodule:: flax.nnx
.. currentmodule:: flax.nnx

.. autoclass:: Object
   :members:
.. autofunction:: data
.. autodata:: Data
   :annotation:
.. autofunction:: is_data_type
.. autofunction:: register_data_type