LoRA
------------------------

NNX LoRA classes.

.. automodule:: flax.nnx
.. currentmodule:: flax.nnx

.. flax_module::
  :module: flax.nnx
  :class: LoRA

.. flax_module::
  :module: flax.nnx
  :class: LoRALinear
