summary
------------------------

.. automodule:: flax.nnx
.. currentmodule:: flax.nnx

.. autofunction:: tabulate