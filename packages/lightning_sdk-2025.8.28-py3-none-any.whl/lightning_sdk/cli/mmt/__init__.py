"""MMT CLI commands."""

import click


def register_commands(group: click.Group) -> None:
    """Register MMT commands with the given group."""
