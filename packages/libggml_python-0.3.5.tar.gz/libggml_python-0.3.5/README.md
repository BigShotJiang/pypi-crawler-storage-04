# libggml-python

Python package containing prebuilt [ggml](https://github.com/ggml-org/ggml) libraries.

To build additional backends, see the [llama.cpp documentation](https://github.com/ggml-org/llama.cpp/blob/master/docs/build.md)
