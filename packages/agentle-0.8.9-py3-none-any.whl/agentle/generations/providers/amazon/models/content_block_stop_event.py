from typing import TypedDict


class ContentBlockStopEvent(TypedDict):
    contentBlockIndex: int
