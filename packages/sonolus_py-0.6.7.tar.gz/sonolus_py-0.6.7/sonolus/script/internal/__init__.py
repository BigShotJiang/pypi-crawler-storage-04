"""Internal scripting details.

These are internal details of scripting which typically should not be used directly
in engine code.
"""
