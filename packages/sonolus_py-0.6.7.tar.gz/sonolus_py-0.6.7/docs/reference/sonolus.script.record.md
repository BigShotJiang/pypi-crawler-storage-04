# sonolus.script.record
For usage details, see the corresponding [concepts page](../concepts/types.md#record).

::: sonolus.script.record
    options:
        members: []

::: sonolus.script.record.Record
    options:
        show_root_heading: true
        show_root_full_path: false
        members:
        - type_var_value
