# sonolus.script.easing

For more information on easing functions, see [easings.net](https://easings.net/).

::: sonolus.script.easing
