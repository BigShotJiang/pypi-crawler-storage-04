Script compiler binaries imported from neverwinter.nim release 2.1.1:

https://github.com/niv/neverwinter.nim/releases/tag/2.1.1
