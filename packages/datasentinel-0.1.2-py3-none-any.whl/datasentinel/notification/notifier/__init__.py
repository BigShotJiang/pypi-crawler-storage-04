"""`datasentinel.notification.notifier` provides functionality for sending notifications."""
