"""Data Sentinel is a framework for data quality validation and monitoring."""

__version__ = "0.1.2"
