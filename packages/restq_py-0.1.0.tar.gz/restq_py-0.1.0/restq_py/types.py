from typing import Literal


QueueAddMode = Literal["json", "pickle"]
