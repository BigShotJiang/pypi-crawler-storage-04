class RestQException(Exception):
    """ Base exception for RestQ """