"""
LigtTools - Tools for converting data between different formats and RDF specification.
"""

__version__ = "0.1.0"