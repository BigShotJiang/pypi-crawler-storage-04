try:
    from libbs.decompilers.angr import *
except ImportError:
    print("[!] libbs is not installed, please `pip install libbs` for THIS python interpreter")
