"""
Genetic Algorithm Utility
"""
