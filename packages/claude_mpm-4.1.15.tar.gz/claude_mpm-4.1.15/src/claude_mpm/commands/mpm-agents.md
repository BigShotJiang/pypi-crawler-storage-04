# Show available agents and their versions

Show all available Claude MPM agents with their versions and deployment status.

This command displays:
- Agent names and descriptions
- Version information
- Tool availability
- Model preferences
- Deployment status

Usage: /mpm-agents