/// A list of recommended combinations of 🐾
#[cfg(feature = "emoji-paw-prints")]
pub static RECOMMEND_EMOJI_CODEPOINTS_COMBINE_WITH_PAW_PRINTS: &[&str] = &[
    "2601-fe0f",  // ☁️
    "1f495",      // ❤️
    "2b50",       // ⭐
    "1f30a",      // 🌊
    "1f31f",      // 🌟
    "1f4ae",      // 🌸
    "1f381",      // 🎁
    "1f386",      // 🎆
    "1f38a",      // 🎊
    "1f3b0",      // 🎰
    "1f44d",      // 👍
    "1f495",      // 💕
    "1f493",      // 💓
    "1f498",      // 💘
    "1f4a1",      // 💡
    "1f4a5",      // 💥
    "1f4df",      // 📟
    "1f4f0",      // 📰
    "1f525",      // 🔥
    "1f52e",      // 🔮
    "1f5ef-fe0f", // 🗯️
    "1f6f8",      // 🛸
    "1f947",      // 🥇
    "1f9ca",      // 🧊
    "1faa4",      // 🪤
    "1f48c",      // 💌
    "1fa82",      // 🪂
    "1f32a-fe0f", // 🌪️
    "1f30b",      // 🌋
    "1f304",      // 🌄
    "1f34c",      // 🍌
    "1f3a3",      // 🎣
    "1f3b3",      // 🎳
    "1f9e9",      // 🧩
    "1f58d-fe0f", // 🖍️
    "1f3ac",      // 🎬
    "1f4e0",      // 📠
    "1f4be",      // 💾
    "2757",       // ❗
    "1f4ac",      // 💬
    "1f4af",      // 💯
    "1f49e",      // 💞
    "1f382",      // 🎂
    "26f3",       // ⛳
    "1f3af",      // 🎯
    "1f0cf",      // 🃏
    "1f39e-fe0f", // 🎞️
    "1f4bb",      // 💻
    "1f48e",      // 💎
    "1f5d1-fe0f", // 🗑️
    "231a",       // ⌚
    "1f514",      // 🔔
    "1f3b6",      // 🎶
    "1f92f",      // 🤯
    "1fae3",      // 🫣
    "1f973",      // 🥳
    "1f929",      // 🤩
    "267b-fe0f",  // ♻️
    "1f4e6",      // 📦
    "1f587-fe0f", // 🖇 ️
    "1f9ec",      // 🧬
    "1f3a8",      // 🎨
    "1f3c6",      // 🏆
    "1f329-fe0f", // 🌩️
    "1f496",      // 💖
    "1f49d",      // 💝
    "1f94a",      // 🥊
    "1f352",      // 🍒
];

/// A list of recommended combinations of 🐱
#[cfg(feature = "emoji-cat")]
pub static RECOMMEND_EMOJI_CODEPOINTS_COMBINE_WITH_CAT: &[&str] = &[
    "1f4df", // 📟
];
