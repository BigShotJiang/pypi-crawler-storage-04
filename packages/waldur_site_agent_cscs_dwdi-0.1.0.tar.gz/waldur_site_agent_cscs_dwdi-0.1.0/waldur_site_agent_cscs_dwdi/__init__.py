"""CSCS-DWDI reporting plugin for Waldur Site Agent."""
