"""Examples for MorphCards package."""
