"""
Utility functions for UnrealOn Driver.
"""

from .time import utc_now

__all__ = [
    "utc_now",
]
