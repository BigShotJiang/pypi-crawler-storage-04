from dataprep_ml.base import StatisticalAnalysis, DataAnalysis

__version__ = '0.0.25'
__name__ = "dataprep_ml"


__all__ = ['__version__', '__name__', 'StatisticalAnalysis', 'DataAnalysis']
