Requirements and Installation
=============================

.. include:: ../README.rst
   :start-after: .. START-INSTALLATION
   :end-before: .. END-INSTALLATION

.. include:: ../README.rst
   :start-after: .. START-COMPATIBILITY
   :end-before: .. END-COMPATIBILITY
