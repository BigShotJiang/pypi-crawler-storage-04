.. include:: ../CONTRIBUTING.rst

.. include:: ../README.rst
    :start-after: .. START-CONTRIBUTING
    :end-before: .. END-CONTRIBUTING
