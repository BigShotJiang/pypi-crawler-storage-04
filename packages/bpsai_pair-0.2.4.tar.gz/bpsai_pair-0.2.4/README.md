# bpsai-pair CLI

The PairCoder CLI tool for AI pair programming workflows.

## Quick Start

### Install from PyPI
```bash
pip install bpsai-pair
bpsai-pair --help
```

### Development Install
```bash
cd tools/cli
pip install -e .
bpsai-pair --help
```
## Windows & Cross-Platform

PairCoder CLI is fully Python-backed (no Bash required). On Windows use:

```powershell
# Create venv
python -m venv .venv

# If activation is blocked...
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass

# Activate venv
.\.venv\Scripts\Activate.ps1
# (Or use .venv\Scripts\activate.bat in CMD)

# Install package
pip install bpsai-pair
# or: pip install .\dist\bpsai_pair-*.whl

# Use the CLI
bpsai-pair --help
bpsai-pair-init
bpsai-pair feature demo --type refactor --primary "Goal" --phase "Phase 1"
bpsai-pair pack --out agent_pack.tgz
bpsai-pair context-sync --last "A" --next "B" --blockers ""
```
If the entry point is not on PATH, use:

```powershell
python -m bpsai_pair.cli --help
```

## Usage

### Initialize scaffolding (uses bundled template)
```bash
bpsai-pair-init
# or with main CLI:
bpsai-pair init
```

### Create feature branch
```bash
bpsai-pair feature auth-refactor \
  --type refactor \
  --primary "Decouple auth via DI" \
  --phase "Refactor auth module + tests"
```

### Pack context for AI
```bash
bpsai-pair pack --out agent_pack.tgz
bpsai-pair pack --list  # Preview files
bpsai-pair pack --json  # JSON output
```

### Update context loop
```bash
bpsai-pair context-sync \
  --last "Initialized scaffolding" \
  --next "Set up CI secrets" \
  --blockers "None"
```

## Commands

- `bpsai-pair init` - Initialize repo with PairCoder structure
- `bpsai-pair-init` - Quick init with bundled template (no args)
- `bpsai-pair feature` - Create feature/fix/refactor branch
- `bpsai-pair pack` - Package context for AI agents
- `bpsai-pair context-sync` - Update the Context Loop
- `bpsai-pair status` - Show current state
- `bpsai-pair validate` - Check repo structure
- `bpsai-pair ci` - Run local CI checks

## Development

Run tests:
```bash
pytest
```

Build wheel:
```bash
python -m build
```

## Template

The CLI bundles a cookiecutter template in `bpsai_pair/data/cookiecutter-paircoder/` 
that gets installed with the package and used by `bpsai-pair-init`.
