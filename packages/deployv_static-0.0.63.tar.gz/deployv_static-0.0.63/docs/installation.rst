============
Installation
============

At the command line::

    $ easy_install deployv-static

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv deployv-static
    $ pip install deployv-static
