===============================
DeployV static
===============================

.. image:: https://img.shields.io/travis/Vauxoo/deployv-static.svg
        :target: https://travis-ci.org/Vauxoo/deployv-static

.. image:: https://img.shields.io/pypi/v/deployv-static.svg
        :target: https://pypi.python.org/pypi/deployv-static


DeployV static files: Dockerfiles, json, configs, templates

* Free software: BSD license
* Documentation: https://deployv-static.readthedocs.org.

Features
--------

* TODO
