# -*- coding: utf-8 -*-
from .deployv_static import get_template_path  # noqa: F401

__author__ = 'Vauxoo'
__email__ = 'info@vauxoo.com'
__version__ = '0.0.63'
