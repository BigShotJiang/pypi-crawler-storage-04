# DeployV static files

DeployV static files: Dockerfiles, json, configs, templates