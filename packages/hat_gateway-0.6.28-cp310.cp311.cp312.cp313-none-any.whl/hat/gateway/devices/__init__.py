"""Gateway devices"""
