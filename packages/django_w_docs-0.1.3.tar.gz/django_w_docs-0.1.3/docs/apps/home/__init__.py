"""Home & Detail pages"""
