"""Tests for docs.home"""
