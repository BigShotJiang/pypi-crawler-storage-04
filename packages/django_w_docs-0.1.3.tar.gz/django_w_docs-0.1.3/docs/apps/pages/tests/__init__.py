"""Tests for docs.pages"""
