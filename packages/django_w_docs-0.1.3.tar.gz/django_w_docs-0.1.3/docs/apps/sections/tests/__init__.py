"""Tests for docs.sections"""
