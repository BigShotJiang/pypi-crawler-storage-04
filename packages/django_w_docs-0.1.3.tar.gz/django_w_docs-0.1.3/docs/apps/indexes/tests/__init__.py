"""Tests for docs.indexes"""
