"""Django Docs APIs"""
