from enum import StrEnum


class KeyFormat(StrEnum):
    BYTES = "bytes"
    STRING = "string"
