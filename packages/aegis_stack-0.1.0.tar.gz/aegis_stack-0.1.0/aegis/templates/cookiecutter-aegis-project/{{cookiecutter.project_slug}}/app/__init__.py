"""
{{ cookiecutter.project_name }} - Main application package.
"""

__version__ = "{{ cookiecutter.version }}"
