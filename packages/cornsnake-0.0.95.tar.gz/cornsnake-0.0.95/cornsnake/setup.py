"""
A setup configuration for a Python package using setuptools.
"""

from setuptools import setup

setup()
