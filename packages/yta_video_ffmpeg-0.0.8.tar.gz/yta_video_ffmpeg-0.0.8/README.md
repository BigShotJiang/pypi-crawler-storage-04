# Youtube Autonomous Video Ffmpeg Module

The way to handle ffmpeg in a simple way.