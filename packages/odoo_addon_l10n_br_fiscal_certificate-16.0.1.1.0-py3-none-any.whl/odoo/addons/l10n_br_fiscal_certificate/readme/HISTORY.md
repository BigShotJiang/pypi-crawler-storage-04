## 14.0.1.0.0 (2023)

Primeira versão do módulo: o código vinha sendo desenvolvido desde a
versão 8 mas estava integrado dentro módulo l10n_br_fiscal. O código foi
extraído para deixar o módulo l10n_br_fiscal mais leve.
