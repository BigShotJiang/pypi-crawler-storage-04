__doc__ = """Deprecated module. Use memory_blocks.utils instead."""
import numpy as np
import numpy.typing as npt

from .utils import (
    make_block_memory_metadata,
    make_block_memory_periodic_boundary_metadata,
)
