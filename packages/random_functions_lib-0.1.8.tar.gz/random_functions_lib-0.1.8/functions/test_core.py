import functions

name = "cove"
name1 =functions.encode(name,"singeli")
print(name1)
print(functions.decode(name1,"singeli"))
print(functions.invert_caps("HeLLo"))
print(functions.reverse("hello"))
print(functions.scramble("hello"))
print(functions.flip_a_coin())
print(functions.shout("hello"))
