from setuptools import setup,find_packages

setup(
    name='Jarvis_FRIDAY',
    version='0.1',
    author='continentalcircle48',
    author_email='example@gmail.com',
    description='This is Speech to text package created by continentalcircle48'
)

packages = find_packages()

install_requirements=[
    'selenium',
    'webdriver_manager'
]