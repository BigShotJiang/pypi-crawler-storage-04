from .schema import VkForgeModel

__all__ = ["VkForgeModel"]
