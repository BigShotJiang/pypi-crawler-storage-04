# -*- coding: utf-8 -*-
"""
Python-related web code.
"""
