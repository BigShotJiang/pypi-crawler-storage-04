# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl-3).

from . import l10n_es_partner_wizard
