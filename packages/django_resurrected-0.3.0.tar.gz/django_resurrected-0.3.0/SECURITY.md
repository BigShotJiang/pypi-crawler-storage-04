# Security Policy

## Reporting a Vulnerability

Please report security issues directly over email to contact@oak3.pl.
