"""Top-level package for Package Discovery."""

__author__ = """Yukihiko Shinoda"""
__email__ = "yuk.hik.future@gmail.com"
__version__ = "0.1.0"
