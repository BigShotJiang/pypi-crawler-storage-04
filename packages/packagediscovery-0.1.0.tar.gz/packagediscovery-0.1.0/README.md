# Package Discovery

[![Test](https://github.com/yukihiko-shinoda/package-discovery/workflows/Test/badge.svg)](https://github.com/yukihiko-shinoda/package-discovery/actions?query=workflow%3ATest)
[![CodeQL](https://github.com/yukihiko-shinoda/package-discovery/workflows/CodeQL/badge.svg)](https://github.com/yukihiko-shinoda/package-discovery/actions?query=workflow%3ACodeQL)
[![Code Coverage](https://qlty.sh/gh/yukihiko-shinoda/projects/package-discovery/coverage.svg)](https://qlty.sh/gh/yukihiko-shinoda/projects/package-discovery)
[![Maintainability](https://qlty.sh/gh/yukihiko-shinoda/projects/package-discovery/maintainability.svg)](https://qlty.sh/gh/yukihiko-shinoda/projects/package-discovery)
[![Dependabot](https://flat.badgen.net/github/dependabot/yukihiko-shinoda/package-discovery?icon=dependabot)](https://github.com/yukihiko-shinoda/package-discovery/security/dependabot)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/packagediscovery)](https://pypi.org/project/packagediscovery)
[![Twitter URL](https://img.shields.io/twitter/url?style=social&url=https%3A%2F%2Fgithub.com%2Fyukihiko-shinoda%2Fpackage-discovery)](http://twitter.com/share?text=Package%20Discovery&url=https://pypi.org/project/packagediscovery/&hashtags=python)

Package discovery based on Setuptools.

## Advantage

* TODO

## Quickstart

* TODO

<!-- markdownlint-disable no-trailing-punctuation -->
## How do I...
<!-- markdownlint-enable no-trailing-punctuation -->

* TODO

## Credits

This package was created with [Cookiecutter] and the [yukihiko-shinoda/cookiecutter-pypackage] project template.

[Cookiecutter]: https://github.com/audreyr/cookiecutter
[yukihiko-shinoda/cookiecutter-pypackage]: https://github.com/audreyr/cookiecutter-pypackage
