# Command line tool

::: mkdocs-click
    :module: cattle_grid.__main__
    :command: main
    :prog_name: python -m cattle_grid
    :depth: 2
