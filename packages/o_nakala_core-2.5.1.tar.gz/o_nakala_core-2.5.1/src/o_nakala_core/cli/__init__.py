"""
CLI interfaces for o-nakala-core package.
"""
