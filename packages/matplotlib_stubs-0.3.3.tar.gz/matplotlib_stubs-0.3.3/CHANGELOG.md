# Changelog

## 0.3.3 - 2025-09-04

- Complete `matplotlib.pyplot.text`'s type hints
- Fix `matplotlib.cm.colors`

## [0.3.2] - 2025-08-07

- Add `matplotlib.cm`'s colormaps

## [0.3.1] - 2025-08-04

- Add return type to `plt.ylabel` and `plt.xlabel`
- Fix/refine argument types for `plt.savefig`, `plt.plot` and `plt.scatter`

## [0.3.0] - 2025-08-02

Improve type hints for the following functions:

- `matplotlib.pyplot.close()`
- `matplotlib.pyplot.figure()`
- `matplotlib.pyplot.legend()`
- `matplotlib.pyplot.plot()`
- `matplotlib.pyplot.savefig()`
- `matplotlib.pyplot.scatter()`
- `matplotlib.pyplot.title()`
- `matplotlib.pyplot.xlabel()`
- `matplotlib.pyplot.ylabel()`

## 0.2.0 - 2023-07-19

- Strictly type Colormap.**call**.
