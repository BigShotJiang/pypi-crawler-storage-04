class HeaptreeAPIException(Exception):
    """Exception raised for errors in the API."""
    pass