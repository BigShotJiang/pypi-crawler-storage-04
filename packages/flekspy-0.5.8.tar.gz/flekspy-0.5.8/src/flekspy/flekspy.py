if __name__ == "__main__":
    print("Running from CLI...")
