# Contract Examples

This page demonstrates how to use the Contract module.

## Example Code

The following example shows how to work with data streams and contracts:

```python
--8<-- "examples/contract.py"
```