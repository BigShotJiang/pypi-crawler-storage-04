__all__ = ["OCRService", "OCRJob"]
__version__ = "0.1.0"

from .main import OCRService, OCRJob