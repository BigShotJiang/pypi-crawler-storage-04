"""MCP Claude Code - Implementation of Claude Code capabilities using MCP."""

__version__ = "0.5.1"
