"""Django REST Framework Redesign: Redesign of DRF browse-able API using Bootstrap 5"""
