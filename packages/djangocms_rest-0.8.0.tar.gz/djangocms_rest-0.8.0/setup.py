from setuptools import setup


# This call to setup() does all the work
setup()
