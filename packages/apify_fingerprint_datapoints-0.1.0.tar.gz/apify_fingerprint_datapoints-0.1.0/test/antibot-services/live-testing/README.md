# Live pages testing

This folder contains a categorized set of pages for testing various anti-bot services.

The `speed.js` test is designed to measure the performance of a simple crawler using different fingerprint-hiding methods.
