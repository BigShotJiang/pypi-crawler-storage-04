#!/usr/bin/env python3
"""Setup script for backward compatibility with older pip versions."""

from setuptools import setup

# All configuration is in pyproject.toml
# This file exists only for backward compatibility
setup()