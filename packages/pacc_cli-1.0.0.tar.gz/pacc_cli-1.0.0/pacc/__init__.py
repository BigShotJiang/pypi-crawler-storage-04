"""PACC - Package manager for Claude Code."""

__version__ = "1.0.0"
