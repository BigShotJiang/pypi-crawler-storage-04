"""
API Package

Module init for api package; optional import helper.
"""

# Optional convenience imports for API development
from .models.user import User

__all__ = ["User"]