from .orders import OrderTabularInline
from .order_proposals import OrderProposalAdmin
