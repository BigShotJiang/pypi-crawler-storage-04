from wbcore.metadata.configs.titles import TitleViewConfig


class ProductPerformanceFeesTitleConfig(TitleViewConfig):
    def get_list_title(self):
        return "Product Fees"
