from wbcore.metadata.configs.titles import TitleViewConfig


class AssetAndNetNewMoneyProgressionChartTitleConfig(TitleViewConfig):
    def get_list_title(self):
        return "AUM/NNM Progression"
