EQUITY_TYPE_KEYS = ["american_depository_receipt", "equity"]  # TODO might want to move this into a dynamic preference
