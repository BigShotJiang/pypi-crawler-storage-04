"""GitLab packages initialization module"""

from gitlab.packages import Packages

__version__ = "1.3.0"
