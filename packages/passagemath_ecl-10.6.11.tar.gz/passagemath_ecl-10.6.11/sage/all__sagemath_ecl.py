# sage_setup: distribution = sagemath-ecl
# delvewheel: patch

from sage.all__sagemath_categories import *
