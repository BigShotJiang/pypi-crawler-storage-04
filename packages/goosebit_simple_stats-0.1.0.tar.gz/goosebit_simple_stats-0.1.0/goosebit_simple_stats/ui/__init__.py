from .routes import router  # noqa: F401
from .static import static  # noqa: F401
from .templates import templates  # noqa: F401
