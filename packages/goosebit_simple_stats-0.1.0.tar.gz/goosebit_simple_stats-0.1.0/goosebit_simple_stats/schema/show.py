from enum import StrEnum


class SimpleStatsShow(StrEnum):
    DEVICE_COUNT = "device_count"
    SOFTWARE_COUNT = "software_count"
