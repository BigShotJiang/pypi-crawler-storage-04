from .const import PWD_CXT  # noqa: F401
from .schema import SimpleStatsSettings

config = SimpleStatsSettings()
