"""Test fixtures for `gfwapiclient`."""
