"""Tests for `gfwapiclient.client`."""
