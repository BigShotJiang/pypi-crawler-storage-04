"""Tests for `gfwapiclient`."""
