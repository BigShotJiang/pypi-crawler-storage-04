"""Tests for `gfwapiclient.http`."""
