"""Unit tests for Apache Beam transforms.

This package contains test modules that validate the behavior and configuration
of reusable PTransforms defined in `pipe_nmea.common.beam.transforms`.
"""
