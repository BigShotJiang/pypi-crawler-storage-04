"""Holds the current version of the program."""

import importlib.metadata


__version__ = importlib.metadata.version("gfw-common")
