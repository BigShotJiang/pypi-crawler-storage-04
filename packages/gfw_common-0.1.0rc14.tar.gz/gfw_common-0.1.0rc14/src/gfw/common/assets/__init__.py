"""Package for non-code assets."""
