The development of this module has been financially supported by:

- Associacion Española de Odoo ([AEODOO](https://www.aeodoo.org/))

The tones provided by default comes from Pixabay:

- Ringback tone: Sound Effect by freesound_community from Pixabay
- Call tone: Sound Effect by Jeremay Jimenez from Pixabay
- Dial tone: Sound Effect by freesound_community from Pixabay
