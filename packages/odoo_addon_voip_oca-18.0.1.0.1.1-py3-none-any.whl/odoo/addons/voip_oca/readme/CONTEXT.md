This module is intended to integrate directly with a VOIP Provider.

The provider need to supply a WebRTC system where we will plug on it.

Currently, it has been tested with:

- [Zerovoz](https://zerovoz.com/)
- [Ringover](https://www.ringover.es/)

Theoretically, it should work with

- Axivox
- OnSIP