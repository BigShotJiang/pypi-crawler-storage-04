class DeepApplyException(Exception):
    pass
