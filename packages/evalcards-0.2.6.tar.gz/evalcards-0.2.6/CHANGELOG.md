# Changelog

## [0.2.0] - 2025-08-30
- Multiclase OvR: curvas ROC/PR por clase y `roc_auc_ovr_macro`.
- Forecasting: sMAPE (%) y MASE + gráficos (fit, residuales).
- Backend matplotlib forzado a Agg (tests/servidores sin GUI).
- README reorganizado.

## [0.1.0] - 2025-08-30
- Primera publicación: clasificación binaria, regresión, CLI y reportes Markdown.

## [0.2.1] - 2025-08-30
- Release de prueba del flujo CI/CD (publicación por tag).