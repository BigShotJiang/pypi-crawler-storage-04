# VideoSDK Groq Plugin

Agent Framework plugin for TTS services from Groq.

## Installation

```bash
pip install videosdk-plugins-groq
```