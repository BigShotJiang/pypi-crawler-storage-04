#!/bin/bash
cd "$(dirname "$0")"
uv run python -m data_go_mcp.nts_business_verification.server