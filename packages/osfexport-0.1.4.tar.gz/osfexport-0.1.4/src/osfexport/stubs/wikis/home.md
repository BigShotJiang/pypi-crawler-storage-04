hello world!

# h1
## h2
### h3
#### h4
##### h5
###### h6

**bold**
*italics*
***bold italics***
~~strikethrough~~


----------
#### hr rules
----------


> here's a quote

> fancy

    here's some code
    another line of code;

[link to project board][1]

 1. List item
 2. item
 3. item
 


item

 - List item
 - more
 - more

  [1]: https://github.com/orgs/CenterForOpenScience/projects/10
  
  