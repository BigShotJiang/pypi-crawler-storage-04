
def run():
    """Run the MCP server."""
    print("MCP Server redis-mcp-server running...")
    return 0

if __name__ == "__main__":
    run()
