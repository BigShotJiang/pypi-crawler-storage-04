"""
AtlasRun source utilities module
"""
