﻿sf\_quant.backtester.backtest\_parallel
=======================================

.. currentmodule:: sf_quant.backtester

.. autofunction:: backtest_parallel