# JIVAS

`jivas` is an Agentic Framework for rapidly prototyping and deploying graph-based, AI solutions.
