"""Text utils package"""
