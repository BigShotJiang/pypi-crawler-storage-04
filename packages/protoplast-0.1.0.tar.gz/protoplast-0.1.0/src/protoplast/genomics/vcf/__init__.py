from ._vcf import read_vcf

__all__ = ["read_vcf"]
