"""
Logging functionality.
"""
