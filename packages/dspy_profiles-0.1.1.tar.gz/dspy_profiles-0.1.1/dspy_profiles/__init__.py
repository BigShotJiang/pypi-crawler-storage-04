"""dspy-profiles package."""

from .core import current_profile, profile, with_profile

__all__ = ["profile", "with_profile", "current_profile"]
