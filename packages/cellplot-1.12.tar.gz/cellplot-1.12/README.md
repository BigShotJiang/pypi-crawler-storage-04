# CellPlot: A Data Visualization Tool for Biological Imaging

This repository contains a suite of visualization tools designed for biological imaging data. 

To install the library, execute the following command:

```bash
pip install cellplot
```
