from fabrix.version import __version__

__all__: list[str] = [
    "__version__",
]
