"""Core package for Tresto."""
