from deepllm.prompters import *
from deepllm.recursors import run_explorer
from deepllm.refiners import SymPlanner


def test_symplanner():
    plan1 = [
        ("vote for a party", ["vote republican"]),
        ("vote for a party", ["vote democrat"]),
    ]

    plan2 = [
        ("buying an ev", ["ev is lower maintenence"]),
        ("buying an ev", ["ev is cheaper over time", "ev_is_fun_to_drive"]),
        ("buying an ev", ["ev is good for environment"]),
        ("ev lower maintenence", ["ev no oil change"]),
    ]

    nat_plan = """
  'buy an EV' : % decision on buying an EV
    'EVs are ecological', 
    'EVS are low_maintance', 
    'EVs cost less over time'.
  'buy an EV' :
     'EVs are fun to drive'.
  """

    run_explorer(explorer=SymPlanner, goal=nat_plan, prompter=verifier_prompter, lim=1)


def run_all():

    # run_explorer(prompter=falsifier_prompter, goal='add high tarifs on imports', lim=2)
    # run_explorer(prompter=verifier_prompter, goal='add high tarifs on imports', lim=2)
    # run_explorer(prompter=falsifier_prompter, goal='reaction of the stock market to high tarifs on imports', lim=2)
    # run_explorer(prompter=verifier_prompter, goal='reaction of the stock market to high tarifs on imports', lim=2)
    test_symplanner()
    return
    run_explorer(prompter=sci_prompter, goal="Logic programming", lim=3)
    run_explorer(prompter=sci_prompter, goal="Generative AI", lim=2)
    run_explorer(prompter=recommendation_prompter, goal="Apocalypse now", lim=2)
    run_explorer(
        prompter=recommendation_prompter, goal="1Q84, by Haruki Murakami", lim=2
    )
    run_explorer(prompter=causal_prompter, goal="Expansion of the Universe", lim=2)
    run_explorer(
        prompter=causal_prompter, goal="Use of tactical nukes in Ukraine war", lim=2
    )
    run_explorer(prompter=conseq_prompter, goal="Use of tactical nukes", lim=2)
    run_explorer(
        prompter=sci_prompter, goal="benchmark QA on document colections", lim=2
    )


def demo():
    run_explorer(prompter=task_planning_prompter, goal="Repair a flat tire", lim=1)
    run_explorer(prompter=sci_prompter, goal="Logic Programming", lim=1)
    run_explorer(
        prompter=sci_prompter, goal="Teaching computational thinking with Prolog", lim=2
    )


def test_recursors():
    # assert run_explorer(prompter=task_planning_prompter, goal='Repair a flat tire', lim=1)
    run_all()


if __name__ == "__main__":
    test_recursors()
