###cfastchat + Vicuna 7B

needs at least 26GB GPU for usable performance 

tested after launching server.sh
