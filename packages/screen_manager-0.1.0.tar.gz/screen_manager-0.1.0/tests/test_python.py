#!/usr/bin/env python3
print("Hello from Python script!")
import os
print(f"Current directory: {os.getcwd()}")
print(f"Python version: {os.sys.version}")
print("Python test completed!")