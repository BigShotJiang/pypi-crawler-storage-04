"""Version information for screen-manager."""

__version__ = "1.0.0"