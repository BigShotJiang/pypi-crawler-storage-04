"""I/O for SSSLM."""

from .skos import read_skos

__all__ = [
    "read_skos",
]
