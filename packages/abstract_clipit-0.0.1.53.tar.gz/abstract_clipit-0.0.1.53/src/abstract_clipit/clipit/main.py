from .clipitTab import clipitTab
