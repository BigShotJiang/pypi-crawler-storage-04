from ...imports import *

def initializeInit(self):
    self.fn_filter_mode = "io"   # "source" | "io" | "all"
    self.current_fn = None       # last clicked function name

    self.setWindowTitle("🔍 React Build Finder")
    self.resize(1100, 720)

    self.cb_try_alt_ext = QCheckBox("Try alternate extensions")
    self.cb_try_alt_ext.setChecked(True)

    # state
    self.last_output = ""
    self.last_errors_only = ""
    self.last_warnings_only = ""

    # inputs
    try:
        default_user = os.getlogin()
    except Exception:
        default_user = "solcatcher"
    self.user_in = QLineEdit(default_user)
    self.user_in.setPlaceholderText("ssh solcatcher")
    self.path_in = QLineEdit(os.getcwd())
    self.path_in.setPlaceholderText("Project path (folder with package.json)")

    # buttons
    self.run_btn = QPushButton("Run");    self.run_btn.clicked.connect(self.start_work)
    self.rerun_btn = QPushButton("Re-run build"); self.rerun_btn.clicked.connect(self.start_work)
    self.clear_btn = QPushButton("Clear"); self.clear_btn.clicked.connect(self.clear_ui)

    # log + filter
    self.log_view = QTextEdit(); self.log_view.setReadOnly(True);
    self.log_view.setLineWrapMode(QTextEdit.LineWrapMode.NoWrap)
    self.filter_group, rbs = self.create_radio_group(["All", "Errors only", "Warnings only"], 0, self.apply_log_filter)
    self.rb_all, self.rb_err, self.rb_wrn = rbs

    # lists
    self.errors_list  =  self.build_warnings_list()
    self.warnings_list =  self.build_warnings_list()
