class DPGContainersException(Exception):
    pass

class UnrenderedException(DPGContainersException):
    pass

class NamedChildNotFound(DPGContainersException):
    pass


