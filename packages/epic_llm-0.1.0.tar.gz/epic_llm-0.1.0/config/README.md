# README.md for config files

Application: crush cli
Description: :
Note: Uses the native Gemini API instead of the open


