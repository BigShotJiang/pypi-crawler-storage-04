class TokenConfigurationError(Exception):
    """Raised when token-related environment variables are missing or invalid."""
    pass
