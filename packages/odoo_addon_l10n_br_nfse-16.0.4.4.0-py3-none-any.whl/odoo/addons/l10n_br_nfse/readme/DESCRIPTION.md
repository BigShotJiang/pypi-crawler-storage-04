Este módulo permite a criação da base de Notas Fiscais de Serviço
Eletrônicas (NFS-e). O documento criado é genérico por isso necessita do
módulo do serviço específico de transmissão.
