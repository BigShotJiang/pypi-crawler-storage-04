from . import config

SETTINGS = config.Config()
