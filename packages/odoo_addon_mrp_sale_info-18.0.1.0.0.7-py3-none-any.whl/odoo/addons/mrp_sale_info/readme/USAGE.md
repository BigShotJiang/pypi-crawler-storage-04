New fields are displayed in tree and in form views (Extra information
tab).
