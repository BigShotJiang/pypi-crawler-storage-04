This module extends the functionality of Odoo for adding related fields
to Manufacturing Orders and Work Orders:

> - Sale order
> - Customer
> - Commitment Date
> - Customer Reference
