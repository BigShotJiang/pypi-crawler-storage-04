def main() -> None:
    print("Hello from fpl-data!")
