"""Tests for profiler module."""
