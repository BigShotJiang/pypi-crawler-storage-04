"""Timer demos and benchmarks."""
