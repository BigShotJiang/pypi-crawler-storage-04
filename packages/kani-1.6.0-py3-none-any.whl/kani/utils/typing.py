import os

PathLike = str | bytes | os.PathLike
