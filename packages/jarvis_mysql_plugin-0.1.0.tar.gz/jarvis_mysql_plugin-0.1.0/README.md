# JARVIS-MySQL-Plugin
A MySQL Database communication plugin designed to work with The J.A.R.V.I.S. Project. And hand in hand with all the plugins for this project.
