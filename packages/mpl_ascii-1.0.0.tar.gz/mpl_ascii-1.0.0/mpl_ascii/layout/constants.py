

RESERVED_CHARS = {" ", "/", "\\"}