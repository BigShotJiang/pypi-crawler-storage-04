# Ultralytics 🚀 AGPL-3.0 License - https://ultralytics.com/license

from autoimport.main import LazyLoader, lazy

__all__ = ("LazyLoader", "lazy")
__version__ = "0.0.4"
