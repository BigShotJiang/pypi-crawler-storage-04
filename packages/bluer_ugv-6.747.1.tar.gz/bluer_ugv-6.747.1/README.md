# 🐬 bluer-ugv

🐬 `@ugv` is a [bluer-ai](https://github.com/kamangir/bluer-ai) plugin for UGVs.

```bash
pip install bluer_ugv
```

|   |   |   |
| --- | --- | --- |
| [`bluer-swallow`](./bluer_ugv/docs/bluer_swallow) [![image](https://github.com/kamangir/assets2/raw/main/bluer-swallow/20250701_2206342_1.gif?raw=true)](./bluer_ugv/docs/bluer_swallow) based on power wheels. | [`bluer-sparrow`](./bluer_ugv/docs/bluer_sparrow) [![image](https://github.com/kamangir/assets2/raw/main/bluer-sparrow/VID-20250830-WA0000~3_1.gif?raw=true)](./bluer_ugv/docs/bluer_sparrow) [bluer-swallow](./bluer_ugv/docs/bluer_swallow)'s little sister. | [`bluer-robin`](./bluer_ugv/docs/bluer_robin) [![image](https://github.com/kamangir/assets2/raw/main/bluer-robin/20250723_095155~2_1.gif?raw=true)](./bluer_ugv/docs/bluer_robin) remote control car kit for teenagers. |
| [`bluer-eagle`](./bluer_ugv/docs/bluer_eagle) [![image](https://github.com/kamangir/assets2/raw/main/bluer-eagle/file_0000000007986246b45343b0c06325dd.png?raw=true)](./bluer_ugv/docs/bluer_eagle) a remotely controlled ballon. | [`bluer-fire`](./bluer_ugv/docs/bluer_fire) [![image](https://github.com/kamangir/assets/raw/main/bluer-ugv/bluer-fire.png?raw=true)](./bluer_ugv/docs/bluer_fire) based on a used car. | [`bluer-beast`](./bluer_ugv/docs/bluer_beast) [![image](https://github.com/waveshareteam/ugv_rpi/raw/main/media/UGV-Rover-details-23.jpg)](./bluer_ugv/docs/bluer_beast) based on [UGV Beast PI ROS2](https://www.waveshare.com/wiki/UGV_Beast_PI_ROS2). |

# aliases

[@swallow](./bluer_ugv/docs/aliases/swallow.md).

---

> 🌀 [`blue-rover`](https://github.com/kamangir/blue-rover) for the [Global South](https://github.com/kamangir/bluer-south).

---


[![pylint](https://github.com/kamangir/bluer-ugv/actions/workflows/pylint.yml/badge.svg)](https://github.com/kamangir/bluer-ugv/actions/workflows/pylint.yml) [![pytest](https://github.com/kamangir/bluer-ugv/actions/workflows/pytest.yml/badge.svg)](https://github.com/kamangir/bluer-ugv/actions/workflows/pytest.yml) [![bashtest](https://github.com/kamangir/bluer-ugv/actions/workflows/bashtest.yml/badge.svg)](https://github.com/kamangir/bluer-ugv/actions/workflows/bashtest.yml) [![PyPI version](https://img.shields.io/pypi/v/bluer-ugv.svg)](https://pypi.org/project/bluer-ugv/) [![PyPI - Downloads](https://img.shields.io/pypi/dd/bluer-ugv)](https://pypistats.org/packages/bluer-ugv)

built by 🌀 [`bluer README`](https://github.com/kamangir/bluer-objects/tree/main/bluer_objects/README), based on 🐬 [`bluer_ugv-6.747.1`](https://github.com/kamangir/bluer-ugv).

