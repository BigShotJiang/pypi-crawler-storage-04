# type: ignore
from .security import argon_hasher

__all__ = ["argon_hasher"]
