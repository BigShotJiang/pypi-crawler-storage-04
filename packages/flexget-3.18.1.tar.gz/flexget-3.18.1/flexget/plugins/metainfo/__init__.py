"""Plugins for "metainfo" task phase."""
