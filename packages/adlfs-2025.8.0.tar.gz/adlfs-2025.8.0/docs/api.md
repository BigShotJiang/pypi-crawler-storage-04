# API Reference

`adlfs.AzureBlobFileSystem` provides an interface for Azure Blob Storage.

```{eval-rst}
.. autoclass:: adlfs.AzureBlobFileSystem
    :show-inheritance:
    :members:

.. autoclass:: adlfs.AzureBlobFile
    :show-inheritance:
    :members:
```

