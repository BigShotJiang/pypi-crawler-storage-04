# makes relcheck.checks a package for discovery

