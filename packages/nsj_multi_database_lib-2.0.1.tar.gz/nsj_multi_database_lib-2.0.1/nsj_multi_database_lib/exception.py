class ParameterNotFound(Exception):
    pass
