
class BaseSelection:
    def __init__(self):
        pass