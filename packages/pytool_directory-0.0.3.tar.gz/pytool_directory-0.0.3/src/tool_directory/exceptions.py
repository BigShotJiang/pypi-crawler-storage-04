class ToolNotFoundException(Exception):
    pass
