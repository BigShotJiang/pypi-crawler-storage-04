default_app_config = "smoothglue.core.apps.TrackerConfig"
