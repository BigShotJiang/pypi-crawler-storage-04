import setuptools

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setuptools.setup(
    name="orionac-ai",
    version="0.1.0",
    author="Orionac",
    author_email="contact@orionac.com",
    description="The official Python SDK for the Orionac AI API (Theta-1.0-sl)",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/orionac/orionac-ai-python", # Replace with your actual URL
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
    python_requires='>=3.6',
    install_requires=[
        'requests>=2.25.0',
    ],
)
