# 🚀 OrionAI Python - Your AI Coding Companion

[![PyPI version](https://badge.fury.io/py/orionai.svg)](https://badge.fury.io/py/orionai)
[![Python](https://img.shields.io/badge/python-3.8%2B-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Streamlit](https://img.shields.io/badge/UI-Streamlit-red.svg)](https://streamlit.io/)

OrionAI Python transforms the way you write code by letting you describe what you want in plain English. Whether you're analyzing data, building machine learning models, or creating visualizations, just tell OrionAI what you need and watch it generate and execute the code for you.

## What makes OrionAI special?

**🎯 Just describe what you want** - No need to remember complex syntax or library details. Want to "analyze sales data and create a dashboard"? Just say it.

**🧠 Multiple AI providers** - Choose from Google Gemini, OpenAI, or Anthropic models based on your preferences and needs.

**🎓 Learn while you code** - Our Python tutor explains every concept with practical examples, making it perfect for beginners and experts alike.

**🎨 Beautiful web interface** - Test features, experiment with code, and learn interactively through our Streamlit interface.

**🔧 Handles the boring stuff** - Automatically installs packages, manages dependencies, and organizes your outputs so you can focus on the fun parts.

## Quick Start

```python
from orionai.python import AIPython

# Initialize your AI assistant
ai = AIPython()

# Just tell it what you want to do
ai.ask("Load the sales.csv file and show me the top 10 customers by revenue")

# Create visualizations with natural language
ai.ask("Make a bar chart showing monthly sales trends")

# Get help with any Python concept
ai.ask("Explain how list comprehensions work with examples")
```

Want to try the interactive interface? Just run:
```python
from orionai.python import ui
ui()  # Opens a web interface at http://localhost:8501
```

## Installation

```bash
# Install OrionAI
pip install orionai

# Or install with development dependencies
pip install orionai[dev]
```

Set up your API key:
```bash
# For Google Gemini (recommended - it's free!)
export GOOGLE_API_KEY="your-api-key-here"

# Or for OpenAI
export OPENAI_API_KEY="your-api-key-here"

# Or for Anthropic
export ANTHROPIC_API_KEY="your-api-key-here"
```

## What can OrionAI do?

### 📊 Data Analysis & Visualization
```python
ai.ask("Load my sales data and create a dashboard showing key metrics")
ai.ask("Find correlation between customer age and purchase amount")
ai.ask("Generate a heatmap of sales by region and month")
```

### 🤖 Machine Learning Made Simple
```python
ai.ask("Build a classifier to predict customer churn using my dataset")
ai.ask("Create a time series forecast for next quarter's sales")
ai.ask("Train a model to detect fraud in transactions")
```

### 🐍 Python Learning Assistant
```python
from orionai.python import SimplePythonChat

chat = SimplePythonChat()
chat.ask("How do I work with dates in Python?")
chat.explain_code("lambda x: x**2 if x > 0 else 0")
chat.get_examples("decorators")
```

### 💬 Interactive Programming
```python
from orionai.python import InteractiveCodeChat

code_chat = InteractiveCodeChat(session_name="my_project")
code_chat.chat("I need to analyze customer behavior patterns")
code_chat.chat_with_code("Load the dataset and show basic statistics")
```

### 🌐 Web & API Operations
```python
ai.ask("Scrape product prices from this e-commerce site")
ai.ask("Call this REST API and analyze the response")
ai.ask("Download and process data from multiple URLs")
```

### 🔒 Security & Encryption
```python
ai.ask("Generate secure passwords and hash them")
ai.ask("Encrypt this sensitive data file")
ai.ask("Validate and sanitize user inputs")
```

## Features by Category

<details>
<summary><strong>📈 Data Science (15+ features)</strong></summary>

- Pandas operations and analysis
- Statistical computations with NumPy  
- Data visualization with matplotlib/seaborn
- CSV/JSON data processing
- Missing data handling
- Feature engineering
- Data cleaning and transformation

</details>

<details>
<summary><strong>🤖 Machine Learning (10+ features)</strong></summary>

- Scikit-learn model building
- Model evaluation and metrics
- Feature selection and engineering
- Cross-validation and hyperparameter tuning
- Classification and regression
- Clustering analysis
- Performance visualization

</details>

<details>
<summary><strong>🌐 Web & Network (8+ features)</strong></summary>

- HTTP requests and API calls
- Web scraping and data extraction
- JSON/XML processing
- URL validation and parsing
- Rate limiting and retry logic
- Authentication handling
- Response processing

</details>

<details>
<summary><strong>💻 System & Performance (7+ features)</strong></summary>

- Memory usage monitoring
- Performance profiling
- Process management
- Environment variables
- File system operations
- Resource optimization
- Timing and benchmarking

</details>

<details>
<summary><strong>🔐 Security & Encryption (5+ features)</strong></summary>

- Password generation and validation
- Data encryption/decryption
- Input sanitization
- Secure file handling
- Authentication helpers

</details>

<details>
<summary><strong>📁 File Operations (5+ features)</strong></summary>

- File reading/writing
- Directory management  
- Archive creation/extraction
- Format conversions
- Batch file processing

</details>

## Interactive Web Interface

Launch the Streamlit interface to explore all features:

```python
from orionai.python import ui
ui()
```

The web interface includes:
- **🔧 LLM Configuration** - Switch between providers and models
- **🤖 AI Assistant** - General Python tasks and code generation  
- **🐍 Python Learning** - Interactive Python tutor
- **💬 Code Chat** - Conversational programming with memory
- **🧪 Feature Tests** - Try out specific capabilities
- **📚 Examples** - Ready-to-run code samples
- **📖 Documentation** - Built-in guides and API reference

## Configuration Options

```python
from orionai.python import AIPython

# Basic usage (uses Google Gemini by default)
ai = AIPython()

# Specify provider and model
ai = AIPython(
    provider="openai",
    model="gpt-4",
    api_key="your-key",
    verbose=True,
    auto_install=True
)

# Advanced configuration
ai = AIPython(
    provider="anthropic",
    model="claude-3-sonnet-20240229",
    max_retries=5,
    workspace_dir="./my_outputs",
    save_outputs=True,
    ask_permission=False
)
```

## Examples & Use Cases

### Real-World Scenarios

**📊 Business Analytics**
```python
ai.ask("Analyze our Q3 sales data and identify trends, top products, and underperforming regions")
```

**🔍 Research & Analysis**  
```python
ai.ask("Process this survey data, calculate significance tests, and create publication-ready charts")
```

**🚀 Rapid Prototyping**
```python
ai.ask("Build a simple web scraper for job postings and save results to a database")
```

**📚 Learning & Teaching**
```python
chat.ask("Show me different ways to handle errors in Python with real examples")
```

## Why Choose OrionAI?

✅ **Zero Learning Curve** - Start coding with natural language immediately  
✅ **Production Ready** - Robust error handling and enterprise features  
✅ **Educational** - Learn Python concepts while getting work done  
✅ **Flexible** - Works with your existing code and workflows  
✅ **Secure** - No code execution without your permission  
✅ **Open Source** - Transparent, community-driven development  

## Getting Help

- **📚 Documentation**: Check our [detailed guides](docs/) for comprehensive information
- **💡 Examples**: Browse [practical examples](examples/) for common use cases  
- **🐛 Issues**: Report bugs or request features on [GitHub Issues](https://github.com/AIMLDev726/OrionAI/issues)
- **💬 Discussions**: Join conversations in [GitHub Discussions](https://github.com/AIMLDev726/OrionAI/discussions)
- **🤝 Contributing**: See our [Contributing Guide](CONTRIBUTING.md) to get involved

## License

OrionAI is released under the MIT License. See [LICENSE](LICENSE) for details.

## What's Next?

We're actively working on:
- 🚀 More LLM provider integrations
- 📱 Mobile-responsive UI improvements  
- 🔌 Plugin system for custom extensions
- 🌍 Multi-language support
- ⚡ Performance optimizations
- 🧠 Advanced AI reasoning capabilities

---

**Ready to revolutionize your Python coding experience?** Install OrionAI today and start building with the power of AI!

```bash
pip install orionai
```
