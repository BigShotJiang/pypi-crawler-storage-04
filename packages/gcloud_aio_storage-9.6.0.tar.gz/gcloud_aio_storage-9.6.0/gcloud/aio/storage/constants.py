DEFAULT_TIMEOUT = 10  # by default, timeout in 10 seconds on requests
