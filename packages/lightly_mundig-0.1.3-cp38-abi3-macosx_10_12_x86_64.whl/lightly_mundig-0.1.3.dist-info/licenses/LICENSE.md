(C) 2025 Lightly AG
