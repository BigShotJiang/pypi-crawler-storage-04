---
name: Feature request
about: Suggest an idea for this project
title: "feat: "
labels: enhancement
assignees: ''
---

# Feature Request

## Description

Please provide a clear and concise description of the feature you would like to request.

## Motivation

Explain why this feature is important and how it would benefit the project.

## Proposed Solution

Outline your proposed solution or any ideas you have for implementing this feature.

## Additional Context

<!-- Add any additional context or screenshots about the feature request here. -->
<!-- If applicable, add screenshots to help explain the problem. -->
<!-- You can take a gif animation screenshot very easily without any additional installation by using this browser-based tool: -->
<!-- https://gifcap.dev -->


## Checklist

- [ ] I have searched for similar feature requests and confirmed that this is a new request.
- [ ] I have provided a clear and concise description of the feature.
- [ ] I have explained the motivation behind this feature request.
- [ ] I have outlined a proposed solution or ideas for implementing this feature.
- [ ] I have provided any additional context or screenshots if applicable.
