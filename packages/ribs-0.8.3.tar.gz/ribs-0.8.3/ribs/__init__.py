"""A bare-bones Python library for quality diversity optimization."""

__author__ = "ICAROS Lab pyribs Team"
__email__ = "team@pyribs.org"
__version__ = "0.8.3"

from ribs import archives, emitters, schedulers

__all__ = [
    "archives",
    "emitters",
    "schedulers",
]
