# 0.5.1
## Added
* Use six module to handle version compatibility
## Fixed
* Fixed the error that occured when calling extract_cursor in python2

# 0.5.0
* Make URL query param ordering consistent
* Use a first-party JSONAPIParser
* README improvements
* Update canonical API URL
* Set User-Agent for proper traffic attribution
* Make currently-unused parameter optional
* Improve flask example
* Thanks to: @21echoes, @tanabi, @phildini
