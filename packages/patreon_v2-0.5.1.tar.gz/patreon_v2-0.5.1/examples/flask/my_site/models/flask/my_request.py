from flask import Request


class MyRequest(Request):
    pass
