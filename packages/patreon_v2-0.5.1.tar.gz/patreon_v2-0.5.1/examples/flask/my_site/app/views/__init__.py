# import all views here for easy partial rendering
from .LandingPage.landing_page import LandingPage
from .LogIn.log_in import LogIn
