# Patreon OAuth Example: Flask Server

Simple website made with Flask and the Patreon OAuth API

## Install

1. `./install.sh && source venv/bin/activate`
2. Fill out `my_site/config.py` with your client details

## Running the Server

1. `./run_server.py`
2. Visit [http://localhost:5000](http://localhost:5000)