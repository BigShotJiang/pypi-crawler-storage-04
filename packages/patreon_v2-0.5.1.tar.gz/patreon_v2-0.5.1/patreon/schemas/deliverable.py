# deliverable.py
# This file is auto-generated from the same code that generates
# https://docs.patreon.com. Community pull requests against this
# file may not be accepted.

class Attributes(object):
    completed_at = 'completed_at'
    delivery_status = 'delivery_status'
    due_at = 'due_at'


class Relationships(object):
    campaign = 'campaign'
    benefit = 'benefit'
    member = 'member'
    user = 'user'
