# webhook.py
# This file is auto-generated from the same code that generates
# https://docs.patreon.com. Community pull requests against this
# file may not be accepted.

class Attributes(object):
    triggers = 'triggers'
    uri = 'uri'
    paused = 'paused'
    last_attempted_at = 'last_attempted_at'
    num_consecutive_times_failed = 'num_consecutive_times_failed'
    secret = 'secret'


class Relationships(object):
    client = 'client'
    campaign = 'campaign'
