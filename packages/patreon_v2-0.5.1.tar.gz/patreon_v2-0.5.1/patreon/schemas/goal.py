# goal.py
# This file is auto-generated from the same code that generates
# https://docs.patreon.com. Community pull requests against this
# file may not be accepted.

class Attributes(object):
    amount_cents = 'amount_cents'
    title = 'title'
    description = 'description'
    created_at = 'created_at'
    reached_at = 'reached_at'
    completed_percentage = 'completed_percentage'


class Relationships(object):
    campaign = 'campaign'
