# media.py
# This file is auto-generated from the same code that generates
# https://docs.patreon.com. Community pull requests against this
# file may not be accepted.

class Attributes(object):
    file_name = 'file_name'
    size_bytes = 'size_bytes'
    mimetype = 'mimetype'
    state = 'state'
    owner_type = 'owner_type'
    owner_id = 'owner_id'
    owner_relationship = 'owner_relationship'
    upload_expires_at = 'upload_expires_at'
    upload_url = 'upload_url'
    upload_parameters = 'upload_parameters'
    download_url = 'download_url'
    created_at = 'created_at'
    metadata = 'metadata'


