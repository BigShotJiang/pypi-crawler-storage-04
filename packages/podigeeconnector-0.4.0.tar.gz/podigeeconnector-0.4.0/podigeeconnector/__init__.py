"""
This package allows you to fetch data from the inofficial Podigee Podcast API.
The API is not documented and may change at any time. Use at your own risk.
"""

from .connector import PodigeeConnector

__all__ = ["PodigeeConnector"]
