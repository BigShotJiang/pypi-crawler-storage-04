To configure the possibility of registering mutiple attendees:

1.  Go to *Events \> Events*.
2.  Create one event.
3.  Check "Allow multiple attendees per registration" to activate this
    function.
