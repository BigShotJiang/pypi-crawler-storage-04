This module allows to make registration to events with more than one
attendee.

This was the unique behavior on versions 8 and 9. As it's useful for
some use cases, this module allows both ways of registering attendees.
