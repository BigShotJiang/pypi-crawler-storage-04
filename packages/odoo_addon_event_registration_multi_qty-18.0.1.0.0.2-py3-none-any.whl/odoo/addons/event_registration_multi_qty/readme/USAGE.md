For registering multiple attendees:

1.  Create an attendee for the created event.
2.  Write the quantities for this registration.
