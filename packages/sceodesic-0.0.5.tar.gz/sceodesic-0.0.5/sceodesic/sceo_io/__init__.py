
from .sceo_load_input import load_input

__all__ = ['load_input']