
UNS_KEY = 'sceodesic'
CLUSTER_KEY = 'cell2cluster'
STRATIFY_KEY = 'stratification_by'
HVG_KEY = 'top_genes'
CLUSTER_COVAR_KEY = 'cluster_covariances'
CLUSTER_VAR_CT_KEY = 'cluster_var_count'
EMBEDDINGS_DICT_KEY = 'embedding_dictionary'
MODULES_KEY = 'sceo_programs'
ADATA_KEY = 'filtered_data'


###
SCEO_EMBEDDINGS_KEY = 'sceo_embeddings'


###
SCEO_CONFIG_KEY = 'config'