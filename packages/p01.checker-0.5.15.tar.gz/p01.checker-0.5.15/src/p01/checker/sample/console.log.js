function logMessage(msg) {
    console.log('Testing console'); 
}

function showMessage(msg) {
    alert("HERE: " + msg);
}

function skipMessage() {
    alert("skip this error"); // p01.checker.silence
}

