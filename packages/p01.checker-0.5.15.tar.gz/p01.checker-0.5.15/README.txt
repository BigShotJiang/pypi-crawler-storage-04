This package provides a source checking/linting tool.
