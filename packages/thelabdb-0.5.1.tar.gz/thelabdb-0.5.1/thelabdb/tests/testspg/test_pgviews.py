from contextlib import closing
from typing import Any

from django.contrib import auth
from django.core.management import call_command
from django.db import connection
from django.db.models import signals
from django.dispatch import receiver
from django.test import TestCase

from thelabdb.pgviews.signals import all_views_synced, view_synced

from . import models


@receiver(signals.post_migrate)
def create_test_schema(sender: object, app_config: object, **kwargs: object) -> None:
    command = "CREATE SCHEMA IF NOT EXISTS {};".format("test_schema")
    print(f"\n\n{command}\n\n")
    with connection.cursor() as cursor:
        cursor.execute(command)


class ViewTestCase(TestCase):
    """Run the tests to ensure the post_migrate hooks were called."""

    def test_views_have_been_created(self) -> None:
        """Look at the PG View table to ensure views were created."""
        with closing(connection.cursor()) as cur:
            cur.execute(
                """SELECT COUNT(*) FROM pg_views
                        WHERE viewname LIKE 'testspg_%';"""
            )

            (count,) = cur.fetchone()
            self.assertEqual(count, 4)

            cur.execute(
                """SELECT COUNT(*) FROM pg_matviews
                        WHERE matviewname LIKE 'testspg_%';"""
            )

            (count,) = cur.fetchone()
            self.assertEqual(count, 3)

            cur.execute(
                """SELECT COUNT(*) FROM information_schema.views
                        WHERE table_schema = 'test_schema';"""
            )

            (count,) = cur.fetchone()
            self.assertEqual(count, 1)

    def test_clear_views(self) -> None:
        """Check the PG View table to see that the views were removed."""
        call_command("clear_pgviews", *[], **{})
        with closing(connection.cursor()) as cur:
            cur.execute(
                """SELECT COUNT(*) FROM pg_views
                        WHERE viewname LIKE 'testspg_%';"""
            )

            (count,) = cur.fetchone()
            self.assertEqual(count, 0)

            cur.execute(
                """SELECT COUNT(*) FROM information_schema.views
                        WHERE table_schema = 'test_schema';"""
            )

            (count,) = cur.fetchone()
            self.assertEqual(count, 0)

    def test_wildcard_projection(self) -> None:
        """Wildcard projections take all fields from a projected model."""
        foo_user = auth.models.User._default_manager.create(
            username="foo", is_superuser=True
        )
        foo_user.set_password("blah")
        foo_user.save()

        foo_superuser = models.Superusers._default_manager.get(
            username="foo",  # type:ignore[misc]
        )

        # TODO: mypy doesn't pick up projected fields
        self.assertEqual(foo_user.id, foo_superuser.id)
        self.assertEqual(
            foo_user.password,
            foo_superuser.password,  # type:ignore[attr-defined]
        )

    def test_limited_projection(self) -> None:
        """A limited projection only creates the projected fields."""
        foo_user = auth.models.User.objects.create(username="foo", is_superuser=True)
        foo_user.set_password("blah")
        foo_user.save()

        foo_simple = models.SimpleUser._default_manager.get(
            username="foo",  # type:ignore[misc]
        )

        # TODO: mypy doesn't pick up projected fields
        self.assertEqual(
            foo_simple.username,  # type:ignore[attr-defined]
            foo_user.username,
        )
        self.assertEqual(
            foo_simple.password,  # type:ignore[attr-defined]
            foo_user.password,
        )
        self.assertFalse(getattr(foo_simple, "date_joined", False))

    def test_related_delete(self) -> None:
        """Test views do not interfere with deleting the models"""
        test_model = models.TestModel()
        test_model.name = "Bob"
        test_model.save()
        test_model.delete()

    def test_materialized_view(self) -> None:
        """Test a materialized view works correctly"""
        self.assertEqual(
            models.MaterializedRelatedView.objects.count(),  # type:ignore[misc]
            0,
            "Materialized view should not have anything",
        )

        test_model = models.TestModel()
        test_model.name = "Bob"
        test_model.save()

        self.assertEqual(
            models.MaterializedRelatedView.objects.count(),  # type:ignore[misc]
            0,
            "Materialized view should not have anything",
        )

        models.MaterializedRelatedView.refresh()

        self.assertEqual(
            models.MaterializedRelatedView.objects.count(),  # type:ignore[misc]
            1,
            "Materialized view should have updated",
        )

        models.MaterializedRelatedViewWithIndex.refresh(concurrently=True)

        self.assertEqual(
            models.MaterializedRelatedViewWithIndex.objects.count(),  # type:ignore[misc]
            1,
            "Materialized view should have updated concurrently",
        )

    def test_signals(self) -> None:
        expected = {
            models.MaterializedRelatedView: {
                "status": "CREATED",
                "has_changed": True,
            },
            models.Superusers: {
                "status": "EXISTS",
                "has_changed": False,
            },
        }
        synced_views = []
        all_views_were_synced = [False]

        @receiver(view_synced)
        def on_view_synced(sender: type[Any], **kwargs: Any) -> None:
            synced_views.append(sender)
            if sender in expected:
                expected_kwargs = expected.pop(sender)
                self.assertEqual(
                    dict(
                        expected_kwargs, update=False, force=False, signal=view_synced
                    ),
                    kwargs,
                )

        @receiver(all_views_synced)
        def on_all_views_synced(sender: type[Any], **kwargs: Any) -> None:
            all_views_were_synced[0] = True

        call_command("sync_pgviews", update=False)

        # All views went through syncing
        self.assertEqual(len(synced_views), 8)
        self.assertEqual(all_views_were_synced[0], True)
        self.assertFalse(expected)


class DependantViewTestCase(TestCase):
    def test_sync_depending_views(self) -> None:
        """Test the sync_pgviews command for views that depend on other views.

        This test drops `testspg_dependantview` and its dependencies
        and recreates them manually, thereby simulating an old state
        of the views in the db before changes to the view model's sql is made.
        Then we sync the views again and verify that everything was updated.
        """

        with closing(connection.cursor()) as cur:
            cur.execute("DROP VIEW testspg_relatedview CASCADE;")

            cur.execute(
                """CREATE VIEW testspg_relatedview as
                SELECT id AS model_id, name FROM testspg_testmodel;"""
            )

            cur.execute(
                """CREATE VIEW testspg_dependantview as
                        SELECT name from testspg_relatedview;"""
            )

            cur.execute("""SELECT name from testspg_relatedview;""")
            cur.execute("""SELECT name from testspg_dependantview;""")

        call_command("sync_pgviews", "--force")

        with closing(connection.cursor()) as cur:
            cur.execute(
                """SELECT COUNT(*) FROM pg_views
                        WHERE viewname LIKE 'testspg_%';"""
            )

            (count,) = cur.fetchone()
            self.assertEqual(count, 4)

            with self.assertRaises(Exception):
                cur.execute("""SELECT name from testspg_relatedview;""")

            with self.assertRaises(Exception):
                cur.execute("""SELECT name from testspg_dependantview;""")

    def test_sync_depending_materialized_views(self) -> None:
        """Refresh views that depend on materialized views."""
        with closing(connection.cursor()) as cur:
            cur.execute(
                """DROP MATERIALIZED VIEW testspg_materializedrelatedview
                CASCADE;"""
            )

            cur.execute(
                """CREATE MATERIALIZED VIEW testspg_materializedrelatedview as
                SELECT id AS model_id, name FROM testspg_testmodel;"""
            )

            cur.execute(
                """CREATE MATERIALIZED VIEW testspg_dependantmaterializedview
                as SELECT name from testspg_materializedrelatedview;"""
            )
            cur.execute("""SELECT name from testspg_materializedrelatedview;""")
            cur.execute("""SELECT name from testspg_dependantmaterializedview;""")

        call_command("sync_pgviews", "--force")

        with closing(connection.cursor()) as cur:
            cur.execute(
                """SELECT COUNT(*) FROM pg_views
                        WHERE viewname LIKE 'testspg_%';"""
            )

            (count,) = cur.fetchone()
            self.assertEqual(count, 4)

            with self.assertRaises(Exception):
                cur.execute(
                    """SELECT name from
                    testspg_dependantmaterializedview;"""
                )
                cur.execute("""SELECT name from testspg_materializedrelatedview; """)

            with self.assertRaises(Exception):
                cur.execute(
                    """SELECT name from
                    testspg_dependantmaterializedview;"""
                )
