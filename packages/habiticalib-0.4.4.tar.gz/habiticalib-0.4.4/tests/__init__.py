"""Tests for Habiticalib."""
