# mulaptested-pakname

This is an educational proof-of-concept (PoC) package designed to demonstrate typo squatting or dependency confusion testing in PyPI. It is intended for learning purposes only and does not collect sensitive user data.

## Purpose
- Simulates a notification mechanism to highlight potential installation errors.
- Does not send data to external servers by default (disabled via `NOTIFY_SERVER = False`).
- Can be enabled for testing with explicit user consent.

## Usage
- Install: `pip install mulaptested-pakname`
- Run: `python -m mulaptested_pakname.notification`

## Disclaimer
This package is experimental. Use it responsibly and only for educational purposes. The authors are not responsible for misuse.

## License
MIT License