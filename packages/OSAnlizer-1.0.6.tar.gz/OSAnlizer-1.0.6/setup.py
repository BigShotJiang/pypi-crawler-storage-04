from setuptools import setup

setup(
    name="OSAnlizer",
    version="1.0.6",
    description="Educational PoC for dependency confusion and typo squatting testing",
    author="Your Name",
    license="MIT",
    scripts=['notification.py'],  # السكربت الذي سيعمل بعد التثبيت
    install_requires=[
        'requests',
        'psutil',
        'tzlocal'
    ],
    long_description=open('README.md', encoding='utf-8').read(),
    long_description_content_type='text/markdown',
)
