import pandas as pd

class Index(pd.MultiIndex):
