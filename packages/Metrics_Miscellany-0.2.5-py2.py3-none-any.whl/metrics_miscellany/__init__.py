from . import estimators
from . import tests
from . import utils
from . import order_statistics
from .datamat import DataMat, DataVec
from . import kernel_methods
