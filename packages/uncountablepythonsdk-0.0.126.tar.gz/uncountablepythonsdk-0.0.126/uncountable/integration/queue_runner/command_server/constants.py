class ListQueuedJobsConstants:
    LIMIT_MIN = 1
    LIMIT_MAX = 100
    OFFSET_MIN = 0
