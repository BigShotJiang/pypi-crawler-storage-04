"""
Utilities package for Spark Analyzer.
"""
