import sys
from imgfind.teeny import main

sys.exit(main())
