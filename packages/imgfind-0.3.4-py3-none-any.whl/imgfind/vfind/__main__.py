import sys
from imgfind.vfind import main

sys.exit(main())
