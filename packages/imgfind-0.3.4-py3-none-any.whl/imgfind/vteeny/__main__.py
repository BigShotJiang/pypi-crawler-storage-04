import sys
from imgfind.vteeny import main

sys.exit(main())
