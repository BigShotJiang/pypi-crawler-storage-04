"""XML readers and writers."""

from pysdmx.__extras_check import __check_xml_extra

__check_xml_extra()
