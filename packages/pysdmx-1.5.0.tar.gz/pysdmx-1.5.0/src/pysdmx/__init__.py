"""Your opinionated Python SDMX library."""

__version__ = "1.5.0"
