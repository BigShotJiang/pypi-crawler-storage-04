"""pysdmx api package."""
