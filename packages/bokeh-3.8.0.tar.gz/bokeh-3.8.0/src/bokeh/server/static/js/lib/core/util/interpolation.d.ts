import type { Arrayable } from "../types";
export declare function catmullrom_spline(x: Arrayable<number>, y: Arrayable<number>, T?: number, tension?: number, closed?: boolean): [Arrayable<number>, Arrayable<number>];
//# sourceMappingURL=interpolation.d.ts.map