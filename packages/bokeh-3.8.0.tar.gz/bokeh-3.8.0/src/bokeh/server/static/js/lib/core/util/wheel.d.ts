/*!
 * jQuery Mousewheel 3.1.13
 *
 * Copyright jQuery Foundation and other contributors
 * Released under the MIT license
 * http://jquery.org/license
 */
export declare function getDeltaY(event: WheelEvent): number;
//# sourceMappingURL=wheel.d.ts.map