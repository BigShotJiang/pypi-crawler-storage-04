"""
Examples demonstrating the earthdata-mcp-server composition capabilities.

This package contains example scripts showing how to use the integrated
earthdata and jupyter MCP server tools for Earth science workflows.
"""

__all__ = []
