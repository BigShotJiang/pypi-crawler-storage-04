# langchain-cli

This package implements the official CLI for LangChain. Right now, it is most useful
for getting started with LangChain Templates!

[CLI Docs](https://github.com/langchain-ai/langchain/blob/master/libs/cli/DOCS.md)
