"""Generate migrations."""
