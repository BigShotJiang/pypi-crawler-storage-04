from .base_load import base, Confpool, MolProxy
from .molgraph import Molecule
from typing import Type

__version__ = "{{version}}"
DEG2RAD = 0.0174532925199432957692
RAD2DEG = 1 / DEG2RAD
H2KC = 627.509474063
KC2H = 1 / H2KC
