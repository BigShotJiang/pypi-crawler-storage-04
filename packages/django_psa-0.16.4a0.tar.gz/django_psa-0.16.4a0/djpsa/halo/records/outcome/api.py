from djpsa.halo.api import HaloAPIClient


class OutcomeAPI(HaloAPIClient):
    endpoint = 'Outcome'
