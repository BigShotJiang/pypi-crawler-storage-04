from djpsa.halo.api import HaloAPIClient


class SiteAPI(HaloAPIClient):
    endpoint = 'Site'
