# Changelog
## 0.1.1
* Update docs embedded in README
* Some imports optimization in tests

## 0.1.0
* Initial release