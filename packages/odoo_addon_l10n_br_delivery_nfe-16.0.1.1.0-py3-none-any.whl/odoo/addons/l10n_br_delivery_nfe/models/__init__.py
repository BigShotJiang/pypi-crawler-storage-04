from . import document
from . import product_product
from . import product_template
from . import stock_picking_vol
from . import stock_picking_lacres
from . import stock_picking
