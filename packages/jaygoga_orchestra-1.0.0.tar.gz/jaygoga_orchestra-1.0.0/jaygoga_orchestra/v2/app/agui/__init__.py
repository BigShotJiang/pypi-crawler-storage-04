from rich.console import Console
console = Console()
from jaygoga_orchestra.v2.app.agui.app import AGUIApp

__all__ = ["AGUIApp"]
