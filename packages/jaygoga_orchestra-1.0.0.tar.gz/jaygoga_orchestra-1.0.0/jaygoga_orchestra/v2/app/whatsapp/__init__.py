from rich.console import Console
console = Console()
from jaygoga_orchestra.v2.app.whatsapp.app import WhatsappAPI

__all__ = ["WhatsappAPI"]
