from rich.console import Console
console = Console()
"""Third-party LLM implementations for crewAI."""
