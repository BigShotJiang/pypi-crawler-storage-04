from rich.console import Console
console = Console()
from .telemetry import Telemetry

__all__ = ["Telemetry"]
