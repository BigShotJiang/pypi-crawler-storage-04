from rich.console import Console
console = Console()
CREWAI_TELEMETRY_BASE_URL: str = "https://telemetry.jaygoga_orchestra.v1.com:4319"
CREWAI_TELEMETRY_SERVICE_NAME: str = "crewAI-telemetry"
