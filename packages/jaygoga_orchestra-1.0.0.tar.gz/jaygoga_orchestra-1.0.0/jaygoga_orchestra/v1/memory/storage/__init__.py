from rich.console import Console
console = Console()
"""Memory storage implementations for crewAI."""
