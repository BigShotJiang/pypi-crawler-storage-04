from rich.console import Console
console = Console()
"""Storage components for RAG infrastructure."""