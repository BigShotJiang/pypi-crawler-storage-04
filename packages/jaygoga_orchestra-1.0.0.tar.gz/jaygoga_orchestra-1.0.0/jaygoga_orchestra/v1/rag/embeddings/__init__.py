from rich.console import Console
console = Console()
"""Embedding components for RAG infrastructure."""