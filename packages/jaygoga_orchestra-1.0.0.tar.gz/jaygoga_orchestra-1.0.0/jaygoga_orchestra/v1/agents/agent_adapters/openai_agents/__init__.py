from rich.console import Console
console = Console()
"""OpenAI agent adapters for crewAI."""
