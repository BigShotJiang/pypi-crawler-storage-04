from rich.console import Console
console = Console()
from .cache_handler import CacheHandler

__all__ = ["CacheHandler"]
