from rich.console import Console
console = Console()
"""Squad-specific utilities."""