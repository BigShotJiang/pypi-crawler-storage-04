from rich.console import Console
console = Console()
"""Exceptions for crewAI."""
