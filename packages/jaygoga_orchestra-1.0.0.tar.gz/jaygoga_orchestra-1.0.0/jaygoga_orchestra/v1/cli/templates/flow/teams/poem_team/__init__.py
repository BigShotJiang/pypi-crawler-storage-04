from rich.console import Console
console = Console()
"""Poem squad template."""
