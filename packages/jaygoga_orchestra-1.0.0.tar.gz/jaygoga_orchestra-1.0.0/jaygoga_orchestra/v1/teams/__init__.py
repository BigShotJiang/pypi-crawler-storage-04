from rich.console import Console
console = Console()
from .team_output import CrewOutput

__all__ = ["CrewOutput"]
