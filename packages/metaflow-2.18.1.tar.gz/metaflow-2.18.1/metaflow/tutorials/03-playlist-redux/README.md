# Episode 03-playlist-redux: Follow the Money.

**Use Metaflow to load the statistics generated from 'Episode 02' and improve
our playlist generator by only recommending top box office grossing movies.**

#### Showcasing:
- Using data artifacts generated from other flows.

#### Before playing this episode:
1. Run 'Episode 02-statistics: Is this Data Science?'

#### To play this episode:
1. ```cd metaflow-tutorials```
2. ```python 03-playlist-redux/playlist.py show```
3. ```python 03-playlist-redux/playlist.py run```
