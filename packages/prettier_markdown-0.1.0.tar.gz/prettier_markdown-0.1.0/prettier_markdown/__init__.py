"""A fast command-line formatter for Markdown files."""

__version__ = '0.1.0'
