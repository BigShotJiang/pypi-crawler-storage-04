## Python coding style

1. Always add type hints where appropriate
2. Use "modern" type hints (such as "dict" instead of "typing.Dict")
3. Use absolute import instead of relative import
