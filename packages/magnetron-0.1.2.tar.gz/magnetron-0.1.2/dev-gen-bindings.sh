#!/usr/bin/env bash
set -euo pipefail

python3 python/bing_gen.py