"""Unused search model."""
