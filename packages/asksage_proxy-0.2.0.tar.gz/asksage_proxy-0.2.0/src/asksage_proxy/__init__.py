"""AskSage Proxy - OpenAI-compatible proxy for AskSage API."""

__version__ = "0.2.0"
