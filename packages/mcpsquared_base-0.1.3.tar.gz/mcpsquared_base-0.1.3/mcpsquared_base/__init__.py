"""
Chain Selection MCP Server

Provides tools for MCPSquared selector/executor handoff:
- write_chain_selection: Write chain selections to handoff files
"""