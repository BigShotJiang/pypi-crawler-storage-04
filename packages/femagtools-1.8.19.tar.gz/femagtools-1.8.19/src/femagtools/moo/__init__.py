
"""
  Multi objective Optimizer
  ~~~~~~~~~~~~~~~~~~~~~~~~~





"""
from .population import Population, Individual
from .problem import Problem
from .algorithm import Nsga2
