"""Communicate with the widgets and models existing in the napari GUI
via Python."""
