from .feature_modelling._obs import ObsAggregator

__all__ = [
    "ObsAggregator",
]
