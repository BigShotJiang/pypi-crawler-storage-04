NOLAN_KEY = "nolan"
CN_KEY = "cellular_neighborhoods"
NE_KEY = "neighborhoods_enrichment"
