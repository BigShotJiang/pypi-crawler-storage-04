
export let coreEmailFilt = { plugin: "peek_core_email" };
export let coreEmailTuplePrefix = "peek_core_email.";

export let coreEmailTupleOfflineServiceName = "peekCoreEmail";
export let coreEmailObservableName = "peekCoreEmail";

export let coreEmailActionProcessorName = "peekCoreEmail";

export let coreEmailBaseUrl = "peek_core_email";

export let coreEmailPluginName = "peek_core_email";