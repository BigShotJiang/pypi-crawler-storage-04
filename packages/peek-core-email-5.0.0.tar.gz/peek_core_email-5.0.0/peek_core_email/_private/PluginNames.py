inboxFilt = {"plugin": "peek_core_email"}
inboxTuplePrefix = "peek_core_email."

inboxObservableName = "peekCoreEmail"

inboxActionProcessorName = "peekCoreEmail"
