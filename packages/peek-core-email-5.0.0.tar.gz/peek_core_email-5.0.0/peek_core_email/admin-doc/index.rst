==============
Administration
==============

This is a core peek module providing support for sending Emails from the peek platform.

.. toctree::
    :maxdepth: 3
    :caption: Contents:

    setup/setup
    admin_task/admin_tasks
