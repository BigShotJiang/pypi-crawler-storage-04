from setuptools import setup, find_packages


with open("README.MD", "r") as f:
    description = f.read()

setup(
    name="alphabuilder_signal",
    version='0.2.5',
    install_requires = [
        # dependencies
    ],
    entry_points={
        "console_scripts": [
            "alphabuilder_signal = indicators:TechnicalIndicators"
        ],
    },
    long_description=description,
    long_description_content_type="text/markdown",
    description="Alpha signal library for quantitative finance research",
    author="Geet Mukherjee",
    author_email="mukherjeegeet3@gmail.com",
    url="https://pypi.org/project/alphabuilder-signal/",
    classifiers=[
        "Development Status :: 2 - Pre-Alpha",
        "Programming Language :: Python :: 3",
        "Intended Audience :: Science/Research",
        "Topic :: Scientific/Engineering :: Information Analysis",
        "License :: OSI Approved :: MIT License",
    ],
    python_requires=">=3.8",
    package_dir={"": "src"},
    packages=find_packages(where="src", exclude=["tests", "tests.*"]),
)