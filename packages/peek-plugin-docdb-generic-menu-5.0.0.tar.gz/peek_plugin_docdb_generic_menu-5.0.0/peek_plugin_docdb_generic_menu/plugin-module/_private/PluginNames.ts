export let docDbGenericMenuFilt = { plugin: "peek_plugin_docdb_generic_menu" };
export let docDbGenericMenuTuplePrefix = "peek_plugin_docdb_generic_menu.";

export let docDbGenericMenuObservableName = "peek_plugin_docdb_generic_menu";
export let docDbGenericMenuActionProcessorName =
    "peek_plugin_docdb_generic_menu";
export let docDbGenericMenuTupleOfflineServiceName =
    "peek_plugin_docdb_generic_menu";

export let docDbGenericMenuBaseUrl = "peek_plugin_docdb_generic_menu";
