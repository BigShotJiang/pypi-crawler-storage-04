==============
Administration
==============

The Object Generic Menu allows administrators to add additional menus that appear when
a display item is selected on the object.

Menu items can have multiple placeholders from the DocDB and the data from the display
item.

.. toctree::
    :maxdepth: 3
    :caption: Contents:

    menus/menus
    admin_tasks/admin_tasks

