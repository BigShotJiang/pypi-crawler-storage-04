To use this module, you need to:

1.  Have the "Show Full Accounting Features" option activated for your
    user.
2.  Go to Invoicing \> Reporting \> Management \> Invoice Lines
