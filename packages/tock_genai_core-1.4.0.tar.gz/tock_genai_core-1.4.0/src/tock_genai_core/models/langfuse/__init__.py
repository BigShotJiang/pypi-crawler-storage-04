# -*- coding: utf-8 -*-
"""Initialisation de module(s)."""

from .setting import LangfuseSetting
