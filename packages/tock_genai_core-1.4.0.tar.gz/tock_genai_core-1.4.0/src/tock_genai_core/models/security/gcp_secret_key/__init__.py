# -*- coding: utf-8 -*-
from .gcp_secret_key import GcpSecretKey
