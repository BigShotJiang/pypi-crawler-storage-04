===========
Chat Plugin
===========

This is a Peek Plugin to enable chat between users in the Peek platform.