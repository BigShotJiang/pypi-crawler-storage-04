export let chatFilt = { plugin: "peek_plugin_chat" };
export let chatTuplePrefix = "peek_plugin_chat.";

export let chatObservableName = "peek_plugin_chat";
export let chatActionProcessorName = "peek_plugin_chat";
export let chatTupleOfflineServiceName = "peek_plugin_chat";

export let chatBaseUrl = "peek_plugin_chat";
