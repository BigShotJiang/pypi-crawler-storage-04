==========
User Guide
==========

The Chat plugin allows field users to chat with each other, they can also chat with
external systems.