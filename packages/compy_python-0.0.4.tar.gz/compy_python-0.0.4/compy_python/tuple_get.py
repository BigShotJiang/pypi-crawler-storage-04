from typing import Any


def tg(tup: tuple[Any, ...], index: int) -> Any:
    return tup[index]
