def list_reserve[T](arr: list[T], size: int) -> None:
    pass
