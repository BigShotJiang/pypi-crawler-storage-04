def to_std_string(s: str) -> str:
    return s


def to_c_string(s: str) -> str:
    return s
