from ._commands import command , get_commands , find_command
from ._movie_title import movie_finder