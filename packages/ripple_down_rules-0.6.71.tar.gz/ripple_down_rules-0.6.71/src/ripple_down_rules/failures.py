

class RDRLoadError(Exception):
    pass
