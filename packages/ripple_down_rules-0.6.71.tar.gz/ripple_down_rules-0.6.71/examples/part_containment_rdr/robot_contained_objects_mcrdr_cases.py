# This file contains the corner cases for the rules.
from ripple_down_rules.datastructures.dataclasses import CaseFactoryMetaData


corner_case_298609776593271728826836208156881692889 = CaseFactoryMetaData(factory_method=None, factory_idx=None, case_conf=None, scenario=None)


