# This file contains the corner cases for the rules.
from ripple_down_rules.datastructures.dataclasses import CaseFactoryMetaData


corner_case_167615852950279355863004646114673699744 = CaseFactoryMetaData(factory_method=None, factory_idx=None, case_conf=None, scenario=None)


