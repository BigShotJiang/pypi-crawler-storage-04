"""
External interfaces for the uoapi package.

This package contains CLI and API interfaces that provide user-facing
functionality while using the service layer for business logic.
"""