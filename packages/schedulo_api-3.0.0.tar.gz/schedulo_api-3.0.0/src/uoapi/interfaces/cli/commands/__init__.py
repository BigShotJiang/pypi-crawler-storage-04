"""
CLI command implementations.

This package contains specific command implementations that use
the CLI framework and service layer.
"""