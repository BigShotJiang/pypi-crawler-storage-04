"""
CLI interface framework.

This module provides the common CLI patterns and utilities
used across all command implementations.
"""