# Package name : banklewan09

`banklewan09` is a lightweight Python package that provides simple utility functions
for **math**, **string processing**, and **data summarization**.
It is designed mainly for learning purposes and as an example of Python packaging.

---

## Features
- **Volume calculation**: compute the volume of a cylinder  
- **Lateral area calculation**: compute the lateral surface area of a cylinder  
- **Surface area calculation**: compute the total surface area of a cylinder  

---

## Installation

You can install the package directly from PyPI:

```bash
pip install banklewan09