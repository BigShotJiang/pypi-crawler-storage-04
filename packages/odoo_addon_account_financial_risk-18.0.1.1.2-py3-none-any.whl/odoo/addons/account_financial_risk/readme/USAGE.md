To use this module, you need to:

1.  Go to *Invoicing/Accounting \> Customers \> Customers*.
2.  Select an existing customer or create a new one.
3.  Open the *Financial Risk* tab.
4.  Set limits and choose options to compute in credit limit.
5.  Go to *Invoicing/Accounting \> Customers \> Invoices* and create new
    customer invoices.
6.  Test the restriction trying to create an invoice for the partner for
    an amount higher of the limit you have set.
7.  Return to Customer *Financial Risk* tab and click in amount to view
    origin.
