from . import account_invoice
from . import res_company
from . import res_config
from . import res_partner
