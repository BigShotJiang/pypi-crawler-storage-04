# thonny-logging-plugin
The goal of this plugin is to log the meaningfull user's actions and send them to a server in order to analyse them.  
The logs can also be stored localy.  

There is an option pannel in the menu Tools --> Options --> LoggingPlugin to change the server's address or the local file path.

The informations are sended to the xAPI format