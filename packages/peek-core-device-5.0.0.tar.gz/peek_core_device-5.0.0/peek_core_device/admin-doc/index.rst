==============
Administration
==============

The device plugin manages the device registration and updates of
the peek mobile and desktop systems.

This performs these primary functions :

#.  Pairs the apps/devices to the Peek Client

#.  Assignees device ids, used for user login and logging.


.. toctree::
    :maxdepth: 3
    :caption: Contents:

    overview
    general_settings/general_settings
    admin_tasks/admin_tasks

