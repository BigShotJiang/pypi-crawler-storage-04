export const SERVER_INFO_TUPLE_DEFAULTS = {
    host: null,
    useSsl: false,
    httpPort: 8000,
    websocketPort: 8000,
    hasConnected: false,
};
