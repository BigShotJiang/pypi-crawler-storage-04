export let deviceFilt = { plugin: "peek_core_device" };
export let deviceTuplePrefix = "peek_core_device.";

export let deviceObservableName = "peek_core_device";
export let deviceActionProcessorName = "peek_core_device";
export let deviceTupleOfflineServiceName = "peek_core_device";

export let deviceBaseUrl = "peek_core_device";
