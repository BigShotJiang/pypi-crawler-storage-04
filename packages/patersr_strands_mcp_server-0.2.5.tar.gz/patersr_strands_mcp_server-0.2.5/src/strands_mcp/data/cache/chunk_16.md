# Types

**Source:** https://github.com/strands-agents/docs/blob/main/docs/api-reference/types.md
**Section:** Docs
**Last Modified:** 2025-07-30T15:16:59+00:00

---

::: strands.types
    options:
      heading_level: 1
      members: false
::: strands.types.content
    options:
      heading_level: 2
::: strands.types.event_loop
    options:
      heading_level: 2
::: strands.types.exceptions
    options:
      heading_level: 2
::: strands.types.guardrails
    options:
      heading_level: 2
::: strands.types.media
    options:
      heading_level: 2
::: strands.types.session
    options:
      heading_level: 2
::: strands.types.streaming
    options:
      heading_level: 2
::: strands.types.tools
    options:
      heading_level: 2
::: strands.types.traces
    options:
      heading_level: 2
