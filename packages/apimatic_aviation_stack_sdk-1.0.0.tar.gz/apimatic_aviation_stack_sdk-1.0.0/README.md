
# Getting Started with Aviationstack

## Introduction

AviationStack API provides real-time and historical aviation data including flights, airports, airlines, and more.
This API allows you to access comprehensive aviation information for various use cases.

## Install the Package

The package is compatible with Python versions `3.7+`.
Install the package from PyPi using the following pip command:

```bash
pip install apimatic-aviation-stack-sdk==1.0.0
```

You can also view the package at:
https://pypi.python.org/pypi/apimatic-aviation-stack-sdk/1.0.0

## Test the SDK

You can test the generated SDK and the server with test cases. `unittest` is used as the testing framework and `pytest` is used as the test runner. You can run the tests as follows:

Navigate to the root directory of the SDK and run the following commands


pip install -r test-requirements.txt
pytest


## Initialize the API Client

**_Note:_** Documentation for the client can be found [here.](doc/client.md)

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| http_client_instance | `HttpClient` | The Http Client passed from the sdk user for making requests |
| override_http_client_configuration | `bool` | The value which determines to override properties of the passed Http Client from the sdk user |
| http_call_back | `HttpCallBack` | The callback value that is invoked before and after an HTTP call is made to an endpoint |
| timeout | `float` | The value to use for connection timeout. <br> **Default: 60** |
| max_retries | `int` | The number of times to retry an endpoint call if it fails. <br> **Default: 0** |
| backoff_factor | `float` | A backoff factor to apply between attempts after the second try. <br> **Default: 2** |
| retry_statuses | `Array of int` | The http statuses on which retry is to be done. <br> **Default: [408, 413, 429, 500, 502, 503, 504, 521, 522, 524]** |
| retry_methods | `Array of string` | The http methods on which retry is to be done. <br> **Default: ['GET', 'PUT']** |
| proxy_settings | [`ProxySettings`](doc/proxy-settings.md) | Optional proxy configuration to route HTTP requests through a proxy server. |
| custom_query_authentication_credentials | [`CustomQueryAuthenticationCredentials`](__base_path/auth/custom-query-parameter.md) | The credential object for Custom Query Parameter |

The API client can be initialized as follows:

```python
from aviationstack.aviationstack_client import AviationstackClient
from aviationstack.configuration import Environment
from aviationstack.http.auth.custom_query_authentication import CustomQueryAuthenticationCredentials

client = AviationstackClient(
    custom_query_authentication_credentials=CustomQueryAuthenticationCredentials(
        access_key='access_key'
    ),
    environment=Environment.PRODUCTION
)
```

## Authorization

This API uses the following authentication schemes.

* [`ApiKeyAuth (Custom Query Parameter)`](__base_path/auth/custom-query-parameter.md)

## List of APIs

* [Aircraft Types](doc/controllers/aircraft-types.md)
* [Flight Schedules](doc/controllers/flight-schedules.md)
* [Flight Future Schedules](doc/controllers/flight-future-schedules.md)
* [Flights](doc/controllers/flights.md)
* [Routes](doc/controllers/routes.md)
* [Airports](doc/controllers/airports.md)
* [Airlines](doc/controllers/airlines.md)
* [Airplanes](doc/controllers/airplanes.md)
* [Taxes](doc/controllers/taxes.md)
* [Cities](doc/controllers/cities.md)
* [Countries](doc/controllers/countries.md)

## SDK Infrastructure

### Configuration

* [ProxySettings](doc/proxy-settings.md)

### HTTP

* [HttpResponse](doc/http-response.md)
* [HttpRequest](doc/http-request.md)

### Utilities

* [ApiHelper](doc/api-helper.md)
* [HttpDateTime](doc/http-date-time.md)
* [RFC3339DateTime](doc/rfc3339-date-time.md)
* [UnixDateTime](doc/unix-date-time.md)

