# -*- coding: utf-8 -*-


class IOCheckerError(Exception):
    pass
