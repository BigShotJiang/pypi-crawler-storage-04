// main.js
// This file initializes the application by importing necessary modules and setting up event listeners.

import './javascript/album.js';
import './javascript/events.js';
import './javascript/metadata-drawer.js';
import './javascript/search-ui.js';
import './javascript/search.js';
import './javascript/seek-slider.js';
import './javascript/settings.js';
import './javascript/state.js';
import './javascript/swiper.js';
import './javascript/thumbnail-gallery.js';
import './javascript/umap.js';
import './javascript/utils.js';

