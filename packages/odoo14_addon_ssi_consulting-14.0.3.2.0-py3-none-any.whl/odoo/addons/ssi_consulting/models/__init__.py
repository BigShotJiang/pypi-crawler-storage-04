# Copyright 2025 OpenSynergy Indonesia
# Copyright 2025 PT. Simetri Sinergi Indonesia
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

from . import (
    consulting_data_structure,
    consulting_materialized_view,
    consulting_dashboard_template,
    consulting_chart_template,
    consulting_report_template,
    consulting_schema_parser,
    consulting_service_type,
    consulting_service,
    consulting_service_detail,
    consulting_service_materialized_view,
    consulting_service_chart,
)
