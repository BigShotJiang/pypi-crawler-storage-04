def test_import():
    import flexprofiler
    assert hasattr(flexprofiler, "__version__")
