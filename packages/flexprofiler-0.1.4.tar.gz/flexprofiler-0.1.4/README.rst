flexprofiler
============

A flexible profiling utility for Python.

See README.md for usage and details.
