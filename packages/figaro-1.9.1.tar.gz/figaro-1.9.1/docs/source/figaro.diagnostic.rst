figaro.diagnostic module
========================

.. automodule:: figaro.diagnostic
   :members:
   :undoc-members:
   :show-inheritance:
