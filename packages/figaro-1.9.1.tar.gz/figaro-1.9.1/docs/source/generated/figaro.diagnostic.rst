﻿figaro.diagnostic
=================

.. automodule:: figaro.diagnostic

   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
   
      angular_coefficient
      autocorrelation
      compute_angular_coefficients
      compute_autocorrelation
      compute_entropy
      compute_entropy_single_draw
      entropy
      plot_angular_coefficient
   
   

   
   
   

   
   
   



