﻿figaro.cumulative
=================

.. automodule:: figaro.cumulative

   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
   
      fast_cumulative
      fast_log_cumulative
   
   

   
   
   

   
   
   



