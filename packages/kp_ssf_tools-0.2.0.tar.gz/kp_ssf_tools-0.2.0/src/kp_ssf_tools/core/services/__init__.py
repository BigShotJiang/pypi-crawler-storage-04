"""Core services package."""
