"""Entropy analysis package."""
