from .object import Object, ParseResult
from .string import String
from .word import Word
# from .Number import Number
# from .TimeInterval import TimeInterval
# from .Time import Time
