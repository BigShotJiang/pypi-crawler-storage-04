# S.T.A.R.K.

**Speech and Text Algorithmic Recognition Kit**

Modern, advanced, and fast framework for creating natural language (especially voice) interfaces. Like [FastAPI](https://fastapi.tiangolo.com/), but with speech instead of http. 

Check [docs](https://stark.markparker.me/) for more information.
