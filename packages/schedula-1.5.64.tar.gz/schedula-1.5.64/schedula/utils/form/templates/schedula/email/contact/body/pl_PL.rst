
Drogi/a *{{ data.name | safe }}*,

Dziękujemy za kontakt z nami. {{ created | safe }} wysłałeś/aś następującą wiadomość:

**{{ data.message | safe }}**

Jeden z naszych konsultantów skontaktuje się z Tobą tak szybko, jak to możliwe.

Z poważaniem,

*Zespół*
