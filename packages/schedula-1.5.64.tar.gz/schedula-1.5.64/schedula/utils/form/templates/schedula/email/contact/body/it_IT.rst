
Caro/a *{{ data.name | safe }}*,

Grazie per averci contattato. Il {{ created | safe }} ci hai inviato il seguente messaggio:

**{{ data.message | safe }}**

Uno dei nostri consulenti ti contatterà il prima possibile.

Cordiali saluti,

*Team*
