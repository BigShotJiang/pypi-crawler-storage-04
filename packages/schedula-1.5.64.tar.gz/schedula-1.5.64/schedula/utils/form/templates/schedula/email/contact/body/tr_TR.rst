
Sayın *{{ data.name | safe }}*,

Bizimle iletişime geçtiğiniz için teşekkür ederiz. {{ created | safe }} tarihinde aşağıdaki mesajı gönderdiniz:

**{{ data.message | safe }}**

Danışmanlarımızdan biri en kısa sürede sizinle iletişime geçecektir.

Saygılarımızla,

*Ekip*
