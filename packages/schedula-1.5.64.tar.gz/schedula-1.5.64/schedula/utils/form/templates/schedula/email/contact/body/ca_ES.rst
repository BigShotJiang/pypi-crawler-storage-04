
Benvolgut/Benvolguda *{{ data.name | safe }}*,

Gràcies per contactar amb nosaltres. El {{ created | safe }} ens vas enviar el següent missatge:

**{{ data.message | safe }}**

Un dels nostres consultors es posarà en contacte amb tu el més aviat possible.

Cordialment,

*Equip*
