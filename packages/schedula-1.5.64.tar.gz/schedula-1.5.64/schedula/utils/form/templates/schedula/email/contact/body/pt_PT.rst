
Caro/Cara *{{ data.name | safe }}*,

Obrigado/a por nos contactar. No dia {{ created | safe }} enviou a seguinte mensagem:

**{{ data.message | safe }}**

Um dos nossos consultores entrará em contacto consigo o mais breve possível.

Atentamente,

*Equipe*
