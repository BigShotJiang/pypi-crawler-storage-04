import components from './components'
import domains from './domains'

export default {components, domains}