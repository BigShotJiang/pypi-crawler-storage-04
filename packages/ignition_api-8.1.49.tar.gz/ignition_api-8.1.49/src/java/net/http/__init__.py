__all__ = ["HttpClient", "HttpRequest", "HttpResponse"]

from java.lang import Object


class HttpResponse(object):
    pass


class HttpClient(Object):
    pass


class HttpRequest(Object):
    pass
