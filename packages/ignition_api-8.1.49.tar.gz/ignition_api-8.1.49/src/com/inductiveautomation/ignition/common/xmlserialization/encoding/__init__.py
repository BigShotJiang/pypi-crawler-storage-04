__all__ = ["AttributeEncoder"]


class AttributeEncoder(object):
    def getCodecType(self):
        # type: () -> int
        raise NotImplementedError
