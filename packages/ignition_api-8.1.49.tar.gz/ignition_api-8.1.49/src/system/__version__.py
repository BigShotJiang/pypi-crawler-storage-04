"""Package information."""

__version__ = "8.1.49"
__build__ = "2025081208"
