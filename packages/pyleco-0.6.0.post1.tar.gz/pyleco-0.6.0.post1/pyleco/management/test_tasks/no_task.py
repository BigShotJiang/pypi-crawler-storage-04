"""
Task which can be imported, but not started as method `task` is missing.
"""
