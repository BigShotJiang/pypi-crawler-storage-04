# AUTHORS:
#   - Pierre Lairez (2019): initial implementation

precision = 2000

nice_paths = True

unsafe_cyclic_decomposition = True

fail_fast = False



