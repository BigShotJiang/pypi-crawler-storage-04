# Copyright 2022 Zurich Instruments AG
# SPDX-License-Identifier: Apache-2.0

# This module and the transmon module are both deprecated.

from laboneq.dsl.quantum.transmon import Transmon, TransmonParameters

Qubit = Transmon
QubitParameters = TransmonParameters
