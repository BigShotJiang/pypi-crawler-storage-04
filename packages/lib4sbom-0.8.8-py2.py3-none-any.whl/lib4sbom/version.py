# Copyright (C) 2025 Anthony Harrison
# SPDX-License-Identifier: Apache-2.0

VERSION: str = "0.8.8"
