# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.5.2](https://github.com/toolCHAINZ/crackers/compare/crackers-v0.5.1...crackers-v0.5.2) - 2025-09-03

### Other

- bump z3 and jingle ([#64](https://github.com/toolCHAINZ/crackers/pull/64))

## [0.5.1](https://github.com/toolCHAINZ/crackers/compare/crackers-v0.5.0...crackers-v0.5.1) - 2025-08-22

### Fixed

- threading changes ([#62](https://github.com/toolCHAINZ/crackers/pull/62))

## [0.5.0](https://github.com/toolCHAINZ/crackers/compare/crackers-v0.4.0...crackers-v0.5.0) - 2025-08-21

### Other

- bump z3 ([#59](https://github.com/toolCHAINZ/crackers/pull/59))

## [0.4.0](https://github.com/toolCHAINZ/crackers/compare/crackers-v0.3.0...crackers-v0.4.0) - 2025-08-14

### Other

- bump deps ([#57](https://github.com/toolCHAINZ/crackers/pull/57))

## [0.3.0](https://github.com/toolCHAINZ/crackers/compare/crackers-v0.2.1...crackers-v0.3.0) - 2025-08-06

### Other

- [**breaking**] bump jingle and z3 ([#55](https://github.com/toolCHAINZ/crackers/pull/55))

## [0.2.1](https://github.com/toolCHAINZ/crackers/compare/crackers-v0.2.0...crackers-v0.2.1) - 2025-07-16

### Fixed

- remove branch and call from reference program blacklist ([#53](https://github.com/toolCHAINZ/crackers/pull/53))

## [0.2.0](https://github.com/toolCHAINZ/crackers/compare/crackers-v0.1.3...crackers-v0.2.0) - 2025-07-16

### Fixed

- verify reference program operations against blacklist ([#51](https://github.com/toolCHAINZ/crackers/pull/51))

## [0.1.3](https://github.com/toolCHAINZ/crackers/compare/crackers-v0.1.2...crackers-v0.1.3) - 2025-07-16

### Other

- bump jingle and update readme ([#49](https://github.com/toolCHAINZ/crackers/pull/49))

## [0.1.2](https://github.com/toolCHAINZ/crackers/compare/crackers-v0.1.1...crackers-v0.1.2) - 2025-07-11

### Added

- use release-plz ([#45](https://github.com/toolCHAINZ/crackers/pull/45))

### Other

- build issues ([#47](https://github.com/toolCHAINZ/crackers/pull/47))
- Reference program refactor ([#44](https://github.com/toolCHAINZ/crackers/pull/44))
- Add logo ([#43](https://github.com/toolCHAINZ/crackers/pull/43))
- Found some missing #[cfg] guards. Oops! ([#42](https://github.com/toolCHAINZ/crackers/pull/42))
- Update refs ([#41](https://github.com/toolCHAINZ/crackers/pull/41))
- Add Python Type Annotations ([#34](https://github.com/toolCHAINZ/crackers/pull/34))
- Add link to usenix ([#32](https://github.com/toolCHAINZ/crackers/pull/32))
- Update README.md ([#31](https://github.com/toolCHAINZ/crackers/pull/31))
- Update README.md ([#30](https://github.com/toolCHAINZ/crackers/pull/30))
- Enhanced Python Constraint Support ([#27](https://github.com/toolCHAINZ/crackers/pull/27))
- Rust 2024 Edition ([#26](https://github.com/toolCHAINZ/crackers/pull/26))
- pyo3 bindings ([#21](https://github.com/toolCHAINZ/crackers/pull/21))
- Readme update
- Add readme
- Reorganize
- Gadget builder tweaks
- Blacklist
- Stuff
- Some library changes to allow more aggressive clause generation
- Merge branch 'main' of github-toolchainz-ssh:toolCHAINZ/crackers
- More invariant stuff
- Pointer invariant stuff
- Cargo fmt
- Playing with constraints
- Precondition and postcondition stuff
- More changes
- More builder stuff
- Tweaks
- Some config stuff
- Remove unneeded pubs
- Make outer layer use a trait and reorganize a bit
- Rename file
- Further penalize length
- Add optimization problem, change how we propagate conflicts
- Add better display for conflicts, make memory branching constraints more aggressive
- Start of better result display
- Account for instruction branching semantics
- Cover/overlap/refine stuff 2
- Cover/overlap/refine stuff
- Move slot assignments to its own file
- Stuff
- Fmt
- Some tweaks
- Rename isolated
- Stuff
- Lint fixes
- fmt
- Use tailored solvers, allow timeouts
- Make things converge slower
- Make things converge faster
- Added some output
- Some tracing
- Some cleanup
- Add stuff
- Add pairwise constraints
- Some sat/theory stuff
- Added some more SAT stuff, some Theory stuff, and a test or two
- Add test
- SAT problem stuff
- Shuffling some stuff around
