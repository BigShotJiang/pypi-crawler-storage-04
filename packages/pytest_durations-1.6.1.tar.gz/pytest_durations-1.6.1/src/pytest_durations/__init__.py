"""Pytest plugin package to measure fixture and test durations."""
from pytest_durations.options import pytest_addoption, pytest_configure  # noqa: F401

__version__ = "1.6.1"
