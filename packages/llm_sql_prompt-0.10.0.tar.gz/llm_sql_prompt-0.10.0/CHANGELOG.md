# [0.10.0](https://github.com/iloveitaly/sql-ai-prompt-generator/compare/v0.9.0...v0.10.0) (2025-08-29)


### Features

* add --version CLI option to output package version ([#31](https://github.com/iloveitaly/sql-ai-prompt-generator/issues/31)) ([703346e](https://github.com/iloveitaly/sql-ai-prompt-generator/commit/703346e96d1985f03d75cb08a5c0e3a61c3cfe79))



# [0.9.0](https://github.com/iloveitaly/sql-ai-prompt-generator/compare/v0.8.0...v0.9.0) (2025-08-21)


### Features

* enhanced schema description to include installed PostgreSQL extensions and server version. ([ad86e31](https://github.com/iloveitaly/sql-ai-prompt-generator/commit/ad86e314316249c33ce92e7b4ca1cbbe0f0578f7))



# [0.8.0](https://github.com/iloveitaly/sql-ai-prompt-generator/compare/v0.7.0...v0.8.0) (2025-04-04)


### Features

* add --no-data flag to exclude sample data in prompts ([a54e0df](https://github.com/iloveitaly/sql-ai-prompt-generator/commit/a54e0df315cad2fa1f41957cf644b0d809019d9a))



# [0.7.0](https://github.com/iloveitaly/sql-ai-prompt-generator/compare/v0.6.0...v0.7.0) (2025-03-03)


### Features

* add MySQL support to SQL prompt generation tool ([2889b76](https://github.com/iloveitaly/sql-ai-prompt-generator/commit/2889b76779005bdd2895d51f29db11aed0cbd0bd))



# [0.6.0](https://github.com/iloveitaly/sql-ai-prompt-generator/compare/v0.5.2...v0.6.0) (2025-02-10)


### Features

* enhance schema description with foreign key info ([e35891b](https://github.com/iloveitaly/sql-ai-prompt-generator/commit/e35891b0063e4f8da41e76321fe69997fd78f8a0))
* include table and column comments in schema output ([5052f09](https://github.com/iloveitaly/sql-ai-prompt-generator/commit/5052f09cee567ab34112ff3fb135089eeeba2505))



