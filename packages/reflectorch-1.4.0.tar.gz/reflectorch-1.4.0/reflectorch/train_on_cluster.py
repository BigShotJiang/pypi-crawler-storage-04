from reflectorch.runs import run_train_on_cluster

if __name__ == '__main__':
    run_train_on_cluster()
