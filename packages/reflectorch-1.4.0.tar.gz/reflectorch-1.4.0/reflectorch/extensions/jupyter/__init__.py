from .callbacks import JPlotLoss


__all__ = [
    'JPlotLoss',
]
