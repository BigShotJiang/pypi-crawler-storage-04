from reflectorch.runs import run_train

if __name__ == '__main__':
    run_train()
