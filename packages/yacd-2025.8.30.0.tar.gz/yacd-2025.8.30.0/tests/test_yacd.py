#!/usr/bin/env --split-string=python -m pytest --verbose

import pytest

from yacd import *

"""Here be dragons"""
