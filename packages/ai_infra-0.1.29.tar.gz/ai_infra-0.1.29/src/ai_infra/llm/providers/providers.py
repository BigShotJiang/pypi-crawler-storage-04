class Providers:
    xai = "xai"
    google_genai = "google_genai"
    openai = "openai"
    anthropic = "anthropic"
    deepseek = "deepseek"
    mistralai = "mistralai"
