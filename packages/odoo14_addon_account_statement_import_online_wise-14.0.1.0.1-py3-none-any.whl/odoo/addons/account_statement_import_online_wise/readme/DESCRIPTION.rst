This module provides online bank statements from
`Wise.com <https://wise.com/>`__.
(formely `TransferWise.com <https://transferwise.com/>`__).
