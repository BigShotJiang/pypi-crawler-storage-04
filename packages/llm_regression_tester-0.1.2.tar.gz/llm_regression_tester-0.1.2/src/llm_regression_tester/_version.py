"""Version information for LLM Regression Tester."""

__version__ = "0.1.2"
__version_info__ = tuple(map(int, __version__.split(".")))
