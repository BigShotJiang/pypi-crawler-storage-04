# Q-CTRL MkDocs Theme

Q-CTRL MkDocs Theme is a Q-CTRL theme for making project documentation using MkDocs.

## Installation and usage

See the [documentation](https://qctrl.github.io/mkdocs-theme) for detailed installation and usage instructions.
