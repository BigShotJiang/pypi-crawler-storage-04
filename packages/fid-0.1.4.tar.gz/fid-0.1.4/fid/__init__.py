from rich.console import Console

from .config import Config

__version__ = "0.1.4"


console = Console()
config = Config()
