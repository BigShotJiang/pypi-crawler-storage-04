SALUTE_SPEECH_HTTP_TIMEOUT = (5, 30)
# HTTP Connection timeouts. 5 seconds connect timeout. 30 seconds read timeout
