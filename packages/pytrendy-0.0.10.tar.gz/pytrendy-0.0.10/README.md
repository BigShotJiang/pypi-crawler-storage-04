### PyTrendy 📈 (WIP)

This project aims to provide a robust and automated solution for identifying and analyzing trends. This will be especially useful for industry applications such as treatment period selection for quasi-experimental analysis using Causal Impact.