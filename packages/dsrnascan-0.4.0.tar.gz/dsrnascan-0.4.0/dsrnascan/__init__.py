# dsRNAscan package
from .dsRNAscan import main

__version__ = '0.4.0'
__all__ = ['main']