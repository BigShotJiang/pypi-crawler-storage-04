"""Headless agent integrations for Omnara."""
