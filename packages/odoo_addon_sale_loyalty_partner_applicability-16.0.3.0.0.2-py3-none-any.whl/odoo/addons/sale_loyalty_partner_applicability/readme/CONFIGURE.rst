To configure the partner based promotion filter:

Go to *Sales > Products > Discount & Loyalty* and select or create a new one.
In conditional rules set the condition based on customers.

In promotions that generate coupons for the next sale, we can allow coupon sharing
between members of the same commercial entity.
To allow this, go to *Settings > Sales > Pricing* and check the option "Allow coupon sharing".
