Go to a sales order and apply the promotion accordingly. If the sales order meets the
requirements set in the partner based filter the promotion will be applied to that order.
