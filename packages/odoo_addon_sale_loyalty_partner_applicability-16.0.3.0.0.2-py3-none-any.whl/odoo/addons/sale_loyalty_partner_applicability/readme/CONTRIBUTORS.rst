* `Tecnativa <https://www.tecnativa.com>`_:

  * Pilar Vargas

* `ACSONE SA/NV <https://acsone.eu>`_:

  * Laurent Mignon <laurent.mignon@acsone.eu>