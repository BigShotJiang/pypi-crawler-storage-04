This module extends the loyalty_partner_applicability functionality. When this filter
is defined, the promotion rule will only be applied to customers who meet the specified
conditions in the filter.
The coupons generated in a sales order for a specific member promotion can be shared
between members of the same trading entity.
