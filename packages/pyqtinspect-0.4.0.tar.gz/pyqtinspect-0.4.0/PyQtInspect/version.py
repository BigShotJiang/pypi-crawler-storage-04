PQI_VERSION = '0.4.0'
PQI_NAME = 'PyQtInspect'
