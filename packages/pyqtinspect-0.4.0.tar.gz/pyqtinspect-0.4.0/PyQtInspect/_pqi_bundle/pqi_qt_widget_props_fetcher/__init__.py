from ._fetcher import WidgetPropertiesGetter
