from pybotx_smartapp_rpc.typing import RPCArgsBaseModel


class EmptyArgs(RPCArgsBaseModel):
    pass  # noqa: WPS420, WPS604
