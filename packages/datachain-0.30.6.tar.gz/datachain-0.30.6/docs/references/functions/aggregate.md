# Aggregate Functions

Aggregate functions perform calculations on sets of values and return a single result.

::: datachain.func.aggregate
