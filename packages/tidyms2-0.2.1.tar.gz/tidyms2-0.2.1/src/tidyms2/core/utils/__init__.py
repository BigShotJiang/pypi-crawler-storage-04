"""General purpose utilities."""
