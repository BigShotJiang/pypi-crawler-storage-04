from skylos.analyzer import analyze

__version__ = "2.1.2"

def debug_test():
    return "debug-ok"

__all__ = ["analyze", "debug_test", "__version__"]