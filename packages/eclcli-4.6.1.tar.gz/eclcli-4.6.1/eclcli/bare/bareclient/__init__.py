SERVICE_TYPE = 'baremetal-server'
__version__ = '2'
