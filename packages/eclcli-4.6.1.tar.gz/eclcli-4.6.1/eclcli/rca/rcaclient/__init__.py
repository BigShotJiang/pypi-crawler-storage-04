SERVICE_TYPE = 'rca'
# __version__ = pbr.version.VersionInfo('python-icgwclient').version_string()
