SERVICE_TYPE = 'network'
__version__ = '2.0'
