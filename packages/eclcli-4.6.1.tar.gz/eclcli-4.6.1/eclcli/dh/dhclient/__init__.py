SERVICE_TYPE = 'dedicated-hypervisor'
# __version__ = pbr.version.VersionInfo('dhclient').version_string()
