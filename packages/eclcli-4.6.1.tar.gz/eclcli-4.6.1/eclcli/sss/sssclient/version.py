import pbr.version

__version__ = pbr.version.VersionInfo('python-sssclient').version_string()
