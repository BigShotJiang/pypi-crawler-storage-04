"""Camera calibration tools for the monocular path prediction pipeline."""
