"""Camera interface for recording and taking pictures using OpenCV."""
