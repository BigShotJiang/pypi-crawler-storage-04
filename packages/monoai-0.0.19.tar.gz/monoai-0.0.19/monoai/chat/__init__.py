"""
Chat module is responsible for handling the chat interface and messages history.
"""

from monoai.chat.chat import Chat

__all__ = ["Chat"]