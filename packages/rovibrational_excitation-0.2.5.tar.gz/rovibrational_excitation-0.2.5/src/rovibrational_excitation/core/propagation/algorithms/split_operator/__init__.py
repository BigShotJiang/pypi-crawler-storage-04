"""
Split-operator propagation algorithms.
"""

from .schrodinger import splitop_schrodinger

__all__ = ["splitop_schrodinger"] 