"""High-level API: LinMolDipoleMatrix"""

from .cache import LinMolDipoleMatrix  # noqa: F401

__all__ = ["LinMolDipoleMatrix"]
