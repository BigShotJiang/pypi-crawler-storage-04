# TaskQueue

A Task Queue Wrapper for Dekoruma Backend

## Description

TaskQueue is a Python package that provides a  wrapper around Celery for task queue management. It includes automatic queue setup, Dead Letter Queue (DLQ) routing, and dynamic task execution capabilities.


## Deploy
- Push changes to main
- Create new TAG with version name (i.e 0.1.3)
- Check status on the Actions page on Github
