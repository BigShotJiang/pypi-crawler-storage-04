__all__ = [
    'successful_response',
    'coord',
    'main',
    'wind',
    'clouds',
    'rain',
    'snow',
    'sys',
    'weather',
]
