Tests in this directory are basic tests that ensure the core functionality of Marvin is working. They do *not* use any external LLM models.

To run these tests, use the following command:

```bash
pytest tests/basic
```
