# Internal utilities for the slackbot
