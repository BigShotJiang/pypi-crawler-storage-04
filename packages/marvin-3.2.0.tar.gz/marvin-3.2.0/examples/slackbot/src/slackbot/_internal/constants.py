WORKSPACE_TO_CHANNEL_ID = {
    "TAN3D79AL": "C046WGGKF4P",  # Prefect -> #ask-marvin-tests
    "T03S63K44P6": "C03S3HZ2X3M",  # Stoat LLC -> #testing-slackbots
}
