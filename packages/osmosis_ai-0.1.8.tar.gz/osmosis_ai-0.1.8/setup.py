from setuptools import setup

# This setup.py is kept for backward compatibility
# All configuration now lives in pyproject.toml

setup()
