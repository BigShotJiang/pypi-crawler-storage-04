"""DVD tools and parsing."""

SECTOR_SIZE = 2048
