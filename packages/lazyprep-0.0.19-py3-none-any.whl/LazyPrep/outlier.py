import pandas as pd
import numpy as np
from typing import Optional, Dict, Any

from .Utilities.logger import setup_logger

logger = setup_logger(log_file='pipeline.log', logger_name=__name__)

class Outlier:
    """
    A utility for detecting and handling outliers in pandas DataFrames using various
    statistical methods.
    """

    def __init__(self,
                 metadata: Optional[Dict[str, Any]] = None,
                 default_strategy: str = 'iqr',
                 custom_strategies: Optional[Dict[str, str]] = None):
        """
        Initializes the Outlier handler.

        Args:
            metadata (Optional[Dict[str, Any]]): Metadata with column information.
            default_strategy (str): Default outlier detection method.
            custom_strategies (Optional[Dict[str, str]]): Per-column strategy overrides.
        """
        self.metadata = metadata if metadata else {}
        self.default_strategy = default_strategy
        self.custom_strategies = custom_strategies if custom_strategies else {}

        self.methods = {
            'iqr': self._iqr,
            'z_score': self._z_score,
            'modified_z_score': self._modified_z_score,
            'percentile': self._percentile,
            'mad': self._mad,
            'log_iqr': self._log_iqr
        }

    def _get_outliers(self, df: pd.DataFrame, col: str, strategy: str) -> pd.Index:
        """Factory method to get outlier indices based on the chosen strategy."""
        if strategy in self.methods:
            return self.methods[strategy](df[col])
        logger.warning(f"Unknown outlier strategy '{strategy}' for column '{col}'. Skipping.")
        return pd.Index([])

    # --- Outlier Detection Strategies ---
    def _iqr(self, series: pd.Series) -> pd.Index:
        q1 = series.quantile(0.25)
        q3 = series.quantile(0.75)
        iqr_val = q3 - q1
        lower_bound = q1 - 1.5 * iqr_val
        upper_bound = q3 + 1.5 * iqr_val
        return series[(series < lower_bound) | (series > upper_bound)].index

    def _z_score(self, series: pd.Series) -> pd.Index:
        z_scores = np.abs((series - series.mean()) / series.std())
        return series[z_scores > 3].index

    def _modified_z_score(self, series: pd.Series) -> pd.Index:
        median = series.median()
        mad = np.median(np.abs(series - median))
        if mad == 0: return pd.Index([])
        modified_z_scores = 0.6745 * np.abs(series - median) / mad
        return series[modified_z_scores > 3.5].index

    def _percentile(self, series: pd.Series) -> pd.Index:
        lower = series.quantile(0.01)
        upper = series.quantile(0.99)
        return series[(series < lower) | (series > upper)].index

    def _mad(self, series: pd.Series) -> pd.Index:
        median = series.median()
        mad = np.median(np.abs(series - median))
        lower_bound = median - 3 * mad
        upper_bound = median + 3 * mad
        return series[(series < lower_bound) | (series > upper_bound)].index

    def _log_iqr(self, series: pd.Series) -> pd.Index:
        if (series <= 0).any():
            logger.warning(f"Column '{series.name}' contains non-positive values. Log-IQR cannot be applied.")
            return pd.Index([])
        log_series = np.log(series)
        q1 = log_series.quantile(0.25)
        q3 = log_series.quantile(0.75)
        iqr_val = q3 - q1
        lower_bound = np.exp(q1 - 1.5 * iqr_val)
        upper_bound = np.exp(q3 + 1.5 * iqr_val)
        return series[(series < lower_bound) | (series > upper_bound)].index

    def transform(self, df: pd.DataFrame, action: str = 'drop') -> pd.DataFrame:
        """
        Detects and handles outliers in the DataFrame.

        Args:
            df (pd.DataFrame): The input DataFrame.
            action (str): The action to take on outliers ('drop' or 'cap').

        Returns:
            pd.DataFrame: The DataFrame with outliers handled.
        """
        logger.info(f"--- Starting Outlier Detection (Action: {action}) ---")
        initial_rows = len(df)
        
        columns_info = self.metadata.get('columns', {})
        numeric_cols = [col for col, details in columns_info.items() if details.get('dtype') == 'numeric']

        for col in numeric_cols:
            if col == self.metadata.get('target_column'):
                logger.info(f"Skipping target column '{col}'")
                continue

            strategy = self.custom_strategies.get(col, columns_info.get(col, {}).get('outlier_detection', self.default_strategy)).lower().replace('-', '_')
            
            outlier_indices = self._get_outliers(df, col, strategy)
            
            if not outlier_indices.empty:
                logger.info(f"Found {len(outlier_indices)} outliers in '{col}' using {strategy} strategy.")
                if action == 'drop':
                    df = df.drop(outlier_indices)
                elif action == 'cap':
                    # Capping logic can be added here if needed
                    pass
        
        rows_dropped = initial_rows - len(df)
        if rows_dropped > 0:
            logger.info(f"Dropped {rows_dropped} rows containing outliers.")
            
        logger.info("--- Outlier Detection Finished ---")
        return df
