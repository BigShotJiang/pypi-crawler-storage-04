import pandas as pd
from typing import List, Optional, Dict, Any
from .Utilities.logger import setup_logger

logger = setup_logger(log_file='pipeline.log', logger_name=__name__)

class DateProcessor:
    """
    Processes datetime columns in a DataFrame to extract useful features.
    """

    def __init__(self, metadata: Dict[str, Any], extract_features: Optional[List[str]] = None):
        """
        Initializes the DateProcessor.

        Args:
            metadata (Dict[str, Any]): Metadata dictionary containing column information.
            extract_features (Optional[List[str]]): A list of features to extract.
                e.g., ['year', 'month', 'day', 'hour', 'minute', 'second', 'dayofweek', 'quarter'].
                If None, a default set of features will be extracted based on the column type.
        """
        self.metadata = metadata
        self.extract_features = extract_features

    def _get_datetime_columns(self) -> Dict[str, List[str]]:
        """Identifies datetime-related columns from metadata."""
        datetime_cols = {'date': [], 'time': [], 'datetime': []}
        if 'columns' in self.metadata:
            for col, details in self.metadata['columns'].items():
                dtype = details.get('dtype')
                if dtype in datetime_cols:
                    datetime_cols[dtype].append(col)
        return datetime_cols

    def _extract_default_features(self, series: pd.Series, dtype: str) -> pd.DataFrame:
        """Extracts a default set of features based on the datetime type."""
        features = pd.DataFrame(index=series.index)
        if dtype == 'datetime':
            features[f'{series.name}_year'] = series.dt.year
            features[f'{series.name}_month'] = series.dt.month
            features[f'{series.name}_day'] = series.dt.day
            features[f'{series.name}_hour'] = series.dt.hour
            features[f'{series.name}_minute'] = series.dt.minute
            features[f'{series.name}_dayofweek'] = series.dt.dayofweek
        elif dtype == 'date':
            features[f'{series.name}_year'] = series.dt.year
            features[f'{series.name}_month'] = series.dt.month
            features[f'{series.name}_day'] = series.dt.day
            features[f'{series.name}_dayofweek'] = series.dt.dayofweek
        elif dtype == 'time':
            features[f'{series.name}_hour'] = series.dt.hour
            features[f'{series.name}_minute'] = series.dt.minute
            features[f'{series.name}_second'] = series.dt.second
        return features

    def _extract_custom_features(self, series: pd.Series) -> pd.DataFrame:
        """Extracts a user-defined list of features."""
        features = pd.DataFrame(index=series.index)
        if self.extract_features:
            for feature in self.extract_features:
                try:
                    if hasattr(series.dt, feature):
                        features[f'{series.name}_{feature}'] = getattr(series.dt, feature)
                    else:
                        logger.warning(f"Feature '{feature}' is not a valid datetime attribute and will be skipped.")
                except Exception as e:
                    logger.error(f"Could not extract feature '{feature}' from {series.name}: {e}")
        return features

    def transform(self, df: pd.DataFrame, drop_original: bool = True) -> pd.DataFrame:
        """
        Processes the DataFrame to extract date and time features.

        Args:
            df (pd.DataFrame): The input DataFrame.
            drop_original (bool): If True, drops the original datetime columns after feature extraction.

        Returns:
            pd.DataFrame: The DataFrame with new datetime features.
        """
        logger.info("--- Starting DateTime Processing ---")
        datetime_cols = self._get_datetime_columns()

        for dtype, cols in datetime_cols.items():
            for col_name in cols:
                if col_name in df.columns:
                    logger.info(f"Processing {dtype} column: {col_name}")
                    
                    # Convert to datetime, coercing errors to NaT
                    df[col_name] = pd.to_datetime(df[col_name], errors='coerce')
                    
                    # Filter out rows where conversion failed (resulted in NaT)
                    initial_rows = len(df)
                    df = df.dropna(subset=[col_name])
                    if len(df) < initial_rows:
                        logger.warning(f"Found {initial_rows - len(df)} values in '{col_name}' that could not be converted to datetime. These rows have been dropped.")

                    series = df[col_name].copy()

                    if self.extract_features:
                        new_features = self._extract_custom_features(series)
                    else:
                        new_features = self._extract_default_features(series, dtype)
                    
                    df = pd.concat([df, new_features], axis=1)
                    
                    if drop_original:
                        df = df.drop(columns=[col_name])
                        logger.info(f"Dropped original column: {col_name}")

        logger.info("--- DateTime Processing Finished ---")
        return df
