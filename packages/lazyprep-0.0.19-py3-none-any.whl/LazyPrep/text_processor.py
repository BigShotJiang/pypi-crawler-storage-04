import re
import string
import pandas as pd
import numpy as np
from typing import List, Optional, Dict, Any
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
import nltk

from .Utilities.logger import setup_logger

logger = setup_logger(log_file='pipeline.log', logger_name=__name__)

class TextProcessor:
    """
    A text processing utility that cleans, tokenizes, and lemmatizes text data in a DataFrame.
    """

    def __init__(self,
                 metadata: Optional[Dict[str, Any]] = None,
                 text_columns: Optional[List[str]] = None,
                 lemmatize: bool = True,
                 remove_stopwords: bool = True):
        """
        Initializes the TextProcessor.

        Args:
            metadata (Optional[Dict[str, Any]]): Metadata with column information.
            text_columns (Optional[List[str]]): A list of columns to be processed as text.
            lemmatize (bool): Whether to apply lemmatization.
            remove_stopwords (bool): Whether to remove stopwords.
        """
        self.metadata = metadata if metadata else {}
        self.text_columns = text_columns if text_columns else self._infer_text_columns()
        self.lemmatize = lemmatize
        self.remove_stopwords = remove_stopwords

        self._download_nltk_resources()
        self.lemmatizer = WordNetLemmatizer()
        self.stop_words = set(stopwords.words('english'))

    def _download_nltk_resources(self):
        """Downloads necessary NLTK resources if they are not already present."""
        resources = ['punkt', 'stopwords', 'wordnet']
        for resource in resources:
            try:
                nltk.data.find(f'tokenizers/{resource}')
            except LookupError:
                logger.info(f"Downloading NLTK resource: {resource}")
                nltk.download(resource, quiet=True)

    def _infer_text_columns(self) -> List[str]:
        """Infers which columns are likely text-based from metadata."""
        text_cols = []
        if 'columns' in self.metadata:
            for col, details in self.metadata['columns'].items():
                # Infer based on dtype (object/categorical) and high cardinality
                if details.get('dtype') in ['categorical', 'object'] and details.get('unique_values', 0) > 50:
                    text_cols.append(col)
        return text_cols

    def _clean_and_tokenize(self, text: str) -> List[str]:
        """Performs cleaning and tokenization of a single text string."""
        if not isinstance(text, str):
            return []
        
        # Lowercase, remove punctuation and numbers
        text = text.lower()
        text = re.sub(f'[{re.escape(string.punctuation)}]', '', text)
        text = re.sub(r'\d+', '', text)
        
        tokens = word_tokenize(text)
        
        if self.remove_stopwords:
            tokens = [token for token in tokens if token not in self.stop_words]
            
        if self.lemmatize:
            tokens = [self.lemmatizer.lemmatize(token) for token in tokens]
            
        return tokens

    def transform(self, df: pd.DataFrame, output_format: str = 'tokens') -> pd.DataFrame:
        """
        Applies text processing to the specified columns in the DataFrame.

        Args:
            df (pd.DataFrame): The input DataFrame.
            output_format (str): The format for the processed text ('tokens' or 'string').

        Returns:
            pd.DataFrame: The DataFrame with processed text columns.
        """
        logger.info("--- Starting Text Processing ---")
        
        for col in self.text_columns:
            if col in df.columns:
                logger.info(f"Processing text column: {col}")
                
                # Apply the processing function
                processed_series = df[col].apply(self._clean_and_tokenize)
                
                if output_format == 'string':
                    df[f'{col}_processed'] = processed_series.apply(lambda tokens: ' '.join(tokens))
                else: # Default to tokens
                    df[f'{col}_processed'] = processed_series
                
                # Update metadata
                if 'columns' in self.metadata and col in self.metadata['columns']:
                    self.metadata['columns'][col]['text_processing_applied'] = True
                    self.metadata['columns'][f'{col}_processed'] = {'dtype': 'processed_text'}
            else:
                logger.warning(f"Text column '{col}' not found in DataFrame. Skipping.")

        logger.info("--- Text Processing Finished ---")
        return df
