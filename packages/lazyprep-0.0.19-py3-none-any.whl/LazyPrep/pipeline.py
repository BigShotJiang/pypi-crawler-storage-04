import os
import json
import pandas as pd
from typing import Dict, List, Optional, Any, Union

from .loader import Loader
from .cleaner import Cleaner
from .analyzer import Analyzer
from .outlier import Outlier
from .imputer import Imputer
from .text_processor import TextProcessor
from .date_processor import DateProcessor
from .Utilities.logger import setup_logger

logger = setup_logger(log_file='pipeline.log', logger_name=__name__)

class PreprocessingPipeline:
    """
    An end-to-end data preprocessing pipeline that automates loading, cleaning,
    analyzing, and transforming data.
    """

    def __init__(self, file_path: str, target_column: Optional[str] = None, config: Optional[Dict[str, Any]] = None):
        """
        Initializes the pipeline.

        Args:
            file_path (str): Path to the data file.
            target_column (Optional[str]): Name of the target variable.
            config (Optional[Dict[str, Any]]): A configuration dictionary for pipeline components.
        """
        self.file_path = file_path
        self.target_column = target_column
        self.config = config if config else {}
        self.metadata: Dict[str, Any] = {'target_column': target_column}
        self.pipeline: List[Any] = []

        self._default_pipeline()

    def add_cleaner(self, column_threshold: float = 0.80, row_threshold: float = 0.80) -> None:
        """
        Add a cleaner component to the pipeline.

        Args:
            column_threshold: Threshold for dropping columns with too many missing values
            row_threshold: Threshold for dropping rows with too many missing values
        """
        self.pipeline.append(Cleaner(self.metadata, column_threshold=column_threshold, row_threshold=row_threshold))
        logger.info(f"Cleaner component added with column_threshold: {column_threshold}, row_threshold: {row_threshold}")

    def add_outlier_detection(self, default_strategy: str = 'iqr', custom_strategies: Optional[Dict[str, str]] = None) -> None:
        """
        Add an outlier detection component to the pipeline.

        Args:
            default_strategy: Default outlier detection method.
            custom_strategies: Per-column strategy overrides.
        """
        # Ensure custom_strategies is a dict if None is passed
        if custom_strategies is None:
            custom_strategies = {}
        self.pipeline.append(Outlier(metadata=self.metadata, default_strategy=default_strategy, custom_strategies=custom_strategies))
        if custom_strategies or default_strategy:
            logger.info(f"Outlier detection component added with default_strategy: '{default_strategy}' and custom_strategies: {custom_strategies}.")

    def add_imputer(self, numeric_strategy: str = 'mean',
                   categorical_strategy: str = 'mode',
                   custom_strategies: Optional[Dict[str, str]] = None) -> None:
        """
        Add an imputer component to the pipeline.

        Args:
            numeric_strategy: Default strategy for numeric columns.
            categorical_strategy: Default strategy for categorical columns.
            custom_strategies: Per-column strategy overrides.
        """
        # Ensure custom_strategies is a dict if None is passed
        if custom_strategies is None:
            custom_strategies = {}
        self.pipeline.append(Imputer(
            metadata=self.metadata,
            numeric_strategy=numeric_strategy,
            categorical_strategy=categorical_strategy,
            custom_strategies=custom_strategies
        ))
        logger.info(f"Imputer component added with numeric_strategy: '{numeric_strategy}', "
                   f"categorical_strategy: '{categorical_strategy}', custom_strategies: {custom_strategies}.")

    def add_text_processor(self, text_columns: Optional[List[str]] = None, lemmatize: bool = True, remove_stopwords: bool = True) -> None:
        """
        Add a text processor component to the pipeline.

        Args:
            text_columns: A list of columns to be processed as text. If None, text columns will be inferred from metadata.
            lemmatize: Whether to apply lemmatization.
            remove_stopwords: Whether to remove stopwords.
        """
        # Infer text columns from metadata if not provided
        if text_columns is None:
            inferred_text_columns = []
            if 'columns' in self.metadata:
                for col, details in self.metadata['columns'].items():
                    # Infer based on dtype (object/categorical) and high cardinality
                    if details.get('dtype') in ['categorical', 'object'] and details.get('unique_values', 0) > 50:
                        inferred_text_columns.append(col)
            text_columns = inferred_text_columns
            
        self.pipeline.append(TextProcessor(metadata=self.metadata, text_columns=text_columns, lemmatize=lemmatize, remove_stopwords=remove_stopwords))
        logger.info(f"TextProcessor component added with text_columns: {text_columns}, lemmatize: {lemmatize}, remove_stopwords: {remove_stopwords}.")

    def add_component(self, component: Any, **kwargs):
        """
        Add a custom processing step to the pipeline.

        Args:
            component (Any): A class with a `transform` method.
            **kwargs: Initialization parameters for the component.
        """
        kwargs['metadata'] = self.metadata
        self.pipeline.append(component(**kwargs))
        logger.info(f"Added custom step: {component.__class__.__name__}")

    def add_configurations(self, cleaner_config: Dict = {},
                          outlier_config: Dict = {},
                          imputer_config: Dict = {},
                          text_processor_config: Dict = {},
                          date_config: Dict = {}) -> None:
        """
        Add configurations for the components in the pipeline.

        Args:
            cleaner_config: Configuration for the Cleaner component
            outlier_config: Configuration for the Outlier component
            imputer_config: Configuration for the Imputer component
            text_processor_config: Configuration for the TextProcessor component
            date_config: Configuration for date processing
        """
        if cleaner_config:
            self.config['cleaner'] = cleaner_config
        if outlier_config:
            self.config['outlier'] = outlier_config
        if imputer_config:
            self.config['imputer'] = imputer_config
        if text_processor_config:
            self.config['text_processor'] = text_processor_config
        if date_config:
            self.config['date'] = date_config

        logger.info(f"Configurations updated: {self.config}")

        # Rebuild pipeline with new configurations
        self._default_pipeline()

    def _default_pipeline(self):
        """Builds the processing pipeline based on the provided configuration."""
        self.pipeline.append(Loader(self.file_path, self.metadata))
        self.pipeline.append(Analyzer(self.metadata))
        component_map = {
            'cleaner': Cleaner,
            'imputer': Imputer,
            'outlier': Outlier,
            'date_processor': DateProcessor,
            'text_processor': TextProcessor
        }

        for name, component_class in component_map.items():
            if name in self.config:
                params = self.config[name]
                params['metadata'] = self.metadata
                self.pipeline.append(component_class(**params))
                logger.info(f"Added {name} to pipeline with params: {params}")


    def run(self) -> pd.DataFrame:
        """
        Executes the entire preprocessing pipeline.

        Returns:
            pd.DataFrame: The fully preprocessed DataFrame.
        """
        logger.info("--- Starting Preprocessing Pipeline ---")
        df = None
        
        for i, step in enumerate(self.pipeline):
            component_name = step.__class__.__name__
            logger.info(f"--- Running Step {i+1}: {component_name} ---")
            
            try:
                if isinstance(step, Loader):
                    df = step.transform()
                elif df is not None:
                    df = step.transform(df)
                else:
                    logger.error("DataFrame is not loaded. Loader must be the first step.")
                    raise ValueError("DataFrame not loaded.")
                
                logger.info(f"Shape after {component_name}: {df.shape}")

            except Exception as e:
                logger.error(f"Error during step {component_name}: {e}", exc_info=True)
                raise

        logger.info("--- Preprocessing Pipeline Finished ---")
        if df is None:
            raise ValueError("Pipeline execution resulted in a None DataFrame.")
        return df

    def get_metadata(self, as_json: bool = False) -> Union[Dict[str, Any], str]:
        """
        Returns the collected metadata.

        Args:
            as_json (bool): If True, returns metadata as a JSON string.

        Returns:
            Union[Dict[str, Any], str]: The metadata dictionary or JSON string.
        """
        if as_json:
            return json.dumps(self.metadata, indent=4, default=str)
        return self.metadata

    def get_pipeline_steps(self) -> List[str]:
        """Returns the names of the components in the pipeline."""
        return [step.__class__.__name__ for step in self.pipeline]
