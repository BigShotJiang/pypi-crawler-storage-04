import pandas as pd
from typing import Optional, Dict, Any, Set

from .Utilities.logger import setup_logger

logger = setup_logger(log_file='pipeline.log', logger_name=__name__)

class Cleaner:
    """
    A class for cleaning and preprocessing pandas DataFrames.
    Provides methods to handle missing values, remove duplicates,
    and prepare data for analysis or modeling.
    """
    def __init__(
        self,
        metadata: Optional[Dict[str, Any]] = None,
        target_column: Optional[str] = None,
        column_threshold: float = 0.7,
        row_threshold: float = 0.7,
        drop_null: bool = False
    ):
        """
        Initialize the Cleaner with optional metadata.
        """
        self.metadata = metadata if metadata is not None else {}
        if 'cleaning_stats' not in self.metadata:
            self.metadata['cleaning_stats'] = {
                'columns_dropped': set(),
                'rows_dropped': 0,
                'duplicates_removed': 0
            }
        else:
            # Ensure 'columns_dropped' is a set for consistent operations
            if not isinstance(self.metadata['cleaning_stats'].get('columns_dropped'), set):
                self.metadata['cleaning_stats']['columns_dropped'] = set(self.metadata['cleaning_stats'].get('columns_dropped', []))

        self.target_column = target_column or self.metadata.get('target_column')
        self.column_threshold = column_threshold
        self.row_threshold = row_threshold
        self.drop_null = drop_null

    def _drop_columns_with_many_nulls(self, df: pd.DataFrame) -> pd.DataFrame:
        """Drops columns with a high percentage of null values."""
        if not (0 <= self.column_threshold <= 1):
            raise ValueError("column_threshold must be between 0 and 1")
        
        null_ratios = df.isnull().mean()
        columns_to_drop = null_ratios[null_ratios > self.column_threshold].index.tolist()
        
        if columns_to_drop:
            logger.info(f"Dropping {len(columns_to_drop)} columns with null ratio > {self.column_threshold}: {columns_to_drop}")
            df = df.drop(columns=columns_to_drop)
            self.metadata['cleaning_stats']['columns_dropped'].update(columns_to_drop)
            # Also remove from the main column metadata if it exists
            for col in columns_to_drop:
                self.metadata.get('columns', {}).pop(col, None)
        return df

    def _drop_rows_with_many_nulls(self, df: pd.DataFrame) -> pd.DataFrame:
        """Drops rows with a high percentage of null values."""
        if not (0 <= self.row_threshold <= 1):
            raise ValueError("row_threshold must be between 0 and 1")
        
        rows_before = len(df)
        row_null_ratios = df.isnull().sum(axis=1) / len(df.columns)
        df = df[row_null_ratios <= self.row_threshold]
        rows_dropped = rows_before - len(df)
        
        if rows_dropped > 0:
            logger.info(f"Dropped {rows_dropped} rows with null ratio > {self.row_threshold}")
            self.metadata['cleaning_stats']['rows_dropped'] += rows_dropped
        return df

    def _drop_rows_with_null_target(self, df: pd.DataFrame) -> pd.DataFrame:
        """Drops rows where the target column is null."""
        if self.target_column and self.target_column in df.columns:
            rows_before = len(df)
            df = df.dropna(subset=[self.target_column])
            rows_dropped = rows_before - len(df)
            
            if rows_dropped > 0:
                logger.info(f"Dropped {rows_dropped} rows with null values in target column '{self.target_column}'")
                self.metadata['cleaning_stats']['rows_dropped'] += rows_dropped
        elif self.target_column:
            logger.warning(f"Target column '{self.target_column}' not found in DataFrame. Skipping null target drop.")
        return df

    def _remove_duplicates(self, df: pd.DataFrame) -> pd.DataFrame:
        """Removes duplicate rows from the DataFrame."""
        rows_before = len(df)
        df = df.drop_duplicates()
        duplicates_removed = rows_before - len(df)
        
        if duplicates_removed > 0:
            logger.info(f"Removed {duplicates_removed} duplicate rows")
            self.metadata['cleaning_stats']['duplicates_removed'] += duplicates_removed
        return df

    def get_cleaning_summary(self) -> Dict[str, Any]:
        """
        Returns a summary of the cleaning operations performed.
        Converts set to list for JSON serializability.
        """
        summary = self.metadata.get('cleaning_stats', {})
        if 'columns_dropped' in summary:
            summary['columns_dropped'] = list(summary['columns_dropped'])
        return summary

    def transform(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Apply the complete data cleaning pipeline to the DataFrame.
        """
        if not isinstance(df, pd.DataFrame):
            raise TypeError("Input must be a pandas DataFrame")
        
        logger.info(f"--- Starting Data Cleaning ---")
        logger.info(f"Initial DataFrame shape: {df.shape}")

        df = self._drop_columns_with_many_nulls(df)
        df = self._drop_rows_with_many_nulls(df)
        df = self._drop_rows_with_null_target(df)
        
        if self.drop_null:
            rows_before = len(df)
            df = df.dropna()
            rows_dropped = rows_before - len(df)
            if rows_dropped > 0:
                logger.info(f"Dropped {rows_dropped} rows with any remaining null values.")
                self.metadata['cleaning_stats']['rows_dropped'] += rows_dropped

        df = self._remove_duplicates(df)
        
        logger.info(f"Final DataFrame shape: {df.shape}")
        logger.info(f"Cleaning summary: {self.get_cleaning_summary()}")
        logger.info(f"--- Data Cleaning Finished ---")
        
        return df
