import pandas as pd
import numpy as np
from scipy.stats import mstats
from sklearn.experimental import enable_iterative_imputer
from sklearn.impute import IterativeImputer, KNNImputer
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import BayesianRidge, LinearRegression
from sklearn.cluster import KMeans
from typing import Optional, Dict, Any

from .Utilities.logger import setup_logger

logger = setup_logger(log_file='pipeline.log', logger_name=__name__)

class Imputer:
    """
    A comprehensive imputation utility for pandas DataFrames that supports various strategies
    for both numeric and categorical data.
    """

    def __init__(self,
                 metadata: Optional[Dict[str, Any]] = None,
                 numeric_strategy: str = 'mean',
                 categorical_strategy: str = 'mode',
                 custom_strategies: Optional[Dict[str, str]] = None):
        """
        Initializes the Imputer.

        Args:
            metadata (Optional[Dict[str, Any]]): Metadata containing column info.
            numeric_strategy (str): Default strategy for numeric columns.
            categorical_strategy (str): Default strategy for categorical columns.
            custom_strategies (Optional[Dict[str, str]]): Per-column strategy overrides.
        """
        self.metadata = metadata if metadata else {}
        self.numeric_strategy = numeric_strategy
        self.categorical_strategy = categorical_strategy
        self.custom_strategies = custom_strategies if custom_strategies else {}

        self.numeric_methods = {
            'mean': self._mean,
            'median': self._median,
            'winsorized_mean': self._winsorized_mean,
            'iterative_rf': self._iterative_rf,
            'knn': self._knn,
            'bayesian': self._bayesian,
            'regression': self._regression,
            'kmeans': self._kmeans
        }
        self.categorical_methods = {
            'mode': self._mode,
            'constant': self._constant
        }

    # --- Numeric Imputation Methods ---
    def _mean(self, series: pd.Series) -> pd.Series:
        return series.fillna(series.mean())

    def _median(self, series: pd.Series) -> pd.Series:
        return series.fillna(series.median())

    def _winsorized_mean(self, series: pd.Series) -> pd.Series:
        winsorized_series = mstats.winsorize(series.dropna(), limits=[0.05, 0.05])
        return series.fillna(winsorized_series.mean())

    def _iterative_rf(self, df: pd.DataFrame, col: str) -> pd.DataFrame:
        imputer = IterativeImputer(estimator=RandomForestRegressor(), random_state=42)
        numeric_cols = df.select_dtypes(include=np.number).columns
        df[numeric_cols] = imputer.fit_transform(df[numeric_cols])
        return df

    def _knn(self, df: pd.DataFrame, col: str) -> pd.DataFrame:
        imputer = KNNImputer()
        numeric_cols = df.select_dtypes(include=np.number).columns
        df[numeric_cols] = imputer.fit_transform(df[numeric_cols])
        return df

    def _bayesian(self, df: pd.DataFrame, col: str) -> pd.DataFrame:
        imputer = IterativeImputer(estimator=BayesianRidge(), random_state=42)
        numeric_cols = df.select_dtypes(include=np.number).columns
        df[numeric_cols] = imputer.fit_transform(df[numeric_cols])
        return df

    def _regression(self, df: pd.DataFrame, col: str) -> pd.DataFrame:
        numeric_df = df.select_dtypes(include=np.number)
        train_df = numeric_df.dropna()
        
        if train_df.empty or col not in train_df.columns:
            return df # Cannot train model

        X_train = train_df.drop(columns=[col])
        y_train = train_df[col]
        
        model = LinearRegression()
        model.fit(X_train, y_train)
        
        predict_df = numeric_df[numeric_df[col].isnull()]
        if not predict_df.empty:
            X_predict = predict_df.drop(columns=[col])
            predictions = model.predict(X_predict)
            df.loc[df[col].isnull(), col] = predictions
        return df

    def _kmeans(self, df: pd.DataFrame, col: str) -> pd.DataFrame:
        numeric_df = df.select_dtypes(include=np.number)
        imputed_df = numeric_df.fillna(numeric_df.mean())
        
        n_clusters = min(5, len(imputed_df))
        if n_clusters < 1: return df

        kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
        imputed_df['cluster'] = kmeans.fit_predict(imputed_df)
        
        cluster_means = imputed_df.groupby('cluster')[col].mean()
        
        for cluster_id, mean_val in cluster_means.items():
            cluster_indices = imputed_df[imputed_df['cluster'] == cluster_id].index
            original_indices = numeric_df.loc[cluster_indices][numeric_df.loc[cluster_indices, col].isnull()].index
            df.loc[original_indices, col] = mean_val
        return df

    # --- Categorical Imputation Methods ---
    def _mode(self, series: pd.Series) -> pd.Series:
        mode_val = series.mode()
        return series.fillna(mode_val.iloc[0] if not mode_val.empty else 'Missing')

    def _constant(self, series: pd.Series, fill_value: str = 'Missing') -> pd.Series:
        return series.fillna(fill_value)

    def transform(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Applies imputation to the DataFrame based on the configured strategies.
        """
        logger.info("--- Starting Imputation ---")
        
        columns_info = self.metadata.get('columns', {})
        
        # Process numeric columns
        numeric_cols = df.select_dtypes(include=np.number).columns
        for col in numeric_cols:
            strategy = self.custom_strategies.get(col, columns_info.get(col, {}).get('imputation', self.numeric_strategy)).lower()
            
            if strategy in self.numeric_methods:
                logger.info(f"Imputing numeric column '{col}' with strategy: {strategy}")
                if strategy in ['iterative_rf', 'knn', 'bayesian', 'regression', 'kmeans']:
                    # These methods operate on the whole DataFrame
                    df = self.numeric_methods[strategy](df, col)
                else:
                    df[col] = self.numeric_methods[strategy](df[col])
            else:
                logger.warning(f"Unknown numeric strategy '{strategy}' for column '{col}'. Skipping.")

        # Process categorical columns
        categorical_cols = df.select_dtypes(exclude=np.number).columns
        for col in categorical_cols:
            if col == self.metadata.get('target_column'):
                logger.info(f"Skipping target column '{col}'")
                continue

            strategy = self.custom_strategies.get(col, self.categorical_strategy).lower()
            
            if strategy in self.categorical_methods:
                logger.info(f"Imputing categorical column '{col}' with strategy: {strategy}")
                df[col] = self.categorical_methods[strategy](df[col])
            else:
                logger.warning(f"Unknown categorical strategy '{strategy}' for column '{col}'. Skipping.")
                
        logger.info("--- Imputation Finished ---")
        return df
