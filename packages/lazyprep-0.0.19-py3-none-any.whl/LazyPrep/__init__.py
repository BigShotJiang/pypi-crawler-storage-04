"""LazyPrep - Efficient data preprocessing tools for data science."""

__version__ = '0.0.19'
__author__ = 'NaveenkumarD'

from .pipeline import PreprocessingPipeline

# Define public API
__all__ = [ 
    'PreprocessingPipeline'
]