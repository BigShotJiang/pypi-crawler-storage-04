import os
import mimetypes
import chardet
import pandas as pd
from typing import Optional, Dict, Any
from .Utilities.logger import setup_logger

logger = setup_logger(log_file='pipeline.log', logger_name=__name__)

class Loader:
    """
    Responsible for detecting file types and loading data into a pandas DataFrame.
    Supports CSV and Excel formats and normalizes column names.
    """
    SUPPORTED_FORMATS = {
        'csv': ['text/csv', '.csv'],
        'excel': ['application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', '.xls', '.xlsx']
    }

    def __init__(self, path: str, metadata: Optional[Dict[str, Any]] = None):
        """
        Initializes the Loader with a file path and optional metadata.

        Args:
            path (str): The path to the file to load.
            metadata (Optional[Dict[str, Any]]): Pre-existing metadata dictionary.
        """
        if not os.path.exists(path):
            raise FileNotFoundError(f"The file was not found at the specified path: {path}")
        
        self.path = path
        self.metadata = metadata if metadata is not None else {}
        self.format = self._detect_file_format()
        self.encoding = self._detect_encoding() if self.format == 'csv' else None
        
        self.metadata['file_info'] = {
            'path': self.path,
            'format': self.format,
            'encoding': self.encoding
        }

    def _detect_file_format(self) -> str:
        """Detects the file format based on its extension and MIME type."""
        _, ext = os.path.splitext(self.path)
        mime_type, _ = mimetypes.guess_type(self.path)

        for fmt, identifiers in self.SUPPORTED_FORMATS.items():
            if ext.lower() in identifiers or mime_type in identifiers:
                logger.info(f"Detected file format: {fmt}")
                return fmt
        
        raise ValueError(f"Unsupported or unknown file type for path: {self.path}")

    def _detect_encoding(self) -> Optional[str]:
        """Detects the character encoding of a file."""
        try:
            with open(self.path, 'rb') as f:
                raw_data = f.read(5000) # Read a sample of the file
            result = chardet.detect(raw_data)
            encoding = result['encoding']
            logger.info(f"Detected encoding: {encoding} with confidence {result['confidence']:.2f}")
            return encoding
        except Exception as e:
            logger.warning(f"Could not detect encoding for {self.path}: {e}. Defaulting to 'utf-8'.")
            return 'utf-8'

    def _normalize_columns(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Normalizes DataFrame column names by converting to lowercase, trimming whitespace,
        and replacing spaces and special characters with underscores.
        """
        original_columns = df.columns
        new_columns = [col.strip().lower().replace(' ', '_').replace('-', '_') for col in original_columns]
        
        # Handle potential duplicate column names after normalization
        if len(set(new_columns)) < len(new_columns):
            logger.warning("Duplicate column names found after normalization. Appending suffixes.")
            # Simple suffixing for duplicates
            from collections import Counter
            counts = Counter(new_columns)
            for i, col in reversed(list(enumerate(new_columns))):
                if counts[col] > 1:
                    suffix = counts[col]
                    new_columns[i] = f"{col}_{suffix}"
                    counts[col] -= 1
        
        df.columns = new_columns
        logger.info("Normalized column names.")
        return df

    def transform(self, normalize_columns: bool = True) -> pd.DataFrame:
        """
        Loads the file into a pandas DataFrame and optionally normalizes column names.

        Args:
            normalize_columns (bool): If True, normalizes the column names.

        Returns:
            pd.DataFrame: The loaded DataFrame.
        """
        logger.info(f"--- Starting File Loading ---")
        try:
            if self.format == 'csv':
                df = pd.read_csv(self.path, encoding=self.encoding)
            elif self.format == 'excel':
                df = pd.read_excel(self.path)
            else:
                # This case should ideally not be reached due to the check in __init__
                raise ValueError(f"Unsupported file format: {self.format}")
            
            logger.info(f"Successfully loaded {self.format} file from: {self.path}")
            self.metadata['file_info']['initial_shape'] = df.shape

            if normalize_columns:
                df = self._normalize_columns(df)
                self.metadata['file_info']['final_shape'] = df.shape

            logger.info(f"--- File Loading Finished ---")
            return df

        except Exception as e:
            logger.error(f"Failed to load or process file {self.path}: {e}")
            raise
