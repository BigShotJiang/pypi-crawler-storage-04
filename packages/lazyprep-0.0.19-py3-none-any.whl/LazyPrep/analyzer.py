import re
import logging
import datetime
import pandas as pd
from pathlib import Path
from .Utilities.strategy import strategies
from .Utilities.logger import setup_logger
from fitter import Fitter, get_common_distributions
from typing import Dict, Any, Union, Optional

logger = setup_logger(log_file='pipeline.log', logger_name=__name__)

class Analyzer:
    """
    Analyzes a pandas DataFrame to determine data types, distributions,
    and suggest preprocessing strategies.
    """

    def __init__(self, metadata: Optional[Dict[str, Any]] = None):
        """
        Initializes the Analyzer with optional metadata.

        Args:
            metadata (Optional[Dict[str, Any]], optional): Pre-existing metadata. Defaults to None.
        """
        self.metadata: Dict[str, Any] = metadata if metadata is not None else {}

    def analyze_distribution(self, feature: pd.Series) -> Dict[str, Union[str, Dict, None]]:
        """
        Analyzes the distribution of a numeric pandas Series.

        Args:
            feature (pd.Series): The numeric series to analyze.

        Returns:
            Dict[str, Union[str, Dict, None]]: A dictionary with the best-fit distribution and its parameters.
        """
        try:
            # Drop NA values and take a sample for performance
            clean_feature = feature.dropna()
            if len(clean_feature) < 2: # Fitter needs at least 2 points
                return {"Distribution": "Not enough data", "Parameters": None}
            
            sample_size = min(1500, len(clean_feature))
            fit_sample = clean_feature.sample(sample_size, random_state=42)
            
            f = Fitter(fit_sample, distributions=get_common_distributions(), timeout=10)
            f.fit()
            
            best_fit = f.get_best(method='sumsquare_error')
            if not best_fit:
                return {"Distribution": "Fitter Failed", "Parameters": None}

            best_dist_name = list(best_fit.keys())[0]
            best_dist_params = best_fit[best_dist_name]
            
            result = {
                "Distribution": best_dist_name,
                "Parameters": best_dist_params
            }
        except Exception as e:
            logger.warning(f"Fitter failed for '{feature.name}': {str(e)}")
            result = {"Distribution": "Fitter Failed", "Parameters": None}
        
        logger.info(f"Distribution analysis for {feature.name}: {result}")
        return result

    def detect_datetime_type(self, series: pd.Series) -> str:
        """
        Detects if a series is of type 'date', 'time', or 'datetime'.

        Args:
            series (pd.Series): The series to analyze.

        Returns:
            str: The detected type ('date', 'time', 'datetime', or 'invalid').
        """
        clean_series = series.dropna()
        if clean_series.empty:
            return "invalid"

        # Regex for time-only formats
        time_pattern = re.compile(r"^\d{1,2}:\d{2}(:\d{2})?(\.\d+)?( AM| PM)?$", re.IGNORECASE)

        def is_time_only(x):
            if isinstance(x, datetime.time):
                return True
            if isinstance(x, str):
                return bool(time_pattern.fullmatch(x))
            return False

        if all(is_time_only(x) for x in clean_series):
            return "time"

        try:
            # Coerce to datetime and check for NaNs
            parsed = pd.to_datetime(clean_series, errors='coerce')
            if parsed.isna().any():
                return "invalid"

            # Check if all dates are midnight (i.e., only date info)
            if (parsed.dt.time == datetime.time(0, 0)).all():
                return "date"
            else:
                return "datetime"
        except Exception:
            return "invalid"

    def _analyze_numeric(self, col_name: str, series: pd.Series):
        """Analyzes a numeric column."""
        dist_info = self.analyze_distribution(series)
        method = dist_info['Distribution']
        
        strategy = {}
        if isinstance(method, str):
            strategy = strategies.get(method, {})

        self.metadata['columns'][col_name] = {
            'dtype': 'numeric',
            'column_distribution': method,
            'outlier_detection': strategy.get('outlier_detection', 'IQR'),
            'normalization': strategy.get('normalization', 'MinMaxScaler'),
            'imputation': strategy.get('imputation', 'Mean')
        }

    def _analyze_datetime(self, col_name: str, series: pd.Series):
        """Analyzes a datetime column."""
        self.metadata['columns'][col_name] = {
            'dtype': self.detect_datetime_type(series)
        }

    def _analyze_categorical(self, col_name: str, series: pd.Series):
        """Analyzes a categorical/object column."""
        # First, check if it could be a datetime type stored as object
        datetime_type = self.detect_datetime_type(series)
        if datetime_type != 'invalid':
            self.metadata['columns'][col_name] = {'dtype': datetime_type}
            return

        # If not datetime, treat as categorical
        unique_values = series.nunique()
        self.metadata['columns'][col_name] = {
            'dtype': 'categorical',
            'unique_values': unique_values,
            'top_value': series.mode().iloc[0] if not series.mode().empty and unique_values != len(series) else None
        }

    def _analyze_boolean(self, col_name: str):
        """Analyzes a boolean column."""
        self.metadata['columns'][col_name] = {'dtype': 'boolean'}

    def analyze(self, df: pd.DataFrame) -> Dict[str, Any]:
        """
        Performs a full analysis of the DataFrame.

        Args:
            df (pd.DataFrame): The DataFrame to analyze.

        Returns:
            Dict[str, Any]: The generated metadata.
        """
        logger.info("--- Starting DataFrame Analysis ---")
        self.metadata['columns'] = self.metadata.get('columns', {})

        for col in df.columns:
            logger.info(f"Analyzing column: {col}")
            series = df[col]
            dtype = series.dtype

            if pd.api.types.is_numeric_dtype(dtype):
                self._analyze_numeric(col, series)
            elif pd.api.types.is_datetime64_any_dtype(dtype):
                self._analyze_datetime(col, series)
            elif pd.api.types.is_object_dtype(dtype) or pd.api.types.is_string_dtype(dtype) or dtype == 'category':
                self._analyze_categorical(col, series)
            elif pd.api.types.is_bool_dtype(dtype):
                self._analyze_boolean(col)
            else:
                logger.warning(f"Column '{col}' has an unknown dtype '{dtype}' and will be ignored.")
                self.metadata['columns'][col] = {'dtype': 'unknown'}
            
            if col in self.metadata['columns']:
                 logger.info(f"Result for {col}: {self.metadata['columns'][col]}")

        logger.info("--- DataFrame Analysis Finished ---")
        return self.metadata

    def transform(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Analyzes the DataFrame and returns it unchanged.

        Args:
            df (pd.DataFrame): The DataFrame to analyze.

        Returns:
            pd.DataFrame: The original, unchanged DataFrame.
        """
        self.analyze(df)
        return df
