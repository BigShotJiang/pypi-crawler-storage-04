# 0.0.1 - 29th August 2025
- Initial build of the project.
