[![CI Build Status](https://img.shields.io/github/actions/workflow/status/StevenMapes/django-aws-api-gateway-websockets/main.yml?branch=main&style=for-the-badge)](https://github.com/StevenMapes/py-ocr-pdf/actions)
[![Coverage](https://img.shields.io/badge/Coverage-96%25-success?style=for-the-badge)](https://github.com/StevenMapes/py-ocr-pdf/actions?workclow=CI)
[![PyPi](https://img.shields.io/pypi/v/django-aws-api-gateway-websockets.svg?style=for-the-badge)](https://pypi.org/project/django-aws-api-gateway-websockets/)
![Code Style](https://img.shields.io/badge/code%20style-black-000000.svg?style=for-the-badge)
![Pre-Commit Enabled](https://img.shields.io/badge/pre--commit-enabled-brightgreen?logo=pre-commit&logoColor=white&style=for-the-badge)
[![Read The Docs](https://img.shields.io/readthedocs/django-mysql?style=for-the-badge)](https://django-aws-api-gateway-websockets.readthedocs.io/)

[![PyPi Downloads](https://img.shields.io/pypi/dd/py-ocr-pdf)](https://pypistats.org/packages/py-ocr-pdf)

# py-ocr-pdf
This project has been designed to allow you to OCR PDF files regardless of whether the PDF contains text or images.

# Python Support
This project only actively supports current Python versions, Python 3.10 to 3.14.

# Installation
You can install this package from pip using
```
pip install py-ocr-pdf
```
## OS Dependencies
- poppler-utils
- tesseract-ocr

### Linux PDF OCR Support
- Install the following ```sudo apt-get install poppler-utils tesseract-ocr```

### Mac OS PDF OCR Support
This project uses pdftoppm and tesseract-ocr so you need to install poppler-utils and tesseract-ocr.
```
brew install poppler
```

### Windows OS PDF OCR Support
On Windows you can install pdftoppm by following the instructions here: 
1. Go to https://github.com/oschwartz10612/poppler-windows
2. Navigate there to the latest release
3. Download the zip
4. Unzip and save the files in a new folder
5. After you have installed the Zotero OCR plugin, adjust the location of pdftoppm in your settings


# Found a Bug?
Issues are tracked via GitHub issues at the [project issue page](https://github.com/StevenMapes/py-ocr-pdf/issues)

# Have A Feature Request?
Feature requests can be raised by creating an issue within the [project issue page](https://github.com/StevenMapes/py-ocr-pdf/issues), but please create the issue with "Feature Request -" at the start of the issue

# Testing
To run the tests use

```
coverage erase && \
python -W error::DeprecationWarning -W error::PendingDeprecationWarning -m coverage run --parallel -m pytest --ds tests.settings && \
coverage combine && \
coverage report
```

# Compiling Requirements
Run ```pip install pip-tools``` then run ```python requirements/compile.py``` to generate the various requirements files.
I use two local VIRTUALENVS to build the requirements, one running Python3.8 and the other running Python 3.11.

# Building
This project uses hatchling
```python -m build --sdist```

# tox

# Contributing
- [Check for open issues](https://github.com/StevenMapes/py-ocr-pdf/issues) at the project issue page or open a new issue to start a discussion about a feature or bug.
- Fork the [repository on GitHub](https://github.com/StevenMapes/py-ocr-pdf) to start making changes.
- Clone the repository
- Initialise pre-commit by running ```pre-commit install```
- Install requirements from one of the requirement files
- Add a test case to show that the bug is fixed or the feature is implemented correctly.
- Test using ```python -W error::DeprecationWarning -W error::PendingDeprecationWarning -m coverage run --parallel -m pytest --ds tests.settings```
- Create a pull request, tagging the issue, bug me until I can merge your pull request. Also, don't forget to add yourself to AUTHORS.
