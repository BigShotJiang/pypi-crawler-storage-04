"""DRF RESTWind template tags"""
