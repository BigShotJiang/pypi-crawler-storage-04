add-ons should not be corrected to add-owns

git glossary has both commitish and committish, so don't correct them

HTTP_REFERER is a valid HTTP header field

It should be reasonable to talk about `<thead>`

SHTTP is a protocol
