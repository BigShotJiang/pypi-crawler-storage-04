from operator import (
    concat,
    iconcat,
    countOf,
    indexOf,
    length_hint,
    delitem,
    setitem,
    getitem,
    contains,
)
