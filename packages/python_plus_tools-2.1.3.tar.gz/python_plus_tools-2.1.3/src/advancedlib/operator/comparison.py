from operator import lt, le, eq, ne, ge, gt
