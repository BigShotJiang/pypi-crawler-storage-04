from colorama import Style, Back, Fore, init

init(autoreset=True)
