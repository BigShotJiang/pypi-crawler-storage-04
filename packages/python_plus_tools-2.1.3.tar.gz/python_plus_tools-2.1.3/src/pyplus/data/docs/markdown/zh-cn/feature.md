# 展望

<div align="center" style="line-height: 1;">
  <a href="./feature.md"><img
    src="https://img.shields.io/badge/语言-English-536af5?color=0326f3&logoColor=white"/></a>
  <a href="./feature-CN.md"><img
    src="https://img.shields.io/badge/简体中文-536af5?color=ff0000&logoColor=white"/></a>
</div>
<br />
<div align="center" style="line-height: 1;">
  <a href="./README-CN.md"><img
    src="https://img.shields.io/badge/打开-readme-536af5?color=3004a0&logoColor=white"/></a>
</div>

# pyplus
## 2.1
添加文档