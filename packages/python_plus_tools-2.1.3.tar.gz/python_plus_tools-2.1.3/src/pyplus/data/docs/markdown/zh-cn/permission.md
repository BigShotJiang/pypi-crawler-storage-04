# permission

## 描述

## 函数