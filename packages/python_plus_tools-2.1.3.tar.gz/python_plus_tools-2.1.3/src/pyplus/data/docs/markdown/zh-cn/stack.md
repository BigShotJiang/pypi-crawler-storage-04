# stack

## 描述

## 函数