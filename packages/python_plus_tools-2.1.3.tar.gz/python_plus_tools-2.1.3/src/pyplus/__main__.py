from pyplus_cmd import main

main()
