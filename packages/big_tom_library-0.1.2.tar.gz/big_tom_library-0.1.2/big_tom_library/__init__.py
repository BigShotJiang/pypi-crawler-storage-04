
def Test():
    print("Test")