# src/OSSS/db/models/core.py
from __future__ import annotations

from .organizations import Organization
__all__ = ["Organization"]
