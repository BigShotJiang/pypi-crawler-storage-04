from .QT6 import *
from .SIMPLEGUI import *
from .SIMPLEGUI.initFuncGen import get_for_all_tabs
