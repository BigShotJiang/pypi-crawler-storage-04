"""Tests for schellma package."""
