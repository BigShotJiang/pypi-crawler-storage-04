# carlosferreyra-cli-py
Personal CLI tool for carlosferreyra (Python version)
