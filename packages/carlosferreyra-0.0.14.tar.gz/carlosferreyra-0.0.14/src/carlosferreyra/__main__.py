def main() -> None:
    """CLI entry point for carlosferreyra package."""
    print("Testing entry point. it should work with uvx carlosferreyra")


if __name__ == "__main__":
    main()
