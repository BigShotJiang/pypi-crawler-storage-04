def hello() -> str:
    return "Hello from carlosferreyra-cli-py!"
