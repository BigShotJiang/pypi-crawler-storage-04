# Changelog

## Unreleased

## v0.3.0

- Add user-configurable repository mappings via pyproject.toml

## v0.2.1

- change hook back to the system python

## v0.2.0

- support python 3.10
- change CLI flags to mimic Black flags, with quiet/verbose/diff/color/check.

## v0.1.2

- hotfix for hook not running at all
- less verbose output, hide debug messages and timestamps

## v0.1.1

- fix hook not running when the system python version is < 3.11

## v0.1.0

- Initial release
