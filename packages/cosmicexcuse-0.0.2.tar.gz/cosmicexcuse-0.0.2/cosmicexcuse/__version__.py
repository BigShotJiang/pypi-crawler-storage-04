"""Version information for CosmicExcuse package."""

__version__ = "1.0.0"
__author__ = "Shamsuddin Ahmed"
__email__ = "info@shamspias.com"
__license__ = "MIT"
__copyright__ = "Copyright 2025 Shamsuddin Ahmed"
__status__ = "Beta"
