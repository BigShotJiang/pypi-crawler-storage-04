# kimmdy-hydrolysis

A reaction plugin for [KIMMDY](https://graeter-group.github.io/kimmdy/) that hydrolyses peptide bonds.

Documentation: <https://graeter-group.github.io/kimmdy-hydrolysis/>

