# sage_setup: distribution = sagemath-gfan
# delvewheel: patch

from sage.all__sagemath_polyhedra import *
