class ProvWorkflowException(Exception):
    pass
