inboxPluginName = "peek_plugin_inbox"

inboxFilt = {"plugin": "peek_plugin_inbox"}
inboxTuplePrefix = "peek_plugin_inbox."

inboxObservableName = "peekPluginInbox"

inboxActionProcessorName = "peekPluginInbox"
