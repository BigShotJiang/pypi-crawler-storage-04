export let inboxFilt = { plugin: "peek_plugin_inbox" };
export let inboxTuplePrefix = "peek_plugin_inbox.";

export let inboxTupleOfflineServiceName = "peekPluginInbox";
export let inboxObservableName = "peekPluginInbox";

export let inboxActionProcessorName = "peekPluginInbox";

export let inboxBaseUrl = "peek_plugin_inbox";

export let inboxPluginName = "peek_plugin_inbox";
