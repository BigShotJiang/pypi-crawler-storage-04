export interface NotifierI {
    loadSound(soundPath: string): void;
    playSound(): void;
}
