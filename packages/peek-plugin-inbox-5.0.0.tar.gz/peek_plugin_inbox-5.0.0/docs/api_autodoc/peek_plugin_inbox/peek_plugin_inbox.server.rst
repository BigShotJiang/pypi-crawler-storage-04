.. _peek_plugin_inbox.server:

\(P\) server
============

.. automodule:: peek_plugin_inbox.server
    :members:
    :undoc-members:
    :show-inheritance:

\(M\) InboxApiABC
----------------------

.. automodule:: peek_plugin_inbox.server.InboxApiABC
    :members:
    :undoc-members:
    :show-inheritance:


