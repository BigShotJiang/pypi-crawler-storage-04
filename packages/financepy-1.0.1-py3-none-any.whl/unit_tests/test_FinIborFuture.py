# Copyright (C) 2018, 2019, 2020 Dominic O'Kane

from financepy.utils.date_format import set_date_format, DateFormatTypes
from financepy.utils.date import Date
from financepy.products.rates.ibor_future import IborFuture

set_date_format(DateFormatTypes.UK_LONG)

########################################################################################


def test_fin_ibor_future():

    today_date = Date(5, 5, 2020)

    i = 1
    fut = IborFuture(today_date, i, "3M")
    fra = fut.to_fra(0.020, 0.0)
    assert fut.delivery_dt == Date(17, 6, 2020)
    assert fra.start_dt == Date(17, 6, 2020)

    i = 4
    fut = IborFuture(today_date, i, "3M")
    fra = fut.to_fra(0.020, 0.0)
    assert fut.delivery_dt == Date(17, 3, 2021)
    assert fra.start_dt == Date(17, 3, 2021)

    i = 7
    fut = IborFuture(today_date, i, "3M")
    fra = fut.to_fra(0.020, 0.0)
    assert fut.delivery_dt == Date(15, 12, 2021)
    assert fra.start_dt == Date(15, 12, 2021)

    i = 10
    fut = IborFuture(today_date, i, "3M")
    fra = fut.to_fra(0.020, 0.0)
    assert fut.delivery_dt == Date(21, 9, 2022)
    assert fra.start_dt == Date(21, 9, 2022)
