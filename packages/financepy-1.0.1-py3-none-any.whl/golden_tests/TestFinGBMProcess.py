# Copyright (C) 2018, 2019, 2020 Dominic O'Kane

import numpy as np

from FinTestCases import FinTestCases, global_test_case_mode
from financepy.models.gbm_process_simulator import get_assets_paths_times
from financepy.utils.math import corr_matrix_generator

test_cases = FinTestCases(__file__, global_test_case_mode)

########################################################################################


def test_fin_gbm_process():

    num_assets = 3
    num_paths = 6
    num_time_steps = 1
    t = 1.0
    mus = 0.03 * np.ones(num_assets)
    stock_prices = 100.0 * np.ones(num_assets)
    volatilities = 0.2 * np.ones(num_assets)
    rho = 0.8
    corr_matrix = corr_matrix_generator(rho, num_assets)
    seed = 1912

    times, paths = get_assets_paths_times(
        num_assets,
        num_paths,
        num_time_steps,
        t,
        mus,
        stock_prices,
        volatilities,
        corr_matrix,
        seed,
    )


########################################################################################

test_fin_gbm_process()
test_cases.compare_test_cases()
