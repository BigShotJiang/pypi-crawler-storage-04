# tce-lib

[![Custom shields.io](https://img.shields.io/badge/docs-brightgreen?logo=github&logoColor=green&label=gh-pages)](https://muexly.github.io/tce-lib)
[![Linting: Ruff](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/charliermarsh/ruff/main/assets/badge/v2.json)](https://github.com/astral-sh/ruff)
[![Checked with mypy](https://www.mypy-lang.org/static/mypy_badge.svg)](https://mypy-lang.org/)
[![Tested with pytest](https://img.shields.io/badge/pytest-tested-blue?logo=pytest)](https://docs.pytest.org/en/stable/)

<img src="https://raw.githubusercontent.com/MUEXLY/tce-lib/refs/heads/main/assets/logo.png" alt="tce-lib logo" style="width:50%;height:auto;">


## 🔎 What is tce-lib?

`tce-lib` is a library for creating and deploying tensor cluster expansion models of concentrated alloys following
our work on [arXiv](https://google.com/).

## 📩 Installation

`tce-lib` is installable via the Python Package Index:

```shell
pip install tce-lib
```

or, from source:

```shell
git clone https://github.com/MUEXLY/tce-lib
pip install -e tce-lib/
```

## 📌 Citation

Please cite our work [here](https://google.com/) if you use `tce-lib` in your work.

## 💙 Acknowledgements

Authors acknowledge support from the U.S. Department of Energy, Office of Basic Energy Sciences, Materials Science and Engineering Division under Award No. DE-SC0022980.

## 🐝 Found a bug?

Please open an issue [here](https://github.com/MUEXLY/tce/issues), with a description of the issue and a [minimal, reproducible example](https://stackoverflow.com/help/minimal-reproducible-example) of the issue.

## 📑 License

`tce-lib` is released under the MIT license.
