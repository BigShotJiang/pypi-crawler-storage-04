class PropertyNotDefined(Exception):
    pass
