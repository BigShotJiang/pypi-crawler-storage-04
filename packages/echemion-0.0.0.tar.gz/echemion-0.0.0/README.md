# echemion
This code package is for modeling electrochemical processes, with a focus on ion transport and separation.
