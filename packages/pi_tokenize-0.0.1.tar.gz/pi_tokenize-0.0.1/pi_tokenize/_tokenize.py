from ._vendor.cpython._tokenize._tokenize import TokenizerIter

__all__ = ["TokenizerIter"]
