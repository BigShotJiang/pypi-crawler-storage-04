Latest (almost) version of CPython's tokenizer machinery.
