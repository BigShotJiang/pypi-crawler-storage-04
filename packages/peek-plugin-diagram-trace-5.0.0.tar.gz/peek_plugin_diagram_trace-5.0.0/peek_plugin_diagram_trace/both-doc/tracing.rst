=======
Tracing
=======


.. toctree::
    :maxdepth: 2
    :caption: Contents:


Start a Trace
-------------

From an **Equipment Attributes Popup**:

#. Click on the **Start a trace from this equipment** button

.. image:: trace_button.png
    :align: center

----

#. Click on a Trace to select it.

.. image:: trace_popup.png
    :align: center

Removing a trace
----------------

#. Click on the **Clear Traces** button.

.. image:: clear_trace_button.png
    :align: center
