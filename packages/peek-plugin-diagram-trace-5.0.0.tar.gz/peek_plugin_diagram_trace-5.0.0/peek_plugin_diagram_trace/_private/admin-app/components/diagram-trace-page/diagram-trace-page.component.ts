
import { Component, ChangeDetectionStrategy } from "@angular/core";

@Component({
    selector: "diagramTrace-admin",
    templateUrl: "diagram-trace-page.component.html",
    styleUrls: ["diagram-trace-page.component.scss"],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class DiagramTracePageComponent {
    constructor() {}
}