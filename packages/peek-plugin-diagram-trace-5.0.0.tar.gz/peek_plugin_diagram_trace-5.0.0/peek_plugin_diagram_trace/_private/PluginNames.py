diagramTraceFilt = {"plugin": "peek_plugin_diagram_trace"}
diagramTraceTuplePrefix = "peek_plugin_diagram_trace."
diagramTraceObservableName = "peek_plugin_diagram_trace"
diagramTraceActionProcessorName = "peek_plugin_diagram_trace"
diagramTraceTupleOfflineServiceName = "peek_plugin_diagram_trace"
