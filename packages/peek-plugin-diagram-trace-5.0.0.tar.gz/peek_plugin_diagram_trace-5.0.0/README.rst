=========================
Peek Diagram Trace Plugin
=========================

This Peek Plugin uses the GraphDB plugin to trace the connectivity from selected
equipment, then highlight the trace result.