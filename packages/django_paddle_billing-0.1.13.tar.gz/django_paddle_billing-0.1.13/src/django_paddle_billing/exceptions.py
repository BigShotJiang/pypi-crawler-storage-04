class DjangoPaddleBillingError(Exception):
    pass
