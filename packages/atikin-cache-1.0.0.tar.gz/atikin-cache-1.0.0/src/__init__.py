"""
Atikin-Cache - High-performance in-memory caching library
"""

from .cache import AtikinCache

__version__ = "1.0.0"
__all__ = ['AtikinCache']