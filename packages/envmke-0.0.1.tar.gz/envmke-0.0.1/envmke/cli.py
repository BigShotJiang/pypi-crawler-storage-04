import argparse
import sys
from pathlib import Path

from .core import (
    generate_example_env,
    sync_env_files,
    audit_env_files,
    print_audit_report,
    get_colored_output,
    write_env_file,
)


def main():
    parser = argparse.ArgumentParser(
        description="Generate, sync, and audit .env files by scanning Python code",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  envmke generate          # Generate .env.example from Python files
  envmke sync             # Sync .env with .env.example
  envmke sync --clean     # Remove unused variables from .env
  envmke audit            # Show audit report
        """
    )
    
    subparsers = parser.add_subparsers(dest='command', help='Available commands')
    
    generate_parser = subparsers.add_parser(
        'generate',
        help='Generate .env.example from Python files'
    )
    generate_parser.add_argument(
        '--directory', '-d',
        type=Path,
        default=Path.cwd(),
        help='Directory to scan (default: current directory)'
    )
    
    sync_parser = subparsers.add_parser(
        'sync',
        help='Sync .env with .env.example'
    )
    sync_parser.add_argument(
        '--directory', '-d',
        type=Path,
        default=Path.cwd(),
        help='Directory to work in (default: current directory)'
    )
    sync_parser.add_argument(
        '--clean',
        action='store_true',
        help='Remove variables not in .env.example'
    )
    
    audit_parser = subparsers.add_parser(
        'audit',
        help='Audit .env files and show report'
    )
    audit_parser.add_argument(
        '--directory', '-d',
        type=Path,
        default=Path.cwd(),
        help='Directory to audit (default: current directory)'
    )
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return 1
    
    try:
        if args.command == 'generate':
            return handle_generate(args.directory)
        elif args.command == 'sync':
            return handle_sync(args.directory, args.clean)
        elif args.command == 'audit':
            return handle_audit(args.directory)
    except KeyboardInterrupt:
        print("\nOperation cancelled by user")
        return 1
    except Exception as e:
        print(f"{get_colored_output('Error:', '31')} {e}")
        return 1
    
    return 0


def handle_generate(directory: Path) -> int:
    print(f"Scanning Python files in {directory}...")
    
    env_vars = generate_example_env(directory)
    
    if not env_vars:
        print(f"{get_colored_output('No environment variables found', '33')}")
        return 0
    
    example_path = directory / ".env.example"
    write_env_file(example_path, env_vars, preserve_comments=False)
    
    print(f"{get_colored_output('Generated', '32')} .env.example with {len(env_vars)} variables:")
    for var in sorted(env_vars.keys()):
        print(f"  {var}")
    
    return 0


def handle_sync(directory: Path, clean: bool) -> int:
    env_path = directory / ".env"
    example_path = directory / ".env.example"
    
    if not example_path.exists():
        print(f"{get_colored_output('Error:', '31')} .env.example not found")
        print("Run 'envmke generate' first to create .env.example")
        return 1
    
    print(f"Syncing .env with .env.example...")
    
    env_vars = sync_env_files(directory, clean)
    write_env_file(env_path, env_vars)
    
    action = "Cleaned" if clean else "Synced"
    print(f"{get_colored_output(action, '32')} .env with {len(env_vars)} variables")
    
    return 0


def handle_audit(directory: Path) -> int:
    env_path = directory / ".env"
    example_path = directory / ".env.example"
    
    if not env_path.exists() and not example_path.exists():
        print(f"{get_colored_output('No .env files found', '33')}")
        return 0
    
    present, missing, unused = audit_env_files(directory)
    print_audit_report(present, missing, unused)
    
    return 0


if __name__ == '__main__':
    sys.exit(main())
