# envmke

A CLI tool that helps devs generate, sync, and audit `.env` files by scanning Python code for environment variable usage.

## Installation

```bash
pip install envmke
```

## License

MIT License

## Repository

[https://github.com/aycsi/envmke](https://github.com/aycsi/envmke)
