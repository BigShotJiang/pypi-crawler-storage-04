from typing import Any, Union

Path = str
SourceType = Union[Path]
StorageHandle = Any

_STORAGE_LOG_FILE_NAME = 'storage.log'
