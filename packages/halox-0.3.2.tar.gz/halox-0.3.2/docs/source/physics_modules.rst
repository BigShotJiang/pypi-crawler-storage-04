Physics modules
===============

This section covers tutorials for the core physics modules in halox.

.. toctree::
   :maxdepth: 1

   notebooks/nfw.ipynb
   notebooks/hmf.ipynb
   notebooks/bias.ipynb