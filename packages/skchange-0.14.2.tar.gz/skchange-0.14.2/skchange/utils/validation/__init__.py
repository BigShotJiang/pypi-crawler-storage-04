"""Input validation utility functions."""
