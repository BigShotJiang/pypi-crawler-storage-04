"""Tests for compositions."""
