"""
Tonic Fabricate - The official Fabricate client for Python.
"""

from .client import generate

__version__ = "1.0.0"

__all__ = ["generate"] 