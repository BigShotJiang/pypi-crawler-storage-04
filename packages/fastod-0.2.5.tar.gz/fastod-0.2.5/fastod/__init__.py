from fastod.core import *
