
import { Component, ChangeDetectionStrategy } from "@angular/core";

@Component({
    selector: "search-admin",
    templateUrl: "search-page.component.html",
    styleUrls: ["search-page.component.scss"],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class SearchPageComponent {}