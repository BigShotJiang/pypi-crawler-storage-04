__author__ = "synerty"
__version__ = '5.0.4'


def importPackages():
    from . import plugin
