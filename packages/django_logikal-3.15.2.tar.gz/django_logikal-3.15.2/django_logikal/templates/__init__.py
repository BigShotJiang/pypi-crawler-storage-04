from django_logikal.templates.template import Template

__all__ = ['Template']
