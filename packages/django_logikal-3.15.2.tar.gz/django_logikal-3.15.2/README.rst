django-logikal
==============
Django utilities used at Logikal.

Getting Started
---------------
You can find the project documentation under `docs.logikal.io/django-logikal/
<https://docs.logikal.io/django-logikal/>`_.
