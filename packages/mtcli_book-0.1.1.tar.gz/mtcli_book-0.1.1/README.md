# mtcli-book
  
Plugin mtcli que exibe o book de ofertas.
  
---
  
## Instalação
  
```cmd
pip install mtcli-book
```
