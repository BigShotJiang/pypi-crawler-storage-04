# dagster-databricks

The docs for `dagster-databricks` can be found
[here](https://docs.dagster.io/api/python-api/libraries/dagster-databricks).

A guide for integrating Databricks using Dagster Pipes can be found
[here](https://docs.dagster.io/guides/dagster-pipes/databricks).
