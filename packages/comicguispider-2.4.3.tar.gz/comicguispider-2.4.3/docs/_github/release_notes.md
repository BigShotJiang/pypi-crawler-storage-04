
> [!Warning]  
> win-绿色包注意：`_pystand_static.int`首行 version 非 `v1` 或没 version 时，需要重新下绿色包解压覆盖以支持后续功能  
> cpython包下载报错无法连接的，手动去下载`python3.13`再重新运行

## 🎁 Feat

✅ 配置窗口调整，映射放进高级设置里
✅ 高级设置新增 拷贝勾选展示单行本，注意会影响用`-3`等倒数选的排序
