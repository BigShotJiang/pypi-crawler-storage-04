Este é o módulo base dos recursos humanos brasileiro e implementa
adaptações nos modelos básicos do cadastro de Empregados e suas
dependências:

- Campo CPF com formatação e validação desto memso;
- CPTS com validação;
- PIS/PASEF;
- Certificado de serviço militar;
- Naturalidade;
- Escolaridade - usar hr_skills;
- Dependentes - Usar hr_employee_relative;
- RG;
- Título de eleitor;
- Paternidade;
- Etinia;
- Tipo sanguíneo;
- Incapacidade física;
- Tipo: Funcionário / Autônomo / Terceirizado / Cedido;
