Este módulo tem uma depedencia do pacote python erpbrasil.base
