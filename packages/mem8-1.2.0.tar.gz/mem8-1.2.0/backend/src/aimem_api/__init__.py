"""AI-Mem Backend API for team collaboration and synchronization."""

__version__ = "0.1.0"