# Cookiecutter Template Directory for .claude items

This directory contains the cookiecutter template structure for new ai-mem projects that are for claude-code's CLAUDE.md subsystem.
