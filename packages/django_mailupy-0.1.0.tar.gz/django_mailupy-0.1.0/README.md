# django-mailupy

Django wrapper for the Mailupy client.

## Overview

`django-mailupy` is a Django app that wraps the [Mailupy](https://pypi.org/project/mailupy/) Python client, providing seamless integration with Django projects. It stores MailUp credentials in the database in a single instance and exposes API endpoints for credential management.

## Features

- Stores MailUp credentials securely in the database
- Provides Django REST Framework viewsets and serializers for credential management
- Exposes MailUp client methods via Django

## Requirements

- Python >= 3.9
- Django >= 4.2
- mailupy >= 1.1.4
- (Optional) djangorestframework >= 3.12 for API features

## Installation

```bash
pip install django-mailupy
```

Or add to your `pyproject.toml` dependencies:

```toml
django-mailupy = ">=0.1.0"
```

## Setup

1. Add `django_mailupy` to your `INSTALLED_APPS` in `settings.py`:

    ```python
    INSTALLED_APPS = [
        # ...existing apps...
        'django_mailupy',
    ]
    ```

2. Run migrations to create the credentials table:

    ```bash
    python manage.py migrate
    ```

3. (Optional) Add the API URLs to your project:

    ```python
    # in your urls.py
    path('mailupy/', include('django_mailupy.urls')),
    ```

## Usage

- Store your MailUp credentials using the admin or API.
- Initialize the `DjangoMailupy` client in your code:

    ```python
    from django_mailupy.client import DjangoMailupy

    client = DjangoMailupy(client_id="your_client_id", client_secret="your_client_secret")
    ```

- Django Mailupy stores only one set of credentials and only username and password to ensure security, since client ID and secret can be hardcoded or managed via environment variables and do not change often.

## Example

- The library contains a simple example app that demonstrates how to use the client and API. You can run it with:

    ```bash
    python manage.py runserver
    ```

inside the `example` directory.

## Project Structure

```
django-mailupy
├─ LICENSE
├─ README.md
├─ example
│  ├─ config
│  │  ├─ __init__.py
│  │  ├─ settings.py
│  │  ├─ urls.py
│  │  ├─ views.py
│  │  └─ wsgi.py
│  └─ manage.py
├─ pyproject.toml
└─ src
   └─ django_mailupy
      ├─ __init__.py
      ├─ admin.py
      ├─ apps.py
      ├─ client.py
      ├─ migrations
      │  ├─ 0001_initial.py
      │  └─ __init__.py
      ├─ models.py
      ├─ serializers.py
      ├─ urls.py
      └─ viewsets.py

```

## License

MIT License. See [LICENSE](LICENSE) for details.