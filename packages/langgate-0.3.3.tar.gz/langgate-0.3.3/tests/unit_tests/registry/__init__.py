"""Unit tests for registry module."""
