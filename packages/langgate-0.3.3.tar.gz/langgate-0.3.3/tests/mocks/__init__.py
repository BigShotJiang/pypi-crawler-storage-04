"""Test mock objects."""
