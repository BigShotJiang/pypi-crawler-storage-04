# LangGate Processor

Envoy External Processor for LangGate AI Gateway.

This package provides the gRPC server that implements Envoy's External Processing filter interface, enabling request transformation and routing for the LangGate proxy.
