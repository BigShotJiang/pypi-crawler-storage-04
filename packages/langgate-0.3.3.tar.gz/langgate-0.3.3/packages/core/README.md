# LangGate Core

Core models and utilities for LangGate AI Gateway.

This package contains shared models and utilities used by the LangGate client, registry, and server components. It provides common data structures and functionality needed across the different parts of the LangGate ecosystem.
