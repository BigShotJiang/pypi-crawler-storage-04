Este módulo adapta o módulo 'hrcontract' aos requisitos da Legislação
Brasileira/e-social

- Tipo de adimissão;
- Tipo de contrato de trabalho;
- Motivo de encerramento de contrato;
- Motivo de demissão;
- Tipo de regime previdenciário;
- Sindicato;
- Salário Mínimo;
