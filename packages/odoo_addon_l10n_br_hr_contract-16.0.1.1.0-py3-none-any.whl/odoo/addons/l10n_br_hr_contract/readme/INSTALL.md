Nothing special is needed to install this module
