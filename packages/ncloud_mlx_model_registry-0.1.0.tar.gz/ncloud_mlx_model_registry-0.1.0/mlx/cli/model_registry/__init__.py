#
# ML expert Platform
# Copyright (c) 2025-present NAVER Cloud Corp.
# Apache-2.0
#

from .main import mlx_app

__all__ = ["mlx_app"]
