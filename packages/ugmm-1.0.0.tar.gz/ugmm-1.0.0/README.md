# UGMM - Universal Gun Mod Manager

A plugin-based mod manager that supports multiple games through a JSON configuration system.

## Features

- **Plugin System**: Load and execute plugins from the `plugins/` directory
- **Game Management**: JSON-based game support with automatic Steam detection
- **GUI Interface**: Modern GUI built with CustomTkinter
- **Extensible**: Easy to add new games and plugins

## Installation

1. Install Python dependencies:
```bash
pip install -r requirements.txt
```

2. Run the application:
```bash
python main.py
```

## How It Works

### Game Management
- Games are defined in `supported_games.json`
- The system automatically detects installed Steam games
- Only games listed in the JSON file will appear in the game selector
- Plugins can add/remove games from the supported list

### Plugin System
- Plugins are Python files in the `plugins/` directory
- Each plugin must inherit from `PluginBase`
- Plugins can access the game manager to modify the supported games list
- Plugins receive the selected game's path for execution

### File Structure
```
ugmm/
├── main.py                 # Main application
├── game_selector.py        # Game selection GUI
├── game_manager.py         # JSON game management
├── plugin_loader.py        # Plugin discovery and loading
├── plugin_base.py          # Base plugin class
├── supported_games.json    # Supported games configuration
├── requirements.txt        # Python dependencies
├── plugins/                # Plugin directory
│   ├── mod_manager_plugin.py
│   ├── nexus_mods_plugin.py
│   ├── json_writer_plugin.py
│   └── game_manager_plugin.py
└── README.md
```

## Creating Plugins

Create a new Python file in the `plugins/` directory:

```python
from plugin_base import PluginBase

class Plugin(PluginBase):
    def __init__(self):
        super().__init__()
        self.name = "My Plugin"
        self.description = "Description of what this plugin does"
        self.version = "1.0.0"
        self.required_game_id = None  # Set to specific AppID if needed
        
    def execute(self, *args, **kwargs):
        # Your plugin logic here
        print(f"Running {self.name} for game at: {self.game_path}")
        return True
        
    def validate(self) -> bool:
        # Validate if plugin can run
        return True
```

## Game Manager Plugin

The included `game_manager_plugin.py` provides a GUI for managing the supported games list. You can:

- Add new games to the supported list
- Remove games from the supported list
- View all currently supported games

## Adding Games

Games can be added in several ways:

1. **Manually edit `supported_games.json`**:
```json
{
  "name": "Game Name",
  "appid": 123456,
  "launcher": "steam",
  "vdf_number": 123456,
  "description": "Game description"
}
```

2. **Use the Game Manager Plugin**: Run the "Game Manager Plugin" from the main application

3. **Programmatically via plugins**: Use `self.game_manager.add_game()` in your plugins

## Supported Game Properties

- `name`: Display name of the game
- `appid`: Steam AppID
- `launcher`: Game launcher (currently supports "steam")
- `vdf_number`: VDF file number (usually same as AppID)
- `description`: Game description
