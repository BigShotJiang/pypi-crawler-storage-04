.. These are examples of badges you might want to add to your README:
   please update the URLs accordingly

    .. image:: https://api.cirrus-ci.com/github/<USER>/symbolify.svg?branch=main
        :alt: Built Status
        :target: https://cirrus-ci.com/github/<USER>/symbolify
    .. image:: https://readthedocs.org/projects/symbolify/badge/?version=latest
        :alt: ReadTheDocs
        :target: https://symbolify.readthedocs.io/en/stable/
    .. image:: https://img.shields.io/coveralls/github/<USER>/symbolify/main.svg
        :alt: Coveralls
        :target: https://coveralls.io/r/<USER>/symbolify
    .. image:: https://img.shields.io/pypi/v/symbolify.svg
        :alt: PyPI-Server
        :target: https://pypi.org/project/symbolify/
    .. image:: https://img.shields.io/conda/vn/conda-forge/symbolify.svg
        :alt: Conda-Forge
        :target: https://anaconda.org/conda-forge/symbolify
    .. image:: https://pepy.tech/badge/symbolify/month
        :alt: Monthly Downloads
        :target: https://pepy.tech/project/symbolify
    .. image:: https://img.shields.io/twitter/url/http/shields.io.svg?style=social&label=Twitter
        :alt: Twitter
        :target: https://twitter.com/symbolify

.. image:: https://img.shields.io/badge/-PyScaffold-005CA0?logo=pyscaffold
    :alt: Project generated with PyScaffold
    :target: https://pyscaffold.org/

|

=========
symbolify
=========


    Add a short description here!


A longer description of your project goes here...


.. _pyscaffold-notes:

Note
====

This project has been set up using PyScaffold 4.6. For details and usage
information on PyScaffold see https://pyscaffold.org/.
