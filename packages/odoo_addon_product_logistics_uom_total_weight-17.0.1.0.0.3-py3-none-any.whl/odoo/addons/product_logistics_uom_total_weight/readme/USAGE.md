To see this new field is available in that views:

-  Go to Inventory \> Products. You will see in kanban view and tree view the new field
-  Go to Inventory \> Reporting \> Stock. 
