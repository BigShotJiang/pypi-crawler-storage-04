"""
Command Line Interface for pytopspeed modernized library

This module provides a comprehensive CLI for converting TopSpeed database files
to SQLite and back, with support for .phd, .mod, .tps, and .phz files.
"""

__version__ = "1.0.0"
__author__ = "pytopspeed modernized"