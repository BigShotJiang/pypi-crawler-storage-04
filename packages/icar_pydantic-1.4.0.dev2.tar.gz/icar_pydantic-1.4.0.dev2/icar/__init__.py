"""``ICAR`` pydantic models."""

name = "icar"

VERSION = (1, 4, 0, "dev2")

__version__ = ".".join(str(v) for v in VERSION)
