version_info = (0, 1, '1')

__version__ = ".".join([str(x) for x in version_info])