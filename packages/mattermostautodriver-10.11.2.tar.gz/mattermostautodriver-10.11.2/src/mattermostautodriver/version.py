full_version = "10.11.2"
short_version = ".".join(full_version.split(".", 2)[:2])
