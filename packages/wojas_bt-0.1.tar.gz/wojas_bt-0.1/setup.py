from setuptools import setup, find_packages

setup(
    name="wojas_bt",
    version="0.1",
    description="Create a beautiful text easily in python with wojas beautiful text",
    author="W0jas",
    packages=find_packages(),
    python_requires=">=3.7",
    install_requires=[
        
    ],  # brak dodatkowych zależności
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
)
