from .main import rainbow_animate

# Import wszystkich gradientów
from .main import (
    red_normal, red_bold, red_italic,
    green_normal, green_bold, green_italic,
    blue_normal, blue_bold, blue_italic,
    yellow_normal, yellow_bold, yellow_italic,
    orange_normal, orange_bold, orange_italic,
    pink_normal, pink_bold, pink_italic,
    purple_normal, purple_bold, purple_italic,
    cyan_normal, cyan_bold, cyan_italic,
    magenta_normal, magenta_bold, magenta_italic,
    lime_normal, lime_bold, lime_italic,
    aqua_normal, aqua_bold, aqua_italic,
    gold_normal, gold_bold, gold_italic,
    silver_normal, silver_bold, silver_italic,
    brown_normal, brown_bold, brown_italic,
    teal_normal, teal_bold, teal_italic,
    indigo_normal, indigo_bold, indigo_italic,
    grey_normal, grey_bold, grey_italic,
    white_normal, white_bold, white_italic
)
