from pyzill.details import get_from_home_id, get_from_deparment_id, get_from_deparment_url, get_from_home_url
from pyzill.search import for_sale,for_rent,sold
from pyzill.utils import parse_proxy
