"""
inverse_laplace - Numerical Inverse Laplace Transform using Talbot's Method.

This module provides efficient computation of the inverse Laplace transform using Talbot’s method,
suitable for engineering, physics, and mathematical applications.

Dependencies:
    - sympy
    - mpmath
"""

import sympy as sp
import mpmath
from functools import lru_cache
from multiprocessing import Pool, cpu_count

t, s = sp.symbols('t s', real=True)

@lru_cache(maxsize=None)
def get_lambdified_func(F):
    return sp.lambdify(s, F, 'mpmath')

def inverse_laplace(F, t_val):
    if t_val <= 0:
        return 0.0
    F_func = get_lambdified_func(F)
    return float(mpmath.invertlaplace(F_func, t_val, method='talbot'))

def pretty_ilaplace(X, s, t, prec=34):
    f = inverse_laplace(F, t_val)
    f = f.subs(sp.Heaviside(t), 1)
    f = f.subs(sp.cos(sp.I*t/2), sp.cosh(t/2))
    f = sp.simplify(f.subs(sp.cosh(t/2) - sp.sinh(t/2), sp.exp(-t/2)))
    f = sp.expand_trig(f)
    f = sp.simplify(f)    
    f_num = sp.N(f, prec)
    omegas = [a for a in f_num.atoms(sp.sqrt)]
    if omegas:
        a = sp.N(omegas[0]/2, prec)  # معمولا sqrt(...) / 2
    else:
        # fallback: از terms استخراج فرکانس
        a = None

    if a is not None:
        g = sp.simplify(sp.expand(f_num / sp.exp(-t/2)))
        A = sp.N(g.coeff(sp.cos(a*t), 1), prec)
        B = sp.N(g.coeff(sp.sin(a*t), 1), prec)

        prefactor = A
        inner_sin_coeff = sp.N(B / prefactor, prec)

        return sp.N(prefactor, prec) * sp.exp(-t/2) * (
            sp.cos(sp.N(a, prec)*t) + sp.N(inner_sin_coeff, prec)*sp.sin(sp.N(a, prec)*t)
        )
    else:
        return f_num


# Public API
__all__ = ['inverse_laplace', 'pretty_ilaplace']
