if __name__ == "__main__":
    from dcqc.main import app

    app(prog_name="dcqc")
