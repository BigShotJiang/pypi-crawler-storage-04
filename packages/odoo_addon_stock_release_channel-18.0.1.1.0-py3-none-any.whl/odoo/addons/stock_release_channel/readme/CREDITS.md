**Financial support**

- Cosanum
- Camptocamp R&D
