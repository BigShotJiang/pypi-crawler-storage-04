In Inventory \> Configuration \> Release Channels. Only Stock Managers
have write permissions.
