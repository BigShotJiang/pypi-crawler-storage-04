from dataclasses import dataclass


@dataclass
class TipSpecification:
    name: str
    color: str
