This directory stores the result of compiling the figures.
