# mcpbytes-lambda-core tests
