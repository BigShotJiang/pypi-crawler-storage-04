# 是否在 HiSilicon 3559 上运行
HISI3559 = False

# 是否在 Atlas 上运行
ATLAS = False

# 是否在 HiSilicon 3403 上运行
HISI3403 = False

# 是否在 HiSilicon 3519 上运行
HISI3519 = False

# 图像宽度
w = 0

# 图像高度
h = 0

# 置信度阈值
conf_thres = 0.20

# IOU阈值
iou_thres = 0.45