"""Global constants for Freight."""

CONTRACT_LIST_USER = "user"
CONTRACT_LIST_ACTIVE = "active"
CONTRACT_LIST_ALL = "all"

AVATAR_SIZE = 128
