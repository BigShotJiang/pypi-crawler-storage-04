"""Main entry point for Taman system monitor."""

from .cli import main


if __name__ == "__main__":
    main()
