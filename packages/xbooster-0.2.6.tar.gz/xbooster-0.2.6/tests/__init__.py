"""
__init__.py
Description: This module tests all the explainer types.
"""

import matplotlib

matplotlib.use("Agg")
