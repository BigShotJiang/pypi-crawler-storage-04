# SET ENV

```bash
uv venv
source .venv/bin/activate
uv sync
```

## Character
1. parse json to Markdown(HTML or Markdown, `.md`) file

## Improvement
1. lines split by '\n' and '\n\n' is different.
2. Sheet cell_value support: trans_word()
3. combination_object: LinkedImage