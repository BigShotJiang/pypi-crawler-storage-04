"""Endpoints package for Gymix API client."""
