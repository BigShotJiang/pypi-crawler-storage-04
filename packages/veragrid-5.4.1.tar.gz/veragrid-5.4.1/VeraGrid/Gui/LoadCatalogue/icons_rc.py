# Resource object code (Python 3)
# Created by: object code
# Created by: The Resource Compiler for Qt version 6.7.2
# WARNING! All changes made in this file will be lost!

from PySide6 import QtCore

qt_resource_data = b"\
\x00\x00\x11U\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   width=\x22\
48\x22\x0a   height=\x224\
8\x22\x0a   viewBox=\x220\
 0 12.7 12.7\x22\x0a  \
 version=\x221.1\x22\x0a \
  id=\x22svg1\x22\x0a   x\
ml:space=\x22preser\
ve\x22\x0a   inkscape:\
version=\x221.3.2 (\
091e20e, 2023-11\
-25, custom)\x22\x0a  \
 sodipodi:docnam\
e=\x22CataloguePriv\
ate.svg\x22\x0a   xmln\
s:inkscape=\x22http\
://www.inkscape.\
org/namespaces/i\
nkscape\x22\x0a   xmln\
s:sodipodi=\x22http\
://sodipodi.sour\
ceforge.net/DTD/\
sodipodi-0.dtd\x22\x0a\
   xmlns=\x22http:/\
/www.w3.org/2000\
/svg\x22\x0a   xmlns:s\
vg=\x22http://www.w\
3.org/2000/svg\x22>\
<sodipodi:namedv\
iew\x0a     id=\x22nam\
edview1\x22\x0a     pa\
gecolor=\x22#ffffff\
\x22\x0a     bordercol\
or=\x22#000000\x22\x0a   \
  borderopacity=\
\x220.25\x22\x0a     inks\
cape:showpagesha\
dow=\x222\x22\x0a     ink\
scape:pageopacit\
y=\x220.0\x22\x0a     ink\
scape:pagechecke\
rboard=\x220\x22\x0a     \
inkscape:deskcol\
or=\x22#d1d1d1\x22\x0a   \
  inkscape:docum\
ent-units=\x22mm\x22\x0a \
    inkscape:zoo\
m=\x2213.118507\x22\x0a  \
   inkscape:cx=\x22\
46.422965\x22\x0a     \
inkscape:cy=\x2223.\
74508\x22\x0a     inks\
cape:window-widt\
h=\x221920\x22\x0a     in\
kscape:window-he\
ight=\x221111\x22\x0a    \
 inkscape:window\
-x=\x222391\x22\x0a     i\
nkscape:window-y\
=\x22-9\x22\x0a     inksc\
ape:window-maxim\
ized=\x221\x22\x0a     in\
kscape:current-l\
ayer=\x22g1\x22 /><def\
s\x0a     id=\x22defs1\
\x22 /><g\x0a     inks\
cape:label=\x22Laye\
r 1\x22\x0a     inksca\
pe:groupmode=\x22la\
yer\x22\x0a     id=\x22la\
yer1\x22><g\x0a       \
id=\x22g1\x22\x0a       t\
ransform=\x22matrix\
(0.26458333,0,0,\
0.26458333,98.54\
8579,142.50107)\x22\
><g\x0a         id=\
\x22g9\x22\x0a         tr\
ansform=\x22matrix(\
1.0914775,0,0,1.\
0914775,31.46110\
6,47.351346)\x22><p\
ath\x0a           s\
odipodi:nodetype\
s=\x22ccccc\x22\x0a      \
     inkscape:co\
nnector-curvatur\
e=\x220\x22\x0a          \
 id=\x22path816-3-7\
\x22\x0a           d=\x22\
m -336.97538,-51\
9.8115 c -4.6142\
9,-1.41608 -9.15\
174,-0.81618 -15\
.69346,1.89795 l\
 -0.1846,19.7815\
 c 7.17161,-2.60\
583 11.54626,-3.\
06716 15.98356,-\
1.84496 z\x22\x0a     \
      style=\x22fil\
l:none;fill-rule\
:evenodd;stroke:\
#999999;stroke-w\
idth:1.83396;str\
oke-linecap:roun\
d;stroke-linejoi\
n:bevel;stroke-m\
iterlimit:4;stro\
ke-dasharray:non\
e;stroke-opacity\
:1\x22 /><path\x0a    \
       sodipodi:\
nodetypes=\x22ccccc\
\x22\x0a           ink\
scape:connector-\
curvature=\x220\x22\x0a  \
         id=\x22pat\
h816-3-7-5\x22\x0a    \
       d=\x22m -368\
.73149,-519.8115\
 c 4.61429,-1.41\
608 9.15174,-0.8\
1618 15.69346,1.\
89795 l 0.18459,\
19.7815 c -7.171\
6,-2.60583 -11.5\
4625,-3.06716 -1\
5.98356,-1.84496\
 z\x22\x0a           s\
tyle=\x22fill:none;\
fill-rule:evenod\
d;stroke:#999999\
;stroke-width:1.\
83396;stroke-lin\
ecap:round;strok\
e-linejoin:bevel\
;stroke-miterlim\
it:4;stroke-dash\
array:none;strok\
e-opacity:1\x22 /><\
text\x0a           \
id=\x22text10\x22\x0a    \
       y=\x2217.491\
526\x22\x0a           \
x=\x2231.84049\x22\x0a   \
        style=\x22f\
ont-style:normal\
;font-weight:nor\
mal;font-size:19\
.5622px;line-hei\
ght:1.25;font-fa\
mily:sans-serif;\
white-space:pre;\
inline-size:0;fi\
ll:#00d4aa;fill-\
opacity:1;stroke\
:none;stroke-wid\
th:0.489054\x22\x0a   \
        xml:spac\
e=\x22preserve\x22\x0a   \
        transfor\
m=\x22translate(-37\
2.2659,-536.7128\
5)\x22><tspan\x0a     \
        style=\x22f\
ill:#00d4aa;stro\
ke-width:0.48905\
4\x22\x0a             \
y=\x2217.491526\x22\x0a  \
           x=\x2231\
.84049\x22\x0a        \
     id=\x22tspan8\x22\
>+</tspan></text\
><g\x0a           i\
d=\x22g8\x22\x0a         \
  transform=\x22mat\
rix(0.38976367,0\
,0,0.38976367,-3\
85.88573,-515.88\
64)\x22><rect\x0a     \
        style=\x22f\
ill:#806600\x22\x0a   \
          id=\x22re\
ct3\x22\x0a           \
  width=\x2220.3747\
54\x22\x0a            \
 height=\x2214.5533\
96\x22\x0a            \
 x=\x2274.160469\x22\x0a \
            y=\x22-\
0.32669878\x22\x0a    \
         ry=\x223.6\
653001\x22 /><rect\x0a\
             sty\
le=\x22fill:#f9f9f9\
;stroke-width:0.\
888332\x22\x0a        \
     id=\x22rect4\x22\x0a\
             wid\
th=\x2214.337787\x22\x0a \
            heig\
ht=\x229.5944614\x22\x0a \
            x=\x227\
7.17897\x22\x0a       \
      y=\x222.47620\
27\x22\x0a            \
 rx=\x222.7719724\x22\x0a\
             ry=\
\x222.6864493\x22 /><r\
ect\x0a            \
 style=\x22fill:#80\
6600\x22\x0a          \
   id=\x22rect2\x22\x0a  \
           width\
=\x2227.381941\x22\x0a   \
          height\
=\x2225.657099\x22\x0a   \
          x=\x2270.\
602997\x22\x0a        \
     y=\x2210.23797\
7\x22\x0a             \
ry=\x224.6355262\x22 /\
><ellipse\x0a      \
       style=\x22fi\
ll:#f9f9f9\x22\x0a    \
         id=\x22pat\
h6\x22\x0a            \
 cx=\x2284.401756\x22\x0a\
             cy=\
\x2219.940264\x22\x0a    \
         rx=\x223.4\
496939\x22\x0a        \
     ry=\x223.39579\
25\x22 /><path\x0a    \
         style=\x22\
fill:#f9f9f9\x22\x0a  \
           d=\x22m \
83.679842,21.833\
362 -3.6114,7.33\
06 4.15041,-0.05\
39 0.32341,-8.24\
693 z\x22\x0a         \
    id=\x22path7\x22 /\
><path\x0a         \
    style=\x22fill:\
#f9f9f9\x22\x0a       \
      d=\x22m 85.13\
1243,21.833776 3\
.6114,7.3306 -4.\
15041,-0.0539 -0\
.32341,-8.24693 \
z\x22\x0a             \
id=\x22path7-4\x22 /><\
rect\x0a           \
  style=\x22fill:#f\
9f9f9;stroke-wid\
th:0.833794\x22\x0a   \
          id=\x22re\
ct7\x22\x0a           \
  width=\x222.17343\
45\x22\x0a            \
 height=\x226.14476\
73\x22\x0a            \
 x=\x2283.305809\x22\x0a \
            y=\x222\
2.977808\x22\x0a      \
       rx=\x220.843\
14221\x22\x0a         \
    ry=\x220\x22 /></g\
></g></g></g></s\
vg>\x0a\
"

qt_resource_name = b"\
\x00\x05\
\x00O\xa6S\
\x00I\
\x00c\x00o\x00n\x00s\
\x00\x05\
\x00o\xa6S\
\x00i\
\x00c\x00o\x00n\x00s\
\x00\x14\
\x0dK\x88'\
\x00C\
\x00a\x00t\x00a\x00l\x00o\x00g\x00u\x00e\x00P\x00r\x00i\x00v\x00a\x00t\x00e\x00.\
\x00s\x00v\x00g\
"

qt_resource_struct = b"\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x01\x00\x00\x00\x01\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x01\x00\x00\x00\x02\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x10\x00\x02\x00\x00\x00\x01\x00\x00\x00\x03\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00 \x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\
\x00\x00\x01\x93\x1a\x9etr\
"

def qInitResources():
    QtCore.qRegisterResourceData(0x03, qt_resource_struct, qt_resource_name, qt_resource_data)

def qCleanupResources():
    QtCore.qUnregisterResourceData(0x03, qt_resource_struct, qt_resource_name, qt_resource_data)

qInitResources()
