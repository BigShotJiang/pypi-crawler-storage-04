# Resource object code (Python 3)
# Created by: object code
# Created by: The Resource Compiler for Qt version 6.7.2
# WARNING! All changes made in this file will be lost!

from PySide6 import QtCore

qt_resource_data = b"\
\x00\x00\x0dZ\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   xmlns:d\
c=\x22http://purl.o\
rg/dc/elements/1\
.1/\x22\x0a   xmlns:cc\
=\x22http://creativ\
ecommons.org/ns#\
\x22\x0a   xmlns:rdf=\x22\
http://www.w3.or\
g/1999/02/22-rdf\
-syntax-ns#\x22\x0a   \
xmlns:svg=\x22http:\
//www.w3.org/200\
0/svg\x22\x0a   xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22\x0a   \
xmlns:sodipodi=\x22\
http://sodipodi.\
sourceforge.net/\
DTD/sodipodi-0.d\
td\x22\x0a   xmlns:ink\
scape=\x22http://ww\
w.inkscape.org/n\
amespaces/inksca\
pe\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg2\
\x22\x0a   width=\x22192\x22\
\x0a   height=\x22192\x22\
\x0a   viewBox=\x220 0\
 192 192\x22\x0a   sod\
ipodi:docname=\x22g\
ear.svg\x22\x0a   inks\
cape:version=\x220.\
92.2 (5c3e80d, 2\
017-08-06)\x22>\x0a  <\
metadata\x0a     id\
=\x22metadata8\x22>\x0a  \
  <rdf:RDF>\x0a    \
  <cc:Work\x0a     \
    rdf:about=\x22\x22\
>\x0a        <dc:fo\
rmat>image/svg+x\
ml</dc:format>\x0a \
       <dc:type\x0a\
           rdf:r\
esource=\x22http://\
purl.org/dc/dcmi\
type/StillImage\x22\
 />\x0a        <dc:\
title />\x0a      <\
/cc:Work>\x0a    </\
rdf:RDF>\x0a  </met\
adata>\x0a  <defs\x0a \
    id=\x22defs6\x22 /\
>\x0a  <sodipodi:na\
medview\x0a     pag\
ecolor=\x22#ffffff\x22\
\x0a     bordercolo\
r=\x22#666666\x22\x0a    \
 borderopacity=\x22\
1\x22\x0a     objectto\
lerance=\x2210\x22\x0a   \
  gridtolerance=\
\x2210\x22\x0a     guidet\
olerance=\x2210\x22\x0a  \
   inkscape:page\
opacity=\x220\x22\x0a    \
 inkscape:pagesh\
adow=\x222\x22\x0a     in\
kscape:window-wi\
dth=\x22784\x22\x0a     i\
nkscape:window-h\
eight=\x22480\x22\x0a    \
 id=\x22namedview4\x22\
\x0a     showgrid=\x22\
false\x22\x0a     inks\
cape:zoom=\x221.229\
1667\x22\x0a     inksc\
ape:cx=\x22-47.9999\
97\x22\x0a     inkscap\
e:cy=\x2296.000003\x22\
\x0a     inkscape:w\
indow-x=\x2257\x22\x0a   \
  inkscape:windo\
w-y=\x2227\x22\x0a     in\
kscape:window-ma\
ximized=\x220\x22\x0a    \
 inkscape:curren\
t-layer=\x22svg2\x22 /\
>\x0a  <path\x0a     s\
tyle=\x22fill:#9999\
99;stroke-width:\
1.33333337\x22\x0a    \
 d=\x22m 77.685212,\
176.62546 c -0.3\
6495,-0.59051 -1\
.359378,-6.15571\
 -2.20984,-12.36\
712 -0.85046,-6.\
21142 -1.647284,\
-11.29448 -1.770\
72,-11.2957 -0.2\
92876,-0.003 -8.\
928958,-4.7575 -\
11.737142,-6.461\
93 -1.605474,-0.\
97444 -5.033267,\
-0.14448 -13.016\
802,3.15168 -6.6\
91473,2.76271 -1\
1.300681,3.99631\
 -12.048381,3.22\
459 -2.638601,-2\
.72336 -17.42210\
1,-29.37153 -17.\
422101,-31.4044 \
0,-1.19223 3.885\
057,-5.09518 8.6\
3346,-8.67324 l \
8.63346,-6.50555\
 v -8.666671 -8.\
666667 l -8.6334\
6,-6.505556 c -4\
.748403,-3.57805\
6 -8.63346,-7.48\
1016 -8.63346,-8\
.673242 0,-2.039\
252 14.78798,-28\
.686171 17.43578\
9,-31.41809 0.76\
5807,-0.790132 5\
.266256,0.388912\
 12.011621,3.146\
851 10.735632,4.\
389415 10.808082\
,4.399033 15.223\
394,2.021232 9.2\
26118,-4.968593 \
9.854293,-5.9181\
76 11.40331,-17.\
237861 0.802812,\
-5.866667 1.9121\
58,-11.134266 2.\
465212,-11.70577\
5 0.553056,-0.57\
1509 9.357958,-0\
.871509 19.56645\
2,-0.666667 l 18\
.560886,0.372442\
 2,11.741416 2,1\
1.741416 6.3294,\
3.92525 c 3.4811\
7,2.158888 6.792\
53,3.925251 7.35\
858,3.925251 0.5\
6605,0 5.41918,-\
1.844483 10.7847\
4,-4.098851 5.36\
556,-2.254369 10\
.45926,-3.828818\
 11.31934,-3.498\
777 2.03324,0.78\
0228 18.20794,29\
.028695 18.20794\
,31.799445 0,1.1\
66222 -3.88505,5\
.047904 -8.63345\
,8.62596 l -8.63\
347,6.505556 v 8\
.666667 8.666671\
 l 8.63347,6.505\
55 c 4.7484,3.57\
806 8.63345,7.48\
101 8.63345,8.67\
324 0,2.03287 -1\
4.7835,28.68104 \
-17.4221,31.4044\
 -0.74772,0.7717\
4 -5.29872,-0.43\
786 -11.89703,-3\
.1621 l -10.6860\
6,-4.41197 -7.21\
862,3.77944 -7.2\
1861,3.77943 -1.\
77879,12.04933 -\
1.77879,12.04933\
 -18.899066,0.36\
932 c -10.394484\
,0.20314 -19.197\
66,-0.11386 -19.\
562612,-0.7043 z\
 m 29.504508,-53\
.06908 c 14.6252\
1,-6.10929 21.57\
602,-23.26646 15\
.09602,-37.26259\
4 -10.20217,-22.\
03565 -40.74219,\
-22.03565 -50.94\
4364,0 -10.32964\
1,22.310974 13.1\
68754,46.736394 \
35.848344,37.262\
594 z\x22\x0a     id=\x22\
path817\x22\x0a     in\
kscape:connector\
-curvature=\x220\x22 /\
>\x0a</svg>\x0a\
\x00\x00\x08K\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   xmlns:d\
c=\x22http://purl.o\
rg/dc/elements/1\
.1/\x22\x0a   xmlns:cc\
=\x22http://creativ\
ecommons.org/ns#\
\x22\x0a   xmlns:rdf=\x22\
http://www.w3.or\
g/1999/02/22-rdf\
-syntax-ns#\x22\x0a   \
xmlns:svg=\x22http:\
//www.w3.org/200\
0/svg\x22\x0a   xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22\x0a   \
xmlns:sodipodi=\x22\
http://sodipodi.\
sourceforge.net/\
DTD/sodipodi-0.d\
td\x22\x0a   xmlns:ink\
scape=\x22http://ww\
w.inkscape.org/n\
amespaces/inksca\
pe\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg2\
\x22\x0a   width=\x22192\x22\
\x0a   height=\x22192\x22\
\x0a   viewBox=\x220 0\
 192 192\x22\x0a   sod\
ipodi:docname=\x22d\
elete.svg\x22\x0a   in\
kscape:version=\x22\
0.92.2 (5c3e80d,\
 2017-08-06)\x22>\x0a \
 <metadata\x0a     \
id=\x22metadata8\x22>\x0a\
    <rdf:RDF>\x0a  \
    <cc:Work\x0a   \
      rdf:about=\
\x22\x22>\x0a        <dc:\
format>image/svg\
+xml</dc:format>\
\x0a        <dc:typ\
e\x0a           rdf\
:resource=\x22http:\
//purl.org/dc/dc\
mitype/StillImag\
e\x22 />\x0a        <d\
c:title />\x0a     \
 </cc:Work>\x0a    \
</rdf:RDF>\x0a  </m\
etadata>\x0a  <defs\
\x0a     id=\x22defs6\x22\
 />\x0a  <sodipodi:\
namedview\x0a     p\
agecolor=\x22#fffff\
f\x22\x0a     borderco\
lor=\x22#666666\x22\x0a  \
   borderopacity\
=\x221\x22\x0a     object\
tolerance=\x2210\x22\x0a \
    gridtoleranc\
e=\x2210\x22\x0a     guid\
etolerance=\x2210\x22\x0a\
     inkscape:pa\
geopacity=\x220\x22\x0a  \
   inkscape:page\
shadow=\x222\x22\x0a     \
inkscape:window-\
width=\x22784\x22\x0a    \
 inkscape:window\
-height=\x22480\x22\x0a  \
   id=\x22namedview\
4\x22\x0a     showgrid\
=\x22false\x22\x0a     in\
kscape:zoom=\x221.2\
291667\x22\x0a     ink\
scape:cx=\x22-47.99\
9997\x22\x0a     inksc\
ape:cy=\x2296.00000\
3\x22\x0a     inkscape\
:window-x=\x2257\x22\x0a \
    inkscape:win\
dow-y=\x2227\x22\x0a     \
inkscape:window-\
maximized=\x220\x22\x0a  \
   inkscape:curr\
ent-layer=\x22svg2\x22\
 />\x0a  <path\x0a    \
 style=\x22fill:#99\
9999;stroke-widt\
h:1.33333337\x22\x0a  \
   d=\x22M 44.01994\
,147.1665 38.367\
572,141.51412 60\
.68885,119.16384\
 83.010129,96.81\
3559 60.68885,74\
.463272 38.36757\
2,52.112986 44.0\
1994,46.460618 4\
9.672308,40.8082\
5 72.022594,63.1\
29528 94.372885,\
85.450807 116.72\
318,63.129528 13\
9.07346,40.80825\
 l 5.65238,5.652\
368 5.65236,5.65\
2368 -22.32128,2\
2.350286 -22.321\
28,22.350287 22.\
32128,22.350281 \
22.32128,22.3502\
8 -5.65236,5.652\
38 -5.65238,5.65\
236 -22.35028,-2\
2.32128 -22.3502\
95,-22.32127 -22\
.350291,22.32127\
 -22.350286,22.3\
2128 z\x22\x0a     id=\
\x22path817\x22\x0a     i\
nkscape:connecto\
r-curvature=\x220\x22 \
/>\x0a</svg>\x0a\
\x00\x00\x08\x1f\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   xmlns:d\
c=\x22http://purl.o\
rg/dc/elements/1\
.1/\x22\x0a   xmlns:cc\
=\x22http://creativ\
ecommons.org/ns#\
\x22\x0a   xmlns:rdf=\x22\
http://www.w3.or\
g/1999/02/22-rdf\
-syntax-ns#\x22\x0a   \
xmlns:svg=\x22http:\
//www.w3.org/200\
0/svg\x22\x0a   xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22\x0a   \
xmlns:sodipodi=\x22\
http://sodipodi.\
sourceforge.net/\
DTD/sodipodi-0.d\
td\x22\x0a   xmlns:ink\
scape=\x22http://ww\
w.inkscape.org/n\
amespaces/inksca\
pe\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg2\
\x22\x0a   width=\x22192\x22\
\x0a   height=\x22192\x22\
\x0a   viewBox=\x220 0\
 192 192\x22\x0a   sod\
ipodi:docname=\x22e\
dit.svg\x22\x0a   inks\
cape:version=\x220.\
92.2 (5c3e80d, 2\
017-08-06)\x22>\x0a  <\
metadata\x0a     id\
=\x22metadata8\x22>\x0a  \
  <rdf:RDF>\x0a    \
  <cc:Work\x0a     \
    rdf:about=\x22\x22\
>\x0a        <dc:fo\
rmat>image/svg+x\
ml</dc:format>\x0a \
       <dc:type\x0a\
           rdf:r\
esource=\x22http://\
purl.org/dc/dcmi\
type/StillImage\x22\
 />\x0a        <dc:\
title />\x0a      <\
/cc:Work>\x0a    </\
rdf:RDF>\x0a  </met\
adata>\x0a  <defs\x0a \
    id=\x22defs6\x22 /\
>\x0a  <sodipodi:na\
medview\x0a     pag\
ecolor=\x22#ffffff\x22\
\x0a     bordercolo\
r=\x22#666666\x22\x0a    \
 borderopacity=\x22\
1\x22\x0a     objectto\
lerance=\x2210\x22\x0a   \
  gridtolerance=\
\x2210\x22\x0a     guidet\
olerance=\x2210\x22\x0a  \
   inkscape:page\
opacity=\x220\x22\x0a    \
 inkscape:pagesh\
adow=\x222\x22\x0a     in\
kscape:window-wi\
dth=\x221863\x22\x0a     \
inkscape:window-\
height=\x221025\x22\x0a  \
   id=\x22namedview\
4\x22\x0a     showgrid\
=\x22false\x22\x0a     in\
kscape:zoom=\x222.4\
583333\x22\x0a     ink\
scape:cx=\x2225.852\
3\x22\x0a     inkscape\
:cy=\x22102.01301\x22\x0a\
     inkscape:wi\
ndow-x=\x2257\x22\x0a    \
 inkscape:window\
-y=\x2227\x22\x0a     ink\
scape:window-max\
imized=\x221\x22\x0a     \
inkscape:current\
-layer=\x22svg2\x22 />\
\x0a  <path\x0a     st\
yle=\x22fill:#99999\
9;stroke:#999999\
;stroke-width:1.\
33333337\x22\x0a     d\
=\x22M 24.40678,148\
.92473 V 133.917\
28 L 68.754672,8\
9.5842 113.10257\
,45.251123 l 14.\
97875,15.021359 \
14.97874,15.0213\
6 -44.333988,44.\
319178 -44.334,4\
4.31918 H 39.399\
422 24.40678 Z m\
 112.28181,-97.3\
56802 -15.0515,-\
15.114105 8.6027\
7,-8.260811 c 5.\
40008,-5.185426 \
9.73241,-8.26080\
9 11.63711,-8.26\
0809 4.22102,0 2\
6.52981,22.33462\
4 26.52981,26.56\
0551 0,1.957621 \
-3.01092,6.15863\
2 -8.33333,11.62\
7168 l -8.33334,\
8.562112 z\x22\x0a    \
 id=\x22path817\x22\x0a  \
   inkscape:conn\
ector-curvature=\
\x220\x22 />\x0a</svg>\x0a\
\x00\x00\x04\xe2\
\x00\
\x00\x1fzx\xda\xedYYo\xdbF\x10~\xf7\xaf`\
\x99\x97\x04-\x97{q\x0fVr\x80\xd6\x08\x90\xd76\
E\x9fire1\xa6\xb8\x02I[v~}g)\
\x9e>\x00\xd9\x0e\x90\x14\xa0\x0c?\xcc\xb5\xbb\xf3}\xb3\
3\xa4\xb4\xfax\xb7+\xbc[S\xd5\xb9-\xd7>A\
\xd8\xf7L\x99\xda,/\xaf\xd6\xfe?_>\x05\xca\xf7\
\xea&)\xb3\xa4\xb0\xa5Y\xfb\xa5\xf5?\x9e\x9f\xad~\
\x09\x02\xef\xcf\xca$\x8d\xc9\xbcC\xdel\xbd\xcf\xe5u\
\x9d&{\xe3\xbd\xdf6\xcd>\x0e\xc3\xc3\xe1\x80\xf2N\
\x89lu\x15~\xf0\x82\xe0\xfc\xeclU\xdf^\x9dy\
\x9e\x07\xfb\x96u\x9c\xa5k\xbf\x0b\xd8\xdfTE\xeb\x98\
\xa5\xa1)\xcc\xce\x94M\x1d\x12DB\x7ftOG\xf7\
\xd4\xed\x9e\xdf\x9a\xd4\xeev\xb6\xac\xdb\xc8\xb2~7q\
\xae\xb2\xcd\xe0\xedNs`\xad\x13\xd1Z\x87\x98\x86\x94\
\x06\xe0\x11\xd4\xf7e\x93\xdc\x05\xf3P8\xe3S\xa1\x14\
c\x1c\x82m\xf4<\xcd+\xae\x01\xd0=\xfc\x0f\xee\xbd\
\x02\xd5\xf6\xa6J\xcd\x06\xe2\x0c*M\x13^|\xb9\x18\
\x8c\x01FY\x93M\x96\xe9\xf1\x9c\xed:\x03\xb9Lv\
\xa6\xde'\xa9\xa9\xc3^\xdf\xc6O\x18&\xad\x22\xcf\xd6\
>\x9c\x91\xb6\xc2!\xcf\x9a-\xd8\xf4Q\xdc\x9a\xfcj\
\xdb\x8c\xf2mn\x0e\x7f\xd8\xbb\xb5\x8f=\xec\x81\xd2\xeb\
\x0d\xfdA\xe3\xcc\xa6n\xe7\xb5\x9f&E\x8a\xfa\xdc\xfb\
\x13\xc4\xc3\xee\x18i\x8a\x98\xf7\x9er\x1cE\x5c\xfc\xe6\
QLT\x80Y@\xc8\x07\xff\x1cbV;\xd3$Y\
\xd2$.\xfex\xca^\xa3Z\x07p\x01\xd6\xe2\xbf.\
>\x1d%\x90\xd34\xfe\xd7V\xd7\x9d\x08\x1f\xe7\x90\x5c\
\xda\x1bH\xc1?\x1f\xd4\xab,\x8d\x01\xe7]\xd2\x9c\xe7\
\xbb\xe4\xca8\x8a~\x05\x5cW\xe1h\x9897\xf7{\
3.z\x5c\xb62G\xc2\x9e\xac\xda,\xdd\xe5.(\
\xfc\xbb\xc9\x8b\xe2\xb3\xdb\xc4\xf7\xc2\x07\x8b\xe6MaF\
\xe5*\xecN\xdf\xe5\x16N\x92[\x85}\xea\xad\x94\x99\
M=\xa2\xe2$\xd1\xad\xbe\x1axp$d\x8e\xae\xa3\
\xe3\x1eN\x90\xda\xc2Vk\xff\xdd\xa6\xfd\xf8G\xc3\xa5\
\xad2S\xf5&\xd1~f&\x0b5\x04\xb9@\x0dt\
j{\xf9\xd5\xa4Mc\x0bS%\xa5\xcb\x9f\xe0\xcer\
UA\xf5<\xa5\xbf\xc93\xf3\x94a(\x0bw\xbca\
\xa3'\xad\xf56\xc9\xeca\xed\xd3\x87\xc6C^\x82!\
\xe8\x0bW\x09\xf6\x8c\xc7P\xcb\x98F\xfe\x08\xdf\x00\x14\
\xef\x94\xf5\xd6\x1e\x5c&k\x7f\x93\x14\xb5y\xb8\xda7\
kwk\x9f!\xa6\xb1\x18\x17\xea\xad)\xdc\x8d\x081\
\x1aI\xa5\xf9#\xa3C\x11k\xc4\x84\xe4\xf2\x99S\xba\
\xf8\xe7l\x10N\x9f\xb3\xed\x92\xbb|\x97\x7f3\xd9H\
\xd4\xb8\xefMUA\x0f\x0d\x8a\xe4\xdeT\xdde\xef\xea\
\xa5\x02*\xbb\xb4\x9b\xfb\x02\xb8\xe9X\x88\xc9\xef\x1b\xa8\
\xdc\xf8\x1d\x93\xa9J.[!\x18muS\xd9k3\
X\x8f\xe2\x91\x83X\xf4b\x91\x97\x06\xf6\x8f+{S\
fS\xe5W\x9b\x97\xf1\xa5\xb95E\xaf\x85\xdbb\xaa\
\x02\x12hb\xde\xeb\xb2\x048\xaf\xaa\xe4>.a\xde\
L\xb5v\xb3\xa9M\x13\xe3^7\x9ek\x9f\xe4\x90g\
[\xb7\x10\x05\x17\xb9\x980\xedrU\xa4/\xa0\xbe`\
\x18E\x82`\xd2\xe3:TI\xa4\x11\x8f\xe4PM\xc0\
\x0b\x03\xd2\xa3H\xd3^\xe5\xd8\x94\x08+>\xb2Y9\
\x1dG\x82s,\xd4\xc9\x18\x1f/\xe43\x18O\x93?\
\x02\xac\x90\xc0\x9a\x0b\x22\xd5\xcf\x8d4\x7f\x80\xb4D\x9c\
i\xcd\xf4#\xa4\x11\x95\x9a\x00^\x03\xd2\x5c\x22\xcd\x09\
\x0c\x86\x09\xd2\x18#\x220\xa5\x13\xa4)\xc2\x82\x09\x11\
\x0d\xba;7\xd5\xb4\xc0\x5c\xe1\x05\xfd\x80\xbd\x1a\x7f\xc9\
\x91\x92\xd0\xc1\xe8\x1c\x7f\x06E\xbd\xe0\x7f2\xfe\xe2\xd5\
\xf8C?B\xb0\x82ds\xfcy\xc48_\xf0?\x15\
\x7f\xf9\xa6\xfe#\xe1o\x02?\x851\xa1\x16\xf8_\xd2\
~\x82\xe8-\x0d\x08\x14\x82\x8a9\x03\x8aa,\x16\x06\
Nn@o\x18\x01m\x0b\x82~\x13\xcd\x19\xd0R\x08\
\xb90p*\x03\xd1\xf7lA\x5c \xc2#\xce\x16\xf8\
OoA\xe2\xbb\xb6 `\x80j\x8a\x97!\xf0\x82\x16\
D\xbfk\x0b\x02\x068S\xe2\x873@\x15\x22\x94)\
\xceI\xf4\xf3S\xa0\x1fP\x80#\xa8\x1f\xa5\x1eR@\
\x05\xd2\x94\x13\xca']H\xa0\x88`\xa6\xe4H\x01\xc3\
\xf0z+1\xd6\x13\x0a\x18\x02\x068\xd07\xa5\x00\xc8\
\x93Dq\xb2\x5c\x02\xf2\xfa)\x00e\xa6\x84\x92|\xc4\
\x1f\xfa\x12'*\x22jiB\xa7\x8f\x81\xd77!\x19\
\xb9\x8b.\x09\x991\x10\x89\x88\xb0\xe5U\xf8\x05=H\
\xbea\x0c8pq4\xbf\x03\xc0\x88dza\xe0\x05\
\x0c\x04\xf8\xf5\x1cP\x0d\x8dHGz\xc6\x01e0.\
\x96\x87\xa1\x97q\xf0h\x1a\xbf\x8c\x05\xec@\x9f\x7f-\
\xa4\xb8\x1e\x9e\x91~\x18\x0b\xc4=\x03h)9\xa3\xff\
\x0f\x1aN|5f\x0a1\xae\xe5\xf0\xb3AK\x83B\
\x0a\x1a\x92\x9a\xbe\x1a3x7#\xb3o\xa7apH\
-\x04\x17\xcf\xd2\xb0r?<\x9e\x9f\xfd\x07\xdbX\x80\
\xb4\
\x00\x00\x07\xa0\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   xmlns:d\
c=\x22http://purl.o\
rg/dc/elements/1\
.1/\x22\x0a   xmlns:cc\
=\x22http://creativ\
ecommons.org/ns#\
\x22\x0a   xmlns:rdf=\x22\
http://www.w3.or\
g/1999/02/22-rdf\
-syntax-ns#\x22\x0a   \
xmlns:svg=\x22http:\
//www.w3.org/200\
0/svg\x22\x0a   xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22\x0a   \
xmlns:sodipodi=\x22\
http://sodipodi.\
sourceforge.net/\
DTD/sodipodi-0.d\
td\x22\x0a   xmlns:ink\
scape=\x22http://ww\
w.inkscape.org/n\
amespaces/inksca\
pe\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg2\
\x22\x0a   width=\x22192\x22\
\x0a   height=\x22192\x22\
\x0a   viewBox=\x220 0\
 192 192\x22\x0a   sod\
ipodi:docname=\x22m\
inus.svg\x22\x0a   ink\
scape:version=\x220\
.92.2 (5c3e80d, \
2017-08-06)\x22>\x0a  \
<metadata\x0a     i\
d=\x22metadata8\x22>\x0a \
   <rdf:RDF>\x0a   \
   <cc:Work\x0a    \
     rdf:about=\x22\
\x22>\x0a        <dc:f\
ormat>image/svg+\
xml</dc:format>\x0a\
        <dc:type\
\x0a           rdf:\
resource=\x22http:/\
/purl.org/dc/dcm\
itype/StillImage\
\x22 />\x0a        <dc\
:title></dc:titl\
e>\x0a      </cc:Wo\
rk>\x0a    </rdf:RD\
F>\x0a  </metadata>\
\x0a  <defs\x0a     id\
=\x22defs6\x22 />\x0a  <s\
odipodi:namedvie\
w\x0a     pagecolor\
=\x22#ffffff\x22\x0a     \
bordercolor=\x22#66\
6666\x22\x0a     borde\
ropacity=\x221\x22\x0a   \
  objecttoleranc\
e=\x2210\x22\x0a     grid\
tolerance=\x2210\x22\x0a \
    guidetoleran\
ce=\x2210\x22\x0a     ink\
scape:pageopacit\
y=\x220\x22\x0a     inksc\
ape:pageshadow=\x22\
2\x22\x0a     inkscape\
:window-width=\x221\
863\x22\x0a     inksca\
pe:window-height\
=\x221025\x22\x0a     id=\
\x22namedview4\x22\x0a   \
  showgrid=\x22fals\
e\x22\x0a     inkscape\
:zoom=\x221.7383042\
\x22\x0a     inkscape:\
cx=\x22-108.27277\x22\x0a\
     inkscape:cy\
=\x22209.44504\x22\x0a   \
  inkscape:windo\
w-x=\x2257\x22\x0a     in\
kscape:window-y=\
\x2227\x22\x0a     inksca\
pe:window-maximi\
zed=\x221\x22\x0a     ink\
scape:current-la\
yer=\x22g831\x22 />\x0a  \
<g\x0a     id=\x22g831\
\x22\x0a     style=\x22st\
roke:#b3b3b3;str\
oke-linecap:roun\
d\x22>\x0a    <path\x0a  \
     sodipodi:no\
detypes=\x22cc\x22\x0a   \
    inkscape:con\
nector-curvature\
=\x220\x22\x0a       id=\x22\
path812-3\x22\x0a     \
  d=\x22m 134.96147\
,95.594487 -79.7\
95108,0.0945\x22\x0a  \
     style=\x22fill\
:none;fill-rule:\
evenodd;stroke:#\
b3b3b3;stroke-wi\
dth:16;stroke-li\
necap:round;stro\
ke-linejoin:mite\
r;stroke-miterli\
mit:4;stroke-das\
harray:none;stro\
ke-opacity:1\x22 />\
\x0a  </g>\x0a</svg>\x0a\
\x00\x00\x08\xe1\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   xmlns:d\
c=\x22http://purl.o\
rg/dc/elements/1\
.1/\x22\x0a   xmlns:cc\
=\x22http://creativ\
ecommons.org/ns#\
\x22\x0a   xmlns:rdf=\x22\
http://www.w3.or\
g/1999/02/22-rdf\
-syntax-ns#\x22\x0a   \
xmlns:svg=\x22http:\
//www.w3.org/200\
0/svg\x22\x0a   xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22\x0a   \
xmlns:sodipodi=\x22\
http://sodipodi.\
sourceforge.net/\
DTD/sodipodi-0.d\
td\x22\x0a   xmlns:ink\
scape=\x22http://ww\
w.inkscape.org/n\
amespaces/inksca\
pe\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg2\
\x22\x0a   width=\x22192\x22\
\x0a   height=\x22192\x22\
\x0a   viewBox=\x220 0\
 192 192\x22\x0a   sod\
ipodi:docname=\x22p\
lus.svg\x22\x0a   inks\
cape:version=\x220.\
92.2 (5c3e80d, 2\
017-08-06)\x22>\x0a  <\
metadata\x0a     id\
=\x22metadata8\x22>\x0a  \
  <rdf:RDF>\x0a    \
  <cc:Work\x0a     \
    rdf:about=\x22\x22\
>\x0a        <dc:fo\
rmat>image/svg+x\
ml</dc:format>\x0a \
       <dc:type\x0a\
           rdf:r\
esource=\x22http://\
purl.org/dc/dcmi\
type/StillImage\x22\
 />\x0a        <dc:\
title />\x0a      <\
/cc:Work>\x0a    </\
rdf:RDF>\x0a  </met\
adata>\x0a  <defs\x0a \
    id=\x22defs6\x22 /\
>\x0a  <sodipodi:na\
medview\x0a     pag\
ecolor=\x22#ffffff\x22\
\x0a     bordercolo\
r=\x22#666666\x22\x0a    \
 borderopacity=\x22\
1\x22\x0a     objectto\
lerance=\x2210\x22\x0a   \
  gridtolerance=\
\x2210\x22\x0a     guidet\
olerance=\x2210\x22\x0a  \
   inkscape:page\
opacity=\x220\x22\x0a    \
 inkscape:pagesh\
adow=\x222\x22\x0a     in\
kscape:window-wi\
dth=\x221863\x22\x0a     \
inkscape:window-\
height=\x221025\x22\x0a  \
   id=\x22namedview\
4\x22\x0a     showgrid\
=\x22false\x22\x0a     in\
kscape:zoom=\x221.7\
383042\x22\x0a     ink\
scape:cx=\x22-108.2\
7277\x22\x0a     inksc\
ape:cy=\x22209.4450\
4\x22\x0a     inkscape\
:window-x=\x2257\x22\x0a \
    inkscape:win\
dow-y=\x2227\x22\x0a     \
inkscape:window-\
maximized=\x221\x22\x0a  \
   inkscape:curr\
ent-layer=\x22svg2\x22\
 />\x0a  <g\x0a     id\
=\x22g831\x22\x0a     sty\
le=\x22stroke:#b3b3\
b3;stroke-lineca\
p:round\x22>\x0a    <p\
ath\x0a       sodip\
odi:nodetypes=\x22c\
c\x22\x0a       inksca\
pe:connector-cur\
vature=\x220\x22\x0a     \
  id=\x22path812\x22\x0a \
      d=\x22m 95.09\
1973,56.172243 0\
.09447,79.795097\
\x22\x0a       style=\x22\
fill:none;fill-r\
ule:evenodd;stro\
ke:#b3b3b3;strok\
e-width:16;strok\
e-linecap:round;\
stroke-linejoin:\
miter;stroke-mit\
erlimit:4;stroke\
-dasharray:none;\
stroke-opacity:1\
\x22 />\x0a    <path\x0a \
      sodipodi:n\
odetypes=\x22cc\x22\x0a  \
     inkscape:co\
nnector-curvatur\
e=\x220\x22\x0a       id=\
\x22path812-3\x22\x0a    \
   d=\x22m 134.9614\
7,95.594487 -79.\
795108,0.0945\x22\x0a \
      style=\x22fil\
l:none;fill-rule\
:evenodd;stroke:\
#b3b3b3;stroke-w\
idth:16;stroke-l\
inecap:round;str\
oke-linejoin:mit\
er;stroke-miterl\
imit:4;stroke-da\
sharray:none;str\
oke-opacity:1\x22 /\
>\x0a  </g>\x0a</svg>\x0a\
\
"

qt_resource_name = b"\
\x00\x05\
\x00O\xa6S\
\x00I\
\x00c\x00o\x00n\x00s\
\x00\x05\
\x00o\xa6S\
\x00i\
\x00c\x00o\x00n\x00s\
\x00\x08\
\x0b\x85Wg\
\x00g\
\x00e\x00a\x00r\x00.\x00s\x00v\x00g\
\x00\x0a\
\x0c\xad\x02\x87\
\x00d\
\x00e\x00l\x00e\x00t\x00e\x00.\x00s\x00v\x00g\
\x00\x08\
\x0b\x07W\xa7\
\x00e\
\x00d\x00i\x00t\x00.\x00s\x00v\x00g\
\x00\x08\
\x08&W\xe7\
\x00c\
\x00a\x00l\x00c\x00.\x00s\x00v\x00g\
\x00\x09\
\x05\xc6\xb2\xc7\
\x00m\
\x00i\x00n\x00u\x00s\x00.\x00s\x00v\x00g\
\x00\x08\
\x03\xc6T'\
\x00p\
\x00l\x00u\x00s\x00.\x00s\x00v\x00g\
"

qt_resource_struct = b"\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x01\x00\x00\x00\x01\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x01\x00\x00\x00\x02\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x10\x00\x02\x00\x00\x00\x06\x00\x00\x00\x03\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x94\x00\x00\x00\x00\x00\x01\x00\x00*Z\
\x00\x00\x01\x88\xae\xf9[-\
\x00\x00\x00|\x00\x00\x00\x00\x00\x01\x00\x00\x22\xb6\
\x00\x00\x01\x88\xae\xf9[-\
\x00\x00\x00f\x00\x01\x00\x00\x00\x01\x00\x00\x1d\xd0\
\x00\x00\x01\x88\xae\xf9[-\
\x00\x00\x00P\x00\x00\x00\x00\x00\x01\x00\x00\x15\xad\
\x00\x00\x01\x88\xae\xf9[-\
\x00\x00\x00 \x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\
\x00\x00\x01\x88\xae\xf9[-\
\x00\x00\x006\x00\x00\x00\x00\x00\x01\x00\x00\x0d^\
\x00\x00\x01\x88\xae\xf9[-\
"

def qInitResources():
    QtCore.qRegisterResourceData(0x03, qt_resource_struct, qt_resource_name, qt_resource_data)

def qCleanupResources():
    QtCore.qUnregisterResourceData(0x03, qt_resource_struct, qt_resource_name, qt_resource_data)

qInitResources()
