# Resource object code (Python 3)
# Created by: object code
# Created by: The Resource Compiler for Qt version 6.7.2
# WARNING! All changes made in this file will be lost!

from PySide6 import QtCore

qt_resource_data = b"\
\x00\x00\x09\x10\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   xmlns:d\
c=\x22http://purl.o\
rg/dc/elements/1\
.1/\x22\x0a   xmlns:cc\
=\x22http://creativ\
ecommons.org/ns#\
\x22\x0a   xmlns:rdf=\x22\
http://www.w3.or\
g/1999/02/22-rdf\
-syntax-ns#\x22\x0a   \
xmlns:svg=\x22http:\
//www.w3.org/200\
0/svg\x22\x0a   xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22\x0a   \
xmlns:sodipodi=\x22\
http://sodipodi.\
sourceforge.net/\
DTD/sodipodi-0.d\
td\x22\x0a   xmlns:ink\
scape=\x22http://ww\
w.inkscape.org/n\
amespaces/inksca\
pe\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg2\
\x22\x0a   width=\x22192\x22\
\x0a   height=\x22192\x22\
\x0a   viewBox=\x220 0\
 192 192\x22\x0a   sod\
ipodi:docname=\x22d\
elete3.svg\x22\x0a   i\
nkscape:version=\
\x220.92.4 (unknown\
)\x22>\x0a  <metadata\x0a\
     id=\x22metadat\
a8\x22>\x0a    <rdf:RD\
F>\x0a      <cc:Wor\
k\x0a         rdf:a\
bout=\x22\x22>\x0a       \
 <dc:format>imag\
e/svg+xml</dc:fo\
rmat>\x0a        <d\
c:type\x0a         \
  rdf:resource=\x22\
http://purl.org/\
dc/dcmitype/Stil\
lImage\x22 />\x0a     \
   <dc:title />\x0a\
      </cc:Work>\
\x0a    </rdf:RDF>\x0a\
  </metadata>\x0a  \
<defs\x0a     id=\x22d\
efs6\x22 />\x0a  <sodi\
podi:namedview\x0a \
    pagecolor=\x22#\
ffffff\x22\x0a     bor\
dercolor=\x22#66666\
6\x22\x0a     borderop\
acity=\x221\x22\x0a     o\
bjecttolerance=\x22\
10\x22\x0a     gridtol\
erance=\x2210\x22\x0a    \
 guidetolerance=\
\x2210\x22\x0a     inksca\
pe:pageopacity=\x22\
0\x22\x0a     inkscape\
:pageshadow=\x222\x22\x0a\
     inkscape:wi\
ndow-width=\x221863\
\x22\x0a     inkscape:\
window-height=\x221\
025\x22\x0a     id=\x22na\
medview4\x22\x0a     s\
howgrid=\x22false\x22\x0a\
     inkscape:zo\
om=\x221.7383042\x22\x0a \
    inkscape:cx=\
\x2228.86947\x22\x0a     \
inkscape:cy=\x226.5\
751461\x22\x0a     ink\
scape:window-x=\x22\
57\x22\x0a     inkscap\
e:window-y=\x2227\x22\x0a\
     inkscape:wi\
ndow-maximized=\x22\
1\x22\x0a     inkscape\
:current-layer=\x22\
g831\x22 />\x0a  <g\x0a  \
   id=\x22g831\x22\x0a   \
  style=\x22stroke:\
#37c8ab;stroke-w\
idth:21;stroke-m\
iterlimit:4;stro\
ke-dasharray:non\
e\x22>\x0a    <path\x0a  \
     inkscape:co\
nnector-curvatur\
e=\x220\x22\x0a       id=\
\x22path812\x22\x0a      \
 d=\x22M 59.837063,\
61.191958 134.85\
037,135.42536\x22\x0a \
      style=\x22fil\
l:none;fill-rule\
:evenodd;stroke:\
#ff8080;stroke-w\
idth:15.57077312\
;stroke-linecap:\
round;stroke-lin\
ejoin:miter;stro\
ke-miterlimit:4;\
stroke-dasharray\
:none;stroke-opa\
city:1\x22\x0a       s\
odipodi:nodetype\
s=\x22cc\x22 />\x0a    <p\
ath\x0a       inksc\
ape:connector-cu\
rvature=\x220\x22\x0a    \
   id=\x22path812-3\
\x22\x0a       d=\x22M 13\
3.89064,61.51186\
6 60.79679,135.1\
0545\x22\x0a       sty\
le=\x22fill:none;fi\
ll-rule:evenodd;\
stroke:#ff8080;s\
troke-width:15.5\
7077312;stroke-l\
inecap:round;str\
oke-linejoin:mit\
er;stroke-miterl\
imit:4;stroke-da\
sharray:none;str\
oke-opacity:1\x22\x0a \
      sodipodi:n\
odetypes=\x22cc\x22 />\
\x0a  </g>\x0a</svg>\x0a\
\x00\x00\x0c=\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<!-- Creat\
ed with Inkscape\
 (http://www.ink\
scape.org/) -->\x0a\
\x0a<svg\x0a   xmlns:d\
c=\x22http://purl.o\
rg/dc/elements/1\
.1/\x22\x0a   xmlns:cc\
=\x22http://creativ\
ecommons.org/ns#\
\x22\x0a   xmlns:rdf=\x22\
http://www.w3.or\
g/1999/02/22-rdf\
-syntax-ns#\x22\x0a   \
xmlns:svg=\x22http:\
//www.w3.org/200\
0/svg\x22\x0a   xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22\x0a   \
xmlns:sodipodi=\x22\
http://sodipodi.\
sourceforge.net/\
DTD/sodipodi-0.d\
td\x22\x0a   xmlns:ink\
scape=\x22http://ww\
w.inkscape.org/n\
amespaces/inksca\
pe\x22\x0a   version=\x22\
1.1\x22\x0a   id=\x22svg2\
\x22\x0a   width=\x22192\x22\
\x0a   height=\x22192\x22\
\x0a   viewBox=\x220 0\
 192 192\x22\x0a   sod\
ipodi:docname=\x22d\
elete2.svg\x22\x0a   i\
nkscape:version=\
\x220.92.3 (2405546\
, 2018-03-11)\x22>\x0a\
  <metadata\x0a    \
 id=\x22metadata8\x22>\
\x0a    <rdf:RDF>\x0a \
     <cc:Work\x0a  \
       rdf:about\
=\x22\x22>\x0a        <dc\
:format>image/sv\
g+xml</dc:format\
>\x0a        <dc:ty\
pe\x0a           rd\
f:resource=\x22http\
://purl.org/dc/d\
cmitype/StillIma\
ge\x22 />\x0a        <\
dc:title />\x0a    \
  </cc:Work>\x0a   \
 </rdf:RDF>\x0a  </\
metadata>\x0a  <def\
s\x0a     id=\x22defs6\
\x22 />\x0a  <sodipodi\
:namedview\x0a     \
pagecolor=\x22#ffff\
ff\x22\x0a     borderc\
olor=\x22#666666\x22\x0a \
    borderopacit\
y=\x221\x22\x0a     objec\
ttolerance=\x2210\x22\x0a\
     gridtoleran\
ce=\x2210\x22\x0a     gui\
detolerance=\x2210\x22\
\x0a     inkscape:p\
ageopacity=\x220\x22\x0a \
    inkscape:pag\
eshadow=\x222\x22\x0a    \
 inkscape:window\
-width=\x221853\x22\x0a  \
   inkscape:wind\
ow-height=\x221025\x22\
\x0a     id=\x22namedv\
iew4\x22\x0a     showg\
rid=\x22false\x22\x0a    \
 inkscape:zoom=\x22\
1.7383042\x22\x0a     \
inkscape:cx=\x22-10\
5.16921\x22\x0a     in\
kscape:cy=\x226.575\
1461\x22\x0a     inksc\
ape:window-x=\x2267\
\x22\x0a     inkscape:\
window-y=\x2227\x22\x0a  \
   inkscape:wind\
ow-maximized=\x221\x22\
\x0a     inkscape:c\
urrent-layer=\x22g8\
31\x22 />\x0a  <g\x0a    \
 id=\x22g831\x22\x0a     \
style=\x22stroke:#3\
7c8ab;stroke-wid\
th:21;stroke-mit\
erlimit:4;stroke\
-dasharray:none\x22\
>\x0a    <g\x0a       \
id=\x22g858\x22\x0a      \
 transform=\x22tran\
slate(-336.53488\
,3.4516398)\x22>\x0a  \
    <path\x0a      \
   sodipodi:node\
types=\x22cc\x22\x0a     \
    style=\x22fill:\
none;fill-rule:e\
venodd;stroke:#f\
f8080;stroke-wid\
th:15.57077312;s\
troke-linecap:ro\
und;stroke-linej\
oin:miter;stroke\
-miterlimit:4;st\
roke-dasharray:n\
one;stroke-opaci\
ty:1\x22\x0a         d\
=\x22M 58.686516,34\
.154113 133.6998\
2,108.38751\x22\x0a   \
      id=\x22path81\
2\x22\x0a         inks\
cape:connector-c\
urvature=\x220\x22 />\x0a\
      <path\x0a    \
     sodipodi:no\
detypes=\x22cc\x22\x0a   \
      style=\x22fil\
l:none;fill-rule\
:evenodd;stroke:\
#ff8080;stroke-w\
idth:15.57077312\
;stroke-linecap:\
round;stroke-lin\
ejoin:miter;stro\
ke-miterlimit:4;\
stroke-dasharray\
:none;stroke-opa\
city:1\x22\x0a        \
 d=\x22M 132.74009,\
34.474021 59.646\
243,108.0676\x22\x0a  \
       id=\x22path8\
12-3\x22\x0a         i\
nkscape:connecto\
r-curvature=\x220\x22 \
/>\x0a    </g>\x0a    \
<path\x0a       ink\
scape:connector-\
curvature=\x220\x22\x0a  \
     id=\x22path812\
-7\x22\x0a       d=\x22M \
48.209069,89.302\
145 123.22237,16\
3.53554\x22\x0a       \
style=\x22fill:none\
;fill-rule:eveno\
dd;stroke:#ff808\
0;stroke-width:1\
5.57077312;strok\
e-linecap:round;\
stroke-linejoin:\
miter;stroke-mit\
erlimit:4;stroke\
-dasharray:none;\
stroke-opacity:1\
\x22\x0a       sodipod\
i:nodetypes=\x22cc\x22\
 />\x0a    <path\x0a  \
     inkscape:co\
nnector-curvatur\
e=\x220\x22\x0a       id=\
\x22path812-3-5\x22\x0a  \
     d=\x22M 122.26\
264,89.622055 49\
.168796,163.2156\
3\x22\x0a       style=\
\x22fill:none;fill-\
rule:evenodd;str\
oke:#ff8080;stro\
ke-width:15.5707\
7312;stroke-line\
cap:round;stroke\
-linejoin:miter;\
stroke-miterlimi\
t:4;stroke-dasha\
rray:none;stroke\
-opacity:1\x22\x0a    \
   sodipodi:node\
types=\x22cc\x22 />\x0a  \
</g>\x0a</svg>\x0a\
\x00\x00\x07\x02\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   xm\
lns:dc=\x22http://p\
url.org/dc/eleme\
nts/1.1/\x22\x0a   xml\
ns:cc=\x22http://cr\
eativecommons.or\
g/ns#\x22\x0a   xmlns:\
rdf=\x22http://www.\
w3.org/1999/02/2\
2-rdf-syntax-ns#\
\x22\x0a   xmlns:svg=\x22\
http://www.w3.or\
g/2000/svg\x22\x0a   x\
mlns=\x22http://www\
.w3.org/2000/svg\
\x22\x0a   xmlns:sodip\
odi=\x22http://sodi\
podi.sourceforge\
.net/DTD/sodipod\
i-0.dtd\x22\x0a   xmln\
s:inkscape=\x22http\
://www.inkscape.\
org/namespaces/i\
nkscape\x22\x0a   widt\
h=\x2248\x22\x0a   height\
=\x2248\x22\x0a   viewBox\
=\x220 0 48 48\x22\x0a   \
version=\x221.1\x22\x0a  \
 id=\x22svg4\x22\x0a   so\
dipodi:docname=\x22\
accept.svg\x22\x0a   i\
nkscape:version=\
\x220.92.3 (2405546\
, 2018-03-11)\x22>\x0a\
  <metadata\x0a    \
 id=\x22metadata10\x22\
>\x0a    <rdf:RDF>\x0a\
      <cc:Work\x0a \
        rdf:abou\
t=\x22\x22>\x0a        <d\
c:format>image/s\
vg+xml</dc:forma\
t>\x0a        <dc:t\
ype\x0a           r\
df:resource=\x22htt\
p://purl.org/dc/\
dcmitype/StillIm\
age\x22 />\x0a      </\
cc:Work>\x0a    </r\
df:RDF>\x0a  </meta\
data>\x0a  <defs\x0a  \
   id=\x22defs8\x22 />\
\x0a  <sodipodi:nam\
edview\x0a     page\
color=\x22#ffffff\x22\x0a\
     bordercolor\
=\x22#666666\x22\x0a     \
borderopacity=\x221\
\x22\x0a     objecttol\
erance=\x2210\x22\x0a    \
 gridtolerance=\x22\
10\x22\x0a     guideto\
lerance=\x2210\x22\x0a   \
  inkscape:pageo\
pacity=\x220\x22\x0a     \
inkscape:pagesha\
dow=\x222\x22\x0a     ink\
scape:window-wid\
th=\x221853\x22\x0a     i\
nkscape:window-h\
eight=\x221025\x22\x0a   \
  id=\x22namedview6\
\x22\x0a     showgrid=\
\x22false\x22\x0a     ink\
scape:zoom=\x222.45\
83333\x22\x0a     inks\
cape:cx=\x22-184.46\
43\x22\x0a     inkscap\
e:cy=\x2239.302561\x22\
\x0a     inkscape:w\
indow-x=\x2267\x22\x0a   \
  inkscape:windo\
w-y=\x2227\x22\x0a     in\
kscape:window-ma\
ximized=\x221\x22\x0a    \
 inkscape:curren\
t-layer=\x22svg4\x22 /\
>\x0a  <path\x0a     s\
tyle=\x22fill:#00d4\
aa;fill-rule:eve\
nodd;stroke:#00d\
4aa;stroke-width\
:1.15240359px;st\
roke-linecap:but\
t;stroke-linejoi\
n:miter;stroke-o\
pacity:1\x22\x0a     d\
=\x22M 4.1877492,25\
.155303 15.67271\
9,39.687308 45.9\
08665,13.904718 \
41.455309,10.857\
686 17.079041,29\
.139883 8.875491\
5,23.748979 Z\x22\x0a \
    id=\x22path815\x22\
\x0a     inkscape:c\
onnector-curvatu\
re=\x220\x22 />\x0a</svg>\
\x0a\
\x00\x00\x0ai\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   xm\
lns:dc=\x22http://p\
url.org/dc/eleme\
nts/1.1/\x22\x0a   xml\
ns:cc=\x22http://cr\
eativecommons.or\
g/ns#\x22\x0a   xmlns:\
rdf=\x22http://www.\
w3.org/1999/02/2\
2-rdf-syntax-ns#\
\x22\x0a   xmlns:svg=\x22\
http://www.w3.or\
g/2000/svg\x22\x0a   x\
mlns=\x22http://www\
.w3.org/2000/svg\
\x22\x0a   xmlns:sodip\
odi=\x22http://sodi\
podi.sourceforge\
.net/DTD/sodipod\
i-0.dtd\x22\x0a   xmln\
s:inkscape=\x22http\
://www.inkscape.\
org/namespaces/i\
nkscape\x22\x0a   widt\
h=\x2248\x22\x0a   height\
=\x2248\x22\x0a   viewBox\
=\x220 0 48 48\x22\x0a   \
version=\x221.1\x22\x0a  \
 id=\x22svg4\x22\x0a   so\
dipodi:docname=\x22\
accept2.svg\x22\x0a   \
inkscape:version\
=\x220.92.3 (240554\
6, 2018-03-11)\x22>\
\x0a  <metadata\x0a   \
  id=\x22metadata10\
\x22>\x0a    <rdf:RDF>\
\x0a      <cc:Work\x0a\
         rdf:abo\
ut=\x22\x22>\x0a        <\
dc:format>image/\
svg+xml</dc:form\
at>\x0a        <dc:\
type\x0a           \
rdf:resource=\x22ht\
tp://purl.org/dc\
/dcmitype/StillI\
mage\x22 />\x0a      <\
/cc:Work>\x0a    </\
rdf:RDF>\x0a  </met\
adata>\x0a  <defs\x0a \
    id=\x22defs8\x22 /\
>\x0a  <sodipodi:na\
medview\x0a     pag\
ecolor=\x22#ffffff\x22\
\x0a     bordercolo\
r=\x22#666666\x22\x0a    \
 borderopacity=\x22\
1\x22\x0a     objectto\
lerance=\x2210\x22\x0a   \
  gridtolerance=\
\x2210\x22\x0a     guidet\
olerance=\x2210\x22\x0a  \
   inkscape:page\
opacity=\x220\x22\x0a    \
 inkscape:pagesh\
adow=\x222\x22\x0a     in\
kscape:window-wi\
dth=\x221853\x22\x0a     \
inkscape:window-\
height=\x221025\x22\x0a  \
   id=\x22namedview\
6\x22\x0a     showgrid\
=\x22false\x22\x0a     in\
kscape:zoom=\x226.3\
333333\x22\x0a     ink\
scape:cx=\x2226.339\
228\x22\x0a     inksca\
pe:cy=\x2250.577833\
\x22\x0a     inkscape:\
window-x=\x2267\x22\x0a  \
   inkscape:wind\
ow-y=\x2227\x22\x0a     i\
nkscape:window-m\
aximized=\x221\x22\x0a   \
  inkscape:curre\
nt-layer=\x22svg4\x22 \
/>\x0a  <path\x0a     \
style=\x22fill:#00d\
4aa;fill-rule:ev\
enodd;stroke:#00\
d4aa;stroke-widt\
h:0.73550624px;s\
troke-linecap:bu\
tt;stroke-linejo\
in:miter;stroke-\
opacity:1\x22\x0a     \
d=\x22M 2.2550022,3\
5.606185 9.58513\
14,44.881044 28.\
882821,28.425649\
 26.040526,26.48\
0922 10.482698,3\
8.14929 5.246891\
2,34.708618 Z\x22\x0a \
    id=\x22path815\x22\
\x0a     inkscape:c\
onnector-curvatu\
re=\x220\x22 />\x0a  <g\x0a \
    style=\x22strok\
e:#37c8ab;stroke\
-width:21;stroke\
-miterlimit:4;st\
roke-dasharray:n\
one\x22\x0a     id=\x22g8\
58\x22\x0a     transfo\
rm=\x22matrix(0.225\
97714,0,0,0.2259\
7714,-8.857672,-\
3.3950478)\x22>\x0a   \
 <path\x0a       so\
dipodi:nodetypes\
=\x22cc\x22\x0a       sty\
le=\x22fill:none;fi\
ll-rule:evenodd;\
stroke:#ff8080;s\
troke-width:15.5\
7077312;stroke-l\
inecap:round;str\
oke-linejoin:mit\
er;stroke-miterl\
imit:4;stroke-da\
sharray:none;str\
oke-opacity:1\x22\x0a \
      d=\x22M 58.68\
6516,34.154113 1\
33.69982,108.387\
51\x22\x0a       id=\x22p\
ath812\x22\x0a       i\
nkscape:connecto\
r-curvature=\x220\x22 \
/>\x0a    <path\x0a   \
    sodipodi:nod\
etypes=\x22cc\x22\x0a    \
   style=\x22fill:n\
one;fill-rule:ev\
enodd;stroke:#ff\
8080;stroke-widt\
h:15.57077312;st\
roke-linecap:rou\
nd;stroke-linejo\
in:miter;stroke-\
miterlimit:4;str\
oke-dasharray:no\
ne;stroke-opacit\
y:1\x22\x0a       d=\x22M\
 132.74009,34.47\
4021 59.646243,1\
08.0676\x22\x0a       \
id=\x22path812-3\x22\x0a \
      inkscape:c\
onnector-curvatu\
re=\x220\x22 />\x0a  </g>\
\x0a</svg>\x0a\
"

qt_resource_name = b"\
\x00\x05\
\x00O\xa6S\
\x00I\
\x00c\x00o\x00n\x00s\
\x00\x05\
\x00o\xa6S\
\x00i\
\x00c\x00o\x00n\x00s\
\x00\x0a\
\x0c\xad\x02\x87\
\x00d\
\x00e\x00l\x00e\x00t\x00e\x00.\x00s\x00v\x00g\
\x00\x0b\
\x0aP\xdfG\
\x00d\
\x00e\x00l\x00e\x00t\x00e\x002\x00.\x00s\x00v\x00g\
\x00\x0a\
\x0c{\xa9\xe7\
\x00a\
\x00c\x00c\x00e\x00p\x00t\x00.\x00s\x00v\x00g\
\x00\x0b\
\x07\xbaiG\
\x00a\
\x00c\x00c\x00e\x00p\x00t\x002\x00.\x00s\x00v\x00g\
"

qt_resource_struct = b"\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x01\x00\x00\x00\x01\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x01\x00\x00\x00\x02\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x10\x00\x02\x00\x00\x00\x04\x00\x00\x00\x03\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00p\x00\x00\x00\x00\x00\x01\x00\x00\x1c[\
\x00\x00\x01\x88\xae\xf9[-\
\x00\x00\x00:\x00\x00\x00\x00\x00\x01\x00\x00\x09\x14\
\x00\x00\x01\x88\xae\xf9[-\
\x00\x00\x00V\x00\x00\x00\x00\x00\x01\x00\x00\x15U\
\x00\x00\x01\x88\xae\xf9[-\
\x00\x00\x00 \x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\
\x00\x00\x01\x88\xae\xf9[-\
"

def qInitResources():
    QtCore.qRegisterResourceData(0x03, qt_resource_struct, qt_resource_name, qt_resource_data)

def qCleanupResources():
    QtCore.qUnregisterResourceData(0x03, qt_resource_struct, qt_resource_name, qt_resource_data)

qInitResources()
