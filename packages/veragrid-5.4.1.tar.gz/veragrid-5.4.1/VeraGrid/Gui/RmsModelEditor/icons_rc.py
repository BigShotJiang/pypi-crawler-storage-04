# Resource object code (Python 3)
# Created by: object code
# Created by: The Resource Compiler for Qt version 6.7.2
# WARNING! All changes made in this file will be lost!

from PySide6 import QtCore

qt_resource_data = b"\
\x00\x00\x0di\
<\
?xml version=\x221.\
0\x22 encoding=\x22UTF\
-8\x22 standalone=\x22\
no\x22?>\x0a<svg\x0a   wi\
dth=\x2248\x22\x0a   heig\
ht=\x2248\x22\x0a   viewB\
ox=\x220 0 48 48\x22\x0a \
  id=\x22svg2\x22\x0a   v\
ersion=\x221.1\x22\x0a   \
inkscape:version\
=\x221.2.2 (b0a8486\
541, 2022-12-01)\
\x22\x0a   sodipodi:do\
cname=\x22dyn.svg\x22\x0a\
   xmlns:inkscap\
e=\x22http://www.in\
kscape.org/names\
paces/inkscape\x22\x0a\
   xmlns:sodipod\
i=\x22http://sodipo\
di.sourceforge.n\
et/DTD/sodipodi-\
0.dtd\x22\x0a   xmlns=\
\x22http://www.w3.o\
rg/2000/svg\x22\x0a   \
xmlns:svg=\x22http:\
//www.w3.org/200\
0/svg\x22\x0a   xmlns:\
rdf=\x22http://www.\
w3.org/1999/02/2\
2-rdf-syntax-ns#\
\x22\x0a   xmlns:cc=\x22h\
ttp://creativeco\
mmons.org/ns#\x22\x0a \
  xmlns:dc=\x22http\
://purl.org/dc/e\
lements/1.1/\x22>\x0a \
 <metadata\x0a     \
id=\x22metadata12\x22>\
\x0a    <rdf:RDF>\x0a \
     <cc:Work\x0a  \
       rdf:about\
=\x22\x22>\x0a        <dc\
:format>image/sv\
g+xml</dc:format\
>\x0a        <dc:ty\
pe\x0a           rd\
f:resource=\x22http\
://purl.org/dc/d\
cmitype/StillIma\
ge\x22 />\x0a        <\
dc:title />\x0a    \
  </cc:Work>\x0a   \
 </rdf:RDF>\x0a  </\
metadata>\x0a  <def\
s\x0a     id=\x22defs1\
0\x22>\x0a    <marker\x0a\
       inkscape:\
stockid=\x22Arrow1L\
start\x22\x0a       or\
ient=\x22auto\x22\x0a    \
   refY=\x220.0\x22\x0a  \
     refX=\x220.0\x22\x0a\
       id=\x22Arrow\
1Lstart\x22\x0a       \
style=\x22overflow:\
visible\x22\x0a       \
inkscape:isstock\
=\x22true\x22>\x0a      <\
path\x0a         id\
=\x22path4598\x22\x0a    \
     d=\x22M 0.0,0.\
0 L 5.0,-5.0 L -\
12.5,0.0 L 5.0,5\
.0 L 0.0,0.0 z \x22\
\x0a         style=\
\x22fill-rule:eveno\
dd;stroke:#00000\
0;stroke-width:1\
.0pt\x22\x0a         t\
ransform=\x22scale(\
0.8) translate(1\
2.5,0)\x22 />\x0a    <\
/marker>\x0a  </def\
s>\x0a  <sodipodi:n\
amedview\x0a     pa\
gecolor=\x22#ffffff\
\x22\x0a     bordercol\
or=\x22#666666\x22\x0a   \
  borderopacity=\
\x221\x22\x0a     objectt\
olerance=\x2210\x22\x0a  \
   gridtolerance\
=\x2210\x22\x0a     guide\
tolerance=\x2210\x22\x0a \
    inkscape:pag\
eopacity=\x220\x22\x0a   \
  inkscape:pages\
hadow=\x222\x22\x0a     i\
nkscape:window-w\
idth=\x222509\x22\x0a    \
 inkscape:window\
-height=\x221012\x22\x0a \
    id=\x22namedvie\
w8\x22\x0a     showgri\
d=\x22false\x22\x0a     i\
nkscape:zoom=\x2213\
.822917\x22\x0a     in\
kscape:cx=\x221.700\
0753\x22\x0a     inksc\
ape:cy=\x2231.46947\
9\x22\x0a     inkscape\
:window-x=\x2251\x22\x0a \
    inkscape:win\
dow-y=\x2231\x22\x0a     \
inkscape:window-\
maximized=\x221\x22\x0a  \
   inkscape:curr\
ent-layer=\x22g901\x22\
\x0a     inkscape:s\
howpageshadow=\x222\
\x22\x0a     inkscape:\
pagecheckerboard\
=\x220\x22\x0a     inksca\
pe:deskcolor=\x22#d\
1d1d1\x22 />\x0a  <g\x0a \
    id=\x22g4150\x22>\x0a\
    <g\x0a       id\
=\x22g901\x22\x0a       t\
ransform=\x22matrix\
(1.0739294,0,0,1\
.0739294,69.4985\
37,31.871502)\x22>\x0a\
      <path\x0a    \
     style=\x22fill\
:none;fill-rule:\
evenodd;stroke:#\
00ccff;stroke-wi\
dth:1.38006;stro\
ke-linecap:round\
;stroke-linejoin\
:miter;stroke-mi\
terlimit:4;strok\
e-dasharray:none\
;stroke-opacity:\
1\x22\x0a         d=\x22m\
 -63.416345,2.72\
16497 c 0,0 0.89\
635,-18.5543157 \
2.52704,-18.5816\
827 1.687925,-0.\
02837 1.357634,2\
2.1569087 3.1498\
8,22.1607102 1.3\
27899,0.00352 1.\
489716,-17.55567\
22 2.922821,-17.\
6019132 1.009226\
,-0.03252 1.6401\
83,14.2669199 2.\
990291,14.241154\
3 0.9489,-0.0179\
51 1.430172,-10.\
027307 2.855953,\
-10.044896 1.023\
397,-0.01264 2.2\
04608,7.88075999\
 3.502636,7.8499\
2569 1.08991,-0.\
026047 2.241092,\
-6.27700099 3.33\
0902,-6.23978169\
 0.947241,0.0323\
48 1.388886,5.03\
048019 2.556198,\
5.03927989 0.893\
226,0.00669 1.78\
2141,-4.73695629\
 2.902092,-4.767\
86799 0.808568,-\
0.022386 1.11582\
8,3.7618438 1.96\
9275,3.7410588 0\
.59796,-0.014396\
 1.116066,-2.399\
4866 2.010737,-2\
.3650515 0.63043\
4,0.024323 1.037\
989,0.9345317 1.\
658338,0.9460417\
 0.808982,0.0151\
71 1.596028,-0.3\
127003 2.404584,\
-0.3440308 0.885\
557,-0.034178 1.\
767599,0.143323 \
2.65334,0.171996\
 0.71826,0.02316\
1 2.155839,0 2.1\
55839,0 l 2.3424\
08,-0.021647\x22\x0a  \
       id=\x22path4\
166\x22\x0a         in\
kscape:connector\
-curvature=\x220\x22\x0a \
        sodipodi\
:nodetypes=\x22csss\
sssssssssaacc\x22 /\
>\x0a    </g>\x0a    <\
g\x0a       transfo\
rm=\x22translate(1.\
0067283,-25.8872\
99)\x22\x0a       id=\x22\
g4144\x22 />\x0a  </g>\
\x0a</svg>\x0a\
"

qt_resource_name = b"\
\x00\x05\
\x00O\xa6S\
\x00I\
\x00c\x00o\x00n\x00s\
\x00\x05\
\x00o\xa6S\
\x00i\
\x00c\x00o\x00n\x00s\
\x00\x07\
\x0c\x01Z\x07\
\x00d\
\x00y\x00n\x00.\x00s\x00v\x00g\
"

qt_resource_struct = b"\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x01\x00\x00\x00\x01\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x01\x00\x00\x00\x02\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x10\x00\x02\x00\x00\x00\x01\x00\x00\x00\x03\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00 \x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\
\x00\x00\x01\x98\xec@Z{\
"

def qInitResources():
    QtCore.qRegisterResourceData(0x03, qt_resource_struct, qt_resource_name, qt_resource_data)

def qCleanupResources():
    QtCore.qUnregisterResourceData(0x03, qt_resource_struct, qt_resource_name, qt_resource_data)

qInitResources()
