### Tests lightweight api, assuming minimal dependencies, as installed from pypi

Run the  with:

```
python3 test_all.py
```
