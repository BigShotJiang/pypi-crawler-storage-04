# Copyright CrisMystik (https://t.me/CrisMystik) 2025-2025.
# Distributed under the Boost Software License, Version 1.0.
# (See accompanying file LICENSE_1_0.txt or copy at
#  https://www.boost.org/LICENSE_1_0.txt)

from .regdurations import *
