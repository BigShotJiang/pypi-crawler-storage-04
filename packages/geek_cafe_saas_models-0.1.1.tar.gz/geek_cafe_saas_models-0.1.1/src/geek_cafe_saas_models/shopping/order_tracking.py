
from .._base_tenant_user_model import BaseTenantUserDBModel as BaseDBModel