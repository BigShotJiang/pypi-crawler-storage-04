"""
Geek Cafe, LLC
MIT License.  See Project Root for the license information.
"""

from ..core.tree.node import Node


class AssetTreeNode(Node):
    def __init__(self):
        super().__init__()

    
