
class AssetTrigger:
    """
    A trigger that happens when on an asset.
    This can be used as the storage model for rules
    
    """