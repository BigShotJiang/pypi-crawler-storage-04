"""
Geek Cafe, LLC
MIT License.  See Project Root for the license information.
"""


class Certificate:
    """
    Defines a Certificate earned after passing a quiz or test
    
    """