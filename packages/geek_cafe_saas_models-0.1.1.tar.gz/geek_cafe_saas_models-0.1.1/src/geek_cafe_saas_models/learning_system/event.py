"""
Geek Cafe, LLC
MIT License.  See Project Root for the license information.
"""

class Event:
    """
    Live / scheduled events.  Events can be "open" seating or with an individual booking/ticket.
    """

