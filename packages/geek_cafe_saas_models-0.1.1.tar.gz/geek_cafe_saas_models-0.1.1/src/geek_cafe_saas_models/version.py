"""Version information for geek_cafe_saas_models."""

__version__ = "0.1.1"
