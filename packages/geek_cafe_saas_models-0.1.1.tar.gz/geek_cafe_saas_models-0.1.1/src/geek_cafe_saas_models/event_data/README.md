# Event Driven Architecture

The models listed here are used to support an Event Driven Architecture