
class SqsEvent:
    """A standardized SQS Event"""