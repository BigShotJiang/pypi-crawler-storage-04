# Searching Model for DynamoDB

Using free text and keyword search isn't directly supported by DynamoDB and we recommend using something like OpenSearch

However, when your budget is tight and you still want to include some basic searching, we can make a "poor mans" DynamoDB keyword and or phrase search.

See the Search Service in the Services modules to see how this is implemented.

