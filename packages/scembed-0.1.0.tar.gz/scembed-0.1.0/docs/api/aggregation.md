# scIB Results Retrieval and Aggregation

```{eval-rst}
.. module:: scembed
.. currentmodule:: scembed

.. autosummary::
    :toctree: ../generated

    scIBAggregator
```
