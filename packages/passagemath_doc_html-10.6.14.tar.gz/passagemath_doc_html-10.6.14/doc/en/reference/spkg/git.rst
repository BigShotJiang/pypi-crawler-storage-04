.. _spkg_git:

git: Version control system
===========================

Description
-----------

   Git is a fast, scalable, distributed revision control system with an
   unusually rich command set that provides both high-operations and
   full access to internals.

-  ``man git``


Upstream Contact
----------------

-  Website: https://git-scm.com/


Type
----

optional


Dependencies
------------



Version Information
-------------------



Equivalent System Packages
--------------------------

.. tab:: Arch Linux:

   .. CODE-BLOCK:: bash

       $ sudo pacman -S git

.. tab:: conda-forge:

   .. CODE-BLOCK:: bash

       $ conda install git

.. tab:: Debian/Ubuntu:

   .. CODE-BLOCK:: bash

       $ sudo apt-get install git

.. tab:: Fedora/Redhat/CentOS:

   .. CODE-BLOCK:: bash

       $ sudo dnf install git

.. tab:: FreeBSD:

   .. CODE-BLOCK:: bash

       $ sudo pkg install devel/git

.. tab:: Homebrew:

   .. CODE-BLOCK:: bash

       $ brew install git

.. tab:: MacPorts:

   .. CODE-BLOCK:: bash

       $ sudo port install git

.. tab:: openSUSE:

   .. CODE-BLOCK:: bash

       $ sudo zypper install git

.. tab:: Slackware:

   .. CODE-BLOCK:: bash

       $ sudo slackpkg install git

.. tab:: Void Linux:

   .. CODE-BLOCK:: bash

       $ sudo xbps-install git

# See https://repology.org/project/git/versions

If the system package is installed, ``./configure`` will check if it can be used.
