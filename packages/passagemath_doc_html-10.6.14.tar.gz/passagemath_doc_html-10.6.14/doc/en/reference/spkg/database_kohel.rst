.. _spkg_database_kohel:

database_kohel: Database of modular and Hilbert polynomials
===========================================================

Description
-----------

Database of modular and Hilbert polynomials.


Upstream Contact
----------------

-  David Kohel <David.Kohel@univ-amu.fr>


Type
----

optional


Dependencies
------------



Version Information
-------------------

package-version.txt::

    20160724

Equivalent System Packages
--------------------------

# See https://repology.org/project/sage-data-kohel/versions

However, these system packages will not be used for building Sage
because ``spkg-configure.m4`` has not been written for this package;
see :issue:`27330` for more information.
