.. _spkg_database_knotinfo:

database_knotinfo: Content of the KnotInfo and LinkInfo databases as lists of dictionaries
==========================================================================================

Description
-----------

Content of the KnotInfo and LinkInfo databases as lists of dictionaries

License
-------

GPL

Upstream Contact
----------------

https://pypi.org/project/database-knotinfo/



Type
----

optional


Dependencies
------------

- $(PYTHON)
- $(PYTHON_TOOLCHAIN)

Version Information
-------------------

package-version.txt::

    2024.10.1

version_requirements.txt::

    database-knotinfo

Equivalent System Packages
--------------------------

(none known)
