"""Constants used in the Ollama Assistant integration."""

SETUP_NOTIFICATION_ID = 'assistant:ollama:setup'
