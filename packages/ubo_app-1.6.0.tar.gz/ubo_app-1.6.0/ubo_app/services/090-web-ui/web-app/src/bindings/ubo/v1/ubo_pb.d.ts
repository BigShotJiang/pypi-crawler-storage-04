import * as jspb from 'google-protobuf'

import * as package_info_v1_package_info_pb from '../../package_info/v1/package_info_pb'; // proto import: "package_info/v1/package_info.proto"


export class BaseMenu extends jspb.Message {
  getMetaFieldPackageNameUboGuiDotMenuDotTypes(): string;
  setMetaFieldPackageNameUboGuiDotMenuDotTypes(value: string): BaseMenu;
  hasMetaFieldPackageNameUboGuiDotMenuDotTypes(): boolean;
  clearMetaFieldPackageNameUboGuiDotMenuDotTypes(): BaseMenu;

  getTitle(): string;
  setTitle(value: string): BaseMenu;

  getItemsList(): Array<Item>;
  setItemsList(value: Array<Item>): BaseMenu;
  clearItemsList(): BaseMenu;
  addItems(value?: Item, index?: number): Item;

  getPlaceholder(): string;
  setPlaceholder(value: string): BaseMenu;
  hasPlaceholder(): boolean;
  clearPlaceholder(): BaseMenu;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): BaseMenu.AsObject;
  static toObject(includeInstance: boolean, msg: BaseMenu): BaseMenu.AsObject;
  static serializeBinaryToWriter(message: BaseMenu, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): BaseMenu;
  static deserializeBinaryFromReader(message: BaseMenu, reader: jspb.BinaryReader): BaseMenu;
}

export namespace BaseMenu {
  export type AsObject = {
    metaFieldPackageNameUboGuiDotMenuDotTypes?: string,
    title: string,
    itemsList: Array<Item.AsObject>,
    placeholder?: string,
  }

  export enum MetaFieldPackageNameUboGuiDotMenuDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_GUI_DOT_MENU_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_GUI_DOT_MENU_DOT_TYPES = 1000,
  }

  export enum PlaceholderCase { 
    _PLACEHOLDER_NOT_SET = 0,
    PLACEHOLDER = 4,
  }
}

export class HeadedMenu extends jspb.Message {
  getMetaFieldPackageNameUboGuiDotMenuDotTypes(): string;
  setMetaFieldPackageNameUboGuiDotMenuDotTypes(value: string): HeadedMenu;
  hasMetaFieldPackageNameUboGuiDotMenuDotTypes(): boolean;
  clearMetaFieldPackageNameUboGuiDotMenuDotTypes(): HeadedMenu;

  getHeading(): string;
  setHeading(value: string): HeadedMenu;

  getSubHeading(): string;
  setSubHeading(value: string): HeadedMenu;

  getTitle(): string;
  setTitle(value: string): HeadedMenu;

  getItemsList(): Array<Item>;
  setItemsList(value: Array<Item>): HeadedMenu;
  clearItemsList(): HeadedMenu;
  addItems(value?: Item, index?: number): Item;

  getPlaceholder(): string;
  setPlaceholder(value: string): HeadedMenu;
  hasPlaceholder(): boolean;
  clearPlaceholder(): HeadedMenu;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): HeadedMenu.AsObject;
  static toObject(includeInstance: boolean, msg: HeadedMenu): HeadedMenu.AsObject;
  static serializeBinaryToWriter(message: HeadedMenu, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): HeadedMenu;
  static deserializeBinaryFromReader(message: HeadedMenu, reader: jspb.BinaryReader): HeadedMenu;
}

export namespace HeadedMenu {
  export type AsObject = {
    metaFieldPackageNameUboGuiDotMenuDotTypes?: string,
    heading: string,
    subHeading: string,
    title: string,
    itemsList: Array<Item.AsObject>,
    placeholder?: string,
  }

  export enum MetaFieldPackageNameUboGuiDotMenuDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_GUI_DOT_MENU_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_GUI_DOT_MENU_DOT_TYPES = 1000,
  }

  export enum PlaceholderCase { 
    _PLACEHOLDER_NOT_SET = 0,
    PLACEHOLDER = 6,
  }
}

export class HeadlessMenu extends jspb.Message {
  getMetaFieldPackageNameUboGuiDotMenuDotTypes(): string;
  setMetaFieldPackageNameUboGuiDotMenuDotTypes(value: string): HeadlessMenu;
  hasMetaFieldPackageNameUboGuiDotMenuDotTypes(): boolean;
  clearMetaFieldPackageNameUboGuiDotMenuDotTypes(): HeadlessMenu;

  getTitle(): string;
  setTitle(value: string): HeadlessMenu;

  getItemsList(): Array<Item>;
  setItemsList(value: Array<Item>): HeadlessMenu;
  clearItemsList(): HeadlessMenu;
  addItems(value?: Item, index?: number): Item;

  getPlaceholder(): string;
  setPlaceholder(value: string): HeadlessMenu;
  hasPlaceholder(): boolean;
  clearPlaceholder(): HeadlessMenu;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): HeadlessMenu.AsObject;
  static toObject(includeInstance: boolean, msg: HeadlessMenu): HeadlessMenu.AsObject;
  static serializeBinaryToWriter(message: HeadlessMenu, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): HeadlessMenu;
  static deserializeBinaryFromReader(message: HeadlessMenu, reader: jspb.BinaryReader): HeadlessMenu;
}

export namespace HeadlessMenu {
  export type AsObject = {
    metaFieldPackageNameUboGuiDotMenuDotTypes?: string,
    title: string,
    itemsList: Array<Item.AsObject>,
    placeholder?: string,
  }

  export enum MetaFieldPackageNameUboGuiDotMenuDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_GUI_DOT_MENU_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_GUI_DOT_MENU_DOT_TYPES = 1000,
  }

  export enum PlaceholderCase { 
    _PLACEHOLDER_NOT_SET = 0,
    PLACEHOLDER = 4,
  }
}

export class Item extends jspb.Message {
  getMetaFieldPackageNameUboGuiDotMenuDotTypes(): string;
  setMetaFieldPackageNameUboGuiDotMenuDotTypes(value: string): Item;
  hasMetaFieldPackageNameUboGuiDotMenuDotTypes(): boolean;
  clearMetaFieldPackageNameUboGuiDotMenuDotTypes(): Item;

  getKey(): string;
  setKey(value: string): Item;
  hasKey(): boolean;
  clearKey(): Item;

  getLabel(): string;
  setLabel(value: string): Item;
  hasLabel(): boolean;
  clearLabel(): Item;

  getColor(): string;
  setColor(value: string): Item;
  hasColor(): boolean;
  clearColor(): Item;

  getBackgroundColor(): string;
  setBackgroundColor(value: string): Item;
  hasBackgroundColor(): boolean;
  clearBackgroundColor(): Item;

  getIcon(): string;
  setIcon(value: string): Item;
  hasIcon(): boolean;
  clearIcon(): Item;

  getIsShort(): boolean;
  setIsShort(value: boolean): Item;
  hasIsShort(): boolean;
  clearIsShort(): Item;

  getOpacity(): number;
  setOpacity(value: number): Item;
  hasOpacity(): boolean;
  clearOpacity(): Item;

  getProgress(): number;
  setProgress(value: number): Item;
  hasProgress(): boolean;
  clearProgress(): Item;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Item.AsObject;
  static toObject(includeInstance: boolean, msg: Item): Item.AsObject;
  static serializeBinaryToWriter(message: Item, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Item;
  static deserializeBinaryFromReader(message: Item, reader: jspb.BinaryReader): Item;
}

export namespace Item {
  export type AsObject = {
    metaFieldPackageNameUboGuiDotMenuDotTypes?: string,
    key?: string,
    label?: string,
    color?: string,
    backgroundColor?: string,
    icon?: string,
    isShort?: boolean,
    opacity?: number,
    progress?: number,
  }

  export enum MetaFieldPackageNameUboGuiDotMenuDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_GUI_DOT_MENU_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_GUI_DOT_MENU_DOT_TYPES = 1000,
  }

  export enum KeyCase { 
    _KEY_NOT_SET = 0,
    KEY = 2,
  }

  export enum LabelCase { 
    _LABEL_NOT_SET = 0,
    LABEL = 3,
  }

  export enum ColorCase { 
    _COLOR_NOT_SET = 0,
    COLOR = 4,
  }

  export enum BackgroundColorCase { 
    _BACKGROUND_COLOR_NOT_SET = 0,
    BACKGROUND_COLOR = 5,
  }

  export enum IconCase { 
    _ICON_NOT_SET = 0,
    ICON = 6,
  }

  export enum IsShortCase { 
    _IS_SHORT_NOT_SET = 0,
    IS_SHORT = 7,
  }

  export enum OpacityCase { 
    _OPACITY_NOT_SET = 0,
    OPACITY = 8,
  }

  export enum ProgressCase { 
    _PROGRESS_NOT_SET = 0,
    PROGRESS = 9,
  }
}

export class ActionItem extends jspb.Message {
  getMetaFieldPackageNameUboGuiDotMenuDotTypes(): string;
  setMetaFieldPackageNameUboGuiDotMenuDotTypes(value: string): ActionItem;
  hasMetaFieldPackageNameUboGuiDotMenuDotTypes(): boolean;
  clearMetaFieldPackageNameUboGuiDotMenuDotTypes(): ActionItem;

  getKey(): string;
  setKey(value: string): ActionItem;
  hasKey(): boolean;
  clearKey(): ActionItem;

  getLabel(): string;
  setLabel(value: string): ActionItem;
  hasLabel(): boolean;
  clearLabel(): ActionItem;

  getColor(): string;
  setColor(value: string): ActionItem;
  hasColor(): boolean;
  clearColor(): ActionItem;

  getBackgroundColor(): string;
  setBackgroundColor(value: string): ActionItem;
  hasBackgroundColor(): boolean;
  clearBackgroundColor(): ActionItem;

  getIcon(): string;
  setIcon(value: string): ActionItem;
  hasIcon(): boolean;
  clearIcon(): ActionItem;

  getIsShort(): boolean;
  setIsShort(value: boolean): ActionItem;
  hasIsShort(): boolean;
  clearIsShort(): ActionItem;

  getOpacity(): number;
  setOpacity(value: number): ActionItem;
  hasOpacity(): boolean;
  clearOpacity(): ActionItem;

  getProgress(): number;
  setProgress(value: number): ActionItem;
  hasProgress(): boolean;
  clearProgress(): ActionItem;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ActionItem.AsObject;
  static toObject(includeInstance: boolean, msg: ActionItem): ActionItem.AsObject;
  static serializeBinaryToWriter(message: ActionItem, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ActionItem;
  static deserializeBinaryFromReader(message: ActionItem, reader: jspb.BinaryReader): ActionItem;
}

export namespace ActionItem {
  export type AsObject = {
    metaFieldPackageNameUboGuiDotMenuDotTypes?: string,
    key?: string,
    label?: string,
    color?: string,
    backgroundColor?: string,
    icon?: string,
    isShort?: boolean,
    opacity?: number,
    progress?: number,
  }

  export enum MetaFieldPackageNameUboGuiDotMenuDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_GUI_DOT_MENU_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_GUI_DOT_MENU_DOT_TYPES = 1000,
  }

  export enum KeyCase { 
    _KEY_NOT_SET = 0,
    KEY = 2,
  }

  export enum LabelCase { 
    _LABEL_NOT_SET = 0,
    LABEL = 3,
  }

  export enum ColorCase { 
    _COLOR_NOT_SET = 0,
    COLOR = 4,
  }

  export enum BackgroundColorCase { 
    _BACKGROUND_COLOR_NOT_SET = 0,
    BACKGROUND_COLOR = 5,
  }

  export enum IconCase { 
    _ICON_NOT_SET = 0,
    ICON = 6,
  }

  export enum IsShortCase { 
    _IS_SHORT_NOT_SET = 0,
    IS_SHORT = 7,
  }

  export enum OpacityCase { 
    _OPACITY_NOT_SET = 0,
    OPACITY = 8,
  }

  export enum ProgressCase { 
    _PROGRESS_NOT_SET = 0,
    PROGRESS = 9,
  }
}

export class ApplicationItem extends jspb.Message {
  getMetaFieldPackageNameUboGuiDotMenuDotTypes(): string;
  setMetaFieldPackageNameUboGuiDotMenuDotTypes(value: string): ApplicationItem;
  hasMetaFieldPackageNameUboGuiDotMenuDotTypes(): boolean;
  clearMetaFieldPackageNameUboGuiDotMenuDotTypes(): ApplicationItem;

  getApplication(): ApplicationItem.Application | undefined;
  setApplication(value?: ApplicationItem.Application): ApplicationItem;
  hasApplication(): boolean;
  clearApplication(): ApplicationItem;

  getKey(): string;
  setKey(value: string): ApplicationItem;
  hasKey(): boolean;
  clearKey(): ApplicationItem;

  getLabel(): string;
  setLabel(value: string): ApplicationItem;
  hasLabel(): boolean;
  clearLabel(): ApplicationItem;

  getColor(): string;
  setColor(value: string): ApplicationItem;
  hasColor(): boolean;
  clearColor(): ApplicationItem;

  getBackgroundColor(): string;
  setBackgroundColor(value: string): ApplicationItem;
  hasBackgroundColor(): boolean;
  clearBackgroundColor(): ApplicationItem;

  getIcon(): string;
  setIcon(value: string): ApplicationItem;
  hasIcon(): boolean;
  clearIcon(): ApplicationItem;

  getIsShort(): boolean;
  setIsShort(value: boolean): ApplicationItem;
  hasIsShort(): boolean;
  clearIsShort(): ApplicationItem;

  getOpacity(): number;
  setOpacity(value: number): ApplicationItem;
  hasOpacity(): boolean;
  clearOpacity(): ApplicationItem;

  getProgress(): number;
  setProgress(value: number): ApplicationItem;
  hasProgress(): boolean;
  clearProgress(): ApplicationItem;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ApplicationItem.AsObject;
  static toObject(includeInstance: boolean, msg: ApplicationItem): ApplicationItem.AsObject;
  static serializeBinaryToWriter(message: ApplicationItem, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ApplicationItem;
  static deserializeBinaryFromReader(message: ApplicationItem, reader: jspb.BinaryReader): ApplicationItem;
}

export namespace ApplicationItem {
  export type AsObject = {
    metaFieldPackageNameUboGuiDotMenuDotTypes?: string,
    application?: ApplicationItem.Application.AsObject,
    key?: string,
    label?: string,
    color?: string,
    backgroundColor?: string,
    icon?: string,
    isShort?: boolean,
    opacity?: number,
    progress?: number,
  }

  export class Application extends jspb.Message {
    getString(): string;
    setString(value: string): Application;

    getApplicationCase(): Application.ApplicationCase;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): Application.AsObject;
    static toObject(includeInstance: boolean, msg: Application): Application.AsObject;
    static serializeBinaryToWriter(message: Application, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): Application;
    static deserializeBinaryFromReader(message: Application, reader: jspb.BinaryReader): Application;
  }

  export namespace Application {
    export type AsObject = {
      string: string,
    }

    export enum ApplicationCase { 
      APPLICATION_NOT_SET = 0,
      STRING = 1,
    }
  }


  export enum MetaFieldPackageNameUboGuiDotMenuDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_GUI_DOT_MENU_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_GUI_DOT_MENU_DOT_TYPES = 1000,
  }

  export enum KeyCase { 
    _KEY_NOT_SET = 0,
    KEY = 3,
  }

  export enum LabelCase { 
    _LABEL_NOT_SET = 0,
    LABEL = 4,
  }

  export enum ColorCase { 
    _COLOR_NOT_SET = 0,
    COLOR = 5,
  }

  export enum BackgroundColorCase { 
    _BACKGROUND_COLOR_NOT_SET = 0,
    BACKGROUND_COLOR = 6,
  }

  export enum IconCase { 
    _ICON_NOT_SET = 0,
    ICON = 7,
  }

  export enum IsShortCase { 
    _IS_SHORT_NOT_SET = 0,
    IS_SHORT = 8,
  }

  export enum OpacityCase { 
    _OPACITY_NOT_SET = 0,
    OPACITY = 9,
  }

  export enum ProgressCase { 
    _PROGRESS_NOT_SET = 0,
    PROGRESS = 10,
  }
}

export class SubMenuItem extends jspb.Message {
  getMetaFieldPackageNameUboGuiDotMenuDotTypes(): string;
  setMetaFieldPackageNameUboGuiDotMenuDotTypes(value: string): SubMenuItem;
  hasMetaFieldPackageNameUboGuiDotMenuDotTypes(): boolean;
  clearMetaFieldPackageNameUboGuiDotMenuDotTypes(): SubMenuItem;

  getSubMenu(): Menu | undefined;
  setSubMenu(value?: Menu): SubMenuItem;
  hasSubMenu(): boolean;
  clearSubMenu(): SubMenuItem;

  getKey(): string;
  setKey(value: string): SubMenuItem;
  hasKey(): boolean;
  clearKey(): SubMenuItem;

  getLabel(): string;
  setLabel(value: string): SubMenuItem;
  hasLabel(): boolean;
  clearLabel(): SubMenuItem;

  getColor(): string;
  setColor(value: string): SubMenuItem;
  hasColor(): boolean;
  clearColor(): SubMenuItem;

  getBackgroundColor(): string;
  setBackgroundColor(value: string): SubMenuItem;
  hasBackgroundColor(): boolean;
  clearBackgroundColor(): SubMenuItem;

  getIcon(): string;
  setIcon(value: string): SubMenuItem;
  hasIcon(): boolean;
  clearIcon(): SubMenuItem;

  getIsShort(): boolean;
  setIsShort(value: boolean): SubMenuItem;
  hasIsShort(): boolean;
  clearIsShort(): SubMenuItem;

  getOpacity(): number;
  setOpacity(value: number): SubMenuItem;
  hasOpacity(): boolean;
  clearOpacity(): SubMenuItem;

  getProgress(): number;
  setProgress(value: number): SubMenuItem;
  hasProgress(): boolean;
  clearProgress(): SubMenuItem;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SubMenuItem.AsObject;
  static toObject(includeInstance: boolean, msg: SubMenuItem): SubMenuItem.AsObject;
  static serializeBinaryToWriter(message: SubMenuItem, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SubMenuItem;
  static deserializeBinaryFromReader(message: SubMenuItem, reader: jspb.BinaryReader): SubMenuItem;
}

export namespace SubMenuItem {
  export type AsObject = {
    metaFieldPackageNameUboGuiDotMenuDotTypes?: string,
    subMenu?: Menu.AsObject,
    key?: string,
    label?: string,
    color?: string,
    backgroundColor?: string,
    icon?: string,
    isShort?: boolean,
    opacity?: number,
    progress?: number,
  }

  export enum MetaFieldPackageNameUboGuiDotMenuDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_GUI_DOT_MENU_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_GUI_DOT_MENU_DOT_TYPES = 1000,
  }

  export enum KeyCase { 
    _KEY_NOT_SET = 0,
    KEY = 3,
  }

  export enum LabelCase { 
    _LABEL_NOT_SET = 0,
    LABEL = 4,
  }

  export enum ColorCase { 
    _COLOR_NOT_SET = 0,
    COLOR = 5,
  }

  export enum BackgroundColorCase { 
    _BACKGROUND_COLOR_NOT_SET = 0,
    BACKGROUND_COLOR = 6,
  }

  export enum IconCase { 
    _ICON_NOT_SET = 0,
    ICON = 7,
  }

  export enum IsShortCase { 
    _IS_SHORT_NOT_SET = 0,
    IS_SHORT = 8,
  }

  export enum OpacityCase { 
    _OPACITY_NOT_SET = 0,
    OPACITY = 9,
  }

  export enum ProgressCase { 
    _PROGRESS_NOT_SET = 0,
    PROGRESS = 10,
  }
}

export class Menu extends jspb.Message {
  getHeadedMenu(): HeadedMenu | undefined;
  setHeadedMenu(value?: HeadedMenu): Menu;
  hasHeadedMenu(): boolean;
  clearHeadedMenu(): Menu;

  getHeadlessMenu(): HeadlessMenu | undefined;
  setHeadlessMenu(value?: HeadlessMenu): Menu;
  hasHeadlessMenu(): boolean;
  clearHeadlessMenu(): Menu;

  getMenuCase(): Menu.MenuCase;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Menu.AsObject;
  static toObject(includeInstance: boolean, msg: Menu): Menu.AsObject;
  static serializeBinaryToWriter(message: Menu, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Menu;
  static deserializeBinaryFromReader(message: Menu, reader: jspb.BinaryReader): Menu;
}

export namespace Menu {
  export type AsObject = {
    headedMenu?: HeadedMenu.AsObject,
    headlessMenu?: HeadlessMenu.AsObject,
  }

  export enum MenuCase { 
    MENU_NOT_SET = 0,
    HEADED_MENU = 1,
    HEADLESS_MENU = 2,
  }
}

export class MainAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(value: string): MainAction;
  hasMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): MainAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): MainAction.AsObject;
  static toObject(includeInstance: boolean, msg: MainAction): MainAction.AsObject;
  static serializeBinaryToWriter(message: MainAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): MainAction;
  static deserializeBinaryFromReader(message: MainAction, reader: jspb.BinaryReader): MainAction;
}

export namespace MainAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotCoreDotTypes?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotCoreDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES = 1000,
  }
}

export class UpdateLightDMState extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(value: string): UpdateLightDMState;
  hasMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): UpdateLightDMState;

  getIsActive(): boolean;
  setIsActive(value: boolean): UpdateLightDMState;

  getIsEnable(): boolean;
  setIsEnable(value: boolean): UpdateLightDMState;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): UpdateLightDMState.AsObject;
  static toObject(includeInstance: boolean, msg: UpdateLightDMState): UpdateLightDMState.AsObject;
  static serializeBinaryToWriter(message: UpdateLightDMState, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): UpdateLightDMState;
  static deserializeBinaryFromReader(message: UpdateLightDMState, reader: jspb.BinaryReader): UpdateLightDMState;
}

export namespace UpdateLightDMState {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotCoreDotTypes?: string,
    isActive: boolean,
    isEnable: boolean,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotCoreDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES = 1000,
  }
}

export class RegisterAppAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(value: string): RegisterAppAction;
  hasMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): RegisterAppAction;

  getMenuItem(): Item | undefined;
  setMenuItem(value?: Item): RegisterAppAction;
  hasMenuItem(): boolean;
  clearMenuItem(): RegisterAppAction;

  getService(): string;
  setService(value: string): RegisterAppAction;
  hasService(): boolean;
  clearService(): RegisterAppAction;

  getKey(): string;
  setKey(value: string): RegisterAppAction;
  hasKey(): boolean;
  clearKey(): RegisterAppAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): RegisterAppAction.AsObject;
  static toObject(includeInstance: boolean, msg: RegisterAppAction): RegisterAppAction.AsObject;
  static serializeBinaryToWriter(message: RegisterAppAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): RegisterAppAction;
  static deserializeBinaryFromReader(message: RegisterAppAction, reader: jspb.BinaryReader): RegisterAppAction;
}

export namespace RegisterAppAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotCoreDotTypes?: string,
    menuItem?: Item.AsObject,
    service?: string,
    key?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotCoreDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES = 1000,
  }

  export enum ServiceCase { 
    _SERVICE_NOT_SET = 0,
    SERVICE = 3,
  }

  export enum KeyCase { 
    _KEY_NOT_SET = 0,
    KEY = 4,
  }
}

export class RegisterRegularAppAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(value: string): RegisterRegularAppAction;
  hasMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): RegisterRegularAppAction;

  getPriority(): number;
  setPriority(value: number): RegisterRegularAppAction;
  hasPriority(): boolean;
  clearPriority(): RegisterRegularAppAction;

  getMenuItem(): Item | undefined;
  setMenuItem(value?: Item): RegisterRegularAppAction;
  hasMenuItem(): boolean;
  clearMenuItem(): RegisterRegularAppAction;

  getService(): string;
  setService(value: string): RegisterRegularAppAction;
  hasService(): boolean;
  clearService(): RegisterRegularAppAction;

  getKey(): string;
  setKey(value: string): RegisterRegularAppAction;
  hasKey(): boolean;
  clearKey(): RegisterRegularAppAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): RegisterRegularAppAction.AsObject;
  static toObject(includeInstance: boolean, msg: RegisterRegularAppAction): RegisterRegularAppAction.AsObject;
  static serializeBinaryToWriter(message: RegisterRegularAppAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): RegisterRegularAppAction;
  static deserializeBinaryFromReader(message: RegisterRegularAppAction, reader: jspb.BinaryReader): RegisterRegularAppAction;
}

export namespace RegisterRegularAppAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotCoreDotTypes?: string,
    priority?: number,
    menuItem?: Item.AsObject,
    service?: string,
    key?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotCoreDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES = 1000,
  }

  export enum PriorityCase { 
    _PRIORITY_NOT_SET = 0,
    PRIORITY = 2,
  }

  export enum ServiceCase { 
    _SERVICE_NOT_SET = 0,
    SERVICE = 4,
  }

  export enum KeyCase { 
    _KEY_NOT_SET = 0,
    KEY = 5,
  }
}

export class DeregisterRegularAppAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(value: string): DeregisterRegularAppAction;
  hasMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): DeregisterRegularAppAction;

  getService(): string;
  setService(value: string): DeregisterRegularAppAction;
  hasService(): boolean;
  clearService(): DeregisterRegularAppAction;

  getKey(): string;
  setKey(value: string): DeregisterRegularAppAction;
  hasKey(): boolean;
  clearKey(): DeregisterRegularAppAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DeregisterRegularAppAction.AsObject;
  static toObject(includeInstance: boolean, msg: DeregisterRegularAppAction): DeregisterRegularAppAction.AsObject;
  static serializeBinaryToWriter(message: DeregisterRegularAppAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DeregisterRegularAppAction;
  static deserializeBinaryFromReader(message: DeregisterRegularAppAction, reader: jspb.BinaryReader): DeregisterRegularAppAction;
}

export namespace DeregisterRegularAppAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotCoreDotTypes?: string,
    service?: string,
    key?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotCoreDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES = 1000,
  }

  export enum ServiceCase { 
    _SERVICE_NOT_SET = 0,
    SERVICE = 2,
  }

  export enum KeyCase { 
    _KEY_NOT_SET = 0,
    KEY = 3,
  }
}

export class RegisterSettingAppAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(value: string): RegisterSettingAppAction;
  hasMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): RegisterSettingAppAction;

  getCategory(): SettingsCategory;
  setCategory(value: SettingsCategory): RegisterSettingAppAction;

  getPriority(): number;
  setPriority(value: number): RegisterSettingAppAction;
  hasPriority(): boolean;
  clearPriority(): RegisterSettingAppAction;

  getMenuItem(): Item | undefined;
  setMenuItem(value?: Item): RegisterSettingAppAction;
  hasMenuItem(): boolean;
  clearMenuItem(): RegisterSettingAppAction;

  getService(): string;
  setService(value: string): RegisterSettingAppAction;
  hasService(): boolean;
  clearService(): RegisterSettingAppAction;

  getKey(): string;
  setKey(value: string): RegisterSettingAppAction;
  hasKey(): boolean;
  clearKey(): RegisterSettingAppAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): RegisterSettingAppAction.AsObject;
  static toObject(includeInstance: boolean, msg: RegisterSettingAppAction): RegisterSettingAppAction.AsObject;
  static serializeBinaryToWriter(message: RegisterSettingAppAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): RegisterSettingAppAction;
  static deserializeBinaryFromReader(message: RegisterSettingAppAction, reader: jspb.BinaryReader): RegisterSettingAppAction;
}

export namespace RegisterSettingAppAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotCoreDotTypes?: string,
    category: SettingsCategory,
    priority?: number,
    menuItem?: Item.AsObject,
    service?: string,
    key?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotCoreDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES = 1000,
  }

  export enum PriorityCase { 
    _PRIORITY_NOT_SET = 0,
    PRIORITY = 3,
  }

  export enum ServiceCase { 
    _SERVICE_NOT_SET = 0,
    SERVICE = 5,
  }

  export enum KeyCase { 
    _KEY_NOT_SET = 0,
    KEY = 6,
  }
}

export class PowerAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(value: string): PowerAction;
  hasMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): PowerAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): PowerAction.AsObject;
  static toObject(includeInstance: boolean, msg: PowerAction): PowerAction.AsObject;
  static serializeBinaryToWriter(message: PowerAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): PowerAction;
  static deserializeBinaryFromReader(message: PowerAction, reader: jspb.BinaryReader): PowerAction;
}

export namespace PowerAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotCoreDotTypes?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotCoreDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES = 1000,
  }
}

export class PowerOffAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(value: string): PowerOffAction;
  hasMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): PowerOffAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): PowerOffAction.AsObject;
  static toObject(includeInstance: boolean, msg: PowerOffAction): PowerOffAction.AsObject;
  static serializeBinaryToWriter(message: PowerOffAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): PowerOffAction;
  static deserializeBinaryFromReader(message: PowerOffAction, reader: jspb.BinaryReader): PowerOffAction;
}

export namespace PowerOffAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotCoreDotTypes?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotCoreDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES = 1000,
  }
}

export class RebootAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(value: string): RebootAction;
  hasMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): RebootAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): RebootAction.AsObject;
  static toObject(includeInstance: boolean, msg: RebootAction): RebootAction.AsObject;
  static serializeBinaryToWriter(message: RebootAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): RebootAction;
  static deserializeBinaryFromReader(message: RebootAction, reader: jspb.BinaryReader): RebootAction;
}

export namespace RebootAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotCoreDotTypes?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotCoreDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES = 1000,
  }
}

export class SetMenuPathAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(value: string): SetMenuPathAction;
  hasMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): SetMenuPathAction;

  getPathList(): Array<string>;
  setPathList(value: Array<string>): SetMenuPathAction;
  clearPathList(): SetMenuPathAction;
  addPath(value: string, index?: number): SetMenuPathAction;

  getDepth(): number;
  setDepth(value: number): SetMenuPathAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SetMenuPathAction.AsObject;
  static toObject(includeInstance: boolean, msg: SetMenuPathAction): SetMenuPathAction.AsObject;
  static serializeBinaryToWriter(message: SetMenuPathAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SetMenuPathAction;
  static deserializeBinaryFromReader(message: SetMenuPathAction, reader: jspb.BinaryReader): SetMenuPathAction;
}

export namespace SetMenuPathAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotCoreDotTypes?: string,
    pathList: Array<string>,
    depth: number,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotCoreDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES = 1000,
  }
}

export class SetAreEnclosuresVisibleAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(value: string): SetAreEnclosuresVisibleAction;
  hasMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): SetAreEnclosuresVisibleAction;

  getIsHeaderVisible(): boolean;
  setIsHeaderVisible(value: boolean): SetAreEnclosuresVisibleAction;
  hasIsHeaderVisible(): boolean;
  clearIsHeaderVisible(): SetAreEnclosuresVisibleAction;

  getIsFooterVisible(): boolean;
  setIsFooterVisible(value: boolean): SetAreEnclosuresVisibleAction;
  hasIsFooterVisible(): boolean;
  clearIsFooterVisible(): SetAreEnclosuresVisibleAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SetAreEnclosuresVisibleAction.AsObject;
  static toObject(includeInstance: boolean, msg: SetAreEnclosuresVisibleAction): SetAreEnclosuresVisibleAction.AsObject;
  static serializeBinaryToWriter(message: SetAreEnclosuresVisibleAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SetAreEnclosuresVisibleAction;
  static deserializeBinaryFromReader(message: SetAreEnclosuresVisibleAction, reader: jspb.BinaryReader): SetAreEnclosuresVisibleAction;
}

export namespace SetAreEnclosuresVisibleAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotCoreDotTypes?: string,
    isHeaderVisible?: boolean,
    isFooterVisible?: boolean,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotCoreDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES = 1000,
  }

  export enum IsHeaderVisibleCase { 
    _IS_HEADER_VISIBLE_NOT_SET = 0,
    IS_HEADER_VISIBLE = 2,
  }

  export enum IsFooterVisibleCase { 
    _IS_FOOTER_VISIBLE_NOT_SET = 0,
    IS_FOOTER_VISIBLE = 3,
  }
}

export class MenuAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(value: string): MenuAction;
  hasMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): MenuAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): MenuAction.AsObject;
  static toObject(includeInstance: boolean, msg: MenuAction): MenuAction.AsObject;
  static serializeBinaryToWriter(message: MenuAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): MenuAction;
  static deserializeBinaryFromReader(message: MenuAction, reader: jspb.BinaryReader): MenuAction;
}

export namespace MenuAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotCoreDotTypes?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotCoreDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES = 1000,
  }
}

export class MenuGoBackAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(value: string): MenuGoBackAction;
  hasMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): MenuGoBackAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): MenuGoBackAction.AsObject;
  static toObject(includeInstance: boolean, msg: MenuGoBackAction): MenuGoBackAction.AsObject;
  static serializeBinaryToWriter(message: MenuGoBackAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): MenuGoBackAction;
  static deserializeBinaryFromReader(message: MenuGoBackAction, reader: jspb.BinaryReader): MenuGoBackAction;
}

export namespace MenuGoBackAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotCoreDotTypes?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotCoreDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES = 1000,
  }
}

export class MenuGoHomeAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(value: string): MenuGoHomeAction;
  hasMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): MenuGoHomeAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): MenuGoHomeAction.AsObject;
  static toObject(includeInstance: boolean, msg: MenuGoHomeAction): MenuGoHomeAction.AsObject;
  static serializeBinaryToWriter(message: MenuGoHomeAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): MenuGoHomeAction;
  static deserializeBinaryFromReader(message: MenuGoHomeAction, reader: jspb.BinaryReader): MenuGoHomeAction;
}

export namespace MenuGoHomeAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotCoreDotTypes?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotCoreDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES = 1000,
  }
}

export class MenuChooseByIconAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(value: string): MenuChooseByIconAction;
  hasMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): MenuChooseByIconAction;

  getIcon(): string;
  setIcon(value: string): MenuChooseByIconAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): MenuChooseByIconAction.AsObject;
  static toObject(includeInstance: boolean, msg: MenuChooseByIconAction): MenuChooseByIconAction.AsObject;
  static serializeBinaryToWriter(message: MenuChooseByIconAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): MenuChooseByIconAction;
  static deserializeBinaryFromReader(message: MenuChooseByIconAction, reader: jspb.BinaryReader): MenuChooseByIconAction;
}

export namespace MenuChooseByIconAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotCoreDotTypes?: string,
    icon: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotCoreDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES = 1000,
  }
}

export class MenuChooseByLabelAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(value: string): MenuChooseByLabelAction;
  hasMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): MenuChooseByLabelAction;

  getLabel(): string;
  setLabel(value: string): MenuChooseByLabelAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): MenuChooseByLabelAction.AsObject;
  static toObject(includeInstance: boolean, msg: MenuChooseByLabelAction): MenuChooseByLabelAction.AsObject;
  static serializeBinaryToWriter(message: MenuChooseByLabelAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): MenuChooseByLabelAction;
  static deserializeBinaryFromReader(message: MenuChooseByLabelAction, reader: jspb.BinaryReader): MenuChooseByLabelAction;
}

export namespace MenuChooseByLabelAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotCoreDotTypes?: string,
    label: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotCoreDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES = 1000,
  }
}

export class MenuChooseByIndexAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(value: string): MenuChooseByIndexAction;
  hasMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): MenuChooseByIndexAction;

  getIndex(): number;
  setIndex(value: number): MenuChooseByIndexAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): MenuChooseByIndexAction.AsObject;
  static toObject(includeInstance: boolean, msg: MenuChooseByIndexAction): MenuChooseByIndexAction.AsObject;
  static serializeBinaryToWriter(message: MenuChooseByIndexAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): MenuChooseByIndexAction;
  static deserializeBinaryFromReader(message: MenuChooseByIndexAction, reader: jspb.BinaryReader): MenuChooseByIndexAction;
}

export namespace MenuChooseByIndexAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotCoreDotTypes?: string,
    index: number,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotCoreDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES = 1000,
  }
}

export class MenuScrollAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(value: string): MenuScrollAction;
  hasMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): MenuScrollAction;

  getDirection(): MenuScrollDirection;
  setDirection(value: MenuScrollDirection): MenuScrollAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): MenuScrollAction.AsObject;
  static toObject(includeInstance: boolean, msg: MenuScrollAction): MenuScrollAction.AsObject;
  static serializeBinaryToWriter(message: MenuScrollAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): MenuScrollAction;
  static deserializeBinaryFromReader(message: MenuScrollAction, reader: jspb.BinaryReader): MenuScrollAction;
}

export namespace MenuScrollAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotCoreDotTypes?: string,
    direction: MenuScrollDirection,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotCoreDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES = 1000,
  }
}

export class OpenApplicationAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(value: string): OpenApplicationAction;
  hasMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): OpenApplicationAction;

  getApplicationId(): string;
  setApplicationId(value: string): OpenApplicationAction;

  getInitializationArgs(): OpenApplicationAction.InitializationArgs | undefined;
  setInitializationArgs(value?: OpenApplicationAction.InitializationArgs): OpenApplicationAction;
  hasInitializationArgs(): boolean;
  clearInitializationArgs(): OpenApplicationAction;

  getInitializationKwargs(): OpenApplicationAction.InitializationKwargsDict | undefined;
  setInitializationKwargs(value?: OpenApplicationAction.InitializationKwargsDict): OpenApplicationAction;
  hasInitializationKwargs(): boolean;
  clearInitializationKwargs(): OpenApplicationAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): OpenApplicationAction.AsObject;
  static toObject(includeInstance: boolean, msg: OpenApplicationAction): OpenApplicationAction.AsObject;
  static serializeBinaryToWriter(message: OpenApplicationAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): OpenApplicationAction;
  static deserializeBinaryFromReader(message: OpenApplicationAction, reader: jspb.BinaryReader): OpenApplicationAction;
}

export namespace OpenApplicationAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotCoreDotTypes?: string,
    applicationId: string,
    initializationArgs?: OpenApplicationAction.InitializationArgs.AsObject,
    initializationKwargs?: OpenApplicationAction.InitializationKwargsDict.AsObject,
  }

  export class InitializationArgs extends jspb.Message {
    getItemsList(): Array<BasicType>;
    setItemsList(value: Array<BasicType>): InitializationArgs;
    clearItemsList(): InitializationArgs;
    addItems(value?: BasicType, index?: number): BasicType;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): InitializationArgs.AsObject;
    static toObject(includeInstance: boolean, msg: InitializationArgs): InitializationArgs.AsObject;
    static serializeBinaryToWriter(message: InitializationArgs, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): InitializationArgs;
    static deserializeBinaryFromReader(message: InitializationArgs, reader: jspb.BinaryReader): InitializationArgs;
  }

  export namespace InitializationArgs {
    export type AsObject = {
      itemsList: Array<BasicType.AsObject>,
    }
  }


  export class InitializationKwargsValue2 extends jspb.Message {
    getItemsList(): Array<BasicType>;
    setItemsList(value: Array<BasicType>): InitializationKwargsValue2;
    clearItemsList(): InitializationKwargsValue2;
    addItems(value?: BasicType, index?: number): BasicType;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): InitializationKwargsValue2.AsObject;
    static toObject(includeInstance: boolean, msg: InitializationKwargsValue2): InitializationKwargsValue2.AsObject;
    static serializeBinaryToWriter(message: InitializationKwargsValue2, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): InitializationKwargsValue2;
    static deserializeBinaryFromReader(message: InitializationKwargsValue2, reader: jspb.BinaryReader): InitializationKwargsValue2;
  }

  export namespace InitializationKwargsValue2 {
    export type AsObject = {
      itemsList: Array<BasicType.AsObject>,
    }
  }


  export class InitializationKwargsValue extends jspb.Message {
    getBasicType(): BasicType | undefined;
    setBasicType(value?: BasicType): InitializationKwargsValue;
    hasBasicType(): boolean;
    clearBasicType(): InitializationKwargsValue;

    getList(): OpenApplicationAction.InitializationKwargsValue2 | undefined;
    setList(value?: OpenApplicationAction.InitializationKwargsValue2): InitializationKwargsValue;
    hasList(): boolean;
    clearList(): InitializationKwargsValue;

    getInitializationKwargsValueCase(): InitializationKwargsValue.InitializationKwargsValueCase;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): InitializationKwargsValue.AsObject;
    static toObject(includeInstance: boolean, msg: InitializationKwargsValue): InitializationKwargsValue.AsObject;
    static serializeBinaryToWriter(message: InitializationKwargsValue, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): InitializationKwargsValue;
    static deserializeBinaryFromReader(message: InitializationKwargsValue, reader: jspb.BinaryReader): InitializationKwargsValue;
  }

  export namespace InitializationKwargsValue {
    export type AsObject = {
      basicType?: BasicType.AsObject,
      list?: OpenApplicationAction.InitializationKwargsValue2.AsObject,
    }

    export enum InitializationKwargsValueCase { 
      INITIALIZATION_KWARGS_VALUE_NOT_SET = 0,
      BASIC_TYPE = 1,
      LIST = 2,
    }
  }


  export class InitializationKwargsDict extends jspb.Message {
    getItemsMap(): jspb.Map<string, OpenApplicationAction.InitializationKwargsValue>;
    clearItemsMap(): InitializationKwargsDict;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): InitializationKwargsDict.AsObject;
    static toObject(includeInstance: boolean, msg: InitializationKwargsDict): InitializationKwargsDict.AsObject;
    static serializeBinaryToWriter(message: InitializationKwargsDict, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): InitializationKwargsDict;
    static deserializeBinaryFromReader(message: InitializationKwargsDict, reader: jspb.BinaryReader): InitializationKwargsDict;
  }

  export namespace InitializationKwargsDict {
    export type AsObject = {
      itemsMap: Array<[string, OpenApplicationAction.InitializationKwargsValue.AsObject]>,
    }
  }


  export enum MetaFieldPackageNameUboAppDotStoreDotCoreDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES = 1000,
  }

  export enum InitializationArgsCase { 
    _INITIALIZATION_ARGS_NOT_SET = 0,
    INITIALIZATION_ARGS = 3,
  }

  export enum InitializationKwargsCase { 
    _INITIALIZATION_KWARGS_NOT_SET = 0,
    INITIALIZATION_KWARGS = 4,
  }
}

export class CloseApplicationAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(value: string): CloseApplicationAction;
  hasMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): CloseApplicationAction;

  getApplicationInstanceId(): string;
  setApplicationInstanceId(value: string): CloseApplicationAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): CloseApplicationAction.AsObject;
  static toObject(includeInstance: boolean, msg: CloseApplicationAction): CloseApplicationAction.AsObject;
  static serializeBinaryToWriter(message: CloseApplicationAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): CloseApplicationAction;
  static deserializeBinaryFromReader(message: CloseApplicationAction, reader: jspb.BinaryReader): CloseApplicationAction;
}

export namespace CloseApplicationAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotCoreDotTypes?: string,
    applicationInstanceId: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotCoreDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES = 1000,
  }
}

export class MainEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(value: string): MainEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): MainEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): MainEvent.AsObject;
  static toObject(includeInstance: boolean, msg: MainEvent): MainEvent.AsObject;
  static serializeBinaryToWriter(message: MainEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): MainEvent;
  static deserializeBinaryFromReader(message: MainEvent, reader: jspb.BinaryReader): MainEvent;
}

export namespace MainEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotCoreDotTypes?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotCoreDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES = 1000,
  }
}

export class InitEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(value: string): InitEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): InitEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): InitEvent.AsObject;
  static toObject(includeInstance: boolean, msg: InitEvent): InitEvent.AsObject;
  static serializeBinaryToWriter(message: InitEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): InitEvent;
  static deserializeBinaryFromReader(message: InitEvent, reader: jspb.BinaryReader): InitEvent;
}

export namespace InitEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotCoreDotTypes?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotCoreDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES = 1000,
  }
}

export class MenuEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(value: string): MenuEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): MenuEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): MenuEvent.AsObject;
  static toObject(includeInstance: boolean, msg: MenuEvent): MenuEvent.AsObject;
  static serializeBinaryToWriter(message: MenuEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): MenuEvent;
  static deserializeBinaryFromReader(message: MenuEvent, reader: jspb.BinaryReader): MenuEvent;
}

export namespace MenuEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotCoreDotTypes?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotCoreDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES = 1000,
  }
}

export class MenuGoBackEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(value: string): MenuGoBackEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): MenuGoBackEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): MenuGoBackEvent.AsObject;
  static toObject(includeInstance: boolean, msg: MenuGoBackEvent): MenuGoBackEvent.AsObject;
  static serializeBinaryToWriter(message: MenuGoBackEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): MenuGoBackEvent;
  static deserializeBinaryFromReader(message: MenuGoBackEvent, reader: jspb.BinaryReader): MenuGoBackEvent;
}

export namespace MenuGoBackEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotCoreDotTypes?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotCoreDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES = 1000,
  }
}

export class MenuGoHomeEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(value: string): MenuGoHomeEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): MenuGoHomeEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): MenuGoHomeEvent.AsObject;
  static toObject(includeInstance: boolean, msg: MenuGoHomeEvent): MenuGoHomeEvent.AsObject;
  static serializeBinaryToWriter(message: MenuGoHomeEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): MenuGoHomeEvent;
  static deserializeBinaryFromReader(message: MenuGoHomeEvent, reader: jspb.BinaryReader): MenuGoHomeEvent;
}

export namespace MenuGoHomeEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotCoreDotTypes?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotCoreDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES = 1000,
  }
}

export class MenuChooseByIconEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(value: string): MenuChooseByIconEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): MenuChooseByIconEvent;

  getIcon(): string;
  setIcon(value: string): MenuChooseByIconEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): MenuChooseByIconEvent.AsObject;
  static toObject(includeInstance: boolean, msg: MenuChooseByIconEvent): MenuChooseByIconEvent.AsObject;
  static serializeBinaryToWriter(message: MenuChooseByIconEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): MenuChooseByIconEvent;
  static deserializeBinaryFromReader(message: MenuChooseByIconEvent, reader: jspb.BinaryReader): MenuChooseByIconEvent;
}

export namespace MenuChooseByIconEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotCoreDotTypes?: string,
    icon: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotCoreDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES = 1000,
  }
}

export class MenuChooseByLabelEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(value: string): MenuChooseByLabelEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): MenuChooseByLabelEvent;

  getLabel(): string;
  setLabel(value: string): MenuChooseByLabelEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): MenuChooseByLabelEvent.AsObject;
  static toObject(includeInstance: boolean, msg: MenuChooseByLabelEvent): MenuChooseByLabelEvent.AsObject;
  static serializeBinaryToWriter(message: MenuChooseByLabelEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): MenuChooseByLabelEvent;
  static deserializeBinaryFromReader(message: MenuChooseByLabelEvent, reader: jspb.BinaryReader): MenuChooseByLabelEvent;
}

export namespace MenuChooseByLabelEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotCoreDotTypes?: string,
    label: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotCoreDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES = 1000,
  }
}

export class MenuChooseByIndexEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(value: string): MenuChooseByIndexEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): MenuChooseByIndexEvent;

  getIndex(): number;
  setIndex(value: number): MenuChooseByIndexEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): MenuChooseByIndexEvent.AsObject;
  static toObject(includeInstance: boolean, msg: MenuChooseByIndexEvent): MenuChooseByIndexEvent.AsObject;
  static serializeBinaryToWriter(message: MenuChooseByIndexEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): MenuChooseByIndexEvent;
  static deserializeBinaryFromReader(message: MenuChooseByIndexEvent, reader: jspb.BinaryReader): MenuChooseByIndexEvent;
}

export namespace MenuChooseByIndexEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotCoreDotTypes?: string,
    index: number,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotCoreDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES = 1000,
  }
}

export class MenuScrollEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(value: string): MenuScrollEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): MenuScrollEvent;

  getDirection(): MenuScrollDirection;
  setDirection(value: MenuScrollDirection): MenuScrollEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): MenuScrollEvent.AsObject;
  static toObject(includeInstance: boolean, msg: MenuScrollEvent): MenuScrollEvent.AsObject;
  static serializeBinaryToWriter(message: MenuScrollEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): MenuScrollEvent;
  static deserializeBinaryFromReader(message: MenuScrollEvent, reader: jspb.BinaryReader): MenuScrollEvent;
}

export namespace MenuScrollEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotCoreDotTypes?: string,
    direction: MenuScrollDirection,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotCoreDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES = 1000,
  }
}

export class OpenApplicationEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(value: string): OpenApplicationEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): OpenApplicationEvent;

  getApplicationId(): string;
  setApplicationId(value: string): OpenApplicationEvent;

  getInitializationArgs(): OpenApplicationEvent.InitializationArgs | undefined;
  setInitializationArgs(value?: OpenApplicationEvent.InitializationArgs): OpenApplicationEvent;
  hasInitializationArgs(): boolean;
  clearInitializationArgs(): OpenApplicationEvent;

  getInitializationKwargs(): OpenApplicationEvent.InitializationKwargsDict | undefined;
  setInitializationKwargs(value?: OpenApplicationEvent.InitializationKwargsDict): OpenApplicationEvent;
  hasInitializationKwargs(): boolean;
  clearInitializationKwargs(): OpenApplicationEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): OpenApplicationEvent.AsObject;
  static toObject(includeInstance: boolean, msg: OpenApplicationEvent): OpenApplicationEvent.AsObject;
  static serializeBinaryToWriter(message: OpenApplicationEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): OpenApplicationEvent;
  static deserializeBinaryFromReader(message: OpenApplicationEvent, reader: jspb.BinaryReader): OpenApplicationEvent;
}

export namespace OpenApplicationEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotCoreDotTypes?: string,
    applicationId: string,
    initializationArgs?: OpenApplicationEvent.InitializationArgs.AsObject,
    initializationKwargs?: OpenApplicationEvent.InitializationKwargsDict.AsObject,
  }

  export class InitializationArgs extends jspb.Message {
    getItemsList(): Array<BasicType>;
    setItemsList(value: Array<BasicType>): InitializationArgs;
    clearItemsList(): InitializationArgs;
    addItems(value?: BasicType, index?: number): BasicType;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): InitializationArgs.AsObject;
    static toObject(includeInstance: boolean, msg: InitializationArgs): InitializationArgs.AsObject;
    static serializeBinaryToWriter(message: InitializationArgs, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): InitializationArgs;
    static deserializeBinaryFromReader(message: InitializationArgs, reader: jspb.BinaryReader): InitializationArgs;
  }

  export namespace InitializationArgs {
    export type AsObject = {
      itemsList: Array<BasicType.AsObject>,
    }
  }


  export class InitializationKwargsValue2 extends jspb.Message {
    getItemsList(): Array<BasicType>;
    setItemsList(value: Array<BasicType>): InitializationKwargsValue2;
    clearItemsList(): InitializationKwargsValue2;
    addItems(value?: BasicType, index?: number): BasicType;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): InitializationKwargsValue2.AsObject;
    static toObject(includeInstance: boolean, msg: InitializationKwargsValue2): InitializationKwargsValue2.AsObject;
    static serializeBinaryToWriter(message: InitializationKwargsValue2, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): InitializationKwargsValue2;
    static deserializeBinaryFromReader(message: InitializationKwargsValue2, reader: jspb.BinaryReader): InitializationKwargsValue2;
  }

  export namespace InitializationKwargsValue2 {
    export type AsObject = {
      itemsList: Array<BasicType.AsObject>,
    }
  }


  export class InitializationKwargsValue extends jspb.Message {
    getBasicType(): BasicType | undefined;
    setBasicType(value?: BasicType): InitializationKwargsValue;
    hasBasicType(): boolean;
    clearBasicType(): InitializationKwargsValue;

    getList(): OpenApplicationEvent.InitializationKwargsValue2 | undefined;
    setList(value?: OpenApplicationEvent.InitializationKwargsValue2): InitializationKwargsValue;
    hasList(): boolean;
    clearList(): InitializationKwargsValue;

    getInitializationKwargsValueCase(): InitializationKwargsValue.InitializationKwargsValueCase;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): InitializationKwargsValue.AsObject;
    static toObject(includeInstance: boolean, msg: InitializationKwargsValue): InitializationKwargsValue.AsObject;
    static serializeBinaryToWriter(message: InitializationKwargsValue, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): InitializationKwargsValue;
    static deserializeBinaryFromReader(message: InitializationKwargsValue, reader: jspb.BinaryReader): InitializationKwargsValue;
  }

  export namespace InitializationKwargsValue {
    export type AsObject = {
      basicType?: BasicType.AsObject,
      list?: OpenApplicationEvent.InitializationKwargsValue2.AsObject,
    }

    export enum InitializationKwargsValueCase { 
      INITIALIZATION_KWARGS_VALUE_NOT_SET = 0,
      BASIC_TYPE = 1,
      LIST = 2,
    }
  }


  export class InitializationKwargsDict extends jspb.Message {
    getItemsMap(): jspb.Map<string, OpenApplicationEvent.InitializationKwargsValue>;
    clearItemsMap(): InitializationKwargsDict;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): InitializationKwargsDict.AsObject;
    static toObject(includeInstance: boolean, msg: InitializationKwargsDict): InitializationKwargsDict.AsObject;
    static serializeBinaryToWriter(message: InitializationKwargsDict, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): InitializationKwargsDict;
    static deserializeBinaryFromReader(message: InitializationKwargsDict, reader: jspb.BinaryReader): InitializationKwargsDict;
  }

  export namespace InitializationKwargsDict {
    export type AsObject = {
      itemsMap: Array<[string, OpenApplicationEvent.InitializationKwargsValue.AsObject]>,
    }
  }


  export enum MetaFieldPackageNameUboAppDotStoreDotCoreDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES = 1000,
  }

  export enum InitializationArgsCase { 
    _INITIALIZATION_ARGS_NOT_SET = 0,
    INITIALIZATION_ARGS = 3,
  }

  export enum InitializationKwargsCase { 
    _INITIALIZATION_KWARGS_NOT_SET = 0,
    INITIALIZATION_KWARGS = 4,
  }
}

export class CloseApplicationEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(value: string): CloseApplicationEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): CloseApplicationEvent;

  getApplicationInstanceId(): string;
  setApplicationInstanceId(value: string): CloseApplicationEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): CloseApplicationEvent.AsObject;
  static toObject(includeInstance: boolean, msg: CloseApplicationEvent): CloseApplicationEvent.AsObject;
  static serializeBinaryToWriter(message: CloseApplicationEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): CloseApplicationEvent;
  static deserializeBinaryFromReader(message: CloseApplicationEvent, reader: jspb.BinaryReader): CloseApplicationEvent;
}

export namespace CloseApplicationEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotCoreDotTypes?: string,
    applicationInstanceId: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotCoreDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES = 1000,
  }
}

export class PowerEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(value: string): PowerEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): PowerEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): PowerEvent.AsObject;
  static toObject(includeInstance: boolean, msg: PowerEvent): PowerEvent.AsObject;
  static serializeBinaryToWriter(message: PowerEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): PowerEvent;
  static deserializeBinaryFromReader(message: PowerEvent, reader: jspb.BinaryReader): PowerEvent;
}

export namespace PowerEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotCoreDotTypes?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotCoreDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES = 1000,
  }
}

export class PowerOffEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(value: string): PowerOffEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): PowerOffEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): PowerOffEvent.AsObject;
  static toObject(includeInstance: boolean, msg: PowerOffEvent): PowerOffEvent.AsObject;
  static serializeBinaryToWriter(message: PowerOffEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): PowerOffEvent;
  static deserializeBinaryFromReader(message: PowerOffEvent, reader: jspb.BinaryReader): PowerOffEvent;
}

export namespace PowerOffEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotCoreDotTypes?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotCoreDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES = 1000,
  }
}

export class RebootEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(value: string): RebootEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): RebootEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): RebootEvent.AsObject;
  static toObject(includeInstance: boolean, msg: RebootEvent): RebootEvent.AsObject;
  static serializeBinaryToWriter(message: RebootEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): RebootEvent;
  static deserializeBinaryFromReader(message: RebootEvent, reader: jspb.BinaryReader): RebootEvent;
}

export namespace RebootEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotCoreDotTypes?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotCoreDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES = 1000,
  }
}

export class ScreenshotEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(value: string): ScreenshotEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): ScreenshotEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ScreenshotEvent.AsObject;
  static toObject(includeInstance: boolean, msg: ScreenshotEvent): ScreenshotEvent.AsObject;
  static serializeBinaryToWriter(message: ScreenshotEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ScreenshotEvent;
  static deserializeBinaryFromReader(message: ScreenshotEvent, reader: jspb.BinaryReader): ScreenshotEvent;
}

export namespace ScreenshotEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotCoreDotTypes?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotCoreDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES = 1000,
  }
}

export class SnapshotEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(value: string): SnapshotEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): SnapshotEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SnapshotEvent.AsObject;
  static toObject(includeInstance: boolean, msg: SnapshotEvent): SnapshotEvent.AsObject;
  static serializeBinaryToWriter(message: SnapshotEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SnapshotEvent;
  static deserializeBinaryFromReader(message: SnapshotEvent, reader: jspb.BinaryReader): SnapshotEvent;
}

export namespace SnapshotEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotCoreDotTypes?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotCoreDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES = 1000,
  }
}

export class ToggleRecordingAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(value: string): ToggleRecordingAction;
  hasMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): ToggleRecordingAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ToggleRecordingAction.AsObject;
  static toObject(includeInstance: boolean, msg: ToggleRecordingAction): ToggleRecordingAction.AsObject;
  static serializeBinaryToWriter(message: ToggleRecordingAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ToggleRecordingAction;
  static deserializeBinaryFromReader(message: ToggleRecordingAction, reader: jspb.BinaryReader): ToggleRecordingAction;
}

export namespace ToggleRecordingAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotCoreDotTypes?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotCoreDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES = 1000,
  }
}

export class StoreRecordedSequenceEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(value: string): StoreRecordedSequenceEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): StoreRecordedSequenceEvent;

  getRecordedSequenceList(): Array<Action>;
  setRecordedSequenceList(value: Array<Action>): StoreRecordedSequenceEvent;
  clearRecordedSequenceList(): StoreRecordedSequenceEvent;
  addRecordedSequence(value?: Action, index?: number): Action;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): StoreRecordedSequenceEvent.AsObject;
  static toObject(includeInstance: boolean, msg: StoreRecordedSequenceEvent): StoreRecordedSequenceEvent.AsObject;
  static serializeBinaryToWriter(message: StoreRecordedSequenceEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): StoreRecordedSequenceEvent;
  static deserializeBinaryFromReader(message: StoreRecordedSequenceEvent, reader: jspb.BinaryReader): StoreRecordedSequenceEvent;
}

export namespace StoreRecordedSequenceEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotCoreDotTypes?: string,
    recordedSequenceList: Array<Action.AsObject>,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotCoreDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES = 1000,
  }
}

export class ReplayRecordedSequenceAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(value: string): ReplayRecordedSequenceAction;
  hasMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): ReplayRecordedSequenceAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ReplayRecordedSequenceAction.AsObject;
  static toObject(includeInstance: boolean, msg: ReplayRecordedSequenceAction): ReplayRecordedSequenceAction.AsObject;
  static serializeBinaryToWriter(message: ReplayRecordedSequenceAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ReplayRecordedSequenceAction;
  static deserializeBinaryFromReader(message: ReplayRecordedSequenceAction, reader: jspb.BinaryReader): ReplayRecordedSequenceAction;
}

export namespace ReplayRecordedSequenceAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotCoreDotTypes?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotCoreDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES = 1000,
  }
}

export class ReplayRecordedSequenceEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(value: string): ReplayRecordedSequenceEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): ReplayRecordedSequenceEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ReplayRecordedSequenceEvent.AsObject;
  static toObject(includeInstance: boolean, msg: ReplayRecordedSequenceEvent): ReplayRecordedSequenceEvent.AsObject;
  static serializeBinaryToWriter(message: ReplayRecordedSequenceEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ReplayRecordedSequenceEvent;
  static deserializeBinaryFromReader(message: ReplayRecordedSequenceEvent, reader: jspb.BinaryReader): ReplayRecordedSequenceEvent;
}

export namespace ReplayRecordedSequenceEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotCoreDotTypes?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotCoreDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES = 1000,
  }
}

export class ReportReplayingDoneAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(value: string): ReportReplayingDoneAction;
  hasMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): ReportReplayingDoneAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ReportReplayingDoneAction.AsObject;
  static toObject(includeInstance: boolean, msg: ReportReplayingDoneAction): ReportReplayingDoneAction.AsObject;
  static serializeBinaryToWriter(message: ReportReplayingDoneAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ReportReplayingDoneAction;
  static deserializeBinaryFromReader(message: ReportReplayingDoneAction, reader: jspb.BinaryReader): ReportReplayingDoneAction;
}

export namespace ReportReplayingDoneAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotCoreDotTypes?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotCoreDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES = 1000,
  }
}

export class MainState extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(value: string): MainState;
  hasMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotCoreDotTypes(): MainState;

  getMenu(): Menu | undefined;
  setMenu(value?: Menu): MainState;
  hasMenu(): boolean;
  clearMenu(): MainState;

  getPath(): MainState.Path | undefined;
  setPath(value?: MainState.Path): MainState;
  hasPath(): boolean;
  clearPath(): MainState;

  getDepth(): number;
  setDepth(value: number): MainState;
  hasDepth(): boolean;
  clearDepth(): MainState;

  getIsHeaderVisible(): boolean;
  setIsHeaderVisible(value: boolean): MainState;
  hasIsHeaderVisible(): boolean;
  clearIsHeaderVisible(): MainState;

  getIsFooterVisible(): boolean;
  setIsFooterVisible(value: boolean): MainState;
  hasIsFooterVisible(): boolean;
  clearIsFooterVisible(): MainState;

  getAppsItemsPriorities(): MainState.AppsItemsPrioritiesDict | undefined;
  setAppsItemsPriorities(value?: MainState.AppsItemsPrioritiesDict): MainState;
  hasAppsItemsPriorities(): boolean;
  clearAppsItemsPriorities(): MainState;

  getSettingsItemsPriorities(): MainState.SettingsItemsPrioritiesDict | undefined;
  setSettingsItemsPriorities(value?: MainState.SettingsItemsPrioritiesDict): MainState;
  hasSettingsItemsPriorities(): boolean;
  clearSettingsItemsPriorities(): MainState;

  getIsRecording(): boolean;
  setIsRecording(value: boolean): MainState;
  hasIsRecording(): boolean;
  clearIsRecording(): MainState;

  getIsReplaying(): boolean;
  setIsReplaying(value: boolean): MainState;
  hasIsReplaying(): boolean;
  clearIsReplaying(): MainState;

  getRecordedSequence(): MainState.RecordedSequence | undefined;
  setRecordedSequence(value?: MainState.RecordedSequence): MainState;
  hasRecordedSequence(): boolean;
  clearRecordedSequence(): MainState;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): MainState.AsObject;
  static toObject(includeInstance: boolean, msg: MainState): MainState.AsObject;
  static serializeBinaryToWriter(message: MainState, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): MainState;
  static deserializeBinaryFromReader(message: MainState, reader: jspb.BinaryReader): MainState;
}

export namespace MainState {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotCoreDotTypes?: string,
    menu?: Menu.AsObject,
    path?: MainState.Path.AsObject,
    depth?: number,
    isHeaderVisible?: boolean,
    isFooterVisible?: boolean,
    appsItemsPriorities?: MainState.AppsItemsPrioritiesDict.AsObject,
    settingsItemsPriorities?: MainState.SettingsItemsPrioritiesDict.AsObject,
    isRecording?: boolean,
    isReplaying?: boolean,
    recordedSequence?: MainState.RecordedSequence.AsObject,
  }

  export class Path extends jspb.Message {
    getItemsList(): Array<string>;
    setItemsList(value: Array<string>): Path;
    clearItemsList(): Path;
    addItems(value: string, index?: number): Path;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): Path.AsObject;
    static toObject(includeInstance: boolean, msg: Path): Path.AsObject;
    static serializeBinaryToWriter(message: Path, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): Path;
    static deserializeBinaryFromReader(message: Path, reader: jspb.BinaryReader): Path;
  }

  export namespace Path {
    export type AsObject = {
      itemsList: Array<string>,
    }
  }


  export class AppsItemsPrioritiesDict extends jspb.Message {
    getItemsMap(): jspb.Map<string, number>;
    clearItemsMap(): AppsItemsPrioritiesDict;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): AppsItemsPrioritiesDict.AsObject;
    static toObject(includeInstance: boolean, msg: AppsItemsPrioritiesDict): AppsItemsPrioritiesDict.AsObject;
    static serializeBinaryToWriter(message: AppsItemsPrioritiesDict, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): AppsItemsPrioritiesDict;
    static deserializeBinaryFromReader(message: AppsItemsPrioritiesDict, reader: jspb.BinaryReader): AppsItemsPrioritiesDict;
  }

  export namespace AppsItemsPrioritiesDict {
    export type AsObject = {
      itemsMap: Array<[string, number]>,
    }
  }


  export class SettingsItemsPrioritiesDict extends jspb.Message {
    getItemsMap(): jspb.Map<string, number>;
    clearItemsMap(): SettingsItemsPrioritiesDict;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): SettingsItemsPrioritiesDict.AsObject;
    static toObject(includeInstance: boolean, msg: SettingsItemsPrioritiesDict): SettingsItemsPrioritiesDict.AsObject;
    static serializeBinaryToWriter(message: SettingsItemsPrioritiesDict, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): SettingsItemsPrioritiesDict;
    static deserializeBinaryFromReader(message: SettingsItemsPrioritiesDict, reader: jspb.BinaryReader): SettingsItemsPrioritiesDict;
  }

  export namespace SettingsItemsPrioritiesDict {
    export type AsObject = {
      itemsMap: Array<[string, number]>,
    }
  }


  export class RecordedSequence extends jspb.Message {
    getItemsList(): Array<Action>;
    setItemsList(value: Array<Action>): RecordedSequence;
    clearItemsList(): RecordedSequence;
    addItems(value?: Action, index?: number): Action;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): RecordedSequence.AsObject;
    static toObject(includeInstance: boolean, msg: RecordedSequence): RecordedSequence.AsObject;
    static serializeBinaryToWriter(message: RecordedSequence, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): RecordedSequence;
    static deserializeBinaryFromReader(message: RecordedSequence, reader: jspb.BinaryReader): RecordedSequence;
  }

  export namespace RecordedSequence {
    export type AsObject = {
      itemsList: Array<Action.AsObject>,
    }
  }


  export enum MetaFieldPackageNameUboAppDotStoreDotCoreDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES = 1000,
  }

  export enum MenuCase { 
    _MENU_NOT_SET = 0,
    MENU = 2,
  }

  export enum PathCase { 
    _PATH_NOT_SET = 0,
    PATH = 3,
  }

  export enum DepthCase { 
    _DEPTH_NOT_SET = 0,
    DEPTH = 4,
  }

  export enum IsHeaderVisibleCase { 
    _IS_HEADER_VISIBLE_NOT_SET = 0,
    IS_HEADER_VISIBLE = 5,
  }

  export enum IsFooterVisibleCase { 
    _IS_FOOTER_VISIBLE_NOT_SET = 0,
    IS_FOOTER_VISIBLE = 6,
  }

  export enum AppsItemsPrioritiesCase { 
    _APPS_ITEMS_PRIORITIES_NOT_SET = 0,
    APPS_ITEMS_PRIORITIES = 7,
  }

  export enum SettingsItemsPrioritiesCase { 
    _SETTINGS_ITEMS_PRIORITIES_NOT_SET = 0,
    SETTINGS_ITEMS_PRIORITIES = 8,
  }

  export enum IsRecordingCase { 
    _IS_RECORDING_NOT_SET = 0,
    IS_RECORDING = 9,
  }

  export enum IsReplayingCase { 
    _IS_REPLAYING_NOT_SET = 0,
    IS_REPLAYING = 10,
  }

  export enum RecordedSequenceCase { 
    _RECORDED_SEQUENCE_NOT_SET = 0,
    RECORDED_SEQUENCE = 11,
  }
}

export class UboDispatchItem extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotUboActions(): string;
  setMetaFieldPackageNameUboAppDotStoreDotUboActions(value: string): UboDispatchItem;
  hasMetaFieldPackageNameUboAppDotStoreDotUboActions(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotUboActions(): UboDispatchItem;

  getStoreAction(): UboDispatchItem.StoreAction | undefined;
  setStoreAction(value?: UboDispatchItem.StoreAction): UboDispatchItem;
  hasStoreAction(): boolean;
  clearStoreAction(): UboDispatchItem;

  getKey(): string;
  setKey(value: string): UboDispatchItem;
  hasKey(): boolean;
  clearKey(): UboDispatchItem;

  getLabel(): string;
  setLabel(value: string): UboDispatchItem;
  hasLabel(): boolean;
  clearLabel(): UboDispatchItem;

  getColor(): string;
  setColor(value: string): UboDispatchItem;
  hasColor(): boolean;
  clearColor(): UboDispatchItem;

  getBackgroundColor(): string;
  setBackgroundColor(value: string): UboDispatchItem;
  hasBackgroundColor(): boolean;
  clearBackgroundColor(): UboDispatchItem;

  getIcon(): string;
  setIcon(value: string): UboDispatchItem;
  hasIcon(): boolean;
  clearIcon(): UboDispatchItem;

  getIsShort(): boolean;
  setIsShort(value: boolean): UboDispatchItem;
  hasIsShort(): boolean;
  clearIsShort(): UboDispatchItem;

  getOpacity(): number;
  setOpacity(value: number): UboDispatchItem;
  hasOpacity(): boolean;
  clearOpacity(): UboDispatchItem;

  getProgress(): number;
  setProgress(value: number): UboDispatchItem;
  hasProgress(): boolean;
  clearProgress(): UboDispatchItem;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): UboDispatchItem.AsObject;
  static toObject(includeInstance: boolean, msg: UboDispatchItem): UboDispatchItem.AsObject;
  static serializeBinaryToWriter(message: UboDispatchItem, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): UboDispatchItem;
  static deserializeBinaryFromReader(message: UboDispatchItem, reader: jspb.BinaryReader): UboDispatchItem;
}

export namespace UboDispatchItem {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotUboActions?: string,
    storeAction?: UboDispatchItem.StoreAction.AsObject,
    key?: string,
    label?: string,
    color?: string,
    backgroundColor?: string,
    icon?: string,
    isShort?: boolean,
    opacity?: number,
    progress?: number,
  }

  export class StoreAction2 extends jspb.Message {
    getItemsList(): Array<Action>;
    setItemsList(value: Array<Action>): StoreAction2;
    clearItemsList(): StoreAction2;
    addItems(value?: Action, index?: number): Action;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): StoreAction2.AsObject;
    static toObject(includeInstance: boolean, msg: StoreAction2): StoreAction2.AsObject;
    static serializeBinaryToWriter(message: StoreAction2, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): StoreAction2;
    static deserializeBinaryFromReader(message: StoreAction2, reader: jspb.BinaryReader): StoreAction2;
  }

  export namespace StoreAction2 {
    export type AsObject = {
      itemsList: Array<Action.AsObject>,
    }
  }


  export class StoreAction extends jspb.Message {
    getUboAction(): Action | undefined;
    setUboAction(value?: Action): StoreAction;
    hasUboAction(): boolean;
    clearUboAction(): StoreAction;

    getList(): UboDispatchItem.StoreAction2 | undefined;
    setList(value?: UboDispatchItem.StoreAction2): StoreAction;
    hasList(): boolean;
    clearList(): StoreAction;

    getStoreActionCase(): StoreAction.StoreActionCase;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): StoreAction.AsObject;
    static toObject(includeInstance: boolean, msg: StoreAction): StoreAction.AsObject;
    static serializeBinaryToWriter(message: StoreAction, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): StoreAction;
    static deserializeBinaryFromReader(message: StoreAction, reader: jspb.BinaryReader): StoreAction;
  }

  export namespace StoreAction {
    export type AsObject = {
      uboAction?: Action.AsObject,
      list?: UboDispatchItem.StoreAction2.AsObject,
    }

    export enum StoreActionCase { 
      STORE_ACTION_NOT_SET = 0,
      UBO_ACTION = 1,
      LIST = 2,
    }
  }


  export enum MetaFieldPackageNameUboAppDotStoreDotUboActionsCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_UBO_ACTIONS_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_UBO_ACTIONS = 1000,
  }

  export enum KeyCase { 
    _KEY_NOT_SET = 0,
    KEY = 3,
  }

  export enum LabelCase { 
    _LABEL_NOT_SET = 0,
    LABEL = 4,
  }

  export enum ColorCase { 
    _COLOR_NOT_SET = 0,
    COLOR = 5,
  }

  export enum BackgroundColorCase { 
    _BACKGROUND_COLOR_NOT_SET = 0,
    BACKGROUND_COLOR = 6,
  }

  export enum IconCase { 
    _ICON_NOT_SET = 0,
    ICON = 7,
  }

  export enum IsShortCase { 
    _IS_SHORT_NOT_SET = 0,
    IS_SHORT = 8,
  }

  export enum OpacityCase { 
    _OPACITY_NOT_SET = 0,
    OPACITY = 9,
  }

  export enum ProgressCase { 
    _PROGRESS_NOT_SET = 0,
    PROGRESS = 10,
  }
}

export class UboApplicationItem extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotUboActions(): string;
  setMetaFieldPackageNameUboAppDotStoreDotUboActions(value: string): UboApplicationItem;
  hasMetaFieldPackageNameUboAppDotStoreDotUboActions(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotUboActions(): UboApplicationItem;

  getApplication(): UboApplicationItem.Application | undefined;
  setApplication(value?: UboApplicationItem.Application): UboApplicationItem;
  hasApplication(): boolean;
  clearApplication(): UboApplicationItem;

  getApplicationId(): string;
  setApplicationId(value: string): UboApplicationItem;

  getInitializationArgs(): UboApplicationItem.InitializationArgs | undefined;
  setInitializationArgs(value?: UboApplicationItem.InitializationArgs): UboApplicationItem;
  hasInitializationArgs(): boolean;
  clearInitializationArgs(): UboApplicationItem;

  getInitializationKwargs(): UboApplicationItem.InitializationKwargsDict | undefined;
  setInitializationKwargs(value?: UboApplicationItem.InitializationKwargsDict): UboApplicationItem;
  hasInitializationKwargs(): boolean;
  clearInitializationKwargs(): UboApplicationItem;

  getKey(): string;
  setKey(value: string): UboApplicationItem;
  hasKey(): boolean;
  clearKey(): UboApplicationItem;

  getLabel(): string;
  setLabel(value: string): UboApplicationItem;
  hasLabel(): boolean;
  clearLabel(): UboApplicationItem;

  getColor(): string;
  setColor(value: string): UboApplicationItem;
  hasColor(): boolean;
  clearColor(): UboApplicationItem;

  getBackgroundColor(): string;
  setBackgroundColor(value: string): UboApplicationItem;
  hasBackgroundColor(): boolean;
  clearBackgroundColor(): UboApplicationItem;

  getIcon(): string;
  setIcon(value: string): UboApplicationItem;
  hasIcon(): boolean;
  clearIcon(): UboApplicationItem;

  getIsShort(): boolean;
  setIsShort(value: boolean): UboApplicationItem;
  hasIsShort(): boolean;
  clearIsShort(): UboApplicationItem;

  getOpacity(): number;
  setOpacity(value: number): UboApplicationItem;
  hasOpacity(): boolean;
  clearOpacity(): UboApplicationItem;

  getProgress(): number;
  setProgress(value: number): UboApplicationItem;
  hasProgress(): boolean;
  clearProgress(): UboApplicationItem;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): UboApplicationItem.AsObject;
  static toObject(includeInstance: boolean, msg: UboApplicationItem): UboApplicationItem.AsObject;
  static serializeBinaryToWriter(message: UboApplicationItem, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): UboApplicationItem;
  static deserializeBinaryFromReader(message: UboApplicationItem, reader: jspb.BinaryReader): UboApplicationItem;
}

export namespace UboApplicationItem {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotUboActions?: string,
    application?: UboApplicationItem.Application.AsObject,
    applicationId: string,
    initializationArgs?: UboApplicationItem.InitializationArgs.AsObject,
    initializationKwargs?: UboApplicationItem.InitializationKwargsDict.AsObject,
    key?: string,
    label?: string,
    color?: string,
    backgroundColor?: string,
    icon?: string,
    isShort?: boolean,
    opacity?: number,
    progress?: number,
  }

  export class Application extends jspb.Message {
    getString(): string;
    setString(value: string): Application;

    getApplicationCase(): Application.ApplicationCase;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): Application.AsObject;
    static toObject(includeInstance: boolean, msg: Application): Application.AsObject;
    static serializeBinaryToWriter(message: Application, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): Application;
    static deserializeBinaryFromReader(message: Application, reader: jspb.BinaryReader): Application;
  }

  export namespace Application {
    export type AsObject = {
      string: string,
    }

    export enum ApplicationCase { 
      APPLICATION_NOT_SET = 0,
      STRING = 1,
    }
  }


  export class InitializationArgs extends jspb.Message {
    getItemsList(): Array<BasicType>;
    setItemsList(value: Array<BasicType>): InitializationArgs;
    clearItemsList(): InitializationArgs;
    addItems(value?: BasicType, index?: number): BasicType;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): InitializationArgs.AsObject;
    static toObject(includeInstance: boolean, msg: InitializationArgs): InitializationArgs.AsObject;
    static serializeBinaryToWriter(message: InitializationArgs, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): InitializationArgs;
    static deserializeBinaryFromReader(message: InitializationArgs, reader: jspb.BinaryReader): InitializationArgs;
  }

  export namespace InitializationArgs {
    export type AsObject = {
      itemsList: Array<BasicType.AsObject>,
    }
  }


  export class InitializationKwargsDict extends jspb.Message {
    getItemsMap(): jspb.Map<string, BasicType>;
    clearItemsMap(): InitializationKwargsDict;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): InitializationKwargsDict.AsObject;
    static toObject(includeInstance: boolean, msg: InitializationKwargsDict): InitializationKwargsDict.AsObject;
    static serializeBinaryToWriter(message: InitializationKwargsDict, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): InitializationKwargsDict;
    static deserializeBinaryFromReader(message: InitializationKwargsDict, reader: jspb.BinaryReader): InitializationKwargsDict;
  }

  export namespace InitializationKwargsDict {
    export type AsObject = {
      itemsMap: Array<[string, BasicType.AsObject]>,
    }
  }


  export enum MetaFieldPackageNameUboAppDotStoreDotUboActionsCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_UBO_ACTIONS_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_UBO_ACTIONS = 1000,
  }

  export enum ApplicationCase { 
    _APPLICATION_NOT_SET = 0,
    APPLICATION = 2,
  }

  export enum InitializationArgsCase { 
    _INITIALIZATION_ARGS_NOT_SET = 0,
    INITIALIZATION_ARGS = 4,
  }

  export enum InitializationKwargsCase { 
    _INITIALIZATION_KWARGS_NOT_SET = 0,
    INITIALIZATION_KWARGS = 5,
  }

  export enum KeyCase { 
    _KEY_NOT_SET = 0,
    KEY = 6,
  }

  export enum LabelCase { 
    _LABEL_NOT_SET = 0,
    LABEL = 7,
  }

  export enum ColorCase { 
    _COLOR_NOT_SET = 0,
    COLOR = 8,
  }

  export enum BackgroundColorCase { 
    _BACKGROUND_COLOR_NOT_SET = 0,
    BACKGROUND_COLOR = 9,
  }

  export enum IconCase { 
    _ICON_NOT_SET = 0,
    ICON = 10,
  }

  export enum IsShortCase { 
    _IS_SHORT_NOT_SET = 0,
    IS_SHORT = 11,
  }

  export enum OpacityCase { 
    _OPACITY_NOT_SET = 0,
    OPACITY = 12,
  }

  export enum ProgressCase { 
    _PROGRESS_NOT_SET = 0,
    PROGRESS = 13,
  }
}

export class BasicTypeOptional extends jspb.Message {
  getBool(): boolean;
  setBool(value: boolean): BasicTypeOptional;

  getBytes(): Uint8Array | string;
  getBytes_asU8(): Uint8Array;
  getBytes_asB64(): string;
  setBytes(value: Uint8Array | string): BasicTypeOptional;

  getFloat(): number;
  setFloat(value: number): BasicTypeOptional;

  getInt64(): number;
  setInt64(value: number): BasicTypeOptional;

  getString(): string;
  setString(value: string): BasicTypeOptional;

  getBasicTypeOptionalCase(): BasicTypeOptional.BasicTypeOptionalCase;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): BasicTypeOptional.AsObject;
  static toObject(includeInstance: boolean, msg: BasicTypeOptional): BasicTypeOptional.AsObject;
  static serializeBinaryToWriter(message: BasicTypeOptional, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): BasicTypeOptional;
  static deserializeBinaryFromReader(message: BasicTypeOptional, reader: jspb.BinaryReader): BasicTypeOptional;
}

export namespace BasicTypeOptional {
  export type AsObject = {
    bool: boolean,
    bytes: Uint8Array | string,
    pb_float: number,
    int64: number,
    string: string,
  }

  export enum BasicTypeOptionalCase { 
    BASIC_TYPE_OPTIONAL_NOT_SET = 0,
    BOOL = 1,
    BYTES = 2,
    FLOAT = 3,
    INT64 = 4,
    STRING = 5,
  }
}

export class BasicType extends jspb.Message {
  getItems(): BasicTypeOptional | undefined;
  setItems(value?: BasicTypeOptional): BasicType;
  hasItems(): boolean;
  clearItems(): BasicType;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): BasicType.AsObject;
  static toObject(includeInstance: boolean, msg: BasicType): BasicType.AsObject;
  static serializeBinaryToWriter(message: BasicType, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): BasicType;
  static deserializeBinaryFromReader(message: BasicType, reader: jspb.BinaryReader): BasicType;
}

export namespace BasicType {
  export type AsObject = {
    items?: BasicTypeOptional.AsObject,
  }

  export enum ItemsCase { 
    _ITEMS_NOT_SET = 0,
    ITEMS = 1,
  }
}

export class InputResult extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotInputDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotInputDotTypes(value: string): InputResult;
  hasMetaFieldPackageNameUboAppDotStoreDotInputDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotInputDotTypes(): InputResult;

  getDataMap(): jspb.Map<string, string>;
  clearDataMap(): InputResult;

  getFilesMap(): jspb.Map<string, Uint8Array | string>;
  clearFilesMap(): InputResult;

  getMethod(): InputMethod;
  setMethod(value: InputMethod): InputResult;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): InputResult.AsObject;
  static toObject(includeInstance: boolean, msg: InputResult): InputResult.AsObject;
  static serializeBinaryToWriter(message: InputResult, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): InputResult;
  static deserializeBinaryFromReader(message: InputResult, reader: jspb.BinaryReader): InputResult;
}

export namespace InputResult {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotInputDotTypes?: string,
    dataMap: Array<[string, string]>,
    filesMap: Array<[string, Uint8Array | string]>,
    method: InputMethod,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotInputDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_INPUT_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_INPUT_DOT_TYPES = 1000,
  }
}

export class InputFieldDescription extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotInputDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotInputDotTypes(value: string): InputFieldDescription;
  hasMetaFieldPackageNameUboAppDotStoreDotInputDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotInputDotTypes(): InputFieldDescription;

  getName(): string;
  setName(value: string): InputFieldDescription;

  getLabel(): string;
  setLabel(value: string): InputFieldDescription;

  getType(): InputFieldType;
  setType(value: InputFieldType): InputFieldDescription;

  getDescription(): string;
  setDescription(value: string): InputFieldDescription;
  hasDescription(): boolean;
  clearDescription(): InputFieldDescription;

  getTitle(): string;
  setTitle(value: string): InputFieldDescription;
  hasTitle(): boolean;
  clearTitle(): InputFieldDescription;

  getFileMimetype(): string;
  setFileMimetype(value: string): InputFieldDescription;
  hasFileMimetype(): boolean;
  clearFileMimetype(): InputFieldDescription;

  getPattern(): string;
  setPattern(value: string): InputFieldDescription;
  hasPattern(): boolean;
  clearPattern(): InputFieldDescription;

  getDefaultValue(): string;
  setDefaultValue(value: string): InputFieldDescription;
  hasDefaultValue(): boolean;
  clearDefaultValue(): InputFieldDescription;

  getOptions(): InputFieldDescription.Options | undefined;
  setOptions(value?: InputFieldDescription.Options): InputFieldDescription;
  hasOptions(): boolean;
  clearOptions(): InputFieldDescription;

  getRequired(): boolean;
  setRequired(value: boolean): InputFieldDescription;
  hasRequired(): boolean;
  clearRequired(): InputFieldDescription;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): InputFieldDescription.AsObject;
  static toObject(includeInstance: boolean, msg: InputFieldDescription): InputFieldDescription.AsObject;
  static serializeBinaryToWriter(message: InputFieldDescription, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): InputFieldDescription;
  static deserializeBinaryFromReader(message: InputFieldDescription, reader: jspb.BinaryReader): InputFieldDescription;
}

export namespace InputFieldDescription {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotInputDotTypes?: string,
    name: string,
    label: string,
    type: InputFieldType,
    description?: string,
    title?: string,
    fileMimetype?: string,
    pattern?: string,
    defaultValue?: string,
    options?: InputFieldDescription.Options.AsObject,
    required?: boolean,
  }

  export class Options extends jspb.Message {
    getItemsList(): Array<string>;
    setItemsList(value: Array<string>): Options;
    clearItemsList(): Options;
    addItems(value: string, index?: number): Options;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): Options.AsObject;
    static toObject(includeInstance: boolean, msg: Options): Options.AsObject;
    static serializeBinaryToWriter(message: Options, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): Options;
    static deserializeBinaryFromReader(message: Options, reader: jspb.BinaryReader): Options;
  }

  export namespace Options {
    export type AsObject = {
      itemsList: Array<string>,
    }
  }


  export enum MetaFieldPackageNameUboAppDotStoreDotInputDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_INPUT_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_INPUT_DOT_TYPES = 1000,
  }

  export enum DescriptionCase { 
    _DESCRIPTION_NOT_SET = 0,
    DESCRIPTION = 5,
  }

  export enum TitleCase { 
    _TITLE_NOT_SET = 0,
    TITLE = 6,
  }

  export enum FileMimetypeCase { 
    _FILE_MIMETYPE_NOT_SET = 0,
    FILE_MIMETYPE = 7,
  }

  export enum PatternCase { 
    _PATTERN_NOT_SET = 0,
    PATTERN = 8,
  }

  export enum DefaultValueCase { 
    _DEFAULT_VALUE_NOT_SET = 0,
    DEFAULT_VALUE = 9,
  }

  export enum OptionsCase { 
    _OPTIONS_NOT_SET = 0,
    OPTIONS = 10,
  }

  export enum RequiredCase { 
    _REQUIRED_NOT_SET = 0,
    REQUIRED = 11,
  }
}

export class InputDescription extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotInputDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotInputDotTypes(value: string): InputDescription;
  hasMetaFieldPackageNameUboAppDotStoreDotInputDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotInputDotTypes(): InputDescription;

  getInputMethod(): InputMethod;
  setInputMethod(value: InputMethod): InputDescription;

  getId(): string;
  setId(value: string): InputDescription;
  hasId(): boolean;
  clearId(): InputDescription;

  getTitle(): string;
  setTitle(value: string): InputDescription;
  hasTitle(): boolean;
  clearTitle(): InputDescription;

  getPrompt(): string;
  setPrompt(value: string): InputDescription;
  hasPrompt(): boolean;
  clearPrompt(): InputDescription;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): InputDescription.AsObject;
  static toObject(includeInstance: boolean, msg: InputDescription): InputDescription.AsObject;
  static serializeBinaryToWriter(message: InputDescription, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): InputDescription;
  static deserializeBinaryFromReader(message: InputDescription, reader: jspb.BinaryReader): InputDescription;
}

export namespace InputDescription {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotInputDotTypes?: string,
    inputMethod: InputMethod,
    id?: string,
    title?: string,
    prompt?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotInputDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_INPUT_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_INPUT_DOT_TYPES = 1000,
  }

  export enum IdCase { 
    _ID_NOT_SET = 0,
    ID = 3,
  }

  export enum TitleCase { 
    _TITLE_NOT_SET = 0,
    TITLE = 4,
  }

  export enum PromptCase { 
    _PROMPT_NOT_SET = 0,
    PROMPT = 5,
  }
}

export class WebUIInputDescription extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotInputDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotInputDotTypes(value: string): WebUIInputDescription;
  hasMetaFieldPackageNameUboAppDotStoreDotInputDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotInputDotTypes(): WebUIInputDescription;

  getInputMethod(): InputMethod;
  setInputMethod(value: InputMethod): WebUIInputDescription;
  hasInputMethod(): boolean;
  clearInputMethod(): WebUIInputDescription;

  getFields(): WebUIInputDescription.Fields | undefined;
  setFields(value?: WebUIInputDescription.Fields): WebUIInputDescription;
  hasFields(): boolean;
  clearFields(): WebUIInputDescription;

  getId(): string;
  setId(value: string): WebUIInputDescription;
  hasId(): boolean;
  clearId(): WebUIInputDescription;

  getTitle(): string;
  setTitle(value: string): WebUIInputDescription;
  hasTitle(): boolean;
  clearTitle(): WebUIInputDescription;

  getPrompt(): string;
  setPrompt(value: string): WebUIInputDescription;
  hasPrompt(): boolean;
  clearPrompt(): WebUIInputDescription;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): WebUIInputDescription.AsObject;
  static toObject(includeInstance: boolean, msg: WebUIInputDescription): WebUIInputDescription.AsObject;
  static serializeBinaryToWriter(message: WebUIInputDescription, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): WebUIInputDescription;
  static deserializeBinaryFromReader(message: WebUIInputDescription, reader: jspb.BinaryReader): WebUIInputDescription;
}

export namespace WebUIInputDescription {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotInputDotTypes?: string,
    inputMethod?: InputMethod,
    fields?: WebUIInputDescription.Fields.AsObject,
    id?: string,
    title?: string,
    prompt?: string,
  }

  export class Fields extends jspb.Message {
    getItemsList(): Array<InputFieldDescription>;
    setItemsList(value: Array<InputFieldDescription>): Fields;
    clearItemsList(): Fields;
    addItems(value?: InputFieldDescription, index?: number): InputFieldDescription;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): Fields.AsObject;
    static toObject(includeInstance: boolean, msg: Fields): Fields.AsObject;
    static serializeBinaryToWriter(message: Fields, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): Fields;
    static deserializeBinaryFromReader(message: Fields, reader: jspb.BinaryReader): Fields;
  }

  export namespace Fields {
    export type AsObject = {
      itemsList: Array<InputFieldDescription.AsObject>,
    }
  }


  export enum MetaFieldPackageNameUboAppDotStoreDotInputDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_INPUT_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_INPUT_DOT_TYPES = 1000,
  }

  export enum InputMethodCase { 
    _INPUT_METHOD_NOT_SET = 0,
    INPUT_METHOD = 2,
  }

  export enum FieldsCase { 
    _FIELDS_NOT_SET = 0,
    FIELDS = 3,
  }

  export enum IdCase { 
    _ID_NOT_SET = 0,
    ID = 4,
  }

  export enum TitleCase { 
    _TITLE_NOT_SET = 0,
    TITLE = 5,
  }

  export enum PromptCase { 
    _PROMPT_NOT_SET = 0,
    PROMPT = 6,
  }
}

export class QRCodeInputDescription extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotInputDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotInputDotTypes(value: string): QRCodeInputDescription;
  hasMetaFieldPackageNameUboAppDotStoreDotInputDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotInputDotTypes(): QRCodeInputDescription;

  getInputMethod(): InputMethod;
  setInputMethod(value: InputMethod): QRCodeInputDescription;
  hasInputMethod(): boolean;
  clearInputMethod(): QRCodeInputDescription;

  getInstructions(): ReadableInformation | undefined;
  setInstructions(value?: ReadableInformation): QRCodeInputDescription;
  hasInstructions(): boolean;
  clearInstructions(): QRCodeInputDescription;

  getPattern(): string;
  setPattern(value: string): QRCodeInputDescription;
  hasPattern(): boolean;
  clearPattern(): QRCodeInputDescription;

  getId(): string;
  setId(value: string): QRCodeInputDescription;
  hasId(): boolean;
  clearId(): QRCodeInputDescription;

  getTitle(): string;
  setTitle(value: string): QRCodeInputDescription;
  hasTitle(): boolean;
  clearTitle(): QRCodeInputDescription;

  getPrompt(): string;
  setPrompt(value: string): QRCodeInputDescription;
  hasPrompt(): boolean;
  clearPrompt(): QRCodeInputDescription;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): QRCodeInputDescription.AsObject;
  static toObject(includeInstance: boolean, msg: QRCodeInputDescription): QRCodeInputDescription.AsObject;
  static serializeBinaryToWriter(message: QRCodeInputDescription, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): QRCodeInputDescription;
  static deserializeBinaryFromReader(message: QRCodeInputDescription, reader: jspb.BinaryReader): QRCodeInputDescription;
}

export namespace QRCodeInputDescription {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotInputDotTypes?: string,
    inputMethod?: InputMethod,
    instructions?: ReadableInformation.AsObject,
    pattern?: string,
    id?: string,
    title?: string,
    prompt?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotInputDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_INPUT_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_INPUT_DOT_TYPES = 1000,
  }

  export enum InputMethodCase { 
    _INPUT_METHOD_NOT_SET = 0,
    INPUT_METHOD = 2,
  }

  export enum InstructionsCase { 
    _INSTRUCTIONS_NOT_SET = 0,
    INSTRUCTIONS = 3,
  }

  export enum PatternCase { 
    _PATTERN_NOT_SET = 0,
    PATTERN = 4,
  }

  export enum IdCase { 
    _ID_NOT_SET = 0,
    ID = 5,
  }

  export enum TitleCase { 
    _TITLE_NOT_SET = 0,
    TITLE = 6,
  }

  export enum PromptCase { 
    _PROMPT_NOT_SET = 0,
    PROMPT = 7,
  }
}

export class PathInputDescription extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotInputDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotInputDotTypes(value: string): PathInputDescription;
  hasMetaFieldPackageNameUboAppDotStoreDotInputDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotInputDotTypes(): PathInputDescription;

  getInputMethod(): InputMethod;
  setInputMethod(value: InputMethod): PathInputDescription;
  hasInputMethod(): boolean;
  clearInputMethod(): PathInputDescription;

  getSelectorConfig(): PathSelectorConfig | undefined;
  setSelectorConfig(value?: PathSelectorConfig): PathInputDescription;
  hasSelectorConfig(): boolean;
  clearSelectorConfig(): PathInputDescription;

  getId(): string;
  setId(value: string): PathInputDescription;
  hasId(): boolean;
  clearId(): PathInputDescription;

  getTitle(): string;
  setTitle(value: string): PathInputDescription;
  hasTitle(): boolean;
  clearTitle(): PathInputDescription;

  getPrompt(): string;
  setPrompt(value: string): PathInputDescription;
  hasPrompt(): boolean;
  clearPrompt(): PathInputDescription;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): PathInputDescription.AsObject;
  static toObject(includeInstance: boolean, msg: PathInputDescription): PathInputDescription.AsObject;
  static serializeBinaryToWriter(message: PathInputDescription, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): PathInputDescription;
  static deserializeBinaryFromReader(message: PathInputDescription, reader: jspb.BinaryReader): PathInputDescription;
}

export namespace PathInputDescription {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotInputDotTypes?: string,
    inputMethod?: InputMethod,
    selectorConfig?: PathSelectorConfig.AsObject,
    id?: string,
    title?: string,
    prompt?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotInputDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_INPUT_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_INPUT_DOT_TYPES = 1000,
  }

  export enum InputMethodCase { 
    _INPUT_METHOD_NOT_SET = 0,
    INPUT_METHOD = 2,
  }

  export enum IdCase { 
    _ID_NOT_SET = 0,
    ID = 4,
  }

  export enum TitleCase { 
    _TITLE_NOT_SET = 0,
    TITLE = 5,
  }

  export enum PromptCase { 
    _PROMPT_NOT_SET = 0,
    PROMPT = 6,
  }
}

export class InputAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotInputDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotInputDotTypes(value: string): InputAction;
  hasMetaFieldPackageNameUboAppDotStoreDotInputDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotInputDotTypes(): InputAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): InputAction.AsObject;
  static toObject(includeInstance: boolean, msg: InputAction): InputAction.AsObject;
  static serializeBinaryToWriter(message: InputAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): InputAction;
  static deserializeBinaryFromReader(message: InputAction, reader: jspb.BinaryReader): InputAction;
}

export namespace InputAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotInputDotTypes?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotInputDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_INPUT_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_INPUT_DOT_TYPES = 1000,
  }
}

export class InputDemandAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotInputDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotInputDotTypes(value: string): InputDemandAction;
  hasMetaFieldPackageNameUboAppDotStoreDotInputDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotInputDotTypes(): InputDemandAction;

  getDescription(): InputDescription | undefined;
  setDescription(value?: InputDescription): InputDemandAction;
  hasDescription(): boolean;
  clearDescription(): InputDemandAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): InputDemandAction.AsObject;
  static toObject(includeInstance: boolean, msg: InputDemandAction): InputDemandAction.AsObject;
  static serializeBinaryToWriter(message: InputDemandAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): InputDemandAction;
  static deserializeBinaryFromReader(message: InputDemandAction, reader: jspb.BinaryReader): InputDemandAction;
}

export namespace InputDemandAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotInputDotTypes?: string,
    description?: InputDescription.AsObject,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotInputDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_INPUT_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_INPUT_DOT_TYPES = 1000,
  }
}

export class InputResolveAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotInputDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotInputDotTypes(value: string): InputResolveAction;
  hasMetaFieldPackageNameUboAppDotStoreDotInputDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotInputDotTypes(): InputResolveAction;

  getId(): string;
  setId(value: string): InputResolveAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): InputResolveAction.AsObject;
  static toObject(includeInstance: boolean, msg: InputResolveAction): InputResolveAction.AsObject;
  static serializeBinaryToWriter(message: InputResolveAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): InputResolveAction;
  static deserializeBinaryFromReader(message: InputResolveAction, reader: jspb.BinaryReader): InputResolveAction;
}

export namespace InputResolveAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotInputDotTypes?: string,
    id: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotInputDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_INPUT_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_INPUT_DOT_TYPES = 1000,
  }
}

export class InputCancelAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotInputDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotInputDotTypes(value: string): InputCancelAction;
  hasMetaFieldPackageNameUboAppDotStoreDotInputDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotInputDotTypes(): InputCancelAction;

  getId(): string;
  setId(value: string): InputCancelAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): InputCancelAction.AsObject;
  static toObject(includeInstance: boolean, msg: InputCancelAction): InputCancelAction.AsObject;
  static serializeBinaryToWriter(message: InputCancelAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): InputCancelAction;
  static deserializeBinaryFromReader(message: InputCancelAction, reader: jspb.BinaryReader): InputCancelAction;
}

export namespace InputCancelAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotInputDotTypes?: string,
    id: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotInputDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_INPUT_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_INPUT_DOT_TYPES = 1000,
  }
}

export class InputProvideAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotInputDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotInputDotTypes(value: string): InputProvideAction;
  hasMetaFieldPackageNameUboAppDotStoreDotInputDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotInputDotTypes(): InputProvideAction;

  getValue(): string;
  setValue(value: string): InputProvideAction;

  getResult(): InputResult | undefined;
  setResult(value?: InputResult): InputProvideAction;
  hasResult(): boolean;
  clearResult(): InputProvideAction;

  getId(): string;
  setId(value: string): InputProvideAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): InputProvideAction.AsObject;
  static toObject(includeInstance: boolean, msg: InputProvideAction): InputProvideAction.AsObject;
  static serializeBinaryToWriter(message: InputProvideAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): InputProvideAction;
  static deserializeBinaryFromReader(message: InputProvideAction, reader: jspb.BinaryReader): InputProvideAction;
}

export namespace InputProvideAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotInputDotTypes?: string,
    value: string,
    result?: InputResult.AsObject,
    id: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotInputDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_INPUT_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_INPUT_DOT_TYPES = 1000,
  }

  export enum ResultCase { 
    _RESULT_NOT_SET = 0,
    RESULT = 3,
  }
}

export class InputResolveEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotInputDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotInputDotTypes(value: string): InputResolveEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotInputDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotInputDotTypes(): InputResolveEvent;

  getId(): string;
  setId(value: string): InputResolveEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): InputResolveEvent.AsObject;
  static toObject(includeInstance: boolean, msg: InputResolveEvent): InputResolveEvent.AsObject;
  static serializeBinaryToWriter(message: InputResolveEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): InputResolveEvent;
  static deserializeBinaryFromReader(message: InputResolveEvent, reader: jspb.BinaryReader): InputResolveEvent;
}

export namespace InputResolveEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotInputDotTypes?: string,
    id: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotInputDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_INPUT_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_INPUT_DOT_TYPES = 1000,
  }
}

export class InputCancelEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotInputDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotInputDotTypes(value: string): InputCancelEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotInputDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotInputDotTypes(): InputCancelEvent;

  getId(): string;
  setId(value: string): InputCancelEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): InputCancelEvent.AsObject;
  static toObject(includeInstance: boolean, msg: InputCancelEvent): InputCancelEvent.AsObject;
  static serializeBinaryToWriter(message: InputCancelEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): InputCancelEvent;
  static deserializeBinaryFromReader(message: InputCancelEvent, reader: jspb.BinaryReader): InputCancelEvent;
}

export namespace InputCancelEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotInputDotTypes?: string,
    id: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotInputDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_INPUT_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_INPUT_DOT_TYPES = 1000,
  }
}

export class InputProvideEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotInputDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotInputDotTypes(value: string): InputProvideEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotInputDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotInputDotTypes(): InputProvideEvent;

  getValue(): string;
  setValue(value: string): InputProvideEvent;

  getResult(): InputResult | undefined;
  setResult(value?: InputResult): InputProvideEvent;
  hasResult(): boolean;
  clearResult(): InputProvideEvent;

  getId(): string;
  setId(value: string): InputProvideEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): InputProvideEvent.AsObject;
  static toObject(includeInstance: boolean, msg: InputProvideEvent): InputProvideEvent.AsObject;
  static serializeBinaryToWriter(message: InputProvideEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): InputProvideEvent;
  static deserializeBinaryFromReader(message: InputProvideEvent, reader: jspb.BinaryReader): InputProvideEvent;
}

export namespace InputProvideEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotInputDotTypes?: string,
    value: string,
    result?: InputResult.AsObject,
    id: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotInputDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_INPUT_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_INPUT_DOT_TYPES = 1000,
  }

  export enum ResultCase { 
    _RESULT_NOT_SET = 0,
    RESULT = 3,
  }
}

export class SettingsAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(value: string): SettingsAction;
  hasMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(): SettingsAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SettingsAction.AsObject;
  static toObject(includeInstance: boolean, msg: SettingsAction): SettingsAction.AsObject;
  static serializeBinaryToWriter(message: SettingsAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SettingsAction;
  static deserializeBinaryFromReader(message: SettingsAction, reader: jspb.BinaryReader): SettingsAction;
}

export namespace SettingsAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotSettingsDotTypes?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotSettingsDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SETTINGS_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SETTINGS_DOT_TYPES = 1000,
  }
}

export class SettingsTogglePdbSignalAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(value: string): SettingsTogglePdbSignalAction;
  hasMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(): SettingsTogglePdbSignalAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SettingsTogglePdbSignalAction.AsObject;
  static toObject(includeInstance: boolean, msg: SettingsTogglePdbSignalAction): SettingsTogglePdbSignalAction.AsObject;
  static serializeBinaryToWriter(message: SettingsTogglePdbSignalAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SettingsTogglePdbSignalAction;
  static deserializeBinaryFromReader(message: SettingsTogglePdbSignalAction, reader: jspb.BinaryReader): SettingsTogglePdbSignalAction;
}

export namespace SettingsTogglePdbSignalAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotSettingsDotTypes?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotSettingsDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SETTINGS_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SETTINGS_DOT_TYPES = 1000,
  }
}

export class SettingsToggleVisualDebugAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(value: string): SettingsToggleVisualDebugAction;
  hasMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(): SettingsToggleVisualDebugAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SettingsToggleVisualDebugAction.AsObject;
  static toObject(includeInstance: boolean, msg: SettingsToggleVisualDebugAction): SettingsToggleVisualDebugAction.AsObject;
  static serializeBinaryToWriter(message: SettingsToggleVisualDebugAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SettingsToggleVisualDebugAction;
  static deserializeBinaryFromReader(message: SettingsToggleVisualDebugAction, reader: jspb.BinaryReader): SettingsToggleVisualDebugAction;
}

export namespace SettingsToggleVisualDebugAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotSettingsDotTypes?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotSettingsDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SETTINGS_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SETTINGS_DOT_TYPES = 1000,
  }
}

export class SettingsToggleBetaVersionsAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(value: string): SettingsToggleBetaVersionsAction;
  hasMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(): SettingsToggleBetaVersionsAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SettingsToggleBetaVersionsAction.AsObject;
  static toObject(includeInstance: boolean, msg: SettingsToggleBetaVersionsAction): SettingsToggleBetaVersionsAction.AsObject;
  static serializeBinaryToWriter(message: SettingsToggleBetaVersionsAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SettingsToggleBetaVersionsAction;
  static deserializeBinaryFromReader(message: SettingsToggleBetaVersionsAction, reader: jspb.BinaryReader): SettingsToggleBetaVersionsAction;
}

export namespace SettingsToggleBetaVersionsAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotSettingsDotTypes?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotSettingsDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SETTINGS_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SETTINGS_DOT_TYPES = 1000,
  }
}

export class SettingsSetServicesAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(value: string): SettingsSetServicesAction;
  hasMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(): SettingsSetServicesAction;

  getServicesMap(): jspb.Map<string, ServiceState>;
  clearServicesMap(): SettingsSetServicesAction;

  getGapDuration(): number;
  setGapDuration(value: number): SettingsSetServicesAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SettingsSetServicesAction.AsObject;
  static toObject(includeInstance: boolean, msg: SettingsSetServicesAction): SettingsSetServicesAction.AsObject;
  static serializeBinaryToWriter(message: SettingsSetServicesAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SettingsSetServicesAction;
  static deserializeBinaryFromReader(message: SettingsSetServicesAction, reader: jspb.BinaryReader): SettingsSetServicesAction;
}

export namespace SettingsSetServicesAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotSettingsDotTypes?: string,
    servicesMap: Array<[string, ServiceState.AsObject]>,
    gapDuration: number,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotSettingsDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SETTINGS_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SETTINGS_DOT_TYPES = 1000,
  }
}

export class SettingsServiceAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(value: string): SettingsServiceAction;
  hasMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(): SettingsServiceAction;

  getServiceId(): string;
  setServiceId(value: string): SettingsServiceAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SettingsServiceAction.AsObject;
  static toObject(includeInstance: boolean, msg: SettingsServiceAction): SettingsServiceAction.AsObject;
  static serializeBinaryToWriter(message: SettingsServiceAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SettingsServiceAction;
  static deserializeBinaryFromReader(message: SettingsServiceAction, reader: jspb.BinaryReader): SettingsServiceAction;
}

export namespace SettingsServiceAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotSettingsDotTypes?: string,
    serviceId: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotSettingsDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SETTINGS_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SETTINGS_DOT_TYPES = 1000,
  }
}

export class SettingsStartServiceAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(value: string): SettingsStartServiceAction;
  hasMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(): SettingsStartServiceAction;

  getServiceId(): string;
  setServiceId(value: string): SettingsStartServiceAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SettingsStartServiceAction.AsObject;
  static toObject(includeInstance: boolean, msg: SettingsStartServiceAction): SettingsStartServiceAction.AsObject;
  static serializeBinaryToWriter(message: SettingsStartServiceAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SettingsStartServiceAction;
  static deserializeBinaryFromReader(message: SettingsStartServiceAction, reader: jspb.BinaryReader): SettingsStartServiceAction;
}

export namespace SettingsStartServiceAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotSettingsDotTypes?: string,
    serviceId: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotSettingsDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SETTINGS_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SETTINGS_DOT_TYPES = 1000,
  }
}

export class SettingsStopServiceAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(value: string): SettingsStopServiceAction;
  hasMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(): SettingsStopServiceAction;

  getServiceId(): string;
  setServiceId(value: string): SettingsStopServiceAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SettingsStopServiceAction.AsObject;
  static toObject(includeInstance: boolean, msg: SettingsStopServiceAction): SettingsStopServiceAction.AsObject;
  static serializeBinaryToWriter(message: SettingsStopServiceAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SettingsStopServiceAction;
  static deserializeBinaryFromReader(message: SettingsStopServiceAction, reader: jspb.BinaryReader): SettingsStopServiceAction;
}

export namespace SettingsStopServiceAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotSettingsDotTypes?: string,
    serviceId: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotSettingsDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SETTINGS_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SETTINGS_DOT_TYPES = 1000,
  }
}

export class SettingsServiceSetStatusAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(value: string): SettingsServiceSetStatusAction;
  hasMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(): SettingsServiceSetStatusAction;

  getIsActive(): boolean;
  setIsActive(value: boolean): SettingsServiceSetStatusAction;

  getServiceId(): string;
  setServiceId(value: string): SettingsServiceSetStatusAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SettingsServiceSetStatusAction.AsObject;
  static toObject(includeInstance: boolean, msg: SettingsServiceSetStatusAction): SettingsServiceSetStatusAction.AsObject;
  static serializeBinaryToWriter(message: SettingsServiceSetStatusAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SettingsServiceSetStatusAction;
  static deserializeBinaryFromReader(message: SettingsServiceSetStatusAction, reader: jspb.BinaryReader): SettingsServiceSetStatusAction;
}

export namespace SettingsServiceSetStatusAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotSettingsDotTypes?: string,
    isActive: boolean,
    serviceId: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotSettingsDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SETTINGS_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SETTINGS_DOT_TYPES = 1000,
  }
}

export class SettingsServiceSetIsEnabledAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(value: string): SettingsServiceSetIsEnabledAction;
  hasMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(): SettingsServiceSetIsEnabledAction;

  getIsEnabled(): boolean;
  setIsEnabled(value: boolean): SettingsServiceSetIsEnabledAction;

  getServiceId(): string;
  setServiceId(value: string): SettingsServiceSetIsEnabledAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SettingsServiceSetIsEnabledAction.AsObject;
  static toObject(includeInstance: boolean, msg: SettingsServiceSetIsEnabledAction): SettingsServiceSetIsEnabledAction.AsObject;
  static serializeBinaryToWriter(message: SettingsServiceSetIsEnabledAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SettingsServiceSetIsEnabledAction;
  static deserializeBinaryFromReader(message: SettingsServiceSetIsEnabledAction, reader: jspb.BinaryReader): SettingsServiceSetIsEnabledAction;
}

export namespace SettingsServiceSetIsEnabledAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotSettingsDotTypes?: string,
    isEnabled: boolean,
    serviceId: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotSettingsDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SETTINGS_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SETTINGS_DOT_TYPES = 1000,
  }
}

export class SettingsServiceSetLogLevelAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(value: string): SettingsServiceSetLogLevelAction;
  hasMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(): SettingsServiceSetLogLevelAction;

  getLogLevel(): number;
  setLogLevel(value: number): SettingsServiceSetLogLevelAction;

  getServiceId(): string;
  setServiceId(value: string): SettingsServiceSetLogLevelAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SettingsServiceSetLogLevelAction.AsObject;
  static toObject(includeInstance: boolean, msg: SettingsServiceSetLogLevelAction): SettingsServiceSetLogLevelAction.AsObject;
  static serializeBinaryToWriter(message: SettingsServiceSetLogLevelAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SettingsServiceSetLogLevelAction;
  static deserializeBinaryFromReader(message: SettingsServiceSetLogLevelAction, reader: jspb.BinaryReader): SettingsServiceSetLogLevelAction;
}

export namespace SettingsServiceSetLogLevelAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotSettingsDotTypes?: string,
    logLevel: number,
    serviceId: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotSettingsDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SETTINGS_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SETTINGS_DOT_TYPES = 1000,
  }
}

export class SettingsServiceSetShouldRestartAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(value: string): SettingsServiceSetShouldRestartAction;
  hasMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(): SettingsServiceSetShouldRestartAction;

  getShouldAutoRestart(): boolean;
  setShouldAutoRestart(value: boolean): SettingsServiceSetShouldRestartAction;

  getServiceId(): string;
  setServiceId(value: string): SettingsServiceSetShouldRestartAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SettingsServiceSetShouldRestartAction.AsObject;
  static toObject(includeInstance: boolean, msg: SettingsServiceSetShouldRestartAction): SettingsServiceSetShouldRestartAction.AsObject;
  static serializeBinaryToWriter(message: SettingsServiceSetShouldRestartAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SettingsServiceSetShouldRestartAction;
  static deserializeBinaryFromReader(message: SettingsServiceSetShouldRestartAction, reader: jspb.BinaryReader): SettingsServiceSetShouldRestartAction;
}

export namespace SettingsServiceSetShouldRestartAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotSettingsDotTypes?: string,
    shouldAutoRestart: boolean,
    serviceId: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotSettingsDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SETTINGS_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SETTINGS_DOT_TYPES = 1000,
  }
}

export class SettingsReportServiceErrorAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(value: string): SettingsReportServiceErrorAction;
  hasMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(): SettingsReportServiceErrorAction;

  getError(): ErrorReport | undefined;
  setError(value?: ErrorReport): SettingsReportServiceErrorAction;
  hasError(): boolean;
  clearError(): SettingsReportServiceErrorAction;

  getServiceId(): string;
  setServiceId(value: string): SettingsReportServiceErrorAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SettingsReportServiceErrorAction.AsObject;
  static toObject(includeInstance: boolean, msg: SettingsReportServiceErrorAction): SettingsReportServiceErrorAction.AsObject;
  static serializeBinaryToWriter(message: SettingsReportServiceErrorAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SettingsReportServiceErrorAction;
  static deserializeBinaryFromReader(message: SettingsReportServiceErrorAction, reader: jspb.BinaryReader): SettingsReportServiceErrorAction;
}

export namespace SettingsReportServiceErrorAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotSettingsDotTypes?: string,
    error?: ErrorReport.AsObject,
    serviceId: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotSettingsDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SETTINGS_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SETTINGS_DOT_TYPES = 1000,
  }
}

export class SettingsClearServiceErrorsAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(value: string): SettingsClearServiceErrorsAction;
  hasMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(): SettingsClearServiceErrorsAction;

  getServiceId(): string;
  setServiceId(value: string): SettingsClearServiceErrorsAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SettingsClearServiceErrorsAction.AsObject;
  static toObject(includeInstance: boolean, msg: SettingsClearServiceErrorsAction): SettingsClearServiceErrorsAction.AsObject;
  static serializeBinaryToWriter(message: SettingsClearServiceErrorsAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SettingsClearServiceErrorsAction;
  static deserializeBinaryFromReader(message: SettingsClearServiceErrorsAction, reader: jspb.BinaryReader): SettingsClearServiceErrorsAction;
}

export namespace SettingsClearServiceErrorsAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotSettingsDotTypes?: string,
    serviceId: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotSettingsDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SETTINGS_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SETTINGS_DOT_TYPES = 1000,
  }
}

export class SettingsEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(value: string): SettingsEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(): SettingsEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SettingsEvent.AsObject;
  static toObject(includeInstance: boolean, msg: SettingsEvent): SettingsEvent.AsObject;
  static serializeBinaryToWriter(message: SettingsEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SettingsEvent;
  static deserializeBinaryFromReader(message: SettingsEvent, reader: jspb.BinaryReader): SettingsEvent;
}

export namespace SettingsEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotSettingsDotTypes?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotSettingsDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SETTINGS_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SETTINGS_DOT_TYPES = 1000,
  }
}

export class SettingsServiceEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(value: string): SettingsServiceEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(): SettingsServiceEvent;

  getServiceId(): string;
  setServiceId(value: string): SettingsServiceEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SettingsServiceEvent.AsObject;
  static toObject(includeInstance: boolean, msg: SettingsServiceEvent): SettingsServiceEvent.AsObject;
  static serializeBinaryToWriter(message: SettingsServiceEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SettingsServiceEvent;
  static deserializeBinaryFromReader(message: SettingsServiceEvent, reader: jspb.BinaryReader): SettingsServiceEvent;
}

export namespace SettingsServiceEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotSettingsDotTypes?: string,
    serviceId: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotSettingsDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SETTINGS_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SETTINGS_DOT_TYPES = 1000,
  }
}

export class SettingsStartServiceEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(value: string): SettingsStartServiceEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(): SettingsStartServiceEvent;

  getDelay(): number;
  setDelay(value: number): SettingsStartServiceEvent;
  hasDelay(): boolean;
  clearDelay(): SettingsStartServiceEvent;

  getServiceId(): string;
  setServiceId(value: string): SettingsStartServiceEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SettingsStartServiceEvent.AsObject;
  static toObject(includeInstance: boolean, msg: SettingsStartServiceEvent): SettingsStartServiceEvent.AsObject;
  static serializeBinaryToWriter(message: SettingsStartServiceEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SettingsStartServiceEvent;
  static deserializeBinaryFromReader(message: SettingsStartServiceEvent, reader: jspb.BinaryReader): SettingsStartServiceEvent;
}

export namespace SettingsStartServiceEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotSettingsDotTypes?: string,
    delay?: number,
    serviceId: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotSettingsDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SETTINGS_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SETTINGS_DOT_TYPES = 1000,
  }

  export enum DelayCase { 
    _DELAY_NOT_SET = 0,
    DELAY = 2,
  }
}

export class SettingsStopServiceEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(value: string): SettingsStopServiceEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(): SettingsStopServiceEvent;

  getServiceId(): string;
  setServiceId(value: string): SettingsStopServiceEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SettingsStopServiceEvent.AsObject;
  static toObject(includeInstance: boolean, msg: SettingsStopServiceEvent): SettingsStopServiceEvent.AsObject;
  static serializeBinaryToWriter(message: SettingsStopServiceEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SettingsStopServiceEvent;
  static deserializeBinaryFromReader(message: SettingsStopServiceEvent, reader: jspb.BinaryReader): SettingsStopServiceEvent;
}

export namespace SettingsStopServiceEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotSettingsDotTypes?: string,
    serviceId: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotSettingsDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SETTINGS_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SETTINGS_DOT_TYPES = 1000,
  }
}

export class ErrorReport extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(value: string): ErrorReport;
  hasMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(): ErrorReport;

  getTimestamp(): number;
  setTimestamp(value: number): ErrorReport;

  getMessage(): string;
  setMessage(value: string): ErrorReport;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ErrorReport.AsObject;
  static toObject(includeInstance: boolean, msg: ErrorReport): ErrorReport.AsObject;
  static serializeBinaryToWriter(message: ErrorReport, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ErrorReport;
  static deserializeBinaryFromReader(message: ErrorReport, reader: jspb.BinaryReader): ErrorReport;
}

export namespace ErrorReport {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotSettingsDotTypes?: string,
    timestamp: number,
    message: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotSettingsDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SETTINGS_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SETTINGS_DOT_TYPES = 1000,
  }
}

export class ServiceState extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(value: string): ServiceState;
  hasMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(): ServiceState;

  getId(): string;
  setId(value: string): ServiceState;

  getLabel(): string;
  setLabel(value: string): ServiceState;

  getIsActive(): boolean;
  setIsActive(value: boolean): ServiceState;

  getIsEnabled(): boolean;
  setIsEnabled(value: boolean): ServiceState;

  getLogLevel(): number;
  setLogLevel(value: number): ServiceState;

  getShouldAutoRestart(): boolean;
  setShouldAutoRestart(value: boolean): ServiceState;

  getErrors(): ServiceState.Errors | undefined;
  setErrors(value?: ServiceState.Errors): ServiceState;
  hasErrors(): boolean;
  clearErrors(): ServiceState;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ServiceState.AsObject;
  static toObject(includeInstance: boolean, msg: ServiceState): ServiceState.AsObject;
  static serializeBinaryToWriter(message: ServiceState, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ServiceState;
  static deserializeBinaryFromReader(message: ServiceState, reader: jspb.BinaryReader): ServiceState;
}

export namespace ServiceState {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotSettingsDotTypes?: string,
    id: string,
    label: string,
    isActive: boolean,
    isEnabled: boolean,
    logLevel: number,
    shouldAutoRestart: boolean,
    errors?: ServiceState.Errors.AsObject,
  }

  export class Errors extends jspb.Message {
    getItemsList(): Array<ErrorReport>;
    setItemsList(value: Array<ErrorReport>): Errors;
    clearItemsList(): Errors;
    addItems(value?: ErrorReport, index?: number): ErrorReport;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): Errors.AsObject;
    static toObject(includeInstance: boolean, msg: Errors): Errors.AsObject;
    static serializeBinaryToWriter(message: Errors, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): Errors;
    static deserializeBinaryFromReader(message: Errors, reader: jspb.BinaryReader): Errors;
  }

  export namespace Errors {
    export type AsObject = {
      itemsList: Array<ErrorReport.AsObject>,
    }
  }


  export enum MetaFieldPackageNameUboAppDotStoreDotSettingsDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SETTINGS_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SETTINGS_DOT_TYPES = 1000,
  }

  export enum ErrorsCase { 
    _ERRORS_NOT_SET = 0,
    ERRORS = 8,
  }
}

export class SettingsState extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(value: string): SettingsState;
  hasMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotSettingsDotTypes(): SettingsState;

  getPdbSignal(): boolean;
  setPdbSignal(value: boolean): SettingsState;
  hasPdbSignal(): boolean;
  clearPdbSignal(): SettingsState;

  getVisualDebug(): boolean;
  setVisualDebug(value: boolean): SettingsState;
  hasVisualDebug(): boolean;
  clearVisualDebug(): SettingsState;

  getBetaVersions(): boolean;
  setBetaVersions(value: boolean): SettingsState;
  hasBetaVersions(): boolean;
  clearBetaVersions(): SettingsState;

  getServices(): SettingsState.ServicesDict | undefined;
  setServices(value?: SettingsState.ServicesDict): SettingsState;
  hasServices(): boolean;
  clearServices(): SettingsState;

  getServicesStatus(): ServicesStatus;
  setServicesStatus(value: ServicesStatus): SettingsState;
  hasServicesStatus(): boolean;
  clearServicesStatus(): SettingsState;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SettingsState.AsObject;
  static toObject(includeInstance: boolean, msg: SettingsState): SettingsState.AsObject;
  static serializeBinaryToWriter(message: SettingsState, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SettingsState;
  static deserializeBinaryFromReader(message: SettingsState, reader: jspb.BinaryReader): SettingsState;
}

export namespace SettingsState {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotSettingsDotTypes?: string,
    pdbSignal?: boolean,
    visualDebug?: boolean,
    betaVersions?: boolean,
    services?: SettingsState.ServicesDict.AsObject,
    servicesStatus?: ServicesStatus,
  }

  export class ServicesDict extends jspb.Message {
    getItemsMap(): jspb.Map<string, ServiceState>;
    clearItemsMap(): ServicesDict;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): ServicesDict.AsObject;
    static toObject(includeInstance: boolean, msg: ServicesDict): ServicesDict.AsObject;
    static serializeBinaryToWriter(message: ServicesDict, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): ServicesDict;
    static deserializeBinaryFromReader(message: ServicesDict, reader: jspb.BinaryReader): ServicesDict;
  }

  export namespace ServicesDict {
    export type AsObject = {
      itemsMap: Array<[string, ServiceState.AsObject]>,
    }
  }


  export enum MetaFieldPackageNameUboAppDotStoreDotSettingsDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SETTINGS_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SETTINGS_DOT_TYPES = 1000,
  }

  export enum PdbSignalCase { 
    _PDB_SIGNAL_NOT_SET = 0,
    PDB_SIGNAL = 2,
  }

  export enum VisualDebugCase { 
    _VISUAL_DEBUG_NOT_SET = 0,
    VISUAL_DEBUG = 3,
  }

  export enum BetaVersionsCase { 
    _BETA_VERSIONS_NOT_SET = 0,
    BETA_VERSIONS = 4,
  }

  export enum ServicesCase { 
    _SERVICES_NOT_SET = 0,
    SERVICES = 5,
  }

  export enum ServicesStatusCase { 
    _SERVICES_STATUS_NOT_SET = 0,
    SERVICES_STATUS = 6,
  }
}

export class IconState extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotStatusIconsDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotStatusIconsDotTypes(value: string): IconState;
  hasMetaFieldPackageNameUboAppDotStoreDotStatusIconsDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotStatusIconsDotTypes(): IconState;

  getSymbol(): string;
  setSymbol(value: string): IconState;

  getColor(): string;
  setColor(value: string): IconState;

  getPriority(): number;
  setPriority(value: number): IconState;

  getServiceId(): string;
  setServiceId(value: string): IconState;

  getId(): string;
  setId(value: string): IconState;
  hasId(): boolean;
  clearId(): IconState;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): IconState.AsObject;
  static toObject(includeInstance: boolean, msg: IconState): IconState.AsObject;
  static serializeBinaryToWriter(message: IconState, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): IconState;
  static deserializeBinaryFromReader(message: IconState, reader: jspb.BinaryReader): IconState;
}

export namespace IconState {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotStatusIconsDotTypes?: string,
    symbol: string,
    color: string,
    priority: number,
    serviceId: string,
    id?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotStatusIconsDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_STATUS_ICONS_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_STATUS_ICONS_DOT_TYPES = 1000,
  }

  export enum IdCase { 
    _ID_NOT_SET = 0,
    ID = 6,
  }
}

export class StatusIconsState extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotStatusIconsDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotStatusIconsDotTypes(value: string): StatusIconsState;
  hasMetaFieldPackageNameUboAppDotStoreDotStatusIconsDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotStatusIconsDotTypes(): StatusIconsState;

  getIconsList(): Array<IconState>;
  setIconsList(value: Array<IconState>): StatusIconsState;
  clearIconsList(): StatusIconsState;
  addIcons(value?: IconState, index?: number): IconState;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): StatusIconsState.AsObject;
  static toObject(includeInstance: boolean, msg: StatusIconsState): StatusIconsState.AsObject;
  static serializeBinaryToWriter(message: StatusIconsState, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): StatusIconsState;
  static deserializeBinaryFromReader(message: StatusIconsState, reader: jspb.BinaryReader): StatusIconsState;
}

export namespace StatusIconsState {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotStatusIconsDotTypes?: string,
    iconsList: Array<IconState.AsObject>,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotStatusIconsDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_STATUS_ICONS_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_STATUS_ICONS_DOT_TYPES = 1000,
  }
}

export class StatusIconsAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotStatusIconsDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotStatusIconsDotTypes(value: string): StatusIconsAction;
  hasMetaFieldPackageNameUboAppDotStoreDotStatusIconsDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotStatusIconsDotTypes(): StatusIconsAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): StatusIconsAction.AsObject;
  static toObject(includeInstance: boolean, msg: StatusIconsAction): StatusIconsAction.AsObject;
  static serializeBinaryToWriter(message: StatusIconsAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): StatusIconsAction;
  static deserializeBinaryFromReader(message: StatusIconsAction, reader: jspb.BinaryReader): StatusIconsAction;
}

export namespace StatusIconsAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotStatusIconsDotTypes?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotStatusIconsDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_STATUS_ICONS_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_STATUS_ICONS_DOT_TYPES = 1000,
  }
}

export class StatusIconsRegisterAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotStatusIconsDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotStatusIconsDotTypes(value: string): StatusIconsRegisterAction;
  hasMetaFieldPackageNameUboAppDotStoreDotStatusIconsDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotStatusIconsDotTypes(): StatusIconsRegisterAction;

  getIcon(): string;
  setIcon(value: string): StatusIconsRegisterAction;

  getColor(): string;
  setColor(value: string): StatusIconsRegisterAction;
  hasColor(): boolean;
  clearColor(): StatusIconsRegisterAction;

  getPriority(): number;
  setPriority(value: number): StatusIconsRegisterAction;
  hasPriority(): boolean;
  clearPriority(): StatusIconsRegisterAction;

  getId(): string;
  setId(value: string): StatusIconsRegisterAction;
  hasId(): boolean;
  clearId(): StatusIconsRegisterAction;

  getService(): string;
  setService(value: string): StatusIconsRegisterAction;
  hasService(): boolean;
  clearService(): StatusIconsRegisterAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): StatusIconsRegisterAction.AsObject;
  static toObject(includeInstance: boolean, msg: StatusIconsRegisterAction): StatusIconsRegisterAction.AsObject;
  static serializeBinaryToWriter(message: StatusIconsRegisterAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): StatusIconsRegisterAction;
  static deserializeBinaryFromReader(message: StatusIconsRegisterAction, reader: jspb.BinaryReader): StatusIconsRegisterAction;
}

export namespace StatusIconsRegisterAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotStatusIconsDotTypes?: string,
    icon: string,
    color?: string,
    priority?: number,
    id?: string,
    service?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotStatusIconsDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_STATUS_ICONS_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_STATUS_ICONS_DOT_TYPES = 1000,
  }

  export enum ColorCase { 
    _COLOR_NOT_SET = 0,
    COLOR = 3,
  }

  export enum PriorityCase { 
    _PRIORITY_NOT_SET = 0,
    PRIORITY = 4,
  }

  export enum IdCase { 
    _ID_NOT_SET = 0,
    ID = 5,
  }

  export enum ServiceCase { 
    _SERVICE_NOT_SET = 0,
    SERVICE = 6,
  }
}

export class UpdateManagerAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotUpdateManagerDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotUpdateManagerDotTypes(value: string): UpdateManagerAction;
  hasMetaFieldPackageNameUboAppDotStoreDotUpdateManagerDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotUpdateManagerDotTypes(): UpdateManagerAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): UpdateManagerAction.AsObject;
  static toObject(includeInstance: boolean, msg: UpdateManagerAction): UpdateManagerAction.AsObject;
  static serializeBinaryToWriter(message: UpdateManagerAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): UpdateManagerAction;
  static deserializeBinaryFromReader(message: UpdateManagerAction, reader: jspb.BinaryReader): UpdateManagerAction;
}

export namespace UpdateManagerAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotUpdateManagerDotTypes?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotUpdateManagerDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_UPDATE_MANAGER_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_UPDATE_MANAGER_DOT_TYPES = 1000,
  }
}

export class UpdateManagerSetVersionsAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotUpdateManagerDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotUpdateManagerDotTypes(value: string): UpdateManagerSetVersionsAction;
  hasMetaFieldPackageNameUboAppDotStoreDotUpdateManagerDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotUpdateManagerDotTypes(): UpdateManagerSetVersionsAction;

  getFlashNotification(): boolean;
  setFlashNotification(value: boolean): UpdateManagerSetVersionsAction;

  getCurrentVersion(): string;
  setCurrentVersion(value: string): UpdateManagerSetVersionsAction;

  getBaseImageVariant(): string;
  setBaseImageVariant(value: string): UpdateManagerSetVersionsAction;

  getLatestVersion(): string;
  setLatestVersion(value: string): UpdateManagerSetVersionsAction;

  getRecentVersions(): UpdateManagerSetVersionsAction.RecentVersions | undefined;
  setRecentVersions(value?: UpdateManagerSetVersionsAction.RecentVersions): UpdateManagerSetVersionsAction;
  hasRecentVersions(): boolean;
  clearRecentVersions(): UpdateManagerSetVersionsAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): UpdateManagerSetVersionsAction.AsObject;
  static toObject(includeInstance: boolean, msg: UpdateManagerSetVersionsAction): UpdateManagerSetVersionsAction.AsObject;
  static serializeBinaryToWriter(message: UpdateManagerSetVersionsAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): UpdateManagerSetVersionsAction;
  static deserializeBinaryFromReader(message: UpdateManagerSetVersionsAction, reader: jspb.BinaryReader): UpdateManagerSetVersionsAction;
}

export namespace UpdateManagerSetVersionsAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotUpdateManagerDotTypes?: string,
    flashNotification: boolean,
    currentVersion: string,
    baseImageVariant: string,
    latestVersion: string,
    recentVersions?: UpdateManagerSetVersionsAction.RecentVersions.AsObject,
  }

  export class RecentVersions extends jspb.Message {
    getItemsList(): Array<string>;
    setItemsList(value: Array<string>): RecentVersions;
    clearItemsList(): RecentVersions;
    addItems(value: string, index?: number): RecentVersions;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): RecentVersions.AsObject;
    static toObject(includeInstance: boolean, msg: RecentVersions): RecentVersions.AsObject;
    static serializeBinaryToWriter(message: RecentVersions, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): RecentVersions;
    static deserializeBinaryFromReader(message: RecentVersions, reader: jspb.BinaryReader): RecentVersions;
  }

  export namespace RecentVersions {
    export type AsObject = {
      itemsList: Array<string>,
    }
  }


  export enum MetaFieldPackageNameUboAppDotStoreDotUpdateManagerDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_UPDATE_MANAGER_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_UPDATE_MANAGER_DOT_TYPES = 1000,
  }

  export enum RecentVersionsCase { 
    _RECENT_VERSIONS_NOT_SET = 0,
    RECENT_VERSIONS = 6,
  }
}

export class UpdateManagerRequestCheckAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotUpdateManagerDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotUpdateManagerDotTypes(value: string): UpdateManagerRequestCheckAction;
  hasMetaFieldPackageNameUboAppDotStoreDotUpdateManagerDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotUpdateManagerDotTypes(): UpdateManagerRequestCheckAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): UpdateManagerRequestCheckAction.AsObject;
  static toObject(includeInstance: boolean, msg: UpdateManagerRequestCheckAction): UpdateManagerRequestCheckAction.AsObject;
  static serializeBinaryToWriter(message: UpdateManagerRequestCheckAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): UpdateManagerRequestCheckAction;
  static deserializeBinaryFromReader(message: UpdateManagerRequestCheckAction, reader: jspb.BinaryReader): UpdateManagerRequestCheckAction;
}

export namespace UpdateManagerRequestCheckAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotUpdateManagerDotTypes?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotUpdateManagerDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_UPDATE_MANAGER_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_UPDATE_MANAGER_DOT_TYPES = 1000,
  }
}

export class UpdateManagerReportFailedCheckAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotUpdateManagerDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotUpdateManagerDotTypes(value: string): UpdateManagerReportFailedCheckAction;
  hasMetaFieldPackageNameUboAppDotStoreDotUpdateManagerDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotUpdateManagerDotTypes(): UpdateManagerReportFailedCheckAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): UpdateManagerReportFailedCheckAction.AsObject;
  static toObject(includeInstance: boolean, msg: UpdateManagerReportFailedCheckAction): UpdateManagerReportFailedCheckAction.AsObject;
  static serializeBinaryToWriter(message: UpdateManagerReportFailedCheckAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): UpdateManagerReportFailedCheckAction;
  static deserializeBinaryFromReader(message: UpdateManagerReportFailedCheckAction, reader: jspb.BinaryReader): UpdateManagerReportFailedCheckAction;
}

export namespace UpdateManagerReportFailedCheckAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotUpdateManagerDotTypes?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotUpdateManagerDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_UPDATE_MANAGER_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_UPDATE_MANAGER_DOT_TYPES = 1000,
  }
}

export class UpdateManagerRequestUpdateAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotUpdateManagerDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotUpdateManagerDotTypes(value: string): UpdateManagerRequestUpdateAction;
  hasMetaFieldPackageNameUboAppDotStoreDotUpdateManagerDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotUpdateManagerDotTypes(): UpdateManagerRequestUpdateAction;

  getVersion(): string;
  setVersion(value: string): UpdateManagerRequestUpdateAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): UpdateManagerRequestUpdateAction.AsObject;
  static toObject(includeInstance: boolean, msg: UpdateManagerRequestUpdateAction): UpdateManagerRequestUpdateAction.AsObject;
  static serializeBinaryToWriter(message: UpdateManagerRequestUpdateAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): UpdateManagerRequestUpdateAction;
  static deserializeBinaryFromReader(message: UpdateManagerRequestUpdateAction, reader: jspb.BinaryReader): UpdateManagerRequestUpdateAction;
}

export namespace UpdateManagerRequestUpdateAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotUpdateManagerDotTypes?: string,
    version: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotUpdateManagerDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_UPDATE_MANAGER_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_UPDATE_MANAGER_DOT_TYPES = 1000,
  }
}

export class UpdateManagerEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotUpdateManagerDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotUpdateManagerDotTypes(value: string): UpdateManagerEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotUpdateManagerDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotUpdateManagerDotTypes(): UpdateManagerEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): UpdateManagerEvent.AsObject;
  static toObject(includeInstance: boolean, msg: UpdateManagerEvent): UpdateManagerEvent.AsObject;
  static serializeBinaryToWriter(message: UpdateManagerEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): UpdateManagerEvent;
  static deserializeBinaryFromReader(message: UpdateManagerEvent, reader: jspb.BinaryReader): UpdateManagerEvent;
}

export namespace UpdateManagerEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotUpdateManagerDotTypes?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotUpdateManagerDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_UPDATE_MANAGER_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_UPDATE_MANAGER_DOT_TYPES = 1000,
  }
}

export class UpdateManagerCheckEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotUpdateManagerDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotUpdateManagerDotTypes(value: string): UpdateManagerCheckEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotUpdateManagerDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotUpdateManagerDotTypes(): UpdateManagerCheckEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): UpdateManagerCheckEvent.AsObject;
  static toObject(includeInstance: boolean, msg: UpdateManagerCheckEvent): UpdateManagerCheckEvent.AsObject;
  static serializeBinaryToWriter(message: UpdateManagerCheckEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): UpdateManagerCheckEvent;
  static deserializeBinaryFromReader(message: UpdateManagerCheckEvent, reader: jspb.BinaryReader): UpdateManagerCheckEvent;
}

export namespace UpdateManagerCheckEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotUpdateManagerDotTypes?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotUpdateManagerDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_UPDATE_MANAGER_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_UPDATE_MANAGER_DOT_TYPES = 1000,
  }
}

export class UpdateManagerUpdateEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotUpdateManagerDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotUpdateManagerDotTypes(value: string): UpdateManagerUpdateEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotUpdateManagerDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotUpdateManagerDotTypes(): UpdateManagerUpdateEvent;

  getVersion(): string;
  setVersion(value: string): UpdateManagerUpdateEvent;
  hasVersion(): boolean;
  clearVersion(): UpdateManagerUpdateEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): UpdateManagerUpdateEvent.AsObject;
  static toObject(includeInstance: boolean, msg: UpdateManagerUpdateEvent): UpdateManagerUpdateEvent.AsObject;
  static serializeBinaryToWriter(message: UpdateManagerUpdateEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): UpdateManagerUpdateEvent;
  static deserializeBinaryFromReader(message: UpdateManagerUpdateEvent, reader: jspb.BinaryReader): UpdateManagerUpdateEvent;
}

export namespace UpdateManagerUpdateEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotUpdateManagerDotTypes?: string,
    version?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotUpdateManagerDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_UPDATE_MANAGER_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_UPDATE_MANAGER_DOT_TYPES = 1000,
  }

  export enum VersionCase { 
    _VERSION_NOT_SET = 0,
    VERSION = 2,
  }
}

export class UpdateManagerState extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotUpdateManagerDotTypes(): string;
  setMetaFieldPackageNameUboAppDotStoreDotUpdateManagerDotTypes(value: string): UpdateManagerState;
  hasMetaFieldPackageNameUboAppDotStoreDotUpdateManagerDotTypes(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotUpdateManagerDotTypes(): UpdateManagerState;

  getCurrentVersion(): string;
  setCurrentVersion(value: string): UpdateManagerState;
  hasCurrentVersion(): boolean;
  clearCurrentVersion(): UpdateManagerState;

  getBaseImageVariant(): string;
  setBaseImageVariant(value: string): UpdateManagerState;
  hasBaseImageVariant(): boolean;
  clearBaseImageVariant(): UpdateManagerState;

  getLatestVersion(): string;
  setLatestVersion(value: string): UpdateManagerState;
  hasLatestVersion(): boolean;
  clearLatestVersion(): UpdateManagerState;

  getUpdateStatus(): UpdateStatus;
  setUpdateStatus(value: UpdateStatus): UpdateManagerState;
  hasUpdateStatus(): boolean;
  clearUpdateStatus(): UpdateManagerState;

  getRecentVersions(): UpdateManagerState.RecentVersions | undefined;
  setRecentVersions(value?: UpdateManagerState.RecentVersions): UpdateManagerState;
  hasRecentVersions(): boolean;
  clearRecentVersions(): UpdateManagerState;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): UpdateManagerState.AsObject;
  static toObject(includeInstance: boolean, msg: UpdateManagerState): UpdateManagerState.AsObject;
  static serializeBinaryToWriter(message: UpdateManagerState, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): UpdateManagerState;
  static deserializeBinaryFromReader(message: UpdateManagerState, reader: jspb.BinaryReader): UpdateManagerState;
}

export namespace UpdateManagerState {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotUpdateManagerDotTypes?: string,
    currentVersion?: string,
    baseImageVariant?: string,
    latestVersion?: string,
    updateStatus?: UpdateStatus,
    recentVersions?: UpdateManagerState.RecentVersions.AsObject,
  }

  export class RecentVersions extends jspb.Message {
    getItemsList(): Array<string>;
    setItemsList(value: Array<string>): RecentVersions;
    clearItemsList(): RecentVersions;
    addItems(value: string, index?: number): RecentVersions;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): RecentVersions.AsObject;
    static toObject(includeInstance: boolean, msg: RecentVersions): RecentVersions.AsObject;
    static serializeBinaryToWriter(message: RecentVersions, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): RecentVersions;
    static deserializeBinaryFromReader(message: RecentVersions, reader: jspb.BinaryReader): RecentVersions;
  }

  export namespace RecentVersions {
    export type AsObject = {
      itemsList: Array<string>,
    }
  }


  export enum MetaFieldPackageNameUboAppDotStoreDotUpdateManagerDotTypesCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_UPDATE_MANAGER_DOT_TYPES_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_UPDATE_MANAGER_DOT_TYPES = 1000,
  }

  export enum CurrentVersionCase { 
    _CURRENT_VERSION_NOT_SET = 0,
    CURRENT_VERSION = 2,
  }

  export enum BaseImageVariantCase { 
    _BASE_IMAGE_VARIANT_NOT_SET = 0,
    BASE_IMAGE_VARIANT = 3,
  }

  export enum LatestVersionCase { 
    _LATEST_VERSION_NOT_SET = 0,
    LATEST_VERSION = 4,
  }

  export enum UpdateStatusCase { 
    _UPDATE_STATUS_NOT_SET = 0,
    UPDATE_STATUS = 5,
  }

  export enum RecentVersionsCase { 
    _RECENT_VERSIONS_NOT_SET = 0,
    RECENT_VERSIONS = 6,
  }
}

export class AssistantAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(value: string): AssistantAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(): AssistantAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): AssistantAction.AsObject;
  static toObject(includeInstance: boolean, msg: AssistantAction): AssistantAction.AsObject;
  static serializeBinaryToWriter(message: AssistantAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): AssistantAction;
  static deserializeBinaryFromReader(message: AssistantAction, reader: jspb.BinaryReader): AssistantAction;
}

export namespace AssistantAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotAssistant?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotAssistantCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_ASSISTANT_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_ASSISTANT = 1000,
  }
}

export class AssistantSetIsActiveAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(value: string): AssistantSetIsActiveAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(): AssistantSetIsActiveAction;

  getIsActive(): boolean;
  setIsActive(value: boolean): AssistantSetIsActiveAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): AssistantSetIsActiveAction.AsObject;
  static toObject(includeInstance: boolean, msg: AssistantSetIsActiveAction): AssistantSetIsActiveAction.AsObject;
  static serializeBinaryToWriter(message: AssistantSetIsActiveAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): AssistantSetIsActiveAction;
  static deserializeBinaryFromReader(message: AssistantSetIsActiveAction, reader: jspb.BinaryReader): AssistantSetIsActiveAction;
}

export namespace AssistantSetIsActiveAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotAssistant?: string,
    isActive: boolean,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotAssistantCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_ASSISTANT_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_ASSISTANT = 1000,
  }
}

export class AssistantSetSelectedLLMAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(value: string): AssistantSetSelectedLLMAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(): AssistantSetSelectedLLMAction;

  getLlmName(): AssistantLLMName;
  setLlmName(value: AssistantLLMName): AssistantSetSelectedLLMAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): AssistantSetSelectedLLMAction.AsObject;
  static toObject(includeInstance: boolean, msg: AssistantSetSelectedLLMAction): AssistantSetSelectedLLMAction.AsObject;
  static serializeBinaryToWriter(message: AssistantSetSelectedLLMAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): AssistantSetSelectedLLMAction;
  static deserializeBinaryFromReader(message: AssistantSetSelectedLLMAction, reader: jspb.BinaryReader): AssistantSetSelectedLLMAction;
}

export namespace AssistantSetSelectedLLMAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotAssistant?: string,
    llmName: AssistantLLMName,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotAssistantCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_ASSISTANT_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_ASSISTANT = 1000,
  }
}

export class AssistantSetSelectedModelAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(value: string): AssistantSetSelectedModelAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(): AssistantSetSelectedModelAction;

  getModel(): string;
  setModel(value: string): AssistantSetSelectedModelAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): AssistantSetSelectedModelAction.AsObject;
  static toObject(includeInstance: boolean, msg: AssistantSetSelectedModelAction): AssistantSetSelectedModelAction.AsObject;
  static serializeBinaryToWriter(message: AssistantSetSelectedModelAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): AssistantSetSelectedModelAction;
  static deserializeBinaryFromReader(message: AssistantSetSelectedModelAction, reader: jspb.BinaryReader): AssistantSetSelectedModelAction;
}

export namespace AssistantSetSelectedModelAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotAssistant?: string,
    model: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotAssistantCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_ASSISTANT_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_ASSISTANT = 1000,
  }
}

export class AssistantDownloadOllamaModelAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(value: string): AssistantDownloadOllamaModelAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(): AssistantDownloadOllamaModelAction;

  getModel(): string;
  setModel(value: string): AssistantDownloadOllamaModelAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): AssistantDownloadOllamaModelAction.AsObject;
  static toObject(includeInstance: boolean, msg: AssistantDownloadOllamaModelAction): AssistantDownloadOllamaModelAction.AsObject;
  static serializeBinaryToWriter(message: AssistantDownloadOllamaModelAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): AssistantDownloadOllamaModelAction;
  static deserializeBinaryFromReader(message: AssistantDownloadOllamaModelAction, reader: jspb.BinaryReader): AssistantDownloadOllamaModelAction;
}

export namespace AssistantDownloadOllamaModelAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotAssistant?: string,
    model: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotAssistantCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_ASSISTANT_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_ASSISTANT = 1000,
  }
}

export class AssistanceFrame extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(value: string): AssistanceFrame;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(): AssistanceFrame;

  getIsLastFrame(): boolean;
  setIsLastFrame(value: boolean): AssistanceFrame;

  getTimestamp(): number;
  setTimestamp(value: number): AssistanceFrame;

  getId(): string;
  setId(value: string): AssistanceFrame;

  getIndex(): number;
  setIndex(value: number): AssistanceFrame;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): AssistanceFrame.AsObject;
  static toObject(includeInstance: boolean, msg: AssistanceFrame): AssistanceFrame.AsObject;
  static serializeBinaryToWriter(message: AssistanceFrame, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): AssistanceFrame;
  static deserializeBinaryFromReader(message: AssistanceFrame, reader: jspb.BinaryReader): AssistanceFrame;
}

export namespace AssistanceFrame {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotAssistant?: string,
    isLastFrame: boolean,
    timestamp: number,
    id: string,
    index: number,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotAssistantCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_ASSISTANT_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_ASSISTANT = 1000,
  }
}

export class AssistanceTextFrame extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(value: string): AssistanceTextFrame;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(): AssistanceTextFrame;

  getText(): string;
  setText(value: string): AssistanceTextFrame;
  hasText(): boolean;
  clearText(): AssistanceTextFrame;

  getIsLastFrame(): boolean;
  setIsLastFrame(value: boolean): AssistanceTextFrame;

  getTimestamp(): number;
  setTimestamp(value: number): AssistanceTextFrame;

  getId(): string;
  setId(value: string): AssistanceTextFrame;

  getIndex(): number;
  setIndex(value: number): AssistanceTextFrame;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): AssistanceTextFrame.AsObject;
  static toObject(includeInstance: boolean, msg: AssistanceTextFrame): AssistanceTextFrame.AsObject;
  static serializeBinaryToWriter(message: AssistanceTextFrame, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): AssistanceTextFrame;
  static deserializeBinaryFromReader(message: AssistanceTextFrame, reader: jspb.BinaryReader): AssistanceTextFrame;
}

export namespace AssistanceTextFrame {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotAssistant?: string,
    text?: string,
    isLastFrame: boolean,
    timestamp: number,
    id: string,
    index: number,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotAssistantCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_ASSISTANT_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_ASSISTANT = 1000,
  }

  export enum TextCase { 
    _TEXT_NOT_SET = 0,
    TEXT = 2,
  }
}

export class AssistanceAudioFrame extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(value: string): AssistanceAudioFrame;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(): AssistanceAudioFrame;

  getAudio(): AudioSample | undefined;
  setAudio(value?: AudioSample): AssistanceAudioFrame;
  hasAudio(): boolean;
  clearAudio(): AssistanceAudioFrame;

  getIsLastFrame(): boolean;
  setIsLastFrame(value: boolean): AssistanceAudioFrame;

  getTimestamp(): number;
  setTimestamp(value: number): AssistanceAudioFrame;

  getId(): string;
  setId(value: string): AssistanceAudioFrame;

  getIndex(): number;
  setIndex(value: number): AssistanceAudioFrame;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): AssistanceAudioFrame.AsObject;
  static toObject(includeInstance: boolean, msg: AssistanceAudioFrame): AssistanceAudioFrame.AsObject;
  static serializeBinaryToWriter(message: AssistanceAudioFrame, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): AssistanceAudioFrame;
  static deserializeBinaryFromReader(message: AssistanceAudioFrame, reader: jspb.BinaryReader): AssistanceAudioFrame;
}

export namespace AssistanceAudioFrame {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotAssistant?: string,
    audio?: AudioSample.AsObject,
    isLastFrame: boolean,
    timestamp: number,
    id: string,
    index: number,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotAssistantCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_ASSISTANT_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_ASSISTANT = 1000,
  }

  export enum AudioCase { 
    _AUDIO_NOT_SET = 0,
    AUDIO = 2,
  }
}

export class AssistanceImageFrame extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(value: string): AssistanceImageFrame;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(): AssistanceImageFrame;

  getImage(): Uint8Array | string;
  getImage_asU8(): Uint8Array;
  getImage_asB64(): string;
  setImage(value: Uint8Array | string): AssistanceImageFrame;
  hasImage(): boolean;
  clearImage(): AssistanceImageFrame;

  getIsLastFrame(): boolean;
  setIsLastFrame(value: boolean): AssistanceImageFrame;

  getTimestamp(): number;
  setTimestamp(value: number): AssistanceImageFrame;

  getId(): string;
  setId(value: string): AssistanceImageFrame;

  getIndex(): number;
  setIndex(value: number): AssistanceImageFrame;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): AssistanceImageFrame.AsObject;
  static toObject(includeInstance: boolean, msg: AssistanceImageFrame): AssistanceImageFrame.AsObject;
  static serializeBinaryToWriter(message: AssistanceImageFrame, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): AssistanceImageFrame;
  static deserializeBinaryFromReader(message: AssistanceImageFrame, reader: jspb.BinaryReader): AssistanceImageFrame;
}

export namespace AssistanceImageFrame {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotAssistant?: string,
    image?: Uint8Array | string,
    isLastFrame: boolean,
    timestamp: number,
    id: string,
    index: number,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotAssistantCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_ASSISTANT_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_ASSISTANT = 1000,
  }

  export enum ImageCase { 
    _IMAGE_NOT_SET = 0,
    IMAGE = 2,
  }
}

export class AssistanceVideoFrame extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(value: string): AssistanceVideoFrame;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(): AssistanceVideoFrame;

  getVideo(): Uint8Array | string;
  getVideo_asU8(): Uint8Array;
  getVideo_asB64(): string;
  setVideo(value: Uint8Array | string): AssistanceVideoFrame;
  hasVideo(): boolean;
  clearVideo(): AssistanceVideoFrame;

  getIsLastFrame(): boolean;
  setIsLastFrame(value: boolean): AssistanceVideoFrame;

  getTimestamp(): number;
  setTimestamp(value: number): AssistanceVideoFrame;

  getId(): string;
  setId(value: string): AssistanceVideoFrame;

  getIndex(): number;
  setIndex(value: number): AssistanceVideoFrame;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): AssistanceVideoFrame.AsObject;
  static toObject(includeInstance: boolean, msg: AssistanceVideoFrame): AssistanceVideoFrame.AsObject;
  static serializeBinaryToWriter(message: AssistanceVideoFrame, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): AssistanceVideoFrame;
  static deserializeBinaryFromReader(message: AssistanceVideoFrame, reader: jspb.BinaryReader): AssistanceVideoFrame;
}

export namespace AssistanceVideoFrame {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotAssistant?: string,
    video?: Uint8Array | string,
    isLastFrame: boolean,
    timestamp: number,
    id: string,
    index: number,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotAssistantCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_ASSISTANT_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_ASSISTANT = 1000,
  }

  export enum VideoCase { 
    _VIDEO_NOT_SET = 0,
    VIDEO = 2,
  }
}

export class AssistantReportAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(value: string): AssistantReportAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(): AssistantReportAction;

  getSourceId(): string;
  setSourceId(value: string): AssistantReportAction;

  getData(): AcceptableAssistanceFrame | undefined;
  setData(value?: AcceptableAssistanceFrame): AssistantReportAction;
  hasData(): boolean;
  clearData(): AssistantReportAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): AssistantReportAction.AsObject;
  static toObject(includeInstance: boolean, msg: AssistantReportAction): AssistantReportAction.AsObject;
  static serializeBinaryToWriter(message: AssistantReportAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): AssistantReportAction;
  static deserializeBinaryFromReader(message: AssistantReportAction, reader: jspb.BinaryReader): AssistantReportAction;
}

export namespace AssistantReportAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotAssistant?: string,
    sourceId: string,
    data?: AcceptableAssistanceFrame.AsObject,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotAssistantCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_ASSISTANT_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_ASSISTANT = 1000,
  }
}

export class AssistantStartListeningAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(value: string): AssistantStartListeningAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(): AssistantStartListeningAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): AssistantStartListeningAction.AsObject;
  static toObject(includeInstance: boolean, msg: AssistantStartListeningAction): AssistantStartListeningAction.AsObject;
  static serializeBinaryToWriter(message: AssistantStartListeningAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): AssistantStartListeningAction;
  static deserializeBinaryFromReader(message: AssistantStartListeningAction, reader: jspb.BinaryReader): AssistantStartListeningAction;
}

export namespace AssistantStartListeningAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotAssistant?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotAssistantCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_ASSISTANT_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_ASSISTANT = 1000,
  }
}

export class AssistantStopListeningAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(value: string): AssistantStopListeningAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(): AssistantStopListeningAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): AssistantStopListeningAction.AsObject;
  static toObject(includeInstance: boolean, msg: AssistantStopListeningAction): AssistantStopListeningAction.AsObject;
  static serializeBinaryToWriter(message: AssistantStopListeningAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): AssistantStopListeningAction;
  static deserializeBinaryFromReader(message: AssistantStopListeningAction, reader: jspb.BinaryReader): AssistantStopListeningAction;
}

export namespace AssistantStopListeningAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotAssistant?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotAssistantCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_ASSISTANT_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_ASSISTANT = 1000,
  }
}

export class AssistantEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(value: string): AssistantEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(): AssistantEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): AssistantEvent.AsObject;
  static toObject(includeInstance: boolean, msg: AssistantEvent): AssistantEvent.AsObject;
  static serializeBinaryToWriter(message: AssistantEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): AssistantEvent;
  static deserializeBinaryFromReader(message: AssistantEvent, reader: jspb.BinaryReader): AssistantEvent;
}

export namespace AssistantEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotAssistant?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotAssistantCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_ASSISTANT_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_ASSISTANT = 1000,
  }
}

export class AssistantDownloadOllamaModelEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(value: string): AssistantDownloadOllamaModelEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(): AssistantDownloadOllamaModelEvent;

  getModel(): string;
  setModel(value: string): AssistantDownloadOllamaModelEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): AssistantDownloadOllamaModelEvent.AsObject;
  static toObject(includeInstance: boolean, msg: AssistantDownloadOllamaModelEvent): AssistantDownloadOllamaModelEvent.AsObject;
  static serializeBinaryToWriter(message: AssistantDownloadOllamaModelEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): AssistantDownloadOllamaModelEvent;
  static deserializeBinaryFromReader(message: AssistantDownloadOllamaModelEvent, reader: jspb.BinaryReader): AssistantDownloadOllamaModelEvent;
}

export namespace AssistantDownloadOllamaModelEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotAssistant?: string,
    model: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotAssistantCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_ASSISTANT_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_ASSISTANT = 1000,
  }
}

export class AssistantReportEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(value: string): AssistantReportEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(): AssistantReportEvent;

  getSourceId(): string;
  setSourceId(value: string): AssistantReportEvent;

  getData(): AcceptableAssistanceFrame | undefined;
  setData(value?: AcceptableAssistanceFrame): AssistantReportEvent;
  hasData(): boolean;
  clearData(): AssistantReportEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): AssistantReportEvent.AsObject;
  static toObject(includeInstance: boolean, msg: AssistantReportEvent): AssistantReportEvent.AsObject;
  static serializeBinaryToWriter(message: AssistantReportEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): AssistantReportEvent;
  static deserializeBinaryFromReader(message: AssistantReportEvent, reader: jspb.BinaryReader): AssistantReportEvent;
}

export namespace AssistantReportEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotAssistant?: string,
    sourceId: string,
    data?: AcceptableAssistanceFrame.AsObject,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotAssistantCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_ASSISTANT_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_ASSISTANT = 1000,
  }
}

export class AssistantState extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(value: string): AssistantState;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotAssistant(): AssistantState;

  getIsListening(): boolean;
  setIsListening(value: boolean): AssistantState;
  hasIsListening(): boolean;
  clearIsListening(): AssistantState;

  getIsActive(): boolean;
  setIsActive(value: boolean): AssistantState;
  hasIsActive(): boolean;
  clearIsActive(): AssistantState;

  getSelectedLlm(): AssistantLLMName;
  setSelectedLlm(value: AssistantLLMName): AssistantState;
  hasSelectedLlm(): boolean;
  clearSelectedLlm(): AssistantState;

  getSelectedModels(): AssistantState.SelectedModelsDict | undefined;
  setSelectedModels(value?: AssistantState.SelectedModelsDict): AssistantState;
  hasSelectedModels(): boolean;
  clearSelectedModels(): AssistantState;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): AssistantState.AsObject;
  static toObject(includeInstance: boolean, msg: AssistantState): AssistantState.AsObject;
  static serializeBinaryToWriter(message: AssistantState, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): AssistantState;
  static deserializeBinaryFromReader(message: AssistantState, reader: jspb.BinaryReader): AssistantState;
}

export namespace AssistantState {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotAssistant?: string,
    isListening?: boolean,
    isActive?: boolean,
    selectedLlm?: AssistantLLMName,
    selectedModels?: AssistantState.SelectedModelsDict.AsObject,
  }

  export class SelectedModelsDict extends jspb.Message {
    getItemsMap(): jspb.Map<string, string>;
    clearItemsMap(): SelectedModelsDict;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): SelectedModelsDict.AsObject;
    static toObject(includeInstance: boolean, msg: SelectedModelsDict): SelectedModelsDict.AsObject;
    static serializeBinaryToWriter(message: SelectedModelsDict, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): SelectedModelsDict;
    static deserializeBinaryFromReader(message: SelectedModelsDict, reader: jspb.BinaryReader): SelectedModelsDict;
  }

  export namespace SelectedModelsDict {
    export type AsObject = {
      itemsMap: Array<[string, string]>,
    }
  }


  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotAssistantCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_ASSISTANT_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_ASSISTANT = 1000,
  }

  export enum IsListeningCase { 
    _IS_LISTENING_NOT_SET = 0,
    IS_LISTENING = 2,
  }

  export enum IsActiveCase { 
    _IS_ACTIVE_NOT_SET = 0,
    IS_ACTIVE = 3,
  }

  export enum SelectedLlmCase { 
    _SELECTED_LLM_NOT_SET = 0,
    SELECTED_LLM = 4,
  }

  export enum SelectedModelsCase { 
    _SELECTED_MODELS_NOT_SET = 0,
    SELECTED_MODELS = 5,
  }
}

export class AcceptableAssistanceFrame extends jspb.Message {
  getAssistanceAudioFrame(): AssistanceAudioFrame | undefined;
  setAssistanceAudioFrame(value?: AssistanceAudioFrame): AcceptableAssistanceFrame;
  hasAssistanceAudioFrame(): boolean;
  clearAssistanceAudioFrame(): AcceptableAssistanceFrame;

  getAssistanceImageFrame(): AssistanceImageFrame | undefined;
  setAssistanceImageFrame(value?: AssistanceImageFrame): AcceptableAssistanceFrame;
  hasAssistanceImageFrame(): boolean;
  clearAssistanceImageFrame(): AcceptableAssistanceFrame;

  getAssistanceTextFrame(): AssistanceTextFrame | undefined;
  setAssistanceTextFrame(value?: AssistanceTextFrame): AcceptableAssistanceFrame;
  hasAssistanceTextFrame(): boolean;
  clearAssistanceTextFrame(): AcceptableAssistanceFrame;

  getAssistanceVideoFrame(): AssistanceVideoFrame | undefined;
  setAssistanceVideoFrame(value?: AssistanceVideoFrame): AcceptableAssistanceFrame;
  hasAssistanceVideoFrame(): boolean;
  clearAssistanceVideoFrame(): AcceptableAssistanceFrame;

  getAcceptableAssistanceFrameCase(): AcceptableAssistanceFrame.AcceptableAssistanceFrameCase;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): AcceptableAssistanceFrame.AsObject;
  static toObject(includeInstance: boolean, msg: AcceptableAssistanceFrame): AcceptableAssistanceFrame.AsObject;
  static serializeBinaryToWriter(message: AcceptableAssistanceFrame, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): AcceptableAssistanceFrame;
  static deserializeBinaryFromReader(message: AcceptableAssistanceFrame, reader: jspb.BinaryReader): AcceptableAssistanceFrame;
}

export namespace AcceptableAssistanceFrame {
  export type AsObject = {
    assistanceAudioFrame?: AssistanceAudioFrame.AsObject,
    assistanceImageFrame?: AssistanceImageFrame.AsObject,
    assistanceTextFrame?: AssistanceTextFrame.AsObject,
    assistanceVideoFrame?: AssistanceVideoFrame.AsObject,
  }

  export enum AcceptableAssistanceFrameCase { 
    ACCEPTABLE_ASSISTANCE_FRAME_NOT_SET = 0,
    ASSISTANCE_AUDIO_FRAME = 1,
    ASSISTANCE_IMAGE_FRAME = 2,
    ASSISTANCE_TEXT_FRAME = 3,
    ASSISTANCE_VIDEO_FRAME = 4,
  }
}

export class AudioAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(value: string): AudioAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(): AudioAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): AudioAction.AsObject;
  static toObject(includeInstance: boolean, msg: AudioAction): AudioAction.AsObject;
  static serializeBinaryToWriter(message: AudioAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): AudioAction;
  static deserializeBinaryFromReader(message: AudioAction, reader: jspb.BinaryReader): AudioAction;
}

export namespace AudioAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotAudio?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotAudioCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_AUDIO_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_AUDIO = 1000,
  }
}

export class AudioInstallDriverAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(value: string): AudioInstallDriverAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(): AudioInstallDriverAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): AudioInstallDriverAction.AsObject;
  static toObject(includeInstance: boolean, msg: AudioInstallDriverAction): AudioInstallDriverAction.AsObject;
  static serializeBinaryToWriter(message: AudioInstallDriverAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): AudioInstallDriverAction;
  static deserializeBinaryFromReader(message: AudioInstallDriverAction, reader: jspb.BinaryReader): AudioInstallDriverAction;
}

export namespace AudioInstallDriverAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotAudio?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotAudioCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_AUDIO_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_AUDIO = 1000,
  }
}

export class AudioSetVolumeAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(value: string): AudioSetVolumeAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(): AudioSetVolumeAction;

  getVolume(): number;
  setVolume(value: number): AudioSetVolumeAction;

  getDevice(): AudioDevice;
  setDevice(value: AudioDevice): AudioSetVolumeAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): AudioSetVolumeAction.AsObject;
  static toObject(includeInstance: boolean, msg: AudioSetVolumeAction): AudioSetVolumeAction.AsObject;
  static serializeBinaryToWriter(message: AudioSetVolumeAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): AudioSetVolumeAction;
  static deserializeBinaryFromReader(message: AudioSetVolumeAction, reader: jspb.BinaryReader): AudioSetVolumeAction;
}

export namespace AudioSetVolumeAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotAudio?: string,
    volume: number,
    device: AudioDevice,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotAudioCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_AUDIO_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_AUDIO = 1000,
  }
}

export class AudioChangeVolumeAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(value: string): AudioChangeVolumeAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(): AudioChangeVolumeAction;

  getAmount(): number;
  setAmount(value: number): AudioChangeVolumeAction;

  getDevice(): AudioDevice;
  setDevice(value: AudioDevice): AudioChangeVolumeAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): AudioChangeVolumeAction.AsObject;
  static toObject(includeInstance: boolean, msg: AudioChangeVolumeAction): AudioChangeVolumeAction.AsObject;
  static serializeBinaryToWriter(message: AudioChangeVolumeAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): AudioChangeVolumeAction;
  static deserializeBinaryFromReader(message: AudioChangeVolumeAction, reader: jspb.BinaryReader): AudioChangeVolumeAction;
}

export namespace AudioChangeVolumeAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotAudio?: string,
    amount: number,
    device: AudioDevice,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotAudioCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_AUDIO_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_AUDIO = 1000,
  }
}

export class AudioSetMuteStatusAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(value: string): AudioSetMuteStatusAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(): AudioSetMuteStatusAction;

  getIsMute(): boolean;
  setIsMute(value: boolean): AudioSetMuteStatusAction;

  getDevice(): AudioDevice;
  setDevice(value: AudioDevice): AudioSetMuteStatusAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): AudioSetMuteStatusAction.AsObject;
  static toObject(includeInstance: boolean, msg: AudioSetMuteStatusAction): AudioSetMuteStatusAction.AsObject;
  static serializeBinaryToWriter(message: AudioSetMuteStatusAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): AudioSetMuteStatusAction;
  static deserializeBinaryFromReader(message: AudioSetMuteStatusAction, reader: jspb.BinaryReader): AudioSetMuteStatusAction;
}

export namespace AudioSetMuteStatusAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotAudio?: string,
    isMute: boolean,
    device: AudioDevice,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotAudioCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_AUDIO_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_AUDIO = 1000,
  }
}

export class AudioToggleMuteStatusAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(value: string): AudioToggleMuteStatusAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(): AudioToggleMuteStatusAction;

  getDevice(): AudioDevice;
  setDevice(value: AudioDevice): AudioToggleMuteStatusAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): AudioToggleMuteStatusAction.AsObject;
  static toObject(includeInstance: boolean, msg: AudioToggleMuteStatusAction): AudioToggleMuteStatusAction.AsObject;
  static serializeBinaryToWriter(message: AudioToggleMuteStatusAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): AudioToggleMuteStatusAction;
  static deserializeBinaryFromReader(message: AudioToggleMuteStatusAction, reader: jspb.BinaryReader): AudioToggleMuteStatusAction;
}

export namespace AudioToggleMuteStatusAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotAudio?: string,
    device: AudioDevice,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotAudioCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_AUDIO_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_AUDIO = 1000,
  }
}

export class AudioPlayChimeAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(value: string): AudioPlayChimeAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(): AudioPlayChimeAction;

  getName(): string;
  setName(value: string): AudioPlayChimeAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): AudioPlayChimeAction.AsObject;
  static toObject(includeInstance: boolean, msg: AudioPlayChimeAction): AudioPlayChimeAction.AsObject;
  static serializeBinaryToWriter(message: AudioPlayChimeAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): AudioPlayChimeAction;
  static deserializeBinaryFromReader(message: AudioPlayChimeAction, reader: jspb.BinaryReader): AudioPlayChimeAction;
}

export namespace AudioPlayChimeAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotAudio?: string,
    name: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotAudioCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_AUDIO_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_AUDIO = 1000,
  }
}

export class AudioPlayAudioSampleAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(value: string): AudioPlayAudioSampleAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(): AudioPlayAudioSampleAction;

  getSample(): AudioSample | undefined;
  setSample(value?: AudioSample): AudioPlayAudioSampleAction;
  hasSample(): boolean;
  clearSample(): AudioPlayAudioSampleAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): AudioPlayAudioSampleAction.AsObject;
  static toObject(includeInstance: boolean, msg: AudioPlayAudioSampleAction): AudioPlayAudioSampleAction.AsObject;
  static serializeBinaryToWriter(message: AudioPlayAudioSampleAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): AudioPlayAudioSampleAction;
  static deserializeBinaryFromReader(message: AudioPlayAudioSampleAction, reader: jspb.BinaryReader): AudioPlayAudioSampleAction;
}

export namespace AudioPlayAudioSampleAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotAudio?: string,
    sample?: AudioSample.AsObject,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotAudioCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_AUDIO_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_AUDIO = 1000,
  }
}

export class AudioPlayAudioSequenceAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(value: string): AudioPlayAudioSequenceAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(): AudioPlayAudioSequenceAction;

  getSample(): AudioSample | undefined;
  setSample(value?: AudioSample): AudioPlayAudioSequenceAction;
  hasSample(): boolean;
  clearSample(): AudioPlayAudioSequenceAction;

  getId(): string;
  setId(value: string): AudioPlayAudioSequenceAction;

  getIndex(): number;
  setIndex(value: number): AudioPlayAudioSequenceAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): AudioPlayAudioSequenceAction.AsObject;
  static toObject(includeInstance: boolean, msg: AudioPlayAudioSequenceAction): AudioPlayAudioSequenceAction.AsObject;
  static serializeBinaryToWriter(message: AudioPlayAudioSequenceAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): AudioPlayAudioSequenceAction;
  static deserializeBinaryFromReader(message: AudioPlayAudioSequenceAction, reader: jspb.BinaryReader): AudioPlayAudioSequenceAction;
}

export namespace AudioPlayAudioSequenceAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotAudio?: string,
    sample?: AudioSample.AsObject,
    id: string,
    index: number,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotAudioCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_AUDIO_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_AUDIO = 1000,
  }

  export enum SampleCase { 
    _SAMPLE_NOT_SET = 0,
    SAMPLE = 2,
  }
}

export class AudioSample extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(value: string): AudioSample;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(): AudioSample;

  getData(): Uint8Array | string;
  getData_asU8(): Uint8Array;
  getData_asB64(): string;
  setData(value: Uint8Array | string): AudioSample;

  getChannels(): number;
  setChannels(value: number): AudioSample;

  getRate(): number;
  setRate(value: number): AudioSample;

  getWidth(): number;
  setWidth(value: number): AudioSample;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): AudioSample.AsObject;
  static toObject(includeInstance: boolean, msg: AudioSample): AudioSample.AsObject;
  static serializeBinaryToWriter(message: AudioSample, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): AudioSample;
  static deserializeBinaryFromReader(message: AudioSample, reader: jspb.BinaryReader): AudioSample;
}

export namespace AudioSample {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotAudio?: string,
    data: Uint8Array | string,
    channels: number,
    rate: number,
    width: number,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotAudioCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_AUDIO_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_AUDIO = 1000,
  }
}

export class AudioPlaybackDoneAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(value: string): AudioPlaybackDoneAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(): AudioPlaybackDoneAction;

  getId(): string;
  setId(value: string): AudioPlaybackDoneAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): AudioPlaybackDoneAction.AsObject;
  static toObject(includeInstance: boolean, msg: AudioPlaybackDoneAction): AudioPlaybackDoneAction.AsObject;
  static serializeBinaryToWriter(message: AudioPlaybackDoneAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): AudioPlaybackDoneAction;
  static deserializeBinaryFromReader(message: AudioPlaybackDoneAction, reader: jspb.BinaryReader): AudioPlaybackDoneAction;
}

export namespace AudioPlaybackDoneAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotAudio?: string,
    id: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotAudioCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_AUDIO_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_AUDIO = 1000,
  }
}

export class AudioEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(value: string): AudioEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(): AudioEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): AudioEvent.AsObject;
  static toObject(includeInstance: boolean, msg: AudioEvent): AudioEvent.AsObject;
  static serializeBinaryToWriter(message: AudioEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): AudioEvent;
  static deserializeBinaryFromReader(message: AudioEvent, reader: jspb.BinaryReader): AudioEvent;
}

export namespace AudioEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotAudio?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotAudioCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_AUDIO_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_AUDIO = 1000,
  }
}

export class AudioReportSampleEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(value: string): AudioReportSampleEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(): AudioReportSampleEvent;

  getTimestamp(): number;
  setTimestamp(value: number): AudioReportSampleEvent;

  getSampleSpeechRecognition(): Uint8Array | string;
  getSampleSpeechRecognition_asU8(): Uint8Array;
  getSampleSpeechRecognition_asB64(): string;
  setSampleSpeechRecognition(value: Uint8Array | string): AudioReportSampleEvent;

  getSample(): AudioSample | undefined;
  setSample(value?: AudioSample): AudioReportSampleEvent;
  hasSample(): boolean;
  clearSample(): AudioReportSampleEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): AudioReportSampleEvent.AsObject;
  static toObject(includeInstance: boolean, msg: AudioReportSampleEvent): AudioReportSampleEvent.AsObject;
  static serializeBinaryToWriter(message: AudioReportSampleEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): AudioReportSampleEvent;
  static deserializeBinaryFromReader(message: AudioReportSampleEvent, reader: jspb.BinaryReader): AudioReportSampleEvent;
}

export namespace AudioReportSampleEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotAudio?: string,
    timestamp: number,
    sampleSpeechRecognition: Uint8Array | string,
    sample?: AudioSample.AsObject,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotAudioCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_AUDIO_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_AUDIO = 1000,
  }
}

export class AudioInstallDriverEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(value: string): AudioInstallDriverEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(): AudioInstallDriverEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): AudioInstallDriverEvent.AsObject;
  static toObject(includeInstance: boolean, msg: AudioInstallDriverEvent): AudioInstallDriverEvent.AsObject;
  static serializeBinaryToWriter(message: AudioInstallDriverEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): AudioInstallDriverEvent;
  static deserializeBinaryFromReader(message: AudioInstallDriverEvent, reader: jspb.BinaryReader): AudioInstallDriverEvent;
}

export namespace AudioInstallDriverEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotAudio?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotAudioCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_AUDIO_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_AUDIO = 1000,
  }
}

export class AudioPlayChimeEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(value: string): AudioPlayChimeEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(): AudioPlayChimeEvent;

  getName(): string;
  setName(value: string): AudioPlayChimeEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): AudioPlayChimeEvent.AsObject;
  static toObject(includeInstance: boolean, msg: AudioPlayChimeEvent): AudioPlayChimeEvent.AsObject;
  static serializeBinaryToWriter(message: AudioPlayChimeEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): AudioPlayChimeEvent;
  static deserializeBinaryFromReader(message: AudioPlayChimeEvent, reader: jspb.BinaryReader): AudioPlayChimeEvent;
}

export namespace AudioPlayChimeEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotAudio?: string,
    name: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotAudioCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_AUDIO_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_AUDIO = 1000,
  }
}

export class AudioPlayAudioSampleEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(value: string): AudioPlayAudioSampleEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(): AudioPlayAudioSampleEvent;

  getVolume(): number;
  setVolume(value: number): AudioPlayAudioSampleEvent;

  getSample(): AudioSample | undefined;
  setSample(value?: AudioSample): AudioPlayAudioSampleEvent;
  hasSample(): boolean;
  clearSample(): AudioPlayAudioSampleEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): AudioPlayAudioSampleEvent.AsObject;
  static toObject(includeInstance: boolean, msg: AudioPlayAudioSampleEvent): AudioPlayAudioSampleEvent.AsObject;
  static serializeBinaryToWriter(message: AudioPlayAudioSampleEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): AudioPlayAudioSampleEvent;
  static deserializeBinaryFromReader(message: AudioPlayAudioSampleEvent, reader: jspb.BinaryReader): AudioPlayAudioSampleEvent;
}

export namespace AudioPlayAudioSampleEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotAudio?: string,
    volume: number,
    sample?: AudioSample.AsObject,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotAudioCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_AUDIO_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_AUDIO = 1000,
  }
}

export class AudioPlayAudioSequenceEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(value: string): AudioPlayAudioSequenceEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(): AudioPlayAudioSequenceEvent;

  getVolume(): number;
  setVolume(value: number): AudioPlayAudioSequenceEvent;

  getSample(): AudioSample | undefined;
  setSample(value?: AudioSample): AudioPlayAudioSequenceEvent;
  hasSample(): boolean;
  clearSample(): AudioPlayAudioSequenceEvent;

  getId(): string;
  setId(value: string): AudioPlayAudioSequenceEvent;

  getIndex(): number;
  setIndex(value: number): AudioPlayAudioSequenceEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): AudioPlayAudioSequenceEvent.AsObject;
  static toObject(includeInstance: boolean, msg: AudioPlayAudioSequenceEvent): AudioPlayAudioSequenceEvent.AsObject;
  static serializeBinaryToWriter(message: AudioPlayAudioSequenceEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): AudioPlayAudioSequenceEvent;
  static deserializeBinaryFromReader(message: AudioPlayAudioSequenceEvent, reader: jspb.BinaryReader): AudioPlayAudioSequenceEvent;
}

export namespace AudioPlayAudioSequenceEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotAudio?: string,
    volume: number,
    sample?: AudioSample.AsObject,
    id: string,
    index: number,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotAudioCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_AUDIO_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_AUDIO = 1000,
  }

  export enum SampleCase { 
    _SAMPLE_NOT_SET = 0,
    SAMPLE = 3,
  }
}

export class AudioPlaybackDoneEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(value: string): AudioPlaybackDoneEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(): AudioPlaybackDoneEvent;

  getId(): string;
  setId(value: string): AudioPlaybackDoneEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): AudioPlaybackDoneEvent.AsObject;
  static toObject(includeInstance: boolean, msg: AudioPlaybackDoneEvent): AudioPlaybackDoneEvent.AsObject;
  static serializeBinaryToWriter(message: AudioPlaybackDoneEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): AudioPlaybackDoneEvent;
  static deserializeBinaryFromReader(message: AudioPlaybackDoneEvent, reader: jspb.BinaryReader): AudioPlaybackDoneEvent;
}

export namespace AudioPlaybackDoneEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotAudio?: string,
    id: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotAudioCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_AUDIO_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_AUDIO = 1000,
  }
}

export class AudioState extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(value: string): AudioState;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotAudio(): AudioState;

  getPlaybackVolume(): number;
  setPlaybackVolume(value: number): AudioState;
  hasPlaybackVolume(): boolean;
  clearPlaybackVolume(): AudioState;

  getIsPlaybackMute(): boolean;
  setIsPlaybackMute(value: boolean): AudioState;
  hasIsPlaybackMute(): boolean;
  clearIsPlaybackMute(): AudioState;

  getCaptureVolume(): number;
  setCaptureVolume(value: number): AudioState;
  hasCaptureVolume(): boolean;
  clearCaptureVolume(): AudioState;

  getIsCaptureMute(): boolean;
  setIsCaptureMute(value: boolean): AudioState;
  hasIsCaptureMute(): boolean;
  clearIsCaptureMute(): AudioState;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): AudioState.AsObject;
  static toObject(includeInstance: boolean, msg: AudioState): AudioState.AsObject;
  static serializeBinaryToWriter(message: AudioState, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): AudioState;
  static deserializeBinaryFromReader(message: AudioState, reader: jspb.BinaryReader): AudioState;
}

export namespace AudioState {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotAudio?: string,
    playbackVolume?: number,
    isPlaybackMute?: boolean,
    captureVolume?: number,
    isCaptureMute?: boolean,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotAudioCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_AUDIO_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_AUDIO = 1000,
  }

  export enum PlaybackVolumeCase { 
    _PLAYBACK_VOLUME_NOT_SET = 0,
    PLAYBACK_VOLUME = 2,
  }

  export enum IsPlaybackMuteCase { 
    _IS_PLAYBACK_MUTE_NOT_SET = 0,
    IS_PLAYBACK_MUTE = 3,
  }

  export enum CaptureVolumeCase { 
    _CAPTURE_VOLUME_NOT_SET = 0,
    CAPTURE_VOLUME = 4,
  }

  export enum IsCaptureMuteCase { 
    _IS_CAPTURE_MUTE_NOT_SET = 0,
    IS_CAPTURE_MUTE = 5,
  }
}

export class CameraAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotCamera(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotCamera(value: string): CameraAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotCamera(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotCamera(): CameraAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): CameraAction.AsObject;
  static toObject(includeInstance: boolean, msg: CameraAction): CameraAction.AsObject;
  static serializeBinaryToWriter(message: CameraAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): CameraAction;
  static deserializeBinaryFromReader(message: CameraAction, reader: jspb.BinaryReader): CameraAction;
}

export namespace CameraAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotCamera?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotCameraCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_CAMERA_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_CAMERA = 1000,
  }
}

export class CameraStartViewfinderAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotCamera(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotCamera(value: string): CameraStartViewfinderAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotCamera(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotCamera(): CameraStartViewfinderAction;

  getPattern(): string;
  setPattern(value: string): CameraStartViewfinderAction;
  hasPattern(): boolean;
  clearPattern(): CameraStartViewfinderAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): CameraStartViewfinderAction.AsObject;
  static toObject(includeInstance: boolean, msg: CameraStartViewfinderAction): CameraStartViewfinderAction.AsObject;
  static serializeBinaryToWriter(message: CameraStartViewfinderAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): CameraStartViewfinderAction;
  static deserializeBinaryFromReader(message: CameraStartViewfinderAction, reader: jspb.BinaryReader): CameraStartViewfinderAction;
}

export namespace CameraStartViewfinderAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotCamera?: string,
    pattern?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotCameraCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_CAMERA_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_CAMERA = 1000,
  }

  export enum PatternCase { 
    _PATTERN_NOT_SET = 0,
    PATTERN = 2,
  }
}

export class CameraReportBarcodeAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotCamera(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotCamera(value: string): CameraReportBarcodeAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotCamera(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotCamera(): CameraReportBarcodeAction;

  getCodesList(): Array<string>;
  setCodesList(value: Array<string>): CameraReportBarcodeAction;
  clearCodesList(): CameraReportBarcodeAction;
  addCodes(value: string, index?: number): CameraReportBarcodeAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): CameraReportBarcodeAction.AsObject;
  static toObject(includeInstance: boolean, msg: CameraReportBarcodeAction): CameraReportBarcodeAction.AsObject;
  static serializeBinaryToWriter(message: CameraReportBarcodeAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): CameraReportBarcodeAction;
  static deserializeBinaryFromReader(message: CameraReportBarcodeAction, reader: jspb.BinaryReader): CameraReportBarcodeAction;
}

export namespace CameraReportBarcodeAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotCamera?: string,
    codesList: Array<string>,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotCameraCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_CAMERA_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_CAMERA = 1000,
  }
}

export class CameraEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotCamera(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotCamera(value: string): CameraEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotCamera(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotCamera(): CameraEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): CameraEvent.AsObject;
  static toObject(includeInstance: boolean, msg: CameraEvent): CameraEvent.AsObject;
  static serializeBinaryToWriter(message: CameraEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): CameraEvent;
  static deserializeBinaryFromReader(message: CameraEvent, reader: jspb.BinaryReader): CameraEvent;
}

export namespace CameraEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotCamera?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotCameraCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_CAMERA_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_CAMERA = 1000,
  }
}

export class CameraStartViewfinderEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotCamera(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotCamera(value: string): CameraStartViewfinderEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotCamera(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotCamera(): CameraStartViewfinderEvent;

  getPattern(): string;
  setPattern(value: string): CameraStartViewfinderEvent;
  hasPattern(): boolean;
  clearPattern(): CameraStartViewfinderEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): CameraStartViewfinderEvent.AsObject;
  static toObject(includeInstance: boolean, msg: CameraStartViewfinderEvent): CameraStartViewfinderEvent.AsObject;
  static serializeBinaryToWriter(message: CameraStartViewfinderEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): CameraStartViewfinderEvent;
  static deserializeBinaryFromReader(message: CameraStartViewfinderEvent, reader: jspb.BinaryReader): CameraStartViewfinderEvent;
}

export namespace CameraStartViewfinderEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotCamera?: string,
    pattern?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotCameraCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_CAMERA_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_CAMERA = 1000,
  }

  export enum PatternCase { 
    _PATTERN_NOT_SET = 0,
    PATTERN = 2,
  }
}

export class CameraStopViewfinderEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotCamera(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotCamera(value: string): CameraStopViewfinderEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotCamera(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotCamera(): CameraStopViewfinderEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): CameraStopViewfinderEvent.AsObject;
  static toObject(includeInstance: boolean, msg: CameraStopViewfinderEvent): CameraStopViewfinderEvent.AsObject;
  static serializeBinaryToWriter(message: CameraStopViewfinderEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): CameraStopViewfinderEvent;
  static deserializeBinaryFromReader(message: CameraStopViewfinderEvent, reader: jspb.BinaryReader): CameraStopViewfinderEvent;
}

export namespace CameraStopViewfinderEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotCamera?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotCameraCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_CAMERA_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_CAMERA = 1000,
  }
}

export class CameraState extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotCamera(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotCamera(value: string): CameraState;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotCamera(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotCamera(): CameraState;

  getQueueList(): Array<QRCodeInputDescription>;
  setQueueList(value: Array<QRCodeInputDescription>): CameraState;
  clearQueueList(): CameraState;
  addQueue(value?: QRCodeInputDescription, index?: number): QRCodeInputDescription;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): CameraState.AsObject;
  static toObject(includeInstance: boolean, msg: CameraState): CameraState.AsObject;
  static serializeBinaryToWriter(message: CameraState, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): CameraState;
  static deserializeBinaryFromReader(message: CameraState, reader: jspb.BinaryReader): CameraState;
}

export namespace CameraState {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotCamera?: string,
    queueList: Array<QRCodeInputDescription.AsObject>,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotCameraCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_CAMERA_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_CAMERA = 1000,
  }
}

export class DisplayAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotDisplay(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotDisplay(value: string): DisplayAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotDisplay(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotDisplay(): DisplayAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DisplayAction.AsObject;
  static toObject(includeInstance: boolean, msg: DisplayAction): DisplayAction.AsObject;
  static serializeBinaryToWriter(message: DisplayAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DisplayAction;
  static deserializeBinaryFromReader(message: DisplayAction, reader: jspb.BinaryReader): DisplayAction;
}

export namespace DisplayAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotDisplay?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotDisplayCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DISPLAY_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DISPLAY = 1000,
  }
}

export class DisplayEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotDisplay(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotDisplay(value: string): DisplayEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotDisplay(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotDisplay(): DisplayEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DisplayEvent.AsObject;
  static toObject(includeInstance: boolean, msg: DisplayEvent): DisplayEvent.AsObject;
  static serializeBinaryToWriter(message: DisplayEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DisplayEvent;
  static deserializeBinaryFromReader(message: DisplayEvent, reader: jspb.BinaryReader): DisplayEvent;
}

export namespace DisplayEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotDisplay?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotDisplayCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DISPLAY_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DISPLAY = 1000,
  }
}

export class DisplayPauseAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotDisplay(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotDisplay(value: string): DisplayPauseAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotDisplay(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotDisplay(): DisplayPauseAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DisplayPauseAction.AsObject;
  static toObject(includeInstance: boolean, msg: DisplayPauseAction): DisplayPauseAction.AsObject;
  static serializeBinaryToWriter(message: DisplayPauseAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DisplayPauseAction;
  static deserializeBinaryFromReader(message: DisplayPauseAction, reader: jspb.BinaryReader): DisplayPauseAction;
}

export namespace DisplayPauseAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotDisplay?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotDisplayCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DISPLAY_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DISPLAY = 1000,
  }
}

export class DisplayResumeAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotDisplay(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotDisplay(value: string): DisplayResumeAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotDisplay(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotDisplay(): DisplayResumeAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DisplayResumeAction.AsObject;
  static toObject(includeInstance: boolean, msg: DisplayResumeAction): DisplayResumeAction.AsObject;
  static serializeBinaryToWriter(message: DisplayResumeAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DisplayResumeAction;
  static deserializeBinaryFromReader(message: DisplayResumeAction, reader: jspb.BinaryReader): DisplayResumeAction;
}

export namespace DisplayResumeAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotDisplay?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotDisplayCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DISPLAY_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DISPLAY = 1000,
  }
}

export class DisplayRerenderEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotDisplay(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotDisplay(value: string): DisplayRerenderEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotDisplay(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotDisplay(): DisplayRerenderEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DisplayRerenderEvent.AsObject;
  static toObject(includeInstance: boolean, msg: DisplayRerenderEvent): DisplayRerenderEvent.AsObject;
  static serializeBinaryToWriter(message: DisplayRerenderEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DisplayRerenderEvent;
  static deserializeBinaryFromReader(message: DisplayRerenderEvent, reader: jspb.BinaryReader): DisplayRerenderEvent;
}

export namespace DisplayRerenderEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotDisplay?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotDisplayCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DISPLAY_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DISPLAY = 1000,
  }
}

export class DisplayRenderEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotDisplay(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotDisplay(value: string): DisplayRenderEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotDisplay(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotDisplay(): DisplayRenderEvent;

  getTimestamp(): number;
  setTimestamp(value: number): DisplayRenderEvent;

  getData(): Uint8Array | string;
  getData_asU8(): Uint8Array;
  getData_asB64(): string;
  setData(value: Uint8Array | string): DisplayRenderEvent;

  getRectangleList(): Array<number>;
  setRectangleList(value: Array<number>): DisplayRenderEvent;
  clearRectangleList(): DisplayRenderEvent;
  addRectangle(value: number, index?: number): DisplayRenderEvent;

  getDensity(): number;
  setDensity(value: number): DisplayRenderEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DisplayRenderEvent.AsObject;
  static toObject(includeInstance: boolean, msg: DisplayRenderEvent): DisplayRenderEvent.AsObject;
  static serializeBinaryToWriter(message: DisplayRenderEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DisplayRenderEvent;
  static deserializeBinaryFromReader(message: DisplayRenderEvent, reader: jspb.BinaryReader): DisplayRenderEvent;
}

export namespace DisplayRenderEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotDisplay?: string,
    timestamp: number,
    data: Uint8Array | string,
    rectangleList: Array<number>,
    density: number,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotDisplayCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DISPLAY_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DISPLAY = 1000,
  }
}

export class DisplayCompressedRenderEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotDisplay(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotDisplay(value: string): DisplayCompressedRenderEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotDisplay(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotDisplay(): DisplayCompressedRenderEvent;

  getTimestamp(): number;
  setTimestamp(value: number): DisplayCompressedRenderEvent;

  getCompressedData(): Uint8Array | string;
  getCompressedData_asU8(): Uint8Array;
  getCompressedData_asB64(): string;
  setCompressedData(value: Uint8Array | string): DisplayCompressedRenderEvent;

  getRectangleList(): Array<number>;
  setRectangleList(value: Array<number>): DisplayCompressedRenderEvent;
  clearRectangleList(): DisplayCompressedRenderEvent;
  addRectangle(value: number, index?: number): DisplayCompressedRenderEvent;

  getDensity(): number;
  setDensity(value: number): DisplayCompressedRenderEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DisplayCompressedRenderEvent.AsObject;
  static toObject(includeInstance: boolean, msg: DisplayCompressedRenderEvent): DisplayCompressedRenderEvent.AsObject;
  static serializeBinaryToWriter(message: DisplayCompressedRenderEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DisplayCompressedRenderEvent;
  static deserializeBinaryFromReader(message: DisplayCompressedRenderEvent, reader: jspb.BinaryReader): DisplayCompressedRenderEvent;
}

export namespace DisplayCompressedRenderEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotDisplay?: string,
    timestamp: number,
    compressedData: Uint8Array | string,
    rectangleList: Array<number>,
    density: number,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotDisplayCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DISPLAY_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DISPLAY = 1000,
  }
}

export class DisplayState extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotDisplay(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotDisplay(value: string): DisplayState;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotDisplay(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotDisplay(): DisplayState;

  getIsPaused(): boolean;
  setIsPaused(value: boolean): DisplayState;
  hasIsPaused(): boolean;
  clearIsPaused(): DisplayState;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DisplayState.AsObject;
  static toObject(includeInstance: boolean, msg: DisplayState): DisplayState.AsObject;
  static serializeBinaryToWriter(message: DisplayState, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DisplayState;
  static deserializeBinaryFromReader(message: DisplayState, reader: jspb.BinaryReader): DisplayState;
}

export namespace DisplayState {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotDisplay?: string,
    isPaused?: boolean,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotDisplayCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DISPLAY_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DISPLAY = 1000,
  }

  export enum IsPausedCase { 
    _IS_PAUSED_NOT_SET = 0,
    IS_PAUSED = 2,
  }
}

export class DockerAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(value: string): DockerAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): DockerAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DockerAction.AsObject;
  static toObject(includeInstance: boolean, msg: DockerAction): DockerAction.AsObject;
  static serializeBinaryToWriter(message: DockerAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DockerAction;
  static deserializeBinaryFromReader(message: DockerAction, reader: jspb.BinaryReader): DockerAction;
}

export namespace DockerAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotDocker?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotDockerCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER = 1000,
  }
}

export class DockerInstallAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(value: string): DockerInstallAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): DockerInstallAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DockerInstallAction.AsObject;
  static toObject(includeInstance: boolean, msg: DockerInstallAction): DockerInstallAction.AsObject;
  static serializeBinaryToWriter(message: DockerInstallAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DockerInstallAction;
  static deserializeBinaryFromReader(message: DockerInstallAction, reader: jspb.BinaryReader): DockerInstallAction;
}

export namespace DockerInstallAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotDocker?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotDockerCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER = 1000,
  }
}

export class DockerStartAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(value: string): DockerStartAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): DockerStartAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DockerStartAction.AsObject;
  static toObject(includeInstance: boolean, msg: DockerStartAction): DockerStartAction.AsObject;
  static serializeBinaryToWriter(message: DockerStartAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DockerStartAction;
  static deserializeBinaryFromReader(message: DockerStartAction, reader: jspb.BinaryReader): DockerStartAction;
}

export namespace DockerStartAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotDocker?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotDockerCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER = 1000,
  }
}

export class DockerStopAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(value: string): DockerStopAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): DockerStopAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DockerStopAction.AsObject;
  static toObject(includeInstance: boolean, msg: DockerStopAction): DockerStopAction.AsObject;
  static serializeBinaryToWriter(message: DockerStopAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DockerStopAction;
  static deserializeBinaryFromReader(message: DockerStopAction, reader: jspb.BinaryReader): DockerStopAction;
}

export namespace DockerStopAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotDocker?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotDockerCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER = 1000,
  }
}

export class DockerSetStatusAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(value: string): DockerSetStatusAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): DockerSetStatusAction;

  getStatus(): DockerStatus;
  setStatus(value: DockerStatus): DockerSetStatusAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DockerSetStatusAction.AsObject;
  static toObject(includeInstance: boolean, msg: DockerSetStatusAction): DockerSetStatusAction.AsObject;
  static serializeBinaryToWriter(message: DockerSetStatusAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DockerSetStatusAction;
  static deserializeBinaryFromReader(message: DockerSetStatusAction, reader: jspb.BinaryReader): DockerSetStatusAction;
}

export namespace DockerSetStatusAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotDocker?: string,
    status: DockerStatus,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotDockerCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER = 1000,
  }
}

export class DockerStoreUsernameAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(value: string): DockerStoreUsernameAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): DockerStoreUsernameAction;

  getRegistry(): string;
  setRegistry(value: string): DockerStoreUsernameAction;

  getUsername(): string;
  setUsername(value: string): DockerStoreUsernameAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DockerStoreUsernameAction.AsObject;
  static toObject(includeInstance: boolean, msg: DockerStoreUsernameAction): DockerStoreUsernameAction.AsObject;
  static serializeBinaryToWriter(message: DockerStoreUsernameAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DockerStoreUsernameAction;
  static deserializeBinaryFromReader(message: DockerStoreUsernameAction, reader: jspb.BinaryReader): DockerStoreUsernameAction;
}

export namespace DockerStoreUsernameAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotDocker?: string,
    registry: string,
    username: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotDockerCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER = 1000,
  }
}

export class DockerRemoveUsernameAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(value: string): DockerRemoveUsernameAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): DockerRemoveUsernameAction;

  getRegistry(): string;
  setRegistry(value: string): DockerRemoveUsernameAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DockerRemoveUsernameAction.AsObject;
  static toObject(includeInstance: boolean, msg: DockerRemoveUsernameAction): DockerRemoveUsernameAction.AsObject;
  static serializeBinaryToWriter(message: DockerRemoveUsernameAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DockerRemoveUsernameAction;
  static deserializeBinaryFromReader(message: DockerRemoveUsernameAction, reader: jspb.BinaryReader): DockerRemoveUsernameAction;
}

export namespace DockerRemoveUsernameAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotDocker?: string,
    registry: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotDockerCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER = 1000,
  }
}

export class DockerImageAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(value: string): DockerImageAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): DockerImageAction;

  getImage(): string;
  setImage(value: string): DockerImageAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DockerImageAction.AsObject;
  static toObject(includeInstance: boolean, msg: DockerImageAction): DockerImageAction.AsObject;
  static serializeBinaryToWriter(message: DockerImageAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DockerImageAction;
  static deserializeBinaryFromReader(message: DockerImageAction, reader: jspb.BinaryReader): DockerImageAction;
}

export namespace DockerImageAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotDocker?: string,
    image: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotDockerCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER = 1000,
  }
}

export class DockerImageSetStatusAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(value: string): DockerImageSetStatusAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): DockerImageSetStatusAction;

  getStatus(): DockerItemStatus;
  setStatus(value: DockerItemStatus): DockerImageSetStatusAction;

  getPorts(): DockerImageSetStatusAction.Ports | undefined;
  setPorts(value?: DockerImageSetStatusAction.Ports): DockerImageSetStatusAction;
  hasPorts(): boolean;
  clearPorts(): DockerImageSetStatusAction;

  getIp(): string;
  setIp(value: string): DockerImageSetStatusAction;
  hasIp(): boolean;
  clearIp(): DockerImageSetStatusAction;

  getImage(): string;
  setImage(value: string): DockerImageSetStatusAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DockerImageSetStatusAction.AsObject;
  static toObject(includeInstance: boolean, msg: DockerImageSetStatusAction): DockerImageSetStatusAction.AsObject;
  static serializeBinaryToWriter(message: DockerImageSetStatusAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DockerImageSetStatusAction;
  static deserializeBinaryFromReader(message: DockerImageSetStatusAction, reader: jspb.BinaryReader): DockerImageSetStatusAction;
}

export namespace DockerImageSetStatusAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotDocker?: string,
    status: DockerItemStatus,
    ports?: DockerImageSetStatusAction.Ports.AsObject,
    ip?: string,
    image: string,
  }

  export class Ports extends jspb.Message {
    getItemsList(): Array<string>;
    setItemsList(value: Array<string>): Ports;
    clearItemsList(): Ports;
    addItems(value: string, index?: number): Ports;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): Ports.AsObject;
    static toObject(includeInstance: boolean, msg: Ports): Ports.AsObject;
    static serializeBinaryToWriter(message: Ports, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): Ports;
    static deserializeBinaryFromReader(message: Ports, reader: jspb.BinaryReader): Ports;
  }

  export namespace Ports {
    export type AsObject = {
      itemsList: Array<string>,
    }
  }


  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotDockerCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER = 1000,
  }

  export enum PortsCase { 
    _PORTS_NOT_SET = 0,
    PORTS = 3,
  }

  export enum IpCase { 
    _IP_NOT_SET = 0,
    IP = 4,
  }
}

export class DockerImageSetDockerIdAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(value: string): DockerImageSetDockerIdAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): DockerImageSetDockerIdAction;

  getDockerId(): string;
  setDockerId(value: string): DockerImageSetDockerIdAction;

  getImage(): string;
  setImage(value: string): DockerImageSetDockerIdAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DockerImageSetDockerIdAction.AsObject;
  static toObject(includeInstance: boolean, msg: DockerImageSetDockerIdAction): DockerImageSetDockerIdAction.AsObject;
  static serializeBinaryToWriter(message: DockerImageSetDockerIdAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DockerImageSetDockerIdAction;
  static deserializeBinaryFromReader(message: DockerImageSetDockerIdAction, reader: jspb.BinaryReader): DockerImageSetDockerIdAction;
}

export namespace DockerImageSetDockerIdAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotDocker?: string,
    dockerId: string,
    image: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotDockerCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER = 1000,
  }
}

export class DockerImageFetchCompositionAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(value: string): DockerImageFetchCompositionAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): DockerImageFetchCompositionAction;

  getImage(): string;
  setImage(value: string): DockerImageFetchCompositionAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DockerImageFetchCompositionAction.AsObject;
  static toObject(includeInstance: boolean, msg: DockerImageFetchCompositionAction): DockerImageFetchCompositionAction.AsObject;
  static serializeBinaryToWriter(message: DockerImageFetchCompositionAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DockerImageFetchCompositionAction;
  static deserializeBinaryFromReader(message: DockerImageFetchCompositionAction, reader: jspb.BinaryReader): DockerImageFetchCompositionAction;
}

export namespace DockerImageFetchCompositionAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotDocker?: string,
    image: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotDockerCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER = 1000,
  }
}

export class DockerImageFetchAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(value: string): DockerImageFetchAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): DockerImageFetchAction;

  getImage(): string;
  setImage(value: string): DockerImageFetchAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DockerImageFetchAction.AsObject;
  static toObject(includeInstance: boolean, msg: DockerImageFetchAction): DockerImageFetchAction.AsObject;
  static serializeBinaryToWriter(message: DockerImageFetchAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DockerImageFetchAction;
  static deserializeBinaryFromReader(message: DockerImageFetchAction, reader: jspb.BinaryReader): DockerImageFetchAction;
}

export namespace DockerImageFetchAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotDocker?: string,
    image: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotDockerCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER = 1000,
  }
}

export class DockerImageRemoveCompositionAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(value: string): DockerImageRemoveCompositionAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): DockerImageRemoveCompositionAction;

  getImage(): string;
  setImage(value: string): DockerImageRemoveCompositionAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DockerImageRemoveCompositionAction.AsObject;
  static toObject(includeInstance: boolean, msg: DockerImageRemoveCompositionAction): DockerImageRemoveCompositionAction.AsObject;
  static serializeBinaryToWriter(message: DockerImageRemoveCompositionAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DockerImageRemoveCompositionAction;
  static deserializeBinaryFromReader(message: DockerImageRemoveCompositionAction, reader: jspb.BinaryReader): DockerImageRemoveCompositionAction;
}

export namespace DockerImageRemoveCompositionAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotDocker?: string,
    image: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotDockerCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER = 1000,
  }
}

export class DockerImageRemoveAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(value: string): DockerImageRemoveAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): DockerImageRemoveAction;

  getImage(): string;
  setImage(value: string): DockerImageRemoveAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DockerImageRemoveAction.AsObject;
  static toObject(includeInstance: boolean, msg: DockerImageRemoveAction): DockerImageRemoveAction.AsObject;
  static serializeBinaryToWriter(message: DockerImageRemoveAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DockerImageRemoveAction;
  static deserializeBinaryFromReader(message: DockerImageRemoveAction, reader: jspb.BinaryReader): DockerImageRemoveAction;
}

export namespace DockerImageRemoveAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotDocker?: string,
    image: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotDockerCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER = 1000,
  }
}

export class DockerImageRunCompositionAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(value: string): DockerImageRunCompositionAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): DockerImageRunCompositionAction;

  getImage(): string;
  setImage(value: string): DockerImageRunCompositionAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DockerImageRunCompositionAction.AsObject;
  static toObject(includeInstance: boolean, msg: DockerImageRunCompositionAction): DockerImageRunCompositionAction.AsObject;
  static serializeBinaryToWriter(message: DockerImageRunCompositionAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DockerImageRunCompositionAction;
  static deserializeBinaryFromReader(message: DockerImageRunCompositionAction, reader: jspb.BinaryReader): DockerImageRunCompositionAction;
}

export namespace DockerImageRunCompositionAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotDocker?: string,
    image: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotDockerCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER = 1000,
  }
}

export class DockerImageRunContainerAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(value: string): DockerImageRunContainerAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): DockerImageRunContainerAction;

  getImage(): string;
  setImage(value: string): DockerImageRunContainerAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DockerImageRunContainerAction.AsObject;
  static toObject(includeInstance: boolean, msg: DockerImageRunContainerAction): DockerImageRunContainerAction.AsObject;
  static serializeBinaryToWriter(message: DockerImageRunContainerAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DockerImageRunContainerAction;
  static deserializeBinaryFromReader(message: DockerImageRunContainerAction, reader: jspb.BinaryReader): DockerImageRunContainerAction;
}

export namespace DockerImageRunContainerAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotDocker?: string,
    image: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotDockerCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER = 1000,
  }
}

export class DockerImageStopCompositionAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(value: string): DockerImageStopCompositionAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): DockerImageStopCompositionAction;

  getImage(): string;
  setImage(value: string): DockerImageStopCompositionAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DockerImageStopCompositionAction.AsObject;
  static toObject(includeInstance: boolean, msg: DockerImageStopCompositionAction): DockerImageStopCompositionAction.AsObject;
  static serializeBinaryToWriter(message: DockerImageStopCompositionAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DockerImageStopCompositionAction;
  static deserializeBinaryFromReader(message: DockerImageStopCompositionAction, reader: jspb.BinaryReader): DockerImageStopCompositionAction;
}

export namespace DockerImageStopCompositionAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotDocker?: string,
    image: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotDockerCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER = 1000,
  }
}

export class DockerImageStopContainerAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(value: string): DockerImageStopContainerAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): DockerImageStopContainerAction;

  getImage(): string;
  setImage(value: string): DockerImageStopContainerAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DockerImageStopContainerAction.AsObject;
  static toObject(includeInstance: boolean, msg: DockerImageStopContainerAction): DockerImageStopContainerAction.AsObject;
  static serializeBinaryToWriter(message: DockerImageStopContainerAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DockerImageStopContainerAction;
  static deserializeBinaryFromReader(message: DockerImageStopContainerAction, reader: jspb.BinaryReader): DockerImageStopContainerAction;
}

export namespace DockerImageStopContainerAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotDocker?: string,
    image: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotDockerCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER = 1000,
  }
}

export class DockerImageReleaseCompositionAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(value: string): DockerImageReleaseCompositionAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): DockerImageReleaseCompositionAction;

  getImage(): string;
  setImage(value: string): DockerImageReleaseCompositionAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DockerImageReleaseCompositionAction.AsObject;
  static toObject(includeInstance: boolean, msg: DockerImageReleaseCompositionAction): DockerImageReleaseCompositionAction.AsObject;
  static serializeBinaryToWriter(message: DockerImageReleaseCompositionAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DockerImageReleaseCompositionAction;
  static deserializeBinaryFromReader(message: DockerImageReleaseCompositionAction, reader: jspb.BinaryReader): DockerImageReleaseCompositionAction;
}

export namespace DockerImageReleaseCompositionAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotDocker?: string,
    image: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotDockerCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER = 1000,
  }
}

export class DockerImageRemoveContainerAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(value: string): DockerImageRemoveContainerAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): DockerImageRemoveContainerAction;

  getImage(): string;
  setImage(value: string): DockerImageRemoveContainerAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DockerImageRemoveContainerAction.AsObject;
  static toObject(includeInstance: boolean, msg: DockerImageRemoveContainerAction): DockerImageRemoveContainerAction.AsObject;
  static serializeBinaryToWriter(message: DockerImageRemoveContainerAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DockerImageRemoveContainerAction;
  static deserializeBinaryFromReader(message: DockerImageRemoveContainerAction, reader: jspb.BinaryReader): DockerImageRemoveContainerAction;
}

export namespace DockerImageRemoveContainerAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotDocker?: string,
    image: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotDockerCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER = 1000,
  }
}

export class DockerEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(value: string): DockerEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): DockerEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DockerEvent.AsObject;
  static toObject(includeInstance: boolean, msg: DockerEvent): DockerEvent.AsObject;
  static serializeBinaryToWriter(message: DockerEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DockerEvent;
  static deserializeBinaryFromReader(message: DockerEvent, reader: jspb.BinaryReader): DockerEvent;
}

export namespace DockerEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotDocker?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotDockerCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER = 1000,
  }
}

export class DockerInstallEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(value: string): DockerInstallEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): DockerInstallEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DockerInstallEvent.AsObject;
  static toObject(includeInstance: boolean, msg: DockerInstallEvent): DockerInstallEvent.AsObject;
  static serializeBinaryToWriter(message: DockerInstallEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DockerInstallEvent;
  static deserializeBinaryFromReader(message: DockerInstallEvent, reader: jspb.BinaryReader): DockerInstallEvent;
}

export namespace DockerInstallEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotDocker?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotDockerCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER = 1000,
  }
}

export class DockerStartEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(value: string): DockerStartEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): DockerStartEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DockerStartEvent.AsObject;
  static toObject(includeInstance: boolean, msg: DockerStartEvent): DockerStartEvent.AsObject;
  static serializeBinaryToWriter(message: DockerStartEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DockerStartEvent;
  static deserializeBinaryFromReader(message: DockerStartEvent, reader: jspb.BinaryReader): DockerStartEvent;
}

export namespace DockerStartEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotDocker?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotDockerCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER = 1000,
  }
}

export class DockerStopEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(value: string): DockerStopEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): DockerStopEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DockerStopEvent.AsObject;
  static toObject(includeInstance: boolean, msg: DockerStopEvent): DockerStopEvent.AsObject;
  static serializeBinaryToWriter(message: DockerStopEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DockerStopEvent;
  static deserializeBinaryFromReader(message: DockerStopEvent, reader: jspb.BinaryReader): DockerStopEvent;
}

export namespace DockerStopEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotDocker?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotDockerCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER = 1000,
  }
}

export class DockerServiceState extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(value: string): DockerServiceState;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): DockerServiceState;

  getStatus(): DockerStatus;
  setStatus(value: DockerStatus): DockerServiceState;
  hasStatus(): boolean;
  clearStatus(): DockerServiceState;

  getUsernames(): DockerServiceState.UsernamesDict | undefined;
  setUsernames(value?: DockerServiceState.UsernamesDict): DockerServiceState;
  hasUsernames(): boolean;
  clearUsernames(): DockerServiceState;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DockerServiceState.AsObject;
  static toObject(includeInstance: boolean, msg: DockerServiceState): DockerServiceState.AsObject;
  static serializeBinaryToWriter(message: DockerServiceState, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DockerServiceState;
  static deserializeBinaryFromReader(message: DockerServiceState, reader: jspb.BinaryReader): DockerServiceState;
}

export namespace DockerServiceState {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotDocker?: string,
    status?: DockerStatus,
    usernames?: DockerServiceState.UsernamesDict.AsObject,
  }

  export class UsernamesDict extends jspb.Message {
    getItemsMap(): jspb.Map<string, string>;
    clearItemsMap(): UsernamesDict;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): UsernamesDict.AsObject;
    static toObject(includeInstance: boolean, msg: UsernamesDict): UsernamesDict.AsObject;
    static serializeBinaryToWriter(message: UsernamesDict, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): UsernamesDict;
    static deserializeBinaryFromReader(message: UsernamesDict, reader: jspb.BinaryReader): UsernamesDict;
  }

  export namespace UsernamesDict {
    export type AsObject = {
      itemsMap: Array<[string, string]>,
    }
  }


  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotDockerCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER = 1000,
  }

  export enum StatusCase { 
    _STATUS_NOT_SET = 0,
    STATUS = 2,
  }

  export enum UsernamesCase { 
    _USERNAMES_NOT_SET = 0,
    USERNAMES = 3,
  }
}

export class DockerImageEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(value: string): DockerImageEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): DockerImageEvent;

  getImage(): string;
  setImage(value: string): DockerImageEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DockerImageEvent.AsObject;
  static toObject(includeInstance: boolean, msg: DockerImageEvent): DockerImageEvent.AsObject;
  static serializeBinaryToWriter(message: DockerImageEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DockerImageEvent;
  static deserializeBinaryFromReader(message: DockerImageEvent, reader: jspb.BinaryReader): DockerImageEvent;
}

export namespace DockerImageEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotDocker?: string,
    image: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotDockerCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER = 1000,
  }
}

export class DockerImageRegisterAppEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(value: string): DockerImageRegisterAppEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): DockerImageRegisterAppEvent;

  getImage(): string;
  setImage(value: string): DockerImageRegisterAppEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DockerImageRegisterAppEvent.AsObject;
  static toObject(includeInstance: boolean, msg: DockerImageRegisterAppEvent): DockerImageRegisterAppEvent.AsObject;
  static serializeBinaryToWriter(message: DockerImageRegisterAppEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DockerImageRegisterAppEvent;
  static deserializeBinaryFromReader(message: DockerImageRegisterAppEvent, reader: jspb.BinaryReader): DockerImageRegisterAppEvent;
}

export namespace DockerImageRegisterAppEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotDocker?: string,
    image: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotDockerCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER = 1000,
  }
}

export class DockerImageFetchCompositionEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(value: string): DockerImageFetchCompositionEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): DockerImageFetchCompositionEvent;

  getImage(): string;
  setImage(value: string): DockerImageFetchCompositionEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DockerImageFetchCompositionEvent.AsObject;
  static toObject(includeInstance: boolean, msg: DockerImageFetchCompositionEvent): DockerImageFetchCompositionEvent.AsObject;
  static serializeBinaryToWriter(message: DockerImageFetchCompositionEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DockerImageFetchCompositionEvent;
  static deserializeBinaryFromReader(message: DockerImageFetchCompositionEvent, reader: jspb.BinaryReader): DockerImageFetchCompositionEvent;
}

export namespace DockerImageFetchCompositionEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotDocker?: string,
    image: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotDockerCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER = 1000,
  }
}

export class DockerImageFetchEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(value: string): DockerImageFetchEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): DockerImageFetchEvent;

  getImage(): string;
  setImage(value: string): DockerImageFetchEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DockerImageFetchEvent.AsObject;
  static toObject(includeInstance: boolean, msg: DockerImageFetchEvent): DockerImageFetchEvent.AsObject;
  static serializeBinaryToWriter(message: DockerImageFetchEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DockerImageFetchEvent;
  static deserializeBinaryFromReader(message: DockerImageFetchEvent, reader: jspb.BinaryReader): DockerImageFetchEvent;
}

export namespace DockerImageFetchEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotDocker?: string,
    image: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotDockerCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER = 1000,
  }
}

export class DockerImageRemoveCompositionEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(value: string): DockerImageRemoveCompositionEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): DockerImageRemoveCompositionEvent;

  getImage(): string;
  setImage(value: string): DockerImageRemoveCompositionEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DockerImageRemoveCompositionEvent.AsObject;
  static toObject(includeInstance: boolean, msg: DockerImageRemoveCompositionEvent): DockerImageRemoveCompositionEvent.AsObject;
  static serializeBinaryToWriter(message: DockerImageRemoveCompositionEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DockerImageRemoveCompositionEvent;
  static deserializeBinaryFromReader(message: DockerImageRemoveCompositionEvent, reader: jspb.BinaryReader): DockerImageRemoveCompositionEvent;
}

export namespace DockerImageRemoveCompositionEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotDocker?: string,
    image: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotDockerCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER = 1000,
  }
}

export class DockerImageRemoveEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(value: string): DockerImageRemoveEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): DockerImageRemoveEvent;

  getImage(): string;
  setImage(value: string): DockerImageRemoveEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DockerImageRemoveEvent.AsObject;
  static toObject(includeInstance: boolean, msg: DockerImageRemoveEvent): DockerImageRemoveEvent.AsObject;
  static serializeBinaryToWriter(message: DockerImageRemoveEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DockerImageRemoveEvent;
  static deserializeBinaryFromReader(message: DockerImageRemoveEvent, reader: jspb.BinaryReader): DockerImageRemoveEvent;
}

export namespace DockerImageRemoveEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotDocker?: string,
    image: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotDockerCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER = 1000,
  }
}

export class DockerImageRunCompositionEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(value: string): DockerImageRunCompositionEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): DockerImageRunCompositionEvent;

  getImage(): string;
  setImage(value: string): DockerImageRunCompositionEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DockerImageRunCompositionEvent.AsObject;
  static toObject(includeInstance: boolean, msg: DockerImageRunCompositionEvent): DockerImageRunCompositionEvent.AsObject;
  static serializeBinaryToWriter(message: DockerImageRunCompositionEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DockerImageRunCompositionEvent;
  static deserializeBinaryFromReader(message: DockerImageRunCompositionEvent, reader: jspb.BinaryReader): DockerImageRunCompositionEvent;
}

export namespace DockerImageRunCompositionEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotDocker?: string,
    image: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotDockerCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER = 1000,
  }
}

export class DockerImageRunContainerEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(value: string): DockerImageRunContainerEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): DockerImageRunContainerEvent;

  getImage(): string;
  setImage(value: string): DockerImageRunContainerEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DockerImageRunContainerEvent.AsObject;
  static toObject(includeInstance: boolean, msg: DockerImageRunContainerEvent): DockerImageRunContainerEvent.AsObject;
  static serializeBinaryToWriter(message: DockerImageRunContainerEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DockerImageRunContainerEvent;
  static deserializeBinaryFromReader(message: DockerImageRunContainerEvent, reader: jspb.BinaryReader): DockerImageRunContainerEvent;
}

export namespace DockerImageRunContainerEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotDocker?: string,
    image: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotDockerCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER = 1000,
  }
}

export class DockerImageStopCompositionEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(value: string): DockerImageStopCompositionEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): DockerImageStopCompositionEvent;

  getImage(): string;
  setImage(value: string): DockerImageStopCompositionEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DockerImageStopCompositionEvent.AsObject;
  static toObject(includeInstance: boolean, msg: DockerImageStopCompositionEvent): DockerImageStopCompositionEvent.AsObject;
  static serializeBinaryToWriter(message: DockerImageStopCompositionEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DockerImageStopCompositionEvent;
  static deserializeBinaryFromReader(message: DockerImageStopCompositionEvent, reader: jspb.BinaryReader): DockerImageStopCompositionEvent;
}

export namespace DockerImageStopCompositionEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotDocker?: string,
    image: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotDockerCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER = 1000,
  }
}

export class DockerImageStopContainerEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(value: string): DockerImageStopContainerEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): DockerImageStopContainerEvent;

  getImage(): string;
  setImage(value: string): DockerImageStopContainerEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DockerImageStopContainerEvent.AsObject;
  static toObject(includeInstance: boolean, msg: DockerImageStopContainerEvent): DockerImageStopContainerEvent.AsObject;
  static serializeBinaryToWriter(message: DockerImageStopContainerEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DockerImageStopContainerEvent;
  static deserializeBinaryFromReader(message: DockerImageStopContainerEvent, reader: jspb.BinaryReader): DockerImageStopContainerEvent;
}

export namespace DockerImageStopContainerEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotDocker?: string,
    image: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotDockerCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER = 1000,
  }
}

export class DockerImageReleaseCompositionEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(value: string): DockerImageReleaseCompositionEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): DockerImageReleaseCompositionEvent;

  getImage(): string;
  setImage(value: string): DockerImageReleaseCompositionEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DockerImageReleaseCompositionEvent.AsObject;
  static toObject(includeInstance: boolean, msg: DockerImageReleaseCompositionEvent): DockerImageReleaseCompositionEvent.AsObject;
  static serializeBinaryToWriter(message: DockerImageReleaseCompositionEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DockerImageReleaseCompositionEvent;
  static deserializeBinaryFromReader(message: DockerImageReleaseCompositionEvent, reader: jspb.BinaryReader): DockerImageReleaseCompositionEvent;
}

export namespace DockerImageReleaseCompositionEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotDocker?: string,
    image: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotDockerCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER = 1000,
  }
}

export class DockerImageRemoveContainerEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(value: string): DockerImageRemoveContainerEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): DockerImageRemoveContainerEvent;

  getImage(): string;
  setImage(value: string): DockerImageRemoveContainerEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DockerImageRemoveContainerEvent.AsObject;
  static toObject(includeInstance: boolean, msg: DockerImageRemoveContainerEvent): DockerImageRemoveContainerEvent.AsObject;
  static serializeBinaryToWriter(message: DockerImageRemoveContainerEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DockerImageRemoveContainerEvent;
  static deserializeBinaryFromReader(message: DockerImageRemoveContainerEvent, reader: jspb.BinaryReader): DockerImageRemoveContainerEvent;
}

export namespace DockerImageRemoveContainerEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotDocker?: string,
    image: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotDockerCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER = 1000,
  }
}

export class ImageState extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(value: string): ImageState;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): ImageState;

  getId(): string;
  setId(value: string): ImageState;

  getLabel(): string;
  setLabel(value: string): ImageState;

  getInstructions(): string;
  setInstructions(value: string): ImageState;
  hasInstructions(): boolean;
  clearInstructions(): ImageState;

  getStatus(): DockerItemStatus;
  setStatus(value: DockerItemStatus): ImageState;
  hasStatus(): boolean;
  clearStatus(): ImageState;

  getContainerIp(): string;
  setContainerIp(value: string): ImageState;
  hasContainerIp(): boolean;
  clearContainerIp(): ImageState;

  getDockerId(): string;
  setDockerId(value: string): ImageState;
  hasDockerId(): boolean;
  clearDockerId(): ImageState;

  getPorts(): ImageState.Ports | undefined;
  setPorts(value?: ImageState.Ports): ImageState;
  hasPorts(): boolean;
  clearPorts(): ImageState;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ImageState.AsObject;
  static toObject(includeInstance: boolean, msg: ImageState): ImageState.AsObject;
  static serializeBinaryToWriter(message: ImageState, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ImageState;
  static deserializeBinaryFromReader(message: ImageState, reader: jspb.BinaryReader): ImageState;
}

export namespace ImageState {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotDocker?: string,
    id: string,
    label: string,
    instructions?: string,
    status?: DockerItemStatus,
    containerIp?: string,
    dockerId?: string,
    ports?: ImageState.Ports.AsObject,
  }

  export class Ports extends jspb.Message {
    getItemsList(): Array<string>;
    setItemsList(value: Array<string>): Ports;
    clearItemsList(): Ports;
    addItems(value: string, index?: number): Ports;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): Ports.AsObject;
    static toObject(includeInstance: boolean, msg: Ports): Ports.AsObject;
    static serializeBinaryToWriter(message: Ports, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): Ports;
    static deserializeBinaryFromReader(message: Ports, reader: jspb.BinaryReader): Ports;
  }

  export namespace Ports {
    export type AsObject = {
      itemsList: Array<string>,
    }
  }


  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotDockerCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER = 1000,
  }

  export enum InstructionsCase { 
    _INSTRUCTIONS_NOT_SET = 0,
    INSTRUCTIONS = 4,
  }

  export enum StatusCase { 
    _STATUS_NOT_SET = 0,
    STATUS = 5,
  }

  export enum ContainerIpCase { 
    _CONTAINER_IP_NOT_SET = 0,
    CONTAINER_IP = 6,
  }

  export enum DockerIdCase { 
    _DOCKER_ID_NOT_SET = 0,
    DOCKER_ID = 7,
  }

  export enum PortsCase { 
    _PORTS_NOT_SET = 0,
    PORTS = 8,
  }
}

export class DockerState extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(value: string): DockerState;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotDocker(): DockerState;

  getService(): DockerServiceState | undefined;
  setService(value?: DockerServiceState): DockerState;
  hasService(): boolean;
  clearService(): DockerState;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): DockerState.AsObject;
  static toObject(includeInstance: boolean, msg: DockerState): DockerState.AsObject;
  static serializeBinaryToWriter(message: DockerState, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): DockerState;
  static deserializeBinaryFromReader(message: DockerState, reader: jspb.BinaryReader): DockerState;
}

export namespace DockerState {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotDocker?: string,
    service?: DockerServiceState.AsObject,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotDockerCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER = 1000,
  }
}

export class PathSelectorConfig extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotFileSystem(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotFileSystem(value: string): PathSelectorConfig;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotFileSystem(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotFileSystem(): PathSelectorConfig;

  getInitialPath(): string;
  setInitialPath(value: string): PathSelectorConfig;
  hasInitialPath(): boolean;
  clearInitialPath(): PathSelectorConfig;

  getShowHidden(): boolean;
  setShowHidden(value: boolean): PathSelectorConfig;
  hasShowHidden(): boolean;
  clearShowHidden(): PathSelectorConfig;

  getAcceptsFiles(): boolean;
  setAcceptsFiles(value: boolean): PathSelectorConfig;
  hasAcceptsFiles(): boolean;
  clearAcceptsFiles(): PathSelectorConfig;

  getAcceptsDirectories(): boolean;
  setAcceptsDirectories(value: boolean): PathSelectorConfig;
  hasAcceptsDirectories(): boolean;
  clearAcceptsDirectories(): PathSelectorConfig;

  getAcceptableSuffixes(): PathSelectorConfig.AcceptableSuffixes | undefined;
  setAcceptableSuffixes(value?: PathSelectorConfig.AcceptableSuffixes): PathSelectorConfig;
  hasAcceptableSuffixes(): boolean;
  clearAcceptableSuffixes(): PathSelectorConfig;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): PathSelectorConfig.AsObject;
  static toObject(includeInstance: boolean, msg: PathSelectorConfig): PathSelectorConfig.AsObject;
  static serializeBinaryToWriter(message: PathSelectorConfig, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): PathSelectorConfig;
  static deserializeBinaryFromReader(message: PathSelectorConfig, reader: jspb.BinaryReader): PathSelectorConfig;
}

export namespace PathSelectorConfig {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotFileSystem?: string,
    initialPath?: string,
    showHidden?: boolean,
    acceptsFiles?: boolean,
    acceptsDirectories?: boolean,
    acceptableSuffixes?: PathSelectorConfig.AcceptableSuffixes.AsObject,
  }

  export class AcceptableSuffixes extends jspb.Message {
    getItemsList(): Array<string>;
    setItemsList(value: Array<string>): AcceptableSuffixes;
    clearItemsList(): AcceptableSuffixes;
    addItems(value: string, index?: number): AcceptableSuffixes;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): AcceptableSuffixes.AsObject;
    static toObject(includeInstance: boolean, msg: AcceptableSuffixes): AcceptableSuffixes.AsObject;
    static serializeBinaryToWriter(message: AcceptableSuffixes, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): AcceptableSuffixes;
    static deserializeBinaryFromReader(message: AcceptableSuffixes, reader: jspb.BinaryReader): AcceptableSuffixes;
  }

  export namespace AcceptableSuffixes {
    export type AsObject = {
      itemsList: Array<string>,
    }
  }


  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotFileSystemCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_FILE_SYSTEM_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_FILE_SYSTEM = 1000,
  }

  export enum InitialPathCase { 
    _INITIAL_PATH_NOT_SET = 0,
    INITIAL_PATH = 2,
  }

  export enum ShowHiddenCase { 
    _SHOW_HIDDEN_NOT_SET = 0,
    SHOW_HIDDEN = 3,
  }

  export enum AcceptsFilesCase { 
    _ACCEPTS_FILES_NOT_SET = 0,
    ACCEPTS_FILES = 4,
  }

  export enum AcceptsDirectoriesCase { 
    _ACCEPTS_DIRECTORIES_NOT_SET = 0,
    ACCEPTS_DIRECTORIES = 5,
  }

  export enum AcceptableSuffixesCase { 
    _ACCEPTABLE_SUFFIXES_NOT_SET = 0,
    ACCEPTABLE_SUFFIXES = 6,
  }
}

export class FileSystemAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotFileSystem(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotFileSystem(value: string): FileSystemAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotFileSystem(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotFileSystem(): FileSystemAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): FileSystemAction.AsObject;
  static toObject(includeInstance: boolean, msg: FileSystemAction): FileSystemAction.AsObject;
  static serializeBinaryToWriter(message: FileSystemAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): FileSystemAction;
  static deserializeBinaryFromReader(message: FileSystemAction, reader: jspb.BinaryReader): FileSystemAction;
}

export namespace FileSystemAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotFileSystem?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotFileSystemCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_FILE_SYSTEM_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_FILE_SYSTEM = 1000,
  }
}

export class FileSystemReportSelectionAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotFileSystem(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotFileSystem(value: string): FileSystemReportSelectionAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotFileSystem(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotFileSystem(): FileSystemReportSelectionAction;

  getPath(): string;
  setPath(value: string): FileSystemReportSelectionAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): FileSystemReportSelectionAction.AsObject;
  static toObject(includeInstance: boolean, msg: FileSystemReportSelectionAction): FileSystemReportSelectionAction.AsObject;
  static serializeBinaryToWriter(message: FileSystemReportSelectionAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): FileSystemReportSelectionAction;
  static deserializeBinaryFromReader(message: FileSystemReportSelectionAction, reader: jspb.BinaryReader): FileSystemReportSelectionAction;
}

export namespace FileSystemReportSelectionAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotFileSystem?: string,
    path: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotFileSystemCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_FILE_SYSTEM_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_FILE_SYSTEM = 1000,
  }
}

export class FileSystemCopyAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotFileSystem(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotFileSystem(value: string): FileSystemCopyAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotFileSystem(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotFileSystem(): FileSystemCopyAction;

  getSourcesList(): Array<string>;
  setSourcesList(value: Array<string>): FileSystemCopyAction;
  clearSourcesList(): FileSystemCopyAction;
  addSources(value: string, index?: number): FileSystemCopyAction;

  getDestination(): string;
  setDestination(value: string): FileSystemCopyAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): FileSystemCopyAction.AsObject;
  static toObject(includeInstance: boolean, msg: FileSystemCopyAction): FileSystemCopyAction.AsObject;
  static serializeBinaryToWriter(message: FileSystemCopyAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): FileSystemCopyAction;
  static deserializeBinaryFromReader(message: FileSystemCopyAction, reader: jspb.BinaryReader): FileSystemCopyAction;
}

export namespace FileSystemCopyAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotFileSystem?: string,
    sourcesList: Array<string>,
    destination: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotFileSystemCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_FILE_SYSTEM_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_FILE_SYSTEM = 1000,
  }
}

export class FileSystemMoveAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotFileSystem(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotFileSystem(value: string): FileSystemMoveAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotFileSystem(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotFileSystem(): FileSystemMoveAction;

  getSourcesList(): Array<string>;
  setSourcesList(value: Array<string>): FileSystemMoveAction;
  clearSourcesList(): FileSystemMoveAction;
  addSources(value: string, index?: number): FileSystemMoveAction;

  getDestination(): string;
  setDestination(value: string): FileSystemMoveAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): FileSystemMoveAction.AsObject;
  static toObject(includeInstance: boolean, msg: FileSystemMoveAction): FileSystemMoveAction.AsObject;
  static serializeBinaryToWriter(message: FileSystemMoveAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): FileSystemMoveAction;
  static deserializeBinaryFromReader(message: FileSystemMoveAction, reader: jspb.BinaryReader): FileSystemMoveAction;
}

export namespace FileSystemMoveAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotFileSystem?: string,
    sourcesList: Array<string>,
    destination: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotFileSystemCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_FILE_SYSTEM_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_FILE_SYSTEM = 1000,
  }
}

export class FileSystemRemoveAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotFileSystem(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotFileSystem(value: string): FileSystemRemoveAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotFileSystem(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotFileSystem(): FileSystemRemoveAction;

  getPathsList(): Array<string>;
  setPathsList(value: Array<string>): FileSystemRemoveAction;
  clearPathsList(): FileSystemRemoveAction;
  addPaths(value: string, index?: number): FileSystemRemoveAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): FileSystemRemoveAction.AsObject;
  static toObject(includeInstance: boolean, msg: FileSystemRemoveAction): FileSystemRemoveAction.AsObject;
  static serializeBinaryToWriter(message: FileSystemRemoveAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): FileSystemRemoveAction;
  static deserializeBinaryFromReader(message: FileSystemRemoveAction, reader: jspb.BinaryReader): FileSystemRemoveAction;
}

export namespace FileSystemRemoveAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotFileSystem?: string,
    pathsList: Array<string>,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotFileSystemCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_FILE_SYSTEM_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_FILE_SYSTEM = 1000,
  }
}

export class FileSystemEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotFileSystem(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotFileSystem(value: string): FileSystemEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotFileSystem(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotFileSystem(): FileSystemEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): FileSystemEvent.AsObject;
  static toObject(includeInstance: boolean, msg: FileSystemEvent): FileSystemEvent.AsObject;
  static serializeBinaryToWriter(message: FileSystemEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): FileSystemEvent;
  static deserializeBinaryFromReader(message: FileSystemEvent, reader: jspb.BinaryReader): FileSystemEvent;
}

export namespace FileSystemEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotFileSystem?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotFileSystemCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_FILE_SYSTEM_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_FILE_SYSTEM = 1000,
  }
}

export class FileSystemSelectEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotFileSystem(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotFileSystem(value: string): FileSystemSelectEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotFileSystem(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotFileSystem(): FileSystemSelectEvent;

  getDescription(): PathInputDescription | undefined;
  setDescription(value?: PathInputDescription): FileSystemSelectEvent;
  hasDescription(): boolean;
  clearDescription(): FileSystemSelectEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): FileSystemSelectEvent.AsObject;
  static toObject(includeInstance: boolean, msg: FileSystemSelectEvent): FileSystemSelectEvent.AsObject;
  static serializeBinaryToWriter(message: FileSystemSelectEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): FileSystemSelectEvent;
  static deserializeBinaryFromReader(message: FileSystemSelectEvent, reader: jspb.BinaryReader): FileSystemSelectEvent;
}

export namespace FileSystemSelectEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotFileSystem?: string,
    description?: PathInputDescription.AsObject,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotFileSystemCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_FILE_SYSTEM_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_FILE_SYSTEM = 1000,
  }
}

export class FileSystemCopyEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotFileSystem(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotFileSystem(value: string): FileSystemCopyEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotFileSystem(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotFileSystem(): FileSystemCopyEvent;

  getSourcesList(): Array<string>;
  setSourcesList(value: Array<string>): FileSystemCopyEvent;
  clearSourcesList(): FileSystemCopyEvent;
  addSources(value: string, index?: number): FileSystemCopyEvent;

  getDestination(): string;
  setDestination(value: string): FileSystemCopyEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): FileSystemCopyEvent.AsObject;
  static toObject(includeInstance: boolean, msg: FileSystemCopyEvent): FileSystemCopyEvent.AsObject;
  static serializeBinaryToWriter(message: FileSystemCopyEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): FileSystemCopyEvent;
  static deserializeBinaryFromReader(message: FileSystemCopyEvent, reader: jspb.BinaryReader): FileSystemCopyEvent;
}

export namespace FileSystemCopyEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotFileSystem?: string,
    sourcesList: Array<string>,
    destination: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotFileSystemCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_FILE_SYSTEM_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_FILE_SYSTEM = 1000,
  }
}

export class FileSystemMoveEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotFileSystem(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotFileSystem(value: string): FileSystemMoveEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotFileSystem(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotFileSystem(): FileSystemMoveEvent;

  getSourcesList(): Array<string>;
  setSourcesList(value: Array<string>): FileSystemMoveEvent;
  clearSourcesList(): FileSystemMoveEvent;
  addSources(value: string, index?: number): FileSystemMoveEvent;

  getDestination(): string;
  setDestination(value: string): FileSystemMoveEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): FileSystemMoveEvent.AsObject;
  static toObject(includeInstance: boolean, msg: FileSystemMoveEvent): FileSystemMoveEvent.AsObject;
  static serializeBinaryToWriter(message: FileSystemMoveEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): FileSystemMoveEvent;
  static deserializeBinaryFromReader(message: FileSystemMoveEvent, reader: jspb.BinaryReader): FileSystemMoveEvent;
}

export namespace FileSystemMoveEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotFileSystem?: string,
    sourcesList: Array<string>,
    destination: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotFileSystemCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_FILE_SYSTEM_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_FILE_SYSTEM = 1000,
  }
}

export class FileSystemRemoveEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotFileSystem(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotFileSystem(value: string): FileSystemRemoveEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotFileSystem(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotFileSystem(): FileSystemRemoveEvent;

  getPathsList(): Array<string>;
  setPathsList(value: Array<string>): FileSystemRemoveEvent;
  clearPathsList(): FileSystemRemoveEvent;
  addPaths(value: string, index?: number): FileSystemRemoveEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): FileSystemRemoveEvent.AsObject;
  static toObject(includeInstance: boolean, msg: FileSystemRemoveEvent): FileSystemRemoveEvent.AsObject;
  static serializeBinaryToWriter(message: FileSystemRemoveEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): FileSystemRemoveEvent;
  static deserializeBinaryFromReader(message: FileSystemRemoveEvent, reader: jspb.BinaryReader): FileSystemRemoveEvent;
}

export namespace FileSystemRemoveEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotFileSystem?: string,
    pathsList: Array<string>,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotFileSystemCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_FILE_SYSTEM_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_FILE_SYSTEM = 1000,
  }
}

export class FileSystemState extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotFileSystem(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotFileSystem(value: string): FileSystemState;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotFileSystem(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotFileSystem(): FileSystemState;

  getCurrentInput(): PathInputDescription | undefined;
  setCurrentInput(value?: PathInputDescription): FileSystemState;
  hasCurrentInput(): boolean;
  clearCurrentInput(): FileSystemState;

  getQueueList(): Array<PathInputDescription>;
  setQueueList(value: Array<PathInputDescription>): FileSystemState;
  clearQueueList(): FileSystemState;
  addQueue(value?: PathInputDescription, index?: number): PathInputDescription;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): FileSystemState.AsObject;
  static toObject(includeInstance: boolean, msg: FileSystemState): FileSystemState.AsObject;
  static serializeBinaryToWriter(message: FileSystemState, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): FileSystemState;
  static deserializeBinaryFromReader(message: FileSystemState, reader: jspb.BinaryReader): FileSystemState;
}

export namespace FileSystemState {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotFileSystem?: string,
    currentInput?: PathInputDescription.AsObject,
    queueList: Array<PathInputDescription.AsObject>,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotFileSystemCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_FILE_SYSTEM_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_FILE_SYSTEM = 1000,
  }

  export enum CurrentInputCase { 
    _CURRENT_INPUT_NOT_SET = 0,
    CURRENT_INPUT = 2,
  }
}

export class InfraredAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotInfrared(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotInfrared(value: string): InfraredAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotInfrared(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotInfrared(): InfraredAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): InfraredAction.AsObject;
  static toObject(includeInstance: boolean, msg: InfraredAction): InfraredAction.AsObject;
  static serializeBinaryToWriter(message: InfraredAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): InfraredAction;
  static deserializeBinaryFromReader(message: InfraredAction, reader: jspb.BinaryReader): InfraredAction;
}

export namespace InfraredAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotInfrared?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotInfraredCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_INFRARED_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_INFRARED = 1000,
  }
}

export class InfraredEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotInfrared(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotInfrared(value: string): InfraredEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotInfrared(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotInfrared(): InfraredEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): InfraredEvent.AsObject;
  static toObject(includeInstance: boolean, msg: InfraredEvent): InfraredEvent.AsObject;
  static serializeBinaryToWriter(message: InfraredEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): InfraredEvent;
  static deserializeBinaryFromReader(message: InfraredEvent, reader: jspb.BinaryReader): InfraredEvent;
}

export namespace InfraredEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotInfrared?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotInfraredCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_INFRARED_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_INFRARED = 1000,
  }
}

export class InfraredHandleReceivedCodeAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotInfrared(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotInfrared(value: string): InfraredHandleReceivedCodeAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotInfrared(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotInfrared(): InfraredHandleReceivedCodeAction;

  getProtocol(): string;
  setProtocol(value: string): InfraredHandleReceivedCodeAction;

  getScancode(): string;
  setScancode(value: string): InfraredHandleReceivedCodeAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): InfraredHandleReceivedCodeAction.AsObject;
  static toObject(includeInstance: boolean, msg: InfraredHandleReceivedCodeAction): InfraredHandleReceivedCodeAction.AsObject;
  static serializeBinaryToWriter(message: InfraredHandleReceivedCodeAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): InfraredHandleReceivedCodeAction;
  static deserializeBinaryFromReader(message: InfraredHandleReceivedCodeAction, reader: jspb.BinaryReader): InfraredHandleReceivedCodeAction;
}

export namespace InfraredHandleReceivedCodeAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotInfrared?: string,
    protocol: string,
    scancode: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotInfraredCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_INFRARED_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_INFRARED = 1000,
  }
}

export class InfraredSendCodeAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotInfrared(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotInfrared(value: string): InfraredSendCodeAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotInfrared(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotInfrared(): InfraredSendCodeAction;

  getProtocol(): string;
  setProtocol(value: string): InfraredSendCodeAction;

  getScancode(): string;
  setScancode(value: string): InfraredSendCodeAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): InfraredSendCodeAction.AsObject;
  static toObject(includeInstance: boolean, msg: InfraredSendCodeAction): InfraredSendCodeAction.AsObject;
  static serializeBinaryToWriter(message: InfraredSendCodeAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): InfraredSendCodeAction;
  static deserializeBinaryFromReader(message: InfraredSendCodeAction, reader: jspb.BinaryReader): InfraredSendCodeAction;
}

export namespace InfraredSendCodeAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotInfrared?: string,
    protocol: string,
    scancode: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotInfraredCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_INFRARED_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_INFRARED = 1000,
  }
}

export class InfraredSetShouldPropagateAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotInfrared(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotInfrared(value: string): InfraredSetShouldPropagateAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotInfrared(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotInfrared(): InfraredSetShouldPropagateAction;

  getShouldPropagate(): boolean;
  setShouldPropagate(value: boolean): InfraredSetShouldPropagateAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): InfraredSetShouldPropagateAction.AsObject;
  static toObject(includeInstance: boolean, msg: InfraredSetShouldPropagateAction): InfraredSetShouldPropagateAction.AsObject;
  static serializeBinaryToWriter(message: InfraredSetShouldPropagateAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): InfraredSetShouldPropagateAction;
  static deserializeBinaryFromReader(message: InfraredSetShouldPropagateAction, reader: jspb.BinaryReader): InfraredSetShouldPropagateAction;
}

export namespace InfraredSetShouldPropagateAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotInfrared?: string,
    shouldPropagate: boolean,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotInfraredCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_INFRARED_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_INFRARED = 1000,
  }
}

export class InfraredSetShouldReceiveAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotInfrared(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotInfrared(value: string): InfraredSetShouldReceiveAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotInfrared(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotInfrared(): InfraredSetShouldReceiveAction;

  getShouldReceive(): boolean;
  setShouldReceive(value: boolean): InfraredSetShouldReceiveAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): InfraredSetShouldReceiveAction.AsObject;
  static toObject(includeInstance: boolean, msg: InfraredSetShouldReceiveAction): InfraredSetShouldReceiveAction.AsObject;
  static serializeBinaryToWriter(message: InfraredSetShouldReceiveAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): InfraredSetShouldReceiveAction;
  static deserializeBinaryFromReader(message: InfraredSetShouldReceiveAction, reader: jspb.BinaryReader): InfraredSetShouldReceiveAction;
}

export namespace InfraredSetShouldReceiveAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotInfrared?: string,
    shouldReceive: boolean,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotInfraredCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_INFRARED_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_INFRARED = 1000,
  }
}

export class InfraredSendCodeEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotInfrared(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotInfrared(value: string): InfraredSendCodeEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotInfrared(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotInfrared(): InfraredSendCodeEvent;

  getProtocol(): string;
  setProtocol(value: string): InfraredSendCodeEvent;

  getScancode(): string;
  setScancode(value: string): InfraredSendCodeEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): InfraredSendCodeEvent.AsObject;
  static toObject(includeInstance: boolean, msg: InfraredSendCodeEvent): InfraredSendCodeEvent.AsObject;
  static serializeBinaryToWriter(message: InfraredSendCodeEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): InfraredSendCodeEvent;
  static deserializeBinaryFromReader(message: InfraredSendCodeEvent, reader: jspb.BinaryReader): InfraredSendCodeEvent;
}

export namespace InfraredSendCodeEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotInfrared?: string,
    protocol: string,
    scancode: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotInfraredCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_INFRARED_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_INFRARED = 1000,
  }
}

export class InfraredState extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotInfrared(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotInfrared(value: string): InfraredState;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotInfrared(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotInfrared(): InfraredState;

  getShouldPropagateKeypadActions(): boolean;
  setShouldPropagateKeypadActions(value: boolean): InfraredState;
  hasShouldPropagateKeypadActions(): boolean;
  clearShouldPropagateKeypadActions(): InfraredState;

  getShouldReceiveKeypadActions(): boolean;
  setShouldReceiveKeypadActions(value: boolean): InfraredState;
  hasShouldReceiveKeypadActions(): boolean;
  clearShouldReceiveKeypadActions(): InfraredState;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): InfraredState.AsObject;
  static toObject(includeInstance: boolean, msg: InfraredState): InfraredState.AsObject;
  static serializeBinaryToWriter(message: InfraredState, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): InfraredState;
  static deserializeBinaryFromReader(message: InfraredState, reader: jspb.BinaryReader): InfraredState;
}

export namespace InfraredState {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotInfrared?: string,
    shouldPropagateKeypadActions?: boolean,
    shouldReceiveKeypadActions?: boolean,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotInfraredCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_INFRARED_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_INFRARED = 1000,
  }

  export enum ShouldPropagateKeypadActionsCase { 
    _SHOULD_PROPAGATE_KEYPAD_ACTIONS_NOT_SET = 0,
    SHOULD_PROPAGATE_KEYPAD_ACTIONS = 2,
  }

  export enum ShouldReceiveKeypadActionsCase { 
    _SHOULD_RECEIVE_KEYPAD_ACTIONS_NOT_SET = 0,
    SHOULD_RECEIVE_KEYPAD_ACTIONS = 3,
  }
}

export class IpAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotIp(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotIp(value: string): IpAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotIp(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotIp(): IpAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): IpAction.AsObject;
  static toObject(includeInstance: boolean, msg: IpAction): IpAction.AsObject;
  static serializeBinaryToWriter(message: IpAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): IpAction;
  static deserializeBinaryFromReader(message: IpAction, reader: jspb.BinaryReader): IpAction;
}

export namespace IpAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotIp?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotIpCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_IP_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_IP = 1000,
  }
}

export class IpEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotIp(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotIp(value: string): IpEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotIp(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotIp(): IpEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): IpEvent.AsObject;
  static toObject(includeInstance: boolean, msg: IpEvent): IpEvent.AsObject;
  static serializeBinaryToWriter(message: IpEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): IpEvent;
  static deserializeBinaryFromReader(message: IpEvent, reader: jspb.BinaryReader): IpEvent;
}

export namespace IpEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotIp?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotIpCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_IP_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_IP = 1000,
  }
}

export class IpUpdateInterfacesAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotIp(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotIp(value: string): IpUpdateInterfacesAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotIp(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotIp(): IpUpdateInterfacesAction;

  getInterfacesList(): Array<IpNetworkInterface>;
  setInterfacesList(value: Array<IpNetworkInterface>): IpUpdateInterfacesAction;
  clearInterfacesList(): IpUpdateInterfacesAction;
  addInterfaces(value?: IpNetworkInterface, index?: number): IpNetworkInterface;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): IpUpdateInterfacesAction.AsObject;
  static toObject(includeInstance: boolean, msg: IpUpdateInterfacesAction): IpUpdateInterfacesAction.AsObject;
  static serializeBinaryToWriter(message: IpUpdateInterfacesAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): IpUpdateInterfacesAction;
  static deserializeBinaryFromReader(message: IpUpdateInterfacesAction, reader: jspb.BinaryReader): IpUpdateInterfacesAction;
}

export namespace IpUpdateInterfacesAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotIp?: string,
    interfacesList: Array<IpNetworkInterface.AsObject>,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotIpCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_IP_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_IP = 1000,
  }
}

export class IpSetIsConnectedAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotIp(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotIp(value: string): IpSetIsConnectedAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotIp(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotIp(): IpSetIsConnectedAction;

  getIsConnected(): boolean;
  setIsConnected(value: boolean): IpSetIsConnectedAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): IpSetIsConnectedAction.AsObject;
  static toObject(includeInstance: boolean, msg: IpSetIsConnectedAction): IpSetIsConnectedAction.AsObject;
  static serializeBinaryToWriter(message: IpSetIsConnectedAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): IpSetIsConnectedAction;
  static deserializeBinaryFromReader(message: IpSetIsConnectedAction, reader: jspb.BinaryReader): IpSetIsConnectedAction;
}

export namespace IpSetIsConnectedAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotIp?: string,
    isConnected: boolean,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotIpCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_IP_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_IP = 1000,
  }
}

export class IpNetworkInterface extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotIp(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotIp(value: string): IpNetworkInterface;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotIp(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotIp(): IpNetworkInterface;

  getName(): string;
  setName(value: string): IpNetworkInterface;

  getIpAddressesList(): Array<string>;
  setIpAddressesList(value: Array<string>): IpNetworkInterface;
  clearIpAddressesList(): IpNetworkInterface;
  addIpAddresses(value: string, index?: number): IpNetworkInterface;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): IpNetworkInterface.AsObject;
  static toObject(includeInstance: boolean, msg: IpNetworkInterface): IpNetworkInterface.AsObject;
  static serializeBinaryToWriter(message: IpNetworkInterface, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): IpNetworkInterface;
  static deserializeBinaryFromReader(message: IpNetworkInterface, reader: jspb.BinaryReader): IpNetworkInterface;
}

export namespace IpNetworkInterface {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotIp?: string,
    name: string,
    ipAddressesList: Array<string>,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotIpCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_IP_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_IP = 1000,
  }
}

export class IpState extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotIp(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotIp(value: string): IpState;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotIp(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotIp(): IpState;

  getInterfacesList(): Array<IpNetworkInterface>;
  setInterfacesList(value: Array<IpNetworkInterface>): IpState;
  clearInterfacesList(): IpState;
  addInterfaces(value?: IpNetworkInterface, index?: number): IpNetworkInterface;

  getIsConnected(): boolean;
  setIsConnected(value: boolean): IpState;
  hasIsConnected(): boolean;
  clearIsConnected(): IpState;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): IpState.AsObject;
  static toObject(includeInstance: boolean, msg: IpState): IpState.AsObject;
  static serializeBinaryToWriter(message: IpState, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): IpState;
  static deserializeBinaryFromReader(message: IpState, reader: jspb.BinaryReader): IpState;
}

export namespace IpState {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotIp?: string,
    interfacesList: Array<IpNetworkInterface.AsObject>,
    isConnected?: boolean,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotIpCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_IP_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_IP = 1000,
  }

  export enum IsConnectedCase { 
    _IS_CONNECTED_NOT_SET = 0,
    IS_CONNECTED = 3,
  }
}

export class KeypadAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotKeypad(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotKeypad(value: string): KeypadAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotKeypad(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotKeypad(): KeypadAction;

  getKey(): Key;
  setKey(value: Key): KeypadAction;

  getPressedKeys(): KeypadAction.PressedKeysSetType | undefined;
  setPressedKeys(value?: KeypadAction.PressedKeysSetType): KeypadAction;
  hasPressedKeys(): boolean;
  clearPressedKeys(): KeypadAction;

  getTime(): number;
  setTime(value: number): KeypadAction;
  hasTime(): boolean;
  clearTime(): KeypadAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): KeypadAction.AsObject;
  static toObject(includeInstance: boolean, msg: KeypadAction): KeypadAction.AsObject;
  static serializeBinaryToWriter(message: KeypadAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): KeypadAction;
  static deserializeBinaryFromReader(message: KeypadAction, reader: jspb.BinaryReader): KeypadAction;
}

export namespace KeypadAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotKeypad?: string,
    key: Key,
    pressedKeys?: KeypadAction.PressedKeysSetType.AsObject,
    time?: number,
  }

  export class PressedKeysSetType extends jspb.Message {
    getItemsList(): Array<Key>;
    setItemsList(value: Array<Key>): PressedKeysSetType;
    clearItemsList(): PressedKeysSetType;
    addItems(value: Key, index?: number): PressedKeysSetType;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): PressedKeysSetType.AsObject;
    static toObject(includeInstance: boolean, msg: PressedKeysSetType): PressedKeysSetType.AsObject;
    static serializeBinaryToWriter(message: PressedKeysSetType, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): PressedKeysSetType;
    static deserializeBinaryFromReader(message: PressedKeysSetType, reader: jspb.BinaryReader): PressedKeysSetType;
  }

  export namespace PressedKeysSetType {
    export type AsObject = {
      itemsList: Array<Key>,
    }
  }


  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotKeypadCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_KEYPAD_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_KEYPAD = 1000,
  }

  export enum TimeCase { 
    _TIME_NOT_SET = 0,
    TIME = 4,
  }
}

export class KeypadKeyPressAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotKeypad(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotKeypad(value: string): KeypadKeyPressAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotKeypad(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotKeypad(): KeypadKeyPressAction;

  getKey(): Key;
  setKey(value: Key): KeypadKeyPressAction;

  getPressedKeys(): KeypadKeyPressAction.PressedKeysSetType | undefined;
  setPressedKeys(value?: KeypadKeyPressAction.PressedKeysSetType): KeypadKeyPressAction;
  hasPressedKeys(): boolean;
  clearPressedKeys(): KeypadKeyPressAction;

  getTime(): number;
  setTime(value: number): KeypadKeyPressAction;
  hasTime(): boolean;
  clearTime(): KeypadKeyPressAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): KeypadKeyPressAction.AsObject;
  static toObject(includeInstance: boolean, msg: KeypadKeyPressAction): KeypadKeyPressAction.AsObject;
  static serializeBinaryToWriter(message: KeypadKeyPressAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): KeypadKeyPressAction;
  static deserializeBinaryFromReader(message: KeypadKeyPressAction, reader: jspb.BinaryReader): KeypadKeyPressAction;
}

export namespace KeypadKeyPressAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotKeypad?: string,
    key: Key,
    pressedKeys?: KeypadKeyPressAction.PressedKeysSetType.AsObject,
    time?: number,
  }

  export class PressedKeysSetType extends jspb.Message {
    getItemsList(): Array<Key>;
    setItemsList(value: Array<Key>): PressedKeysSetType;
    clearItemsList(): PressedKeysSetType;
    addItems(value: Key, index?: number): PressedKeysSetType;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): PressedKeysSetType.AsObject;
    static toObject(includeInstance: boolean, msg: PressedKeysSetType): PressedKeysSetType.AsObject;
    static serializeBinaryToWriter(message: PressedKeysSetType, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): PressedKeysSetType;
    static deserializeBinaryFromReader(message: PressedKeysSetType, reader: jspb.BinaryReader): PressedKeysSetType;
  }

  export namespace PressedKeysSetType {
    export type AsObject = {
      itemsList: Array<Key>,
    }
  }


  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotKeypadCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_KEYPAD_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_KEYPAD = 1000,
  }

  export enum TimeCase { 
    _TIME_NOT_SET = 0,
    TIME = 4,
  }
}

export class KeypadKeyReleaseAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotKeypad(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotKeypad(value: string): KeypadKeyReleaseAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotKeypad(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotKeypad(): KeypadKeyReleaseAction;

  getKey(): Key;
  setKey(value: Key): KeypadKeyReleaseAction;

  getPressedKeys(): KeypadKeyReleaseAction.PressedKeysSetType | undefined;
  setPressedKeys(value?: KeypadKeyReleaseAction.PressedKeysSetType): KeypadKeyReleaseAction;
  hasPressedKeys(): boolean;
  clearPressedKeys(): KeypadKeyReleaseAction;

  getTime(): number;
  setTime(value: number): KeypadKeyReleaseAction;
  hasTime(): boolean;
  clearTime(): KeypadKeyReleaseAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): KeypadKeyReleaseAction.AsObject;
  static toObject(includeInstance: boolean, msg: KeypadKeyReleaseAction): KeypadKeyReleaseAction.AsObject;
  static serializeBinaryToWriter(message: KeypadKeyReleaseAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): KeypadKeyReleaseAction;
  static deserializeBinaryFromReader(message: KeypadKeyReleaseAction, reader: jspb.BinaryReader): KeypadKeyReleaseAction;
}

export namespace KeypadKeyReleaseAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotKeypad?: string,
    key: Key,
    pressedKeys?: KeypadKeyReleaseAction.PressedKeysSetType.AsObject,
    time?: number,
  }

  export class PressedKeysSetType extends jspb.Message {
    getItemsList(): Array<Key>;
    setItemsList(value: Array<Key>): PressedKeysSetType;
    clearItemsList(): PressedKeysSetType;
    addItems(value: Key, index?: number): PressedKeysSetType;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): PressedKeysSetType.AsObject;
    static toObject(includeInstance: boolean, msg: PressedKeysSetType): PressedKeysSetType.AsObject;
    static serializeBinaryToWriter(message: PressedKeysSetType, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): PressedKeysSetType;
    static deserializeBinaryFromReader(message: PressedKeysSetType, reader: jspb.BinaryReader): PressedKeysSetType;
  }

  export namespace PressedKeysSetType {
    export type AsObject = {
      itemsList: Array<Key>,
    }
  }


  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotKeypadCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_KEYPAD_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_KEYPAD = 1000,
  }

  export enum TimeCase { 
    _TIME_NOT_SET = 0,
    TIME = 4,
  }
}

export class KeypadState extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotKeypad(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotKeypad(value: string): KeypadState;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotKeypad(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotKeypad(): KeypadState;

  getDepth(): number;
  setDepth(value: number): KeypadState;
  hasDepth(): boolean;
  clearDepth(): KeypadState;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): KeypadState.AsObject;
  static toObject(includeInstance: boolean, msg: KeypadState): KeypadState.AsObject;
  static serializeBinaryToWriter(message: KeypadState, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): KeypadState;
  static deserializeBinaryFromReader(message: KeypadState, reader: jspb.BinaryReader): KeypadState;
}

export namespace KeypadState {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotKeypad?: string,
    depth?: number,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotKeypadCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_KEYPAD_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_KEYPAD = 1000,
  }

  export enum DepthCase { 
    _DEPTH_NOT_SET = 0,
    DEPTH = 2,
  }
}

export class LightDMAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotLightdm(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotLightdm(value: string): LightDMAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotLightdm(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotLightdm(): LightDMAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): LightDMAction.AsObject;
  static toObject(includeInstance: boolean, msg: LightDMAction): LightDMAction.AsObject;
  static serializeBinaryToWriter(message: LightDMAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): LightDMAction;
  static deserializeBinaryFromReader(message: LightDMAction, reader: jspb.BinaryReader): LightDMAction;
}

export namespace LightDMAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotLightdm?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotLightdmCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_LIGHTDM_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_LIGHTDM = 1000,
  }
}

export class LightDMUpdateStateAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotLightdm(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotLightdm(value: string): LightDMUpdateStateAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotLightdm(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotLightdm(): LightDMUpdateStateAction;

  getIsActive(): boolean;
  setIsActive(value: boolean): LightDMUpdateStateAction;
  hasIsActive(): boolean;
  clearIsActive(): LightDMUpdateStateAction;

  getIsEnabled(): boolean;
  setIsEnabled(value: boolean): LightDMUpdateStateAction;
  hasIsEnabled(): boolean;
  clearIsEnabled(): LightDMUpdateStateAction;

  getIsInstalled(): boolean;
  setIsInstalled(value: boolean): LightDMUpdateStateAction;
  hasIsInstalled(): boolean;
  clearIsInstalled(): LightDMUpdateStateAction;

  getIsInstalling(): boolean;
  setIsInstalling(value: boolean): LightDMUpdateStateAction;
  hasIsInstalling(): boolean;
  clearIsInstalling(): LightDMUpdateStateAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): LightDMUpdateStateAction.AsObject;
  static toObject(includeInstance: boolean, msg: LightDMUpdateStateAction): LightDMUpdateStateAction.AsObject;
  static serializeBinaryToWriter(message: LightDMUpdateStateAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): LightDMUpdateStateAction;
  static deserializeBinaryFromReader(message: LightDMUpdateStateAction, reader: jspb.BinaryReader): LightDMUpdateStateAction;
}

export namespace LightDMUpdateStateAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotLightdm?: string,
    isActive?: boolean,
    isEnabled?: boolean,
    isInstalled?: boolean,
    isInstalling?: boolean,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotLightdmCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_LIGHTDM_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_LIGHTDM = 1000,
  }

  export enum IsActiveCase { 
    _IS_ACTIVE_NOT_SET = 0,
    IS_ACTIVE = 2,
  }

  export enum IsEnabledCase { 
    _IS_ENABLED_NOT_SET = 0,
    IS_ENABLED = 3,
  }

  export enum IsInstalledCase { 
    _IS_INSTALLED_NOT_SET = 0,
    IS_INSTALLED = 4,
  }

  export enum IsInstallingCase { 
    _IS_INSTALLING_NOT_SET = 0,
    IS_INSTALLING = 5,
  }
}

export class LightDMClearEnabledStateAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotLightdm(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotLightdm(value: string): LightDMClearEnabledStateAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotLightdm(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotLightdm(): LightDMClearEnabledStateAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): LightDMClearEnabledStateAction.AsObject;
  static toObject(includeInstance: boolean, msg: LightDMClearEnabledStateAction): LightDMClearEnabledStateAction.AsObject;
  static serializeBinaryToWriter(message: LightDMClearEnabledStateAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): LightDMClearEnabledStateAction;
  static deserializeBinaryFromReader(message: LightDMClearEnabledStateAction, reader: jspb.BinaryReader): LightDMClearEnabledStateAction;
}

export namespace LightDMClearEnabledStateAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotLightdm?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotLightdmCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_LIGHTDM_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_LIGHTDM = 1000,
  }
}

export class LightDMState extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotLightdm(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotLightdm(value: string): LightDMState;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotLightdm(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotLightdm(): LightDMState;

  getIsActive(): boolean;
  setIsActive(value: boolean): LightDMState;
  hasIsActive(): boolean;
  clearIsActive(): LightDMState;

  getIsEnabled(): boolean;
  setIsEnabled(value: boolean): LightDMState;
  hasIsEnabled(): boolean;
  clearIsEnabled(): LightDMState;

  getIsInstalled(): boolean;
  setIsInstalled(value: boolean): LightDMState;
  hasIsInstalled(): boolean;
  clearIsInstalled(): LightDMState;

  getIsInstalling(): boolean;
  setIsInstalling(value: boolean): LightDMState;
  hasIsInstalling(): boolean;
  clearIsInstalling(): LightDMState;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): LightDMState.AsObject;
  static toObject(includeInstance: boolean, msg: LightDMState): LightDMState.AsObject;
  static serializeBinaryToWriter(message: LightDMState, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): LightDMState;
  static deserializeBinaryFromReader(message: LightDMState, reader: jspb.BinaryReader): LightDMState;
}

export namespace LightDMState {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotLightdm?: string,
    isActive?: boolean,
    isEnabled?: boolean,
    isInstalled?: boolean,
    isInstalling?: boolean,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotLightdmCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_LIGHTDM_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_LIGHTDM = 1000,
  }

  export enum IsActiveCase { 
    _IS_ACTIVE_NOT_SET = 0,
    IS_ACTIVE = 2,
  }

  export enum IsEnabledCase { 
    _IS_ENABLED_NOT_SET = 0,
    IS_ENABLED = 3,
  }

  export enum IsInstalledCase { 
    _IS_INSTALLED_NOT_SET = 0,
    IS_INSTALLED = 4,
  }

  export enum IsInstallingCase { 
    _IS_INSTALLING_NOT_SET = 0,
    IS_INSTALLING = 5,
  }
}

export class NotificationActionItem extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotNotifications(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotNotifications(value: string): NotificationActionItem;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotNotifications(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotNotifications(): NotificationActionItem;

  getBackgroundColor(): string;
  setBackgroundColor(value: string): NotificationActionItem;
  hasBackgroundColor(): boolean;
  clearBackgroundColor(): NotificationActionItem;

  getDismissNotification(): boolean;
  setDismissNotification(value: boolean): NotificationActionItem;
  hasDismissNotification(): boolean;
  clearDismissNotification(): NotificationActionItem;

  getCloseNotification(): boolean;
  setCloseNotification(value: boolean): NotificationActionItem;
  hasCloseNotification(): boolean;
  clearCloseNotification(): NotificationActionItem;

  getKey(): string;
  setKey(value: string): NotificationActionItem;
  hasKey(): boolean;
  clearKey(): NotificationActionItem;

  getLabel(): string;
  setLabel(value: string): NotificationActionItem;
  hasLabel(): boolean;
  clearLabel(): NotificationActionItem;

  getColor(): string;
  setColor(value: string): NotificationActionItem;
  hasColor(): boolean;
  clearColor(): NotificationActionItem;

  getIcon(): string;
  setIcon(value: string): NotificationActionItem;
  hasIcon(): boolean;
  clearIcon(): NotificationActionItem;

  getIsShort(): boolean;
  setIsShort(value: boolean): NotificationActionItem;
  hasIsShort(): boolean;
  clearIsShort(): NotificationActionItem;

  getOpacity(): number;
  setOpacity(value: number): NotificationActionItem;
  hasOpacity(): boolean;
  clearOpacity(): NotificationActionItem;

  getProgress(): number;
  setProgress(value: number): NotificationActionItem;
  hasProgress(): boolean;
  clearProgress(): NotificationActionItem;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): NotificationActionItem.AsObject;
  static toObject(includeInstance: boolean, msg: NotificationActionItem): NotificationActionItem.AsObject;
  static serializeBinaryToWriter(message: NotificationActionItem, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): NotificationActionItem;
  static deserializeBinaryFromReader(message: NotificationActionItem, reader: jspb.BinaryReader): NotificationActionItem;
}

export namespace NotificationActionItem {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotNotifications?: string,
    backgroundColor?: string,
    dismissNotification?: boolean,
    closeNotification?: boolean,
    key?: string,
    label?: string,
    color?: string,
    icon?: string,
    isShort?: boolean,
    opacity?: number,
    progress?: number,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotNotificationsCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_NOTIFICATIONS_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_NOTIFICATIONS = 1000,
  }

  export enum BackgroundColorCase { 
    _BACKGROUND_COLOR_NOT_SET = 0,
    BACKGROUND_COLOR = 2,
  }

  export enum DismissNotificationCase { 
    _DISMISS_NOTIFICATION_NOT_SET = 0,
    DISMISS_NOTIFICATION = 3,
  }

  export enum CloseNotificationCase { 
    _CLOSE_NOTIFICATION_NOT_SET = 0,
    CLOSE_NOTIFICATION = 4,
  }

  export enum KeyCase { 
    _KEY_NOT_SET = 0,
    KEY = 5,
  }

  export enum LabelCase { 
    _LABEL_NOT_SET = 0,
    LABEL = 6,
  }

  export enum ColorCase { 
    _COLOR_NOT_SET = 0,
    COLOR = 7,
  }

  export enum IconCase { 
    _ICON_NOT_SET = 0,
    ICON = 8,
  }

  export enum IsShortCase { 
    _IS_SHORT_NOT_SET = 0,
    IS_SHORT = 9,
  }

  export enum OpacityCase { 
    _OPACITY_NOT_SET = 0,
    OPACITY = 10,
  }

  export enum ProgressCase { 
    _PROGRESS_NOT_SET = 0,
    PROGRESS = 11,
  }
}

export class NotificationApplicationItem extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotNotifications(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotNotifications(value: string): NotificationApplicationItem;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotNotifications(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotNotifications(): NotificationApplicationItem;

  getBackgroundColor(): string;
  setBackgroundColor(value: string): NotificationApplicationItem;
  hasBackgroundColor(): boolean;
  clearBackgroundColor(): NotificationApplicationItem;

  getDismissNotification(): boolean;
  setDismissNotification(value: boolean): NotificationApplicationItem;
  hasDismissNotification(): boolean;
  clearDismissNotification(): NotificationApplicationItem;

  getCloseNotification(): boolean;
  setCloseNotification(value: boolean): NotificationApplicationItem;
  hasCloseNotification(): boolean;
  clearCloseNotification(): NotificationApplicationItem;

  getApplication(): NotificationApplicationItem.Application | undefined;
  setApplication(value?: NotificationApplicationItem.Application): NotificationApplicationItem;
  hasApplication(): boolean;
  clearApplication(): NotificationApplicationItem;

  getApplicationId(): string;
  setApplicationId(value: string): NotificationApplicationItem;

  getInitializationArgs(): NotificationApplicationItem.InitializationArgs | undefined;
  setInitializationArgs(value?: NotificationApplicationItem.InitializationArgs): NotificationApplicationItem;
  hasInitializationArgs(): boolean;
  clearInitializationArgs(): NotificationApplicationItem;

  getInitializationKwargs(): NotificationApplicationItem.InitializationKwargsDict | undefined;
  setInitializationKwargs(value?: NotificationApplicationItem.InitializationKwargsDict): NotificationApplicationItem;
  hasInitializationKwargs(): boolean;
  clearInitializationKwargs(): NotificationApplicationItem;

  getKey(): string;
  setKey(value: string): NotificationApplicationItem;
  hasKey(): boolean;
  clearKey(): NotificationApplicationItem;

  getLabel(): string;
  setLabel(value: string): NotificationApplicationItem;
  hasLabel(): boolean;
  clearLabel(): NotificationApplicationItem;

  getColor(): string;
  setColor(value: string): NotificationApplicationItem;
  hasColor(): boolean;
  clearColor(): NotificationApplicationItem;

  getIcon(): string;
  setIcon(value: string): NotificationApplicationItem;
  hasIcon(): boolean;
  clearIcon(): NotificationApplicationItem;

  getIsShort(): boolean;
  setIsShort(value: boolean): NotificationApplicationItem;
  hasIsShort(): boolean;
  clearIsShort(): NotificationApplicationItem;

  getOpacity(): number;
  setOpacity(value: number): NotificationApplicationItem;
  hasOpacity(): boolean;
  clearOpacity(): NotificationApplicationItem;

  getProgress(): number;
  setProgress(value: number): NotificationApplicationItem;
  hasProgress(): boolean;
  clearProgress(): NotificationApplicationItem;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): NotificationApplicationItem.AsObject;
  static toObject(includeInstance: boolean, msg: NotificationApplicationItem): NotificationApplicationItem.AsObject;
  static serializeBinaryToWriter(message: NotificationApplicationItem, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): NotificationApplicationItem;
  static deserializeBinaryFromReader(message: NotificationApplicationItem, reader: jspb.BinaryReader): NotificationApplicationItem;
}

export namespace NotificationApplicationItem {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotNotifications?: string,
    backgroundColor?: string,
    dismissNotification?: boolean,
    closeNotification?: boolean,
    application?: NotificationApplicationItem.Application.AsObject,
    applicationId: string,
    initializationArgs?: NotificationApplicationItem.InitializationArgs.AsObject,
    initializationKwargs?: NotificationApplicationItem.InitializationKwargsDict.AsObject,
    key?: string,
    label?: string,
    color?: string,
    icon?: string,
    isShort?: boolean,
    opacity?: number,
    progress?: number,
  }

  export class Application extends jspb.Message {
    getString(): string;
    setString(value: string): Application;

    getApplicationCase(): Application.ApplicationCase;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): Application.AsObject;
    static toObject(includeInstance: boolean, msg: Application): Application.AsObject;
    static serializeBinaryToWriter(message: Application, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): Application;
    static deserializeBinaryFromReader(message: Application, reader: jspb.BinaryReader): Application;
  }

  export namespace Application {
    export type AsObject = {
      string: string,
    }

    export enum ApplicationCase { 
      APPLICATION_NOT_SET = 0,
      STRING = 1,
    }
  }


  export class InitializationArgs extends jspb.Message {
    getItemsList(): Array<BasicType>;
    setItemsList(value: Array<BasicType>): InitializationArgs;
    clearItemsList(): InitializationArgs;
    addItems(value?: BasicType, index?: number): BasicType;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): InitializationArgs.AsObject;
    static toObject(includeInstance: boolean, msg: InitializationArgs): InitializationArgs.AsObject;
    static serializeBinaryToWriter(message: InitializationArgs, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): InitializationArgs;
    static deserializeBinaryFromReader(message: InitializationArgs, reader: jspb.BinaryReader): InitializationArgs;
  }

  export namespace InitializationArgs {
    export type AsObject = {
      itemsList: Array<BasicType.AsObject>,
    }
  }


  export class InitializationKwargsDict extends jspb.Message {
    getItemsMap(): jspb.Map<string, BasicType>;
    clearItemsMap(): InitializationKwargsDict;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): InitializationKwargsDict.AsObject;
    static toObject(includeInstance: boolean, msg: InitializationKwargsDict): InitializationKwargsDict.AsObject;
    static serializeBinaryToWriter(message: InitializationKwargsDict, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): InitializationKwargsDict;
    static deserializeBinaryFromReader(message: InitializationKwargsDict, reader: jspb.BinaryReader): InitializationKwargsDict;
  }

  export namespace InitializationKwargsDict {
    export type AsObject = {
      itemsMap: Array<[string, BasicType.AsObject]>,
    }
  }


  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotNotificationsCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_NOTIFICATIONS_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_NOTIFICATIONS = 1000,
  }

  export enum BackgroundColorCase { 
    _BACKGROUND_COLOR_NOT_SET = 0,
    BACKGROUND_COLOR = 2,
  }

  export enum DismissNotificationCase { 
    _DISMISS_NOTIFICATION_NOT_SET = 0,
    DISMISS_NOTIFICATION = 3,
  }

  export enum CloseNotificationCase { 
    _CLOSE_NOTIFICATION_NOT_SET = 0,
    CLOSE_NOTIFICATION = 4,
  }

  export enum ApplicationCase { 
    _APPLICATION_NOT_SET = 0,
    APPLICATION = 5,
  }

  export enum InitializationArgsCase { 
    _INITIALIZATION_ARGS_NOT_SET = 0,
    INITIALIZATION_ARGS = 7,
  }

  export enum InitializationKwargsCase { 
    _INITIALIZATION_KWARGS_NOT_SET = 0,
    INITIALIZATION_KWARGS = 8,
  }

  export enum KeyCase { 
    _KEY_NOT_SET = 0,
    KEY = 9,
  }

  export enum LabelCase { 
    _LABEL_NOT_SET = 0,
    LABEL = 10,
  }

  export enum ColorCase { 
    _COLOR_NOT_SET = 0,
    COLOR = 11,
  }

  export enum IconCase { 
    _ICON_NOT_SET = 0,
    ICON = 12,
  }

  export enum IsShortCase { 
    _IS_SHORT_NOT_SET = 0,
    IS_SHORT = 13,
  }

  export enum OpacityCase { 
    _OPACITY_NOT_SET = 0,
    OPACITY = 14,
  }

  export enum ProgressCase { 
    _PROGRESS_NOT_SET = 0,
    PROGRESS = 15,
  }
}

export class NotificationDispatchItem extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotNotifications(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotNotifications(value: string): NotificationDispatchItem;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotNotifications(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotNotifications(): NotificationDispatchItem;

  getStoreAction(): NotificationDispatchItem.StoreAction | undefined;
  setStoreAction(value?: NotificationDispatchItem.StoreAction): NotificationDispatchItem;
  hasStoreAction(): boolean;
  clearStoreAction(): NotificationDispatchItem;

  getKey(): string;
  setKey(value: string): NotificationDispatchItem;
  hasKey(): boolean;
  clearKey(): NotificationDispatchItem;

  getLabel(): string;
  setLabel(value: string): NotificationDispatchItem;
  hasLabel(): boolean;
  clearLabel(): NotificationDispatchItem;

  getColor(): string;
  setColor(value: string): NotificationDispatchItem;
  hasColor(): boolean;
  clearColor(): NotificationDispatchItem;

  getBackgroundColor(): string;
  setBackgroundColor(value: string): NotificationDispatchItem;
  hasBackgroundColor(): boolean;
  clearBackgroundColor(): NotificationDispatchItem;

  getIcon(): string;
  setIcon(value: string): NotificationDispatchItem;
  hasIcon(): boolean;
  clearIcon(): NotificationDispatchItem;

  getIsShort(): boolean;
  setIsShort(value: boolean): NotificationDispatchItem;
  hasIsShort(): boolean;
  clearIsShort(): NotificationDispatchItem;

  getOpacity(): number;
  setOpacity(value: number): NotificationDispatchItem;
  hasOpacity(): boolean;
  clearOpacity(): NotificationDispatchItem;

  getProgress(): number;
  setProgress(value: number): NotificationDispatchItem;
  hasProgress(): boolean;
  clearProgress(): NotificationDispatchItem;

  getDismissNotification(): boolean;
  setDismissNotification(value: boolean): NotificationDispatchItem;
  hasDismissNotification(): boolean;
  clearDismissNotification(): NotificationDispatchItem;

  getCloseNotification(): boolean;
  setCloseNotification(value: boolean): NotificationDispatchItem;
  hasCloseNotification(): boolean;
  clearCloseNotification(): NotificationDispatchItem;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): NotificationDispatchItem.AsObject;
  static toObject(includeInstance: boolean, msg: NotificationDispatchItem): NotificationDispatchItem.AsObject;
  static serializeBinaryToWriter(message: NotificationDispatchItem, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): NotificationDispatchItem;
  static deserializeBinaryFromReader(message: NotificationDispatchItem, reader: jspb.BinaryReader): NotificationDispatchItem;
}

export namespace NotificationDispatchItem {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotNotifications?: string,
    storeAction?: NotificationDispatchItem.StoreAction.AsObject,
    key?: string,
    label?: string,
    color?: string,
    backgroundColor?: string,
    icon?: string,
    isShort?: boolean,
    opacity?: number,
    progress?: number,
    dismissNotification?: boolean,
    closeNotification?: boolean,
  }

  export class StoreAction2 extends jspb.Message {
    getItemsList(): Array<Action>;
    setItemsList(value: Array<Action>): StoreAction2;
    clearItemsList(): StoreAction2;
    addItems(value?: Action, index?: number): Action;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): StoreAction2.AsObject;
    static toObject(includeInstance: boolean, msg: StoreAction2): StoreAction2.AsObject;
    static serializeBinaryToWriter(message: StoreAction2, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): StoreAction2;
    static deserializeBinaryFromReader(message: StoreAction2, reader: jspb.BinaryReader): StoreAction2;
  }

  export namespace StoreAction2 {
    export type AsObject = {
      itemsList: Array<Action.AsObject>,
    }
  }


  export class StoreAction extends jspb.Message {
    getUboAction(): Action | undefined;
    setUboAction(value?: Action): StoreAction;
    hasUboAction(): boolean;
    clearUboAction(): StoreAction;

    getList(): NotificationDispatchItem.StoreAction2 | undefined;
    setList(value?: NotificationDispatchItem.StoreAction2): StoreAction;
    hasList(): boolean;
    clearList(): StoreAction;

    getStoreActionCase(): StoreAction.StoreActionCase;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): StoreAction.AsObject;
    static toObject(includeInstance: boolean, msg: StoreAction): StoreAction.AsObject;
    static serializeBinaryToWriter(message: StoreAction, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): StoreAction;
    static deserializeBinaryFromReader(message: StoreAction, reader: jspb.BinaryReader): StoreAction;
  }

  export namespace StoreAction {
    export type AsObject = {
      uboAction?: Action.AsObject,
      list?: NotificationDispatchItem.StoreAction2.AsObject,
    }

    export enum StoreActionCase { 
      STORE_ACTION_NOT_SET = 0,
      UBO_ACTION = 1,
      LIST = 2,
    }
  }


  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotNotificationsCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_NOTIFICATIONS_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_NOTIFICATIONS = 1000,
  }

  export enum KeyCase { 
    _KEY_NOT_SET = 0,
    KEY = 3,
  }

  export enum LabelCase { 
    _LABEL_NOT_SET = 0,
    LABEL = 4,
  }

  export enum ColorCase { 
    _COLOR_NOT_SET = 0,
    COLOR = 5,
  }

  export enum BackgroundColorCase { 
    _BACKGROUND_COLOR_NOT_SET = 0,
    BACKGROUND_COLOR = 6,
  }

  export enum IconCase { 
    _ICON_NOT_SET = 0,
    ICON = 7,
  }

  export enum IsShortCase { 
    _IS_SHORT_NOT_SET = 0,
    IS_SHORT = 8,
  }

  export enum OpacityCase { 
    _OPACITY_NOT_SET = 0,
    OPACITY = 9,
  }

  export enum ProgressCase { 
    _PROGRESS_NOT_SET = 0,
    PROGRESS = 10,
  }

  export enum DismissNotificationCase { 
    _DISMISS_NOTIFICATION_NOT_SET = 0,
    DISMISS_NOTIFICATION = 11,
  }

  export enum CloseNotificationCase { 
    _CLOSE_NOTIFICATION_NOT_SET = 0,
    CLOSE_NOTIFICATION = 12,
  }
}

export class Notification extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotNotifications(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotNotifications(value: string): Notification;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotNotifications(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotNotifications(): Notification;

  getId(): string;
  setId(value: string): Notification;
  hasId(): boolean;
  clearId(): Notification;

  getTitle(): string;
  setTitle(value: string): Notification;

  getContent(): string;
  setContent(value: string): Notification;

  getExtraInformation(): ReadableInformation | undefined;
  setExtraInformation(value?: ReadableInformation): Notification;
  hasExtraInformation(): boolean;
  clearExtraInformation(): Notification;

  getImportance(): Importance;
  setImportance(value: Importance): Notification;
  hasImportance(): boolean;
  clearImportance(): Notification;

  getChime(): Chime;
  setChime(value: Chime): Notification;
  hasChime(): boolean;
  clearChime(): Notification;

  getTimestamp(): number;
  setTimestamp(value: number): Notification;
  hasTimestamp(): boolean;
  clearTimestamp(): Notification;

  getIsRead(): boolean;
  setIsRead(value: boolean): Notification;
  hasIsRead(): boolean;
  clearIsRead(): Notification;

  getSender(): string;
  setSender(value: string): Notification;
  hasSender(): boolean;
  clearSender(): Notification;

  getActions(): Notification.Actions | undefined;
  setActions(value?: Notification.Actions): Notification;
  hasActions(): boolean;
  clearActions(): Notification;

  getIcon(): string;
  setIcon(value: string): Notification;
  hasIcon(): boolean;
  clearIcon(): Notification;

  getColor(): string;
  setColor(value: string): Notification;
  hasColor(): boolean;
  clearColor(): Notification;

  getExpirationTimestamp(): number;
  setExpirationTimestamp(value: number): Notification;
  hasExpirationTimestamp(): boolean;
  clearExpirationTimestamp(): Notification;

  getDisplayType(): NotificationDisplayType;
  setDisplayType(value: NotificationDisplayType): Notification;
  hasDisplayType(): boolean;
  clearDisplayType(): Notification;

  getFlashTime(): number;
  setFlashTime(value: number): Notification;
  hasFlashTime(): boolean;
  clearFlashTime(): Notification;

  getShowDismissAction(): boolean;
  setShowDismissAction(value: boolean): Notification;
  hasShowDismissAction(): boolean;
  clearShowDismissAction(): Notification;

  getDismissOnClose(): boolean;
  setDismissOnClose(value: boolean): Notification;
  hasDismissOnClose(): boolean;
  clearDismissOnClose(): Notification;

  getOnClose(): Notification.OnClose | undefined;
  setOnClose(value?: Notification.OnClose): Notification;
  hasOnClose(): boolean;
  clearOnClose(): Notification;

  getBlink(): boolean;
  setBlink(value: boolean): Notification;
  hasBlink(): boolean;
  clearBlink(): Notification;

  getProgress(): number;
  setProgress(value: number): Notification;
  hasProgress(): boolean;
  clearProgress(): Notification;

  getProgressWeight(): number;
  setProgressWeight(value: number): Notification;
  hasProgressWeight(): boolean;
  clearProgressWeight(): Notification;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Notification.AsObject;
  static toObject(includeInstance: boolean, msg: Notification): Notification.AsObject;
  static serializeBinaryToWriter(message: Notification, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Notification;
  static deserializeBinaryFromReader(message: Notification, reader: jspb.BinaryReader): Notification;
}

export namespace Notification {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotNotifications?: string,
    id?: string,
    title: string,
    content: string,
    extraInformation?: ReadableInformation.AsObject,
    importance?: Importance,
    chime?: Chime,
    timestamp?: number,
    isRead?: boolean,
    sender?: string,
    actions?: Notification.Actions.AsObject,
    icon?: string,
    color?: string,
    expirationTimestamp?: number,
    displayType?: NotificationDisplayType,
    flashTime?: number,
    showDismissAction?: boolean,
    dismissOnClose?: boolean,
    onClose?: Notification.OnClose.AsObject,
    blink?: boolean,
    progress?: number,
    progressWeight?: number,
  }

  export class ActionsItem extends jspb.Message {
    getNotificationActionItem(): NotificationActionItem | undefined;
    setNotificationActionItem(value?: NotificationActionItem): ActionsItem;
    hasNotificationActionItem(): boolean;
    clearNotificationActionItem(): ActionsItem;

    getNotificationApplicationItem(): NotificationApplicationItem | undefined;
    setNotificationApplicationItem(value?: NotificationApplicationItem): ActionsItem;
    hasNotificationApplicationItem(): boolean;
    clearNotificationApplicationItem(): ActionsItem;

    getNotificationDispatchItem(): NotificationDispatchItem | undefined;
    setNotificationDispatchItem(value?: NotificationDispatchItem): ActionsItem;
    hasNotificationDispatchItem(): boolean;
    clearNotificationDispatchItem(): ActionsItem;

    getActionsItemCase(): ActionsItem.ActionsItemCase;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): ActionsItem.AsObject;
    static toObject(includeInstance: boolean, msg: ActionsItem): ActionsItem.AsObject;
    static serializeBinaryToWriter(message: ActionsItem, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): ActionsItem;
    static deserializeBinaryFromReader(message: ActionsItem, reader: jspb.BinaryReader): ActionsItem;
  }

  export namespace ActionsItem {
    export type AsObject = {
      notificationActionItem?: NotificationActionItem.AsObject,
      notificationApplicationItem?: NotificationApplicationItem.AsObject,
      notificationDispatchItem?: NotificationDispatchItem.AsObject,
    }

    export enum ActionsItemCase { 
      ACTIONS_ITEM_NOT_SET = 0,
      NOTIFICATION_ACTION_ITEM = 1,
      NOTIFICATION_APPLICATION_ITEM = 2,
      NOTIFICATION_DISPATCH_ITEM = 3,
    }
  }


  export class Actions extends jspb.Message {
    getItemsList(): Array<Notification.ActionsItem>;
    setItemsList(value: Array<Notification.ActionsItem>): Actions;
    clearItemsList(): Actions;
    addItems(value?: Notification.ActionsItem, index?: number): Notification.ActionsItem;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): Actions.AsObject;
    static toObject(includeInstance: boolean, msg: Actions): Actions.AsObject;
    static serializeBinaryToWriter(message: Actions, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): Actions;
    static deserializeBinaryFromReader(message: Actions, reader: jspb.BinaryReader): Actions;
  }

  export namespace Actions {
    export type AsObject = {
      itemsList: Array<Notification.ActionsItem.AsObject>,
    }
  }


  export class OnClose extends jspb.Message {
    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): OnClose.AsObject;
    static toObject(includeInstance: boolean, msg: OnClose): OnClose.AsObject;
    static serializeBinaryToWriter(message: OnClose, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): OnClose;
    static deserializeBinaryFromReader(message: OnClose, reader: jspb.BinaryReader): OnClose;
  }

  export namespace OnClose {
    export type AsObject = {
    }
  }


  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotNotificationsCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_NOTIFICATIONS_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_NOTIFICATIONS = 1000,
  }

  export enum IdCase { 
    _ID_NOT_SET = 0,
    ID = 2,
  }

  export enum ExtraInformationCase { 
    _EXTRA_INFORMATION_NOT_SET = 0,
    EXTRA_INFORMATION = 5,
  }

  export enum ImportanceCase { 
    _IMPORTANCE_NOT_SET = 0,
    IMPORTANCE = 6,
  }

  export enum ChimeCase { 
    _CHIME_NOT_SET = 0,
    CHIME = 7,
  }

  export enum TimestampCase { 
    _TIMESTAMP_NOT_SET = 0,
    TIMESTAMP = 8,
  }

  export enum IsReadCase { 
    _IS_READ_NOT_SET = 0,
    IS_READ = 9,
  }

  export enum SenderCase { 
    _SENDER_NOT_SET = 0,
    SENDER = 10,
  }

  export enum ActionsCase { 
    _ACTIONS_NOT_SET = 0,
    ACTIONS = 11,
  }

  export enum IconCase { 
    _ICON_NOT_SET = 0,
    ICON = 12,
  }

  export enum ColorCase { 
    _COLOR_NOT_SET = 0,
    COLOR = 13,
  }

  export enum ExpirationTimestampCase { 
    _EXPIRATION_TIMESTAMP_NOT_SET = 0,
    EXPIRATION_TIMESTAMP = 14,
  }

  export enum DisplayTypeCase { 
    _DISPLAY_TYPE_NOT_SET = 0,
    DISPLAY_TYPE = 15,
  }

  export enum FlashTimeCase { 
    _FLASH_TIME_NOT_SET = 0,
    FLASH_TIME = 16,
  }

  export enum ShowDismissActionCase { 
    _SHOW_DISMISS_ACTION_NOT_SET = 0,
    SHOW_DISMISS_ACTION = 17,
  }

  export enum DismissOnCloseCase { 
    _DISMISS_ON_CLOSE_NOT_SET = 0,
    DISMISS_ON_CLOSE = 18,
  }

  export enum OnCloseCase { 
    _ON_CLOSE_NOT_SET = 0,
    ON_CLOSE = 19,
  }

  export enum BlinkCase { 
    _BLINK_NOT_SET = 0,
    BLINK = 20,
  }

  export enum ProgressCase { 
    _PROGRESS_NOT_SET = 0,
    PROGRESS = 21,
  }

  export enum ProgressWeightCase { 
    _PROGRESS_WEIGHT_NOT_SET = 0,
    PROGRESS_WEIGHT = 22,
  }
}

export class NotificationsAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotNotifications(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotNotifications(value: string): NotificationsAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotNotifications(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotNotifications(): NotificationsAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): NotificationsAction.AsObject;
  static toObject(includeInstance: boolean, msg: NotificationsAction): NotificationsAction.AsObject;
  static serializeBinaryToWriter(message: NotificationsAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): NotificationsAction;
  static deserializeBinaryFromReader(message: NotificationsAction, reader: jspb.BinaryReader): NotificationsAction;
}

export namespace NotificationsAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotNotifications?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotNotificationsCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_NOTIFICATIONS_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_NOTIFICATIONS = 1000,
  }
}

export class NotificationsAddAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotNotifications(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotNotifications(value: string): NotificationsAddAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotNotifications(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotNotifications(): NotificationsAddAction;

  getNotification(): Notification | undefined;
  setNotification(value?: Notification): NotificationsAddAction;
  hasNotification(): boolean;
  clearNotification(): NotificationsAddAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): NotificationsAddAction.AsObject;
  static toObject(includeInstance: boolean, msg: NotificationsAddAction): NotificationsAddAction.AsObject;
  static serializeBinaryToWriter(message: NotificationsAddAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): NotificationsAddAction;
  static deserializeBinaryFromReader(message: NotificationsAddAction, reader: jspb.BinaryReader): NotificationsAddAction;
}

export namespace NotificationsAddAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotNotifications?: string,
    notification?: Notification.AsObject,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotNotificationsCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_NOTIFICATIONS_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_NOTIFICATIONS = 1000,
  }
}

export class NotificationsDisplayAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotNotifications(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotNotifications(value: string): NotificationsDisplayAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotNotifications(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotNotifications(): NotificationsDisplayAction;

  getNotification(): Notification | undefined;
  setNotification(value?: Notification): NotificationsDisplayAction;
  hasNotification(): boolean;
  clearNotification(): NotificationsDisplayAction;

  getIndex(): number;
  setIndex(value: number): NotificationsDisplayAction;
  hasIndex(): boolean;
  clearIndex(): NotificationsDisplayAction;

  getCount(): number;
  setCount(value: number): NotificationsDisplayAction;
  hasCount(): boolean;
  clearCount(): NotificationsDisplayAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): NotificationsDisplayAction.AsObject;
  static toObject(includeInstance: boolean, msg: NotificationsDisplayAction): NotificationsDisplayAction.AsObject;
  static serializeBinaryToWriter(message: NotificationsDisplayAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): NotificationsDisplayAction;
  static deserializeBinaryFromReader(message: NotificationsDisplayAction, reader: jspb.BinaryReader): NotificationsDisplayAction;
}

export namespace NotificationsDisplayAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotNotifications?: string,
    notification?: Notification.AsObject,
    index?: number,
    count?: number,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotNotificationsCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_NOTIFICATIONS_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_NOTIFICATIONS = 1000,
  }

  export enum IndexCase { 
    _INDEX_NOT_SET = 0,
    INDEX = 3,
  }

  export enum CountCase { 
    _COUNT_NOT_SET = 0,
    COUNT = 4,
  }
}

export class NotificationsClearAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotNotifications(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotNotifications(value: string): NotificationsClearAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotNotifications(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotNotifications(): NotificationsClearAction;

  getNotification(): Notification | undefined;
  setNotification(value?: Notification): NotificationsClearAction;
  hasNotification(): boolean;
  clearNotification(): NotificationsClearAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): NotificationsClearAction.AsObject;
  static toObject(includeInstance: boolean, msg: NotificationsClearAction): NotificationsClearAction.AsObject;
  static serializeBinaryToWriter(message: NotificationsClearAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): NotificationsClearAction;
  static deserializeBinaryFromReader(message: NotificationsClearAction, reader: jspb.BinaryReader): NotificationsClearAction;
}

export namespace NotificationsClearAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotNotifications?: string,
    notification?: Notification.AsObject,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotNotificationsCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_NOTIFICATIONS_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_NOTIFICATIONS = 1000,
  }
}

export class NotificationsClearByIdAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotNotifications(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotNotifications(value: string): NotificationsClearByIdAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotNotifications(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotNotifications(): NotificationsClearByIdAction;

  getId(): string;
  setId(value: string): NotificationsClearByIdAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): NotificationsClearByIdAction.AsObject;
  static toObject(includeInstance: boolean, msg: NotificationsClearByIdAction): NotificationsClearByIdAction.AsObject;
  static serializeBinaryToWriter(message: NotificationsClearByIdAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): NotificationsClearByIdAction;
  static deserializeBinaryFromReader(message: NotificationsClearByIdAction, reader: jspb.BinaryReader): NotificationsClearByIdAction;
}

export namespace NotificationsClearByIdAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotNotifications?: string,
    id: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotNotificationsCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_NOTIFICATIONS_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_NOTIFICATIONS = 1000,
  }
}

export class NotificationsClearAllAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotNotifications(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotNotifications(value: string): NotificationsClearAllAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotNotifications(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotNotifications(): NotificationsClearAllAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): NotificationsClearAllAction.AsObject;
  static toObject(includeInstance: boolean, msg: NotificationsClearAllAction): NotificationsClearAllAction.AsObject;
  static serializeBinaryToWriter(message: NotificationsClearAllAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): NotificationsClearAllAction;
  static deserializeBinaryFromReader(message: NotificationsClearAllAction, reader: jspb.BinaryReader): NotificationsClearAllAction;
}

export namespace NotificationsClearAllAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotNotifications?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotNotificationsCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_NOTIFICATIONS_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_NOTIFICATIONS = 1000,
  }
}

export class NotificationsEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotNotifications(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotNotifications(value: string): NotificationsEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotNotifications(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotNotifications(): NotificationsEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): NotificationsEvent.AsObject;
  static toObject(includeInstance: boolean, msg: NotificationsEvent): NotificationsEvent.AsObject;
  static serializeBinaryToWriter(message: NotificationsEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): NotificationsEvent;
  static deserializeBinaryFromReader(message: NotificationsEvent, reader: jspb.BinaryReader): NotificationsEvent;
}

export namespace NotificationsEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotNotifications?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotNotificationsCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_NOTIFICATIONS_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_NOTIFICATIONS = 1000,
  }
}

export class NotificationsClearEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotNotifications(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotNotifications(value: string): NotificationsClearEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotNotifications(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotNotifications(): NotificationsClearEvent;

  getNotification(): Notification | undefined;
  setNotification(value?: Notification): NotificationsClearEvent;
  hasNotification(): boolean;
  clearNotification(): NotificationsClearEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): NotificationsClearEvent.AsObject;
  static toObject(includeInstance: boolean, msg: NotificationsClearEvent): NotificationsClearEvent.AsObject;
  static serializeBinaryToWriter(message: NotificationsClearEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): NotificationsClearEvent;
  static deserializeBinaryFromReader(message: NotificationsClearEvent, reader: jspb.BinaryReader): NotificationsClearEvent;
}

export namespace NotificationsClearEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotNotifications?: string,
    notification?: Notification.AsObject,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotNotificationsCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_NOTIFICATIONS_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_NOTIFICATIONS = 1000,
  }
}

export class NotificationsDisplayEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotNotifications(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotNotifications(value: string): NotificationsDisplayEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotNotifications(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotNotifications(): NotificationsDisplayEvent;

  getNotification(): Notification | undefined;
  setNotification(value?: Notification): NotificationsDisplayEvent;
  hasNotification(): boolean;
  clearNotification(): NotificationsDisplayEvent;

  getIndex(): number;
  setIndex(value: number): NotificationsDisplayEvent;
  hasIndex(): boolean;
  clearIndex(): NotificationsDisplayEvent;

  getCount(): number;
  setCount(value: number): NotificationsDisplayEvent;
  hasCount(): boolean;
  clearCount(): NotificationsDisplayEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): NotificationsDisplayEvent.AsObject;
  static toObject(includeInstance: boolean, msg: NotificationsDisplayEvent): NotificationsDisplayEvent.AsObject;
  static serializeBinaryToWriter(message: NotificationsDisplayEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): NotificationsDisplayEvent;
  static deserializeBinaryFromReader(message: NotificationsDisplayEvent, reader: jspb.BinaryReader): NotificationsDisplayEvent;
}

export namespace NotificationsDisplayEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotNotifications?: string,
    notification?: Notification.AsObject,
    index?: number,
    count?: number,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotNotificationsCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_NOTIFICATIONS_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_NOTIFICATIONS = 1000,
  }

  export enum IndexCase { 
    _INDEX_NOT_SET = 0,
    INDEX = 3,
  }

  export enum CountCase { 
    _COUNT_NOT_SET = 0,
    COUNT = 4,
  }
}

export class NotificationsState extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotNotifications(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotNotifications(value: string): NotificationsState;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotNotifications(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotNotifications(): NotificationsState;

  getNotificationsList(): Array<Notification>;
  setNotificationsList(value: Array<Notification>): NotificationsState;
  clearNotificationsList(): NotificationsState;
  addNotifications(value?: Notification, index?: number): Notification;

  getUnreadCount(): number;
  setUnreadCount(value: number): NotificationsState;

  getProgress(): number;
  setProgress(value: number): NotificationsState;
  hasProgress(): boolean;
  clearProgress(): NotificationsState;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): NotificationsState.AsObject;
  static toObject(includeInstance: boolean, msg: NotificationsState): NotificationsState.AsObject;
  static serializeBinaryToWriter(message: NotificationsState, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): NotificationsState;
  static deserializeBinaryFromReader(message: NotificationsState, reader: jspb.BinaryReader): NotificationsState;
}

export namespace NotificationsState {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotNotifications?: string,
    notificationsList: Array<Notification.AsObject>,
    unreadCount: number,
    progress?: number,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotNotificationsCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_NOTIFICATIONS_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_NOTIFICATIONS = 1000,
  }

  export enum ProgressCase { 
    _PROGRESS_NOT_SET = 0,
    PROGRESS = 4,
  }
}

export class RgbRingAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(value: string): RgbRingAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(): RgbRingAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): RgbRingAction.AsObject;
  static toObject(includeInstance: boolean, msg: RgbRingAction): RgbRingAction.AsObject;
  static serializeBinaryToWriter(message: RgbRingAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): RgbRingAction;
  static deserializeBinaryFromReader(message: RgbRingAction, reader: jspb.BinaryReader): RgbRingAction;
}

export namespace RgbRingAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRingCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_RGB_RING_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_RGB_RING = 1000,
  }
}

export class RgbRingEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(value: string): RgbRingEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(): RgbRingEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): RgbRingEvent.AsObject;
  static toObject(includeInstance: boolean, msg: RgbRingEvent): RgbRingEvent.AsObject;
  static serializeBinaryToWriter(message: RgbRingEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): RgbRingEvent;
  static deserializeBinaryFromReader(message: RgbRingEvent, reader: jspb.BinaryReader): RgbRingEvent;
}

export namespace RgbRingEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRingCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_RGB_RING_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_RGB_RING = 1000,
  }
}

export class RgbRingSetIsBusyAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(value: string): RgbRingSetIsBusyAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(): RgbRingSetIsBusyAction;

  getIsBusy(): boolean;
  setIsBusy(value: boolean): RgbRingSetIsBusyAction;
  hasIsBusy(): boolean;
  clearIsBusy(): RgbRingSetIsBusyAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): RgbRingSetIsBusyAction.AsObject;
  static toObject(includeInstance: boolean, msg: RgbRingSetIsBusyAction): RgbRingSetIsBusyAction.AsObject;
  static serializeBinaryToWriter(message: RgbRingSetIsBusyAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): RgbRingSetIsBusyAction;
  static deserializeBinaryFromReader(message: RgbRingSetIsBusyAction, reader: jspb.BinaryReader): RgbRingSetIsBusyAction;
}

export namespace RgbRingSetIsBusyAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing?: string,
    isBusy?: boolean,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRingCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_RGB_RING_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_RGB_RING = 1000,
  }

  export enum IsBusyCase { 
    _IS_BUSY_NOT_SET = 0,
    IS_BUSY = 2,
  }
}

export class RgbRingCommandAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(value: string): RgbRingCommandAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(): RgbRingCommandAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): RgbRingCommandAction.AsObject;
  static toObject(includeInstance: boolean, msg: RgbRingCommandAction): RgbRingCommandAction.AsObject;
  static serializeBinaryToWriter(message: RgbRingCommandAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): RgbRingCommandAction;
  static deserializeBinaryFromReader(message: RgbRingCommandAction, reader: jspb.BinaryReader): RgbRingCommandAction;
}

export namespace RgbRingCommandAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRingCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_RGB_RING_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_RGB_RING = 1000,
  }
}

export class RgbRingWaitableCommandAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(value: string): RgbRingWaitableCommandAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(): RgbRingWaitableCommandAction;

  getWait(): number;
  setWait(value: number): RgbRingWaitableCommandAction;
  hasWait(): boolean;
  clearWait(): RgbRingWaitableCommandAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): RgbRingWaitableCommandAction.AsObject;
  static toObject(includeInstance: boolean, msg: RgbRingWaitableCommandAction): RgbRingWaitableCommandAction.AsObject;
  static serializeBinaryToWriter(message: RgbRingWaitableCommandAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): RgbRingWaitableCommandAction;
  static deserializeBinaryFromReader(message: RgbRingWaitableCommandAction, reader: jspb.BinaryReader): RgbRingWaitableCommandAction;
}

export namespace RgbRingWaitableCommandAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing?: string,
    wait?: number,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRingCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_RGB_RING_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_RGB_RING = 1000,
  }

  export enum WaitCase { 
    _WAIT_NOT_SET = 0,
    WAIT = 2,
  }
}

export class RgbRingColorfulCommandAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(value: string): RgbRingColorfulCommandAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(): RgbRingColorfulCommandAction;

  getColor(): RgbColor | undefined;
  setColor(value?: RgbColor): RgbRingColorfulCommandAction;
  hasColor(): boolean;
  clearColor(): RgbRingColorfulCommandAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): RgbRingColorfulCommandAction.AsObject;
  static toObject(includeInstance: boolean, msg: RgbRingColorfulCommandAction): RgbRingColorfulCommandAction.AsObject;
  static serializeBinaryToWriter(message: RgbRingColorfulCommandAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): RgbRingColorfulCommandAction;
  static deserializeBinaryFromReader(message: RgbRingColorfulCommandAction, reader: jspb.BinaryReader): RgbRingColorfulCommandAction;
}

export namespace RgbRingColorfulCommandAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing?: string,
    color?: RgbColor.AsObject,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRingCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_RGB_RING_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_RGB_RING = 1000,
  }

  export enum ColorCase { 
    _COLOR_NOT_SET = 0,
    COLOR = 2,
  }
}

export class RgbRingSetEnabledAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(value: string): RgbRingSetEnabledAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(): RgbRingSetEnabledAction;

  getEnabled(): boolean;
  setEnabled(value: boolean): RgbRingSetEnabledAction;
  hasEnabled(): boolean;
  clearEnabled(): RgbRingSetEnabledAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): RgbRingSetEnabledAction.AsObject;
  static toObject(includeInstance: boolean, msg: RgbRingSetEnabledAction): RgbRingSetEnabledAction.AsObject;
  static serializeBinaryToWriter(message: RgbRingSetEnabledAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): RgbRingSetEnabledAction;
  static deserializeBinaryFromReader(message: RgbRingSetEnabledAction, reader: jspb.BinaryReader): RgbRingSetEnabledAction;
}

export namespace RgbRingSetEnabledAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing?: string,
    enabled?: boolean,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRingCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_RGB_RING_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_RGB_RING = 1000,
  }

  export enum EnabledCase { 
    _ENABLED_NOT_SET = 0,
    ENABLED = 2,
  }
}

export class RgbRingSetAllAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(value: string): RgbRingSetAllAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(): RgbRingSetAllAction;

  getColor(): RgbColor | undefined;
  setColor(value?: RgbColor): RgbRingSetAllAction;
  hasColor(): boolean;
  clearColor(): RgbRingSetAllAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): RgbRingSetAllAction.AsObject;
  static toObject(includeInstance: boolean, msg: RgbRingSetAllAction): RgbRingSetAllAction.AsObject;
  static serializeBinaryToWriter(message: RgbRingSetAllAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): RgbRingSetAllAction;
  static deserializeBinaryFromReader(message: RgbRingSetAllAction, reader: jspb.BinaryReader): RgbRingSetAllAction;
}

export namespace RgbRingSetAllAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing?: string,
    color?: RgbColor.AsObject,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRingCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_RGB_RING_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_RGB_RING = 1000,
  }

  export enum ColorCase { 
    _COLOR_NOT_SET = 0,
    COLOR = 2,
  }
}

export class RgbRingSetBrightnessAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(value: string): RgbRingSetBrightnessAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(): RgbRingSetBrightnessAction;

  getBrightness(): number;
  setBrightness(value: number): RgbRingSetBrightnessAction;
  hasBrightness(): boolean;
  clearBrightness(): RgbRingSetBrightnessAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): RgbRingSetBrightnessAction.AsObject;
  static toObject(includeInstance: boolean, msg: RgbRingSetBrightnessAction): RgbRingSetBrightnessAction.AsObject;
  static serializeBinaryToWriter(message: RgbRingSetBrightnessAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): RgbRingSetBrightnessAction;
  static deserializeBinaryFromReader(message: RgbRingSetBrightnessAction, reader: jspb.BinaryReader): RgbRingSetBrightnessAction;
}

export namespace RgbRingSetBrightnessAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing?: string,
    brightness?: number,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRingCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_RGB_RING_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_RGB_RING = 1000,
  }

  export enum BrightnessCase { 
    _BRIGHTNESS_NOT_SET = 0,
    BRIGHTNESS = 2,
  }
}

export class RgbRingBlankAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(value: string): RgbRingBlankAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(): RgbRingBlankAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): RgbRingBlankAction.AsObject;
  static toObject(includeInstance: boolean, msg: RgbRingBlankAction): RgbRingBlankAction.AsObject;
  static serializeBinaryToWriter(message: RgbRingBlankAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): RgbRingBlankAction;
  static deserializeBinaryFromReader(message: RgbRingBlankAction, reader: jspb.BinaryReader): RgbRingBlankAction;
}

export namespace RgbRingBlankAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRingCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_RGB_RING_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_RGB_RING = 1000,
  }
}

export class RgbRingRainbowAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(value: string): RgbRingRainbowAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(): RgbRingRainbowAction;

  getWait(): number;
  setWait(value: number): RgbRingRainbowAction;
  hasWait(): boolean;
  clearWait(): RgbRingRainbowAction;

  getRounds(): number;
  setRounds(value: number): RgbRingRainbowAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): RgbRingRainbowAction.AsObject;
  static toObject(includeInstance: boolean, msg: RgbRingRainbowAction): RgbRingRainbowAction.AsObject;
  static serializeBinaryToWriter(message: RgbRingRainbowAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): RgbRingRainbowAction;
  static deserializeBinaryFromReader(message: RgbRingRainbowAction, reader: jspb.BinaryReader): RgbRingRainbowAction;
}

export namespace RgbRingRainbowAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing?: string,
    wait?: number,
    rounds: number,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRingCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_RGB_RING_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_RGB_RING = 1000,
  }

  export enum WaitCase { 
    _WAIT_NOT_SET = 0,
    WAIT = 2,
  }
}

export class RgbRingProgressWheelStepAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(value: string): RgbRingProgressWheelStepAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(): RgbRingProgressWheelStepAction;

  getColor(): RgbColor | undefined;
  setColor(value?: RgbColor): RgbRingProgressWheelStepAction;
  hasColor(): boolean;
  clearColor(): RgbRingProgressWheelStepAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): RgbRingProgressWheelStepAction.AsObject;
  static toObject(includeInstance: boolean, msg: RgbRingProgressWheelStepAction): RgbRingProgressWheelStepAction.AsObject;
  static serializeBinaryToWriter(message: RgbRingProgressWheelStepAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): RgbRingProgressWheelStepAction;
  static deserializeBinaryFromReader(message: RgbRingProgressWheelStepAction, reader: jspb.BinaryReader): RgbRingProgressWheelStepAction;
}

export namespace RgbRingProgressWheelStepAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing?: string,
    color?: RgbColor.AsObject,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRingCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_RGB_RING_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_RGB_RING = 1000,
  }

  export enum ColorCase { 
    _COLOR_NOT_SET = 0,
    COLOR = 2,
  }
}

export class RgbRingPulseAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(value: string): RgbRingPulseAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(): RgbRingPulseAction;

  getRepetitions(): number;
  setRepetitions(value: number): RgbRingPulseAction;
  hasRepetitions(): boolean;
  clearRepetitions(): RgbRingPulseAction;

  getWait(): number;
  setWait(value: number): RgbRingPulseAction;
  hasWait(): boolean;
  clearWait(): RgbRingPulseAction;

  getColor(): RgbColor | undefined;
  setColor(value?: RgbColor): RgbRingPulseAction;
  hasColor(): boolean;
  clearColor(): RgbRingPulseAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): RgbRingPulseAction.AsObject;
  static toObject(includeInstance: boolean, msg: RgbRingPulseAction): RgbRingPulseAction.AsObject;
  static serializeBinaryToWriter(message: RgbRingPulseAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): RgbRingPulseAction;
  static deserializeBinaryFromReader(message: RgbRingPulseAction, reader: jspb.BinaryReader): RgbRingPulseAction;
}

export namespace RgbRingPulseAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing?: string,
    repetitions?: number,
    wait?: number,
    color?: RgbColor.AsObject,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRingCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_RGB_RING_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_RGB_RING = 1000,
  }

  export enum RepetitionsCase { 
    _REPETITIONS_NOT_SET = 0,
    REPETITIONS = 2,
  }

  export enum WaitCase { 
    _WAIT_NOT_SET = 0,
    WAIT = 3,
  }

  export enum ColorCase { 
    _COLOR_NOT_SET = 0,
    COLOR = 4,
  }
}

export class RgbRingBlinkAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(value: string): RgbRingBlinkAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(): RgbRingBlinkAction;

  getRepetitions(): number;
  setRepetitions(value: number): RgbRingBlinkAction;
  hasRepetitions(): boolean;
  clearRepetitions(): RgbRingBlinkAction;

  getWait(): number;
  setWait(value: number): RgbRingBlinkAction;
  hasWait(): boolean;
  clearWait(): RgbRingBlinkAction;

  getColor(): RgbColor | undefined;
  setColor(value?: RgbColor): RgbRingBlinkAction;
  hasColor(): boolean;
  clearColor(): RgbRingBlinkAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): RgbRingBlinkAction.AsObject;
  static toObject(includeInstance: boolean, msg: RgbRingBlinkAction): RgbRingBlinkAction.AsObject;
  static serializeBinaryToWriter(message: RgbRingBlinkAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): RgbRingBlinkAction;
  static deserializeBinaryFromReader(message: RgbRingBlinkAction, reader: jspb.BinaryReader): RgbRingBlinkAction;
}

export namespace RgbRingBlinkAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing?: string,
    repetitions?: number,
    wait?: number,
    color?: RgbColor.AsObject,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRingCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_RGB_RING_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_RGB_RING = 1000,
  }

  export enum RepetitionsCase { 
    _REPETITIONS_NOT_SET = 0,
    REPETITIONS = 2,
  }

  export enum WaitCase { 
    _WAIT_NOT_SET = 0,
    WAIT = 3,
  }

  export enum ColorCase { 
    _COLOR_NOT_SET = 0,
    COLOR = 4,
  }
}

export class RgbRingSpinningWheelAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(value: string): RgbRingSpinningWheelAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(): RgbRingSpinningWheelAction;

  getLength(): number;
  setLength(value: number): RgbRingSpinningWheelAction;
  hasLength(): boolean;
  clearLength(): RgbRingSpinningWheelAction;

  getRepetitions(): number;
  setRepetitions(value: number): RgbRingSpinningWheelAction;
  hasRepetitions(): boolean;
  clearRepetitions(): RgbRingSpinningWheelAction;

  getWait(): number;
  setWait(value: number): RgbRingSpinningWheelAction;
  hasWait(): boolean;
  clearWait(): RgbRingSpinningWheelAction;

  getColor(): RgbColor | undefined;
  setColor(value?: RgbColor): RgbRingSpinningWheelAction;
  hasColor(): boolean;
  clearColor(): RgbRingSpinningWheelAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): RgbRingSpinningWheelAction.AsObject;
  static toObject(includeInstance: boolean, msg: RgbRingSpinningWheelAction): RgbRingSpinningWheelAction.AsObject;
  static serializeBinaryToWriter(message: RgbRingSpinningWheelAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): RgbRingSpinningWheelAction;
  static deserializeBinaryFromReader(message: RgbRingSpinningWheelAction, reader: jspb.BinaryReader): RgbRingSpinningWheelAction;
}

export namespace RgbRingSpinningWheelAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing?: string,
    length?: number,
    repetitions?: number,
    wait?: number,
    color?: RgbColor.AsObject,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRingCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_RGB_RING_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_RGB_RING = 1000,
  }

  export enum LengthCase { 
    _LENGTH_NOT_SET = 0,
    LENGTH = 2,
  }

  export enum RepetitionsCase { 
    _REPETITIONS_NOT_SET = 0,
    REPETITIONS = 3,
  }

  export enum WaitCase { 
    _WAIT_NOT_SET = 0,
    WAIT = 4,
  }

  export enum ColorCase { 
    _COLOR_NOT_SET = 0,
    COLOR = 5,
  }
}

export class RgbRingProgressWheelAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(value: string): RgbRingProgressWheelAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(): RgbRingProgressWheelAction;

  getPercentage(): number;
  setPercentage(value: number): RgbRingProgressWheelAction;
  hasPercentage(): boolean;
  clearPercentage(): RgbRingProgressWheelAction;

  getColor(): RgbColor | undefined;
  setColor(value?: RgbColor): RgbRingProgressWheelAction;
  hasColor(): boolean;
  clearColor(): RgbRingProgressWheelAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): RgbRingProgressWheelAction.AsObject;
  static toObject(includeInstance: boolean, msg: RgbRingProgressWheelAction): RgbRingProgressWheelAction.AsObject;
  static serializeBinaryToWriter(message: RgbRingProgressWheelAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): RgbRingProgressWheelAction;
  static deserializeBinaryFromReader(message: RgbRingProgressWheelAction, reader: jspb.BinaryReader): RgbRingProgressWheelAction;
}

export namespace RgbRingProgressWheelAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing?: string,
    percentage?: number,
    color?: RgbColor.AsObject,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRingCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_RGB_RING_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_RGB_RING = 1000,
  }

  export enum PercentageCase { 
    _PERCENTAGE_NOT_SET = 0,
    PERCENTAGE = 2,
  }

  export enum ColorCase { 
    _COLOR_NOT_SET = 0,
    COLOR = 3,
  }
}

export class RgbRingFillUptoAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(value: string): RgbRingFillUptoAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(): RgbRingFillUptoAction;

  getPercentage(): number;
  setPercentage(value: number): RgbRingFillUptoAction;
  hasPercentage(): boolean;
  clearPercentage(): RgbRingFillUptoAction;

  getWait(): number;
  setWait(value: number): RgbRingFillUptoAction;
  hasWait(): boolean;
  clearWait(): RgbRingFillUptoAction;

  getColor(): RgbColor | undefined;
  setColor(value?: RgbColor): RgbRingFillUptoAction;
  hasColor(): boolean;
  clearColor(): RgbRingFillUptoAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): RgbRingFillUptoAction.AsObject;
  static toObject(includeInstance: boolean, msg: RgbRingFillUptoAction): RgbRingFillUptoAction.AsObject;
  static serializeBinaryToWriter(message: RgbRingFillUptoAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): RgbRingFillUptoAction;
  static deserializeBinaryFromReader(message: RgbRingFillUptoAction, reader: jspb.BinaryReader): RgbRingFillUptoAction;
}

export namespace RgbRingFillUptoAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing?: string,
    percentage?: number,
    wait?: number,
    color?: RgbColor.AsObject,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRingCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_RGB_RING_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_RGB_RING = 1000,
  }

  export enum PercentageCase { 
    _PERCENTAGE_NOT_SET = 0,
    PERCENTAGE = 2,
  }

  export enum WaitCase { 
    _WAIT_NOT_SET = 0,
    WAIT = 3,
  }

  export enum ColorCase { 
    _COLOR_NOT_SET = 0,
    COLOR = 4,
  }
}

export class RgbRingFillDownfromAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(value: string): RgbRingFillDownfromAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(): RgbRingFillDownfromAction;

  getPercentage(): number;
  setPercentage(value: number): RgbRingFillDownfromAction;
  hasPercentage(): boolean;
  clearPercentage(): RgbRingFillDownfromAction;

  getWait(): number;
  setWait(value: number): RgbRingFillDownfromAction;
  hasWait(): boolean;
  clearWait(): RgbRingFillDownfromAction;

  getColor(): RgbColor | undefined;
  setColor(value?: RgbColor): RgbRingFillDownfromAction;
  hasColor(): boolean;
  clearColor(): RgbRingFillDownfromAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): RgbRingFillDownfromAction.AsObject;
  static toObject(includeInstance: boolean, msg: RgbRingFillDownfromAction): RgbRingFillDownfromAction.AsObject;
  static serializeBinaryToWriter(message: RgbRingFillDownfromAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): RgbRingFillDownfromAction;
  static deserializeBinaryFromReader(message: RgbRingFillDownfromAction, reader: jspb.BinaryReader): RgbRingFillDownfromAction;
}

export namespace RgbRingFillDownfromAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing?: string,
    percentage?: number,
    wait?: number,
    color?: RgbColor.AsObject,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRingCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_RGB_RING_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_RGB_RING = 1000,
  }

  export enum PercentageCase { 
    _PERCENTAGE_NOT_SET = 0,
    PERCENTAGE = 2,
  }

  export enum WaitCase { 
    _WAIT_NOT_SET = 0,
    WAIT = 3,
  }

  export enum ColorCase { 
    _COLOR_NOT_SET = 0,
    COLOR = 4,
  }
}

export class RgbRingSequenceAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(value: string): RgbRingSequenceAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(): RgbRingSequenceAction;

  getSequenceList(): Array<RgbRingCommandAction>;
  setSequenceList(value: Array<RgbRingCommandAction>): RgbRingSequenceAction;
  clearSequenceList(): RgbRingSequenceAction;
  addSequence(value?: RgbRingCommandAction, index?: number): RgbRingCommandAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): RgbRingSequenceAction.AsObject;
  static toObject(includeInstance: boolean, msg: RgbRingSequenceAction): RgbRingSequenceAction.AsObject;
  static serializeBinaryToWriter(message: RgbRingSequenceAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): RgbRingSequenceAction;
  static deserializeBinaryFromReader(message: RgbRingSequenceAction, reader: jspb.BinaryReader): RgbRingSequenceAction;
}

export namespace RgbRingSequenceAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing?: string,
    sequenceList: Array<RgbRingCommandAction.AsObject>,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRingCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_RGB_RING_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_RGB_RING = 1000,
  }
}

export class RgbRingCommandEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(value: string): RgbRingCommandEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(): RgbRingCommandEvent;

  getCommandList(): Array<string>;
  setCommandList(value: Array<string>): RgbRingCommandEvent;
  clearCommandList(): RgbRingCommandEvent;
  addCommand(value: string, index?: number): RgbRingCommandEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): RgbRingCommandEvent.AsObject;
  static toObject(includeInstance: boolean, msg: RgbRingCommandEvent): RgbRingCommandEvent.AsObject;
  static serializeBinaryToWriter(message: RgbRingCommandEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): RgbRingCommandEvent;
  static deserializeBinaryFromReader(message: RgbRingCommandEvent, reader: jspb.BinaryReader): RgbRingCommandEvent;
}

export namespace RgbRingCommandEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing?: string,
    commandList: Array<string>,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRingCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_RGB_RING_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_RGB_RING = 1000,
  }
}

export class RgbRingState extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(value: string): RgbRingState;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing(): RgbRingState;

  getIsBusy(): boolean;
  setIsBusy(value: boolean): RgbRingState;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): RgbRingState.AsObject;
  static toObject(includeInstance: boolean, msg: RgbRingState): RgbRingState.AsObject;
  static serializeBinaryToWriter(message: RgbRingState, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): RgbRingState;
  static deserializeBinaryFromReader(message: RgbRingState, reader: jspb.BinaryReader): RgbRingState;
}

export namespace RgbRingState {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotRgbRing?: string,
    isBusy: boolean,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotRgbRingCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_RGB_RING_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_RGB_RING = 1000,
  }
}

export class RgbColorElement extends jspb.Message {
  getFloat(): number;
  setFloat(value: number): RgbColorElement;

  getInt64(): number;
  setInt64(value: number): RgbColorElement;

  getRgbColorElementCase(): RgbColorElement.RgbColorElementCase;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): RgbColorElement.AsObject;
  static toObject(includeInstance: boolean, msg: RgbColorElement): RgbColorElement.AsObject;
  static serializeBinaryToWriter(message: RgbColorElement, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): RgbColorElement;
  static deserializeBinaryFromReader(message: RgbColorElement, reader: jspb.BinaryReader): RgbColorElement;
}

export namespace RgbColorElement {
  export type AsObject = {
    pb_float: number,
    int64: number,
  }

  export enum RgbColorElementCase { 
    RGB_COLOR_ELEMENT_NOT_SET = 0,
    FLOAT = 1,
    INT64 = 2,
  }
}

export class RgbColor extends jspb.Message {
  getItemsList(): Array<RgbColorElement>;
  setItemsList(value: Array<RgbColorElement>): RgbColor;
  clearItemsList(): RgbColor;
  addItems(value?: RgbColorElement, index?: number): RgbColorElement;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): RgbColor.AsObject;
  static toObject(includeInstance: boolean, msg: RgbColor): RgbColor.AsObject;
  static serializeBinaryToWriter(message: RgbColor, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): RgbColor;
  static deserializeBinaryFromReader(message: RgbColor, reader: jspb.BinaryReader): RgbColor;
}

export namespace RgbColor {
  export type AsObject = {
    itemsList: Array<RgbColorElement.AsObject>,
  }
}

export class RPiConnectAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotRpiConnect(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotRpiConnect(value: string): RPiConnectAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotRpiConnect(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotRpiConnect(): RPiConnectAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): RPiConnectAction.AsObject;
  static toObject(includeInstance: boolean, msg: RPiConnectAction): RPiConnectAction.AsObject;
  static serializeBinaryToWriter(message: RPiConnectAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): RPiConnectAction;
  static deserializeBinaryFromReader(message: RPiConnectAction, reader: jspb.BinaryReader): RPiConnectAction;
}

export namespace RPiConnectAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotRpiConnect?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotRpiConnectCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_RPI_CONNECT_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_RPI_CONNECT = 1000,
  }
}

export class RPiConnectEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotRpiConnect(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotRpiConnect(value: string): RPiConnectEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotRpiConnect(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotRpiConnect(): RPiConnectEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): RPiConnectEvent.AsObject;
  static toObject(includeInstance: boolean, msg: RPiConnectEvent): RPiConnectEvent.AsObject;
  static serializeBinaryToWriter(message: RPiConnectEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): RPiConnectEvent;
  static deserializeBinaryFromReader(message: RPiConnectEvent, reader: jspb.BinaryReader): RPiConnectEvent;
}

export namespace RPiConnectEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotRpiConnect?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotRpiConnectCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_RPI_CONNECT_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_RPI_CONNECT = 1000,
  }
}

export class RPiConnectStartDownloadingAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotRpiConnect(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotRpiConnect(value: string): RPiConnectStartDownloadingAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotRpiConnect(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotRpiConnect(): RPiConnectStartDownloadingAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): RPiConnectStartDownloadingAction.AsObject;
  static toObject(includeInstance: boolean, msg: RPiConnectStartDownloadingAction): RPiConnectStartDownloadingAction.AsObject;
  static serializeBinaryToWriter(message: RPiConnectStartDownloadingAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): RPiConnectStartDownloadingAction;
  static deserializeBinaryFromReader(message: RPiConnectStartDownloadingAction, reader: jspb.BinaryReader): RPiConnectStartDownloadingAction;
}

export namespace RPiConnectStartDownloadingAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotRpiConnect?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotRpiConnectCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_RPI_CONNECT_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_RPI_CONNECT = 1000,
  }
}

export class RPiConnectDoneDownloadingAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotRpiConnect(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotRpiConnect(value: string): RPiConnectDoneDownloadingAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotRpiConnect(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotRpiConnect(): RPiConnectDoneDownloadingAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): RPiConnectDoneDownloadingAction.AsObject;
  static toObject(includeInstance: boolean, msg: RPiConnectDoneDownloadingAction): RPiConnectDoneDownloadingAction.AsObject;
  static serializeBinaryToWriter(message: RPiConnectDoneDownloadingAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): RPiConnectDoneDownloadingAction;
  static deserializeBinaryFromReader(message: RPiConnectDoneDownloadingAction, reader: jspb.BinaryReader): RPiConnectDoneDownloadingAction;
}

export namespace RPiConnectDoneDownloadingAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotRpiConnect?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotRpiConnectCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_RPI_CONNECT_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_RPI_CONNECT = 1000,
  }
}

export class RPiConnectSetPendingAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotRpiConnect(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotRpiConnect(value: string): RPiConnectSetPendingAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotRpiConnect(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotRpiConnect(): RPiConnectSetPendingAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): RPiConnectSetPendingAction.AsObject;
  static toObject(includeInstance: boolean, msg: RPiConnectSetPendingAction): RPiConnectSetPendingAction.AsObject;
  static serializeBinaryToWriter(message: RPiConnectSetPendingAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): RPiConnectSetPendingAction;
  static deserializeBinaryFromReader(message: RPiConnectSetPendingAction, reader: jspb.BinaryReader): RPiConnectSetPendingAction;
}

export namespace RPiConnectSetPendingAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotRpiConnect?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotRpiConnectCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_RPI_CONNECT_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_RPI_CONNECT = 1000,
  }
}

export class RPiConnectStatus extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotRpiConnect(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotRpiConnect(value: string): RPiConnectStatus;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotRpiConnect(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotRpiConnect(): RPiConnectStatus;

  getScreenSharingSessions(): number;
  setScreenSharingSessions(value: number): RPiConnectStatus;
  hasScreenSharingSessions(): boolean;
  clearScreenSharingSessions(): RPiConnectStatus;

  getRemoteShellSessions(): number;
  setRemoteShellSessions(value: number): RPiConnectStatus;
  hasRemoteShellSessions(): boolean;
  clearRemoteShellSessions(): RPiConnectStatus;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): RPiConnectStatus.AsObject;
  static toObject(includeInstance: boolean, msg: RPiConnectStatus): RPiConnectStatus.AsObject;
  static serializeBinaryToWriter(message: RPiConnectStatus, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): RPiConnectStatus;
  static deserializeBinaryFromReader(message: RPiConnectStatus, reader: jspb.BinaryReader): RPiConnectStatus;
}

export namespace RPiConnectStatus {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotRpiConnect?: string,
    screenSharingSessions?: number,
    remoteShellSessions?: number,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotRpiConnectCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_RPI_CONNECT_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_RPI_CONNECT = 1000,
  }

  export enum ScreenSharingSessionsCase { 
    _SCREEN_SHARING_SESSIONS_NOT_SET = 0,
    SCREEN_SHARING_SESSIONS = 2,
  }

  export enum RemoteShellSessionsCase { 
    _REMOTE_SHELL_SESSIONS_NOT_SET = 0,
    REMOTE_SHELL_SESSIONS = 3,
  }
}

export class RPiConnectSetStatusAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotRpiConnect(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotRpiConnect(value: string): RPiConnectSetStatusAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotRpiConnect(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotRpiConnect(): RPiConnectSetStatusAction;

  getIsInstalled(): boolean;
  setIsInstalled(value: boolean): RPiConnectSetStatusAction;

  getIsSignedIn(): boolean;
  setIsSignedIn(value: boolean): RPiConnectSetStatusAction;
  hasIsSignedIn(): boolean;
  clearIsSignedIn(): RPiConnectSetStatusAction;

  getStatus(): RPiConnectStatus | undefined;
  setStatus(value?: RPiConnectStatus): RPiConnectSetStatusAction;
  hasStatus(): boolean;
  clearStatus(): RPiConnectSetStatusAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): RPiConnectSetStatusAction.AsObject;
  static toObject(includeInstance: boolean, msg: RPiConnectSetStatusAction): RPiConnectSetStatusAction.AsObject;
  static serializeBinaryToWriter(message: RPiConnectSetStatusAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): RPiConnectSetStatusAction;
  static deserializeBinaryFromReader(message: RPiConnectSetStatusAction, reader: jspb.BinaryReader): RPiConnectSetStatusAction;
}

export namespace RPiConnectSetStatusAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotRpiConnect?: string,
    isInstalled: boolean,
    isSignedIn?: boolean,
    status?: RPiConnectStatus.AsObject,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotRpiConnectCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_RPI_CONNECT_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_RPI_CONNECT = 1000,
  }

  export enum IsSignedInCase { 
    _IS_SIGNED_IN_NOT_SET = 0,
    IS_SIGNED_IN = 3,
  }

  export enum StatusCase { 
    _STATUS_NOT_SET = 0,
    STATUS = 4,
  }
}

export class RPiConnectLoginEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotRpiConnect(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotRpiConnect(value: string): RPiConnectLoginEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotRpiConnect(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotRpiConnect(): RPiConnectLoginEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): RPiConnectLoginEvent.AsObject;
  static toObject(includeInstance: boolean, msg: RPiConnectLoginEvent): RPiConnectLoginEvent.AsObject;
  static serializeBinaryToWriter(message: RPiConnectLoginEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): RPiConnectLoginEvent;
  static deserializeBinaryFromReader(message: RPiConnectLoginEvent, reader: jspb.BinaryReader): RPiConnectLoginEvent;
}

export namespace RPiConnectLoginEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotRpiConnect?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotRpiConnectCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_RPI_CONNECT_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_RPI_CONNECT = 1000,
  }
}

export class RPiConnectUpdateServiceStateAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotRpiConnect(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotRpiConnect(value: string): RPiConnectUpdateServiceStateAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotRpiConnect(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotRpiConnect(): RPiConnectUpdateServiceStateAction;

  getIsActive(): boolean;
  setIsActive(value: boolean): RPiConnectUpdateServiceStateAction;
  hasIsActive(): boolean;
  clearIsActive(): RPiConnectUpdateServiceStateAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): RPiConnectUpdateServiceStateAction.AsObject;
  static toObject(includeInstance: boolean, msg: RPiConnectUpdateServiceStateAction): RPiConnectUpdateServiceStateAction.AsObject;
  static serializeBinaryToWriter(message: RPiConnectUpdateServiceStateAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): RPiConnectUpdateServiceStateAction;
  static deserializeBinaryFromReader(message: RPiConnectUpdateServiceStateAction, reader: jspb.BinaryReader): RPiConnectUpdateServiceStateAction;
}

export namespace RPiConnectUpdateServiceStateAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotRpiConnect?: string,
    isActive?: boolean,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotRpiConnectCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_RPI_CONNECT_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_RPI_CONNECT = 1000,
  }

  export enum IsActiveCase { 
    _IS_ACTIVE_NOT_SET = 0,
    IS_ACTIVE = 2,
  }
}

export class RPiConnectState extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotRpiConnect(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotRpiConnect(value: string): RPiConnectState;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotRpiConnect(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotRpiConnect(): RPiConnectState;

  getIsDownloading(): boolean;
  setIsDownloading(value: boolean): RPiConnectState;
  hasIsDownloading(): boolean;
  clearIsDownloading(): RPiConnectState;

  getIsActive(): boolean;
  setIsActive(value: boolean): RPiConnectState;
  hasIsActive(): boolean;
  clearIsActive(): RPiConnectState;

  getIsInstalled(): boolean;
  setIsInstalled(value: boolean): RPiConnectState;
  hasIsInstalled(): boolean;
  clearIsInstalled(): RPiConnectState;

  getIsSignedIn(): boolean;
  setIsSignedIn(value: boolean): RPiConnectState;
  hasIsSignedIn(): boolean;
  clearIsSignedIn(): RPiConnectState;

  getStatus(): RPiConnectStatus | undefined;
  setStatus(value?: RPiConnectStatus): RPiConnectState;
  hasStatus(): boolean;
  clearStatus(): RPiConnectState;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): RPiConnectState.AsObject;
  static toObject(includeInstance: boolean, msg: RPiConnectState): RPiConnectState.AsObject;
  static serializeBinaryToWriter(message: RPiConnectState, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): RPiConnectState;
  static deserializeBinaryFromReader(message: RPiConnectState, reader: jspb.BinaryReader): RPiConnectState;
}

export namespace RPiConnectState {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotRpiConnect?: string,
    isDownloading?: boolean,
    isActive?: boolean,
    isInstalled?: boolean,
    isSignedIn?: boolean,
    status?: RPiConnectStatus.AsObject,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotRpiConnectCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_RPI_CONNECT_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_RPI_CONNECT = 1000,
  }

  export enum IsDownloadingCase { 
    _IS_DOWNLOADING_NOT_SET = 0,
    IS_DOWNLOADING = 2,
  }

  export enum IsActiveCase { 
    _IS_ACTIVE_NOT_SET = 0,
    IS_ACTIVE = 3,
  }

  export enum IsInstalledCase { 
    _IS_INSTALLED_NOT_SET = 0,
    IS_INSTALLED = 4,
  }

  export enum IsSignedInCase { 
    _IS_SIGNED_IN_NOT_SET = 0,
    IS_SIGNED_IN = 5,
  }

  export enum StatusCase { 
    _STATUS_NOT_SET = 0,
    STATUS = 6,
  }
}

export class SensorsAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotSensors(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotSensors(value: string): SensorsAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotSensors(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotSensors(): SensorsAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SensorsAction.AsObject;
  static toObject(includeInstance: boolean, msg: SensorsAction): SensorsAction.AsObject;
  static serializeBinaryToWriter(message: SensorsAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SensorsAction;
  static deserializeBinaryFromReader(message: SensorsAction, reader: jspb.BinaryReader): SensorsAction;
}

export namespace SensorsAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotSensors?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotSensorsCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_SENSORS_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_SENSORS = 1000,
  }
}

export class SensorsReportReadingAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotSensors(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotSensors(value: string): SensorsReportReadingAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotSensors(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotSensors(): SensorsReportReadingAction;

  getSensor(): Sensor;
  setSensor(value: Sensor): SensorsReportReadingAction;

  getReading(): number;
  setReading(value: number): SensorsReportReadingAction;

  getTimestamp(): number;
  setTimestamp(value: number): SensorsReportReadingAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SensorsReportReadingAction.AsObject;
  static toObject(includeInstance: boolean, msg: SensorsReportReadingAction): SensorsReportReadingAction.AsObject;
  static serializeBinaryToWriter(message: SensorsReportReadingAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SensorsReportReadingAction;
  static deserializeBinaryFromReader(message: SensorsReportReadingAction, reader: jspb.BinaryReader): SensorsReportReadingAction;
}

export namespace SensorsReportReadingAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotSensors?: string,
    sensor: Sensor,
    reading: number,
    timestamp: number,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotSensorsCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_SENSORS_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_SENSORS = 1000,
  }
}

export class SensorState extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotSensors(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotSensors(value: string): SensorState;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotSensors(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotSensors(): SensorState;

  getValue(): number;
  setValue(value: number): SensorState;
  hasValue(): boolean;
  clearValue(): SensorState;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SensorState.AsObject;
  static toObject(includeInstance: boolean, msg: SensorState): SensorState.AsObject;
  static serializeBinaryToWriter(message: SensorState, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SensorState;
  static deserializeBinaryFromReader(message: SensorState, reader: jspb.BinaryReader): SensorState;
}

export namespace SensorState {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotSensors?: string,
    value?: number,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotSensorsCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_SENSORS_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_SENSORS = 1000,
  }

  export enum ValueCase { 
    _VALUE_NOT_SET = 0,
    VALUE = 2,
  }
}

export class SensorsState extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotSensors(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotSensors(value: string): SensorsState;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotSensors(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotSensors(): SensorsState;

  getTemperature(): SensorState | undefined;
  setTemperature(value?: SensorState): SensorsState;
  hasTemperature(): boolean;
  clearTemperature(): SensorsState;

  getLight(): SensorState | undefined;
  setLight(value?: SensorState): SensorsState;
  hasLight(): boolean;
  clearLight(): SensorsState;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SensorsState.AsObject;
  static toObject(includeInstance: boolean, msg: SensorsState): SensorsState.AsObject;
  static serializeBinaryToWriter(message: SensorsState, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SensorsState;
  static deserializeBinaryFromReader(message: SensorsState, reader: jspb.BinaryReader): SensorsState;
}

export namespace SensorsState {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotSensors?: string,
    temperature?: SensorState.AsObject,
    light?: SensorState.AsObject,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotSensorsCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_SENSORS_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_SENSORS = 1000,
  }

  export enum TemperatureCase { 
    _TEMPERATURE_NOT_SET = 0,
    TEMPERATURE = 2,
  }

  export enum LightCase { 
    _LIGHT_NOT_SET = 0,
    LIGHT = 3,
  }
}

export class SpeechRecognitionAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognition(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognition(value: string): SpeechRecognitionAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognition(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognition(): SpeechRecognitionAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SpeechRecognitionAction.AsObject;
  static toObject(includeInstance: boolean, msg: SpeechRecognitionAction): SpeechRecognitionAction.AsObject;
  static serializeBinaryToWriter(message: SpeechRecognitionAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SpeechRecognitionAction;
  static deserializeBinaryFromReader(message: SpeechRecognitionAction, reader: jspb.BinaryReader): SpeechRecognitionAction;
}

export namespace SpeechRecognitionAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognition?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognitionCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_SPEECH_RECOGNITION_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_SPEECH_RECOGNITION = 1000,
  }
}

export class SpeechRecognitionSetSelectedEngineAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognition(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognition(value: string): SpeechRecognitionSetSelectedEngineAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognition(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognition(): SpeechRecognitionSetSelectedEngineAction;

  getEngineName(): SpeechRecognitionEngineName;
  setEngineName(value: SpeechRecognitionEngineName): SpeechRecognitionSetSelectedEngineAction;
  hasEngineName(): boolean;
  clearEngineName(): SpeechRecognitionSetSelectedEngineAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SpeechRecognitionSetSelectedEngineAction.AsObject;
  static toObject(includeInstance: boolean, msg: SpeechRecognitionSetSelectedEngineAction): SpeechRecognitionSetSelectedEngineAction.AsObject;
  static serializeBinaryToWriter(message: SpeechRecognitionSetSelectedEngineAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SpeechRecognitionSetSelectedEngineAction;
  static deserializeBinaryFromReader(message: SpeechRecognitionSetSelectedEngineAction, reader: jspb.BinaryReader): SpeechRecognitionSetSelectedEngineAction;
}

export namespace SpeechRecognitionSetSelectedEngineAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognition?: string,
    engineName?: SpeechRecognitionEngineName,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognitionCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_SPEECH_RECOGNITION_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_SPEECH_RECOGNITION = 1000,
  }

  export enum EngineNameCase { 
    _ENGINE_NAME_NOT_SET = 0,
    ENGINE_NAME = 2,
  }
}

export class SpeechRecognitionSetIsIntentsActiveAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognition(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognition(value: string): SpeechRecognitionSetIsIntentsActiveAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognition(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognition(): SpeechRecognitionSetIsIntentsActiveAction;

  getIsActive(): boolean;
  setIsActive(value: boolean): SpeechRecognitionSetIsIntentsActiveAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SpeechRecognitionSetIsIntentsActiveAction.AsObject;
  static toObject(includeInstance: boolean, msg: SpeechRecognitionSetIsIntentsActiveAction): SpeechRecognitionSetIsIntentsActiveAction.AsObject;
  static serializeBinaryToWriter(message: SpeechRecognitionSetIsIntentsActiveAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SpeechRecognitionSetIsIntentsActiveAction;
  static deserializeBinaryFromReader(message: SpeechRecognitionSetIsIntentsActiveAction, reader: jspb.BinaryReader): SpeechRecognitionSetIsIntentsActiveAction;
}

export namespace SpeechRecognitionSetIsIntentsActiveAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognition?: string,
    isActive: boolean,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognitionCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_SPEECH_RECOGNITION_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_SPEECH_RECOGNITION = 1000,
  }
}

export class SpeechRecognitionSetIsAssistantActiveAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognition(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognition(value: string): SpeechRecognitionSetIsAssistantActiveAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognition(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognition(): SpeechRecognitionSetIsAssistantActiveAction;

  getIsActive(): boolean;
  setIsActive(value: boolean): SpeechRecognitionSetIsAssistantActiveAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SpeechRecognitionSetIsAssistantActiveAction.AsObject;
  static toObject(includeInstance: boolean, msg: SpeechRecognitionSetIsAssistantActiveAction): SpeechRecognitionSetIsAssistantActiveAction.AsObject;
  static serializeBinaryToWriter(message: SpeechRecognitionSetIsAssistantActiveAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SpeechRecognitionSetIsAssistantActiveAction;
  static deserializeBinaryFromReader(message: SpeechRecognitionSetIsAssistantActiveAction, reader: jspb.BinaryReader): SpeechRecognitionSetIsAssistantActiveAction;
}

export namespace SpeechRecognitionSetIsAssistantActiveAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognition?: string,
    isActive: boolean,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognitionCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_SPEECH_RECOGNITION_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_SPEECH_RECOGNITION = 1000,
  }
}

export class SpeechRecognitionIntent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognition(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognition(value: string): SpeechRecognitionIntent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognition(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognition(): SpeechRecognitionIntent;

  getPhrase(): SpeechRecognitionIntent.Phrase | undefined;
  setPhrase(value?: SpeechRecognitionIntent.Phrase): SpeechRecognitionIntent;
  hasPhrase(): boolean;
  clearPhrase(): SpeechRecognitionIntent;

  getAction(): SpeechRecognitionIntent.Action | undefined;
  setAction(value?: SpeechRecognitionIntent.Action): SpeechRecognitionIntent;
  hasAction(): boolean;
  clearAction(): SpeechRecognitionIntent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SpeechRecognitionIntent.AsObject;
  static toObject(includeInstance: boolean, msg: SpeechRecognitionIntent): SpeechRecognitionIntent.AsObject;
  static serializeBinaryToWriter(message: SpeechRecognitionIntent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SpeechRecognitionIntent;
  static deserializeBinaryFromReader(message: SpeechRecognitionIntent, reader: jspb.BinaryReader): SpeechRecognitionIntent;
}

export namespace SpeechRecognitionIntent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognition?: string,
    phrase?: SpeechRecognitionIntent.Phrase.AsObject,
    action?: SpeechRecognitionIntent.Action.AsObject,
  }

  export class Phrase1 extends jspb.Message {
    getItemsList(): Array<string>;
    setItemsList(value: Array<string>): Phrase1;
    clearItemsList(): Phrase1;
    addItems(value: string, index?: number): Phrase1;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): Phrase1.AsObject;
    static toObject(includeInstance: boolean, msg: Phrase1): Phrase1.AsObject;
    static serializeBinaryToWriter(message: Phrase1, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): Phrase1;
    static deserializeBinaryFromReader(message: Phrase1, reader: jspb.BinaryReader): Phrase1;
  }

  export namespace Phrase1 {
    export type AsObject = {
      itemsList: Array<string>,
    }
  }


  export class Phrase extends jspb.Message {
    getList(): SpeechRecognitionIntent.Phrase1 | undefined;
    setList(value?: SpeechRecognitionIntent.Phrase1): Phrase;
    hasList(): boolean;
    clearList(): Phrase;

    getString(): string;
    setString(value: string): Phrase;

    getPhraseCase(): Phrase.PhraseCase;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): Phrase.AsObject;
    static toObject(includeInstance: boolean, msg: Phrase): Phrase.AsObject;
    static serializeBinaryToWriter(message: Phrase, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): Phrase;
    static deserializeBinaryFromReader(message: Phrase, reader: jspb.BinaryReader): Phrase;
  }

  export namespace Phrase {
    export type AsObject = {
      list?: SpeechRecognitionIntent.Phrase1.AsObject,
      string: string,
    }

    export enum PhraseCase { 
      PHRASE_NOT_SET = 0,
      LIST = 1,
      STRING = 2,
    }
  }


  export class Action2 extends jspb.Message {
    getItemsList(): Array<SpeechRecognitionIntent.Action>;
    setItemsList(value: Array<SpeechRecognitionIntent.Action>): Action2;
    clearItemsList(): Action2;
    addItems(value?: SpeechRecognitionIntent.Action, index?: number): SpeechRecognitionIntent.Action;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): Action2.AsObject;
    static toObject(includeInstance: boolean, msg: Action2): Action2.AsObject;
    static serializeBinaryToWriter(message: Action2, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): Action2;
    static deserializeBinaryFromReader(message: Action2, reader: jspb.BinaryReader): Action2;
  }

  export namespace Action2 {
    export type AsObject = {
      itemsList: Array<SpeechRecognitionIntent.Action.AsObject>,
    }
  }


  export class Action extends jspb.Message {
    getUboAction(): SpeechRecognitionIntent.Action | undefined;
    setUboAction(value?: SpeechRecognitionIntent.Action): Action;
    hasUboAction(): boolean;
    clearUboAction(): Action;

    getList(): SpeechRecognitionIntent.Action2 | undefined;
    setList(value?: SpeechRecognitionIntent.Action2): Action;
    hasList(): boolean;
    clearList(): Action;

    getActionCase(): Action.ActionCase;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): Action.AsObject;
    static toObject(includeInstance: boolean, msg: Action): Action.AsObject;
    static serializeBinaryToWriter(message: Action, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): Action;
    static deserializeBinaryFromReader(message: Action, reader: jspb.BinaryReader): Action;
  }

  export namespace Action {
    export type AsObject = {
      uboAction?: SpeechRecognitionIntent.Action.AsObject,
      list?: SpeechRecognitionIntent.Action2.AsObject,
    }

    export enum ActionCase { 
      ACTION_NOT_SET = 0,
      UBO_ACTION = 1,
      LIST = 2,
    }
  }


  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognitionCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_SPEECH_RECOGNITION_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_SPEECH_RECOGNITION = 1000,
  }
}

export class SpeechRecognitionReportWakeWordDetectionAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognition(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognition(value: string): SpeechRecognitionReportWakeWordDetectionAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognition(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognition(): SpeechRecognitionReportWakeWordDetectionAction;

  getWakeWord(): string;
  setWakeWord(value: string): SpeechRecognitionReportWakeWordDetectionAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SpeechRecognitionReportWakeWordDetectionAction.AsObject;
  static toObject(includeInstance: boolean, msg: SpeechRecognitionReportWakeWordDetectionAction): SpeechRecognitionReportWakeWordDetectionAction.AsObject;
  static serializeBinaryToWriter(message: SpeechRecognitionReportWakeWordDetectionAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SpeechRecognitionReportWakeWordDetectionAction;
  static deserializeBinaryFromReader(message: SpeechRecognitionReportWakeWordDetectionAction, reader: jspb.BinaryReader): SpeechRecognitionReportWakeWordDetectionAction;
}

export namespace SpeechRecognitionReportWakeWordDetectionAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognition?: string,
    wakeWord: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognitionCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_SPEECH_RECOGNITION_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_SPEECH_RECOGNITION = 1000,
  }
}

export class SpeechRecognitionReportIntentDetectionAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognition(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognition(value: string): SpeechRecognitionReportIntentDetectionAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognition(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognition(): SpeechRecognitionReportIntentDetectionAction;

  getIntent(): SpeechRecognitionIntent | undefined;
  setIntent(value?: SpeechRecognitionIntent): SpeechRecognitionReportIntentDetectionAction;
  hasIntent(): boolean;
  clearIntent(): SpeechRecognitionReportIntentDetectionAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SpeechRecognitionReportIntentDetectionAction.AsObject;
  static toObject(includeInstance: boolean, msg: SpeechRecognitionReportIntentDetectionAction): SpeechRecognitionReportIntentDetectionAction.AsObject;
  static serializeBinaryToWriter(message: SpeechRecognitionReportIntentDetectionAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SpeechRecognitionReportIntentDetectionAction;
  static deserializeBinaryFromReader(message: SpeechRecognitionReportIntentDetectionAction, reader: jspb.BinaryReader): SpeechRecognitionReportIntentDetectionAction;
}

export namespace SpeechRecognitionReportIntentDetectionAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognition?: string,
    intent?: SpeechRecognitionIntent.AsObject,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognitionCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_SPEECH_RECOGNITION_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_SPEECH_RECOGNITION = 1000,
  }
}

export class SpeechRecognitionReportSpeechAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognition(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognition(value: string): SpeechRecognitionReportSpeechAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognition(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognition(): SpeechRecognitionReportSpeechAction;

  getEngineName(): SpeechRecognitionEngineName;
  setEngineName(value: SpeechRecognitionEngineName): SpeechRecognitionReportSpeechAction;

  getText(): string;
  setText(value: string): SpeechRecognitionReportSpeechAction;

  getAudio(): Uint8Array | string;
  getAudio_asU8(): Uint8Array;
  getAudio_asB64(): string;
  setAudio(value: Uint8Array | string): SpeechRecognitionReportSpeechAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SpeechRecognitionReportSpeechAction.AsObject;
  static toObject(includeInstance: boolean, msg: SpeechRecognitionReportSpeechAction): SpeechRecognitionReportSpeechAction.AsObject;
  static serializeBinaryToWriter(message: SpeechRecognitionReportSpeechAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SpeechRecognitionReportSpeechAction;
  static deserializeBinaryFromReader(message: SpeechRecognitionReportSpeechAction, reader: jspb.BinaryReader): SpeechRecognitionReportSpeechAction;
}

export namespace SpeechRecognitionReportSpeechAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognition?: string,
    engineName: SpeechRecognitionEngineName,
    text: string,
    audio: Uint8Array | string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognitionCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_SPEECH_RECOGNITION_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_SPEECH_RECOGNITION = 1000,
  }
}

export class SpeechRecognitionEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognition(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognition(value: string): SpeechRecognitionEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognition(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognition(): SpeechRecognitionEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SpeechRecognitionEvent.AsObject;
  static toObject(includeInstance: boolean, msg: SpeechRecognitionEvent): SpeechRecognitionEvent.AsObject;
  static serializeBinaryToWriter(message: SpeechRecognitionEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SpeechRecognitionEvent;
  static deserializeBinaryFromReader(message: SpeechRecognitionEvent, reader: jspb.BinaryReader): SpeechRecognitionEvent;
}

export namespace SpeechRecognitionEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognition?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognitionCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_SPEECH_RECOGNITION_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_SPEECH_RECOGNITION = 1000,
  }
}

export class SpeechRecognitionReportTextEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognition(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognition(value: string): SpeechRecognitionReportTextEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognition(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognition(): SpeechRecognitionReportTextEvent;

  getTimestamp(): number;
  setTimestamp(value: number): SpeechRecognitionReportTextEvent;

  getText(): string;
  setText(value: string): SpeechRecognitionReportTextEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SpeechRecognitionReportTextEvent.AsObject;
  static toObject(includeInstance: boolean, msg: SpeechRecognitionReportTextEvent): SpeechRecognitionReportTextEvent.AsObject;
  static serializeBinaryToWriter(message: SpeechRecognitionReportTextEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SpeechRecognitionReportTextEvent;
  static deserializeBinaryFromReader(message: SpeechRecognitionReportTextEvent, reader: jspb.BinaryReader): SpeechRecognitionReportTextEvent;
}

export namespace SpeechRecognitionReportTextEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognition?: string,
    timestamp: number,
    text: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognitionCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_SPEECH_RECOGNITION_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_SPEECH_RECOGNITION = 1000,
  }
}

export class SpeechRecognitionState extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognition(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognition(value: string): SpeechRecognitionState;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognition(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognition(): SpeechRecognitionState;

  getSelectedEngine(): SpeechRecognitionEngineName;
  setSelectedEngine(value: SpeechRecognitionEngineName): SpeechRecognitionState;
  hasSelectedEngine(): boolean;
  clearSelectedEngine(): SpeechRecognitionState;

  getIntentsList(): Array<SpeechRecognitionIntent>;
  setIntentsList(value: Array<SpeechRecognitionIntent>): SpeechRecognitionState;
  clearIntentsList(): SpeechRecognitionState;
  addIntents(value?: SpeechRecognitionIntent, index?: number): SpeechRecognitionIntent;

  getIsIntentsActive(): boolean;
  setIsIntentsActive(value: boolean): SpeechRecognitionState;
  hasIsIntentsActive(): boolean;
  clearIsIntentsActive(): SpeechRecognitionState;

  getIsAssistantActive(): boolean;
  setIsAssistantActive(value: boolean): SpeechRecognitionState;
  hasIsAssistantActive(): boolean;
  clearIsAssistantActive(): SpeechRecognitionState;

  getStatus(): SpeechRecognitionStatus;
  setStatus(value: SpeechRecognitionStatus): SpeechRecognitionState;
  hasStatus(): boolean;
  clearStatus(): SpeechRecognitionState;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SpeechRecognitionState.AsObject;
  static toObject(includeInstance: boolean, msg: SpeechRecognitionState): SpeechRecognitionState.AsObject;
  static serializeBinaryToWriter(message: SpeechRecognitionState, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SpeechRecognitionState;
  static deserializeBinaryFromReader(message: SpeechRecognitionState, reader: jspb.BinaryReader): SpeechRecognitionState;
}

export namespace SpeechRecognitionState {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognition?: string,
    selectedEngine?: SpeechRecognitionEngineName,
    intentsList: Array<SpeechRecognitionIntent.AsObject>,
    isIntentsActive?: boolean,
    isAssistantActive?: boolean,
    status?: SpeechRecognitionStatus,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechRecognitionCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_SPEECH_RECOGNITION_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_SPEECH_RECOGNITION = 1000,
  }

  export enum SelectedEngineCase { 
    _SELECTED_ENGINE_NOT_SET = 0,
    SELECTED_ENGINE = 2,
  }

  export enum IsIntentsActiveCase { 
    _IS_INTENTS_ACTIVE_NOT_SET = 0,
    IS_INTENTS_ACTIVE = 4,
  }

  export enum IsAssistantActiveCase { 
    _IS_ASSISTANT_ACTIVE_NOT_SET = 0,
    IS_ASSISTANT_ACTIVE = 5,
  }

  export enum StatusCase { 
    _STATUS_NOT_SET = 0,
    STATUS = 6,
  }
}

export class SpeechSynthesisAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechSynthesis(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechSynthesis(value: string): SpeechSynthesisAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechSynthesis(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechSynthesis(): SpeechSynthesisAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SpeechSynthesisAction.AsObject;
  static toObject(includeInstance: boolean, msg: SpeechSynthesisAction): SpeechSynthesisAction.AsObject;
  static serializeBinaryToWriter(message: SpeechSynthesisAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SpeechSynthesisAction;
  static deserializeBinaryFromReader(message: SpeechSynthesisAction, reader: jspb.BinaryReader): SpeechSynthesisAction;
}

export namespace SpeechSynthesisAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotSpeechSynthesis?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechSynthesisCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_SPEECH_SYNTHESIS_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_SPEECH_SYNTHESIS = 1000,
  }
}

export class SpeechSynthesisEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechSynthesis(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechSynthesis(value: string): SpeechSynthesisEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechSynthesis(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechSynthesis(): SpeechSynthesisEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SpeechSynthesisEvent.AsObject;
  static toObject(includeInstance: boolean, msg: SpeechSynthesisEvent): SpeechSynthesisEvent.AsObject;
  static serializeBinaryToWriter(message: SpeechSynthesisEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SpeechSynthesisEvent;
  static deserializeBinaryFromReader(message: SpeechSynthesisEvent, reader: jspb.BinaryReader): SpeechSynthesisEvent;
}

export namespace SpeechSynthesisEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotSpeechSynthesis?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechSynthesisCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_SPEECH_SYNTHESIS_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_SPEECH_SYNTHESIS = 1000,
  }
}

export class SpeechSynthesisUpdateAccessKeyStatus extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechSynthesis(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechSynthesis(value: string): SpeechSynthesisUpdateAccessKeyStatus;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechSynthesis(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechSynthesis(): SpeechSynthesisUpdateAccessKeyStatus;

  getIsAccessKeySet(): boolean;
  setIsAccessKeySet(value: boolean): SpeechSynthesisUpdateAccessKeyStatus;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SpeechSynthesisUpdateAccessKeyStatus.AsObject;
  static toObject(includeInstance: boolean, msg: SpeechSynthesisUpdateAccessKeyStatus): SpeechSynthesisUpdateAccessKeyStatus.AsObject;
  static serializeBinaryToWriter(message: SpeechSynthesisUpdateAccessKeyStatus, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SpeechSynthesisUpdateAccessKeyStatus;
  static deserializeBinaryFromReader(message: SpeechSynthesisUpdateAccessKeyStatus, reader: jspb.BinaryReader): SpeechSynthesisUpdateAccessKeyStatus;
}

export namespace SpeechSynthesisUpdateAccessKeyStatus {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotSpeechSynthesis?: string,
    isAccessKeySet: boolean,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechSynthesisCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_SPEECH_SYNTHESIS_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_SPEECH_SYNTHESIS = 1000,
  }
}

export class SpeechSynthesisSetSelectedEngineAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechSynthesis(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechSynthesis(value: string): SpeechSynthesisSetSelectedEngineAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechSynthesis(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechSynthesis(): SpeechSynthesisSetSelectedEngineAction;

  getEngineName(): SpeechSynthesisEngineName;
  setEngineName(value: SpeechSynthesisEngineName): SpeechSynthesisSetSelectedEngineAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SpeechSynthesisSetSelectedEngineAction.AsObject;
  static toObject(includeInstance: boolean, msg: SpeechSynthesisSetSelectedEngineAction): SpeechSynthesisSetSelectedEngineAction.AsObject;
  static serializeBinaryToWriter(message: SpeechSynthesisSetSelectedEngineAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SpeechSynthesisSetSelectedEngineAction;
  static deserializeBinaryFromReader(message: SpeechSynthesisSetSelectedEngineAction, reader: jspb.BinaryReader): SpeechSynthesisSetSelectedEngineAction;
}

export namespace SpeechSynthesisSetSelectedEngineAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotSpeechSynthesis?: string,
    engineName: SpeechSynthesisEngineName,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechSynthesisCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_SPEECH_SYNTHESIS_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_SPEECH_SYNTHESIS = 1000,
  }
}

export class ReadableInformation extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechSynthesis(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechSynthesis(value: string): ReadableInformation;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechSynthesis(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechSynthesis(): ReadableInformation;

  getText(): string;
  setText(value: string): ReadableInformation;

  getPiperText(): string;
  setPiperText(value: string): ReadableInformation;
  hasPiperText(): boolean;
  clearPiperText(): ReadableInformation;

  getPicovoiceText(): string;
  setPicovoiceText(value: string): ReadableInformation;
  hasPicovoiceText(): boolean;
  clearPicovoiceText(): ReadableInformation;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): ReadableInformation.AsObject;
  static toObject(includeInstance: boolean, msg: ReadableInformation): ReadableInformation.AsObject;
  static serializeBinaryToWriter(message: ReadableInformation, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): ReadableInformation;
  static deserializeBinaryFromReader(message: ReadableInformation, reader: jspb.BinaryReader): ReadableInformation;
}

export namespace ReadableInformation {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotSpeechSynthesis?: string,
    text: string,
    piperText?: string,
    picovoiceText?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechSynthesisCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_SPEECH_SYNTHESIS_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_SPEECH_SYNTHESIS = 1000,
  }

  export enum PiperTextCase { 
    _PIPER_TEXT_NOT_SET = 0,
    PIPER_TEXT = 3,
  }

  export enum PicovoiceTextCase { 
    _PICOVOICE_TEXT_NOT_SET = 0,
    PICOVOICE_TEXT = 4,
  }
}

export class SpeechSynthesisReadTextAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechSynthesis(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechSynthesis(value: string): SpeechSynthesisReadTextAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechSynthesis(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechSynthesis(): SpeechSynthesisReadTextAction;

  getInformation(): ReadableInformation | undefined;
  setInformation(value?: ReadableInformation): SpeechSynthesisReadTextAction;
  hasInformation(): boolean;
  clearInformation(): SpeechSynthesisReadTextAction;

  getSpeechRate(): number;
  setSpeechRate(value: number): SpeechSynthesisReadTextAction;
  hasSpeechRate(): boolean;
  clearSpeechRate(): SpeechSynthesisReadTextAction;

  getEngine(): SpeechSynthesisEngineName;
  setEngine(value: SpeechSynthesisEngineName): SpeechSynthesisReadTextAction;
  hasEngine(): boolean;
  clearEngine(): SpeechSynthesisReadTextAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SpeechSynthesisReadTextAction.AsObject;
  static toObject(includeInstance: boolean, msg: SpeechSynthesisReadTextAction): SpeechSynthesisReadTextAction.AsObject;
  static serializeBinaryToWriter(message: SpeechSynthesisReadTextAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SpeechSynthesisReadTextAction;
  static deserializeBinaryFromReader(message: SpeechSynthesisReadTextAction, reader: jspb.BinaryReader): SpeechSynthesisReadTextAction;
}

export namespace SpeechSynthesisReadTextAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotSpeechSynthesis?: string,
    information?: ReadableInformation.AsObject,
    speechRate?: number,
    engine?: SpeechSynthesisEngineName,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechSynthesisCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_SPEECH_SYNTHESIS_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_SPEECH_SYNTHESIS = 1000,
  }

  export enum SpeechRateCase { 
    _SPEECH_RATE_NOT_SET = 0,
    SPEECH_RATE = 3,
  }

  export enum EngineCase { 
    _ENGINE_NOT_SET = 0,
    ENGINE = 4,
  }
}

export class SpeechSynthesisSynthesizeTextEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechSynthesis(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechSynthesis(value: string): SpeechSynthesisSynthesizeTextEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechSynthesis(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechSynthesis(): SpeechSynthesisSynthesizeTextEvent;

  getInformation(): ReadableInformation | undefined;
  setInformation(value?: ReadableInformation): SpeechSynthesisSynthesizeTextEvent;
  hasInformation(): boolean;
  clearInformation(): SpeechSynthesisSynthesizeTextEvent;

  getSpeechRate(): number;
  setSpeechRate(value: number): SpeechSynthesisSynthesizeTextEvent;
  hasSpeechRate(): boolean;
  clearSpeechRate(): SpeechSynthesisSynthesizeTextEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SpeechSynthesisSynthesizeTextEvent.AsObject;
  static toObject(includeInstance: boolean, msg: SpeechSynthesisSynthesizeTextEvent): SpeechSynthesisSynthesizeTextEvent.AsObject;
  static serializeBinaryToWriter(message: SpeechSynthesisSynthesizeTextEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SpeechSynthesisSynthesizeTextEvent;
  static deserializeBinaryFromReader(message: SpeechSynthesisSynthesizeTextEvent, reader: jspb.BinaryReader): SpeechSynthesisSynthesizeTextEvent;
}

export namespace SpeechSynthesisSynthesizeTextEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotSpeechSynthesis?: string,
    information?: ReadableInformation.AsObject,
    speechRate?: number,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechSynthesisCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_SPEECH_SYNTHESIS_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_SPEECH_SYNTHESIS = 1000,
  }

  export enum SpeechRateCase { 
    _SPEECH_RATE_NOT_SET = 0,
    SPEECH_RATE = 3,
  }
}

export class SpeechSynthesisState extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechSynthesis(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechSynthesis(value: string): SpeechSynthesisState;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechSynthesis(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechSynthesis(): SpeechSynthesisState;

  getIsAccessKeySet(): boolean;
  setIsAccessKeySet(value: boolean): SpeechSynthesisState;
  hasIsAccessKeySet(): boolean;
  clearIsAccessKeySet(): SpeechSynthesisState;

  getSelectedEngine(): SpeechSynthesisEngineName;
  setSelectedEngine(value: SpeechSynthesisEngineName): SpeechSynthesisState;
  hasSelectedEngine(): boolean;
  clearSelectedEngine(): SpeechSynthesisState;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SpeechSynthesisState.AsObject;
  static toObject(includeInstance: boolean, msg: SpeechSynthesisState): SpeechSynthesisState.AsObject;
  static serializeBinaryToWriter(message: SpeechSynthesisState, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SpeechSynthesisState;
  static deserializeBinaryFromReader(message: SpeechSynthesisState, reader: jspb.BinaryReader): SpeechSynthesisState;
}

export namespace SpeechSynthesisState {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotSpeechSynthesis?: string,
    isAccessKeySet?: boolean,
    selectedEngine?: SpeechSynthesisEngineName,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotSpeechSynthesisCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_SPEECH_SYNTHESIS_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_SPEECH_SYNTHESIS = 1000,
  }

  export enum IsAccessKeySetCase { 
    _IS_ACCESS_KEY_SET_NOT_SET = 0,
    IS_ACCESS_KEY_SET = 2,
  }

  export enum SelectedEngineCase { 
    _SELECTED_ENGINE_NOT_SET = 0,
    SELECTED_ENGINE = 3,
  }
}

export class SSHAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotSsh(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotSsh(value: string): SSHAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotSsh(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotSsh(): SSHAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SSHAction.AsObject;
  static toObject(includeInstance: boolean, msg: SSHAction): SSHAction.AsObject;
  static serializeBinaryToWriter(message: SSHAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SSHAction;
  static deserializeBinaryFromReader(message: SSHAction, reader: jspb.BinaryReader): SSHAction;
}

export namespace SSHAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotSsh?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotSshCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_SSH_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_SSH = 1000,
  }
}

export class SSHUpdateStateAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotSsh(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotSsh(value: string): SSHUpdateStateAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotSsh(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotSsh(): SSHUpdateStateAction;

  getIsActive(): boolean;
  setIsActive(value: boolean): SSHUpdateStateAction;
  hasIsActive(): boolean;
  clearIsActive(): SSHUpdateStateAction;

  getIsEnabled(): boolean;
  setIsEnabled(value: boolean): SSHUpdateStateAction;
  hasIsEnabled(): boolean;
  clearIsEnabled(): SSHUpdateStateAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SSHUpdateStateAction.AsObject;
  static toObject(includeInstance: boolean, msg: SSHUpdateStateAction): SSHUpdateStateAction.AsObject;
  static serializeBinaryToWriter(message: SSHUpdateStateAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SSHUpdateStateAction;
  static deserializeBinaryFromReader(message: SSHUpdateStateAction, reader: jspb.BinaryReader): SSHUpdateStateAction;
}

export namespace SSHUpdateStateAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotSsh?: string,
    isActive?: boolean,
    isEnabled?: boolean,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotSshCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_SSH_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_SSH = 1000,
  }

  export enum IsActiveCase { 
    _IS_ACTIVE_NOT_SET = 0,
    IS_ACTIVE = 2,
  }

  export enum IsEnabledCase { 
    _IS_ENABLED_NOT_SET = 0,
    IS_ENABLED = 3,
  }
}

export class SSHClearEnabledStateAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotSsh(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotSsh(value: string): SSHClearEnabledStateAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotSsh(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotSsh(): SSHClearEnabledStateAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SSHClearEnabledStateAction.AsObject;
  static toObject(includeInstance: boolean, msg: SSHClearEnabledStateAction): SSHClearEnabledStateAction.AsObject;
  static serializeBinaryToWriter(message: SSHClearEnabledStateAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SSHClearEnabledStateAction;
  static deserializeBinaryFromReader(message: SSHClearEnabledStateAction, reader: jspb.BinaryReader): SSHClearEnabledStateAction;
}

export namespace SSHClearEnabledStateAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotSsh?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotSshCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_SSH_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_SSH = 1000,
  }
}

export class SSHState extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotSsh(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotSsh(value: string): SSHState;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotSsh(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotSsh(): SSHState;

  getIsActive(): boolean;
  setIsActive(value: boolean): SSHState;
  hasIsActive(): boolean;
  clearIsActive(): SSHState;

  getIsEnabled(): boolean;
  setIsEnabled(value: boolean): SSHState;
  hasIsEnabled(): boolean;
  clearIsEnabled(): SSHState;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): SSHState.AsObject;
  static toObject(includeInstance: boolean, msg: SSHState): SSHState.AsObject;
  static serializeBinaryToWriter(message: SSHState, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): SSHState;
  static deserializeBinaryFromReader(message: SSHState, reader: jspb.BinaryReader): SSHState;
}

export namespace SSHState {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotSsh?: string,
    isActive?: boolean,
    isEnabled?: boolean,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotSshCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_SSH_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_SSH = 1000,
  }

  export enum IsActiveCase { 
    _IS_ACTIVE_NOT_SET = 0,
    IS_ACTIVE = 2,
  }

  export enum IsEnabledCase { 
    _IS_ENABLED_NOT_SET = 0,
    IS_ENABLED = 3,
  }
}

export class UsersAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotUsers(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotUsers(value: string): UsersAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotUsers(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotUsers(): UsersAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): UsersAction.AsObject;
  static toObject(includeInstance: boolean, msg: UsersAction): UsersAction.AsObject;
  static serializeBinaryToWriter(message: UsersAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): UsersAction;
  static deserializeBinaryFromReader(message: UsersAction, reader: jspb.BinaryReader): UsersAction;
}

export namespace UsersAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotUsers?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotUsersCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_USERS_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_USERS = 1000,
  }
}

export class UsersSetUsersAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotUsers(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotUsers(value: string): UsersSetUsersAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotUsers(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotUsers(): UsersSetUsersAction;

  getUsersList(): Array<UserState>;
  setUsersList(value: Array<UserState>): UsersSetUsersAction;
  clearUsersList(): UsersSetUsersAction;
  addUsers(value?: UserState, index?: number): UserState;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): UsersSetUsersAction.AsObject;
  static toObject(includeInstance: boolean, msg: UsersSetUsersAction): UsersSetUsersAction.AsObject;
  static serializeBinaryToWriter(message: UsersSetUsersAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): UsersSetUsersAction;
  static deserializeBinaryFromReader(message: UsersSetUsersAction, reader: jspb.BinaryReader): UsersSetUsersAction;
}

export namespace UsersSetUsersAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotUsers?: string,
    usersList: Array<UserState.AsObject>,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotUsersCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_USERS_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_USERS = 1000,
  }
}

export class UsersCreateUserAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotUsers(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotUsers(value: string): UsersCreateUserAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotUsers(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotUsers(): UsersCreateUserAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): UsersCreateUserAction.AsObject;
  static toObject(includeInstance: boolean, msg: UsersCreateUserAction): UsersCreateUserAction.AsObject;
  static serializeBinaryToWriter(message: UsersCreateUserAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): UsersCreateUserAction;
  static deserializeBinaryFromReader(message: UsersCreateUserAction, reader: jspb.BinaryReader): UsersCreateUserAction;
}

export namespace UsersCreateUserAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotUsers?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotUsersCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_USERS_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_USERS = 1000,
  }
}

export class UsersDeleteUserAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotUsers(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotUsers(value: string): UsersDeleteUserAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotUsers(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotUsers(): UsersDeleteUserAction;

  getId(): string;
  setId(value: string): UsersDeleteUserAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): UsersDeleteUserAction.AsObject;
  static toObject(includeInstance: boolean, msg: UsersDeleteUserAction): UsersDeleteUserAction.AsObject;
  static serializeBinaryToWriter(message: UsersDeleteUserAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): UsersDeleteUserAction;
  static deserializeBinaryFromReader(message: UsersDeleteUserAction, reader: jspb.BinaryReader): UsersDeleteUserAction;
}

export namespace UsersDeleteUserAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotUsers?: string,
    id: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotUsersCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_USERS_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_USERS = 1000,
  }
}

export class UsersResetPasswordAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotUsers(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotUsers(value: string): UsersResetPasswordAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotUsers(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotUsers(): UsersResetPasswordAction;

  getId(): string;
  setId(value: string): UsersResetPasswordAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): UsersResetPasswordAction.AsObject;
  static toObject(includeInstance: boolean, msg: UsersResetPasswordAction): UsersResetPasswordAction.AsObject;
  static serializeBinaryToWriter(message: UsersResetPasswordAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): UsersResetPasswordAction;
  static deserializeBinaryFromReader(message: UsersResetPasswordAction, reader: jspb.BinaryReader): UsersResetPasswordAction;
}

export namespace UsersResetPasswordAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotUsers?: string,
    id: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotUsersCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_USERS_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_USERS = 1000,
  }
}

export class UsersEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotUsers(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotUsers(value: string): UsersEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotUsers(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotUsers(): UsersEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): UsersEvent.AsObject;
  static toObject(includeInstance: boolean, msg: UsersEvent): UsersEvent.AsObject;
  static serializeBinaryToWriter(message: UsersEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): UsersEvent;
  static deserializeBinaryFromReader(message: UsersEvent, reader: jspb.BinaryReader): UsersEvent;
}

export namespace UsersEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotUsers?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotUsersCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_USERS_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_USERS = 1000,
  }
}

export class UsersCreateUserEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotUsers(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotUsers(value: string): UsersCreateUserEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotUsers(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotUsers(): UsersCreateUserEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): UsersCreateUserEvent.AsObject;
  static toObject(includeInstance: boolean, msg: UsersCreateUserEvent): UsersCreateUserEvent.AsObject;
  static serializeBinaryToWriter(message: UsersCreateUserEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): UsersCreateUserEvent;
  static deserializeBinaryFromReader(message: UsersCreateUserEvent, reader: jspb.BinaryReader): UsersCreateUserEvent;
}

export namespace UsersCreateUserEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotUsers?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotUsersCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_USERS_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_USERS = 1000,
  }
}

export class UsersDeleteUserEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotUsers(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotUsers(value: string): UsersDeleteUserEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotUsers(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotUsers(): UsersDeleteUserEvent;

  getId(): string;
  setId(value: string): UsersDeleteUserEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): UsersDeleteUserEvent.AsObject;
  static toObject(includeInstance: boolean, msg: UsersDeleteUserEvent): UsersDeleteUserEvent.AsObject;
  static serializeBinaryToWriter(message: UsersDeleteUserEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): UsersDeleteUserEvent;
  static deserializeBinaryFromReader(message: UsersDeleteUserEvent, reader: jspb.BinaryReader): UsersDeleteUserEvent;
}

export namespace UsersDeleteUserEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotUsers?: string,
    id: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotUsersCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_USERS_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_USERS = 1000,
  }
}

export class UsersResetPasswordEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotUsers(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotUsers(value: string): UsersResetPasswordEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotUsers(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotUsers(): UsersResetPasswordEvent;

  getId(): string;
  setId(value: string): UsersResetPasswordEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): UsersResetPasswordEvent.AsObject;
  static toObject(includeInstance: boolean, msg: UsersResetPasswordEvent): UsersResetPasswordEvent.AsObject;
  static serializeBinaryToWriter(message: UsersResetPasswordEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): UsersResetPasswordEvent;
  static deserializeBinaryFromReader(message: UsersResetPasswordEvent, reader: jspb.BinaryReader): UsersResetPasswordEvent;
}

export namespace UsersResetPasswordEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotUsers?: string,
    id: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotUsersCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_USERS_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_USERS = 1000,
  }
}

export class UserState extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotUsers(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotUsers(value: string): UserState;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotUsers(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotUsers(): UserState;

  getId(): string;
  setId(value: string): UserState;

  getIsRemovable(): boolean;
  setIsRemovable(value: boolean): UserState;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): UserState.AsObject;
  static toObject(includeInstance: boolean, msg: UserState): UserState.AsObject;
  static serializeBinaryToWriter(message: UserState, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): UserState;
  static deserializeBinaryFromReader(message: UserState, reader: jspb.BinaryReader): UserState;
}

export namespace UserState {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotUsers?: string,
    id: string,
    isRemovable: boolean,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotUsersCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_USERS_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_USERS = 1000,
  }
}

export class UsersState extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotUsers(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotUsers(value: string): UsersState;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotUsers(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotUsers(): UsersState;

  getUsers(): UsersState.Users | undefined;
  setUsers(value?: UsersState.Users): UsersState;
  hasUsers(): boolean;
  clearUsers(): UsersState;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): UsersState.AsObject;
  static toObject(includeInstance: boolean, msg: UsersState): UsersState.AsObject;
  static serializeBinaryToWriter(message: UsersState, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): UsersState;
  static deserializeBinaryFromReader(message: UsersState, reader: jspb.BinaryReader): UsersState;
}

export namespace UsersState {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotUsers?: string,
    users?: UsersState.Users.AsObject,
  }

  export class Users extends jspb.Message {
    getItemsList(): Array<UserState>;
    setItemsList(value: Array<UserState>): Users;
    clearItemsList(): Users;
    addItems(value?: UserState, index?: number): UserState;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): Users.AsObject;
    static toObject(includeInstance: boolean, msg: Users): Users.AsObject;
    static serializeBinaryToWriter(message: Users, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): Users;
    static deserializeBinaryFromReader(message: Users, reader: jspb.BinaryReader): Users;
  }

  export namespace Users {
    export type AsObject = {
      itemsList: Array<UserState.AsObject>,
    }
  }


  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotUsersCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_USERS_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_USERS = 1000,
  }

  export enum UsersCase { 
    _USERS_NOT_SET = 0,
    USERS = 2,
  }
}

export class VSCodeAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotVscode(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotVscode(value: string): VSCodeAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotVscode(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotVscode(): VSCodeAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): VSCodeAction.AsObject;
  static toObject(includeInstance: boolean, msg: VSCodeAction): VSCodeAction.AsObject;
  static serializeBinaryToWriter(message: VSCodeAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): VSCodeAction;
  static deserializeBinaryFromReader(message: VSCodeAction, reader: jspb.BinaryReader): VSCodeAction;
}

export namespace VSCodeAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotVscode?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotVscodeCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_VSCODE_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_VSCODE = 1000,
  }
}

export class VSCodeEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotVscode(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotVscode(value: string): VSCodeEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotVscode(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotVscode(): VSCodeEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): VSCodeEvent.AsObject;
  static toObject(includeInstance: boolean, msg: VSCodeEvent): VSCodeEvent.AsObject;
  static serializeBinaryToWriter(message: VSCodeEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): VSCodeEvent;
  static deserializeBinaryFromReader(message: VSCodeEvent, reader: jspb.BinaryReader): VSCodeEvent;
}

export namespace VSCodeEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotVscode?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotVscodeCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_VSCODE_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_VSCODE = 1000,
  }
}

export class VSCodeStartDownloadingAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotVscode(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotVscode(value: string): VSCodeStartDownloadingAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotVscode(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotVscode(): VSCodeStartDownloadingAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): VSCodeStartDownloadingAction.AsObject;
  static toObject(includeInstance: boolean, msg: VSCodeStartDownloadingAction): VSCodeStartDownloadingAction.AsObject;
  static serializeBinaryToWriter(message: VSCodeStartDownloadingAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): VSCodeStartDownloadingAction;
  static deserializeBinaryFromReader(message: VSCodeStartDownloadingAction, reader: jspb.BinaryReader): VSCodeStartDownloadingAction;
}

export namespace VSCodeStartDownloadingAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotVscode?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotVscodeCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_VSCODE_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_VSCODE = 1000,
  }
}

export class VSCodeDoneDownloadingAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotVscode(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotVscode(value: string): VSCodeDoneDownloadingAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotVscode(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotVscode(): VSCodeDoneDownloadingAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): VSCodeDoneDownloadingAction.AsObject;
  static toObject(includeInstance: boolean, msg: VSCodeDoneDownloadingAction): VSCodeDoneDownloadingAction.AsObject;
  static serializeBinaryToWriter(message: VSCodeDoneDownloadingAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): VSCodeDoneDownloadingAction;
  static deserializeBinaryFromReader(message: VSCodeDoneDownloadingAction, reader: jspb.BinaryReader): VSCodeDoneDownloadingAction;
}

export namespace VSCodeDoneDownloadingAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotVscode?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotVscodeCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_VSCODE_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_VSCODE = 1000,
  }
}

export class VSCodeSetPendingAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotVscode(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotVscode(value: string): VSCodeSetPendingAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotVscode(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotVscode(): VSCodeSetPendingAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): VSCodeSetPendingAction.AsObject;
  static toObject(includeInstance: boolean, msg: VSCodeSetPendingAction): VSCodeSetPendingAction.AsObject;
  static serializeBinaryToWriter(message: VSCodeSetPendingAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): VSCodeSetPendingAction;
  static deserializeBinaryFromReader(message: VSCodeSetPendingAction, reader: jspb.BinaryReader): VSCodeSetPendingAction;
}

export namespace VSCodeSetPendingAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotVscode?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotVscodeCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_VSCODE_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_VSCODE = 1000,
  }
}

export class VSCodeStatus extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotVscode(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotVscode(value: string): VSCodeStatus;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotVscode(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotVscode(): VSCodeStatus;

  getIsServiceInstalled(): boolean;
  setIsServiceInstalled(value: boolean): VSCodeStatus;

  getIsRunning(): boolean;
  setIsRunning(value: boolean): VSCodeStatus;

  getName(): string;
  setName(value: string): VSCodeStatus;
  hasName(): boolean;
  clearName(): VSCodeStatus;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): VSCodeStatus.AsObject;
  static toObject(includeInstance: boolean, msg: VSCodeStatus): VSCodeStatus.AsObject;
  static serializeBinaryToWriter(message: VSCodeStatus, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): VSCodeStatus;
  static deserializeBinaryFromReader(message: VSCodeStatus, reader: jspb.BinaryReader): VSCodeStatus;
}

export namespace VSCodeStatus {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotVscode?: string,
    isServiceInstalled: boolean,
    isRunning: boolean,
    name?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotVscodeCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_VSCODE_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_VSCODE = 1000,
  }

  export enum NameCase { 
    _NAME_NOT_SET = 0,
    NAME = 4,
  }
}

export class VSCodeSetStatusAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotVscode(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotVscode(value: string): VSCodeSetStatusAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotVscode(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotVscode(): VSCodeSetStatusAction;

  getIsBinaryInstalled(): boolean;
  setIsBinaryInstalled(value: boolean): VSCodeSetStatusAction;

  getIsLoggedIn(): boolean;
  setIsLoggedIn(value: boolean): VSCodeSetStatusAction;

  getStatus(): VSCodeStatus | undefined;
  setStatus(value?: VSCodeStatus): VSCodeSetStatusAction;
  hasStatus(): boolean;
  clearStatus(): VSCodeSetStatusAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): VSCodeSetStatusAction.AsObject;
  static toObject(includeInstance: boolean, msg: VSCodeSetStatusAction): VSCodeSetStatusAction.AsObject;
  static serializeBinaryToWriter(message: VSCodeSetStatusAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): VSCodeSetStatusAction;
  static deserializeBinaryFromReader(message: VSCodeSetStatusAction, reader: jspb.BinaryReader): VSCodeSetStatusAction;
}

export namespace VSCodeSetStatusAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotVscode?: string,
    isBinaryInstalled: boolean,
    isLoggedIn: boolean,
    status?: VSCodeStatus.AsObject,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotVscodeCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_VSCODE_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_VSCODE = 1000,
  }

  export enum StatusCase { 
    _STATUS_NOT_SET = 0,
    STATUS = 4,
  }
}

export class VSCodeLoginEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotVscode(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotVscode(value: string): VSCodeLoginEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotVscode(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotVscode(): VSCodeLoginEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): VSCodeLoginEvent.AsObject;
  static toObject(includeInstance: boolean, msg: VSCodeLoginEvent): VSCodeLoginEvent.AsObject;
  static serializeBinaryToWriter(message: VSCodeLoginEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): VSCodeLoginEvent;
  static deserializeBinaryFromReader(message: VSCodeLoginEvent, reader: jspb.BinaryReader): VSCodeLoginEvent;
}

export namespace VSCodeLoginEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotVscode?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotVscodeCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_VSCODE_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_VSCODE = 1000,
  }
}

export class VSCodeRestartEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotVscode(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotVscode(value: string): VSCodeRestartEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotVscode(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotVscode(): VSCodeRestartEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): VSCodeRestartEvent.AsObject;
  static toObject(includeInstance: boolean, msg: VSCodeRestartEvent): VSCodeRestartEvent.AsObject;
  static serializeBinaryToWriter(message: VSCodeRestartEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): VSCodeRestartEvent;
  static deserializeBinaryFromReader(message: VSCodeRestartEvent, reader: jspb.BinaryReader): VSCodeRestartEvent;
}

export namespace VSCodeRestartEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotVscode?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotVscodeCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_VSCODE_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_VSCODE = 1000,
  }
}

export class VSCodeState extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotVscode(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotVscode(value: string): VSCodeState;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotVscode(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotVscode(): VSCodeState;

  getIsPending(): boolean;
  setIsPending(value: boolean): VSCodeState;
  hasIsPending(): boolean;
  clearIsPending(): VSCodeState;

  getIsDownloading(): boolean;
  setIsDownloading(value: boolean): VSCodeState;
  hasIsDownloading(): boolean;
  clearIsDownloading(): VSCodeState;

  getIsBinaryInstalled(): boolean;
  setIsBinaryInstalled(value: boolean): VSCodeState;
  hasIsBinaryInstalled(): boolean;
  clearIsBinaryInstalled(): VSCodeState;

  getIsLoggedIn(): boolean;
  setIsLoggedIn(value: boolean): VSCodeState;
  hasIsLoggedIn(): boolean;
  clearIsLoggedIn(): VSCodeState;

  getStatus(): VSCodeStatus | undefined;
  setStatus(value?: VSCodeStatus): VSCodeState;
  hasStatus(): boolean;
  clearStatus(): VSCodeState;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): VSCodeState.AsObject;
  static toObject(includeInstance: boolean, msg: VSCodeState): VSCodeState.AsObject;
  static serializeBinaryToWriter(message: VSCodeState, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): VSCodeState;
  static deserializeBinaryFromReader(message: VSCodeState, reader: jspb.BinaryReader): VSCodeState;
}

export namespace VSCodeState {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotVscode?: string,
    isPending?: boolean,
    isDownloading?: boolean,
    isBinaryInstalled?: boolean,
    isLoggedIn?: boolean,
    status?: VSCodeStatus.AsObject,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotVscodeCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_VSCODE_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_VSCODE = 1000,
  }

  export enum IsPendingCase { 
    _IS_PENDING_NOT_SET = 0,
    IS_PENDING = 2,
  }

  export enum IsDownloadingCase { 
    _IS_DOWNLOADING_NOT_SET = 0,
    IS_DOWNLOADING = 3,
  }

  export enum IsBinaryInstalledCase { 
    _IS_BINARY_INSTALLED_NOT_SET = 0,
    IS_BINARY_INSTALLED = 4,
  }

  export enum IsLoggedInCase { 
    _IS_LOGGED_IN_NOT_SET = 0,
    IS_LOGGED_IN = 5,
  }

  export enum StatusCase { 
    _STATUS_NOT_SET = 0,
    STATUS = 6,
  }
}

export class WebUIEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotWebUi(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotWebUi(value: string): WebUIEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotWebUi(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotWebUi(): WebUIEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): WebUIEvent.AsObject;
  static toObject(includeInstance: boolean, msg: WebUIEvent): WebUIEvent.AsObject;
  static serializeBinaryToWriter(message: WebUIEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): WebUIEvent;
  static deserializeBinaryFromReader(message: WebUIEvent, reader: jspb.BinaryReader): WebUIEvent;
}

export namespace WebUIEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotWebUi?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotWebUiCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_WEB_UI_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_WEB_UI = 1000,
  }
}

export class WebUIInitializeEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotWebUi(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotWebUi(value: string): WebUIInitializeEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotWebUi(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotWebUi(): WebUIInitializeEvent;

  getDescription(): WebUIInputDescription | undefined;
  setDescription(value?: WebUIInputDescription): WebUIInitializeEvent;
  hasDescription(): boolean;
  clearDescription(): WebUIInitializeEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): WebUIInitializeEvent.AsObject;
  static toObject(includeInstance: boolean, msg: WebUIInitializeEvent): WebUIInitializeEvent.AsObject;
  static serializeBinaryToWriter(message: WebUIInitializeEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): WebUIInitializeEvent;
  static deserializeBinaryFromReader(message: WebUIInitializeEvent, reader: jspb.BinaryReader): WebUIInitializeEvent;
}

export namespace WebUIInitializeEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotWebUi?: string,
    description?: WebUIInputDescription.AsObject,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotWebUiCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_WEB_UI_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_WEB_UI = 1000,
  }
}

export class WebUIStopEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotWebUi(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotWebUi(value: string): WebUIStopEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotWebUi(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotWebUi(): WebUIStopEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): WebUIStopEvent.AsObject;
  static toObject(includeInstance: boolean, msg: WebUIStopEvent): WebUIStopEvent.AsObject;
  static serializeBinaryToWriter(message: WebUIStopEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): WebUIStopEvent;
  static deserializeBinaryFromReader(message: WebUIStopEvent, reader: jspb.BinaryReader): WebUIStopEvent;
}

export namespace WebUIStopEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotWebUi?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotWebUiCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_WEB_UI_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_WEB_UI = 1000,
  }
}

export class WebUIState extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotWebUi(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotWebUi(value: string): WebUIState;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotWebUi(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotWebUi(): WebUIState;

  getActiveInputsList(): Array<WebUIInputDescription>;
  setActiveInputsList(value: Array<WebUIInputDescription>): WebUIState;
  clearActiveInputsList(): WebUIState;
  addActiveInputs(value?: WebUIInputDescription, index?: number): WebUIInputDescription;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): WebUIState.AsObject;
  static toObject(includeInstance: boolean, msg: WebUIState): WebUIState.AsObject;
  static serializeBinaryToWriter(message: WebUIState, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): WebUIState;
  static deserializeBinaryFromReader(message: WebUIState, reader: jspb.BinaryReader): WebUIState;
}

export namespace WebUIState {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotWebUi?: string,
    activeInputsList: Array<WebUIInputDescription.AsObject>,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotWebUiCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_WEB_UI_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_WEB_UI = 1000,
  }
}

export class WiFiConnection extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotWifi(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotWifi(value: string): WiFiConnection;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotWifi(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotWifi(): WiFiConnection;

  getSsid(): string;
  setSsid(value: string): WiFiConnection;

  getState(): ConnectionState;
  setState(value: ConnectionState): WiFiConnection;
  hasState(): boolean;
  clearState(): WiFiConnection;

  getSignalStrength(): number;
  setSignalStrength(value: number): WiFiConnection;
  hasSignalStrength(): boolean;
  clearSignalStrength(): WiFiConnection;

  getPassword(): string;
  setPassword(value: string): WiFiConnection;
  hasPassword(): boolean;
  clearPassword(): WiFiConnection;

  getType(): WiFiType;
  setType(value: WiFiType): WiFiConnection;
  hasType(): boolean;
  clearType(): WiFiConnection;

  getHidden(): boolean;
  setHidden(value: boolean): WiFiConnection;
  hasHidden(): boolean;
  clearHidden(): WiFiConnection;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): WiFiConnection.AsObject;
  static toObject(includeInstance: boolean, msg: WiFiConnection): WiFiConnection.AsObject;
  static serializeBinaryToWriter(message: WiFiConnection, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): WiFiConnection;
  static deserializeBinaryFromReader(message: WiFiConnection, reader: jspb.BinaryReader): WiFiConnection;
}

export namespace WiFiConnection {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotWifi?: string,
    ssid: string,
    state?: ConnectionState,
    signalStrength?: number,
    password?: string,
    type?: WiFiType,
    hidden?: boolean,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotWifiCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_WIFI_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_WIFI = 1000,
  }

  export enum StateCase { 
    _STATE_NOT_SET = 0,
    STATE = 3,
  }

  export enum SignalStrengthCase { 
    _SIGNAL_STRENGTH_NOT_SET = 0,
    SIGNAL_STRENGTH = 4,
  }

  export enum PasswordCase { 
    _PASSWORD_NOT_SET = 0,
    PASSWORD = 5,
  }

  export enum TypeCase { 
    _TYPE_NOT_SET = 0,
    TYPE = 6,
  }

  export enum HiddenCase { 
    _HIDDEN_NOT_SET = 0,
    HIDDEN = 7,
  }
}

export class WiFiAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotWifi(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotWifi(value: string): WiFiAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotWifi(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotWifi(): WiFiAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): WiFiAction.AsObject;
  static toObject(includeInstance: boolean, msg: WiFiAction): WiFiAction.AsObject;
  static serializeBinaryToWriter(message: WiFiAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): WiFiAction;
  static deserializeBinaryFromReader(message: WiFiAction, reader: jspb.BinaryReader): WiFiAction;
}

export namespace WiFiAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotWifi?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotWifiCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_WIFI_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_WIFI = 1000,
  }
}

export class WiFiInputConnectionAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotWifi(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotWifi(value: string): WiFiInputConnectionAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotWifi(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotWifi(): WiFiInputConnectionAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): WiFiInputConnectionAction.AsObject;
  static toObject(includeInstance: boolean, msg: WiFiInputConnectionAction): WiFiInputConnectionAction.AsObject;
  static serializeBinaryToWriter(message: WiFiInputConnectionAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): WiFiInputConnectionAction;
  static deserializeBinaryFromReader(message: WiFiInputConnectionAction, reader: jspb.BinaryReader): WiFiInputConnectionAction;
}

export namespace WiFiInputConnectionAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotWifi?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotWifiCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_WIFI_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_WIFI = 1000,
  }
}

export class WiFiSetHasVisitedOnboardingAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotWifi(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotWifi(value: string): WiFiSetHasVisitedOnboardingAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotWifi(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotWifi(): WiFiSetHasVisitedOnboardingAction;

  getHasVisitedOnboarding(): boolean;
  setHasVisitedOnboarding(value: boolean): WiFiSetHasVisitedOnboardingAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): WiFiSetHasVisitedOnboardingAction.AsObject;
  static toObject(includeInstance: boolean, msg: WiFiSetHasVisitedOnboardingAction): WiFiSetHasVisitedOnboardingAction.AsObject;
  static serializeBinaryToWriter(message: WiFiSetHasVisitedOnboardingAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): WiFiSetHasVisitedOnboardingAction;
  static deserializeBinaryFromReader(message: WiFiSetHasVisitedOnboardingAction, reader: jspb.BinaryReader): WiFiSetHasVisitedOnboardingAction;
}

export namespace WiFiSetHasVisitedOnboardingAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotWifi?: string,
    hasVisitedOnboarding: boolean,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotWifiCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_WIFI_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_WIFI = 1000,
  }
}

export class WiFiUpdateAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotWifi(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotWifi(value: string): WiFiUpdateAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotWifi(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotWifi(): WiFiUpdateAction;

  getConnectionsList(): Array<WiFiConnection>;
  setConnectionsList(value: Array<WiFiConnection>): WiFiUpdateAction;
  clearConnectionsList(): WiFiUpdateAction;
  addConnections(value?: WiFiConnection, index?: number): WiFiConnection;

  getState(): NetState;
  setState(value: NetState): WiFiUpdateAction;

  getCurrentConnection(): WiFiConnection | undefined;
  setCurrentConnection(value?: WiFiConnection): WiFiUpdateAction;
  hasCurrentConnection(): boolean;
  clearCurrentConnection(): WiFiUpdateAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): WiFiUpdateAction.AsObject;
  static toObject(includeInstance: boolean, msg: WiFiUpdateAction): WiFiUpdateAction.AsObject;
  static serializeBinaryToWriter(message: WiFiUpdateAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): WiFiUpdateAction;
  static deserializeBinaryFromReader(message: WiFiUpdateAction, reader: jspb.BinaryReader): WiFiUpdateAction;
}

export namespace WiFiUpdateAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotWifi?: string,
    connectionsList: Array<WiFiConnection.AsObject>,
    state: NetState,
    currentConnection?: WiFiConnection.AsObject,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotWifiCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_WIFI_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_WIFI = 1000,
  }

  export enum CurrentConnectionCase { 
    _CURRENT_CONNECTION_NOT_SET = 0,
    CURRENT_CONNECTION = 4,
  }
}

export class WiFiUpdateRequestAction extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotWifi(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotWifi(value: string): WiFiUpdateRequestAction;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotWifi(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotWifi(): WiFiUpdateRequestAction;

  getReset(): boolean;
  setReset(value: boolean): WiFiUpdateRequestAction;
  hasReset(): boolean;
  clearReset(): WiFiUpdateRequestAction;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): WiFiUpdateRequestAction.AsObject;
  static toObject(includeInstance: boolean, msg: WiFiUpdateRequestAction): WiFiUpdateRequestAction.AsObject;
  static serializeBinaryToWriter(message: WiFiUpdateRequestAction, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): WiFiUpdateRequestAction;
  static deserializeBinaryFromReader(message: WiFiUpdateRequestAction, reader: jspb.BinaryReader): WiFiUpdateRequestAction;
}

export namespace WiFiUpdateRequestAction {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotWifi?: string,
    reset?: boolean,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotWifiCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_WIFI_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_WIFI = 1000,
  }

  export enum ResetCase { 
    _RESET_NOT_SET = 0,
    RESET = 2,
  }
}

export class WiFiEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotWifi(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotWifi(value: string): WiFiEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotWifi(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotWifi(): WiFiEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): WiFiEvent.AsObject;
  static toObject(includeInstance: boolean, msg: WiFiEvent): WiFiEvent.AsObject;
  static serializeBinaryToWriter(message: WiFiEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): WiFiEvent;
  static deserializeBinaryFromReader(message: WiFiEvent, reader: jspb.BinaryReader): WiFiEvent;
}

export namespace WiFiEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotWifi?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotWifiCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_WIFI_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_WIFI = 1000,
  }
}

export class WiFiInputConnectionEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotWifi(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotWifi(value: string): WiFiInputConnectionEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotWifi(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotWifi(): WiFiInputConnectionEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): WiFiInputConnectionEvent.AsObject;
  static toObject(includeInstance: boolean, msg: WiFiInputConnectionEvent): WiFiInputConnectionEvent.AsObject;
  static serializeBinaryToWriter(message: WiFiInputConnectionEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): WiFiInputConnectionEvent;
  static deserializeBinaryFromReader(message: WiFiInputConnectionEvent, reader: jspb.BinaryReader): WiFiInputConnectionEvent;
}

export namespace WiFiInputConnectionEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotWifi?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotWifiCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_WIFI_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_WIFI = 1000,
  }
}

export class WiFiUpdateRequestEvent extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotWifi(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotWifi(value: string): WiFiUpdateRequestEvent;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotWifi(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotWifi(): WiFiUpdateRequestEvent;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): WiFiUpdateRequestEvent.AsObject;
  static toObject(includeInstance: boolean, msg: WiFiUpdateRequestEvent): WiFiUpdateRequestEvent.AsObject;
  static serializeBinaryToWriter(message: WiFiUpdateRequestEvent, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): WiFiUpdateRequestEvent;
  static deserializeBinaryFromReader(message: WiFiUpdateRequestEvent, reader: jspb.BinaryReader): WiFiUpdateRequestEvent;
}

export namespace WiFiUpdateRequestEvent {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotWifi?: string,
  }

  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotWifiCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_WIFI_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_WIFI = 1000,
  }
}

export class WiFiState extends jspb.Message {
  getMetaFieldPackageNameUboAppDotStoreDotServicesDotWifi(): string;
  setMetaFieldPackageNameUboAppDotStoreDotServicesDotWifi(value: string): WiFiState;
  hasMetaFieldPackageNameUboAppDotStoreDotServicesDotWifi(): boolean;
  clearMetaFieldPackageNameUboAppDotStoreDotServicesDotWifi(): WiFiState;

  getConnections(): WiFiState.Connections | undefined;
  setConnections(value?: WiFiState.Connections): WiFiState;
  hasConnections(): boolean;
  clearConnections(): WiFiState;

  getState(): NetState;
  setState(value: NetState): WiFiState;

  getCurrentConnection(): WiFiConnection | undefined;
  setCurrentConnection(value?: WiFiConnection): WiFiState;
  hasCurrentConnection(): boolean;
  clearCurrentConnection(): WiFiState;

  getHasVisitedOnboarding(): boolean;
  setHasVisitedOnboarding(value: boolean): WiFiState;
  hasHasVisitedOnboarding(): boolean;
  clearHasVisitedOnboarding(): WiFiState;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): WiFiState.AsObject;
  static toObject(includeInstance: boolean, msg: WiFiState): WiFiState.AsObject;
  static serializeBinaryToWriter(message: WiFiState, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): WiFiState;
  static deserializeBinaryFromReader(message: WiFiState, reader: jspb.BinaryReader): WiFiState;
}

export namespace WiFiState {
  export type AsObject = {
    metaFieldPackageNameUboAppDotStoreDotServicesDotWifi?: string,
    connections?: WiFiState.Connections.AsObject,
    state: NetState,
    currentConnection?: WiFiConnection.AsObject,
    hasVisitedOnboarding?: boolean,
  }

  export class Connections extends jspb.Message {
    getItemsList(): Array<WiFiConnection>;
    setItemsList(value: Array<WiFiConnection>): Connections;
    clearItemsList(): Connections;
    addItems(value?: WiFiConnection, index?: number): WiFiConnection;

    serializeBinary(): Uint8Array;
    toObject(includeInstance?: boolean): Connections.AsObject;
    static toObject(includeInstance: boolean, msg: Connections): Connections.AsObject;
    static serializeBinaryToWriter(message: Connections, writer: jspb.BinaryWriter): void;
    static deserializeBinary(bytes: Uint8Array): Connections;
    static deserializeBinaryFromReader(message: Connections, reader: jspb.BinaryReader): Connections;
  }

  export namespace Connections {
    export type AsObject = {
      itemsList: Array<WiFiConnection.AsObject>,
    }
  }


  export enum MetaFieldPackageNameUboAppDotStoreDotServicesDotWifiCase { 
    _META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_WIFI_NOT_SET = 0,
    META_FIELD_PACKAGE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_WIFI = 1000,
  }

  export enum ConnectionsCase { 
    _CONNECTIONS_NOT_SET = 0,
    CONNECTIONS = 2,
  }

  export enum CurrentConnectionCase { 
    _CURRENT_CONNECTION_NOT_SET = 0,
    CURRENT_CONNECTION = 4,
  }

  export enum HasVisitedOnboardingCase { 
    _HAS_VISITED_ONBOARDING_NOT_SET = 0,
    HAS_VISITED_ONBOARDING = 5,
  }
}

export class Action extends jspb.Message {
  getAssistantAction(): AssistantAction | undefined;
  setAssistantAction(value?: AssistantAction): Action;
  hasAssistantAction(): boolean;
  clearAssistantAction(): Action;

  getAssistantDownloadOllamaModelAction(): AssistantDownloadOllamaModelAction | undefined;
  setAssistantDownloadOllamaModelAction(value?: AssistantDownloadOllamaModelAction): Action;
  hasAssistantDownloadOllamaModelAction(): boolean;
  clearAssistantDownloadOllamaModelAction(): Action;

  getAssistantReportAction(): AssistantReportAction | undefined;
  setAssistantReportAction(value?: AssistantReportAction): Action;
  hasAssistantReportAction(): boolean;
  clearAssistantReportAction(): Action;

  getAssistantSetIsActiveAction(): AssistantSetIsActiveAction | undefined;
  setAssistantSetIsActiveAction(value?: AssistantSetIsActiveAction): Action;
  hasAssistantSetIsActiveAction(): boolean;
  clearAssistantSetIsActiveAction(): Action;

  getAssistantSetSelectedLlmAction(): AssistantSetSelectedLLMAction | undefined;
  setAssistantSetSelectedLlmAction(value?: AssistantSetSelectedLLMAction): Action;
  hasAssistantSetSelectedLlmAction(): boolean;
  clearAssistantSetSelectedLlmAction(): Action;

  getAssistantSetSelectedModelAction(): AssistantSetSelectedModelAction | undefined;
  setAssistantSetSelectedModelAction(value?: AssistantSetSelectedModelAction): Action;
  hasAssistantSetSelectedModelAction(): boolean;
  clearAssistantSetSelectedModelAction(): Action;

  getAssistantStartListeningAction(): AssistantStartListeningAction | undefined;
  setAssistantStartListeningAction(value?: AssistantStartListeningAction): Action;
  hasAssistantStartListeningAction(): boolean;
  clearAssistantStartListeningAction(): Action;

  getAssistantStopListeningAction(): AssistantStopListeningAction | undefined;
  setAssistantStopListeningAction(value?: AssistantStopListeningAction): Action;
  hasAssistantStopListeningAction(): boolean;
  clearAssistantStopListeningAction(): Action;

  getAudioAction(): AudioAction | undefined;
  setAudioAction(value?: AudioAction): Action;
  hasAudioAction(): boolean;
  clearAudioAction(): Action;

  getAudioChangeVolumeAction(): AudioChangeVolumeAction | undefined;
  setAudioChangeVolumeAction(value?: AudioChangeVolumeAction): Action;
  hasAudioChangeVolumeAction(): boolean;
  clearAudioChangeVolumeAction(): Action;

  getAudioInstallDriverAction(): AudioInstallDriverAction | undefined;
  setAudioInstallDriverAction(value?: AudioInstallDriverAction): Action;
  hasAudioInstallDriverAction(): boolean;
  clearAudioInstallDriverAction(): Action;

  getAudioPlayAudioSampleAction(): AudioPlayAudioSampleAction | undefined;
  setAudioPlayAudioSampleAction(value?: AudioPlayAudioSampleAction): Action;
  hasAudioPlayAudioSampleAction(): boolean;
  clearAudioPlayAudioSampleAction(): Action;

  getAudioPlayAudioSequenceAction(): AudioPlayAudioSequenceAction | undefined;
  setAudioPlayAudioSequenceAction(value?: AudioPlayAudioSequenceAction): Action;
  hasAudioPlayAudioSequenceAction(): boolean;
  clearAudioPlayAudioSequenceAction(): Action;

  getAudioPlayChimeAction(): AudioPlayChimeAction | undefined;
  setAudioPlayChimeAction(value?: AudioPlayChimeAction): Action;
  hasAudioPlayChimeAction(): boolean;
  clearAudioPlayChimeAction(): Action;

  getAudioPlaybackDoneAction(): AudioPlaybackDoneAction | undefined;
  setAudioPlaybackDoneAction(value?: AudioPlaybackDoneAction): Action;
  hasAudioPlaybackDoneAction(): boolean;
  clearAudioPlaybackDoneAction(): Action;

  getAudioSetMuteStatusAction(): AudioSetMuteStatusAction | undefined;
  setAudioSetMuteStatusAction(value?: AudioSetMuteStatusAction): Action;
  hasAudioSetMuteStatusAction(): boolean;
  clearAudioSetMuteStatusAction(): Action;

  getAudioSetVolumeAction(): AudioSetVolumeAction | undefined;
  setAudioSetVolumeAction(value?: AudioSetVolumeAction): Action;
  hasAudioSetVolumeAction(): boolean;
  clearAudioSetVolumeAction(): Action;

  getAudioToggleMuteStatusAction(): AudioToggleMuteStatusAction | undefined;
  setAudioToggleMuteStatusAction(value?: AudioToggleMuteStatusAction): Action;
  hasAudioToggleMuteStatusAction(): boolean;
  clearAudioToggleMuteStatusAction(): Action;

  getCameraAction(): CameraAction | undefined;
  setCameraAction(value?: CameraAction): Action;
  hasCameraAction(): boolean;
  clearCameraAction(): Action;

  getCameraReportBarcodeAction(): CameraReportBarcodeAction | undefined;
  setCameraReportBarcodeAction(value?: CameraReportBarcodeAction): Action;
  hasCameraReportBarcodeAction(): boolean;
  clearCameraReportBarcodeAction(): Action;

  getCameraStartViewfinderAction(): CameraStartViewfinderAction | undefined;
  setCameraStartViewfinderAction(value?: CameraStartViewfinderAction): Action;
  hasCameraStartViewfinderAction(): boolean;
  clearCameraStartViewfinderAction(): Action;

  getCloseApplicationAction(): CloseApplicationAction | undefined;
  setCloseApplicationAction(value?: CloseApplicationAction): Action;
  hasCloseApplicationAction(): boolean;
  clearCloseApplicationAction(): Action;

  getDeregisterRegularAppAction(): DeregisterRegularAppAction | undefined;
  setDeregisterRegularAppAction(value?: DeregisterRegularAppAction): Action;
  hasDeregisterRegularAppAction(): boolean;
  clearDeregisterRegularAppAction(): Action;

  getDisplayAction(): DisplayAction | undefined;
  setDisplayAction(value?: DisplayAction): Action;
  hasDisplayAction(): boolean;
  clearDisplayAction(): Action;

  getDisplayPauseAction(): DisplayPauseAction | undefined;
  setDisplayPauseAction(value?: DisplayPauseAction): Action;
  hasDisplayPauseAction(): boolean;
  clearDisplayPauseAction(): Action;

  getDisplayResumeAction(): DisplayResumeAction | undefined;
  setDisplayResumeAction(value?: DisplayResumeAction): Action;
  hasDisplayResumeAction(): boolean;
  clearDisplayResumeAction(): Action;

  getDockerAction(): DockerAction | undefined;
  setDockerAction(value?: DockerAction): Action;
  hasDockerAction(): boolean;
  clearDockerAction(): Action;

  getDockerImageAction(): DockerImageAction | undefined;
  setDockerImageAction(value?: DockerImageAction): Action;
  hasDockerImageAction(): boolean;
  clearDockerImageAction(): Action;

  getDockerImageFetchAction(): DockerImageFetchAction | undefined;
  setDockerImageFetchAction(value?: DockerImageFetchAction): Action;
  hasDockerImageFetchAction(): boolean;
  clearDockerImageFetchAction(): Action;

  getDockerImageFetchCompositionAction(): DockerImageFetchCompositionAction | undefined;
  setDockerImageFetchCompositionAction(value?: DockerImageFetchCompositionAction): Action;
  hasDockerImageFetchCompositionAction(): boolean;
  clearDockerImageFetchCompositionAction(): Action;

  getDockerImageReleaseCompositionAction(): DockerImageReleaseCompositionAction | undefined;
  setDockerImageReleaseCompositionAction(value?: DockerImageReleaseCompositionAction): Action;
  hasDockerImageReleaseCompositionAction(): boolean;
  clearDockerImageReleaseCompositionAction(): Action;

  getDockerImageRemoveAction(): DockerImageRemoveAction | undefined;
  setDockerImageRemoveAction(value?: DockerImageRemoveAction): Action;
  hasDockerImageRemoveAction(): boolean;
  clearDockerImageRemoveAction(): Action;

  getDockerImageRemoveCompositionAction(): DockerImageRemoveCompositionAction | undefined;
  setDockerImageRemoveCompositionAction(value?: DockerImageRemoveCompositionAction): Action;
  hasDockerImageRemoveCompositionAction(): boolean;
  clearDockerImageRemoveCompositionAction(): Action;

  getDockerImageRemoveContainerAction(): DockerImageRemoveContainerAction | undefined;
  setDockerImageRemoveContainerAction(value?: DockerImageRemoveContainerAction): Action;
  hasDockerImageRemoveContainerAction(): boolean;
  clearDockerImageRemoveContainerAction(): Action;

  getDockerImageRunCompositionAction(): DockerImageRunCompositionAction | undefined;
  setDockerImageRunCompositionAction(value?: DockerImageRunCompositionAction): Action;
  hasDockerImageRunCompositionAction(): boolean;
  clearDockerImageRunCompositionAction(): Action;

  getDockerImageRunContainerAction(): DockerImageRunContainerAction | undefined;
  setDockerImageRunContainerAction(value?: DockerImageRunContainerAction): Action;
  hasDockerImageRunContainerAction(): boolean;
  clearDockerImageRunContainerAction(): Action;

  getDockerImageSetDockerIdAction(): DockerImageSetDockerIdAction | undefined;
  setDockerImageSetDockerIdAction(value?: DockerImageSetDockerIdAction): Action;
  hasDockerImageSetDockerIdAction(): boolean;
  clearDockerImageSetDockerIdAction(): Action;

  getDockerImageSetStatusAction(): DockerImageSetStatusAction | undefined;
  setDockerImageSetStatusAction(value?: DockerImageSetStatusAction): Action;
  hasDockerImageSetStatusAction(): boolean;
  clearDockerImageSetStatusAction(): Action;

  getDockerImageStopCompositionAction(): DockerImageStopCompositionAction | undefined;
  setDockerImageStopCompositionAction(value?: DockerImageStopCompositionAction): Action;
  hasDockerImageStopCompositionAction(): boolean;
  clearDockerImageStopCompositionAction(): Action;

  getDockerImageStopContainerAction(): DockerImageStopContainerAction | undefined;
  setDockerImageStopContainerAction(value?: DockerImageStopContainerAction): Action;
  hasDockerImageStopContainerAction(): boolean;
  clearDockerImageStopContainerAction(): Action;

  getDockerInstallAction(): DockerInstallAction | undefined;
  setDockerInstallAction(value?: DockerInstallAction): Action;
  hasDockerInstallAction(): boolean;
  clearDockerInstallAction(): Action;

  getDockerRemoveUsernameAction(): DockerRemoveUsernameAction | undefined;
  setDockerRemoveUsernameAction(value?: DockerRemoveUsernameAction): Action;
  hasDockerRemoveUsernameAction(): boolean;
  clearDockerRemoveUsernameAction(): Action;

  getDockerSetStatusAction(): DockerSetStatusAction | undefined;
  setDockerSetStatusAction(value?: DockerSetStatusAction): Action;
  hasDockerSetStatusAction(): boolean;
  clearDockerSetStatusAction(): Action;

  getDockerStartAction(): DockerStartAction | undefined;
  setDockerStartAction(value?: DockerStartAction): Action;
  hasDockerStartAction(): boolean;
  clearDockerStartAction(): Action;

  getDockerStopAction(): DockerStopAction | undefined;
  setDockerStopAction(value?: DockerStopAction): Action;
  hasDockerStopAction(): boolean;
  clearDockerStopAction(): Action;

  getDockerStoreUsernameAction(): DockerStoreUsernameAction | undefined;
  setDockerStoreUsernameAction(value?: DockerStoreUsernameAction): Action;
  hasDockerStoreUsernameAction(): boolean;
  clearDockerStoreUsernameAction(): Action;

  getFileSystemAction(): FileSystemAction | undefined;
  setFileSystemAction(value?: FileSystemAction): Action;
  hasFileSystemAction(): boolean;
  clearFileSystemAction(): Action;

  getFileSystemCopyAction(): FileSystemCopyAction | undefined;
  setFileSystemCopyAction(value?: FileSystemCopyAction): Action;
  hasFileSystemCopyAction(): boolean;
  clearFileSystemCopyAction(): Action;

  getFileSystemMoveAction(): FileSystemMoveAction | undefined;
  setFileSystemMoveAction(value?: FileSystemMoveAction): Action;
  hasFileSystemMoveAction(): boolean;
  clearFileSystemMoveAction(): Action;

  getFileSystemRemoveAction(): FileSystemRemoveAction | undefined;
  setFileSystemRemoveAction(value?: FileSystemRemoveAction): Action;
  hasFileSystemRemoveAction(): boolean;
  clearFileSystemRemoveAction(): Action;

  getFileSystemReportSelectionAction(): FileSystemReportSelectionAction | undefined;
  setFileSystemReportSelectionAction(value?: FileSystemReportSelectionAction): Action;
  hasFileSystemReportSelectionAction(): boolean;
  clearFileSystemReportSelectionAction(): Action;

  getInfraredAction(): InfraredAction | undefined;
  setInfraredAction(value?: InfraredAction): Action;
  hasInfraredAction(): boolean;
  clearInfraredAction(): Action;

  getInfraredHandleReceivedCodeAction(): InfraredHandleReceivedCodeAction | undefined;
  setInfraredHandleReceivedCodeAction(value?: InfraredHandleReceivedCodeAction): Action;
  hasInfraredHandleReceivedCodeAction(): boolean;
  clearInfraredHandleReceivedCodeAction(): Action;

  getInfraredSendCodeAction(): InfraredSendCodeAction | undefined;
  setInfraredSendCodeAction(value?: InfraredSendCodeAction): Action;
  hasInfraredSendCodeAction(): boolean;
  clearInfraredSendCodeAction(): Action;

  getInfraredSetShouldPropagateAction(): InfraredSetShouldPropagateAction | undefined;
  setInfraredSetShouldPropagateAction(value?: InfraredSetShouldPropagateAction): Action;
  hasInfraredSetShouldPropagateAction(): boolean;
  clearInfraredSetShouldPropagateAction(): Action;

  getInfraredSetShouldReceiveAction(): InfraredSetShouldReceiveAction | undefined;
  setInfraredSetShouldReceiveAction(value?: InfraredSetShouldReceiveAction): Action;
  hasInfraredSetShouldReceiveAction(): boolean;
  clearInfraredSetShouldReceiveAction(): Action;

  getInputAction(): InputAction | undefined;
  setInputAction(value?: InputAction): Action;
  hasInputAction(): boolean;
  clearInputAction(): Action;

  getInputCancelAction(): InputCancelAction | undefined;
  setInputCancelAction(value?: InputCancelAction): Action;
  hasInputCancelAction(): boolean;
  clearInputCancelAction(): Action;

  getInputDemandAction(): InputDemandAction | undefined;
  setInputDemandAction(value?: InputDemandAction): Action;
  hasInputDemandAction(): boolean;
  clearInputDemandAction(): Action;

  getInputProvideAction(): InputProvideAction | undefined;
  setInputProvideAction(value?: InputProvideAction): Action;
  hasInputProvideAction(): boolean;
  clearInputProvideAction(): Action;

  getInputResolveAction(): InputResolveAction | undefined;
  setInputResolveAction(value?: InputResolveAction): Action;
  hasInputResolveAction(): boolean;
  clearInputResolveAction(): Action;

  getIpAction(): IpAction | undefined;
  setIpAction(value?: IpAction): Action;
  hasIpAction(): boolean;
  clearIpAction(): Action;

  getIpSetIsConnectedAction(): IpSetIsConnectedAction | undefined;
  setIpSetIsConnectedAction(value?: IpSetIsConnectedAction): Action;
  hasIpSetIsConnectedAction(): boolean;
  clearIpSetIsConnectedAction(): Action;

  getIpUpdateInterfacesAction(): IpUpdateInterfacesAction | undefined;
  setIpUpdateInterfacesAction(value?: IpUpdateInterfacesAction): Action;
  hasIpUpdateInterfacesAction(): boolean;
  clearIpUpdateInterfacesAction(): Action;

  getKeypadAction(): KeypadAction | undefined;
  setKeypadAction(value?: KeypadAction): Action;
  hasKeypadAction(): boolean;
  clearKeypadAction(): Action;

  getKeypadKeyPressAction(): KeypadKeyPressAction | undefined;
  setKeypadKeyPressAction(value?: KeypadKeyPressAction): Action;
  hasKeypadKeyPressAction(): boolean;
  clearKeypadKeyPressAction(): Action;

  getKeypadKeyReleaseAction(): KeypadKeyReleaseAction | undefined;
  setKeypadKeyReleaseAction(value?: KeypadKeyReleaseAction): Action;
  hasKeypadKeyReleaseAction(): boolean;
  clearKeypadKeyReleaseAction(): Action;

  getLightDmAction(): LightDMAction | undefined;
  setLightDmAction(value?: LightDMAction): Action;
  hasLightDmAction(): boolean;
  clearLightDmAction(): Action;

  getLightDmClearEnabledStateAction(): LightDMClearEnabledStateAction | undefined;
  setLightDmClearEnabledStateAction(value?: LightDMClearEnabledStateAction): Action;
  hasLightDmClearEnabledStateAction(): boolean;
  clearLightDmClearEnabledStateAction(): Action;

  getLightDmUpdateStateAction(): LightDMUpdateStateAction | undefined;
  setLightDmUpdateStateAction(value?: LightDMUpdateStateAction): Action;
  hasLightDmUpdateStateAction(): boolean;
  clearLightDmUpdateStateAction(): Action;

  getMainAction(): MainAction | undefined;
  setMainAction(value?: MainAction): Action;
  hasMainAction(): boolean;
  clearMainAction(): Action;

  getMenuAction(): MenuAction | undefined;
  setMenuAction(value?: MenuAction): Action;
  hasMenuAction(): boolean;
  clearMenuAction(): Action;

  getMenuChooseByIconAction(): MenuChooseByIconAction | undefined;
  setMenuChooseByIconAction(value?: MenuChooseByIconAction): Action;
  hasMenuChooseByIconAction(): boolean;
  clearMenuChooseByIconAction(): Action;

  getMenuChooseByIndexAction(): MenuChooseByIndexAction | undefined;
  setMenuChooseByIndexAction(value?: MenuChooseByIndexAction): Action;
  hasMenuChooseByIndexAction(): boolean;
  clearMenuChooseByIndexAction(): Action;

  getMenuChooseByLabelAction(): MenuChooseByLabelAction | undefined;
  setMenuChooseByLabelAction(value?: MenuChooseByLabelAction): Action;
  hasMenuChooseByLabelAction(): boolean;
  clearMenuChooseByLabelAction(): Action;

  getMenuGoBackAction(): MenuGoBackAction | undefined;
  setMenuGoBackAction(value?: MenuGoBackAction): Action;
  hasMenuGoBackAction(): boolean;
  clearMenuGoBackAction(): Action;

  getMenuGoHomeAction(): MenuGoHomeAction | undefined;
  setMenuGoHomeAction(value?: MenuGoHomeAction): Action;
  hasMenuGoHomeAction(): boolean;
  clearMenuGoHomeAction(): Action;

  getMenuScrollAction(): MenuScrollAction | undefined;
  setMenuScrollAction(value?: MenuScrollAction): Action;
  hasMenuScrollAction(): boolean;
  clearMenuScrollAction(): Action;

  getNotificationsAction(): NotificationsAction | undefined;
  setNotificationsAction(value?: NotificationsAction): Action;
  hasNotificationsAction(): boolean;
  clearNotificationsAction(): Action;

  getNotificationsAddAction(): NotificationsAddAction | undefined;
  setNotificationsAddAction(value?: NotificationsAddAction): Action;
  hasNotificationsAddAction(): boolean;
  clearNotificationsAddAction(): Action;

  getNotificationsClearAction(): NotificationsClearAction | undefined;
  setNotificationsClearAction(value?: NotificationsClearAction): Action;
  hasNotificationsClearAction(): boolean;
  clearNotificationsClearAction(): Action;

  getNotificationsClearAllAction(): NotificationsClearAllAction | undefined;
  setNotificationsClearAllAction(value?: NotificationsClearAllAction): Action;
  hasNotificationsClearAllAction(): boolean;
  clearNotificationsClearAllAction(): Action;

  getNotificationsClearByIdAction(): NotificationsClearByIdAction | undefined;
  setNotificationsClearByIdAction(value?: NotificationsClearByIdAction): Action;
  hasNotificationsClearByIdAction(): boolean;
  clearNotificationsClearByIdAction(): Action;

  getNotificationsDisplayAction(): NotificationsDisplayAction | undefined;
  setNotificationsDisplayAction(value?: NotificationsDisplayAction): Action;
  hasNotificationsDisplayAction(): boolean;
  clearNotificationsDisplayAction(): Action;

  getOpenApplicationAction(): OpenApplicationAction | undefined;
  setOpenApplicationAction(value?: OpenApplicationAction): Action;
  hasOpenApplicationAction(): boolean;
  clearOpenApplicationAction(): Action;

  getPowerAction(): PowerAction | undefined;
  setPowerAction(value?: PowerAction): Action;
  hasPowerAction(): boolean;
  clearPowerAction(): Action;

  getPowerOffAction(): PowerOffAction | undefined;
  setPowerOffAction(value?: PowerOffAction): Action;
  hasPowerOffAction(): boolean;
  clearPowerOffAction(): Action;

  getRPiConnectAction(): RPiConnectAction | undefined;
  setRPiConnectAction(value?: RPiConnectAction): Action;
  hasRPiConnectAction(): boolean;
  clearRPiConnectAction(): Action;

  getRPiConnectDoneDownloadingAction(): RPiConnectDoneDownloadingAction | undefined;
  setRPiConnectDoneDownloadingAction(value?: RPiConnectDoneDownloadingAction): Action;
  hasRPiConnectDoneDownloadingAction(): boolean;
  clearRPiConnectDoneDownloadingAction(): Action;

  getRPiConnectSetPendingAction(): RPiConnectSetPendingAction | undefined;
  setRPiConnectSetPendingAction(value?: RPiConnectSetPendingAction): Action;
  hasRPiConnectSetPendingAction(): boolean;
  clearRPiConnectSetPendingAction(): Action;

  getRPiConnectSetStatusAction(): RPiConnectSetStatusAction | undefined;
  setRPiConnectSetStatusAction(value?: RPiConnectSetStatusAction): Action;
  hasRPiConnectSetStatusAction(): boolean;
  clearRPiConnectSetStatusAction(): Action;

  getRPiConnectStartDownloadingAction(): RPiConnectStartDownloadingAction | undefined;
  setRPiConnectStartDownloadingAction(value?: RPiConnectStartDownloadingAction): Action;
  hasRPiConnectStartDownloadingAction(): boolean;
  clearRPiConnectStartDownloadingAction(): Action;

  getRPiConnectUpdateServiceStateAction(): RPiConnectUpdateServiceStateAction | undefined;
  setRPiConnectUpdateServiceStateAction(value?: RPiConnectUpdateServiceStateAction): Action;
  hasRPiConnectUpdateServiceStateAction(): boolean;
  clearRPiConnectUpdateServiceStateAction(): Action;

  getRebootAction(): RebootAction | undefined;
  setRebootAction(value?: RebootAction): Action;
  hasRebootAction(): boolean;
  clearRebootAction(): Action;

  getRegisterAppAction(): RegisterAppAction | undefined;
  setRegisterAppAction(value?: RegisterAppAction): Action;
  hasRegisterAppAction(): boolean;
  clearRegisterAppAction(): Action;

  getRegisterRegularAppAction(): RegisterRegularAppAction | undefined;
  setRegisterRegularAppAction(value?: RegisterRegularAppAction): Action;
  hasRegisterRegularAppAction(): boolean;
  clearRegisterRegularAppAction(): Action;

  getRegisterSettingAppAction(): RegisterSettingAppAction | undefined;
  setRegisterSettingAppAction(value?: RegisterSettingAppAction): Action;
  hasRegisterSettingAppAction(): boolean;
  clearRegisterSettingAppAction(): Action;

  getReplayRecordedSequenceAction(): ReplayRecordedSequenceAction | undefined;
  setReplayRecordedSequenceAction(value?: ReplayRecordedSequenceAction): Action;
  hasReplayRecordedSequenceAction(): boolean;
  clearReplayRecordedSequenceAction(): Action;

  getReportReplayingDoneAction(): ReportReplayingDoneAction | undefined;
  setReportReplayingDoneAction(value?: ReportReplayingDoneAction): Action;
  hasReportReplayingDoneAction(): boolean;
  clearReportReplayingDoneAction(): Action;

  getRgbRingAction(): RgbRingAction | undefined;
  setRgbRingAction(value?: RgbRingAction): Action;
  hasRgbRingAction(): boolean;
  clearRgbRingAction(): Action;

  getRgbRingBlankAction(): RgbRingBlankAction | undefined;
  setRgbRingBlankAction(value?: RgbRingBlankAction): Action;
  hasRgbRingBlankAction(): boolean;
  clearRgbRingBlankAction(): Action;

  getRgbRingBlinkAction(): RgbRingBlinkAction | undefined;
  setRgbRingBlinkAction(value?: RgbRingBlinkAction): Action;
  hasRgbRingBlinkAction(): boolean;
  clearRgbRingBlinkAction(): Action;

  getRgbRingColorfulCommandAction(): RgbRingColorfulCommandAction | undefined;
  setRgbRingColorfulCommandAction(value?: RgbRingColorfulCommandAction): Action;
  hasRgbRingColorfulCommandAction(): boolean;
  clearRgbRingColorfulCommandAction(): Action;

  getRgbRingCommandAction(): RgbRingCommandAction | undefined;
  setRgbRingCommandAction(value?: RgbRingCommandAction): Action;
  hasRgbRingCommandAction(): boolean;
  clearRgbRingCommandAction(): Action;

  getRgbRingFillDownfromAction(): RgbRingFillDownfromAction | undefined;
  setRgbRingFillDownfromAction(value?: RgbRingFillDownfromAction): Action;
  hasRgbRingFillDownfromAction(): boolean;
  clearRgbRingFillDownfromAction(): Action;

  getRgbRingFillUptoAction(): RgbRingFillUptoAction | undefined;
  setRgbRingFillUptoAction(value?: RgbRingFillUptoAction): Action;
  hasRgbRingFillUptoAction(): boolean;
  clearRgbRingFillUptoAction(): Action;

  getRgbRingProgressWheelAction(): RgbRingProgressWheelAction | undefined;
  setRgbRingProgressWheelAction(value?: RgbRingProgressWheelAction): Action;
  hasRgbRingProgressWheelAction(): boolean;
  clearRgbRingProgressWheelAction(): Action;

  getRgbRingProgressWheelStepAction(): RgbRingProgressWheelStepAction | undefined;
  setRgbRingProgressWheelStepAction(value?: RgbRingProgressWheelStepAction): Action;
  hasRgbRingProgressWheelStepAction(): boolean;
  clearRgbRingProgressWheelStepAction(): Action;

  getRgbRingPulseAction(): RgbRingPulseAction | undefined;
  setRgbRingPulseAction(value?: RgbRingPulseAction): Action;
  hasRgbRingPulseAction(): boolean;
  clearRgbRingPulseAction(): Action;

  getRgbRingRainbowAction(): RgbRingRainbowAction | undefined;
  setRgbRingRainbowAction(value?: RgbRingRainbowAction): Action;
  hasRgbRingRainbowAction(): boolean;
  clearRgbRingRainbowAction(): Action;

  getRgbRingSequenceAction(): RgbRingSequenceAction | undefined;
  setRgbRingSequenceAction(value?: RgbRingSequenceAction): Action;
  hasRgbRingSequenceAction(): boolean;
  clearRgbRingSequenceAction(): Action;

  getRgbRingSetAllAction(): RgbRingSetAllAction | undefined;
  setRgbRingSetAllAction(value?: RgbRingSetAllAction): Action;
  hasRgbRingSetAllAction(): boolean;
  clearRgbRingSetAllAction(): Action;

  getRgbRingSetBrightnessAction(): RgbRingSetBrightnessAction | undefined;
  setRgbRingSetBrightnessAction(value?: RgbRingSetBrightnessAction): Action;
  hasRgbRingSetBrightnessAction(): boolean;
  clearRgbRingSetBrightnessAction(): Action;

  getRgbRingSetEnabledAction(): RgbRingSetEnabledAction | undefined;
  setRgbRingSetEnabledAction(value?: RgbRingSetEnabledAction): Action;
  hasRgbRingSetEnabledAction(): boolean;
  clearRgbRingSetEnabledAction(): Action;

  getRgbRingSetIsBusyAction(): RgbRingSetIsBusyAction | undefined;
  setRgbRingSetIsBusyAction(value?: RgbRingSetIsBusyAction): Action;
  hasRgbRingSetIsBusyAction(): boolean;
  clearRgbRingSetIsBusyAction(): Action;

  getRgbRingSpinningWheelAction(): RgbRingSpinningWheelAction | undefined;
  setRgbRingSpinningWheelAction(value?: RgbRingSpinningWheelAction): Action;
  hasRgbRingSpinningWheelAction(): boolean;
  clearRgbRingSpinningWheelAction(): Action;

  getRgbRingWaitableCommandAction(): RgbRingWaitableCommandAction | undefined;
  setRgbRingWaitableCommandAction(value?: RgbRingWaitableCommandAction): Action;
  hasRgbRingWaitableCommandAction(): boolean;
  clearRgbRingWaitableCommandAction(): Action;

  getSshAction(): SSHAction | undefined;
  setSshAction(value?: SSHAction): Action;
  hasSshAction(): boolean;
  clearSshAction(): Action;

  getSshClearEnabledStateAction(): SSHClearEnabledStateAction | undefined;
  setSshClearEnabledStateAction(value?: SSHClearEnabledStateAction): Action;
  hasSshClearEnabledStateAction(): boolean;
  clearSshClearEnabledStateAction(): Action;

  getSshUpdateStateAction(): SSHUpdateStateAction | undefined;
  setSshUpdateStateAction(value?: SSHUpdateStateAction): Action;
  hasSshUpdateStateAction(): boolean;
  clearSshUpdateStateAction(): Action;

  getSensorsAction(): SensorsAction | undefined;
  setSensorsAction(value?: SensorsAction): Action;
  hasSensorsAction(): boolean;
  clearSensorsAction(): Action;

  getSensorsReportReadingAction(): SensorsReportReadingAction | undefined;
  setSensorsReportReadingAction(value?: SensorsReportReadingAction): Action;
  hasSensorsReportReadingAction(): boolean;
  clearSensorsReportReadingAction(): Action;

  getSetAreEnclosuresVisibleAction(): SetAreEnclosuresVisibleAction | undefined;
  setSetAreEnclosuresVisibleAction(value?: SetAreEnclosuresVisibleAction): Action;
  hasSetAreEnclosuresVisibleAction(): boolean;
  clearSetAreEnclosuresVisibleAction(): Action;

  getSetMenuPathAction(): SetMenuPathAction | undefined;
  setSetMenuPathAction(value?: SetMenuPathAction): Action;
  hasSetMenuPathAction(): boolean;
  clearSetMenuPathAction(): Action;

  getSettingsAction(): SettingsAction | undefined;
  setSettingsAction(value?: SettingsAction): Action;
  hasSettingsAction(): boolean;
  clearSettingsAction(): Action;

  getSettingsClearServiceErrorsAction(): SettingsClearServiceErrorsAction | undefined;
  setSettingsClearServiceErrorsAction(value?: SettingsClearServiceErrorsAction): Action;
  hasSettingsClearServiceErrorsAction(): boolean;
  clearSettingsClearServiceErrorsAction(): Action;

  getSettingsReportServiceErrorAction(): SettingsReportServiceErrorAction | undefined;
  setSettingsReportServiceErrorAction(value?: SettingsReportServiceErrorAction): Action;
  hasSettingsReportServiceErrorAction(): boolean;
  clearSettingsReportServiceErrorAction(): Action;

  getSettingsServiceAction(): SettingsServiceAction | undefined;
  setSettingsServiceAction(value?: SettingsServiceAction): Action;
  hasSettingsServiceAction(): boolean;
  clearSettingsServiceAction(): Action;

  getSettingsServiceSetIsEnabledAction(): SettingsServiceSetIsEnabledAction | undefined;
  setSettingsServiceSetIsEnabledAction(value?: SettingsServiceSetIsEnabledAction): Action;
  hasSettingsServiceSetIsEnabledAction(): boolean;
  clearSettingsServiceSetIsEnabledAction(): Action;

  getSettingsServiceSetLogLevelAction(): SettingsServiceSetLogLevelAction | undefined;
  setSettingsServiceSetLogLevelAction(value?: SettingsServiceSetLogLevelAction): Action;
  hasSettingsServiceSetLogLevelAction(): boolean;
  clearSettingsServiceSetLogLevelAction(): Action;

  getSettingsServiceSetShouldRestartAction(): SettingsServiceSetShouldRestartAction | undefined;
  setSettingsServiceSetShouldRestartAction(value?: SettingsServiceSetShouldRestartAction): Action;
  hasSettingsServiceSetShouldRestartAction(): boolean;
  clearSettingsServiceSetShouldRestartAction(): Action;

  getSettingsServiceSetStatusAction(): SettingsServiceSetStatusAction | undefined;
  setSettingsServiceSetStatusAction(value?: SettingsServiceSetStatusAction): Action;
  hasSettingsServiceSetStatusAction(): boolean;
  clearSettingsServiceSetStatusAction(): Action;

  getSettingsSetServicesAction(): SettingsSetServicesAction | undefined;
  setSettingsSetServicesAction(value?: SettingsSetServicesAction): Action;
  hasSettingsSetServicesAction(): boolean;
  clearSettingsSetServicesAction(): Action;

  getSettingsStartServiceAction(): SettingsStartServiceAction | undefined;
  setSettingsStartServiceAction(value?: SettingsStartServiceAction): Action;
  hasSettingsStartServiceAction(): boolean;
  clearSettingsStartServiceAction(): Action;

  getSettingsStopServiceAction(): SettingsStopServiceAction | undefined;
  setSettingsStopServiceAction(value?: SettingsStopServiceAction): Action;
  hasSettingsStopServiceAction(): boolean;
  clearSettingsStopServiceAction(): Action;

  getSettingsToggleBetaVersionsAction(): SettingsToggleBetaVersionsAction | undefined;
  setSettingsToggleBetaVersionsAction(value?: SettingsToggleBetaVersionsAction): Action;
  hasSettingsToggleBetaVersionsAction(): boolean;
  clearSettingsToggleBetaVersionsAction(): Action;

  getSettingsTogglePdbSignalAction(): SettingsTogglePdbSignalAction | undefined;
  setSettingsTogglePdbSignalAction(value?: SettingsTogglePdbSignalAction): Action;
  hasSettingsTogglePdbSignalAction(): boolean;
  clearSettingsTogglePdbSignalAction(): Action;

  getSettingsToggleVisualDebugAction(): SettingsToggleVisualDebugAction | undefined;
  setSettingsToggleVisualDebugAction(value?: SettingsToggleVisualDebugAction): Action;
  hasSettingsToggleVisualDebugAction(): boolean;
  clearSettingsToggleVisualDebugAction(): Action;

  getSpeechRecognitionAction(): SpeechRecognitionAction | undefined;
  setSpeechRecognitionAction(value?: SpeechRecognitionAction): Action;
  hasSpeechRecognitionAction(): boolean;
  clearSpeechRecognitionAction(): Action;

  getSpeechRecognitionReportIntentDetectionAction(): SpeechRecognitionReportIntentDetectionAction | undefined;
  setSpeechRecognitionReportIntentDetectionAction(value?: SpeechRecognitionReportIntentDetectionAction): Action;
  hasSpeechRecognitionReportIntentDetectionAction(): boolean;
  clearSpeechRecognitionReportIntentDetectionAction(): Action;

  getSpeechRecognitionReportSpeechAction(): SpeechRecognitionReportSpeechAction | undefined;
  setSpeechRecognitionReportSpeechAction(value?: SpeechRecognitionReportSpeechAction): Action;
  hasSpeechRecognitionReportSpeechAction(): boolean;
  clearSpeechRecognitionReportSpeechAction(): Action;

  getSpeechRecognitionReportWakeWordDetectionAction(): SpeechRecognitionReportWakeWordDetectionAction | undefined;
  setSpeechRecognitionReportWakeWordDetectionAction(value?: SpeechRecognitionReportWakeWordDetectionAction): Action;
  hasSpeechRecognitionReportWakeWordDetectionAction(): boolean;
  clearSpeechRecognitionReportWakeWordDetectionAction(): Action;

  getSpeechRecognitionSetIsAssistantActiveAction(): SpeechRecognitionSetIsAssistantActiveAction | undefined;
  setSpeechRecognitionSetIsAssistantActiveAction(value?: SpeechRecognitionSetIsAssistantActiveAction): Action;
  hasSpeechRecognitionSetIsAssistantActiveAction(): boolean;
  clearSpeechRecognitionSetIsAssistantActiveAction(): Action;

  getSpeechRecognitionSetIsIntentsActiveAction(): SpeechRecognitionSetIsIntentsActiveAction | undefined;
  setSpeechRecognitionSetIsIntentsActiveAction(value?: SpeechRecognitionSetIsIntentsActiveAction): Action;
  hasSpeechRecognitionSetIsIntentsActiveAction(): boolean;
  clearSpeechRecognitionSetIsIntentsActiveAction(): Action;

  getSpeechRecognitionSetSelectedEngineAction(): SpeechRecognitionSetSelectedEngineAction | undefined;
  setSpeechRecognitionSetSelectedEngineAction(value?: SpeechRecognitionSetSelectedEngineAction): Action;
  hasSpeechRecognitionSetSelectedEngineAction(): boolean;
  clearSpeechRecognitionSetSelectedEngineAction(): Action;

  getSpeechSynthesisAction(): SpeechSynthesisAction | undefined;
  setSpeechSynthesisAction(value?: SpeechSynthesisAction): Action;
  hasSpeechSynthesisAction(): boolean;
  clearSpeechSynthesisAction(): Action;

  getSpeechSynthesisReadTextAction(): SpeechSynthesisReadTextAction | undefined;
  setSpeechSynthesisReadTextAction(value?: SpeechSynthesisReadTextAction): Action;
  hasSpeechSynthesisReadTextAction(): boolean;
  clearSpeechSynthesisReadTextAction(): Action;

  getSpeechSynthesisSetSelectedEngineAction(): SpeechSynthesisSetSelectedEngineAction | undefined;
  setSpeechSynthesisSetSelectedEngineAction(value?: SpeechSynthesisSetSelectedEngineAction): Action;
  hasSpeechSynthesisSetSelectedEngineAction(): boolean;
  clearSpeechSynthesisSetSelectedEngineAction(): Action;

  getStatusIconsAction(): StatusIconsAction | undefined;
  setStatusIconsAction(value?: StatusIconsAction): Action;
  hasStatusIconsAction(): boolean;
  clearStatusIconsAction(): Action;

  getStatusIconsRegisterAction(): StatusIconsRegisterAction | undefined;
  setStatusIconsRegisterAction(value?: StatusIconsRegisterAction): Action;
  hasStatusIconsRegisterAction(): boolean;
  clearStatusIconsRegisterAction(): Action;

  getToggleRecordingAction(): ToggleRecordingAction | undefined;
  setToggleRecordingAction(value?: ToggleRecordingAction): Action;
  hasToggleRecordingAction(): boolean;
  clearToggleRecordingAction(): Action;

  getUpdateManagerAction(): UpdateManagerAction | undefined;
  setUpdateManagerAction(value?: UpdateManagerAction): Action;
  hasUpdateManagerAction(): boolean;
  clearUpdateManagerAction(): Action;

  getUpdateManagerReportFailedCheckAction(): UpdateManagerReportFailedCheckAction | undefined;
  setUpdateManagerReportFailedCheckAction(value?: UpdateManagerReportFailedCheckAction): Action;
  hasUpdateManagerReportFailedCheckAction(): boolean;
  clearUpdateManagerReportFailedCheckAction(): Action;

  getUpdateManagerRequestCheckAction(): UpdateManagerRequestCheckAction | undefined;
  setUpdateManagerRequestCheckAction(value?: UpdateManagerRequestCheckAction): Action;
  hasUpdateManagerRequestCheckAction(): boolean;
  clearUpdateManagerRequestCheckAction(): Action;

  getUpdateManagerRequestUpdateAction(): UpdateManagerRequestUpdateAction | undefined;
  setUpdateManagerRequestUpdateAction(value?: UpdateManagerRequestUpdateAction): Action;
  hasUpdateManagerRequestUpdateAction(): boolean;
  clearUpdateManagerRequestUpdateAction(): Action;

  getUpdateManagerSetVersionsAction(): UpdateManagerSetVersionsAction | undefined;
  setUpdateManagerSetVersionsAction(value?: UpdateManagerSetVersionsAction): Action;
  hasUpdateManagerSetVersionsAction(): boolean;
  clearUpdateManagerSetVersionsAction(): Action;

  getUsersAction(): UsersAction | undefined;
  setUsersAction(value?: UsersAction): Action;
  hasUsersAction(): boolean;
  clearUsersAction(): Action;

  getUsersCreateUserAction(): UsersCreateUserAction | undefined;
  setUsersCreateUserAction(value?: UsersCreateUserAction): Action;
  hasUsersCreateUserAction(): boolean;
  clearUsersCreateUserAction(): Action;

  getUsersDeleteUserAction(): UsersDeleteUserAction | undefined;
  setUsersDeleteUserAction(value?: UsersDeleteUserAction): Action;
  hasUsersDeleteUserAction(): boolean;
  clearUsersDeleteUserAction(): Action;

  getUsersResetPasswordAction(): UsersResetPasswordAction | undefined;
  setUsersResetPasswordAction(value?: UsersResetPasswordAction): Action;
  hasUsersResetPasswordAction(): boolean;
  clearUsersResetPasswordAction(): Action;

  getUsersSetUsersAction(): UsersSetUsersAction | undefined;
  setUsersSetUsersAction(value?: UsersSetUsersAction): Action;
  hasUsersSetUsersAction(): boolean;
  clearUsersSetUsersAction(): Action;

  getVsCodeAction(): VSCodeAction | undefined;
  setVsCodeAction(value?: VSCodeAction): Action;
  hasVsCodeAction(): boolean;
  clearVsCodeAction(): Action;

  getVsCodeDoneDownloadingAction(): VSCodeDoneDownloadingAction | undefined;
  setVsCodeDoneDownloadingAction(value?: VSCodeDoneDownloadingAction): Action;
  hasVsCodeDoneDownloadingAction(): boolean;
  clearVsCodeDoneDownloadingAction(): Action;

  getVsCodeSetPendingAction(): VSCodeSetPendingAction | undefined;
  setVsCodeSetPendingAction(value?: VSCodeSetPendingAction): Action;
  hasVsCodeSetPendingAction(): boolean;
  clearVsCodeSetPendingAction(): Action;

  getVsCodeSetStatusAction(): VSCodeSetStatusAction | undefined;
  setVsCodeSetStatusAction(value?: VSCodeSetStatusAction): Action;
  hasVsCodeSetStatusAction(): boolean;
  clearVsCodeSetStatusAction(): Action;

  getVsCodeStartDownloadingAction(): VSCodeStartDownloadingAction | undefined;
  setVsCodeStartDownloadingAction(value?: VSCodeStartDownloadingAction): Action;
  hasVsCodeStartDownloadingAction(): boolean;
  clearVsCodeStartDownloadingAction(): Action;

  getWiFiAction(): WiFiAction | undefined;
  setWiFiAction(value?: WiFiAction): Action;
  hasWiFiAction(): boolean;
  clearWiFiAction(): Action;

  getWiFiInputConnectionAction(): WiFiInputConnectionAction | undefined;
  setWiFiInputConnectionAction(value?: WiFiInputConnectionAction): Action;
  hasWiFiInputConnectionAction(): boolean;
  clearWiFiInputConnectionAction(): Action;

  getWiFiSetHasVisitedOnboardingAction(): WiFiSetHasVisitedOnboardingAction | undefined;
  setWiFiSetHasVisitedOnboardingAction(value?: WiFiSetHasVisitedOnboardingAction): Action;
  hasWiFiSetHasVisitedOnboardingAction(): boolean;
  clearWiFiSetHasVisitedOnboardingAction(): Action;

  getWiFiUpdateAction(): WiFiUpdateAction | undefined;
  setWiFiUpdateAction(value?: WiFiUpdateAction): Action;
  hasWiFiUpdateAction(): boolean;
  clearWiFiUpdateAction(): Action;

  getWiFiUpdateRequestAction(): WiFiUpdateRequestAction | undefined;
  setWiFiUpdateRequestAction(value?: WiFiUpdateRequestAction): Action;
  hasWiFiUpdateRequestAction(): boolean;
  clearWiFiUpdateRequestAction(): Action;

  getActionCase(): Action.ActionCase;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Action.AsObject;
  static toObject(includeInstance: boolean, msg: Action): Action.AsObject;
  static serializeBinaryToWriter(message: Action, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Action;
  static deserializeBinaryFromReader(message: Action, reader: jspb.BinaryReader): Action;
}

export namespace Action {
  export type AsObject = {
    assistantAction?: AssistantAction.AsObject,
    assistantDownloadOllamaModelAction?: AssistantDownloadOllamaModelAction.AsObject,
    assistantReportAction?: AssistantReportAction.AsObject,
    assistantSetIsActiveAction?: AssistantSetIsActiveAction.AsObject,
    assistantSetSelectedLlmAction?: AssistantSetSelectedLLMAction.AsObject,
    assistantSetSelectedModelAction?: AssistantSetSelectedModelAction.AsObject,
    assistantStartListeningAction?: AssistantStartListeningAction.AsObject,
    assistantStopListeningAction?: AssistantStopListeningAction.AsObject,
    audioAction?: AudioAction.AsObject,
    audioChangeVolumeAction?: AudioChangeVolumeAction.AsObject,
    audioInstallDriverAction?: AudioInstallDriverAction.AsObject,
    audioPlayAudioSampleAction?: AudioPlayAudioSampleAction.AsObject,
    audioPlayAudioSequenceAction?: AudioPlayAudioSequenceAction.AsObject,
    audioPlayChimeAction?: AudioPlayChimeAction.AsObject,
    audioPlaybackDoneAction?: AudioPlaybackDoneAction.AsObject,
    audioSetMuteStatusAction?: AudioSetMuteStatusAction.AsObject,
    audioSetVolumeAction?: AudioSetVolumeAction.AsObject,
    audioToggleMuteStatusAction?: AudioToggleMuteStatusAction.AsObject,
    cameraAction?: CameraAction.AsObject,
    cameraReportBarcodeAction?: CameraReportBarcodeAction.AsObject,
    cameraStartViewfinderAction?: CameraStartViewfinderAction.AsObject,
    closeApplicationAction?: CloseApplicationAction.AsObject,
    deregisterRegularAppAction?: DeregisterRegularAppAction.AsObject,
    displayAction?: DisplayAction.AsObject,
    displayPauseAction?: DisplayPauseAction.AsObject,
    displayResumeAction?: DisplayResumeAction.AsObject,
    dockerAction?: DockerAction.AsObject,
    dockerImageAction?: DockerImageAction.AsObject,
    dockerImageFetchAction?: DockerImageFetchAction.AsObject,
    dockerImageFetchCompositionAction?: DockerImageFetchCompositionAction.AsObject,
    dockerImageReleaseCompositionAction?: DockerImageReleaseCompositionAction.AsObject,
    dockerImageRemoveAction?: DockerImageRemoveAction.AsObject,
    dockerImageRemoveCompositionAction?: DockerImageRemoveCompositionAction.AsObject,
    dockerImageRemoveContainerAction?: DockerImageRemoveContainerAction.AsObject,
    dockerImageRunCompositionAction?: DockerImageRunCompositionAction.AsObject,
    dockerImageRunContainerAction?: DockerImageRunContainerAction.AsObject,
    dockerImageSetDockerIdAction?: DockerImageSetDockerIdAction.AsObject,
    dockerImageSetStatusAction?: DockerImageSetStatusAction.AsObject,
    dockerImageStopCompositionAction?: DockerImageStopCompositionAction.AsObject,
    dockerImageStopContainerAction?: DockerImageStopContainerAction.AsObject,
    dockerInstallAction?: DockerInstallAction.AsObject,
    dockerRemoveUsernameAction?: DockerRemoveUsernameAction.AsObject,
    dockerSetStatusAction?: DockerSetStatusAction.AsObject,
    dockerStartAction?: DockerStartAction.AsObject,
    dockerStopAction?: DockerStopAction.AsObject,
    dockerStoreUsernameAction?: DockerStoreUsernameAction.AsObject,
    fileSystemAction?: FileSystemAction.AsObject,
    fileSystemCopyAction?: FileSystemCopyAction.AsObject,
    fileSystemMoveAction?: FileSystemMoveAction.AsObject,
    fileSystemRemoveAction?: FileSystemRemoveAction.AsObject,
    fileSystemReportSelectionAction?: FileSystemReportSelectionAction.AsObject,
    infraredAction?: InfraredAction.AsObject,
    infraredHandleReceivedCodeAction?: InfraredHandleReceivedCodeAction.AsObject,
    infraredSendCodeAction?: InfraredSendCodeAction.AsObject,
    infraredSetShouldPropagateAction?: InfraredSetShouldPropagateAction.AsObject,
    infraredSetShouldReceiveAction?: InfraredSetShouldReceiveAction.AsObject,
    inputAction?: InputAction.AsObject,
    inputCancelAction?: InputCancelAction.AsObject,
    inputDemandAction?: InputDemandAction.AsObject,
    inputProvideAction?: InputProvideAction.AsObject,
    inputResolveAction?: InputResolveAction.AsObject,
    ipAction?: IpAction.AsObject,
    ipSetIsConnectedAction?: IpSetIsConnectedAction.AsObject,
    ipUpdateInterfacesAction?: IpUpdateInterfacesAction.AsObject,
    keypadAction?: KeypadAction.AsObject,
    keypadKeyPressAction?: KeypadKeyPressAction.AsObject,
    keypadKeyReleaseAction?: KeypadKeyReleaseAction.AsObject,
    lightDmAction?: LightDMAction.AsObject,
    lightDmClearEnabledStateAction?: LightDMClearEnabledStateAction.AsObject,
    lightDmUpdateStateAction?: LightDMUpdateStateAction.AsObject,
    mainAction?: MainAction.AsObject,
    menuAction?: MenuAction.AsObject,
    menuChooseByIconAction?: MenuChooseByIconAction.AsObject,
    menuChooseByIndexAction?: MenuChooseByIndexAction.AsObject,
    menuChooseByLabelAction?: MenuChooseByLabelAction.AsObject,
    menuGoBackAction?: MenuGoBackAction.AsObject,
    menuGoHomeAction?: MenuGoHomeAction.AsObject,
    menuScrollAction?: MenuScrollAction.AsObject,
    notificationsAction?: NotificationsAction.AsObject,
    notificationsAddAction?: NotificationsAddAction.AsObject,
    notificationsClearAction?: NotificationsClearAction.AsObject,
    notificationsClearAllAction?: NotificationsClearAllAction.AsObject,
    notificationsClearByIdAction?: NotificationsClearByIdAction.AsObject,
    notificationsDisplayAction?: NotificationsDisplayAction.AsObject,
    openApplicationAction?: OpenApplicationAction.AsObject,
    powerAction?: PowerAction.AsObject,
    powerOffAction?: PowerOffAction.AsObject,
    rPiConnectAction?: RPiConnectAction.AsObject,
    rPiConnectDoneDownloadingAction?: RPiConnectDoneDownloadingAction.AsObject,
    rPiConnectSetPendingAction?: RPiConnectSetPendingAction.AsObject,
    rPiConnectSetStatusAction?: RPiConnectSetStatusAction.AsObject,
    rPiConnectStartDownloadingAction?: RPiConnectStartDownloadingAction.AsObject,
    rPiConnectUpdateServiceStateAction?: RPiConnectUpdateServiceStateAction.AsObject,
    rebootAction?: RebootAction.AsObject,
    registerAppAction?: RegisterAppAction.AsObject,
    registerRegularAppAction?: RegisterRegularAppAction.AsObject,
    registerSettingAppAction?: RegisterSettingAppAction.AsObject,
    replayRecordedSequenceAction?: ReplayRecordedSequenceAction.AsObject,
    reportReplayingDoneAction?: ReportReplayingDoneAction.AsObject,
    rgbRingAction?: RgbRingAction.AsObject,
    rgbRingBlankAction?: RgbRingBlankAction.AsObject,
    rgbRingBlinkAction?: RgbRingBlinkAction.AsObject,
    rgbRingColorfulCommandAction?: RgbRingColorfulCommandAction.AsObject,
    rgbRingCommandAction?: RgbRingCommandAction.AsObject,
    rgbRingFillDownfromAction?: RgbRingFillDownfromAction.AsObject,
    rgbRingFillUptoAction?: RgbRingFillUptoAction.AsObject,
    rgbRingProgressWheelAction?: RgbRingProgressWheelAction.AsObject,
    rgbRingProgressWheelStepAction?: RgbRingProgressWheelStepAction.AsObject,
    rgbRingPulseAction?: RgbRingPulseAction.AsObject,
    rgbRingRainbowAction?: RgbRingRainbowAction.AsObject,
    rgbRingSequenceAction?: RgbRingSequenceAction.AsObject,
    rgbRingSetAllAction?: RgbRingSetAllAction.AsObject,
    rgbRingSetBrightnessAction?: RgbRingSetBrightnessAction.AsObject,
    rgbRingSetEnabledAction?: RgbRingSetEnabledAction.AsObject,
    rgbRingSetIsBusyAction?: RgbRingSetIsBusyAction.AsObject,
    rgbRingSpinningWheelAction?: RgbRingSpinningWheelAction.AsObject,
    rgbRingWaitableCommandAction?: RgbRingWaitableCommandAction.AsObject,
    sshAction?: SSHAction.AsObject,
    sshClearEnabledStateAction?: SSHClearEnabledStateAction.AsObject,
    sshUpdateStateAction?: SSHUpdateStateAction.AsObject,
    sensorsAction?: SensorsAction.AsObject,
    sensorsReportReadingAction?: SensorsReportReadingAction.AsObject,
    setAreEnclosuresVisibleAction?: SetAreEnclosuresVisibleAction.AsObject,
    setMenuPathAction?: SetMenuPathAction.AsObject,
    settingsAction?: SettingsAction.AsObject,
    settingsClearServiceErrorsAction?: SettingsClearServiceErrorsAction.AsObject,
    settingsReportServiceErrorAction?: SettingsReportServiceErrorAction.AsObject,
    settingsServiceAction?: SettingsServiceAction.AsObject,
    settingsServiceSetIsEnabledAction?: SettingsServiceSetIsEnabledAction.AsObject,
    settingsServiceSetLogLevelAction?: SettingsServiceSetLogLevelAction.AsObject,
    settingsServiceSetShouldRestartAction?: SettingsServiceSetShouldRestartAction.AsObject,
    settingsServiceSetStatusAction?: SettingsServiceSetStatusAction.AsObject,
    settingsSetServicesAction?: SettingsSetServicesAction.AsObject,
    settingsStartServiceAction?: SettingsStartServiceAction.AsObject,
    settingsStopServiceAction?: SettingsStopServiceAction.AsObject,
    settingsToggleBetaVersionsAction?: SettingsToggleBetaVersionsAction.AsObject,
    settingsTogglePdbSignalAction?: SettingsTogglePdbSignalAction.AsObject,
    settingsToggleVisualDebugAction?: SettingsToggleVisualDebugAction.AsObject,
    speechRecognitionAction?: SpeechRecognitionAction.AsObject,
    speechRecognitionReportIntentDetectionAction?: SpeechRecognitionReportIntentDetectionAction.AsObject,
    speechRecognitionReportSpeechAction?: SpeechRecognitionReportSpeechAction.AsObject,
    speechRecognitionReportWakeWordDetectionAction?: SpeechRecognitionReportWakeWordDetectionAction.AsObject,
    speechRecognitionSetIsAssistantActiveAction?: SpeechRecognitionSetIsAssistantActiveAction.AsObject,
    speechRecognitionSetIsIntentsActiveAction?: SpeechRecognitionSetIsIntentsActiveAction.AsObject,
    speechRecognitionSetSelectedEngineAction?: SpeechRecognitionSetSelectedEngineAction.AsObject,
    speechSynthesisAction?: SpeechSynthesisAction.AsObject,
    speechSynthesisReadTextAction?: SpeechSynthesisReadTextAction.AsObject,
    speechSynthesisSetSelectedEngineAction?: SpeechSynthesisSetSelectedEngineAction.AsObject,
    statusIconsAction?: StatusIconsAction.AsObject,
    statusIconsRegisterAction?: StatusIconsRegisterAction.AsObject,
    toggleRecordingAction?: ToggleRecordingAction.AsObject,
    updateManagerAction?: UpdateManagerAction.AsObject,
    updateManagerReportFailedCheckAction?: UpdateManagerReportFailedCheckAction.AsObject,
    updateManagerRequestCheckAction?: UpdateManagerRequestCheckAction.AsObject,
    updateManagerRequestUpdateAction?: UpdateManagerRequestUpdateAction.AsObject,
    updateManagerSetVersionsAction?: UpdateManagerSetVersionsAction.AsObject,
    usersAction?: UsersAction.AsObject,
    usersCreateUserAction?: UsersCreateUserAction.AsObject,
    usersDeleteUserAction?: UsersDeleteUserAction.AsObject,
    usersResetPasswordAction?: UsersResetPasswordAction.AsObject,
    usersSetUsersAction?: UsersSetUsersAction.AsObject,
    vsCodeAction?: VSCodeAction.AsObject,
    vsCodeDoneDownloadingAction?: VSCodeDoneDownloadingAction.AsObject,
    vsCodeSetPendingAction?: VSCodeSetPendingAction.AsObject,
    vsCodeSetStatusAction?: VSCodeSetStatusAction.AsObject,
    vsCodeStartDownloadingAction?: VSCodeStartDownloadingAction.AsObject,
    wiFiAction?: WiFiAction.AsObject,
    wiFiInputConnectionAction?: WiFiInputConnectionAction.AsObject,
    wiFiSetHasVisitedOnboardingAction?: WiFiSetHasVisitedOnboardingAction.AsObject,
    wiFiUpdateAction?: WiFiUpdateAction.AsObject,
    wiFiUpdateRequestAction?: WiFiUpdateRequestAction.AsObject,
  }

  export enum ActionCase { 
    ACTION_NOT_SET = 0,
    ASSISTANT_ACTION = 1,
    ASSISTANT_DOWNLOAD_OLLAMA_MODEL_ACTION = 2,
    ASSISTANT_REPORT_ACTION = 3,
    ASSISTANT_SET_IS_ACTIVE_ACTION = 4,
    ASSISTANT_SET_SELECTED_LLM_ACTION = 5,
    ASSISTANT_SET_SELECTED_MODEL_ACTION = 6,
    ASSISTANT_START_LISTENING_ACTION = 7,
    ASSISTANT_STOP_LISTENING_ACTION = 8,
    AUDIO_ACTION = 9,
    AUDIO_CHANGE_VOLUME_ACTION = 10,
    AUDIO_INSTALL_DRIVER_ACTION = 11,
    AUDIO_PLAY_AUDIO_SAMPLE_ACTION = 12,
    AUDIO_PLAY_AUDIO_SEQUENCE_ACTION = 13,
    AUDIO_PLAY_CHIME_ACTION = 14,
    AUDIO_PLAYBACK_DONE_ACTION = 15,
    AUDIO_SET_MUTE_STATUS_ACTION = 16,
    AUDIO_SET_VOLUME_ACTION = 17,
    AUDIO_TOGGLE_MUTE_STATUS_ACTION = 18,
    CAMERA_ACTION = 19,
    CAMERA_REPORT_BARCODE_ACTION = 20,
    CAMERA_START_VIEWFINDER_ACTION = 21,
    CLOSE_APPLICATION_ACTION = 22,
    DEREGISTER_REGULAR_APP_ACTION = 23,
    DISPLAY_ACTION = 24,
    DISPLAY_PAUSE_ACTION = 25,
    DISPLAY_RESUME_ACTION = 26,
    DOCKER_ACTION = 27,
    DOCKER_IMAGE_ACTION = 28,
    DOCKER_IMAGE_FETCH_ACTION = 29,
    DOCKER_IMAGE_FETCH_COMPOSITION_ACTION = 30,
    DOCKER_IMAGE_RELEASE_COMPOSITION_ACTION = 31,
    DOCKER_IMAGE_REMOVE_ACTION = 32,
    DOCKER_IMAGE_REMOVE_COMPOSITION_ACTION = 33,
    DOCKER_IMAGE_REMOVE_CONTAINER_ACTION = 34,
    DOCKER_IMAGE_RUN_COMPOSITION_ACTION = 35,
    DOCKER_IMAGE_RUN_CONTAINER_ACTION = 36,
    DOCKER_IMAGE_SET_DOCKER_ID_ACTION = 37,
    DOCKER_IMAGE_SET_STATUS_ACTION = 38,
    DOCKER_IMAGE_STOP_COMPOSITION_ACTION = 39,
    DOCKER_IMAGE_STOP_CONTAINER_ACTION = 40,
    DOCKER_INSTALL_ACTION = 41,
    DOCKER_REMOVE_USERNAME_ACTION = 42,
    DOCKER_SET_STATUS_ACTION = 43,
    DOCKER_START_ACTION = 44,
    DOCKER_STOP_ACTION = 45,
    DOCKER_STORE_USERNAME_ACTION = 46,
    FILE_SYSTEM_ACTION = 47,
    FILE_SYSTEM_COPY_ACTION = 48,
    FILE_SYSTEM_MOVE_ACTION = 49,
    FILE_SYSTEM_REMOVE_ACTION = 50,
    FILE_SYSTEM_REPORT_SELECTION_ACTION = 51,
    INFRARED_ACTION = 52,
    INFRARED_HANDLE_RECEIVED_CODE_ACTION = 53,
    INFRARED_SEND_CODE_ACTION = 54,
    INFRARED_SET_SHOULD_PROPAGATE_ACTION = 55,
    INFRARED_SET_SHOULD_RECEIVE_ACTION = 56,
    INPUT_ACTION = 57,
    INPUT_CANCEL_ACTION = 58,
    INPUT_DEMAND_ACTION = 59,
    INPUT_PROVIDE_ACTION = 60,
    INPUT_RESOLVE_ACTION = 61,
    IP_ACTION = 62,
    IP_SET_IS_CONNECTED_ACTION = 63,
    IP_UPDATE_INTERFACES_ACTION = 64,
    KEYPAD_ACTION = 65,
    KEYPAD_KEY_PRESS_ACTION = 66,
    KEYPAD_KEY_RELEASE_ACTION = 67,
    LIGHT_DM_ACTION = 68,
    LIGHT_DM_CLEAR_ENABLED_STATE_ACTION = 69,
    LIGHT_DM_UPDATE_STATE_ACTION = 70,
    MAIN_ACTION = 71,
    MENU_ACTION = 72,
    MENU_CHOOSE_BY_ICON_ACTION = 73,
    MENU_CHOOSE_BY_INDEX_ACTION = 74,
    MENU_CHOOSE_BY_LABEL_ACTION = 75,
    MENU_GO_BACK_ACTION = 76,
    MENU_GO_HOME_ACTION = 77,
    MENU_SCROLL_ACTION = 78,
    NOTIFICATIONS_ACTION = 79,
    NOTIFICATIONS_ADD_ACTION = 80,
    NOTIFICATIONS_CLEAR_ACTION = 81,
    NOTIFICATIONS_CLEAR_ALL_ACTION = 82,
    NOTIFICATIONS_CLEAR_BY_ID_ACTION = 83,
    NOTIFICATIONS_DISPLAY_ACTION = 84,
    OPEN_APPLICATION_ACTION = 85,
    POWER_ACTION = 86,
    POWER_OFF_ACTION = 87,
    R_PI_CONNECT_ACTION = 88,
    R_PI_CONNECT_DONE_DOWNLOADING_ACTION = 89,
    R_PI_CONNECT_SET_PENDING_ACTION = 90,
    R_PI_CONNECT_SET_STATUS_ACTION = 91,
    R_PI_CONNECT_START_DOWNLOADING_ACTION = 92,
    R_PI_CONNECT_UPDATE_SERVICE_STATE_ACTION = 93,
    REBOOT_ACTION = 94,
    REGISTER_APP_ACTION = 95,
    REGISTER_REGULAR_APP_ACTION = 96,
    REGISTER_SETTING_APP_ACTION = 97,
    REPLAY_RECORDED_SEQUENCE_ACTION = 98,
    REPORT_REPLAYING_DONE_ACTION = 99,
    RGB_RING_ACTION = 100,
    RGB_RING_BLANK_ACTION = 101,
    RGB_RING_BLINK_ACTION = 102,
    RGB_RING_COLORFUL_COMMAND_ACTION = 103,
    RGB_RING_COMMAND_ACTION = 104,
    RGB_RING_FILL_DOWNFROM_ACTION = 105,
    RGB_RING_FILL_UPTO_ACTION = 106,
    RGB_RING_PROGRESS_WHEEL_ACTION = 107,
    RGB_RING_PROGRESS_WHEEL_STEP_ACTION = 108,
    RGB_RING_PULSE_ACTION = 109,
    RGB_RING_RAINBOW_ACTION = 110,
    RGB_RING_SEQUENCE_ACTION = 111,
    RGB_RING_SET_ALL_ACTION = 112,
    RGB_RING_SET_BRIGHTNESS_ACTION = 113,
    RGB_RING_SET_ENABLED_ACTION = 114,
    RGB_RING_SET_IS_BUSY_ACTION = 115,
    RGB_RING_SPINNING_WHEEL_ACTION = 116,
    RGB_RING_WAITABLE_COMMAND_ACTION = 117,
    SSH_ACTION = 118,
    SSH_CLEAR_ENABLED_STATE_ACTION = 119,
    SSH_UPDATE_STATE_ACTION = 120,
    SENSORS_ACTION = 121,
    SENSORS_REPORT_READING_ACTION = 122,
    SET_ARE_ENCLOSURES_VISIBLE_ACTION = 123,
    SET_MENU_PATH_ACTION = 124,
    SETTINGS_ACTION = 125,
    SETTINGS_CLEAR_SERVICE_ERRORS_ACTION = 126,
    SETTINGS_REPORT_SERVICE_ERROR_ACTION = 127,
    SETTINGS_SERVICE_ACTION = 128,
    SETTINGS_SERVICE_SET_IS_ENABLED_ACTION = 129,
    SETTINGS_SERVICE_SET_LOG_LEVEL_ACTION = 130,
    SETTINGS_SERVICE_SET_SHOULD_RESTART_ACTION = 131,
    SETTINGS_SERVICE_SET_STATUS_ACTION = 132,
    SETTINGS_SET_SERVICES_ACTION = 133,
    SETTINGS_START_SERVICE_ACTION = 134,
    SETTINGS_STOP_SERVICE_ACTION = 135,
    SETTINGS_TOGGLE_BETA_VERSIONS_ACTION = 136,
    SETTINGS_TOGGLE_PDB_SIGNAL_ACTION = 137,
    SETTINGS_TOGGLE_VISUAL_DEBUG_ACTION = 138,
    SPEECH_RECOGNITION_ACTION = 139,
    SPEECH_RECOGNITION_REPORT_INTENT_DETECTION_ACTION = 140,
    SPEECH_RECOGNITION_REPORT_SPEECH_ACTION = 141,
    SPEECH_RECOGNITION_REPORT_WAKE_WORD_DETECTION_ACTION = 142,
    SPEECH_RECOGNITION_SET_IS_ASSISTANT_ACTIVE_ACTION = 143,
    SPEECH_RECOGNITION_SET_IS_INTENTS_ACTIVE_ACTION = 144,
    SPEECH_RECOGNITION_SET_SELECTED_ENGINE_ACTION = 145,
    SPEECH_SYNTHESIS_ACTION = 146,
    SPEECH_SYNTHESIS_READ_TEXT_ACTION = 147,
    SPEECH_SYNTHESIS_SET_SELECTED_ENGINE_ACTION = 148,
    STATUS_ICONS_ACTION = 149,
    STATUS_ICONS_REGISTER_ACTION = 150,
    TOGGLE_RECORDING_ACTION = 151,
    UPDATE_MANAGER_ACTION = 152,
    UPDATE_MANAGER_REPORT_FAILED_CHECK_ACTION = 153,
    UPDATE_MANAGER_REQUEST_CHECK_ACTION = 154,
    UPDATE_MANAGER_REQUEST_UPDATE_ACTION = 155,
    UPDATE_MANAGER_SET_VERSIONS_ACTION = 156,
    USERS_ACTION = 157,
    USERS_CREATE_USER_ACTION = 158,
    USERS_DELETE_USER_ACTION = 159,
    USERS_RESET_PASSWORD_ACTION = 160,
    USERS_SET_USERS_ACTION = 161,
    VS_CODE_ACTION = 162,
    VS_CODE_DONE_DOWNLOADING_ACTION = 163,
    VS_CODE_SET_PENDING_ACTION = 164,
    VS_CODE_SET_STATUS_ACTION = 165,
    VS_CODE_START_DOWNLOADING_ACTION = 166,
    WI_FI_ACTION = 167,
    WI_FI_INPUT_CONNECTION_ACTION = 168,
    WI_FI_SET_HAS_VISITED_ONBOARDING_ACTION = 169,
    WI_FI_UPDATE_ACTION = 170,
    WI_FI_UPDATE_REQUEST_ACTION = 171,
  }
}

export class Event extends jspb.Message {
  getAssistantDownloadOllamaModelEvent(): AssistantDownloadOllamaModelEvent | undefined;
  setAssistantDownloadOllamaModelEvent(value?: AssistantDownloadOllamaModelEvent): Event;
  hasAssistantDownloadOllamaModelEvent(): boolean;
  clearAssistantDownloadOllamaModelEvent(): Event;

  getAssistantEvent(): AssistantEvent | undefined;
  setAssistantEvent(value?: AssistantEvent): Event;
  hasAssistantEvent(): boolean;
  clearAssistantEvent(): Event;

  getAssistantReportEvent(): AssistantReportEvent | undefined;
  setAssistantReportEvent(value?: AssistantReportEvent): Event;
  hasAssistantReportEvent(): boolean;
  clearAssistantReportEvent(): Event;

  getAudioEvent(): AudioEvent | undefined;
  setAudioEvent(value?: AudioEvent): Event;
  hasAudioEvent(): boolean;
  clearAudioEvent(): Event;

  getAudioInstallDriverEvent(): AudioInstallDriverEvent | undefined;
  setAudioInstallDriverEvent(value?: AudioInstallDriverEvent): Event;
  hasAudioInstallDriverEvent(): boolean;
  clearAudioInstallDriverEvent(): Event;

  getAudioPlayAudioSampleEvent(): AudioPlayAudioSampleEvent | undefined;
  setAudioPlayAudioSampleEvent(value?: AudioPlayAudioSampleEvent): Event;
  hasAudioPlayAudioSampleEvent(): boolean;
  clearAudioPlayAudioSampleEvent(): Event;

  getAudioPlayAudioSequenceEvent(): AudioPlayAudioSequenceEvent | undefined;
  setAudioPlayAudioSequenceEvent(value?: AudioPlayAudioSequenceEvent): Event;
  hasAudioPlayAudioSequenceEvent(): boolean;
  clearAudioPlayAudioSequenceEvent(): Event;

  getAudioPlayChimeEvent(): AudioPlayChimeEvent | undefined;
  setAudioPlayChimeEvent(value?: AudioPlayChimeEvent): Event;
  hasAudioPlayChimeEvent(): boolean;
  clearAudioPlayChimeEvent(): Event;

  getAudioPlaybackDoneEvent(): AudioPlaybackDoneEvent | undefined;
  setAudioPlaybackDoneEvent(value?: AudioPlaybackDoneEvent): Event;
  hasAudioPlaybackDoneEvent(): boolean;
  clearAudioPlaybackDoneEvent(): Event;

  getAudioReportSampleEvent(): AudioReportSampleEvent | undefined;
  setAudioReportSampleEvent(value?: AudioReportSampleEvent): Event;
  hasAudioReportSampleEvent(): boolean;
  clearAudioReportSampleEvent(): Event;

  getCameraEvent(): CameraEvent | undefined;
  setCameraEvent(value?: CameraEvent): Event;
  hasCameraEvent(): boolean;
  clearCameraEvent(): Event;

  getCameraStartViewfinderEvent(): CameraStartViewfinderEvent | undefined;
  setCameraStartViewfinderEvent(value?: CameraStartViewfinderEvent): Event;
  hasCameraStartViewfinderEvent(): boolean;
  clearCameraStartViewfinderEvent(): Event;

  getCameraStopViewfinderEvent(): CameraStopViewfinderEvent | undefined;
  setCameraStopViewfinderEvent(value?: CameraStopViewfinderEvent): Event;
  hasCameraStopViewfinderEvent(): boolean;
  clearCameraStopViewfinderEvent(): Event;

  getCloseApplicationEvent(): CloseApplicationEvent | undefined;
  setCloseApplicationEvent(value?: CloseApplicationEvent): Event;
  hasCloseApplicationEvent(): boolean;
  clearCloseApplicationEvent(): Event;

  getDisplayCompressedRenderEvent(): DisplayCompressedRenderEvent | undefined;
  setDisplayCompressedRenderEvent(value?: DisplayCompressedRenderEvent): Event;
  hasDisplayCompressedRenderEvent(): boolean;
  clearDisplayCompressedRenderEvent(): Event;

  getDisplayEvent(): DisplayEvent | undefined;
  setDisplayEvent(value?: DisplayEvent): Event;
  hasDisplayEvent(): boolean;
  clearDisplayEvent(): Event;

  getDisplayRenderEvent(): DisplayRenderEvent | undefined;
  setDisplayRenderEvent(value?: DisplayRenderEvent): Event;
  hasDisplayRenderEvent(): boolean;
  clearDisplayRenderEvent(): Event;

  getDisplayRerenderEvent(): DisplayRerenderEvent | undefined;
  setDisplayRerenderEvent(value?: DisplayRerenderEvent): Event;
  hasDisplayRerenderEvent(): boolean;
  clearDisplayRerenderEvent(): Event;

  getDockerEvent(): DockerEvent | undefined;
  setDockerEvent(value?: DockerEvent): Event;
  hasDockerEvent(): boolean;
  clearDockerEvent(): Event;

  getDockerImageEvent(): DockerImageEvent | undefined;
  setDockerImageEvent(value?: DockerImageEvent): Event;
  hasDockerImageEvent(): boolean;
  clearDockerImageEvent(): Event;

  getDockerImageFetchCompositionEvent(): DockerImageFetchCompositionEvent | undefined;
  setDockerImageFetchCompositionEvent(value?: DockerImageFetchCompositionEvent): Event;
  hasDockerImageFetchCompositionEvent(): boolean;
  clearDockerImageFetchCompositionEvent(): Event;

  getDockerImageFetchEvent(): DockerImageFetchEvent | undefined;
  setDockerImageFetchEvent(value?: DockerImageFetchEvent): Event;
  hasDockerImageFetchEvent(): boolean;
  clearDockerImageFetchEvent(): Event;

  getDockerImageRegisterAppEvent(): DockerImageRegisterAppEvent | undefined;
  setDockerImageRegisterAppEvent(value?: DockerImageRegisterAppEvent): Event;
  hasDockerImageRegisterAppEvent(): boolean;
  clearDockerImageRegisterAppEvent(): Event;

  getDockerImageReleaseCompositionEvent(): DockerImageReleaseCompositionEvent | undefined;
  setDockerImageReleaseCompositionEvent(value?: DockerImageReleaseCompositionEvent): Event;
  hasDockerImageReleaseCompositionEvent(): boolean;
  clearDockerImageReleaseCompositionEvent(): Event;

  getDockerImageRemoveCompositionEvent(): DockerImageRemoveCompositionEvent | undefined;
  setDockerImageRemoveCompositionEvent(value?: DockerImageRemoveCompositionEvent): Event;
  hasDockerImageRemoveCompositionEvent(): boolean;
  clearDockerImageRemoveCompositionEvent(): Event;

  getDockerImageRemoveContainerEvent(): DockerImageRemoveContainerEvent | undefined;
  setDockerImageRemoveContainerEvent(value?: DockerImageRemoveContainerEvent): Event;
  hasDockerImageRemoveContainerEvent(): boolean;
  clearDockerImageRemoveContainerEvent(): Event;

  getDockerImageRemoveEvent(): DockerImageRemoveEvent | undefined;
  setDockerImageRemoveEvent(value?: DockerImageRemoveEvent): Event;
  hasDockerImageRemoveEvent(): boolean;
  clearDockerImageRemoveEvent(): Event;

  getDockerImageRunCompositionEvent(): DockerImageRunCompositionEvent | undefined;
  setDockerImageRunCompositionEvent(value?: DockerImageRunCompositionEvent): Event;
  hasDockerImageRunCompositionEvent(): boolean;
  clearDockerImageRunCompositionEvent(): Event;

  getDockerImageRunContainerEvent(): DockerImageRunContainerEvent | undefined;
  setDockerImageRunContainerEvent(value?: DockerImageRunContainerEvent): Event;
  hasDockerImageRunContainerEvent(): boolean;
  clearDockerImageRunContainerEvent(): Event;

  getDockerImageStopCompositionEvent(): DockerImageStopCompositionEvent | undefined;
  setDockerImageStopCompositionEvent(value?: DockerImageStopCompositionEvent): Event;
  hasDockerImageStopCompositionEvent(): boolean;
  clearDockerImageStopCompositionEvent(): Event;

  getDockerImageStopContainerEvent(): DockerImageStopContainerEvent | undefined;
  setDockerImageStopContainerEvent(value?: DockerImageStopContainerEvent): Event;
  hasDockerImageStopContainerEvent(): boolean;
  clearDockerImageStopContainerEvent(): Event;

  getDockerInstallEvent(): DockerInstallEvent | undefined;
  setDockerInstallEvent(value?: DockerInstallEvent): Event;
  hasDockerInstallEvent(): boolean;
  clearDockerInstallEvent(): Event;

  getDockerStartEvent(): DockerStartEvent | undefined;
  setDockerStartEvent(value?: DockerStartEvent): Event;
  hasDockerStartEvent(): boolean;
  clearDockerStartEvent(): Event;

  getDockerStopEvent(): DockerStopEvent | undefined;
  setDockerStopEvent(value?: DockerStopEvent): Event;
  hasDockerStopEvent(): boolean;
  clearDockerStopEvent(): Event;

  getFileSystemCopyEvent(): FileSystemCopyEvent | undefined;
  setFileSystemCopyEvent(value?: FileSystemCopyEvent): Event;
  hasFileSystemCopyEvent(): boolean;
  clearFileSystemCopyEvent(): Event;

  getFileSystemEvent(): FileSystemEvent | undefined;
  setFileSystemEvent(value?: FileSystemEvent): Event;
  hasFileSystemEvent(): boolean;
  clearFileSystemEvent(): Event;

  getFileSystemMoveEvent(): FileSystemMoveEvent | undefined;
  setFileSystemMoveEvent(value?: FileSystemMoveEvent): Event;
  hasFileSystemMoveEvent(): boolean;
  clearFileSystemMoveEvent(): Event;

  getFileSystemRemoveEvent(): FileSystemRemoveEvent | undefined;
  setFileSystemRemoveEvent(value?: FileSystemRemoveEvent): Event;
  hasFileSystemRemoveEvent(): boolean;
  clearFileSystemRemoveEvent(): Event;

  getFileSystemSelectEvent(): FileSystemSelectEvent | undefined;
  setFileSystemSelectEvent(value?: FileSystemSelectEvent): Event;
  hasFileSystemSelectEvent(): boolean;
  clearFileSystemSelectEvent(): Event;

  getInfraredEvent(): InfraredEvent | undefined;
  setInfraredEvent(value?: InfraredEvent): Event;
  hasInfraredEvent(): boolean;
  clearInfraredEvent(): Event;

  getInfraredSendCodeEvent(): InfraredSendCodeEvent | undefined;
  setInfraredSendCodeEvent(value?: InfraredSendCodeEvent): Event;
  hasInfraredSendCodeEvent(): boolean;
  clearInfraredSendCodeEvent(): Event;

  getInitEvent(): InitEvent | undefined;
  setInitEvent(value?: InitEvent): Event;
  hasInitEvent(): boolean;
  clearInitEvent(): Event;

  getInputCancelEvent(): InputCancelEvent | undefined;
  setInputCancelEvent(value?: InputCancelEvent): Event;
  hasInputCancelEvent(): boolean;
  clearInputCancelEvent(): Event;

  getInputProvideEvent(): InputProvideEvent | undefined;
  setInputProvideEvent(value?: InputProvideEvent): Event;
  hasInputProvideEvent(): boolean;
  clearInputProvideEvent(): Event;

  getInputResolveEvent(): InputResolveEvent | undefined;
  setInputResolveEvent(value?: InputResolveEvent): Event;
  hasInputResolveEvent(): boolean;
  clearInputResolveEvent(): Event;

  getIpEvent(): IpEvent | undefined;
  setIpEvent(value?: IpEvent): Event;
  hasIpEvent(): boolean;
  clearIpEvent(): Event;

  getMainEvent(): MainEvent | undefined;
  setMainEvent(value?: MainEvent): Event;
  hasMainEvent(): boolean;
  clearMainEvent(): Event;

  getMenuChooseByIconEvent(): MenuChooseByIconEvent | undefined;
  setMenuChooseByIconEvent(value?: MenuChooseByIconEvent): Event;
  hasMenuChooseByIconEvent(): boolean;
  clearMenuChooseByIconEvent(): Event;

  getMenuChooseByIndexEvent(): MenuChooseByIndexEvent | undefined;
  setMenuChooseByIndexEvent(value?: MenuChooseByIndexEvent): Event;
  hasMenuChooseByIndexEvent(): boolean;
  clearMenuChooseByIndexEvent(): Event;

  getMenuChooseByLabelEvent(): MenuChooseByLabelEvent | undefined;
  setMenuChooseByLabelEvent(value?: MenuChooseByLabelEvent): Event;
  hasMenuChooseByLabelEvent(): boolean;
  clearMenuChooseByLabelEvent(): Event;

  getMenuEvent(): MenuEvent | undefined;
  setMenuEvent(value?: MenuEvent): Event;
  hasMenuEvent(): boolean;
  clearMenuEvent(): Event;

  getMenuGoBackEvent(): MenuGoBackEvent | undefined;
  setMenuGoBackEvent(value?: MenuGoBackEvent): Event;
  hasMenuGoBackEvent(): boolean;
  clearMenuGoBackEvent(): Event;

  getMenuGoHomeEvent(): MenuGoHomeEvent | undefined;
  setMenuGoHomeEvent(value?: MenuGoHomeEvent): Event;
  hasMenuGoHomeEvent(): boolean;
  clearMenuGoHomeEvent(): Event;

  getMenuScrollEvent(): MenuScrollEvent | undefined;
  setMenuScrollEvent(value?: MenuScrollEvent): Event;
  hasMenuScrollEvent(): boolean;
  clearMenuScrollEvent(): Event;

  getNotificationsClearEvent(): NotificationsClearEvent | undefined;
  setNotificationsClearEvent(value?: NotificationsClearEvent): Event;
  hasNotificationsClearEvent(): boolean;
  clearNotificationsClearEvent(): Event;

  getNotificationsDisplayEvent(): NotificationsDisplayEvent | undefined;
  setNotificationsDisplayEvent(value?: NotificationsDisplayEvent): Event;
  hasNotificationsDisplayEvent(): boolean;
  clearNotificationsDisplayEvent(): Event;

  getNotificationsEvent(): NotificationsEvent | undefined;
  setNotificationsEvent(value?: NotificationsEvent): Event;
  hasNotificationsEvent(): boolean;
  clearNotificationsEvent(): Event;

  getOpenApplicationEvent(): OpenApplicationEvent | undefined;
  setOpenApplicationEvent(value?: OpenApplicationEvent): Event;
  hasOpenApplicationEvent(): boolean;
  clearOpenApplicationEvent(): Event;

  getPowerEvent(): PowerEvent | undefined;
  setPowerEvent(value?: PowerEvent): Event;
  hasPowerEvent(): boolean;
  clearPowerEvent(): Event;

  getPowerOffEvent(): PowerOffEvent | undefined;
  setPowerOffEvent(value?: PowerOffEvent): Event;
  hasPowerOffEvent(): boolean;
  clearPowerOffEvent(): Event;

  getRPiConnectEvent(): RPiConnectEvent | undefined;
  setRPiConnectEvent(value?: RPiConnectEvent): Event;
  hasRPiConnectEvent(): boolean;
  clearRPiConnectEvent(): Event;

  getRPiConnectLoginEvent(): RPiConnectLoginEvent | undefined;
  setRPiConnectLoginEvent(value?: RPiConnectLoginEvent): Event;
  hasRPiConnectLoginEvent(): boolean;
  clearRPiConnectLoginEvent(): Event;

  getRebootEvent(): RebootEvent | undefined;
  setRebootEvent(value?: RebootEvent): Event;
  hasRebootEvent(): boolean;
  clearRebootEvent(): Event;

  getReplayRecordedSequenceEvent(): ReplayRecordedSequenceEvent | undefined;
  setReplayRecordedSequenceEvent(value?: ReplayRecordedSequenceEvent): Event;
  hasReplayRecordedSequenceEvent(): boolean;
  clearReplayRecordedSequenceEvent(): Event;

  getRgbRingCommandEvent(): RgbRingCommandEvent | undefined;
  setRgbRingCommandEvent(value?: RgbRingCommandEvent): Event;
  hasRgbRingCommandEvent(): boolean;
  clearRgbRingCommandEvent(): Event;

  getRgbRingEvent(): RgbRingEvent | undefined;
  setRgbRingEvent(value?: RgbRingEvent): Event;
  hasRgbRingEvent(): boolean;
  clearRgbRingEvent(): Event;

  getScreenshotEvent(): ScreenshotEvent | undefined;
  setScreenshotEvent(value?: ScreenshotEvent): Event;
  hasScreenshotEvent(): boolean;
  clearScreenshotEvent(): Event;

  getSettingsEvent(): SettingsEvent | undefined;
  setSettingsEvent(value?: SettingsEvent): Event;
  hasSettingsEvent(): boolean;
  clearSettingsEvent(): Event;

  getSettingsServiceEvent(): SettingsServiceEvent | undefined;
  setSettingsServiceEvent(value?: SettingsServiceEvent): Event;
  hasSettingsServiceEvent(): boolean;
  clearSettingsServiceEvent(): Event;

  getSettingsStartServiceEvent(): SettingsStartServiceEvent | undefined;
  setSettingsStartServiceEvent(value?: SettingsStartServiceEvent): Event;
  hasSettingsStartServiceEvent(): boolean;
  clearSettingsStartServiceEvent(): Event;

  getSettingsStopServiceEvent(): SettingsStopServiceEvent | undefined;
  setSettingsStopServiceEvent(value?: SettingsStopServiceEvent): Event;
  hasSettingsStopServiceEvent(): boolean;
  clearSettingsStopServiceEvent(): Event;

  getSnapshotEvent(): SnapshotEvent | undefined;
  setSnapshotEvent(value?: SnapshotEvent): Event;
  hasSnapshotEvent(): boolean;
  clearSnapshotEvent(): Event;

  getSpeechRecognitionEvent(): SpeechRecognitionEvent | undefined;
  setSpeechRecognitionEvent(value?: SpeechRecognitionEvent): Event;
  hasSpeechRecognitionEvent(): boolean;
  clearSpeechRecognitionEvent(): Event;

  getSpeechRecognitionReportTextEvent(): SpeechRecognitionReportTextEvent | undefined;
  setSpeechRecognitionReportTextEvent(value?: SpeechRecognitionReportTextEvent): Event;
  hasSpeechRecognitionReportTextEvent(): boolean;
  clearSpeechRecognitionReportTextEvent(): Event;

  getSpeechSynthesisEvent(): SpeechSynthesisEvent | undefined;
  setSpeechSynthesisEvent(value?: SpeechSynthesisEvent): Event;
  hasSpeechSynthesisEvent(): boolean;
  clearSpeechSynthesisEvent(): Event;

  getSpeechSynthesisSynthesizeTextEvent(): SpeechSynthesisSynthesizeTextEvent | undefined;
  setSpeechSynthesisSynthesizeTextEvent(value?: SpeechSynthesisSynthesizeTextEvent): Event;
  hasSpeechSynthesisSynthesizeTextEvent(): boolean;
  clearSpeechSynthesisSynthesizeTextEvent(): Event;

  getStoreRecordedSequenceEvent(): StoreRecordedSequenceEvent | undefined;
  setStoreRecordedSequenceEvent(value?: StoreRecordedSequenceEvent): Event;
  hasStoreRecordedSequenceEvent(): boolean;
  clearStoreRecordedSequenceEvent(): Event;

  getUpdateManagerCheckEvent(): UpdateManagerCheckEvent | undefined;
  setUpdateManagerCheckEvent(value?: UpdateManagerCheckEvent): Event;
  hasUpdateManagerCheckEvent(): boolean;
  clearUpdateManagerCheckEvent(): Event;

  getUpdateManagerEvent(): UpdateManagerEvent | undefined;
  setUpdateManagerEvent(value?: UpdateManagerEvent): Event;
  hasUpdateManagerEvent(): boolean;
  clearUpdateManagerEvent(): Event;

  getUpdateManagerUpdateEvent(): UpdateManagerUpdateEvent | undefined;
  setUpdateManagerUpdateEvent(value?: UpdateManagerUpdateEvent): Event;
  hasUpdateManagerUpdateEvent(): boolean;
  clearUpdateManagerUpdateEvent(): Event;

  getUsersCreateUserEvent(): UsersCreateUserEvent | undefined;
  setUsersCreateUserEvent(value?: UsersCreateUserEvent): Event;
  hasUsersCreateUserEvent(): boolean;
  clearUsersCreateUserEvent(): Event;

  getUsersDeleteUserEvent(): UsersDeleteUserEvent | undefined;
  setUsersDeleteUserEvent(value?: UsersDeleteUserEvent): Event;
  hasUsersDeleteUserEvent(): boolean;
  clearUsersDeleteUserEvent(): Event;

  getUsersEvent(): UsersEvent | undefined;
  setUsersEvent(value?: UsersEvent): Event;
  hasUsersEvent(): boolean;
  clearUsersEvent(): Event;

  getUsersResetPasswordEvent(): UsersResetPasswordEvent | undefined;
  setUsersResetPasswordEvent(value?: UsersResetPasswordEvent): Event;
  hasUsersResetPasswordEvent(): boolean;
  clearUsersResetPasswordEvent(): Event;

  getVsCodeEvent(): VSCodeEvent | undefined;
  setVsCodeEvent(value?: VSCodeEvent): Event;
  hasVsCodeEvent(): boolean;
  clearVsCodeEvent(): Event;

  getVsCodeLoginEvent(): VSCodeLoginEvent | undefined;
  setVsCodeLoginEvent(value?: VSCodeLoginEvent): Event;
  hasVsCodeLoginEvent(): boolean;
  clearVsCodeLoginEvent(): Event;

  getVsCodeRestartEvent(): VSCodeRestartEvent | undefined;
  setVsCodeRestartEvent(value?: VSCodeRestartEvent): Event;
  hasVsCodeRestartEvent(): boolean;
  clearVsCodeRestartEvent(): Event;

  getWebUiEvent(): WebUIEvent | undefined;
  setWebUiEvent(value?: WebUIEvent): Event;
  hasWebUiEvent(): boolean;
  clearWebUiEvent(): Event;

  getWebUiInitializeEvent(): WebUIInitializeEvent | undefined;
  setWebUiInitializeEvent(value?: WebUIInitializeEvent): Event;
  hasWebUiInitializeEvent(): boolean;
  clearWebUiInitializeEvent(): Event;

  getWebUiStopEvent(): WebUIStopEvent | undefined;
  setWebUiStopEvent(value?: WebUIStopEvent): Event;
  hasWebUiStopEvent(): boolean;
  clearWebUiStopEvent(): Event;

  getWiFiEvent(): WiFiEvent | undefined;
  setWiFiEvent(value?: WiFiEvent): Event;
  hasWiFiEvent(): boolean;
  clearWiFiEvent(): Event;

  getWiFiInputConnectionEvent(): WiFiInputConnectionEvent | undefined;
  setWiFiInputConnectionEvent(value?: WiFiInputConnectionEvent): Event;
  hasWiFiInputConnectionEvent(): boolean;
  clearWiFiInputConnectionEvent(): Event;

  getWiFiUpdateRequestEvent(): WiFiUpdateRequestEvent | undefined;
  setWiFiUpdateRequestEvent(value?: WiFiUpdateRequestEvent): Event;
  hasWiFiUpdateRequestEvent(): boolean;
  clearWiFiUpdateRequestEvent(): Event;

  getEventCase(): Event.EventCase;

  serializeBinary(): Uint8Array;
  toObject(includeInstance?: boolean): Event.AsObject;
  static toObject(includeInstance: boolean, msg: Event): Event.AsObject;
  static serializeBinaryToWriter(message: Event, writer: jspb.BinaryWriter): void;
  static deserializeBinary(bytes: Uint8Array): Event;
  static deserializeBinaryFromReader(message: Event, reader: jspb.BinaryReader): Event;
}

export namespace Event {
  export type AsObject = {
    assistantDownloadOllamaModelEvent?: AssistantDownloadOllamaModelEvent.AsObject,
    assistantEvent?: AssistantEvent.AsObject,
    assistantReportEvent?: AssistantReportEvent.AsObject,
    audioEvent?: AudioEvent.AsObject,
    audioInstallDriverEvent?: AudioInstallDriverEvent.AsObject,
    audioPlayAudioSampleEvent?: AudioPlayAudioSampleEvent.AsObject,
    audioPlayAudioSequenceEvent?: AudioPlayAudioSequenceEvent.AsObject,
    audioPlayChimeEvent?: AudioPlayChimeEvent.AsObject,
    audioPlaybackDoneEvent?: AudioPlaybackDoneEvent.AsObject,
    audioReportSampleEvent?: AudioReportSampleEvent.AsObject,
    cameraEvent?: CameraEvent.AsObject,
    cameraStartViewfinderEvent?: CameraStartViewfinderEvent.AsObject,
    cameraStopViewfinderEvent?: CameraStopViewfinderEvent.AsObject,
    closeApplicationEvent?: CloseApplicationEvent.AsObject,
    displayCompressedRenderEvent?: DisplayCompressedRenderEvent.AsObject,
    displayEvent?: DisplayEvent.AsObject,
    displayRenderEvent?: DisplayRenderEvent.AsObject,
    displayRerenderEvent?: DisplayRerenderEvent.AsObject,
    dockerEvent?: DockerEvent.AsObject,
    dockerImageEvent?: DockerImageEvent.AsObject,
    dockerImageFetchCompositionEvent?: DockerImageFetchCompositionEvent.AsObject,
    dockerImageFetchEvent?: DockerImageFetchEvent.AsObject,
    dockerImageRegisterAppEvent?: DockerImageRegisterAppEvent.AsObject,
    dockerImageReleaseCompositionEvent?: DockerImageReleaseCompositionEvent.AsObject,
    dockerImageRemoveCompositionEvent?: DockerImageRemoveCompositionEvent.AsObject,
    dockerImageRemoveContainerEvent?: DockerImageRemoveContainerEvent.AsObject,
    dockerImageRemoveEvent?: DockerImageRemoveEvent.AsObject,
    dockerImageRunCompositionEvent?: DockerImageRunCompositionEvent.AsObject,
    dockerImageRunContainerEvent?: DockerImageRunContainerEvent.AsObject,
    dockerImageStopCompositionEvent?: DockerImageStopCompositionEvent.AsObject,
    dockerImageStopContainerEvent?: DockerImageStopContainerEvent.AsObject,
    dockerInstallEvent?: DockerInstallEvent.AsObject,
    dockerStartEvent?: DockerStartEvent.AsObject,
    dockerStopEvent?: DockerStopEvent.AsObject,
    fileSystemCopyEvent?: FileSystemCopyEvent.AsObject,
    fileSystemEvent?: FileSystemEvent.AsObject,
    fileSystemMoveEvent?: FileSystemMoveEvent.AsObject,
    fileSystemRemoveEvent?: FileSystemRemoveEvent.AsObject,
    fileSystemSelectEvent?: FileSystemSelectEvent.AsObject,
    infraredEvent?: InfraredEvent.AsObject,
    infraredSendCodeEvent?: InfraredSendCodeEvent.AsObject,
    initEvent?: InitEvent.AsObject,
    inputCancelEvent?: InputCancelEvent.AsObject,
    inputProvideEvent?: InputProvideEvent.AsObject,
    inputResolveEvent?: InputResolveEvent.AsObject,
    ipEvent?: IpEvent.AsObject,
    mainEvent?: MainEvent.AsObject,
    menuChooseByIconEvent?: MenuChooseByIconEvent.AsObject,
    menuChooseByIndexEvent?: MenuChooseByIndexEvent.AsObject,
    menuChooseByLabelEvent?: MenuChooseByLabelEvent.AsObject,
    menuEvent?: MenuEvent.AsObject,
    menuGoBackEvent?: MenuGoBackEvent.AsObject,
    menuGoHomeEvent?: MenuGoHomeEvent.AsObject,
    menuScrollEvent?: MenuScrollEvent.AsObject,
    notificationsClearEvent?: NotificationsClearEvent.AsObject,
    notificationsDisplayEvent?: NotificationsDisplayEvent.AsObject,
    notificationsEvent?: NotificationsEvent.AsObject,
    openApplicationEvent?: OpenApplicationEvent.AsObject,
    powerEvent?: PowerEvent.AsObject,
    powerOffEvent?: PowerOffEvent.AsObject,
    rPiConnectEvent?: RPiConnectEvent.AsObject,
    rPiConnectLoginEvent?: RPiConnectLoginEvent.AsObject,
    rebootEvent?: RebootEvent.AsObject,
    replayRecordedSequenceEvent?: ReplayRecordedSequenceEvent.AsObject,
    rgbRingCommandEvent?: RgbRingCommandEvent.AsObject,
    rgbRingEvent?: RgbRingEvent.AsObject,
    screenshotEvent?: ScreenshotEvent.AsObject,
    settingsEvent?: SettingsEvent.AsObject,
    settingsServiceEvent?: SettingsServiceEvent.AsObject,
    settingsStartServiceEvent?: SettingsStartServiceEvent.AsObject,
    settingsStopServiceEvent?: SettingsStopServiceEvent.AsObject,
    snapshotEvent?: SnapshotEvent.AsObject,
    speechRecognitionEvent?: SpeechRecognitionEvent.AsObject,
    speechRecognitionReportTextEvent?: SpeechRecognitionReportTextEvent.AsObject,
    speechSynthesisEvent?: SpeechSynthesisEvent.AsObject,
    speechSynthesisSynthesizeTextEvent?: SpeechSynthesisSynthesizeTextEvent.AsObject,
    storeRecordedSequenceEvent?: StoreRecordedSequenceEvent.AsObject,
    updateManagerCheckEvent?: UpdateManagerCheckEvent.AsObject,
    updateManagerEvent?: UpdateManagerEvent.AsObject,
    updateManagerUpdateEvent?: UpdateManagerUpdateEvent.AsObject,
    usersCreateUserEvent?: UsersCreateUserEvent.AsObject,
    usersDeleteUserEvent?: UsersDeleteUserEvent.AsObject,
    usersEvent?: UsersEvent.AsObject,
    usersResetPasswordEvent?: UsersResetPasswordEvent.AsObject,
    vsCodeEvent?: VSCodeEvent.AsObject,
    vsCodeLoginEvent?: VSCodeLoginEvent.AsObject,
    vsCodeRestartEvent?: VSCodeRestartEvent.AsObject,
    webUiEvent?: WebUIEvent.AsObject,
    webUiInitializeEvent?: WebUIInitializeEvent.AsObject,
    webUiStopEvent?: WebUIStopEvent.AsObject,
    wiFiEvent?: WiFiEvent.AsObject,
    wiFiInputConnectionEvent?: WiFiInputConnectionEvent.AsObject,
    wiFiUpdateRequestEvent?: WiFiUpdateRequestEvent.AsObject,
  }

  export enum EventCase { 
    EVENT_NOT_SET = 0,
    ASSISTANT_DOWNLOAD_OLLAMA_MODEL_EVENT = 1,
    ASSISTANT_EVENT = 2,
    ASSISTANT_REPORT_EVENT = 3,
    AUDIO_EVENT = 4,
    AUDIO_INSTALL_DRIVER_EVENT = 5,
    AUDIO_PLAY_AUDIO_SAMPLE_EVENT = 6,
    AUDIO_PLAY_AUDIO_SEQUENCE_EVENT = 7,
    AUDIO_PLAY_CHIME_EVENT = 8,
    AUDIO_PLAYBACK_DONE_EVENT = 9,
    AUDIO_REPORT_SAMPLE_EVENT = 10,
    CAMERA_EVENT = 11,
    CAMERA_START_VIEWFINDER_EVENT = 12,
    CAMERA_STOP_VIEWFINDER_EVENT = 13,
    CLOSE_APPLICATION_EVENT = 14,
    DISPLAY_COMPRESSED_RENDER_EVENT = 15,
    DISPLAY_EVENT = 16,
    DISPLAY_RENDER_EVENT = 17,
    DISPLAY_RERENDER_EVENT = 18,
    DOCKER_EVENT = 19,
    DOCKER_IMAGE_EVENT = 20,
    DOCKER_IMAGE_FETCH_COMPOSITION_EVENT = 21,
    DOCKER_IMAGE_FETCH_EVENT = 22,
    DOCKER_IMAGE_REGISTER_APP_EVENT = 23,
    DOCKER_IMAGE_RELEASE_COMPOSITION_EVENT = 24,
    DOCKER_IMAGE_REMOVE_COMPOSITION_EVENT = 25,
    DOCKER_IMAGE_REMOVE_CONTAINER_EVENT = 26,
    DOCKER_IMAGE_REMOVE_EVENT = 27,
    DOCKER_IMAGE_RUN_COMPOSITION_EVENT = 28,
    DOCKER_IMAGE_RUN_CONTAINER_EVENT = 29,
    DOCKER_IMAGE_STOP_COMPOSITION_EVENT = 30,
    DOCKER_IMAGE_STOP_CONTAINER_EVENT = 31,
    DOCKER_INSTALL_EVENT = 32,
    DOCKER_START_EVENT = 33,
    DOCKER_STOP_EVENT = 34,
    FILE_SYSTEM_COPY_EVENT = 35,
    FILE_SYSTEM_EVENT = 36,
    FILE_SYSTEM_MOVE_EVENT = 37,
    FILE_SYSTEM_REMOVE_EVENT = 38,
    FILE_SYSTEM_SELECT_EVENT = 39,
    INFRARED_EVENT = 40,
    INFRARED_SEND_CODE_EVENT = 41,
    INIT_EVENT = 42,
    INPUT_CANCEL_EVENT = 43,
    INPUT_PROVIDE_EVENT = 44,
    INPUT_RESOLVE_EVENT = 45,
    IP_EVENT = 46,
    MAIN_EVENT = 47,
    MENU_CHOOSE_BY_ICON_EVENT = 48,
    MENU_CHOOSE_BY_INDEX_EVENT = 49,
    MENU_CHOOSE_BY_LABEL_EVENT = 50,
    MENU_EVENT = 51,
    MENU_GO_BACK_EVENT = 52,
    MENU_GO_HOME_EVENT = 53,
    MENU_SCROLL_EVENT = 54,
    NOTIFICATIONS_CLEAR_EVENT = 55,
    NOTIFICATIONS_DISPLAY_EVENT = 56,
    NOTIFICATIONS_EVENT = 57,
    OPEN_APPLICATION_EVENT = 58,
    POWER_EVENT = 59,
    POWER_OFF_EVENT = 60,
    R_PI_CONNECT_EVENT = 61,
    R_PI_CONNECT_LOGIN_EVENT = 62,
    REBOOT_EVENT = 63,
    REPLAY_RECORDED_SEQUENCE_EVENT = 64,
    RGB_RING_COMMAND_EVENT = 65,
    RGB_RING_EVENT = 66,
    SCREENSHOT_EVENT = 67,
    SETTINGS_EVENT = 68,
    SETTINGS_SERVICE_EVENT = 69,
    SETTINGS_START_SERVICE_EVENT = 70,
    SETTINGS_STOP_SERVICE_EVENT = 71,
    SNAPSHOT_EVENT = 72,
    SPEECH_RECOGNITION_EVENT = 73,
    SPEECH_RECOGNITION_REPORT_TEXT_EVENT = 74,
    SPEECH_SYNTHESIS_EVENT = 75,
    SPEECH_SYNTHESIS_SYNTHESIZE_TEXT_EVENT = 76,
    STORE_RECORDED_SEQUENCE_EVENT = 77,
    UPDATE_MANAGER_CHECK_EVENT = 78,
    UPDATE_MANAGER_EVENT = 79,
    UPDATE_MANAGER_UPDATE_EVENT = 80,
    USERS_CREATE_USER_EVENT = 81,
    USERS_DELETE_USER_EVENT = 82,
    USERS_EVENT = 83,
    USERS_RESET_PASSWORD_EVENT = 84,
    VS_CODE_EVENT = 85,
    VS_CODE_LOGIN_EVENT = 86,
    VS_CODE_RESTART_EVENT = 87,
    WEB_UI_EVENT = 88,
    WEB_UI_INITIALIZE_EVENT = 89,
    WEB_UI_STOP_EVENT = 90,
    WI_FI_EVENT = 91,
    WI_FI_INPUT_CONNECTION_EVENT = 92,
    WI_FI_UPDATE_REQUEST_EVENT = 93,
  }
}

export enum SettingsCategory { 
  SETTINGS_CATEGORY_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES_UNSPECIFIED = 0,
  SETTINGS_CATEGORY_NETWORK = 1,
  SETTINGS_CATEGORY_REMOTE = 2,
  SETTINGS_CATEGORY_SYSTEM = 3,
  SETTINGS_CATEGORY_HARDWARE = 4,
  SETTINGS_CATEGORY_SPEECH = 5,
  SETTINGS_CATEGORY_DOCKER = 6,
}
export enum MenuScrollDirection { 
  MENU_SCROLL_DIRECTION_UBO_APP_DOT_STORE_DOT_CORE_DOT_TYPES_UNSPECIFIED = 0,
  MENU_SCROLL_DIRECTION_UP = 1,
  MENU_SCROLL_DIRECTION_DOWN = 2,
}
export enum InputMethod { 
  INPUT_METHOD_UBO_APP_DOT_STORE_DOT_INPUT_DOT_TYPES_UNSPECIFIED = 0,
  INPUT_METHOD_CAMERA = 1,
  INPUT_METHOD_WEB_DASHBOARD = 2,
  INPUT_METHOD_PATH_SELECTOR = 3,
}
export enum InputFieldType { 
  INPUT_FIELD_TYPE_UBO_APP_DOT_STORE_DOT_INPUT_DOT_TYPES_UNSPECIFIED = 0,
  INPUT_FIELD_TYPE_LONG = 1,
  INPUT_FIELD_TYPE_TEXT = 2,
  INPUT_FIELD_TYPE_PASSWORD = 3,
  INPUT_FIELD_TYPE_NUMBER = 4,
  INPUT_FIELD_TYPE_CHECKBOX = 5,
  INPUT_FIELD_TYPE_COLOR = 6,
  INPUT_FIELD_TYPE_SELECT = 7,
  INPUT_FIELD_TYPE_FILE = 8,
  INPUT_FIELD_TYPE_DATE = 9,
  INPUT_FIELD_TYPE_TIME = 10,
}
export enum ServicesStatus { 
  SERVICES_STATUS_UBO_APP_DOT_STORE_DOT_SETTINGS_DOT_TYPES_UNSPECIFIED = 0,
  SERVICES_STATUS_LOADING = 1,
  SERVICES_STATUS_READY = 2,
}
export enum UpdateStatus { 
  UPDATE_STATUS_UBO_APP_DOT_STORE_DOT_UPDATE_MANAGER_DOT_TYPES_UNSPECIFIED = 0,
  UPDATE_STATUS_CHECKING = 1,
  UPDATE_STATUS_FAILED_TO_CHECK = 2,
  UPDATE_STATUS_UP_TO_DATE = 3,
  UPDATE_STATUS_OUTDATED = 4,
  UPDATE_STATUS_UPDATING = 5,
}
export enum AssistantLLMName { 
  ASSISTANT_LLM_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_ASSISTANT_UNSPECIFIED = 0,
  ASSISTANT_LLM_NAME_OLLAMA = 1,
  ASSISTANT_LLM_NAME_GOOGLE = 2,
  ASSISTANT_LLM_NAME_OPENAI = 3,
  ASSISTANT_LLM_NAME_ANTHROPIC = 4,
}
export enum AudioDevice { 
  AUDIO_DEVICE_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_AUDIO_UNSPECIFIED = 0,
  AUDIO_DEVICE_INPUT = 1,
  AUDIO_DEVICE_OUTPUT = 2,
}
export enum DockerStatus { 
  DOCKER_STATUS_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER_UNSPECIFIED = 0,
  DOCKER_STATUS_UNKNOWN = 1,
  DOCKER_STATUS_NOT_INSTALLED = 2,
  DOCKER_STATUS_INSTALLING = 3,
  DOCKER_STATUS_NOT_RUNNING = 4,
  DOCKER_STATUS_RUNNING = 5,
  DOCKER_STATUS_ERROR = 6,
}
export enum DockerItemStatus { 
  DOCKER_ITEM_STATUS_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_DOCKER_UNSPECIFIED = 0,
  DOCKER_ITEM_STATUS_NOT_AVAILABLE = 1,
  DOCKER_ITEM_STATUS_FETCHING = 2,
  DOCKER_ITEM_STATUS_AVAILABLE = 3,
  DOCKER_ITEM_STATUS_CREATED = 4,
  DOCKER_ITEM_STATUS_RUNNING = 5,
  DOCKER_ITEM_STATUS_ERROR = 6,
  DOCKER_ITEM_STATUS_PROCESSING = 7,
}
export enum NetState { 
  NET_STATE_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_ETHERNET_UNSPECIFIED = 0,
  NET_STATE_CONNECTED = 1,
  NET_STATE_DISCONNECTED = 2,
  NET_STATE_PENDING = 3,
  NET_STATE_NEEDS_ATTENTION = 4,
  NET_STATE_UNKNOWN = 5,
}
export enum Key { 
  KEY_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_KEYPAD_UNSPECIFIED = 0,
  KEY_BACK = 1,
  KEY_HOME = 2,
  KEY_UP = 3,
  KEY_DOWN = 4,
  KEY_L1 = 5,
  KEY_L2 = 6,
  KEY_L3 = 7,
}
export enum Importance { 
  IMPORTANCE_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_NOTIFICATIONS_UNSPECIFIED = 0,
  IMPORTANCE_CRITICAL = 1,
  IMPORTANCE_HIGH = 2,
  IMPORTANCE_MEDIUM = 3,
  IMPORTANCE_LOW = 4,
}
export enum NotificationDisplayType { 
  NOTIFICATION_DISPLAY_TYPE_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_NOTIFICATIONS_UNSPECIFIED = 0,
  NOTIFICATION_DISPLAY_TYPE_NOT_SET = 1,
  NOTIFICATION_DISPLAY_TYPE_BACKGROUND = 2,
  NOTIFICATION_DISPLAY_TYPE_FLASH = 3,
  NOTIFICATION_DISPLAY_TYPE_STICKY = 4,
}
export enum Chime { 
  CHIME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_NOTIFICATIONS_UNSPECIFIED = 0,
  CHIME_ADD = 1,
  CHIME_DONE = 2,
  CHIME_FAILURE = 3,
  CHIME_VOLUME_CHANGE = 4,
}
export enum Sensor { 
  SENSOR_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_SENSORS_UNSPECIFIED = 0,
  SENSOR_TEMPERATURE = 1,
  SENSOR_LIGHT = 2,
}
export enum SpeechRecognitionStatus { 
  SPEECH_RECOGNITION_STATUS_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_SPEECH_RECOGNITION_UNSPECIFIED = 0,
  SPEECH_RECOGNITION_STATUS_IDLE = 1,
  SPEECH_RECOGNITION_STATUS_INTENTS_WAITING = 2,
  SPEECH_RECOGNITION_STATUS_ASSISTANT_WAITING = 3,
}
export enum SpeechRecognitionEngineName { 
  SPEECH_RECOGNITION_ENGINE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_SPEECH_RECOGNITION_UNSPECIFIED = 0,
  SPEECH_RECOGNITION_ENGINE_NAME_VOSK = 1,
  SPEECH_RECOGNITION_ENGINE_NAME_GOOGLE = 2,
}
export enum SpeechSynthesisEngineName { 
  SPEECH_SYNTHESIS_ENGINE_NAME_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_SPEECH_SYNTHESIS_UNSPECIFIED = 0,
  SPEECH_SYNTHESIS_ENGINE_NAME_PIPER = 1,
  SPEECH_SYNTHESIS_ENGINE_NAME_PICOVOICE = 2,
}
export enum WiFiType { 
  WI_FI_TYPE_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_WIFI_UNSPECIFIED = 0,
  WI_FI_TYPE_WEP = 1,
  WI_FI_TYPE_WPA = 2,
  WI_FI_TYPE_WPA2 = 3,
  WI_FI_TYPE_NOPASS = 4,
}
export enum ConnectionState { 
  CONNECTION_STATE_UBO_APP_DOT_STORE_DOT_SERVICES_DOT_WIFI_UNSPECIFIED = 0,
  CONNECTION_STATE_CONNECTED = 1,
  CONNECTION_STATE_CONNECTING = 2,
  CONNECTION_STATE_DISCONNECTED = 3,
  CONNECTION_STATE_UNKNOWN = 4,
}
