"""Sets up the display for the Raspberry Pi and manages its state."""

from __future__ import annotations

splash_screen = None


def init_service() -> None:
    """Initialize the display service."""
