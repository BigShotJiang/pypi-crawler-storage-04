class InvalidConfigurationException(Exception):
    pass
