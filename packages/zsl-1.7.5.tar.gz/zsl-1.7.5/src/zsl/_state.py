from typing import Any

_current_app = None


def get_current_app():
    # type: () -> Any
    return _current_app


def set_current_app(app):
    # type: (Any) -> None
    global _current_app

    _current_app = app
