"""
:mod:`zsl.application.containers`
---------------------------------

Module containing various IoC containers. IoC container holds\
a collection of modules.
"""
