"""
:mod:`zsl.application.modules`
------------------------------

Module for DI modules.
"""
