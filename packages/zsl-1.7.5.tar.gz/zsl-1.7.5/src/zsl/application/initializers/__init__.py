"""
:mod:`zsl.application.initializers`
-----------------------------------

Module for application parts needed to initialize on start.
"""
