"""
:mod:`zsl.interface.webservice.importer`
----------------------------------------
"""
import os
import sys

# TODO: Consider removing automatic path initialization!
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', '..'))
