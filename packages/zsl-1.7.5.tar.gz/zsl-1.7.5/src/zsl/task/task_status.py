"""
:mod:`zsl.task.task_status`
---------------------------

Status codes for REST services
"""


OK = {'status': 'ok'}

ERROR = {'status': 'error'}
