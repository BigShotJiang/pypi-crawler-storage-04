from wsgiref.handlers import CGIHandler

from flask import Flask

app = Flask(__name__)
