from collections import namedtuple

AlembicConfiguration = namedtuple('AlembicConfiguration', ['alembic_directory'])
