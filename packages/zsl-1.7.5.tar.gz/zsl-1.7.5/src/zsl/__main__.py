"""
:mod:`zsl.__main__` -- zsl main module
======================================

Main service module.
"""
from zsl.interface.cli import cli

if __name__ == "__main__":
    cli()
