# uf uf to nebude easy, potrebujem spusit v pozadi workera, odchytit mu volanie, a v popredi spustit task
# zatial ma nenapadlo ako na to urobit case
#
