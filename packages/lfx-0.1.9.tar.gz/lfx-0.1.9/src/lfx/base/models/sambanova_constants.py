SAMBANOVA_MODEL_NAMES = [
    "Meta-Llama-3.3-70B-Instruct",
    "Meta-Llama-3.1-8B-Instruct",
    "Meta-Llama-3.1-70B-Instruct",
    "Meta-Llama-3.1-405B-Instruct",
    "DeepSeek-R1-Distill-Llama-70B",
    "DeepSeek-R1",
    "Meta-Llama-3.2-1B-Instruct",
    "Meta-Llama-3.2-3B-Instruct",
    "Llama-3.2-11B-Vision-Instruct",
    "Llama-3.2-90B-Vision-Instruct",
    "Qwen2.5-Coder-32B-Instruct",
    "Qwen2.5-72B-Instruct",
    "QwQ-32B-Preview",
    "Qwen2-Audio-7B-Instruct",
]

MODEL_NAMES = SAMBANOVA_MODEL_NAMES
