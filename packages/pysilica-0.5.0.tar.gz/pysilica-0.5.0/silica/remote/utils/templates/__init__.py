"""Templates for silica agent environments."""
