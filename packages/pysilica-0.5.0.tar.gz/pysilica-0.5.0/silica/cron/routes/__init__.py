"""API routes for silica-cron."""
