OC PYTHON SDK
==============
Quickstart
----------

Install package

.. code-block:: bash

    pip install -i https://test.pypi.org/simple/ oc-python-sdk  # Install test package
    pip install oc-python-sdk  # Install released package
