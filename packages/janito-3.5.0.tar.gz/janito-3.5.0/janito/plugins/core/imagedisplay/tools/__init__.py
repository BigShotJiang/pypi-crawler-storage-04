"""Tools for image display plugin."""
