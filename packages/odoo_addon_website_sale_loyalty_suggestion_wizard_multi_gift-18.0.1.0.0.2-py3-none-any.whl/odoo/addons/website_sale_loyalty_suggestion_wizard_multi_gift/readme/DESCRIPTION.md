This module extends the promotion suggestions module on the website by
making suggestions for multi-gift promotions, allowing you to configure
and apply these promotions using the wizard.
