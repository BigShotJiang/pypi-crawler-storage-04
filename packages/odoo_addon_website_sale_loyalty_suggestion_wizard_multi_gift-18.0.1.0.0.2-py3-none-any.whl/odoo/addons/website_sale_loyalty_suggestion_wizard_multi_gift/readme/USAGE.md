To apply promotions:

Option 1:

1.  Go to /promotions and choose the one apply.
2.  You'll be prompted to check the promotion configuration.
3.  Apply after that.

Option 2:

1.  Add a product in the promotion multi-product rules.
2.  A cart suggestion will appear.
3.  Add the promotion and configure the options.

Option 3:

1.  Select a suggested promotion in the shopping cart from a list of
    "Suggested promotions".
2.  Add the promotion and configure the options.
