
<div align="center">
  <img src="assets/icons/SunscanPyLogo.svg" alt="SunscanPy Logo" width="200" height="auto">
  <!-- <h1>SunscanPy</h1> -->
  <p><em>A python library to calibrate the pointing of your weather or cloud radar based on the position of the Sun!</em></p>
</div>

## Description

Precise knowledge of the pointing direction is essential for weather and cloud radars. Radars with scanning capability can be calibrated using the sun as a microwave emitting target with a precisely defined position in the sky.
SunscanPy provides tools to evaluate radar measurements of the sun, derive the mispointing of your antenna and actively correct misalignments using the scanner motors.

For more information, see the two tutorial jupyter notebooks provided in the examples subfolder.

## Installation
```bash
pip install sunscanpy
```

### From source

```bash
git clone https://github.com/yourusername/sunscanpy.git
cd sunscanpy
pip install -e .
```

## Contributing
See Contributing.md

## License

SunscanPy  © 2025 by Paul Ockenfuß, Gregor Köcher, Ludwig-Maximilians Universität München is licensed under CC BY-SA 4.0. To view a copy of this license, visit https://creativecommons.org/licenses/by-sa/4.0/


## Authors

- Paul Ockenfuß
- Gregor Köcher
