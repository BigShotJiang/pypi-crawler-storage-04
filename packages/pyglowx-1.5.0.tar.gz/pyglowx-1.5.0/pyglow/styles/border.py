class Border:
    ROUNDED = "rounded"
    SQUARE = "square"
    HEAVY = "heavy"
    DOUBLE = "double"
    MINIMAL = "minimal"