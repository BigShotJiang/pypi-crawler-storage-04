# QCC v0.3.0 发布说明 - 终端UI框架升级

## 🚀 主要新功能

### 现代化交互式终端UI
- **全新终端框架**: 基于 `rich` + `prompt_toolkit` 的现代化终端界面
- **箭头键导航**: 支持 ↑↓ 键选择选项，Enter 确认，数字键快选
- **智能倒计时**: 默认自动选择，用户交互后停止倒计时
- **视觉增强**: 彩色高亮、实时反馈、加载动画、状态提示

### 交互式命令升级
- **`qcc default`** - 无参数时提供交互式设置默认配置
- **`qcc remove`** - 无参数时提供交互式删除配置选择  
- **`qcc use`** - 无参数时提供交互式配置选择和启动

### 跨平台兼容性
- **多系统支持**: Windows, macOS, Linux 全平台兼容
- **自动回退**: 新UI无法启动时自动使用简化模式
- **终端适配**: 自动检测终端能力，优雅降级

## 🎯 用户体验改进

### 更智能的选择界面
- 显示配置详细信息: 名称、描述、最后使用时间
- 智能默认选择高亮 (⭐ 标记)
- 实时倒计时显示，用户操作后停止
- 清晰的操作提示和帮助信息

### 增强的安全性
- 删除操作二次确认机制
- 显示完整配置信息供确认
- 友好的取消操作支持

### 完全向下兼容
- 保持所有现有命令参数方式可用
- 现有脚本和使用习惯无需改变
- 渐进式增强，不破坏现有功能

## 🔧 技术改进

### 新增依赖
- `rich>=12.0.0` - 提供丰富的终端显示效果
- `prompt_toolkit>=3.0.0` - 提供强大的交互式输入功能

### 代码架构优化
- 重构 `select_from_list` 函数支持交互式选择
- 增强所有 UI 组件的视觉效果
- 改进错误处理和异常恢复
- 优化导入结构和模块组织

### 错误修复
- 修复 `print_separator` 和 `confirm_action` 导入错误
- 改进 Windows 系统的终端兼容性
- 优化非交互环境下的回退机制

## 📋 使用示例

### 新的交互式使用方式
```bash
# 交互式选择默认配置
qcc default

# 交互式删除配置
qcc remove  

# 交互式选择并启动配置
qcc use
```

### 传统方式依然可用
```bash
# 直接指定配置名称
qcc default myconfig
qcc remove myconfig
qcc use myconfig
```

## 🚀 升级指南

1. **安装新版本**
   ```bash
   pip install --upgrade qcc
   ```

2. **新依赖安装**
   新版本会自动安装 `rich` 和 `prompt_toolkit`

3. **使用体验**
   - 所有现有命令保持不变
   - 新增的交互式功能可选使用
   - 在不支持的环境中自动回退

## 🔗 相关链接

- **PyPI**: https://pypi.org/project/qcc/
- **GitHub**: https://github.com/你的用户名/qcc
- **文档**: 查看 `USAGE_EXAMPLE.md` 了解详细使用方法

## 🙏 致谢

感谢所有用户的反馈和建议，让 QCC 变得更好用！

---

**完整更新日志**: v0.2.1...v0.3.0


export TWINE_USERNAME=__token__
export TWINE_PASSWORD=pypi-AgEIcHlwaS5vcmcCJGFhZjQzODgwLTBmMDctNGZjZi05MGE2LTU2MTdlYmZkODlkNQACC1sxLFsicWNjIl1dAAIsWzIsWyIxNTQ2NGIzZC0wMWExLTRlZmEtOTAyMC05NjczMzEwNGNjZDYiXV0AAAYglSGucBUSc2EcxOb3kGtJJxFgJwKsQ-J8u53wt1Z1uls
source venv/bin/activate && python -m twine upload dist/*