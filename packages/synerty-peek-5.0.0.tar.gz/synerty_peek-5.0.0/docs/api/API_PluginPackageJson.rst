.. _api_plugin_package_json:

================================
File :file:`plugin_package.json`
================================


This page will describe the options in the :file:`plugin_package.json`

