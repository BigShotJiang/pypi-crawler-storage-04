.. _admin_win:

Peek Windows Admin
------------------

.. toctree::
    :maxdepth: 1
    :caption: Contents:

    admin_win_services
    win_postgres_backup_restore

