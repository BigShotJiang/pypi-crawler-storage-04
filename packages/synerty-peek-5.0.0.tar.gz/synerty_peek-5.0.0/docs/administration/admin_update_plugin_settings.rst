.. _admin_update_plugin_settings:

Updating Plugin Settings
------------------------

Plugins are intended to be entierly configured via the peek server Admin page.

Navigate to `<http://127.0.0.1:8010/>`_ and click the plugins dropdown.
