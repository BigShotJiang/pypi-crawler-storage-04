.. _upgrade_notes:

=============
Release Notes
=============

.. toctree::
    :maxdepth: 1
    :caption: Contents:

    PEEP0XX/IndexUpgrade
    v4.1.x/v4.1.x
    v4.0.x/v4.0.x
    v3.4.x/release_notes_v3.4.x_uat
    v3.4.x/v3.4.x
    v3.3.x/v3.3.x
    v3.2.x/v3.2.x
    v3.1.x/v3.1.x
    v3.1.x/v3.1.x_uat
    v3.0.x/v3.0.x
    v2.5.x/v2.5.x
    v2.4.x/v2.4.x
    v2.3.x/v2.3.x
    v2.2.x/v2.2.x
    v2.1.x/v2.1.x
    v2.0.x/v2.0.x
    v1.3.x/v1.3.x
    v1.2.x/v1.2.x
    v1.1.0/v1.1.0
    v0.10.0/v0.10.0
    v0.6.0/v0.6.0
