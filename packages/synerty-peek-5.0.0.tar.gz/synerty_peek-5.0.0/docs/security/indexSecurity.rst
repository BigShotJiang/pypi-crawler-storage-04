.. _security_errata:

===============
Security Errata
===============

.. toctree::
    :maxdepth: 1
    :caption: Contents:

    CVE-2023-40217/CVE-2023-40217