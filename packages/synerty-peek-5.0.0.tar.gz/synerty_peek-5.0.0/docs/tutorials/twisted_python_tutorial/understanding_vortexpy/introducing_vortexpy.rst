====================
Introducing VortexPy
====================


What is a VortexPy?
-------------------

VortexPy is Synerty's observable, routable, data serialisation and transport code.
