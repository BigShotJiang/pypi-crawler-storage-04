=========
deferUtil
=========

DeferUtil provides utility utility methods make it easy to integrate Twisted's Deferreds simply, with
a focus on painless multithreading. The library also provides control methods to limit or log the execution of
these methods.

