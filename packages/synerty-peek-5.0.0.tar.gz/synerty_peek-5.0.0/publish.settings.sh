#!/usr/bin/env bash

PY_PACKAGE="synerty_peek"
PYPI_PUBLISH="1"

VER_FILES_TO_COMMIT="docs/conf.py"

VER_FILES="docs/conf.py"
