__project__ = "Synerty Peek"
__copyright__ = "2016, Synerty"
__author__ = "Synerty"
__version__ = "0.0.0"
