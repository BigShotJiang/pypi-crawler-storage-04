# Recommended FineCode preset for formatting in Python projects
