"""Generated protocol buffer code."""
from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder
_sym_db = _symbol_database.Default()
DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n\x1dresponses/retrieve_tags.proto\x12\x08protocol"*\n\x14RetrieveTagsResponse\x12\x12\n\x04tags\x18\x01 \x03(\tR\x04tagsb\x06proto3')
_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'responses.retrieve_tags_pb2', _globals)
if _descriptor._USE_C_DESCRIPTORS == False:
    DESCRIPTOR._options = None
    _globals['_RETRIEVETAGSRESPONSE']._serialized_start = 43
    _globals['_RETRIEVETAGSRESPONSE']._serialized_end = 85