# Version History

## 0.1.2

* Change metadata structure
* Update requirements.txt

## 0.1.1

* Rename project to pgpack_dumper
* Fix legacy setup.py bdist_wheel mechanism, which will be removed in a future version
* Fix multiquery
* Add CHANGELOG.md

## 0.1.0

* Add CopyBufferObjectError & CopyBufferTableNotDefined
* Add PGObject
* Add logger
* Add sqlparse for cut comments from query
* Add multiquery
* Update requirements.txt

## 0.0.2

* Fix include *.sql
* Fix requirements.txt
* Docs change README.md

## 0.0.1

First version of the library pgcrypt_dumper
