__version__ = "74.20250829"
GIT_REF = "3369cf3"
URL = "https://github.com/micro-manager/mmCoreAndDevices/tree/3369cf3"