from morgoth.morgoth import *
from morgoth.multivariate_dt import *
from morgoth.conformal_prediction import *
from morgoth.similarity_test_train import *
from morgoth.multi_rf_main import *
__version__ = 1.2
