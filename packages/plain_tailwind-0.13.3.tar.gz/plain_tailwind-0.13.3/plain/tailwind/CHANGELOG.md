# plain-tailwind changelog

## [0.13.3](https://github.com/dropseed/plain/releases/plain-tailwind@0.13.3) (2025-09-03)

### What's changed

- Comprehensive README update with improved documentation structure, table of contents, and detailed usage examples ([4ebecd1](https://github.com/dropseed/plain/commit/4ebecd1856))
- Added AGENTS.md file with guidance for conditional Tailwind styling using `data-` attributes ([df3edbf](https://github.com/dropseed/plain/commit/df3edbf0bd))

### Upgrade instructions

- No changes required

## [0.13.2](https://github.com/dropseed/plain/releases/plain-tailwind@0.13.2) (2025-07-07)

### What's changed

- The CLI now shows a progress bar while downloading the Tailwind standalone binary, so long downloads no longer appear to hang ([ec637aa](https://github.com/dropseed/plain/commit/ec637aa)).

### Upgrade instructions

- No changes required

## [0.13.1](https://github.com/dropseed/plain/releases/plain-tailwind@0.13.1) (2025-06-26)

### What's changed

- No user-facing changes in this patch release. Internal housekeeping of the CHANGELOG file only ([e1f5dd3](https://github.com/dropseed/plain/commit/e1f5dd3e4612)).

### Upgrade instructions

- No changes required
