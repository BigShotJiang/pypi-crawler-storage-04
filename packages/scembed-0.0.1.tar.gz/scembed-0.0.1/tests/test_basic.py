import scembed


def test_package_has_version():
    assert scembed.__version__ is not None
