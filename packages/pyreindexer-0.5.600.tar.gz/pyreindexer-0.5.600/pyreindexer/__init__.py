"""
The pyreindexer module provides a connector and its auxiliary tools for interaction with Reindexer.
"""

from pyreindexer.rx_connector import RxConnector
