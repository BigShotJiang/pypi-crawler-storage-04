#!/usr/bin/env python3
"""
Entry point for splurge-sql-runner when run as a module.

This module serves as a stub that delegates to the CLI module.

Copyright (c) 2025, Jim Schilling

This module is licensed under the MIT License.
"""

from splurge_sql_runner.cli import main

if __name__ == "__main__":
    main()
