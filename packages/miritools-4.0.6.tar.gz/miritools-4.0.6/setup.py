"""
Setup.py added because I don't understand how to upload to pypi without a setup.py,
even if I don't need it to do a pip install
"""

from setuptools import setup

setup()
