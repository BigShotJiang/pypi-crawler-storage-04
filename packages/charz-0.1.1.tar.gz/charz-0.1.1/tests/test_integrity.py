def test_integrity() -> None:
    import charz  # noqa: PLC0415
