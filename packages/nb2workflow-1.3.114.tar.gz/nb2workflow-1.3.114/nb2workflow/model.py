

class DataFile:
    def __init__(self,fn):
        self.filename = fn
