import os

from mtcli.conf import *

symbol = os.getenv("SYMBOL", "WINV25")
sl = os.getenv("SL", 150)
tp = os.getenv("TP", 300)
