"""This module if for processing text."""
