""".. include:: ./doc.md"""  # noqa: D415

from .api import classify_emotions_from_speech  # noqa: F401
