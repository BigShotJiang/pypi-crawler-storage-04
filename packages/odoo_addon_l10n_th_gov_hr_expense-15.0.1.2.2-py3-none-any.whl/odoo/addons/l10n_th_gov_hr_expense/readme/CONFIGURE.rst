To configure the Purchase Request to link with Expense,
you need to go to the Purchase > Configuration > Purchase Type.
Choose the type and change the 'To Create' setting to Expense.
