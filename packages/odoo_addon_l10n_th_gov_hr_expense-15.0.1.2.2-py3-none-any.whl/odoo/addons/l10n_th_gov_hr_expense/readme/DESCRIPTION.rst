This module enhances the integration of Purchase Request and Expense,
aimed to follow Thai Government regulations.
