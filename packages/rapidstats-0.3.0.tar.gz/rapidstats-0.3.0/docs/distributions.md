::: rapidstats._distributions
