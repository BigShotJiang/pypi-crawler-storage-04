# SPDX-FileCopyrightText: UL Research Institutes
# SPDX-License-Identifier: Apache-2.0

# class Tagger(_Tagger, frozen=True, tag=str.lower):
# files: Set[str] = field(default_factory=set)


# class Names(Files, frozen=True):
#     names: List[str] = field(default_factory=list)
#
#
# class Fnmatches(Files, frozen=True):
#     patterns: List[str] = field(default_factory=list)
