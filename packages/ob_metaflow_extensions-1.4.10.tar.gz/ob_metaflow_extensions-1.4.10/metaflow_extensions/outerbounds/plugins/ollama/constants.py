OLLAMA_SUFFIX = "mf.ollama"
