from setuptools import setup, find_packages

setup(
    name="offline_chat",
    version="0.1.0",
    packages=find_packages(),
    install_requires=[
        "pycryptodome",
        "prompt_toolkit"
    ],
    python_requires='>=3.8',
    entry_points={
        "console_scripts": [
            "offline_chat=offline_chat.main:main",
        ],
    },
)

