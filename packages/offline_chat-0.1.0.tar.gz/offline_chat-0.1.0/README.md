# Offline Chat

Offline Chat adalah sistem komunikasi peer-to-peer (P2P) **100% offline** dengan AES end-to-end encryption.  
Dirancang agar bisa dijalankan di **Android (Termux)** atau **Linux/PC** masih versi beta mungkin pesan tidak terkirim atau gagal aku akan mengupdate nya seiring waktu tapi untuk complain silakan lewat email jika anda menemukan kendala. 

### Fitur
- Offline P2P, tanpa internet, Wi-Fi, Bluetooth, NFC, USB, atau SD card  
- User register/login dengan AES key unik  
- Mutual contact → hanya bisa kirim ke teman  
- Listener realtime → pesan masuk langsung muncul  
- Notifikasi cross-platform:
  - Termux Android → termux-notification  
  - Linux → notify-send  
  - Fallback → terminal print  

##Cara pakai

- offline_chat

- Pilih Register atau Login

- Tambah teman /add USERID

- Kirim pesan /send USERID pesanmu

- Lihat daftar teman /list

- Keluar /exit

### Cara install
```bash
pip install offline_chat
