## DroneCOT 1.1.1

- Fixes #2: Missing cot_to_xml function export.

## DroneCOT 1.1.0

* Updates


## DroneCOT 1.0.0

Initial release of DroneCOT.
