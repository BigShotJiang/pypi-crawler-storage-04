"""
devctl-mcp: A basic MCP (Model Context Protocol) server implementation
"""

from ._version import __version__

__all__ = ["__version__"]