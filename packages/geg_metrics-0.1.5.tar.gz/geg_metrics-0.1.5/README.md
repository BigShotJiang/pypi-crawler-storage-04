# GEG Eencodes Graphs

GEG Encodes Graphs is a JSON based storage format for encoding graph drawings which contain complex edge geometries using SVG path commands. GEG enables readability metric calculations on drawings containing curved/polygonal edges. 

This package contains code for reading/wwriting GEG files, converting to/from other common formats, and several readability metric implementations.

## Installation

## Usage

### For more information, see the following publication:
GD PAPER CITATION 