from llama_index.postprocessor.ibm.base import WatsonxRerank


__all__ = ["WatsonxRerank"]
