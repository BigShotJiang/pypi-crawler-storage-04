View utilities
==============


create_view
-----------

.. autofunction:: sqlalchemy_utils.view.create_view


create_materialized_view
------------------------

.. autofunction:: sqlalchemy_utils.view.create_materialized_view


refresh_materialized_view
-------------------------

.. autofunction:: sqlalchemy_utils.view.refresh_materialized_view
