Observers
=========

.. automodule:: sqlalchemy_utils.observer

.. autofunction:: observes
