Range data types
================

.. automodule:: sqlalchemy_utils.types.range


DateRangeType
-------------

.. autoclass:: DateRangeType


DateTimeRangeType
-----------------

.. autoclass:: DateTimeRangeType


IntRangeType
------------

.. autoclass:: IntRangeType


NumericRangeType
----------------

.. autoclass:: NumericRangeType


RangeComparator
---------------

.. autoclass:: RangeComparator
    :members:
