from .person import PlayerButtonConfig
from .team import TeamButtonConfig
