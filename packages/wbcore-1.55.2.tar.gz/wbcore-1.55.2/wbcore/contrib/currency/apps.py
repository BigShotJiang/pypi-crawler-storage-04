from django.apps import AppConfig


class CurrencyConfig(AppConfig):
    name = "wbcore.contrib.currency"
