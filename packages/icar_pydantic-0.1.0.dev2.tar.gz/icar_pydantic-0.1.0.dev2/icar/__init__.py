"""``ICAR`` pydantic models."""

name = "icar"

VERSION = (0, 1, 0, "dev2")

__version__ = ".".join(str(v) for v in VERSION)
