from setuptools import setup, find_packages

setup(
    name="vzr-pybridge",
    version="0.1.0",
    description="SDK simples para integração com serviços Vezor",
    author="Breno Leone",
    author_email="contato@vezor.com.br",
    url="https://github.com/seuuser/vzr-pybridge",
    packages=find_packages(),
    install_requires=["requests>=2.31.0"],
    python_requires=">=3.8",
)
