See `the pimutils CoC <http://pimutils.org/coc>`_.
