from __future__ import annotations

if __name__ == "__main__":
    from vdirsyncer.cli import app

    app()
