===================
Credits and License
===================

.. include:: ../AUTHORS.rst

License
=======

.. include:: ../LICENSE
