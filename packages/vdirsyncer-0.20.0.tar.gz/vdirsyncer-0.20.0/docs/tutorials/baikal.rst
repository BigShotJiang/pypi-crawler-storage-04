======
Baikal
======

Vdirsyncer is continuously tested against the latest version of Baikal_.

- Baikal up to ``0.2.7`` also uses an old version of SabreDAV, with the same
  issue as ownCloud, see :gh:`160`. This issue is fixed in later versions.

.. _Baikal: http://sabre.io/baikal/
