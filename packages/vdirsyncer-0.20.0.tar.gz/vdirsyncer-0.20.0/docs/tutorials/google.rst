======
Google
======

Using vdirsyncer with Google Calendar is possible as of 0.10, but it is not
tested frequently. You can use :storage:`google_contacts` and
:storage:`google_calendar`.

For more information see :gh:`202` and :gh:`8`.
