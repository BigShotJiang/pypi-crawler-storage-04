===================
Support and Contact
===================

* The ``#pimutils`` `IRC channel on Libera.Chat <https://pimutils.org/contact>`_
  might be active, depending on your timezone. Use it for support and general
  (including off-topic) discussion.

* Open `a GitHub issue <https://github.com/pimutils/vdirsyncer/issues/>`_ for
  concrete bug reports and feature requests.

* For security issues, contact ``contact@pimutils.org``.
