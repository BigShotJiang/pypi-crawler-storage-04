=========
Donations
=========

vdirsyncer is and will always be free and open source software. We appreciate
sponsors willing to fund our continued work on it.

If you found my work useful, please consider donating. Thank you!

- Bitcoin: ``13p42uWDL62bNRH3KWA6cSpSgvnHy1fs2E``.
- Sponsor via one-time tips or recurring donations `via Ko-fi`_.
- Sponsor via recurring donations `via liberapay`_.

.. _via Ko-fi: https://ko-fi.com/whynothugo
.. _via liberapay: https://liberapay.com/WhyNotHugo/
