import pathlib

# The absolute path to this module
__templates_path__ = pathlib.Path(__file__).parent

del pathlib
