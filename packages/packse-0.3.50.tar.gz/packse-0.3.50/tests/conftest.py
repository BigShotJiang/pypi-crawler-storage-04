# Ensure common fixtures are available to all tests

from .common import *  # noqa: F403
