# sack
Lightweight chat application for terminal

<img width="1180" height="857" alt="image" src="https://github.com/user-attachments/assets/975a44b7-f1be-4cdb-a5da-9966364b1d9b" />
