# flashplot

```
pip install flashplot
```

```python
import flashplot as fp
```
