from .goldie import *

MAIN_AGENT = Goldie
__all__ = goldie.__all__

__author__ = ""
__team__ = ""
__email__ = ""
__version__ = "0.1.0"
