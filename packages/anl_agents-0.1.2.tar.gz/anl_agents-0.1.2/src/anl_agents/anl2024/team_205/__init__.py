from .kosagent import *

MAIN_AGENT = KosAgent
__all__ = kosagent.__all__

__author__ = ""
__team__ = ""
__email__ = ""
__version__ = "0.1.0"
