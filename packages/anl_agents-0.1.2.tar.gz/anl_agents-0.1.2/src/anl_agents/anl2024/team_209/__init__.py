from .bargain_bot import *

MAIN_AGENT = BargainBot
__all__ = bargain_bot.__all__

__author__ = ""
__team__ = ""
__email__ = ""
__version__ = "0.1.0"
