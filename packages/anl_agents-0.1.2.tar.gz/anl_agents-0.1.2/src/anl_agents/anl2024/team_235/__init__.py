from .group6 import *

MAIN_AGENT = Group6
__all__ = group6.__all__

__author__ = ""
__team__ = ""
__email__ = ""
__version__ = "0.1.0"
