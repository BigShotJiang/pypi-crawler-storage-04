from .nayesian import *
from .nayesian2 import *

MAIN_AGENT = Nayesian2
__all__ = nayesian.__all__ + nayesian2.__all__

__author__ = ""
__team__ = ""
__email__ = ""
__version__ = "0.1.0"
