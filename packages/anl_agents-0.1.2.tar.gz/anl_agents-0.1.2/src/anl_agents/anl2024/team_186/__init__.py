from .ilan import *
from .myagent import *

MAIN_AGENT = Ilan
__all__ = ilan.__all__ + myagent.__all__

__author__ = ""
__team__ = ""
__email__ = ""
__version__ = "0.1.0"
