from .renting2024 import *

MAIN_AGENT = AgentRenting2024
__all__ = renting2024.__all__

__author__ = ""
__team__ = ""
__email__ = ""
__version__ = "0.1.0"
