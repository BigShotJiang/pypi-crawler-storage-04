from .antiagent import *

MAIN_AGENT = AntiAgent
__all__ = antiagent.__all__

__author__ = ""
__team__ = """
1. Panagiotis Aronis <p.aronis@students.uu.nl>
2. Sander van Bennekom <s.vanbennekom1@students.uu.nl>
3. Mats Buis <m.p.buis@students.uu.nl>
4. Vedant Puneet Singh <v.p.singh@students.uu.nl>
5. Collin de Wit <c.r.dewit@students.uu.nl>
"""
__email__ = ""
__version__ = "0.1.0"
