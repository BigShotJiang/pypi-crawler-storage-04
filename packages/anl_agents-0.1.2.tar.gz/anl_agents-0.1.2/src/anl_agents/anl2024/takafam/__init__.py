from .shochan import *

MAIN_AGENT = Shochan
__all__ = shochan.__all__

__author__ = ""
__team__ = ""
__email__ = ""
__version__ = "0.1.0"
