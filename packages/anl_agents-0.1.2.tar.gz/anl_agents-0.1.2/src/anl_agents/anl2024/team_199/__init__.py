from .hard_chaos import *

MAIN_AGENT = HardChaosNegotiator
__all__ = hard_chaos.__all__

__author__ = ""
__team__ = ""
__email__ = ""
__version__ = "0.1.0"
