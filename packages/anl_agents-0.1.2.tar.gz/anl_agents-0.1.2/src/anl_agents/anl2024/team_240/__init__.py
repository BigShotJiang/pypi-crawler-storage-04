from .bidbot import *

MAIN_AGENT = BidBot
__all__ = bidbot.__all__

__author__ = ""
__team__ = ""
__email__ = ""
__version__ = "0.1.0"
