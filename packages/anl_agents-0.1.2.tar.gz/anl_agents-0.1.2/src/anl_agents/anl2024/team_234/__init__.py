from .ardabot import *

MAIN_AGENT = Ardabot
__all__ = ardabot.__all__

__author__ = ""
__team__ = ""
__email__ = ""
__version__ = "0.1.0"
