from .inegotiator import *
from .others import *

MAIN_AGENT = INegotiator
__all__ = inegotiator.__all__ + others.__all__

__author__ = ""
__team__ = ""
__email__ = ""
__version__ = "0.1.0"
