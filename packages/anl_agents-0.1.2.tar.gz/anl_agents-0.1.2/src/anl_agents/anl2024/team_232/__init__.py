from .tak import *

MAIN_AGENT = TAKAgent
__all__ = tak.__all__

__author__ = ""
__team__ = ""
__email__ = ""
__version__ = "0.1.0"
