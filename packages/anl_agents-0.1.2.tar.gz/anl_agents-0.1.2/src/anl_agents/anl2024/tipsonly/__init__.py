from .katla_nir_aent import *

MAIN_AGENT = KatlaNirAgent
__all__ = katla_nir_aent.__all__

__author__ = ""
__team__ = ""
__email__ = ""
__version__ = "0.1.0"
