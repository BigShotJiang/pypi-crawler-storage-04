from .riv_agent import *

MAIN_AGENT = RivAgent
__all__ = riv_agent.__all__

__author__ = ""
__team__ = ""
__email__ = ""
__version__ = "0.1.0"
