from .carc2025 import *

MAIN_AGENT = CARC2025
__all__ = carc2025.__all__

__author__ = ""
__team__ = ""
__email__ = ""
__version__ = "0.1.0"
