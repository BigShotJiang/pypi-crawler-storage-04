from .agent import *

MAIN_AGENT = EOHAgent
__all__ = agent.__all__

__author__ = ""
__team__ = ""
__email__ = ""
__version__ = "0.1.0"
