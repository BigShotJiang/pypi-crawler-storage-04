from .star_gold import *

MAIN_AGENT = StarGold15
__all__ = star_gold.__all__

__author__ = ""
__team__ = ""
__email__ = ""
__version__ = "0.1.0"
