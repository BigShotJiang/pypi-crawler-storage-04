"""
Workflow patterns - explicit control flow.
"""

class WorkflowSystem:
    """Workflow system stub."""
    pass
