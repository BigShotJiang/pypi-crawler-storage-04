print("Hi")
