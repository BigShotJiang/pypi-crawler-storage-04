figaro.utils module
===================

.. automodule:: figaro.utils
   :members:
   :undoc-members:
   :show-inheritance:
