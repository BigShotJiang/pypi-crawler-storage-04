﻿figaro.load
===========

.. automodule:: figaro.load

   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
   
      available_gw_pars
      load_data
      load_density
      load_single_event
      save_density
   
   

   
   
   

   
   
   



