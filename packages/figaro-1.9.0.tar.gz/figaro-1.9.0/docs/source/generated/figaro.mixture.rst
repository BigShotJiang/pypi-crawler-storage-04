﻿figaro.mixture
==============

.. automodule:: figaro.mixture

   
   
   

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
   
      DPGMM
      HDPGMM
      density
      mixture
   
   

   
   
   



