﻿figaro.marginal
===============

.. automodule:: figaro.marginal

   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
   
      condition
      marginalise
   
   

   
   
   

   
   
   



