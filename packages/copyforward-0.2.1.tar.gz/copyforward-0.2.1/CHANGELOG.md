# Changelog

All notable changes to this project will be documented in this file.
This project follows Keep a Changelog and Semantic Versioning.

## [Unreleased]
- TBD

## [0.2.1] - 2025-08-28
- Add crates.io publish workflow triggered by `v*` tags.
- Add MIT LICENSE file and update copyright.
- Add required Cargo metadata (description, readme).
- Bump version to 0.2.1.
- Add README badges and initial changelog.

