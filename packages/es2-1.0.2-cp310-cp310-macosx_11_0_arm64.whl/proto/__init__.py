import os
import sys

from . import es2_comm_type_pb2

sys.path.append(os.path.abspath(os.path.dirname(__file__)))
