# Sovant Python SDK

**AI Infrastructure: Memory-as-a-Service for AI systems.**  
The official Python client for the Sovant Memory API.

[![PyPI version](https://img.shields.io/pypi/v/sovant)](https://pypi.org/project/sovant/)
[![Documentation](https://img.shields.io/badge/docs-sovant.ai-blue)](https://sovant.ai/docs)
[![GitHub](https://img.shields.io/badge/github-sovant-lightgrey)](https://github.com/sovant-ai/sovant)

---

## What is Sovant?

Sovant is an **AI infrastructure company** providing the **memory layer for AI systems**.  
Our platform makes it simple to persist, search, and manage conversational/context data securely across sessions, channels, and applications.

- **Problem:** Most AI systems forget once a session ends → compliance risk, knowledge loss, poor UX.  
- **Solution:** Sovant provides a **Memory-as-a-Service API** — store, retrieve, and search memories with audit-ready controls.  
- **Built for:** Developers & enterprises building AI agents, copilots, or compliance-driven apps that need persistent context.

---

## Installation

```bash
pip install sovant
```

## 60-Second Quickstart

```python
from sovant import Sovant, MemoryCreate, SearchQuery

client = Sovant(api_key="YOUR_API_KEY")

# Create a memory
created = client.memory_create(MemoryCreate(
    content="User prefers morning meetings",
    type="preference",
    tags=["customer:123"],
    # metadata={"source": "crm"},
    # thread_id="00000000-0000-0000-0000-000000000000",
))
print(created)

# Search memories
results = client.memory_search(SearchQuery(
    query="meeting preferences",
    topK=3,
    # tags=["customer:123"],
    # thread_id="...",
))
print(results)
```

## Features

- **Memory CRUD** — create, retrieve, update (PATCH/PUT), delete
- **Semantic Search** — full-text/semantic with topK and filters
- **Threads** — group related memories via thread_id (REST API)
- **Batch Operations (Beta)** — atomic multi-operation requests
- **Compliance-ready** — audit trails, PDPA/GDPR-friendly design
- **SDKs** — official Python & TypeScript clients + REST reference

## SDKs & Documentation

- **Python** (this package) on PyPI: https://pypi.org/project/sovant/
- **TypeScript** on npm: https://www.npmjs.com/package/@sovant/sdk
- **REST API Reference**: https://sovant.ai/docs/api
- **Full Documentation**: https://sovant.ai/docs

## API Overview

### Endpoints Summary

- `POST /api/v1/memory` — Create memory
- `GET /api/v1/memory` — List memories
- `GET /api/v1/memories/{id}` — Get by ID
- `PATCH | PUT /api/v1/memories/{id}` — Update
- `DELETE /api/v1/memories/{id}` — Delete
- `GET /api/v1/memory/search` — Search
- `POST /api/v1/memory/batch` — Batch (Beta)

**Auth:** Bearer token in the `Authorization` header.

## Field Mapping Note

- **API expects:** `content` (required), optional `type`, `tags`, `metadata`, `thread_id`.
- **SDK convenience:** Some client methods may accept `data` and map it to `content` internally.
- **Deprecated:** `subject` is ignored by the API. Use `thread_id`, `tags`, or `metadata` for grouping.

## Status of Advanced Features

- **Batch API:** Available, marked Beta (contract may evolve).
- **Threads:** Fully supported via REST API.
- **Webhooks / Personalization / Multi-Channel Sync:** Coming soon.

## Versioning & Changelog

- **Stable baseline:** 1.0.3
- See [CHANGELOG.md](https://github.com/sovant-ai/sovant) in the repo for details.

## License

MIT © Sovant AI