"""
Algorithms for update of genes.
"""
