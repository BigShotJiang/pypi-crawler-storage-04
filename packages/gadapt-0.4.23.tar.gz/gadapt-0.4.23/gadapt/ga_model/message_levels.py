"""
Message levels
"""

ERROR = "ERROR"
WARNING = "WARNING"
INFO = "INFO"
