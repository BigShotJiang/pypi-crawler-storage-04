# LangGate Client

HTTP client for LangGate AI Gateway.

This package provides an HTTP client for interacting with a remote LangGate registry server. Use this package when you want to connect to a remote LangGate service instead of running the registry locally.
