# l6e-forge-cli

CLI for Forge. Provides the `forge` command and user-facing tooling that depends on the core library `l6e-forge`.

Links:
- Homepage: https://l6e.ai
- Docs: https://docs.l6e.ai
- Monorepo for Forge: https://github.com/l6e-ai/forge
- Issues: https://github.com/l6e-ai/forge/issues

License: Apache 2.0

