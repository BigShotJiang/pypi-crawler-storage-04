"""Tests for configuration options."""
