"""Project Module."""
from .project import CAUProject

__all__ = ("CAUProject", )
