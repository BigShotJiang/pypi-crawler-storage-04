"""Tests for CAU CLI."""
