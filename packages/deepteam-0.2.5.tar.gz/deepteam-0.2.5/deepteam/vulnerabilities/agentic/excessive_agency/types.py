from enum import Enum


class ExcessiveAgencyType(Enum):
    FUNCTIONALITY = "functionality"
    PERMISSIONS = "permissions"
    AUTONOMY = "autonomy"
