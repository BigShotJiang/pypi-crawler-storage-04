from .types import GoalTheftType
from .template import GoalTheftTemplate
