var Xa = Object.defineProperty;
var di = (i) => {
  throw TypeError(i);
};
var Wa = (i, e, t) => e in i ? Xa(i, e, { enumerable: !0, configurable: !0, writable: !0, value: t }) : i[e] = t;
var X = (i, e, t) => Wa(i, typeof e != "symbol" ? e + "" : e, t), Ya = (i, e, t) => e.has(i) || di("Cannot " + t);
var fi = (i, e, t) => e.has(i) ? di("Cannot add the same private member more than once") : e instanceof WeakSet ? e.add(i) : e.set(i, t);
var Xt = (i, e, t) => (Ya(i, e, "access private method"), t);
const {
  SvelteComponent: Ka,
  append_hydration: Zn,
  assign: Qa,
  attr: ue,
  binding_callbacks: Ja,
  children: Bt,
  claim_element: zl,
  claim_space: Il,
  claim_svg_element: kn,
  create_slot: eo,
  detach: Ie,
  element: Ml,
  empty: hi,
  get_all_dirty_from_scope: to,
  get_slot_changes: no,
  get_spread_update: io,
  init: lo,
  insert_hydration: zt,
  listen: ao,
  noop: oo,
  safe_not_equal: ro,
  set_dynamic_element_data: pi,
  set_style: R,
  space: Rl,
  svg_element: Fn,
  toggle_class: ne,
  transition_in: Ol,
  transition_out: Nl,
  update_slot_base: so
} = window.__gradio__svelte__internal;
function mi(i) {
  let e, t, n, l, a;
  return {
    c() {
      e = Fn("svg"), t = Fn("line"), n = Fn("line"), this.h();
    },
    l(o) {
      e = kn(o, "svg", { class: !0, xmlns: !0, viewBox: !0 });
      var r = Bt(e);
      t = kn(r, "line", {
        x1: !0,
        y1: !0,
        x2: !0,
        y2: !0,
        stroke: !0,
        "stroke-width": !0
      }), Bt(t).forEach(Ie), n = kn(r, "line", {
        x1: !0,
        y1: !0,
        x2: !0,
        y2: !0,
        stroke: !0,
        "stroke-width": !0
      }), Bt(n).forEach(Ie), r.forEach(Ie), this.h();
    },
    h() {
      ue(t, "x1", "1"), ue(t, "y1", "9"), ue(t, "x2", "9"), ue(t, "y2", "1"), ue(t, "stroke", "gray"), ue(t, "stroke-width", "0.5"), ue(n, "x1", "5"), ue(n, "y1", "9"), ue(n, "x2", "9"), ue(n, "y2", "5"), ue(n, "stroke", "gray"), ue(n, "stroke-width", "0.5"), ue(e, "class", "resize-handle svelte-239wnu"), ue(e, "xmlns", "http://www.w3.org/2000/svg"), ue(e, "viewBox", "0 0 10 10");
    },
    m(o, r) {
      zt(o, e, r), Zn(e, t), Zn(e, n), l || (a = ao(
        e,
        "mousedown",
        /*resize*/
        i[27]
      ), l = !0);
    },
    p: oo,
    d(o) {
      o && Ie(e), l = !1, a();
    }
  };
}
function uo(i) {
  var d;
  let e, t, n, l, a;
  const o = (
    /*#slots*/
    i[31].default
  ), r = eo(
    o,
    i,
    /*$$scope*/
    i[30],
    null
  );
  let u = (
    /*resizable*/
    i[19] && mi(i)
  ), c = [
    { "data-testid": (
      /*test_id*/
      i[11]
    ) },
    { id: (
      /*elem_id*/
      i[6]
    ) },
    {
      class: n = "block " + /*elem_classes*/
      (((d = i[7]) == null ? void 0 : d.join(" ")) || "") + " svelte-239wnu"
    },
    {
      dir: l = /*rtl*/
      i[20] ? "rtl" : "ltr"
    }
  ], s = {};
  for (let f = 0; f < c.length; f += 1)
    s = Qa(s, c[f]);
  return {
    c() {
      e = Ml(
        /*tag*/
        i[25]
      ), r && r.c(), t = Rl(), u && u.c(), this.h();
    },
    l(f) {
      e = zl(
        f,
        /*tag*/
        (i[25] || "null").toUpperCase(),
        {
          "data-testid": !0,
          id: !0,
          class: !0,
          dir: !0
        }
      );
      var h = Bt(e);
      r && r.l(h), t = Il(h), u && u.l(h), h.forEach(Ie), this.h();
    },
    h() {
      pi(
        /*tag*/
        i[25]
      )(e, s), ne(
        e,
        "hidden",
        /*visible*/
        i[14] === !1
      ), ne(
        e,
        "padded",
        /*padding*/
        i[10]
      ), ne(
        e,
        "flex",
        /*flex*/
        i[1]
      ), ne(
        e,
        "border_focus",
        /*border_mode*/
        i[9] === "focus"
      ), ne(
        e,
        "border_contrast",
        /*border_mode*/
        i[9] === "contrast"
      ), ne(e, "hide-container", !/*explicit_call*/
      i[12] && !/*container*/
      i[13]), ne(
        e,
        "fullscreen",
        /*fullscreen*/
        i[0]
      ), ne(
        e,
        "animating",
        /*fullscreen*/
        i[0] && /*preexpansionBoundingRect*/
        i[24] !== null
      ), ne(
        e,
        "auto-margin",
        /*scale*/
        i[17] === null
      ), R(
        e,
        "height",
        /*fullscreen*/
        i[0] ? void 0 : (
          /*get_dimension*/
          i[26](
            /*height*/
            i[2]
          )
        )
      ), R(
        e,
        "min-height",
        /*fullscreen*/
        i[0] ? void 0 : (
          /*get_dimension*/
          i[26](
            /*min_height*/
            i[3]
          )
        )
      ), R(
        e,
        "max-height",
        /*fullscreen*/
        i[0] ? void 0 : (
          /*get_dimension*/
          i[26](
            /*max_height*/
            i[4]
          )
        )
      ), R(
        e,
        "--start-top",
        /*preexpansionBoundingRect*/
        i[24] ? `${/*preexpansionBoundingRect*/
        i[24].top}px` : "0px"
      ), R(
        e,
        "--start-left",
        /*preexpansionBoundingRect*/
        i[24] ? `${/*preexpansionBoundingRect*/
        i[24].left}px` : "0px"
      ), R(
        e,
        "--start-width",
        /*preexpansionBoundingRect*/
        i[24] ? `${/*preexpansionBoundingRect*/
        i[24].width}px` : "0px"
      ), R(
        e,
        "--start-height",
        /*preexpansionBoundingRect*/
        i[24] ? `${/*preexpansionBoundingRect*/
        i[24].height}px` : "0px"
      ), R(
        e,
        "width",
        /*fullscreen*/
        i[0] ? void 0 : typeof /*width*/
        i[5] == "number" ? `calc(min(${/*width*/
        i[5]}px, 100%))` : (
          /*get_dimension*/
          i[26](
            /*width*/
            i[5]
          )
        )
      ), R(
        e,
        "border-style",
        /*variant*/
        i[8]
      ), R(
        e,
        "overflow",
        /*allow_overflow*/
        i[15] ? (
          /*overflow_behavior*/
          i[16]
        ) : "hidden"
      ), R(
        e,
        "flex-grow",
        /*scale*/
        i[17]
      ), R(e, "min-width", `calc(min(${/*min_width*/
      i[18]}px, 100%))`), R(e, "border-width", "var(--block-border-width)");
    },
    m(f, h) {
      zt(f, e, h), r && r.m(e, null), Zn(e, t), u && u.m(e, null), i[32](e), a = !0;
    },
    p(f, h) {
      var p;
      r && r.p && (!a || h[0] & /*$$scope*/
      1073741824) && so(
        r,
        o,
        f,
        /*$$scope*/
        f[30],
        a ? no(
          o,
          /*$$scope*/
          f[30],
          h,
          null
        ) : to(
          /*$$scope*/
          f[30]
        ),
        null
      ), /*resizable*/
      f[19] ? u ? u.p(f, h) : (u = mi(f), u.c(), u.m(e, null)) : u && (u.d(1), u = null), pi(
        /*tag*/
        f[25]
      )(e, s = io(c, [
        (!a || h[0] & /*test_id*/
        2048) && { "data-testid": (
          /*test_id*/
          f[11]
        ) },
        (!a || h[0] & /*elem_id*/
        64) && { id: (
          /*elem_id*/
          f[6]
        ) },
        (!a || h[0] & /*elem_classes*/
        128 && n !== (n = "block " + /*elem_classes*/
        (((p = f[7]) == null ? void 0 : p.join(" ")) || "") + " svelte-239wnu")) && { class: n },
        (!a || h[0] & /*rtl*/
        1048576 && l !== (l = /*rtl*/
        f[20] ? "rtl" : "ltr")) && { dir: l }
      ])), ne(
        e,
        "hidden",
        /*visible*/
        f[14] === !1
      ), ne(
        e,
        "padded",
        /*padding*/
        f[10]
      ), ne(
        e,
        "flex",
        /*flex*/
        f[1]
      ), ne(
        e,
        "border_focus",
        /*border_mode*/
        f[9] === "focus"
      ), ne(
        e,
        "border_contrast",
        /*border_mode*/
        f[9] === "contrast"
      ), ne(e, "hide-container", !/*explicit_call*/
      f[12] && !/*container*/
      f[13]), ne(
        e,
        "fullscreen",
        /*fullscreen*/
        f[0]
      ), ne(
        e,
        "animating",
        /*fullscreen*/
        f[0] && /*preexpansionBoundingRect*/
        f[24] !== null
      ), ne(
        e,
        "auto-margin",
        /*scale*/
        f[17] === null
      ), h[0] & /*fullscreen, height*/
      5 && R(
        e,
        "height",
        /*fullscreen*/
        f[0] ? void 0 : (
          /*get_dimension*/
          f[26](
            /*height*/
            f[2]
          )
        )
      ), h[0] & /*fullscreen, min_height*/
      9 && R(
        e,
        "min-height",
        /*fullscreen*/
        f[0] ? void 0 : (
          /*get_dimension*/
          f[26](
            /*min_height*/
            f[3]
          )
        )
      ), h[0] & /*fullscreen, max_height*/
      17 && R(
        e,
        "max-height",
        /*fullscreen*/
        f[0] ? void 0 : (
          /*get_dimension*/
          f[26](
            /*max_height*/
            f[4]
          )
        )
      ), h[0] & /*preexpansionBoundingRect*/
      16777216 && R(
        e,
        "--start-top",
        /*preexpansionBoundingRect*/
        f[24] ? `${/*preexpansionBoundingRect*/
        f[24].top}px` : "0px"
      ), h[0] & /*preexpansionBoundingRect*/
      16777216 && R(
        e,
        "--start-left",
        /*preexpansionBoundingRect*/
        f[24] ? `${/*preexpansionBoundingRect*/
        f[24].left}px` : "0px"
      ), h[0] & /*preexpansionBoundingRect*/
      16777216 && R(
        e,
        "--start-width",
        /*preexpansionBoundingRect*/
        f[24] ? `${/*preexpansionBoundingRect*/
        f[24].width}px` : "0px"
      ), h[0] & /*preexpansionBoundingRect*/
      16777216 && R(
        e,
        "--start-height",
        /*preexpansionBoundingRect*/
        f[24] ? `${/*preexpansionBoundingRect*/
        f[24].height}px` : "0px"
      ), h[0] & /*fullscreen, width*/
      33 && R(
        e,
        "width",
        /*fullscreen*/
        f[0] ? void 0 : typeof /*width*/
        f[5] == "number" ? `calc(min(${/*width*/
        f[5]}px, 100%))` : (
          /*get_dimension*/
          f[26](
            /*width*/
            f[5]
          )
        )
      ), h[0] & /*variant*/
      256 && R(
        e,
        "border-style",
        /*variant*/
        f[8]
      ), h[0] & /*allow_overflow, overflow_behavior*/
      98304 && R(
        e,
        "overflow",
        /*allow_overflow*/
        f[15] ? (
          /*overflow_behavior*/
          f[16]
        ) : "hidden"
      ), h[0] & /*scale*/
      131072 && R(
        e,
        "flex-grow",
        /*scale*/
        f[17]
      ), h[0] & /*min_width*/
      262144 && R(e, "min-width", `calc(min(${/*min_width*/
      f[18]}px, 100%))`);
    },
    i(f) {
      a || (Ol(r, f), a = !0);
    },
    o(f) {
      Nl(r, f), a = !1;
    },
    d(f) {
      f && Ie(e), r && r.d(f), u && u.d(), i[32](null);
    }
  };
}
function gi(i) {
  let e;
  return {
    c() {
      e = Ml("div"), this.h();
    },
    l(t) {
      e = zl(t, "DIV", { class: !0 }), Bt(e).forEach(Ie), this.h();
    },
    h() {
      ue(e, "class", "placeholder svelte-239wnu"), R(
        e,
        "height",
        /*placeholder_height*/
        i[22] + "px"
      ), R(
        e,
        "width",
        /*placeholder_width*/
        i[23] + "px"
      );
    },
    m(t, n) {
      zt(t, e, n);
    },
    p(t, n) {
      n[0] & /*placeholder_height*/
      4194304 && R(
        e,
        "height",
        /*placeholder_height*/
        t[22] + "px"
      ), n[0] & /*placeholder_width*/
      8388608 && R(
        e,
        "width",
        /*placeholder_width*/
        t[23] + "px"
      );
    },
    d(t) {
      t && Ie(e);
    }
  };
}
function co(i) {
  let e, t, n, l = (
    /*tag*/
    i[25] && uo(i)
  ), a = (
    /*fullscreen*/
    i[0] && gi(i)
  );
  return {
    c() {
      l && l.c(), e = Rl(), a && a.c(), t = hi();
    },
    l(o) {
      l && l.l(o), e = Il(o), a && a.l(o), t = hi();
    },
    m(o, r) {
      l && l.m(o, r), zt(o, e, r), a && a.m(o, r), zt(o, t, r), n = !0;
    },
    p(o, r) {
      /*tag*/
      o[25] && l.p(o, r), /*fullscreen*/
      o[0] ? a ? a.p(o, r) : (a = gi(o), a.c(), a.m(t.parentNode, t)) : a && (a.d(1), a = null);
    },
    i(o) {
      n || (Ol(l, o), n = !0);
    },
    o(o) {
      Nl(l, o), n = !1;
    },
    d(o) {
      o && (Ie(e), Ie(t)), l && l.d(o), a && a.d(o);
    }
  };
}
function _o(i, e, t) {
  let { $$slots: n = {}, $$scope: l } = e, { height: a = void 0 } = e, { min_height: o = void 0 } = e, { max_height: r = void 0 } = e, { width: u = void 0 } = e, { elem_id: c = "" } = e, { elem_classes: s = [] } = e, { variant: d = "solid" } = e, { border_mode: f = "base" } = e, { padding: h = !0 } = e, { type: p = "normal" } = e, { test_id: v = void 0 } = e, { explicit_call: k = !1 } = e, { container: C = !0 } = e, { visible: m = !0 } = e, { allow_overflow: _ = !0 } = e, { overflow_behavior: g = "auto" } = e, { scale: D = null } = e, { min_width: b = 0 } = e, { flex: w = !1 } = e, { resizable: E = !1 } = e, { rtl: y = !1 } = e, { fullscreen: B = !1 } = e, q = B, z, le = p === "fieldset" ? "fieldset" : "div", G = 0, N = 0, M = null;
  function V(A) {
    B && A.key === "Escape" && t(0, B = !1);
  }
  const P = (A) => {
    if (A !== void 0) {
      if (typeof A == "number")
        return A + "px";
      if (typeof A == "string")
        return A;
    }
  }, ee = (A) => {
    let Q = A.clientY;
    const qe = (x) => {
      const S = x.clientY - Q;
      Q = x.clientY, t(21, z.style.height = `${z.offsetHeight + S}px`, z);
    }, ae = () => {
      window.removeEventListener("mousemove", qe), window.removeEventListener("mouseup", ae);
    };
    window.addEventListener("mousemove", qe), window.addEventListener("mouseup", ae);
  };
  function K(A) {
    Ja[A ? "unshift" : "push"](() => {
      z = A, t(21, z);
    });
  }
  return i.$$set = (A) => {
    "height" in A && t(2, a = A.height), "min_height" in A && t(3, o = A.min_height), "max_height" in A && t(4, r = A.max_height), "width" in A && t(5, u = A.width), "elem_id" in A && t(6, c = A.elem_id), "elem_classes" in A && t(7, s = A.elem_classes), "variant" in A && t(8, d = A.variant), "border_mode" in A && t(9, f = A.border_mode), "padding" in A && t(10, h = A.padding), "type" in A && t(28, p = A.type), "test_id" in A && t(11, v = A.test_id), "explicit_call" in A && t(12, k = A.explicit_call), "container" in A && t(13, C = A.container), "visible" in A && t(14, m = A.visible), "allow_overflow" in A && t(15, _ = A.allow_overflow), "overflow_behavior" in A && t(16, g = A.overflow_behavior), "scale" in A && t(17, D = A.scale), "min_width" in A && t(18, b = A.min_width), "flex" in A && t(1, w = A.flex), "resizable" in A && t(19, E = A.resizable), "rtl" in A && t(20, y = A.rtl), "fullscreen" in A && t(0, B = A.fullscreen), "$$scope" in A && t(30, l = A.$$scope);
  }, i.$$.update = () => {
    i.$$.dirty[0] & /*fullscreen, old_fullscreen, element*/
    538968065 && B !== q && (t(29, q = B), B ? (t(24, M = z.getBoundingClientRect()), t(22, G = z.offsetHeight), t(23, N = z.offsetWidth), window.addEventListener("keydown", V)) : (t(24, M = null), window.removeEventListener("keydown", V))), i.$$.dirty[0] & /*visible*/
    16384 && (m || t(1, w = !1));
  }, [
    B,
    w,
    a,
    o,
    r,
    u,
    c,
    s,
    d,
    f,
    h,
    v,
    k,
    C,
    m,
    _,
    g,
    D,
    b,
    E,
    y,
    z,
    G,
    N,
    M,
    le,
    P,
    ee,
    p,
    q,
    l,
    n,
    K
  ];
}
class fo extends Ka {
  constructor(e) {
    super(), lo(
      this,
      e,
      _o,
      co,
      ro,
      {
        height: 2,
        min_height: 3,
        max_height: 4,
        width: 5,
        elem_id: 6,
        elem_classes: 7,
        variant: 8,
        border_mode: 9,
        padding: 10,
        type: 28,
        test_id: 11,
        explicit_call: 12,
        container: 13,
        visible: 14,
        allow_overflow: 15,
        overflow_behavior: 16,
        scale: 17,
        min_width: 18,
        flex: 1,
        resizable: 19,
        rtl: 20,
        fullscreen: 0
      },
      null,
      [-1, -1]
    );
  }
}
function ei() {
  return {
    async: !1,
    breaks: !1,
    extensions: null,
    gfm: !0,
    hooks: null,
    pedantic: !1,
    renderer: null,
    silent: !1,
    tokenizer: null,
    walkTokens: null
  };
}
let at = ei();
function Pl(i) {
  at = i;
}
const Hl = /[&<>"']/, ho = new RegExp(Hl.source, "g"), Zl = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, po = new RegExp(Zl.source, "g"), mo = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, bi = (i) => mo[i];
function me(i, e) {
  if (e) {
    if (Hl.test(i))
      return i.replace(ho, bi);
  } else if (Zl.test(i))
    return i.replace(po, bi);
  return i;
}
const go = /&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/ig;
function bo(i) {
  return i.replace(go, (e, t) => (t = t.toLowerCase(), t === "colon" ? ":" : t.charAt(0) === "#" ? t.charAt(1) === "x" ? String.fromCharCode(parseInt(t.substring(2), 16)) : String.fromCharCode(+t.substring(1)) : ""));
}
const vo = /(^|[^\[])\^/g;
function U(i, e) {
  let t = typeof i == "string" ? i : i.source;
  e = e || "";
  const n = {
    replace: (l, a) => {
      let o = typeof a == "string" ? a : a.source;
      return o = o.replace(vo, "$1"), t = t.replace(l, o), n;
    },
    getRegex: () => new RegExp(t, e)
  };
  return n;
}
function vi(i) {
  try {
    i = encodeURI(i).replace(/%25/g, "%");
  } catch {
    return null;
  }
  return i;
}
const xt = { exec: () => null };
function Di(i, e) {
  const t = i.replace(/\|/g, (a, o, r) => {
    let u = !1, c = o;
    for (; --c >= 0 && r[c] === "\\"; )
      u = !u;
    return u ? "|" : " |";
  }), n = t.split(/ \|/);
  let l = 0;
  if (n[0].trim() || n.shift(), n.length > 0 && !n[n.length - 1].trim() && n.pop(), e)
    if (n.length > e)
      n.splice(e);
    else
      for (; n.length < e; )
        n.push("");
  for (; l < n.length; l++)
    n[l] = n[l].trim().replace(/\\\|/g, "|");
  return n;
}
function Wt(i, e, t) {
  const n = i.length;
  if (n === 0)
    return "";
  let l = 0;
  for (; l < n && i.charAt(n - l - 1) === e; )
    l++;
  return i.slice(0, n - l);
}
function Do(i, e) {
  if (i.indexOf(e[1]) === -1)
    return -1;
  let t = 0;
  for (let n = 0; n < i.length; n++)
    if (i[n] === "\\")
      n++;
    else if (i[n] === e[0])
      t++;
    else if (i[n] === e[1] && (t--, t < 0))
      return n;
  return -1;
}
function wi(i, e, t, n) {
  const l = e.href, a = e.title ? me(e.title) : null, o = i[1].replace(/\\([\[\]])/g, "$1");
  if (i[0].charAt(0) !== "!") {
    n.state.inLink = !0;
    const r = {
      type: "link",
      raw: t,
      href: l,
      title: a,
      text: o,
      tokens: n.inlineTokens(o)
    };
    return n.state.inLink = !1, r;
  }
  return {
    type: "image",
    raw: t,
    href: l,
    title: a,
    text: me(o)
  };
}
function wo(i, e) {
  const t = i.match(/^(\s+)(?:```)/);
  if (t === null)
    return e;
  const n = t[1];
  return e.split(`
`).map((l) => {
    const a = l.match(/^\s+/);
    if (a === null)
      return l;
    const [o] = a;
    return o.length >= n.length ? l.slice(n.length) : l;
  }).join(`
`);
}
class pn {
  // set by the lexer
  constructor(e) {
    X(this, "options");
    X(this, "rules");
    // set by the lexer
    X(this, "lexer");
    this.options = e || at;
  }
  space(e) {
    const t = this.rules.block.newline.exec(e);
    if (t && t[0].length > 0)
      return {
        type: "space",
        raw: t[0]
      };
  }
  code(e) {
    const t = this.rules.block.code.exec(e);
    if (t) {
      const n = t[0].replace(/^ {1,4}/gm, "");
      return {
        type: "code",
        raw: t[0],
        codeBlockStyle: "indented",
        text: this.options.pedantic ? n : Wt(n, `
`)
      };
    }
  }
  fences(e) {
    const t = this.rules.block.fences.exec(e);
    if (t) {
      const n = t[0], l = wo(n, t[3] || "");
      return {
        type: "code",
        raw: n,
        lang: t[2] ? t[2].trim().replace(this.rules.inline.anyPunctuation, "$1") : t[2],
        text: l
      };
    }
  }
  heading(e) {
    const t = this.rules.block.heading.exec(e);
    if (t) {
      let n = t[2].trim();
      if (/#$/.test(n)) {
        const l = Wt(n, "#");
        (this.options.pedantic || !l || / $/.test(l)) && (n = l.trim());
      }
      return {
        type: "heading",
        raw: t[0],
        depth: t[1].length,
        text: n,
        tokens: this.lexer.inline(n)
      };
    }
  }
  hr(e) {
    const t = this.rules.block.hr.exec(e);
    if (t)
      return {
        type: "hr",
        raw: t[0]
      };
  }
  blockquote(e) {
    const t = this.rules.block.blockquote.exec(e);
    if (t) {
      let n = t[0].replace(/\n {0,3}((?:=+|-+) *)(?=\n|$)/g, `
    $1`);
      n = Wt(n.replace(/^ *>[ \t]?/gm, ""), `
`);
      const l = this.lexer.state.top;
      this.lexer.state.top = !0;
      const a = this.lexer.blockTokens(n);
      return this.lexer.state.top = l, {
        type: "blockquote",
        raw: t[0],
        tokens: a,
        text: n
      };
    }
  }
  list(e) {
    let t = this.rules.block.list.exec(e);
    if (t) {
      let n = t[1].trim();
      const l = n.length > 1, a = {
        type: "list",
        raw: "",
        ordered: l,
        start: l ? +n.slice(0, -1) : "",
        loose: !1,
        items: []
      };
      n = l ? `\\d{1,9}\\${n.slice(-1)}` : `\\${n}`, this.options.pedantic && (n = l ? n : "[*+-]");
      const o = new RegExp(`^( {0,3}${n})((?:[	 ][^\\n]*)?(?:\\n|$))`);
      let r = "", u = "", c = !1;
      for (; e; ) {
        let s = !1;
        if (!(t = o.exec(e)) || this.rules.block.hr.test(e))
          break;
        r = t[0], e = e.substring(r.length);
        let d = t[2].split(`
`, 1)[0].replace(/^\t+/, (C) => " ".repeat(3 * C.length)), f = e.split(`
`, 1)[0], h = 0;
        this.options.pedantic ? (h = 2, u = d.trimStart()) : (h = t[2].search(/[^ ]/), h = h > 4 ? 1 : h, u = d.slice(h), h += t[1].length);
        let p = !1;
        if (!d && /^ *$/.test(f) && (r += f + `
`, e = e.substring(f.length + 1), s = !0), !s) {
          const C = new RegExp(`^ {0,${Math.min(3, h - 1)}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`), m = new RegExp(`^ {0,${Math.min(3, h - 1)}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)`), _ = new RegExp(`^ {0,${Math.min(3, h - 1)}}(?:\`\`\`|~~~)`), g = new RegExp(`^ {0,${Math.min(3, h - 1)}}#`);
          for (; e; ) {
            const D = e.split(`
`, 1)[0];
            if (f = D, this.options.pedantic && (f = f.replace(/^ {1,4}(?=( {4})*[^ ])/g, "  ")), _.test(f) || g.test(f) || C.test(f) || m.test(e))
              break;
            if (f.search(/[^ ]/) >= h || !f.trim())
              u += `
` + f.slice(h);
            else {
              if (p || d.search(/[^ ]/) >= 4 || _.test(d) || g.test(d) || m.test(d))
                break;
              u += `
` + f;
            }
            !p && !f.trim() && (p = !0), r += D + `
`, e = e.substring(D.length + 1), d = f.slice(h);
          }
        }
        a.loose || (c ? a.loose = !0 : /\n *\n *$/.test(r) && (c = !0));
        let v = null, k;
        this.options.gfm && (v = /^\[[ xX]\] /.exec(u), v && (k = v[0] !== "[ ] ", u = u.replace(/^\[[ xX]\] +/, ""))), a.items.push({
          type: "list_item",
          raw: r,
          task: !!v,
          checked: k,
          loose: !1,
          text: u,
          tokens: []
        }), a.raw += r;
      }
      a.items[a.items.length - 1].raw = r.trimEnd(), a.items[a.items.length - 1].text = u.trimEnd(), a.raw = a.raw.trimEnd();
      for (let s = 0; s < a.items.length; s++)
        if (this.lexer.state.top = !1, a.items[s].tokens = this.lexer.blockTokens(a.items[s].text, []), !a.loose) {
          const d = a.items[s].tokens.filter((h) => h.type === "space"), f = d.length > 0 && d.some((h) => /\n.*\n/.test(h.raw));
          a.loose = f;
        }
      if (a.loose)
        for (let s = 0; s < a.items.length; s++)
          a.items[s].loose = !0;
      return a;
    }
  }
  html(e) {
    const t = this.rules.block.html.exec(e);
    if (t)
      return {
        type: "html",
        block: !0,
        raw: t[0],
        pre: t[1] === "pre" || t[1] === "script" || t[1] === "style",
        text: t[0]
      };
  }
  def(e) {
    const t = this.rules.block.def.exec(e);
    if (t) {
      const n = t[1].toLowerCase().replace(/\s+/g, " "), l = t[2] ? t[2].replace(/^<(.*)>$/, "$1").replace(this.rules.inline.anyPunctuation, "$1") : "", a = t[3] ? t[3].substring(1, t[3].length - 1).replace(this.rules.inline.anyPunctuation, "$1") : t[3];
      return {
        type: "def",
        tag: n,
        raw: t[0],
        href: l,
        title: a
      };
    }
  }
  table(e) {
    const t = this.rules.block.table.exec(e);
    if (!t || !/[:|]/.test(t[2]))
      return;
    const n = Di(t[1]), l = t[2].replace(/^\||\| *$/g, "").split("|"), a = t[3] && t[3].trim() ? t[3].replace(/\n[ \t]*$/, "").split(`
`) : [], o = {
      type: "table",
      raw: t[0],
      header: [],
      align: [],
      rows: []
    };
    if (n.length === l.length) {
      for (const r of l)
        /^ *-+: *$/.test(r) ? o.align.push("right") : /^ *:-+: *$/.test(r) ? o.align.push("center") : /^ *:-+ *$/.test(r) ? o.align.push("left") : o.align.push(null);
      for (const r of n)
        o.header.push({
          text: r,
          tokens: this.lexer.inline(r)
        });
      for (const r of a)
        o.rows.push(Di(r, o.header.length).map((u) => ({
          text: u,
          tokens: this.lexer.inline(u)
        })));
      return o;
    }
  }
  lheading(e) {
    const t = this.rules.block.lheading.exec(e);
    if (t)
      return {
        type: "heading",
        raw: t[0],
        depth: t[2].charAt(0) === "=" ? 1 : 2,
        text: t[1],
        tokens: this.lexer.inline(t[1])
      };
  }
  paragraph(e) {
    const t = this.rules.block.paragraph.exec(e);
    if (t) {
      const n = t[1].charAt(t[1].length - 1) === `
` ? t[1].slice(0, -1) : t[1];
      return {
        type: "paragraph",
        raw: t[0],
        text: n,
        tokens: this.lexer.inline(n)
      };
    }
  }
  text(e) {
    const t = this.rules.block.text.exec(e);
    if (t)
      return {
        type: "text",
        raw: t[0],
        text: t[0],
        tokens: this.lexer.inline(t[0])
      };
  }
  escape(e) {
    const t = this.rules.inline.escape.exec(e);
    if (t)
      return {
        type: "escape",
        raw: t[0],
        text: me(t[1])
      };
  }
  tag(e) {
    const t = this.rules.inline.tag.exec(e);
    if (t)
      return !this.lexer.state.inLink && /^<a /i.test(t[0]) ? this.lexer.state.inLink = !0 : this.lexer.state.inLink && /^<\/a>/i.test(t[0]) && (this.lexer.state.inLink = !1), !this.lexer.state.inRawBlock && /^<(pre|code|kbd|script)(\s|>)/i.test(t[0]) ? this.lexer.state.inRawBlock = !0 : this.lexer.state.inRawBlock && /^<\/(pre|code|kbd|script)(\s|>)/i.test(t[0]) && (this.lexer.state.inRawBlock = !1), {
        type: "html",
        raw: t[0],
        inLink: this.lexer.state.inLink,
        inRawBlock: this.lexer.state.inRawBlock,
        block: !1,
        text: t[0]
      };
  }
  link(e) {
    const t = this.rules.inline.link.exec(e);
    if (t) {
      const n = t[2].trim();
      if (!this.options.pedantic && /^</.test(n)) {
        if (!/>$/.test(n))
          return;
        const o = Wt(n.slice(0, -1), "\\");
        if ((n.length - o.length) % 2 === 0)
          return;
      } else {
        const o = Do(t[2], "()");
        if (o > -1) {
          const u = (t[0].indexOf("!") === 0 ? 5 : 4) + t[1].length + o;
          t[2] = t[2].substring(0, o), t[0] = t[0].substring(0, u).trim(), t[3] = "";
        }
      }
      let l = t[2], a = "";
      if (this.options.pedantic) {
        const o = /^([^'"]*[^\s])\s+(['"])(.*)\2/.exec(l);
        o && (l = o[1], a = o[3]);
      } else
        a = t[3] ? t[3].slice(1, -1) : "";
      return l = l.trim(), /^</.test(l) && (this.options.pedantic && !/>$/.test(n) ? l = l.slice(1) : l = l.slice(1, -1)), wi(t, {
        href: l && l.replace(this.rules.inline.anyPunctuation, "$1"),
        title: a && a.replace(this.rules.inline.anyPunctuation, "$1")
      }, t[0], this.lexer);
    }
  }
  reflink(e, t) {
    let n;
    if ((n = this.rules.inline.reflink.exec(e)) || (n = this.rules.inline.nolink.exec(e))) {
      const l = (n[2] || n[1]).replace(/\s+/g, " "), a = t[l.toLowerCase()];
      if (!a) {
        const o = n[0].charAt(0);
        return {
          type: "text",
          raw: o,
          text: o
        };
      }
      return wi(n, a, n[0], this.lexer);
    }
  }
  emStrong(e, t, n = "") {
    let l = this.rules.inline.emStrongLDelim.exec(e);
    if (!l || l[3] && n.match(/[\p{L}\p{N}]/u))
      return;
    if (!(l[1] || l[2] || "") || !n || this.rules.inline.punctuation.exec(n)) {
      const o = [...l[0]].length - 1;
      let r, u, c = o, s = 0;
      const d = l[0][0] === "*" ? this.rules.inline.emStrongRDelimAst : this.rules.inline.emStrongRDelimUnd;
      for (d.lastIndex = 0, t = t.slice(-1 * e.length + o); (l = d.exec(t)) != null; ) {
        if (r = l[1] || l[2] || l[3] || l[4] || l[5] || l[6], !r)
          continue;
        if (u = [...r].length, l[3] || l[4]) {
          c += u;
          continue;
        } else if ((l[5] || l[6]) && o % 3 && !((o + u) % 3)) {
          s += u;
          continue;
        }
        if (c -= u, c > 0)
          continue;
        u = Math.min(u, u + c + s);
        const f = [...l[0]][0].length, h = e.slice(0, o + l.index + f + u);
        if (Math.min(o, u) % 2) {
          const v = h.slice(1, -1);
          return {
            type: "em",
            raw: h,
            text: v,
            tokens: this.lexer.inlineTokens(v)
          };
        }
        const p = h.slice(2, -2);
        return {
          type: "strong",
          raw: h,
          text: p,
          tokens: this.lexer.inlineTokens(p)
        };
      }
    }
  }
  codespan(e) {
    const t = this.rules.inline.code.exec(e);
    if (t) {
      let n = t[2].replace(/\n/g, " ");
      const l = /[^ ]/.test(n), a = /^ /.test(n) && / $/.test(n);
      return l && a && (n = n.substring(1, n.length - 1)), n = me(n, !0), {
        type: "codespan",
        raw: t[0],
        text: n
      };
    }
  }
  br(e) {
    const t = this.rules.inline.br.exec(e);
    if (t)
      return {
        type: "br",
        raw: t[0]
      };
  }
  del(e) {
    const t = this.rules.inline.del.exec(e);
    if (t)
      return {
        type: "del",
        raw: t[0],
        text: t[2],
        tokens: this.lexer.inlineTokens(t[2])
      };
  }
  autolink(e) {
    const t = this.rules.inline.autolink.exec(e);
    if (t) {
      let n, l;
      return t[2] === "@" ? (n = me(t[1]), l = "mailto:" + n) : (n = me(t[1]), l = n), {
        type: "link",
        raw: t[0],
        text: n,
        href: l,
        tokens: [
          {
            type: "text",
            raw: n,
            text: n
          }
        ]
      };
    }
  }
  url(e) {
    var n;
    let t;
    if (t = this.rules.inline.url.exec(e)) {
      let l, a;
      if (t[2] === "@")
        l = me(t[0]), a = "mailto:" + l;
      else {
        let o;
        do
          o = t[0], t[0] = ((n = this.rules.inline._backpedal.exec(t[0])) == null ? void 0 : n[0]) ?? "";
        while (o !== t[0]);
        l = me(t[0]), t[1] === "www." ? a = "http://" + t[0] : a = t[0];
      }
      return {
        type: "link",
        raw: t[0],
        text: l,
        href: a,
        tokens: [
          {
            type: "text",
            raw: l,
            text: l
          }
        ]
      };
    }
  }
  inlineText(e) {
    const t = this.rules.inline.text.exec(e);
    if (t) {
      let n;
      return this.lexer.state.inRawBlock ? n = t[0] : n = me(t[0]), {
        type: "text",
        raw: t[0],
        text: n
      };
    }
  }
}
const yo = /^(?: *(?:\n|$))+/, ko = /^( {4}[^\n]+(?:\n(?: *(?:\n|$))*)?)+/, Fo = /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/, It = /^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/, $o = /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/, jl = /(?:[*+-]|\d{1,9}[.)])/, Ul = U(/^(?!bull |blockCode|fences|blockquote|heading|html)((?:.|\n(?!\s*?\n|bull |blockCode|fences|blockquote|heading|html))+?)\n {0,3}(=+|-+) *(?:\n+|$)/).replace(/bull/g, jl).replace(/blockCode/g, / {4}/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).getRegex(), ti = /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/, Co = /^[^\n]+/, ni = /(?!\s*\])(?:\\.|[^\[\]\\])+/, Eo = U(/^ {0,3}\[(label)\]: *(?:\n *)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n *)?| *\n *)(title))? *(?:\n+|$)/).replace("label", ni).replace("title", /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/).getRegex(), Ao = U(/^( {0,3}bull)([ \t][^\n]+?)?(?:\n|$)/).replace(/bull/g, jl).getRegex(), Dn = "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul", ii = /<!--(?:-?>|[\s\S]*?(?:-->|$))/, So = U("^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>\\n*|$)|<![A-Z][\\s\\S]*?(?:>\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n *)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$))", "i").replace("comment", ii).replace("tag", Dn).replace("attribute", / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex(), Gl = U(ti).replace("hr", It).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("|table", "").replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Dn).getRegex(), Bo = U(/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/).replace("paragraph", Gl).getRegex(), li = {
  blockquote: Bo,
  code: ko,
  def: Eo,
  fences: Fo,
  heading: $o,
  hr: It,
  html: So,
  lheading: Ul,
  list: Ao,
  newline: yo,
  paragraph: Gl,
  table: xt,
  text: Co
}, yi = U("^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)").replace("hr", It).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("blockquote", " {0,3}>").replace("code", " {4}[^\\n]").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Dn).getRegex(), xo = {
  ...li,
  table: yi,
  paragraph: U(ti).replace("hr", It).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("table", yi).replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", Dn).getRegex()
}, To = {
  ...li,
  html: U(`^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`).replace("comment", ii).replace(/tag/g, "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(),
  def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/,
  heading: /^(#{1,6})(.*)(?:\n+|$)/,
  fences: xt,
  // fences not supported
  lheading: /^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/,
  paragraph: U(ti).replace("hr", It).replace("heading", ` *#{1,6} *[^
]`).replace("lheading", Ul).replace("|table", "").replace("blockquote", " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html", "").replace("|tag", "").getRegex()
}, Vl = /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/, qo = /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/, Xl = /^( {2,}|\\)\n(?!\s*$)/, Lo = /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/, Mt = "\\p{P}\\p{S}", zo = U(/^((?![*_])[\spunctuation])/, "u").replace(/punctuation/g, Mt).getRegex(), Io = /\[[^[\]]*?\]\([^\(\)]*?\)|`[^`]*?`|<[^<>]*?>/g, Mo = U(/^(?:\*+(?:((?!\*)[punct])|[^\s*]))|^_+(?:((?!_)[punct])|([^\s_]))/, "u").replace(/punct/g, Mt).getRegex(), Ro = U("^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)[punct](\\*+)(?=[\\s]|$)|[^punct\\s](\\*+)(?!\\*)(?=[punct\\s]|$)|(?!\\*)[punct\\s](\\*+)(?=[^punct\\s])|[\\s](\\*+)(?!\\*)(?=[punct])|(?!\\*)[punct](\\*+)(?!\\*)(?=[punct])|[^punct\\s](\\*+)(?=[^punct\\s])", "gu").replace(/punct/g, Mt).getRegex(), Oo = U("^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)[punct](_+)(?=[\\s]|$)|[^punct\\s](_+)(?!_)(?=[punct\\s]|$)|(?!_)[punct\\s](_+)(?=[^punct\\s])|[\\s](_+)(?!_)(?=[punct])|(?!_)[punct](_+)(?!_)(?=[punct])", "gu").replace(/punct/g, Mt).getRegex(), No = U(/\\([punct])/, "gu").replace(/punct/g, Mt).getRegex(), Po = U(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/).replace("scheme", /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/).replace("email", /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/).getRegex(), Ho = U(ii).replace("(?:-->|$)", "-->").getRegex(), Zo = U("^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>").replace("comment", Ho).replace("attribute", /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/).getRegex(), mn = /(?:\[(?:\\.|[^\[\]\\])*\]|\\.|`[^`]*`|[^\[\]\\`])*?/, jo = U(/^!?\[(label)\]\(\s*(href)(?:\s+(title))?\s*\)/).replace("label", mn).replace("href", /<(?:\\.|[^\n<>\\])+>|[^\s\x00-\x1f]*/).replace("title", /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/).getRegex(), Wl = U(/^!?\[(label)\]\[(ref)\]/).replace("label", mn).replace("ref", ni).getRegex(), Yl = U(/^!?\[(ref)\](?:\[\])?/).replace("ref", ni).getRegex(), Uo = U("reflink|nolink(?!\\()", "g").replace("reflink", Wl).replace("nolink", Yl).getRegex(), ai = {
  _backpedal: xt,
  // only used for GFM url
  anyPunctuation: No,
  autolink: Po,
  blockSkip: Io,
  br: Xl,
  code: qo,
  del: xt,
  emStrongLDelim: Mo,
  emStrongRDelimAst: Ro,
  emStrongRDelimUnd: Oo,
  escape: Vl,
  link: jo,
  nolink: Yl,
  punctuation: zo,
  reflink: Wl,
  reflinkSearch: Uo,
  tag: Zo,
  text: Lo,
  url: xt
}, Go = {
  ...ai,
  link: U(/^!?\[(label)\]\((.*?)\)/).replace("label", mn).getRegex(),
  reflink: U(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", mn).getRegex()
}, jn = {
  ...ai,
  escape: U(Vl).replace("])", "~|])").getRegex(),
  url: U(/^((?:ftp|https?):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/, "i").replace("email", /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/).getRegex(),
  _backpedal: /(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/,
  del: /^(~~?)(?=[^\s~])([\s\S]*?[^\s~])\1(?=[^~]|$)/,
  text: /^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|https?:\/\/|ftp:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/
}, Vo = {
  ...jn,
  br: U(Xl).replace("{2,}", "*").getRegex(),
  text: U(jn.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex()
}, Yt = {
  normal: li,
  gfm: xo,
  pedantic: To
}, Ft = {
  normal: ai,
  gfm: jn,
  breaks: Vo,
  pedantic: Go
};
class Me {
  constructor(e) {
    X(this, "tokens");
    X(this, "options");
    X(this, "state");
    X(this, "tokenizer");
    X(this, "inlineQueue");
    this.tokens = [], this.tokens.links = /* @__PURE__ */ Object.create(null), this.options = e || at, this.options.tokenizer = this.options.tokenizer || new pn(), this.tokenizer = this.options.tokenizer, this.tokenizer.options = this.options, this.tokenizer.lexer = this, this.inlineQueue = [], this.state = {
      inLink: !1,
      inRawBlock: !1,
      top: !0
    };
    const t = {
      block: Yt.normal,
      inline: Ft.normal
    };
    this.options.pedantic ? (t.block = Yt.pedantic, t.inline = Ft.pedantic) : this.options.gfm && (t.block = Yt.gfm, this.options.breaks ? t.inline = Ft.breaks : t.inline = Ft.gfm), this.tokenizer.rules = t;
  }
  /**
   * Expose Rules
   */
  static get rules() {
    return {
      block: Yt,
      inline: Ft
    };
  }
  /**
   * Static Lex Method
   */
  static lex(e, t) {
    return new Me(t).lex(e);
  }
  /**
   * Static Lex Inline Method
   */
  static lexInline(e, t) {
    return new Me(t).inlineTokens(e);
  }
  /**
   * Preprocessing
   */
  lex(e) {
    e = e.replace(/\r\n|\r/g, `
`), this.blockTokens(e, this.tokens);
    for (let t = 0; t < this.inlineQueue.length; t++) {
      const n = this.inlineQueue[t];
      this.inlineTokens(n.src, n.tokens);
    }
    return this.inlineQueue = [], this.tokens;
  }
  blockTokens(e, t = []) {
    this.options.pedantic ? e = e.replace(/\t/g, "    ").replace(/^ +$/gm, "") : e = e.replace(/^( *)(\t+)/gm, (r, u, c) => u + "    ".repeat(c.length));
    let n, l, a, o;
    for (; e; )
      if (!(this.options.extensions && this.options.extensions.block && this.options.extensions.block.some((r) => (n = r.call({ lexer: this }, e, t)) ? (e = e.substring(n.raw.length), t.push(n), !0) : !1))) {
        if (n = this.tokenizer.space(e)) {
          e = e.substring(n.raw.length), n.raw.length === 1 && t.length > 0 ? t[t.length - 1].raw += `
` : t.push(n);
          continue;
        }
        if (n = this.tokenizer.code(e)) {
          e = e.substring(n.raw.length), l = t[t.length - 1], l && (l.type === "paragraph" || l.type === "text") ? (l.raw += `
` + n.raw, l.text += `
` + n.text, this.inlineQueue[this.inlineQueue.length - 1].src = l.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.fences(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.heading(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.hr(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.blockquote(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.list(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.html(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.def(e)) {
          e = e.substring(n.raw.length), l = t[t.length - 1], l && (l.type === "paragraph" || l.type === "text") ? (l.raw += `
` + n.raw, l.text += `
` + n.raw, this.inlineQueue[this.inlineQueue.length - 1].src = l.text) : this.tokens.links[n.tag] || (this.tokens.links[n.tag] = {
            href: n.href,
            title: n.title
          });
          continue;
        }
        if (n = this.tokenizer.table(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.lheading(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (a = e, this.options.extensions && this.options.extensions.startBlock) {
          let r = 1 / 0;
          const u = e.slice(1);
          let c;
          this.options.extensions.startBlock.forEach((s) => {
            c = s.call({ lexer: this }, u), typeof c == "number" && c >= 0 && (r = Math.min(r, c));
          }), r < 1 / 0 && r >= 0 && (a = e.substring(0, r + 1));
        }
        if (this.state.top && (n = this.tokenizer.paragraph(a))) {
          l = t[t.length - 1], o && l.type === "paragraph" ? (l.raw += `
` + n.raw, l.text += `
` + n.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = l.text) : t.push(n), o = a.length !== e.length, e = e.substring(n.raw.length);
          continue;
        }
        if (n = this.tokenizer.text(e)) {
          e = e.substring(n.raw.length), l = t[t.length - 1], l && l.type === "text" ? (l.raw += `
` + n.raw, l.text += `
` + n.text, this.inlineQueue.pop(), this.inlineQueue[this.inlineQueue.length - 1].src = l.text) : t.push(n);
          continue;
        }
        if (e) {
          const r = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(r);
            break;
          } else
            throw new Error(r);
        }
      }
    return this.state.top = !0, t;
  }
  inline(e, t = []) {
    return this.inlineQueue.push({ src: e, tokens: t }), t;
  }
  /**
   * Lexing/Compiling
   */
  inlineTokens(e, t = []) {
    let n, l, a, o = e, r, u, c;
    if (this.tokens.links) {
      const s = Object.keys(this.tokens.links);
      if (s.length > 0)
        for (; (r = this.tokenizer.rules.inline.reflinkSearch.exec(o)) != null; )
          s.includes(r[0].slice(r[0].lastIndexOf("[") + 1, -1)) && (o = o.slice(0, r.index) + "[" + "a".repeat(r[0].length - 2) + "]" + o.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex));
    }
    for (; (r = this.tokenizer.rules.inline.blockSkip.exec(o)) != null; )
      o = o.slice(0, r.index) + "[" + "a".repeat(r[0].length - 2) + "]" + o.slice(this.tokenizer.rules.inline.blockSkip.lastIndex);
    for (; (r = this.tokenizer.rules.inline.anyPunctuation.exec(o)) != null; )
      o = o.slice(0, r.index) + "++" + o.slice(this.tokenizer.rules.inline.anyPunctuation.lastIndex);
    for (; e; )
      if (u || (c = ""), u = !1, !(this.options.extensions && this.options.extensions.inline && this.options.extensions.inline.some((s) => (n = s.call({ lexer: this }, e, t)) ? (e = e.substring(n.raw.length), t.push(n), !0) : !1))) {
        if (n = this.tokenizer.escape(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.tag(e)) {
          e = e.substring(n.raw.length), l = t[t.length - 1], l && n.type === "text" && l.type === "text" ? (l.raw += n.raw, l.text += n.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.link(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.reflink(e, this.tokens.links)) {
          e = e.substring(n.raw.length), l = t[t.length - 1], l && n.type === "text" && l.type === "text" ? (l.raw += n.raw, l.text += n.text) : t.push(n);
          continue;
        }
        if (n = this.tokenizer.emStrong(e, o, c)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.codespan(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.br(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.del(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (n = this.tokenizer.autolink(e)) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (!this.state.inLink && (n = this.tokenizer.url(e))) {
          e = e.substring(n.raw.length), t.push(n);
          continue;
        }
        if (a = e, this.options.extensions && this.options.extensions.startInline) {
          let s = 1 / 0;
          const d = e.slice(1);
          let f;
          this.options.extensions.startInline.forEach((h) => {
            f = h.call({ lexer: this }, d), typeof f == "number" && f >= 0 && (s = Math.min(s, f));
          }), s < 1 / 0 && s >= 0 && (a = e.substring(0, s + 1));
        }
        if (n = this.tokenizer.inlineText(a)) {
          e = e.substring(n.raw.length), n.raw.slice(-1) !== "_" && (c = n.raw.slice(-1)), u = !0, l = t[t.length - 1], l && l.type === "text" ? (l.raw += n.raw, l.text += n.text) : t.push(n);
          continue;
        }
        if (e) {
          const s = "Infinite loop on byte: " + e.charCodeAt(0);
          if (this.options.silent) {
            console.error(s);
            break;
          } else
            throw new Error(s);
        }
      }
    return t;
  }
}
class gn {
  constructor(e) {
    X(this, "options");
    this.options = e || at;
  }
  code(e, t, n) {
    var a;
    const l = (a = (t || "").match(/^\S*/)) == null ? void 0 : a[0];
    return e = e.replace(/\n$/, "") + `
`, l ? '<pre><code class="language-' + me(l) + '">' + (n ? e : me(e, !0)) + `</code></pre>
` : "<pre><code>" + (n ? e : me(e, !0)) + `</code></pre>
`;
  }
  blockquote(e) {
    return `<blockquote>
${e}</blockquote>
`;
  }
  html(e, t) {
    return e;
  }
  heading(e, t, n) {
    return `<h${t}>${e}</h${t}>
`;
  }
  hr() {
    return `<hr>
`;
  }
  list(e, t, n) {
    const l = t ? "ol" : "ul", a = t && n !== 1 ? ' start="' + n + '"' : "";
    return "<" + l + a + `>
` + e + "</" + l + `>
`;
  }
  listitem(e, t, n) {
    return `<li>${e}</li>
`;
  }
  checkbox(e) {
    return "<input " + (e ? 'checked="" ' : "") + 'disabled="" type="checkbox">';
  }
  paragraph(e) {
    return `<p>${e}</p>
`;
  }
  table(e, t) {
    return t && (t = `<tbody>${t}</tbody>`), `<table>
<thead>
` + e + `</thead>
` + t + `</table>
`;
  }
  tablerow(e) {
    return `<tr>
${e}</tr>
`;
  }
  tablecell(e, t) {
    const n = t.header ? "th" : "td";
    return (t.align ? `<${n} align="${t.align}">` : `<${n}>`) + e + `</${n}>
`;
  }
  /**
   * span level renderer
   */
  strong(e) {
    return `<strong>${e}</strong>`;
  }
  em(e) {
    return `<em>${e}</em>`;
  }
  codespan(e) {
    return `<code>${e}</code>`;
  }
  br() {
    return "<br>";
  }
  del(e) {
    return `<del>${e}</del>`;
  }
  link(e, t, n) {
    const l = vi(e);
    if (l === null)
      return n;
    e = l;
    let a = '<a href="' + e + '"';
    return t && (a += ' title="' + t + '"'), a += ">" + n + "</a>", a;
  }
  image(e, t, n) {
    const l = vi(e);
    if (l === null)
      return n;
    e = l;
    let a = `<img src="${e}" alt="${n}"`;
    return t && (a += ` title="${t}"`), a += ">", a;
  }
  text(e) {
    return e;
  }
}
class oi {
  // no need for block level renderers
  strong(e) {
    return e;
  }
  em(e) {
    return e;
  }
  codespan(e) {
    return e;
  }
  del(e) {
    return e;
  }
  html(e) {
    return e;
  }
  text(e) {
    return e;
  }
  link(e, t, n) {
    return "" + n;
  }
  image(e, t, n) {
    return "" + n;
  }
  br() {
    return "";
  }
}
class Re {
  constructor(e) {
    X(this, "options");
    X(this, "renderer");
    X(this, "textRenderer");
    this.options = e || at, this.options.renderer = this.options.renderer || new gn(), this.renderer = this.options.renderer, this.renderer.options = this.options, this.textRenderer = new oi();
  }
  /**
   * Static Parse Method
   */
  static parse(e, t) {
    return new Re(t).parse(e);
  }
  /**
   * Static Parse Inline Method
   */
  static parseInline(e, t) {
    return new Re(t).parseInline(e);
  }
  /**
   * Parse Loop
   */
  parse(e, t = !0) {
    let n = "";
    for (let l = 0; l < e.length; l++) {
      const a = e[l];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[a.type]) {
        const o = a, r = this.options.extensions.renderers[o.type].call({ parser: this }, o);
        if (r !== !1 || !["space", "hr", "heading", "code", "table", "blockquote", "list", "html", "paragraph", "text"].includes(o.type)) {
          n += r || "";
          continue;
        }
      }
      switch (a.type) {
        case "space":
          continue;
        case "hr": {
          n += this.renderer.hr();
          continue;
        }
        case "heading": {
          const o = a;
          n += this.renderer.heading(this.parseInline(o.tokens), o.depth, bo(this.parseInline(o.tokens, this.textRenderer)));
          continue;
        }
        case "code": {
          const o = a;
          n += this.renderer.code(o.text, o.lang, !!o.escaped);
          continue;
        }
        case "table": {
          const o = a;
          let r = "", u = "";
          for (let s = 0; s < o.header.length; s++)
            u += this.renderer.tablecell(this.parseInline(o.header[s].tokens), { header: !0, align: o.align[s] });
          r += this.renderer.tablerow(u);
          let c = "";
          for (let s = 0; s < o.rows.length; s++) {
            const d = o.rows[s];
            u = "";
            for (let f = 0; f < d.length; f++)
              u += this.renderer.tablecell(this.parseInline(d[f].tokens), { header: !1, align: o.align[f] });
            c += this.renderer.tablerow(u);
          }
          n += this.renderer.table(r, c);
          continue;
        }
        case "blockquote": {
          const o = a, r = this.parse(o.tokens);
          n += this.renderer.blockquote(r);
          continue;
        }
        case "list": {
          const o = a, r = o.ordered, u = o.start, c = o.loose;
          let s = "";
          for (let d = 0; d < o.items.length; d++) {
            const f = o.items[d], h = f.checked, p = f.task;
            let v = "";
            if (f.task) {
              const k = this.renderer.checkbox(!!h);
              c ? f.tokens.length > 0 && f.tokens[0].type === "paragraph" ? (f.tokens[0].text = k + " " + f.tokens[0].text, f.tokens[0].tokens && f.tokens[0].tokens.length > 0 && f.tokens[0].tokens[0].type === "text" && (f.tokens[0].tokens[0].text = k + " " + f.tokens[0].tokens[0].text)) : f.tokens.unshift({
                type: "text",
                text: k + " "
              }) : v += k + " ";
            }
            v += this.parse(f.tokens, c), s += this.renderer.listitem(v, p, !!h);
          }
          n += this.renderer.list(s, r, u);
          continue;
        }
        case "html": {
          const o = a;
          n += this.renderer.html(o.text, o.block);
          continue;
        }
        case "paragraph": {
          const o = a;
          n += this.renderer.paragraph(this.parseInline(o.tokens));
          continue;
        }
        case "text": {
          let o = a, r = o.tokens ? this.parseInline(o.tokens) : o.text;
          for (; l + 1 < e.length && e[l + 1].type === "text"; )
            o = e[++l], r += `
` + (o.tokens ? this.parseInline(o.tokens) : o.text);
          n += t ? this.renderer.paragraph(r) : r;
          continue;
        }
        default: {
          const o = 'Token with "' + a.type + '" type was not found.';
          if (this.options.silent)
            return console.error(o), "";
          throw new Error(o);
        }
      }
    }
    return n;
  }
  /**
   * Parse Inline Tokens
   */
  parseInline(e, t) {
    t = t || this.renderer;
    let n = "";
    for (let l = 0; l < e.length; l++) {
      const a = e[l];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[a.type]) {
        const o = this.options.extensions.renderers[a.type].call({ parser: this }, a);
        if (o !== !1 || !["escape", "html", "link", "image", "strong", "em", "codespan", "br", "del", "text"].includes(a.type)) {
          n += o || "";
          continue;
        }
      }
      switch (a.type) {
        case "escape": {
          const o = a;
          n += t.text(o.text);
          break;
        }
        case "html": {
          const o = a;
          n += t.html(o.text);
          break;
        }
        case "link": {
          const o = a;
          n += t.link(o.href, o.title, this.parseInline(o.tokens, t));
          break;
        }
        case "image": {
          const o = a;
          n += t.image(o.href, o.title, o.text);
          break;
        }
        case "strong": {
          const o = a;
          n += t.strong(this.parseInline(o.tokens, t));
          break;
        }
        case "em": {
          const o = a;
          n += t.em(this.parseInline(o.tokens, t));
          break;
        }
        case "codespan": {
          const o = a;
          n += t.codespan(o.text);
          break;
        }
        case "br": {
          n += t.br();
          break;
        }
        case "del": {
          const o = a;
          n += t.del(this.parseInline(o.tokens, t));
          break;
        }
        case "text": {
          const o = a;
          n += t.text(o.text);
          break;
        }
        default: {
          const o = 'Token with "' + a.type + '" type was not found.';
          if (this.options.silent)
            return console.error(o), "";
          throw new Error(o);
        }
      }
    }
    return n;
  }
}
class Tt {
  constructor(e) {
    X(this, "options");
    this.options = e || at;
  }
  /**
   * Process markdown before marked
   */
  preprocess(e) {
    return e;
  }
  /**
   * Process HTML after marked is finished
   */
  postprocess(e) {
    return e;
  }
  /**
   * Process all tokens before walk tokens
   */
  processAllTokens(e) {
    return e;
  }
}
X(Tt, "passThroughHooks", /* @__PURE__ */ new Set([
  "preprocess",
  "postprocess",
  "processAllTokens"
]));
var lt, Un, Ql;
class Kl {
  constructor(...e) {
    fi(this, lt);
    X(this, "defaults", ei());
    X(this, "options", this.setOptions);
    X(this, "parse", Xt(this, lt, Un).call(this, Me.lex, Re.parse));
    X(this, "parseInline", Xt(this, lt, Un).call(this, Me.lexInline, Re.parseInline));
    X(this, "Parser", Re);
    X(this, "Renderer", gn);
    X(this, "TextRenderer", oi);
    X(this, "Lexer", Me);
    X(this, "Tokenizer", pn);
    X(this, "Hooks", Tt);
    this.use(...e);
  }
  /**
   * Run callback for every token
   */
  walkTokens(e, t) {
    var l, a;
    let n = [];
    for (const o of e)
      switch (n = n.concat(t.call(this, o)), o.type) {
        case "table": {
          const r = o;
          for (const u of r.header)
            n = n.concat(this.walkTokens(u.tokens, t));
          for (const u of r.rows)
            for (const c of u)
              n = n.concat(this.walkTokens(c.tokens, t));
          break;
        }
        case "list": {
          const r = o;
          n = n.concat(this.walkTokens(r.items, t));
          break;
        }
        default: {
          const r = o;
          (a = (l = this.defaults.extensions) == null ? void 0 : l.childTokens) != null && a[r.type] ? this.defaults.extensions.childTokens[r.type].forEach((u) => {
            const c = r[u].flat(1 / 0);
            n = n.concat(this.walkTokens(c, t));
          }) : r.tokens && (n = n.concat(this.walkTokens(r.tokens, t)));
        }
      }
    return n;
  }
  use(...e) {
    const t = this.defaults.extensions || { renderers: {}, childTokens: {} };
    return e.forEach((n) => {
      const l = { ...n };
      if (l.async = this.defaults.async || l.async || !1, n.extensions && (n.extensions.forEach((a) => {
        if (!a.name)
          throw new Error("extension name required");
        if ("renderer" in a) {
          const o = t.renderers[a.name];
          o ? t.renderers[a.name] = function(...r) {
            let u = a.renderer.apply(this, r);
            return u === !1 && (u = o.apply(this, r)), u;
          } : t.renderers[a.name] = a.renderer;
        }
        if ("tokenizer" in a) {
          if (!a.level || a.level !== "block" && a.level !== "inline")
            throw new Error("extension level must be 'block' or 'inline'");
          const o = t[a.level];
          o ? o.unshift(a.tokenizer) : t[a.level] = [a.tokenizer], a.start && (a.level === "block" ? t.startBlock ? t.startBlock.push(a.start) : t.startBlock = [a.start] : a.level === "inline" && (t.startInline ? t.startInline.push(a.start) : t.startInline = [a.start]));
        }
        "childTokens" in a && a.childTokens && (t.childTokens[a.name] = a.childTokens);
      }), l.extensions = t), n.renderer) {
        const a = this.defaults.renderer || new gn(this.defaults);
        for (const o in n.renderer) {
          if (!(o in a))
            throw new Error(`renderer '${o}' does not exist`);
          if (o === "options")
            continue;
          const r = o, u = n.renderer[r], c = a[r];
          a[r] = (...s) => {
            let d = u.apply(a, s);
            return d === !1 && (d = c.apply(a, s)), d || "";
          };
        }
        l.renderer = a;
      }
      if (n.tokenizer) {
        const a = this.defaults.tokenizer || new pn(this.defaults);
        for (const o in n.tokenizer) {
          if (!(o in a))
            throw new Error(`tokenizer '${o}' does not exist`);
          if (["options", "rules", "lexer"].includes(o))
            continue;
          const r = o, u = n.tokenizer[r], c = a[r];
          a[r] = (...s) => {
            let d = u.apply(a, s);
            return d === !1 && (d = c.apply(a, s)), d;
          };
        }
        l.tokenizer = a;
      }
      if (n.hooks) {
        const a = this.defaults.hooks || new Tt();
        for (const o in n.hooks) {
          if (!(o in a))
            throw new Error(`hook '${o}' does not exist`);
          if (o === "options")
            continue;
          const r = o, u = n.hooks[r], c = a[r];
          Tt.passThroughHooks.has(o) ? a[r] = (s) => {
            if (this.defaults.async)
              return Promise.resolve(u.call(a, s)).then((f) => c.call(a, f));
            const d = u.call(a, s);
            return c.call(a, d);
          } : a[r] = (...s) => {
            let d = u.apply(a, s);
            return d === !1 && (d = c.apply(a, s)), d;
          };
        }
        l.hooks = a;
      }
      if (n.walkTokens) {
        const a = this.defaults.walkTokens, o = n.walkTokens;
        l.walkTokens = function(r) {
          let u = [];
          return u.push(o.call(this, r)), a && (u = u.concat(a.call(this, r))), u;
        };
      }
      this.defaults = { ...this.defaults, ...l };
    }), this;
  }
  setOptions(e) {
    return this.defaults = { ...this.defaults, ...e }, this;
  }
  lexer(e, t) {
    return Me.lex(e, t ?? this.defaults);
  }
  parser(e, t) {
    return Re.parse(e, t ?? this.defaults);
  }
}
lt = new WeakSet(), Un = function(e, t) {
  return (n, l) => {
    const a = { ...l }, o = { ...this.defaults, ...a };
    this.defaults.async === !0 && a.async === !1 && (o.silent || console.warn("marked(): The async option was set to true by an extension. The async: false option sent to parse will be ignored."), o.async = !0);
    const r = Xt(this, lt, Ql).call(this, !!o.silent, !!o.async);
    if (typeof n > "u" || n === null)
      return r(new Error("marked(): input parameter is undefined or null"));
    if (typeof n != "string")
      return r(new Error("marked(): input parameter is of type " + Object.prototype.toString.call(n) + ", string expected"));
    if (o.hooks && (o.hooks.options = o), o.async)
      return Promise.resolve(o.hooks ? o.hooks.preprocess(n) : n).then((u) => e(u, o)).then((u) => o.hooks ? o.hooks.processAllTokens(u) : u).then((u) => o.walkTokens ? Promise.all(this.walkTokens(u, o.walkTokens)).then(() => u) : u).then((u) => t(u, o)).then((u) => o.hooks ? o.hooks.postprocess(u) : u).catch(r);
    try {
      o.hooks && (n = o.hooks.preprocess(n));
      let u = e(n, o);
      o.hooks && (u = o.hooks.processAllTokens(u)), o.walkTokens && this.walkTokens(u, o.walkTokens);
      let c = t(u, o);
      return o.hooks && (c = o.hooks.postprocess(c)), c;
    } catch (u) {
      return r(u);
    }
  };
}, Ql = function(e, t) {
  return (n) => {
    if (n.message += `
Please report this to https://github.com/markedjs/marked.`, e) {
      const l = "<p>An error occurred:</p><pre>" + me(n.message + "", !0) + "</pre>";
      return t ? Promise.resolve(l) : l;
    }
    if (t)
      return Promise.reject(n);
    throw n;
  };
};
const it = new Kl();
function j(i, e) {
  return it.parse(i, e);
}
j.options = j.setOptions = function(i) {
  return it.setOptions(i), j.defaults = it.defaults, Pl(j.defaults), j;
};
j.getDefaults = ei;
j.defaults = at;
j.use = function(...i) {
  return it.use(...i), j.defaults = it.defaults, Pl(j.defaults), j;
};
j.walkTokens = function(i, e) {
  return it.walkTokens(i, e);
};
j.parseInline = it.parseInline;
j.Parser = Re;
j.parser = Re.parse;
j.Renderer = gn;
j.TextRenderer = oi;
j.Lexer = Me;
j.lexer = Me.lex;
j.Tokenizer = pn;
j.Hooks = Tt;
j.parse = j;
j.options;
j.setOptions;
j.use;
j.walkTokens;
j.parseInline;
Re.parse;
Me.lex;
function Xo(i) {
  if (typeof i == "function" && (i = {
    highlight: i
  }), !i || typeof i.highlight != "function")
    throw new Error("Must provide highlight function");
  return typeof i.langPrefix != "string" && (i.langPrefix = "language-"), typeof i.emptyLangClass != "string" && (i.emptyLangClass = ""), {
    async: !!i.async,
    walkTokens(e) {
      if (e.type !== "code")
        return;
      const t = ki(e.lang);
      if (i.async)
        return Promise.resolve(i.highlight(e.text, t, e.lang || "")).then(Fi(e));
      const n = i.highlight(e.text, t, e.lang || "");
      if (n instanceof Promise)
        throw new Error("markedHighlight is not set to async but the highlight function is async. Set the async option to true on markedHighlight to await the async highlight function.");
      Fi(e)(n);
    },
    useNewRenderer: !0,
    renderer: {
      code(e, t, n) {
        typeof e == "object" && (n = e.escaped, t = e.lang, e = e.text);
        const l = ki(t), a = l ? i.langPrefix + Ci(l) : i.emptyLangClass, o = a ? ` class="${a}"` : "";
        return e = e.replace(/\n$/, ""), `<pre><code${o}>${n ? e : Ci(e, !0)}
</code></pre>`;
      }
    }
  };
}
function ki(i) {
  return (i || "").match(/\S*/)[0];
}
function Fi(i) {
  return (e) => {
    typeof e == "string" && e !== i.text && (i.escaped = !0, i.text = e);
  };
}
const Jl = /[&<>"']/, Wo = new RegExp(Jl.source, "g"), ea = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, Yo = new RegExp(ea.source, "g"), Ko = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, $i = (i) => Ko[i];
function Ci(i, e) {
  if (e) {
    if (Jl.test(i))
      return i.replace(Wo, $i);
  } else if (ea.test(i))
    return i.replace(Yo, $i);
  return i;
}
const Qo = /[\0-\x1F!-,\.\/:-@\[-\^`\{-\xA9\xAB-\xB4\xB6-\xB9\xBB-\xBF\xD7\xF7\u02C2-\u02C5\u02D2-\u02DF\u02E5-\u02EB\u02ED\u02EF-\u02FF\u0375\u0378\u0379\u037E\u0380-\u0385\u0387\u038B\u038D\u03A2\u03F6\u0482\u0530\u0557\u0558\u055A-\u055F\u0589-\u0590\u05BE\u05C0\u05C3\u05C6\u05C8-\u05CF\u05EB-\u05EE\u05F3-\u060F\u061B-\u061F\u066A-\u066D\u06D4\u06DD\u06DE\u06E9\u06FD\u06FE\u0700-\u070F\u074B\u074C\u07B2-\u07BF\u07F6-\u07F9\u07FB\u07FC\u07FE\u07FF\u082E-\u083F\u085C-\u085F\u086B-\u089F\u08B5\u08C8-\u08D2\u08E2\u0964\u0965\u0970\u0984\u098D\u098E\u0991\u0992\u09A9\u09B1\u09B3-\u09B5\u09BA\u09BB\u09C5\u09C6\u09C9\u09CA\u09CF-\u09D6\u09D8-\u09DB\u09DE\u09E4\u09E5\u09F2-\u09FB\u09FD\u09FF\u0A00\u0A04\u0A0B-\u0A0E\u0A11\u0A12\u0A29\u0A31\u0A34\u0A37\u0A3A\u0A3B\u0A3D\u0A43-\u0A46\u0A49\u0A4A\u0A4E-\u0A50\u0A52-\u0A58\u0A5D\u0A5F-\u0A65\u0A76-\u0A80\u0A84\u0A8E\u0A92\u0AA9\u0AB1\u0AB4\u0ABA\u0ABB\u0AC6\u0ACA\u0ACE\u0ACF\u0AD1-\u0ADF\u0AE4\u0AE5\u0AF0-\u0AF8\u0B00\u0B04\u0B0D\u0B0E\u0B11\u0B12\u0B29\u0B31\u0B34\u0B3A\u0B3B\u0B45\u0B46\u0B49\u0B4A\u0B4E-\u0B54\u0B58-\u0B5B\u0B5E\u0B64\u0B65\u0B70\u0B72-\u0B81\u0B84\u0B8B-\u0B8D\u0B91\u0B96-\u0B98\u0B9B\u0B9D\u0BA0-\u0BA2\u0BA5-\u0BA7\u0BAB-\u0BAD\u0BBA-\u0BBD\u0BC3-\u0BC5\u0BC9\u0BCE\u0BCF\u0BD1-\u0BD6\u0BD8-\u0BE5\u0BF0-\u0BFF\u0C0D\u0C11\u0C29\u0C3A-\u0C3C\u0C45\u0C49\u0C4E-\u0C54\u0C57\u0C5B-\u0C5F\u0C64\u0C65\u0C70-\u0C7F\u0C84\u0C8D\u0C91\u0CA9\u0CB4\u0CBA\u0CBB\u0CC5\u0CC9\u0CCE-\u0CD4\u0CD7-\u0CDD\u0CDF\u0CE4\u0CE5\u0CF0\u0CF3-\u0CFF\u0D0D\u0D11\u0D45\u0D49\u0D4F-\u0D53\u0D58-\u0D5E\u0D64\u0D65\u0D70-\u0D79\u0D80\u0D84\u0D97-\u0D99\u0DB2\u0DBC\u0DBE\u0DBF\u0DC7-\u0DC9\u0DCB-\u0DCE\u0DD5\u0DD7\u0DE0-\u0DE5\u0DF0\u0DF1\u0DF4-\u0E00\u0E3B-\u0E3F\u0E4F\u0E5A-\u0E80\u0E83\u0E85\u0E8B\u0EA4\u0EA6\u0EBE\u0EBF\u0EC5\u0EC7\u0ECE\u0ECF\u0EDA\u0EDB\u0EE0-\u0EFF\u0F01-\u0F17\u0F1A-\u0F1F\u0F2A-\u0F34\u0F36\u0F38\u0F3A-\u0F3D\u0F48\u0F6D-\u0F70\u0F85\u0F98\u0FBD-\u0FC5\u0FC7-\u0FFF\u104A-\u104F\u109E\u109F\u10C6\u10C8-\u10CC\u10CE\u10CF\u10FB\u1249\u124E\u124F\u1257\u1259\u125E\u125F\u1289\u128E\u128F\u12B1\u12B6\u12B7\u12BF\u12C1\u12C6\u12C7\u12D7\u1311\u1316\u1317\u135B\u135C\u1360-\u137F\u1390-\u139F\u13F6\u13F7\u13FE-\u1400\u166D\u166E\u1680\u169B-\u169F\u16EB-\u16ED\u16F9-\u16FF\u170D\u1715-\u171F\u1735-\u173F\u1754-\u175F\u176D\u1771\u1774-\u177F\u17D4-\u17D6\u17D8-\u17DB\u17DE\u17DF\u17EA-\u180A\u180E\u180F\u181A-\u181F\u1879-\u187F\u18AB-\u18AF\u18F6-\u18FF\u191F\u192C-\u192F\u193C-\u1945\u196E\u196F\u1975-\u197F\u19AC-\u19AF\u19CA-\u19CF\u19DA-\u19FF\u1A1C-\u1A1F\u1A5F\u1A7D\u1A7E\u1A8A-\u1A8F\u1A9A-\u1AA6\u1AA8-\u1AAF\u1AC1-\u1AFF\u1B4C-\u1B4F\u1B5A-\u1B6A\u1B74-\u1B7F\u1BF4-\u1BFF\u1C38-\u1C3F\u1C4A-\u1C4C\u1C7E\u1C7F\u1C89-\u1C8F\u1CBB\u1CBC\u1CC0-\u1CCF\u1CD3\u1CFB-\u1CFF\u1DFA\u1F16\u1F17\u1F1E\u1F1F\u1F46\u1F47\u1F4E\u1F4F\u1F58\u1F5A\u1F5C\u1F5E\u1F7E\u1F7F\u1FB5\u1FBD\u1FBF-\u1FC1\u1FC5\u1FCD-\u1FCF\u1FD4\u1FD5\u1FDC-\u1FDF\u1FED-\u1FF1\u1FF5\u1FFD-\u203E\u2041-\u2053\u2055-\u2070\u2072-\u207E\u2080-\u208F\u209D-\u20CF\u20F1-\u2101\u2103-\u2106\u2108\u2109\u2114\u2116-\u2118\u211E-\u2123\u2125\u2127\u2129\u212E\u213A\u213B\u2140-\u2144\u214A-\u214D\u214F-\u215F\u2189-\u24B5\u24EA-\u2BFF\u2C2F\u2C5F\u2CE5-\u2CEA\u2CF4-\u2CFF\u2D26\u2D28-\u2D2C\u2D2E\u2D2F\u2D68-\u2D6E\u2D70-\u2D7E\u2D97-\u2D9F\u2DA7\u2DAF\u2DB7\u2DBF\u2DC7\u2DCF\u2DD7\u2DDF\u2E00-\u2E2E\u2E30-\u3004\u3008-\u3020\u3030\u3036\u3037\u303D-\u3040\u3097\u3098\u309B\u309C\u30A0\u30FB\u3100-\u3104\u3130\u318F-\u319F\u31C0-\u31EF\u3200-\u33FF\u4DC0-\u4DFF\u9FFD-\u9FFF\uA48D-\uA4CF\uA4FE\uA4FF\uA60D-\uA60F\uA62C-\uA63F\uA673\uA67E\uA6F2-\uA716\uA720\uA721\uA789\uA78A\uA7C0\uA7C1\uA7CB-\uA7F4\uA828-\uA82B\uA82D-\uA83F\uA874-\uA87F\uA8C6-\uA8CF\uA8DA-\uA8DF\uA8F8-\uA8FA\uA8FC\uA92E\uA92F\uA954-\uA95F\uA97D-\uA97F\uA9C1-\uA9CE\uA9DA-\uA9DF\uA9FF\uAA37-\uAA3F\uAA4E\uAA4F\uAA5A-\uAA5F\uAA77-\uAA79\uAAC3-\uAADA\uAADE\uAADF\uAAF0\uAAF1\uAAF7-\uAB00\uAB07\uAB08\uAB0F\uAB10\uAB17-\uAB1F\uAB27\uAB2F\uAB5B\uAB6A-\uAB6F\uABEB\uABEE\uABEF\uABFA-\uABFF\uD7A4-\uD7AF\uD7C7-\uD7CA\uD7FC-\uD7FF\uE000-\uF8FF\uFA6E\uFA6F\uFADA-\uFAFF\uFB07-\uFB12\uFB18-\uFB1C\uFB29\uFB37\uFB3D\uFB3F\uFB42\uFB45\uFBB2-\uFBD2\uFD3E-\uFD4F\uFD90\uFD91\uFDC8-\uFDEF\uFDFC-\uFDFF\uFE10-\uFE1F\uFE30-\uFE32\uFE35-\uFE4C\uFE50-\uFE6F\uFE75\uFEFD-\uFF0F\uFF1A-\uFF20\uFF3B-\uFF3E\uFF40\uFF5B-\uFF65\uFFBF-\uFFC1\uFFC8\uFFC9\uFFD0\uFFD1\uFFD8\uFFD9\uFFDD-\uFFFF]|\uD800[\uDC0C\uDC27\uDC3B\uDC3E\uDC4E\uDC4F\uDC5E-\uDC7F\uDCFB-\uDD3F\uDD75-\uDDFC\uDDFE-\uDE7F\uDE9D-\uDE9F\uDED1-\uDEDF\uDEE1-\uDEFF\uDF20-\uDF2C\uDF4B-\uDF4F\uDF7B-\uDF7F\uDF9E\uDF9F\uDFC4-\uDFC7\uDFD0\uDFD6-\uDFFF]|\uD801[\uDC9E\uDC9F\uDCAA-\uDCAF\uDCD4-\uDCD7\uDCFC-\uDCFF\uDD28-\uDD2F\uDD64-\uDDFF\uDF37-\uDF3F\uDF56-\uDF5F\uDF68-\uDFFF]|\uD802[\uDC06\uDC07\uDC09\uDC36\uDC39-\uDC3B\uDC3D\uDC3E\uDC56-\uDC5F\uDC77-\uDC7F\uDC9F-\uDCDF\uDCF3\uDCF6-\uDCFF\uDD16-\uDD1F\uDD3A-\uDD7F\uDDB8-\uDDBD\uDDC0-\uDDFF\uDE04\uDE07-\uDE0B\uDE14\uDE18\uDE36\uDE37\uDE3B-\uDE3E\uDE40-\uDE5F\uDE7D-\uDE7F\uDE9D-\uDEBF\uDEC8\uDEE7-\uDEFF\uDF36-\uDF3F\uDF56-\uDF5F\uDF73-\uDF7F\uDF92-\uDFFF]|\uD803[\uDC49-\uDC7F\uDCB3-\uDCBF\uDCF3-\uDCFF\uDD28-\uDD2F\uDD3A-\uDE7F\uDEAA\uDEAD-\uDEAF\uDEB2-\uDEFF\uDF1D-\uDF26\uDF28-\uDF2F\uDF51-\uDFAF\uDFC5-\uDFDF\uDFF7-\uDFFF]|\uD804[\uDC47-\uDC65\uDC70-\uDC7E\uDCBB-\uDCCF\uDCE9-\uDCEF\uDCFA-\uDCFF\uDD35\uDD40-\uDD43\uDD48-\uDD4F\uDD74\uDD75\uDD77-\uDD7F\uDDC5-\uDDC8\uDDCD\uDDDB\uDDDD-\uDDFF\uDE12\uDE38-\uDE3D\uDE3F-\uDE7F\uDE87\uDE89\uDE8E\uDE9E\uDEA9-\uDEAF\uDEEB-\uDEEF\uDEFA-\uDEFF\uDF04\uDF0D\uDF0E\uDF11\uDF12\uDF29\uDF31\uDF34\uDF3A\uDF45\uDF46\uDF49\uDF4A\uDF4E\uDF4F\uDF51-\uDF56\uDF58-\uDF5C\uDF64\uDF65\uDF6D-\uDF6F\uDF75-\uDFFF]|\uD805[\uDC4B-\uDC4F\uDC5A-\uDC5D\uDC62-\uDC7F\uDCC6\uDCC8-\uDCCF\uDCDA-\uDD7F\uDDB6\uDDB7\uDDC1-\uDDD7\uDDDE-\uDDFF\uDE41-\uDE43\uDE45-\uDE4F\uDE5A-\uDE7F\uDEB9-\uDEBF\uDECA-\uDEFF\uDF1B\uDF1C\uDF2C-\uDF2F\uDF3A-\uDFFF]|\uD806[\uDC3B-\uDC9F\uDCEA-\uDCFE\uDD07\uDD08\uDD0A\uDD0B\uDD14\uDD17\uDD36\uDD39\uDD3A\uDD44-\uDD4F\uDD5A-\uDD9F\uDDA8\uDDA9\uDDD8\uDDD9\uDDE2\uDDE5-\uDDFF\uDE3F-\uDE46\uDE48-\uDE4F\uDE9A-\uDE9C\uDE9E-\uDEBF\uDEF9-\uDFFF]|\uD807[\uDC09\uDC37\uDC41-\uDC4F\uDC5A-\uDC71\uDC90\uDC91\uDCA8\uDCB7-\uDCFF\uDD07\uDD0A\uDD37-\uDD39\uDD3B\uDD3E\uDD48-\uDD4F\uDD5A-\uDD5F\uDD66\uDD69\uDD8F\uDD92\uDD99-\uDD9F\uDDAA-\uDEDF\uDEF7-\uDFAF\uDFB1-\uDFFF]|\uD808[\uDF9A-\uDFFF]|\uD809[\uDC6F-\uDC7F\uDD44-\uDFFF]|[\uD80A\uD80B\uD80E-\uD810\uD812-\uD819\uD824-\uD82B\uD82D\uD82E\uD830-\uD833\uD837\uD839\uD83D\uD83F\uD87B-\uD87D\uD87F\uD885-\uDB3F\uDB41-\uDBFF][\uDC00-\uDFFF]|\uD80D[\uDC2F-\uDFFF]|\uD811[\uDE47-\uDFFF]|\uD81A[\uDE39-\uDE3F\uDE5F\uDE6A-\uDECF\uDEEE\uDEEF\uDEF5-\uDEFF\uDF37-\uDF3F\uDF44-\uDF4F\uDF5A-\uDF62\uDF78-\uDF7C\uDF90-\uDFFF]|\uD81B[\uDC00-\uDE3F\uDE80-\uDEFF\uDF4B-\uDF4E\uDF88-\uDF8E\uDFA0-\uDFDF\uDFE2\uDFE5-\uDFEF\uDFF2-\uDFFF]|\uD821[\uDFF8-\uDFFF]|\uD823[\uDCD6-\uDCFF\uDD09-\uDFFF]|\uD82C[\uDD1F-\uDD4F\uDD53-\uDD63\uDD68-\uDD6F\uDEFC-\uDFFF]|\uD82F[\uDC6B-\uDC6F\uDC7D-\uDC7F\uDC89-\uDC8F\uDC9A-\uDC9C\uDC9F-\uDFFF]|\uD834[\uDC00-\uDD64\uDD6A-\uDD6C\uDD73-\uDD7A\uDD83\uDD84\uDD8C-\uDDA9\uDDAE-\uDE41\uDE45-\uDFFF]|\uD835[\uDC55\uDC9D\uDCA0\uDCA1\uDCA3\uDCA4\uDCA7\uDCA8\uDCAD\uDCBA\uDCBC\uDCC4\uDD06\uDD0B\uDD0C\uDD15\uDD1D\uDD3A\uDD3F\uDD45\uDD47-\uDD49\uDD51\uDEA6\uDEA7\uDEC1\uDEDB\uDEFB\uDF15\uDF35\uDF4F\uDF6F\uDF89\uDFA9\uDFC3\uDFCC\uDFCD]|\uD836[\uDC00-\uDDFF\uDE37-\uDE3A\uDE6D-\uDE74\uDE76-\uDE83\uDE85-\uDE9A\uDEA0\uDEB0-\uDFFF]|\uD838[\uDC07\uDC19\uDC1A\uDC22\uDC25\uDC2B-\uDCFF\uDD2D-\uDD2F\uDD3E\uDD3F\uDD4A-\uDD4D\uDD4F-\uDEBF\uDEFA-\uDFFF]|\uD83A[\uDCC5-\uDCCF\uDCD7-\uDCFF\uDD4C-\uDD4F\uDD5A-\uDFFF]|\uD83B[\uDC00-\uDDFF\uDE04\uDE20\uDE23\uDE25\uDE26\uDE28\uDE33\uDE38\uDE3A\uDE3C-\uDE41\uDE43-\uDE46\uDE48\uDE4A\uDE4C\uDE50\uDE53\uDE55\uDE56\uDE58\uDE5A\uDE5C\uDE5E\uDE60\uDE63\uDE65\uDE66\uDE6B\uDE73\uDE78\uDE7D\uDE7F\uDE8A\uDE9C-\uDEA0\uDEA4\uDEAA\uDEBC-\uDFFF]|\uD83C[\uDC00-\uDD2F\uDD4A-\uDD4F\uDD6A-\uDD6F\uDD8A-\uDFFF]|\uD83E[\uDC00-\uDFEF\uDFFA-\uDFFF]|\uD869[\uDEDE-\uDEFF]|\uD86D[\uDF35-\uDF3F]|\uD86E[\uDC1E\uDC1F]|\uD873[\uDEA2-\uDEAF]|\uD87A[\uDFE1-\uDFFF]|\uD87E[\uDE1E-\uDFFF]|\uD884[\uDF4B-\uDFFF]|\uDB40[\uDC00-\uDCFF\uDDF0-\uDFFF]/g, Jo = Object.hasOwnProperty;
class ri {
  /**
   * Create a new slug class.
   */
  constructor() {
    this.occurrences, this.reset();
  }
  /**
   * Generate a unique slug.
  *
  * Tracks previously generated slugs: repeated calls with the same value
  * will result in different slugs.
  * Use the `slug` function to get same slugs.
   *
   * @param  {string} value
   *   String of text to slugify
   * @param  {boolean} [maintainCase=false]
   *   Keep the current case, otherwise make all lowercase
   * @return {string}
   *   A unique slug string
   */
  slug(e, t) {
    const n = this;
    let l = er(e, t === !0);
    const a = l;
    for (; Jo.call(n.occurrences, l); )
      n.occurrences[a]++, l = a + "-" + n.occurrences[a];
    return n.occurrences[l] = 0, l;
  }
  /**
   * Reset - Forget all previous slugs
   *
   * @return void
   */
  reset() {
    this.occurrences = /* @__PURE__ */ Object.create(null);
  }
}
function er(i, e) {
  return typeof i != "string" ? "" : (e || (i = i.toLowerCase()), i.replace(Qo, "").replace(/ /g, "-"));
}
let ta = new ri(), na = [];
function tr({ prefix: i = "", globalSlugs: e = !1 } = {}) {
  return {
    headerIds: !1,
    // prevent deprecation warning; remove this once headerIds option is removed
    hooks: {
      preprocess(t) {
        return e || nr(), t;
      }
    },
    renderer: {
      heading(t, n, l) {
        l = l.toLowerCase().trim().replace(/<[!\/a-z].*?>/gi, "");
        const a = `${i}${ta.slug(l)}`, o = { level: n, text: t, id: a };
        return na.push(o), `<h${n} id="${a}">${t}</h${n}>
`;
      }
    }
  };
}
function nr() {
  na = [], ta = new ri();
}
var Ei = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {};
function B_(i) {
  return i && i.__esModule && Object.prototype.hasOwnProperty.call(i, "default") ? i.default : i;
}
var ia = { exports: {} };
(function(i) {
  var e = typeof window < "u" ? window : typeof WorkerGlobalScope < "u" && self instanceof WorkerGlobalScope ? self : {};
  /**
   * Prism: Lightweight, robust, elegant syntax highlighting
   *
   * @license MIT <https://opensource.org/licenses/MIT>
   * @author Lea Verou <https://lea.verou.me>
   * @namespace
   * @public
   */
  var t = function(n) {
    var l = /(?:^|\s)lang(?:uage)?-([\w-]+)(?=\s|$)/i, a = 0, o = {}, r = {
      /**
       * By default, Prism will attempt to highlight all code elements (by calling {@link Prism.highlightAll}) on the
       * current page after the page finished loading. This might be a problem if e.g. you wanted to asynchronously load
       * additional languages or plugins yourself.
       *
       * By setting this value to `true`, Prism will not automatically highlight all code elements on the page.
       *
       * You obviously have to change this value before the automatic highlighting started. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.manual = true;
       * // add a new <script> to load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      manual: n.Prism && n.Prism.manual,
      /**
       * By default, if Prism is in a web worker, it assumes that it is in a worker it created itself, so it uses
       * `addEventListener` to communicate with its parent instance. However, if you're using Prism manually in your
       * own worker, you don't want it to do this.
       *
       * By setting this value to `true`, Prism will not add its own listeners to the worker.
       *
       * You obviously have to change this value before Prism executes. To do this, you can add an
       * empty Prism object into the global scope before loading the Prism script like this:
       *
       * ```js
       * window.Prism = window.Prism || {};
       * Prism.disableWorkerMessageHandler = true;
       * // Load Prism's script
       * ```
       *
       * @default false
       * @type {boolean}
       * @memberof Prism
       * @public
       */
      disableWorkerMessageHandler: n.Prism && n.Prism.disableWorkerMessageHandler,
      /**
       * A namespace for utility methods.
       *
       * All function in this namespace that are not explicitly marked as _public_ are for __internal use only__ and may
       * change or disappear at any time.
       *
       * @namespace
       * @memberof Prism
       */
      util: {
        encode: function m(_) {
          return _ instanceof u ? new u(_.type, m(_.content), _.alias) : Array.isArray(_) ? _.map(m) : _.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/\u00a0/g, " ");
        },
        /**
         * Returns the name of the type of the given value.
         *
         * @param {any} o
         * @returns {string}
         * @example
         * type(null)      === 'Null'
         * type(undefined) === 'Undefined'
         * type(123)       === 'Number'
         * type('foo')     === 'String'
         * type(true)      === 'Boolean'
         * type([1, 2])    === 'Array'
         * type({})        === 'Object'
         * type(String)    === 'Function'
         * type(/abc+/)    === 'RegExp'
         */
        type: function(m) {
          return Object.prototype.toString.call(m).slice(8, -1);
        },
        /**
         * Returns a unique number for the given object. Later calls will still return the same number.
         *
         * @param {Object} obj
         * @returns {number}
         */
        objId: function(m) {
          return m.__id || Object.defineProperty(m, "__id", { value: ++a }), m.__id;
        },
        /**
         * Creates a deep clone of the given object.
         *
         * The main intended use of this function is to clone language definitions.
         *
         * @param {T} o
         * @param {Record<number, any>} [visited]
         * @returns {T}
         * @template T
         */
        clone: function m(_, g) {
          g = g || {};
          var D, b;
          switch (r.util.type(_)) {
            case "Object":
              if (b = r.util.objId(_), g[b])
                return g[b];
              D = /** @type {Record<string, any>} */
              {}, g[b] = D;
              for (var w in _)
                _.hasOwnProperty(w) && (D[w] = m(_[w], g));
              return (
                /** @type {any} */
                D
              );
            case "Array":
              return b = r.util.objId(_), g[b] ? g[b] : (D = [], g[b] = D, /** @type {Array} */
              /** @type {any} */
              _.forEach(function(E, y) {
                D[y] = m(E, g);
              }), /** @type {any} */
              D);
            default:
              return _;
          }
        },
        /**
         * Returns the Prism language of the given element set by a `language-xxxx` or `lang-xxxx` class.
         *
         * If no language is set for the element or the element is `null` or `undefined`, `none` will be returned.
         *
         * @param {Element} element
         * @returns {string}
         */
        getLanguage: function(m) {
          for (; m; ) {
            var _ = l.exec(m.className);
            if (_)
              return _[1].toLowerCase();
            m = m.parentElement;
          }
          return "none";
        },
        /**
         * Sets the Prism `language-xxxx` class of the given element.
         *
         * @param {Element} element
         * @param {string} language
         * @returns {void}
         */
        setLanguage: function(m, _) {
          m.className = m.className.replace(RegExp(l, "gi"), ""), m.classList.add("language-" + _);
        },
        /**
         * Returns the script element that is currently executing.
         *
         * This does __not__ work for line script element.
         *
         * @returns {HTMLScriptElement | null}
         */
        currentScript: function() {
          if (typeof document > "u")
            return null;
          if ("currentScript" in document)
            return (
              /** @type {any} */
              document.currentScript
            );
          try {
            throw new Error();
          } catch (D) {
            var m = (/at [^(\r\n]*\((.*):[^:]+:[^:]+\)$/i.exec(D.stack) || [])[1];
            if (m) {
              var _ = document.getElementsByTagName("script");
              for (var g in _)
                if (_[g].src == m)
                  return _[g];
            }
            return null;
          }
        },
        /**
         * Returns whether a given class is active for `element`.
         *
         * The class can be activated if `element` or one of its ancestors has the given class and it can be deactivated
         * if `element` or one of its ancestors has the negated version of the given class. The _negated version_ of the
         * given class is just the given class with a `no-` prefix.
         *
         * Whether the class is active is determined by the closest ancestor of `element` (where `element` itself is
         * closest ancestor) that has the given class or the negated version of it. If neither `element` nor any of its
         * ancestors have the given class or the negated version of it, then the default activation will be returned.
         *
         * In the paradoxical situation where the closest ancestor contains __both__ the given class and the negated
         * version of it, the class is considered active.
         *
         * @param {Element} element
         * @param {string} className
         * @param {boolean} [defaultActivation=false]
         * @returns {boolean}
         */
        isActive: function(m, _, g) {
          for (var D = "no-" + _; m; ) {
            var b = m.classList;
            if (b.contains(_))
              return !0;
            if (b.contains(D))
              return !1;
            m = m.parentElement;
          }
          return !!g;
        }
      },
      /**
       * This namespace contains all currently loaded languages and the some helper functions to create and modify languages.
       *
       * @namespace
       * @memberof Prism
       * @public
       */
      languages: {
        /**
         * The grammar for plain, unformatted text.
         */
        plain: o,
        plaintext: o,
        text: o,
        txt: o,
        /**
         * Creates a deep copy of the language with the given id and appends the given tokens.
         *
         * If a token in `redef` also appears in the copied language, then the existing token in the copied language
         * will be overwritten at its original position.
         *
         * ## Best practices
         *
         * Since the position of overwriting tokens (token in `redef` that overwrite tokens in the copied language)
         * doesn't matter, they can technically be in any order. However, this can be confusing to others that trying to
         * understand the language definition because, normally, the order of tokens matters in Prism grammars.
         *
         * Therefore, it is encouraged to order overwriting tokens according to the positions of the overwritten tokens.
         * Furthermore, all non-overwriting tokens should be placed after the overwriting ones.
         *
         * @param {string} id The id of the language to extend. This has to be a key in `Prism.languages`.
         * @param {Grammar} redef The new tokens to append.
         * @returns {Grammar} The new language created.
         * @public
         * @example
         * Prism.languages['css-with-colors'] = Prism.languages.extend('css', {
         *     // Prism.languages.css already has a 'comment' token, so this token will overwrite CSS' 'comment' token
         *     // at its original position
         *     'comment': { ... },
         *     // CSS doesn't have a 'color' token, so this token will be appended
         *     'color': /\b(?:red|green|blue)\b/
         * });
         */
        extend: function(m, _) {
          var g = r.util.clone(r.languages[m]);
          for (var D in _)
            g[D] = _[D];
          return g;
        },
        /**
         * Inserts tokens _before_ another token in a language definition or any other grammar.
         *
         * ## Usage
         *
         * This helper method makes it easy to modify existing languages. For example, the CSS language definition
         * not only defines CSS highlighting for CSS documents, but also needs to define highlighting for CSS embedded
         * in HTML through `<style>` elements. To do this, it needs to modify `Prism.languages.markup` and add the
         * appropriate tokens. However, `Prism.languages.markup` is a regular JavaScript object literal, so if you do
         * this:
         *
         * ```js
         * Prism.languages.markup.style = {
         *     // token
         * };
         * ```
         *
         * then the `style` token will be added (and processed) at the end. `insertBefore` allows you to insert tokens
         * before existing tokens. For the CSS example above, you would use it like this:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'cdata', {
         *     'style': {
         *         // token
         *     }
         * });
         * ```
         *
         * ## Special cases
         *
         * If the grammars of `inside` and `insert` have tokens with the same name, the tokens in `inside`'s grammar
         * will be ignored.
         *
         * This behavior can be used to insert tokens after `before`:
         *
         * ```js
         * Prism.languages.insertBefore('markup', 'comment', {
         *     'comment': Prism.languages.markup.comment,
         *     // tokens after 'comment'
         * });
         * ```
         *
         * ## Limitations
         *
         * The main problem `insertBefore` has to solve is iteration order. Since ES2015, the iteration order for object
         * properties is guaranteed to be the insertion order (except for integer keys) but some browsers behave
         * differently when keys are deleted and re-inserted. So `insertBefore` can't be implemented by temporarily
         * deleting properties which is necessary to insert at arbitrary positions.
         *
         * To solve this problem, `insertBefore` doesn't actually insert the given tokens into the target object.
         * Instead, it will create a new object and replace all references to the target object with the new one. This
         * can be done without temporarily deleting properties, so the iteration order is well-defined.
         *
         * However, only references that can be reached from `Prism.languages` or `insert` will be replaced. I.e. if
         * you hold the target object in a variable, then the value of the variable will not change.
         *
         * ```js
         * var oldMarkup = Prism.languages.markup;
         * var newMarkup = Prism.languages.insertBefore('markup', 'comment', { ... });
         *
         * assert(oldMarkup !== Prism.languages.markup);
         * assert(newMarkup === Prism.languages.markup);
         * ```
         *
         * @param {string} inside The property of `root` (e.g. a language id in `Prism.languages`) that contains the
         * object to be modified.
         * @param {string} before The key to insert before.
         * @param {Grammar} insert An object containing the key-value pairs to be inserted.
         * @param {Object<string, any>} [root] The object containing `inside`, i.e. the object that contains the
         * object to be modified.
         *
         * Defaults to `Prism.languages`.
         * @returns {Grammar} The new grammar object.
         * @public
         */
        insertBefore: function(m, _, g, D) {
          D = D || /** @type {any} */
          r.languages;
          var b = D[m], w = {};
          for (var E in b)
            if (b.hasOwnProperty(E)) {
              if (E == _)
                for (var y in g)
                  g.hasOwnProperty(y) && (w[y] = g[y]);
              g.hasOwnProperty(E) || (w[E] = b[E]);
            }
          var B = D[m];
          return D[m] = w, r.languages.DFS(r.languages, function(q, z) {
            z === B && q != m && (this[q] = w);
          }), w;
        },
        // Traverse a language definition with Depth First Search
        DFS: function m(_, g, D, b) {
          b = b || {};
          var w = r.util.objId;
          for (var E in _)
            if (_.hasOwnProperty(E)) {
              g.call(_, E, _[E], D || E);
              var y = _[E], B = r.util.type(y);
              B === "Object" && !b[w(y)] ? (b[w(y)] = !0, m(y, g, null, b)) : B === "Array" && !b[w(y)] && (b[w(y)] = !0, m(y, g, E, b));
            }
        }
      },
      plugins: {},
      /**
       * This is the most high-level function in Prism’s API.
       * It fetches all the elements that have a `.language-xxxx` class and then calls {@link Prism.highlightElement} on
       * each one of them.
       *
       * This is equivalent to `Prism.highlightAllUnder(document, async, callback)`.
       *
       * @param {boolean} [async=false] Same as in {@link Prism.highlightAllUnder}.
       * @param {HighlightCallback} [callback] Same as in {@link Prism.highlightAllUnder}.
       * @memberof Prism
       * @public
       */
      highlightAll: function(m, _) {
        r.highlightAllUnder(document, m, _);
      },
      /**
       * Fetches all the descendants of `container` that have a `.language-xxxx` class and then calls
       * {@link Prism.highlightElement} on each one of them.
       *
       * The following hooks will be run:
       * 1. `before-highlightall`
       * 2. `before-all-elements-highlight`
       * 3. All hooks of {@link Prism.highlightElement} for each element.
       *
       * @param {ParentNode} container The root element, whose descendants that have a `.language-xxxx` class will be highlighted.
       * @param {boolean} [async=false] Whether each element is to be highlighted asynchronously using Web Workers.
       * @param {HighlightCallback} [callback] An optional callback to be invoked on each element after its highlighting is done.
       * @memberof Prism
       * @public
       */
      highlightAllUnder: function(m, _, g) {
        var D = {
          callback: g,
          container: m,
          selector: 'code[class*="language-"], [class*="language-"] code, code[class*="lang-"], [class*="lang-"] code'
        };
        r.hooks.run("before-highlightall", D), D.elements = Array.prototype.slice.apply(D.container.querySelectorAll(D.selector)), r.hooks.run("before-all-elements-highlight", D);
        for (var b = 0, w; w = D.elements[b++]; )
          r.highlightElement(w, _ === !0, D.callback);
      },
      /**
       * Highlights the code inside a single element.
       *
       * The following hooks will be run:
       * 1. `before-sanity-check`
       * 2. `before-highlight`
       * 3. All hooks of {@link Prism.highlight}. These hooks will be run by an asynchronous worker if `async` is `true`.
       * 4. `before-insert`
       * 5. `after-highlight`
       * 6. `complete`
       *
       * Some the above hooks will be skipped if the element doesn't contain any text or there is no grammar loaded for
       * the element's language.
       *
       * @param {Element} element The element containing the code.
       * It must have a class of `language-xxxx` to be processed, where `xxxx` is a valid language identifier.
       * @param {boolean} [async=false] Whether the element is to be highlighted asynchronously using Web Workers
       * to improve performance and avoid blocking the UI when highlighting very large chunks of code. This option is
       * [disabled by default](https://prismjs.com/faq.html#why-is-asynchronous-highlighting-disabled-by-default).
       *
       * Note: All language definitions required to highlight the code must be included in the main `prism.js` file for
       * asynchronous highlighting to work. You can build your own bundle on the
       * [Download page](https://prismjs.com/download.html).
       * @param {HighlightCallback} [callback] An optional callback to be invoked after the highlighting is done.
       * Mostly useful when `async` is `true`, since in that case, the highlighting is done asynchronously.
       * @memberof Prism
       * @public
       */
      highlightElement: function(m, _, g) {
        var D = r.util.getLanguage(m), b = r.languages[D];
        r.util.setLanguage(m, D);
        var w = m.parentElement;
        w && w.nodeName.toLowerCase() === "pre" && r.util.setLanguage(w, D);
        var E = m.textContent, y = {
          element: m,
          language: D,
          grammar: b,
          code: E
        };
        function B(z) {
          y.highlightedCode = z, r.hooks.run("before-insert", y), y.element.innerHTML = y.highlightedCode, r.hooks.run("after-highlight", y), r.hooks.run("complete", y), g && g.call(y.element);
        }
        if (r.hooks.run("before-sanity-check", y), w = y.element.parentElement, w && w.nodeName.toLowerCase() === "pre" && !w.hasAttribute("tabindex") && w.setAttribute("tabindex", "0"), !y.code) {
          r.hooks.run("complete", y), g && g.call(y.element);
          return;
        }
        if (r.hooks.run("before-highlight", y), !y.grammar) {
          B(r.util.encode(y.code));
          return;
        }
        if (_ && n.Worker) {
          var q = new Worker(r.filename);
          q.onmessage = function(z) {
            B(z.data);
          }, q.postMessage(JSON.stringify({
            language: y.language,
            code: y.code,
            immediateClose: !0
          }));
        } else
          B(r.highlight(y.code, y.grammar, y.language));
      },
      /**
       * Low-level function, only use if you know what you’re doing. It accepts a string of text as input
       * and the language definitions to use, and returns a string with the HTML produced.
       *
       * The following hooks will be run:
       * 1. `before-tokenize`
       * 2. `after-tokenize`
       * 3. `wrap`: On each {@link Token}.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @param {string} language The name of the language definition passed to `grammar`.
       * @returns {string} The highlighted HTML.
       * @memberof Prism
       * @public
       * @example
       * Prism.highlight('var foo = true;', Prism.languages.javascript, 'javascript');
       */
      highlight: function(m, _, g) {
        var D = {
          code: m,
          grammar: _,
          language: g
        };
        if (r.hooks.run("before-tokenize", D), !D.grammar)
          throw new Error('The language "' + D.language + '" has no grammar.');
        return D.tokens = r.tokenize(D.code, D.grammar), r.hooks.run("after-tokenize", D), u.stringify(r.util.encode(D.tokens), D.language);
      },
      /**
       * This is the heart of Prism, and the most low-level function you can use. It accepts a string of text as input
       * and the language definitions to use, and returns an array with the tokenized code.
       *
       * When the language definition includes nested tokens, the function is called recursively on each of these tokens.
       *
       * This method could be useful in other contexts as well, as a very crude parser.
       *
       * @param {string} text A string with the code to be highlighted.
       * @param {Grammar} grammar An object containing the tokens to use.
       *
       * Usually a language definition like `Prism.languages.markup`.
       * @returns {TokenStream} An array of strings and tokens, a token stream.
       * @memberof Prism
       * @public
       * @example
       * let code = `var foo = 0;`;
       * let tokens = Prism.tokenize(code, Prism.languages.javascript);
       * tokens.forEach(token => {
       *     if (token instanceof Prism.Token && token.type === 'number') {
       *         console.log(`Found numeric literal: ${token.content}`);
       *     }
       * });
       */
      tokenize: function(m, _) {
        var g = _.rest;
        if (g) {
          for (var D in g)
            _[D] = g[D];
          delete _.rest;
        }
        var b = new d();
        return f(b, b.head, m), s(m, b, _, b.head, 0), p(b);
      },
      /**
       * @namespace
       * @memberof Prism
       * @public
       */
      hooks: {
        all: {},
        /**
         * Adds the given callback to the list of callbacks for the given hook.
         *
         * The callback will be invoked when the hook it is registered for is run.
         * Hooks are usually directly run by a highlight function but you can also run hooks yourself.
         *
         * One callback function can be registered to multiple hooks and the same hook multiple times.
         *
         * @param {string} name The name of the hook.
         * @param {HookCallback} callback The callback function which is given environment variables.
         * @public
         */
        add: function(m, _) {
          var g = r.hooks.all;
          g[m] = g[m] || [], g[m].push(_);
        },
        /**
         * Runs a hook invoking all registered callbacks with the given environment variables.
         *
         * Callbacks will be invoked synchronously and in the order in which they were registered.
         *
         * @param {string} name The name of the hook.
         * @param {Object<string, any>} env The environment variables of the hook passed to all callbacks registered.
         * @public
         */
        run: function(m, _) {
          var g = r.hooks.all[m];
          if (!(!g || !g.length))
            for (var D = 0, b; b = g[D++]; )
              b(_);
        }
      },
      Token: u
    };
    n.Prism = r;
    function u(m, _, g, D) {
      this.type = m, this.content = _, this.alias = g, this.length = (D || "").length | 0;
    }
    u.stringify = function m(_, g) {
      if (typeof _ == "string")
        return _;
      if (Array.isArray(_)) {
        var D = "";
        return _.forEach(function(B) {
          D += m(B, g);
        }), D;
      }
      var b = {
        type: _.type,
        content: m(_.content, g),
        tag: "span",
        classes: ["token", _.type],
        attributes: {},
        language: g
      }, w = _.alias;
      w && (Array.isArray(w) ? Array.prototype.push.apply(b.classes, w) : b.classes.push(w)), r.hooks.run("wrap", b);
      var E = "";
      for (var y in b.attributes)
        E += " " + y + '="' + (b.attributes[y] || "").replace(/"/g, "&quot;") + '"';
      return "<" + b.tag + ' class="' + b.classes.join(" ") + '"' + E + ">" + b.content + "</" + b.tag + ">";
    };
    function c(m, _, g, D) {
      m.lastIndex = _;
      var b = m.exec(g);
      if (b && D && b[1]) {
        var w = b[1].length;
        b.index += w, b[0] = b[0].slice(w);
      }
      return b;
    }
    function s(m, _, g, D, b, w) {
      for (var E in g)
        if (!(!g.hasOwnProperty(E) || !g[E])) {
          var y = g[E];
          y = Array.isArray(y) ? y : [y];
          for (var B = 0; B < y.length; ++B) {
            if (w && w.cause == E + "," + B)
              return;
            var q = y[B], z = q.inside, le = !!q.lookbehind, G = !!q.greedy, N = q.alias;
            if (G && !q.pattern.global) {
              var M = q.pattern.toString().match(/[imsuy]*$/)[0];
              q.pattern = RegExp(q.pattern.source, M + "g");
            }
            for (var V = q.pattern || q, P = D.next, ee = b; P !== _.tail && !(w && ee >= w.reach); ee += P.value.length, P = P.next) {
              var K = P.value;
              if (_.length > m.length)
                return;
              if (!(K instanceof u)) {
                var A = 1, Q;
                if (G) {
                  if (Q = c(V, ee, m, le), !Q || Q.index >= m.length)
                    break;
                  var S = Q.index, qe = Q.index + Q[0].length, ae = ee;
                  for (ae += P.value.length; S >= ae; )
                    P = P.next, ae += P.value.length;
                  if (ae -= P.value.length, ee = ae, P.value instanceof u)
                    continue;
                  for (var x = P; x !== _.tail && (ae < qe || typeof x.value == "string"); x = x.next)
                    A++, ae += x.value.length;
                  A--, K = m.slice(ee, ae), Q.index -= ee;
                } else if (Q = c(V, 0, K, le), !Q)
                  continue;
                var S = Q.index, ot = Q[0], Dt = K.slice(0, S), Gt = K.slice(S + ot.length), wt = ee + K.length;
                w && wt > w.reach && (w.reach = wt);
                var rt = P.prev;
                Dt && (rt = f(_, rt, Dt), ee += Dt.length), h(_, rt, A);
                var st = new u(E, z ? r.tokenize(ot, z) : ot, N, ot);
                if (P = f(_, rt, st), Gt && f(_, P, Gt), A > 1) {
                  var yt = {
                    cause: E + "," + B,
                    reach: wt
                  };
                  s(m, _, g, P.prev, ee, yt), w && yt.reach > w.reach && (w.reach = yt.reach);
                }
              }
            }
          }
        }
    }
    function d() {
      var m = { value: null, prev: null, next: null }, _ = { value: null, prev: m, next: null };
      m.next = _, this.head = m, this.tail = _, this.length = 0;
    }
    function f(m, _, g) {
      var D = _.next, b = { value: g, prev: _, next: D };
      return _.next = b, D.prev = b, m.length++, b;
    }
    function h(m, _, g) {
      for (var D = _.next, b = 0; b < g && D !== m.tail; b++)
        D = D.next;
      _.next = D, D.prev = _, m.length -= b;
    }
    function p(m) {
      for (var _ = [], g = m.head.next; g !== m.tail; )
        _.push(g.value), g = g.next;
      return _;
    }
    if (!n.document)
      return n.addEventListener && (r.disableWorkerMessageHandler || n.addEventListener("message", function(m) {
        var _ = JSON.parse(m.data), g = _.language, D = _.code, b = _.immediateClose;
        n.postMessage(r.highlight(D, r.languages[g], g)), b && n.close();
      }, !1)), r;
    var v = r.util.currentScript();
    v && (r.filename = v.src, v.hasAttribute("data-manual") && (r.manual = !0));
    function k() {
      r.manual || r.highlightAll();
    }
    if (!r.manual) {
      var C = document.readyState;
      C === "loading" || C === "interactive" && v && v.defer ? document.addEventListener("DOMContentLoaded", k) : window.requestAnimationFrame ? window.requestAnimationFrame(k) : window.setTimeout(k, 16);
    }
    return r;
  }(e);
  i.exports && (i.exports = t), typeof Ei < "u" && (Ei.Prism = t), t.languages.markup = {
    comment: {
      pattern: /<!--(?:(?!<!--)[\s\S])*?-->/,
      greedy: !0
    },
    prolog: {
      pattern: /<\?[\s\S]+?\?>/,
      greedy: !0
    },
    doctype: {
      // https://www.w3.org/TR/xml/#NT-doctypedecl
      pattern: /<!DOCTYPE(?:[^>"'[\]]|"[^"]*"|'[^']*')+(?:\[(?:[^<"'\]]|"[^"]*"|'[^']*'|<(?!!--)|<!--(?:[^-]|-(?!->))*-->)*\]\s*)?>/i,
      greedy: !0,
      inside: {
        "internal-subset": {
          pattern: /(^[^\[]*\[)[\s\S]+(?=\]>$)/,
          lookbehind: !0,
          greedy: !0,
          inside: null
          // see below
        },
        string: {
          pattern: /"[^"]*"|'[^']*'/,
          greedy: !0
        },
        punctuation: /^<!|>$|[[\]]/,
        "doctype-tag": /^DOCTYPE/i,
        name: /[^\s<>'"]+/
      }
    },
    cdata: {
      pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
      greedy: !0
    },
    tag: {
      pattern: /<\/?(?!\d)[^\s>\/=$<%]+(?:\s(?:\s*[^\s>\/=]+(?:\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))|(?=[\s/>])))+)?\s*\/?>/,
      greedy: !0,
      inside: {
        tag: {
          pattern: /^<\/?[^\s>\/]+/,
          inside: {
            punctuation: /^<\/?/,
            namespace: /^[^\s>\/:]+:/
          }
        },
        "special-attr": [],
        "attr-value": {
          pattern: /=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+)/,
          inside: {
            punctuation: [
              {
                pattern: /^=/,
                alias: "attr-equals"
              },
              {
                pattern: /^(\s*)["']|["']$/,
                lookbehind: !0
              }
            ]
          }
        },
        punctuation: /\/?>/,
        "attr-name": {
          pattern: /[^\s>\/]+/,
          inside: {
            namespace: /^[^\s>\/:]+:/
          }
        }
      }
    },
    entity: [
      {
        pattern: /&[\da-z]{1,8};/i,
        alias: "named-entity"
      },
      /&#x?[\da-f]{1,8};/i
    ]
  }, t.languages.markup.tag.inside["attr-value"].inside.entity = t.languages.markup.entity, t.languages.markup.doctype.inside["internal-subset"].inside = t.languages.markup, t.hooks.add("wrap", function(n) {
    n.type === "entity" && (n.attributes.title = n.content.replace(/&amp;/, "&"));
  }), Object.defineProperty(t.languages.markup.tag, "addInlined", {
    /**
     * Adds an inlined language to markup.
     *
     * An example of an inlined language is CSS with `<style>` tags.
     *
     * @param {string} tagName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addInlined('style', 'css');
     */
    value: function(l, a) {
      var o = {};
      o["language-" + a] = {
        pattern: /(^<!\[CDATA\[)[\s\S]+?(?=\]\]>$)/i,
        lookbehind: !0,
        inside: t.languages[a]
      }, o.cdata = /^<!\[CDATA\[|\]\]>$/i;
      var r = {
        "included-cdata": {
          pattern: /<!\[CDATA\[[\s\S]*?\]\]>/i,
          inside: o
        }
      };
      r["language-" + a] = {
        pattern: /[\s\S]+/,
        inside: t.languages[a]
      };
      var u = {};
      u[l] = {
        pattern: RegExp(/(<__[^>]*>)(?:<!\[CDATA\[(?:[^\]]|\](?!\]>))*\]\]>|(?!<!\[CDATA\[)[\s\S])*?(?=<\/__>)/.source.replace(/__/g, function() {
          return l;
        }), "i"),
        lookbehind: !0,
        greedy: !0,
        inside: r
      }, t.languages.insertBefore("markup", "cdata", u);
    }
  }), Object.defineProperty(t.languages.markup.tag, "addAttribute", {
    /**
     * Adds an pattern to highlight languages embedded in HTML attributes.
     *
     * An example of an inlined language is CSS with `style` attributes.
     *
     * @param {string} attrName The name of the tag that contains the inlined language. This name will be treated as
     * case insensitive.
     * @param {string} lang The language key.
     * @example
     * addAttribute('style', 'css');
     */
    value: function(n, l) {
      t.languages.markup.tag.inside["special-attr"].push({
        pattern: RegExp(
          /(^|["'\s])/.source + "(?:" + n + ")" + /\s*=\s*(?:"[^"]*"|'[^']*'|[^\s'">=]+(?=[\s>]))/.source,
          "i"
        ),
        lookbehind: !0,
        inside: {
          "attr-name": /^[^\s=]+/,
          "attr-value": {
            pattern: /=[\s\S]+/,
            inside: {
              value: {
                pattern: /(^=\s*(["']|(?!["'])))\S[\s\S]*(?=\2$)/,
                lookbehind: !0,
                alias: [l, "language-" + l],
                inside: t.languages[l]
              },
              punctuation: [
                {
                  pattern: /^=/,
                  alias: "attr-equals"
                },
                /"|'/
              ]
            }
          }
        }
      });
    }
  }), t.languages.html = t.languages.markup, t.languages.mathml = t.languages.markup, t.languages.svg = t.languages.markup, t.languages.xml = t.languages.extend("markup", {}), t.languages.ssml = t.languages.xml, t.languages.atom = t.languages.xml, t.languages.rss = t.languages.xml, function(n) {
    var l = /(?:"(?:\\(?:\r\n|[\s\S])|[^"\\\r\n])*"|'(?:\\(?:\r\n|[\s\S])|[^'\\\r\n])*')/;
    n.languages.css = {
      comment: /\/\*[\s\S]*?\*\//,
      atrule: {
        pattern: RegExp("@[\\w-](?:" + /[^;{\s"']|\s+(?!\s)/.source + "|" + l.source + ")*?" + /(?:;|(?=\s*\{))/.source),
        inside: {
          rule: /^@[\w-]+/,
          "selector-function-argument": {
            pattern: /(\bselector\s*\(\s*(?![\s)]))(?:[^()\s]|\s+(?![\s)])|\((?:[^()]|\([^()]*\))*\))+(?=\s*\))/,
            lookbehind: !0,
            alias: "selector"
          },
          keyword: {
            pattern: /(^|[^\w-])(?:and|not|only|or)(?![\w-])/,
            lookbehind: !0
          }
          // See rest below
        }
      },
      url: {
        // https://drafts.csswg.org/css-values-3/#urls
        pattern: RegExp("\\burl\\((?:" + l.source + "|" + /(?:[^\\\r\n()"']|\\[\s\S])*/.source + ")\\)", "i"),
        greedy: !0,
        inside: {
          function: /^url/i,
          punctuation: /^\(|\)$/,
          string: {
            pattern: RegExp("^" + l.source + "$"),
            alias: "url"
          }
        }
      },
      selector: {
        pattern: RegExp(`(^|[{}\\s])[^{}\\s](?:[^{};"'\\s]|\\s+(?![\\s{])|` + l.source + ")*(?=\\s*\\{)"),
        lookbehind: !0
      },
      string: {
        pattern: l,
        greedy: !0
      },
      property: {
        pattern: /(^|[^-\w\xA0-\uFFFF])(?!\s)[-_a-z\xA0-\uFFFF](?:(?!\s)[-\w\xA0-\uFFFF])*(?=\s*:)/i,
        lookbehind: !0
      },
      important: /!important\b/i,
      function: {
        pattern: /(^|[^-a-z0-9])[-a-z0-9]+(?=\()/i,
        lookbehind: !0
      },
      punctuation: /[(){};:,]/
    }, n.languages.css.atrule.inside.rest = n.languages.css;
    var a = n.languages.markup;
    a && (a.tag.addInlined("style", "css"), a.tag.addAttribute("style", "css"));
  }(t), t.languages.clike = {
    comment: [
      {
        pattern: /(^|[^\\])\/\*[\s\S]*?(?:\*\/|$)/,
        lookbehind: !0,
        greedy: !0
      },
      {
        pattern: /(^|[^\\:])\/\/.*/,
        lookbehind: !0,
        greedy: !0
      }
    ],
    string: {
      pattern: /(["'])(?:\\(?:\r\n|[\s\S])|(?!\1)[^\\\r\n])*\1/,
      greedy: !0
    },
    "class-name": {
      pattern: /(\b(?:class|extends|implements|instanceof|interface|new|trait)\s+|\bcatch\s+\()[\w.\\]+/i,
      lookbehind: !0,
      inside: {
        punctuation: /[.\\]/
      }
    },
    keyword: /\b(?:break|catch|continue|do|else|finally|for|function|if|in|instanceof|new|null|return|throw|try|while)\b/,
    boolean: /\b(?:false|true)\b/,
    function: /\b\w+(?=\()/,
    number: /\b0x[\da-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:e[+-]?\d+)?/i,
    operator: /[<>]=?|[!=]=?=?|--?|\+\+?|&&?|\|\|?|[?*/~^%]/,
    punctuation: /[{}[\];(),.:]/
  }, t.languages.javascript = t.languages.extend("clike", {
    "class-name": [
      t.languages.clike["class-name"],
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$A-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\.(?:constructor|prototype))/,
        lookbehind: !0
      }
    ],
    keyword: [
      {
        pattern: /((?:^|\})\s*)catch\b/,
        lookbehind: !0
      },
      {
        pattern: /(^|[^.]|\.\.\.\s*)\b(?:as|assert(?=\s*\{)|async(?=\s*(?:function\b|\(|[$\w\xA0-\uFFFF]|$))|await|break|case|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally(?=\s*(?:\{|$))|for|from(?=\s*(?:['"]|$))|function|(?:get|set)(?=\s*(?:[#\[$\w\xA0-\uFFFF]|$))|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)\b/,
        lookbehind: !0
      }
    ],
    // Allow for all non-ASCII characters (See http://stackoverflow.com/a/2008444)
    function: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*(?:\.\s*(?:apply|bind|call)\s*)?\()/,
    number: {
      pattern: RegExp(
        /(^|[^\w$])/.source + "(?:" + // constant
        (/NaN|Infinity/.source + "|" + // binary integer
        /0[bB][01]+(?:_[01]+)*n?/.source + "|" + // octal integer
        /0[oO][0-7]+(?:_[0-7]+)*n?/.source + "|" + // hexadecimal integer
        /0[xX][\dA-Fa-f]+(?:_[\dA-Fa-f]+)*n?/.source + "|" + // decimal bigint
        /\d+(?:_\d+)*n/.source + "|" + // decimal number (integer or float) but no bigint
        /(?:\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\.\d+(?:_\d+)*)(?:[Ee][+-]?\d+(?:_\d+)*)?/.source) + ")" + /(?![\w$])/.source
      ),
      lookbehind: !0
    },
    operator: /--|\+\+|\*\*=?|=>|&&=?|\|\|=?|[!=]==|<<=?|>>>?=?|[-+*/%&|^!=<>]=?|\.{3}|\?\?=?|\?\.?|[~:]/
  }), t.languages.javascript["class-name"][0].pattern = /(\b(?:class|extends|implements|instanceof|interface|new)\s+)[\w.\\]+/, t.languages.insertBefore("javascript", "keyword", {
    regex: {
      pattern: RegExp(
        // lookbehind
        // eslint-disable-next-line regexp/no-dupe-characters-character-class
        /((?:^|[^$\w\xA0-\uFFFF."'\])\s]|\b(?:return|yield))\s*)/.source + // Regex pattern:
        // There are 2 regex patterns here. The RegExp set notation proposal added support for nested character
        // classes if the `v` flag is present. Unfortunately, nested CCs are both context-free and incompatible
        // with the only syntax, so we have to define 2 different regex patterns.
        /\//.source + "(?:" + /(?:\[(?:[^\]\\\r\n]|\\.)*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}/.source + "|" + // `v` flag syntax. This supports 3 levels of nested character classes.
        /(?:\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.|\[(?:[^[\]\\\r\n]|\\.)*\])*\])*\]|\\.|[^/\\\[\r\n])+\/[dgimyus]{0,7}v[dgimyus]{0,7}/.source + ")" + // lookahead
        /(?=(?:\s|\/\*(?:[^*]|\*(?!\/))*\*\/)*(?:$|[\r\n,.;:})\]]|\/\/))/.source
      ),
      lookbehind: !0,
      greedy: !0,
      inside: {
        "regex-source": {
          pattern: /^(\/)[\s\S]+(?=\/[a-z]*$)/,
          lookbehind: !0,
          alias: "language-regex",
          inside: t.languages.regex
        },
        "regex-delimiter": /^\/|\/$/,
        "regex-flags": /^[a-z]+$/
      }
    },
    // This must be declared before keyword because we use "function" inside the look-forward
    "function-variable": {
      pattern: /#?(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*[=:]\s*(?:async\s*)?(?:\bfunction\b|(?:\((?:[^()]|\([^()]*\))*\)|(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)\s*=>))/,
      alias: "function"
    },
    parameter: [
      {
        pattern: /(function(?:\s+(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*)?\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\))/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(^|[^$\w\xA0-\uFFFF])(?!\s)[_$a-z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*=>)/i,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /(\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*=>)/,
        lookbehind: !0,
        inside: t.languages.javascript
      },
      {
        pattern: /((?:\b|\s|^)(?!(?:as|async|await|break|case|catch|class|const|continue|debugger|default|delete|do|else|enum|export|extends|finally|for|from|function|get|if|implements|import|in|instanceof|interface|let|new|null|of|package|private|protected|public|return|set|static|super|switch|this|throw|try|typeof|undefined|var|void|while|with|yield)(?![$\w\xA0-\uFFFF]))(?:(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*\s*)\(\s*|\]\s*\(\s*)(?!\s)(?:[^()\s]|\s+(?![\s)])|\([^()]*\))+(?=\s*\)\s*\{)/,
        lookbehind: !0,
        inside: t.languages.javascript
      }
    ],
    constant: /\b[A-Z](?:[A-Z_]|\dx?)*\b/
  }), t.languages.insertBefore("javascript", "string", {
    hashbang: {
      pattern: /^#!.*/,
      greedy: !0,
      alias: "comment"
    },
    "template-string": {
      pattern: /`(?:\\[\s\S]|\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}|(?!\$\{)[^\\`])*`/,
      greedy: !0,
      inside: {
        "template-punctuation": {
          pattern: /^`|`$/,
          alias: "string"
        },
        interpolation: {
          pattern: /((?:^|[^\\])(?:\\{2})*)\$\{(?:[^{}]|\{(?:[^{}]|\{[^}]*\})*\})+\}/,
          lookbehind: !0,
          inside: {
            "interpolation-punctuation": {
              pattern: /^\$\{|\}$/,
              alias: "punctuation"
            },
            rest: t.languages.javascript
          }
        },
        string: /[\s\S]+/
      }
    },
    "string-property": {
      pattern: /((?:^|[,{])[ \t]*)(["'])(?:\\(?:\r\n|[\s\S])|(?!\2)[^\\\r\n])*\2(?=\s*:)/m,
      lookbehind: !0,
      greedy: !0,
      alias: "property"
    }
  }), t.languages.insertBefore("javascript", "operator", {
    "literal-property": {
      pattern: /((?:^|[,{])[ \t]*)(?!\s)[_$a-zA-Z\xA0-\uFFFF](?:(?!\s)[$\w\xA0-\uFFFF])*(?=\s*:)/m,
      lookbehind: !0,
      alias: "property"
    }
  }), t.languages.markup && (t.languages.markup.tag.addInlined("script", "javascript"), t.languages.markup.tag.addAttribute(
    /on(?:abort|blur|change|click|composition(?:end|start|update)|dblclick|error|focus(?:in|out)?|key(?:down|up)|load|mouse(?:down|enter|leave|move|out|over|up)|reset|resize|scroll|select|slotchange|submit|unload|wheel)/.source,
    "javascript"
  )), t.languages.js = t.languages.javascript, function() {
    if (typeof t > "u" || typeof document > "u")
      return;
    Element.prototype.matches || (Element.prototype.matches = Element.prototype.msMatchesSelector || Element.prototype.webkitMatchesSelector);
    var n = "Loading…", l = function(v, k) {
      return "✖ Error " + v + " while fetching file: " + k;
    }, a = "✖ Error: File does not exist or is empty", o = {
      js: "javascript",
      py: "python",
      rb: "ruby",
      ps1: "powershell",
      psm1: "powershell",
      sh: "bash",
      bat: "batch",
      h: "c",
      tex: "latex"
    }, r = "data-src-status", u = "loading", c = "loaded", s = "failed", d = "pre[data-src]:not([" + r + '="' + c + '"]):not([' + r + '="' + u + '"])';
    function f(v, k, C) {
      var m = new XMLHttpRequest();
      m.open("GET", v, !0), m.onreadystatechange = function() {
        m.readyState == 4 && (m.status < 400 && m.responseText ? k(m.responseText) : m.status >= 400 ? C(l(m.status, m.statusText)) : C(a));
      }, m.send(null);
    }
    function h(v) {
      var k = /^\s*(\d+)\s*(?:(,)\s*(?:(\d+)\s*)?)?$/.exec(v || "");
      if (k) {
        var C = Number(k[1]), m = k[2], _ = k[3];
        return m ? _ ? [C, Number(_)] : [C, void 0] : [C, C];
      }
    }
    t.hooks.add("before-highlightall", function(v) {
      v.selector += ", " + d;
    }), t.hooks.add("before-sanity-check", function(v) {
      var k = (
        /** @type {HTMLPreElement} */
        v.element
      );
      if (k.matches(d)) {
        v.code = "", k.setAttribute(r, u);
        var C = k.appendChild(document.createElement("CODE"));
        C.textContent = n;
        var m = k.getAttribute("data-src"), _ = v.language;
        if (_ === "none") {
          var g = (/\.(\w+)$/.exec(m) || [, "none"])[1];
          _ = o[g] || g;
        }
        t.util.setLanguage(C, _), t.util.setLanguage(k, _);
        var D = t.plugins.autoloader;
        D && D.loadLanguages(_), f(
          m,
          function(b) {
            k.setAttribute(r, c);
            var w = h(k.getAttribute("data-range"));
            if (w) {
              var E = b.split(/\r\n?|\n/g), y = w[0], B = w[1] == null ? E.length : w[1];
              y < 0 && (y += E.length), y = Math.max(0, Math.min(y - 1, E.length)), B < 0 && (B += E.length), B = Math.max(0, Math.min(B, E.length)), b = E.slice(y, B).join(`
`), k.hasAttribute("data-start") || k.setAttribute("data-start", String(y + 1));
            }
            C.textContent = b, t.highlightElement(C);
          },
          function(b) {
            k.setAttribute(r, s), C.textContent = b;
          }
        );
      }
    }), t.plugins.fileHighlight = {
      /**
       * Executes the File Highlight plugin for all matching `pre` elements under the given container.
       *
       * Note: Elements which are already loaded or currently loading will not be touched by this method.
       *
       * @param {ParentNode} [container=document]
       */
      highlight: function(k) {
        for (var C = (k || document).querySelectorAll(d), m = 0, _; _ = C[m++]; )
          t.highlightElement(_);
      }
    };
    var p = !1;
    t.fileHighlight = function() {
      p || (console.warn("Prism.fileHighlight is deprecated. Use `Prism.plugins.fileHighlight.highlight` instead."), p = !0), t.plugins.fileHighlight.highlight.apply(this, arguments);
    };
  }();
})(ia);
var $n = ia.exports;
Prism.languages.python = {
  comment: {
    pattern: /(^|[^\\])#.*/,
    lookbehind: !0,
    greedy: !0
  },
  "string-interpolation": {
    pattern: /(?:f|fr|rf)(?:("""|''')[\s\S]*?\1|("|')(?:\\.|(?!\2)[^\\\r\n])*\2)/i,
    greedy: !0,
    inside: {
      interpolation: {
        // "{" <expression> <optional "!s", "!r", or "!a"> <optional ":" format specifier> "}"
        pattern: /((?:^|[^{])(?:\{\{)*)\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}]|\{(?!\{)(?:[^{}])+\})+\})+\}/,
        lookbehind: !0,
        inside: {
          "format-spec": {
            pattern: /(:)[^:(){}]+(?=\}$)/,
            lookbehind: !0
          },
          "conversion-option": {
            pattern: /![sra](?=[:}]$)/,
            alias: "punctuation"
          },
          rest: null
        }
      },
      string: /[\s\S]+/
    }
  },
  "triple-quoted-string": {
    pattern: /(?:[rub]|br|rb)?("""|''')[\s\S]*?\1/i,
    greedy: !0,
    alias: "string"
  },
  string: {
    pattern: /(?:[rub]|br|rb)?("|')(?:\\.|(?!\1)[^\\\r\n])*\1/i,
    greedy: !0
  },
  function: {
    pattern: /((?:^|\s)def[ \t]+)[a-zA-Z_]\w*(?=\s*\()/g,
    lookbehind: !0
  },
  "class-name": {
    pattern: /(\bclass\s+)\w+/i,
    lookbehind: !0
  },
  decorator: {
    pattern: /(^[\t ]*)@\w+(?:\.\w+)*/m,
    lookbehind: !0,
    alias: ["annotation", "punctuation"],
    inside: {
      punctuation: /\./
    }
  },
  keyword: /\b(?:_(?=\s*:)|and|as|assert|async|await|break|case|class|continue|def|del|elif|else|except|exec|finally|for|from|global|if|import|in|is|lambda|match|nonlocal|not|or|pass|print|raise|return|try|while|with|yield)\b/,
  builtin: /\b(?:__import__|abs|all|any|apply|ascii|basestring|bin|bool|buffer|bytearray|bytes|callable|chr|classmethod|cmp|coerce|compile|complex|delattr|dict|dir|divmod|enumerate|eval|execfile|file|filter|float|format|frozenset|getattr|globals|hasattr|hash|help|hex|id|input|int|intern|isinstance|issubclass|iter|len|list|locals|long|map|max|memoryview|min|next|object|oct|open|ord|pow|property|range|raw_input|reduce|reload|repr|reversed|round|set|setattr|slice|sorted|staticmethod|str|sum|super|tuple|type|unichr|unicode|vars|xrange|zip)\b/,
  boolean: /\b(?:False|None|True)\b/,
  number: /\b0(?:b(?:_?[01])+|o(?:_?[0-7])+|x(?:_?[a-f0-9])+)\b|(?:\b\d+(?:_\d+)*(?:\.(?:\d+(?:_\d+)*)?)?|\B\.\d+(?:_\d+)*)(?:e[+-]?\d+(?:_\d+)*)?j?(?!\w)/i,
  operator: /[-+%=]=?|!=|:=|\*\*?=?|\/\/?=?|<[<=>]?|>[=>]?|[&|^~]/,
  punctuation: /[{}[\];(),.:]/
};
Prism.languages.python["string-interpolation"].inside.interpolation.inside.rest = Prism.languages.python;
Prism.languages.py = Prism.languages.python;
(function(i) {
  var e = /\\(?:[^a-z()[\]]|[a-z*]+)/i, t = {
    "equation-command": {
      pattern: e,
      alias: "regex"
    }
  };
  i.languages.latex = {
    comment: /%.*/,
    // the verbatim environment prints whitespace to the document
    cdata: {
      pattern: /(\\begin\{((?:lstlisting|verbatim)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
      lookbehind: !0
    },
    /*
     * equations can be between $$ $$ or $ $ or \( \) or \[ \]
     * (all are multiline)
     */
    equation: [
      {
        pattern: /\$\$(?:\\[\s\S]|[^\\$])+\$\$|\$(?:\\[\s\S]|[^\\$])+\$|\\\([\s\S]*?\\\)|\\\[[\s\S]*?\\\]/,
        inside: t,
        alias: "string"
      },
      {
        pattern: /(\\begin\{((?:align|eqnarray|equation|gather|math|multline)\*?)\})[\s\S]*?(?=\\end\{\2\})/,
        lookbehind: !0,
        inside: t,
        alias: "string"
      }
    ],
    /*
     * arguments which are keywords or references are highlighted
     * as keywords
     */
    keyword: {
      pattern: /(\\(?:begin|cite|documentclass|end|label|ref|usepackage)(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    url: {
      pattern: /(\\url\{)[^}]+(?=\})/,
      lookbehind: !0
    },
    /*
     * section or chapter headlines are highlighted as bold so that
     * they stand out more
     */
    headline: {
      pattern: /(\\(?:chapter|frametitle|paragraph|part|section|subparagraph|subsection|subsubparagraph|subsubsection|subsubsubparagraph)\*?(?:\[[^\]]+\])?\{)[^}]+(?=\})/,
      lookbehind: !0,
      alias: "class-name"
    },
    function: {
      pattern: e,
      alias: "selector"
    },
    punctuation: /[[\]{}&]/
  }, i.languages.tex = i.languages.latex, i.languages.context = i.languages.latex;
})(Prism);
(function(i) {
  var e = "\\b(?:BASH|BASHOPTS|BASH_ALIASES|BASH_ARGC|BASH_ARGV|BASH_CMDS|BASH_COMPLETION_COMPAT_DIR|BASH_LINENO|BASH_REMATCH|BASH_SOURCE|BASH_VERSINFO|BASH_VERSION|COLORTERM|COLUMNS|COMP_WORDBREAKS|DBUS_SESSION_BUS_ADDRESS|DEFAULTS_PATH|DESKTOP_SESSION|DIRSTACK|DISPLAY|EUID|GDMSESSION|GDM_LANG|GNOME_KEYRING_CONTROL|GNOME_KEYRING_PID|GPG_AGENT_INFO|GROUPS|HISTCONTROL|HISTFILE|HISTFILESIZE|HISTSIZE|HOME|HOSTNAME|HOSTTYPE|IFS|INSTANCE|JOB|LANG|LANGUAGE|LC_ADDRESS|LC_ALL|LC_IDENTIFICATION|LC_MEASUREMENT|LC_MONETARY|LC_NAME|LC_NUMERIC|LC_PAPER|LC_TELEPHONE|LC_TIME|LESSCLOSE|LESSOPEN|LINES|LOGNAME|LS_COLORS|MACHTYPE|MAILCHECK|MANDATORY_PATH|NO_AT_BRIDGE|OLDPWD|OPTERR|OPTIND|ORBIT_SOCKETDIR|OSTYPE|PAPERSIZE|PATH|PIPESTATUS|PPID|PS1|PS2|PS3|PS4|PWD|RANDOM|REPLY|SECONDS|SELINUX_INIT|SESSION|SESSIONTYPE|SESSION_MANAGER|SHELL|SHELLOPTS|SHLVL|SSH_AUTH_SOCK|TERM|UID|UPSTART_EVENTS|UPSTART_INSTANCE|UPSTART_JOB|UPSTART_SESSION|USER|WINDOWID|XAUTHORITY|XDG_CONFIG_DIRS|XDG_CURRENT_DESKTOP|XDG_DATA_DIRS|XDG_GREETER_DATA_DIR|XDG_MENU_PREFIX|XDG_RUNTIME_DIR|XDG_SEAT|XDG_SEAT_PATH|XDG_SESSION_DESKTOP|XDG_SESSION_ID|XDG_SESSION_PATH|XDG_SESSION_TYPE|XDG_VTNR|XMODIFIERS)\\b", t = {
    pattern: /(^(["']?)\w+\2)[ \t]+\S.*/,
    lookbehind: !0,
    alias: "punctuation",
    // this looks reasonably well in all themes
    inside: null
    // see below
  }, n = {
    bash: t,
    environment: {
      pattern: RegExp("\\$" + e),
      alias: "constant"
    },
    variable: [
      // [0]: Arithmetic Environment
      {
        pattern: /\$?\(\([\s\S]+?\)\)/,
        greedy: !0,
        inside: {
          // If there is a $ sign at the beginning highlight $(( and )) as variable
          variable: [
            {
              pattern: /(^\$\(\([\s\S]+)\)\)/,
              lookbehind: !0
            },
            /^\$\(\(/
          ],
          number: /\b0x[\dA-Fa-f]+\b|(?:\b\d+(?:\.\d*)?|\B\.\d+)(?:[Ee]-?\d+)?/,
          // Operators according to https://www.gnu.org/software/bash/manual/bashref.html#Shell-Arithmetic
          operator: /--|\+\+|\*\*=?|<<=?|>>=?|&&|\|\||[=!+\-*/%<>^&|]=?|[?~:]/,
          // If there is no $ sign at the beginning highlight (( and )) as punctuation
          punctuation: /\(\(?|\)\)?|,|;/
        }
      },
      // [1]: Command Substitution
      {
        pattern: /\$\((?:\([^)]+\)|[^()])+\)|`[^`]+`/,
        greedy: !0,
        inside: {
          variable: /^\$\(|^`|\)$|`$/
        }
      },
      // [2]: Brace expansion
      {
        pattern: /\$\{[^}]+\}/,
        greedy: !0,
        inside: {
          operator: /:[-=?+]?|[!\/]|##?|%%?|\^\^?|,,?/,
          punctuation: /[\[\]]/,
          environment: {
            pattern: RegExp("(\\{)" + e),
            lookbehind: !0,
            alias: "constant"
          }
        }
      },
      /\$(?:\w+|[#?*!@$])/
    ],
    // Escape sequences from echo and printf's manuals, and escaped quotes.
    entity: /\\(?:[abceEfnrtv\\"]|O?[0-7]{1,3}|U[0-9a-fA-F]{8}|u[0-9a-fA-F]{4}|x[0-9a-fA-F]{1,2})/
  };
  i.languages.bash = {
    shebang: {
      pattern: /^#!\s*\/.*/,
      alias: "important"
    },
    comment: {
      pattern: /(^|[^"{\\$])#.*/,
      lookbehind: !0
    },
    "function-name": [
      // a) function foo {
      // b) foo() {
      // c) function foo() {
      // but not “foo {”
      {
        // a) and c)
        pattern: /(\bfunction\s+)[\w-]+(?=(?:\s*\(?:\s*\))?\s*\{)/,
        lookbehind: !0,
        alias: "function"
      },
      {
        // b)
        pattern: /\b[\w-]+(?=\s*\(\s*\)\s*\{)/,
        alias: "function"
      }
    ],
    // Highlight variable names as variables in for and select beginnings.
    "for-or-select": {
      pattern: /(\b(?:for|select)\s+)\w+(?=\s+in\s)/,
      alias: "variable",
      lookbehind: !0
    },
    // Highlight variable names as variables in the left-hand part
    // of assignments (“=” and “+=”).
    "assign-left": {
      pattern: /(^|[\s;|&]|[<>]\()\w+(?:\.\w+)*(?=\+?=)/,
      inside: {
        environment: {
          pattern: RegExp("(^|[\\s;|&]|[<>]\\()" + e),
          lookbehind: !0,
          alias: "constant"
        }
      },
      alias: "variable",
      lookbehind: !0
    },
    // Highlight parameter names as variables
    parameter: {
      pattern: /(^|\s)-{1,2}(?:\w+:[+-]?)?\w+(?:\.\w+)*(?=[=\s]|$)/,
      alias: "variable",
      lookbehind: !0
    },
    string: [
      // Support for Here-documents https://en.wikipedia.org/wiki/Here_document
      {
        pattern: /((?:^|[^<])<<-?\s*)(\w+)\s[\s\S]*?(?:\r?\n|\r)\2/,
        lookbehind: !0,
        greedy: !0,
        inside: n
      },
      // Here-document with quotes around the tag
      // → No expansion (so no “inside”).
      {
        pattern: /((?:^|[^<])<<-?\s*)(["'])(\w+)\2\s[\s\S]*?(?:\r?\n|\r)\3/,
        lookbehind: !0,
        greedy: !0,
        inside: {
          bash: t
        }
      },
      // “Normal” string
      {
        // https://www.gnu.org/software/bash/manual/html_node/Double-Quotes.html
        pattern: /(^|[^\\](?:\\\\)*)"(?:\\[\s\S]|\$\([^)]+\)|\$(?!\()|`[^`]+`|[^"\\`$])*"/,
        lookbehind: !0,
        greedy: !0,
        inside: n
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/Single-Quotes.html
        pattern: /(^|[^$\\])'[^']*'/,
        lookbehind: !0,
        greedy: !0
      },
      {
        // https://www.gnu.org/software/bash/manual/html_node/ANSI_002dC-Quoting.html
        pattern: /\$'(?:[^'\\]|\\[\s\S])*'/,
        greedy: !0,
        inside: {
          entity: n.entity
        }
      }
    ],
    environment: {
      pattern: RegExp("\\$?" + e),
      alias: "constant"
    },
    variable: n.variable,
    function: {
      pattern: /(^|[\s;|&]|[<>]\()(?:add|apropos|apt|apt-cache|apt-get|aptitude|aspell|automysqlbackup|awk|basename|bash|bc|bconsole|bg|bzip2|cal|cargo|cat|cfdisk|chgrp|chkconfig|chmod|chown|chroot|cksum|clear|cmp|column|comm|composer|cp|cron|crontab|csplit|curl|cut|date|dc|dd|ddrescue|debootstrap|df|diff|diff3|dig|dir|dircolors|dirname|dirs|dmesg|docker|docker-compose|du|egrep|eject|env|ethtool|expand|expect|expr|fdformat|fdisk|fg|fgrep|file|find|fmt|fold|format|free|fsck|ftp|fuser|gawk|git|gparted|grep|groupadd|groupdel|groupmod|groups|grub-mkconfig|gzip|halt|head|hg|history|host|hostname|htop|iconv|id|ifconfig|ifdown|ifup|import|install|ip|java|jobs|join|kill|killall|less|link|ln|locate|logname|logrotate|look|lpc|lpr|lprint|lprintd|lprintq|lprm|ls|lsof|lynx|make|man|mc|mdadm|mkconfig|mkdir|mke2fs|mkfifo|mkfs|mkisofs|mknod|mkswap|mmv|more|most|mount|mtools|mtr|mutt|mv|nano|nc|netstat|nice|nl|node|nohup|notify-send|npm|nslookup|op|open|parted|passwd|paste|pathchk|ping|pkill|pnpm|podman|podman-compose|popd|pr|printcap|printenv|ps|pushd|pv|quota|quotacheck|quotactl|ram|rar|rcp|reboot|remsync|rename|renice|rev|rm|rmdir|rpm|rsync|scp|screen|sdiff|sed|sendmail|seq|service|sftp|sh|shellcheck|shuf|shutdown|sleep|slocate|sort|split|ssh|stat|strace|su|sudo|sum|suspend|swapon|sync|sysctl|tac|tail|tar|tee|time|timeout|top|touch|tr|traceroute|tsort|tty|umount|uname|unexpand|uniq|units|unrar|unshar|unzip|update-grub|uptime|useradd|userdel|usermod|users|uudecode|uuencode|v|vcpkg|vdir|vi|vim|virsh|vmstat|wait|watch|wc|wget|whereis|which|who|whoami|write|xargs|xdg-open|yarn|yes|zenity|zip|zsh|zypper)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    keyword: {
      pattern: /(^|[\s;|&]|[<>]\()(?:case|do|done|elif|else|esac|fi|for|function|if|in|select|then|until|while)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    // https://www.gnu.org/software/bash/manual/html_node/Shell-Builtin-Commands.html
    builtin: {
      pattern: /(^|[\s;|&]|[<>]\()(?:\.|:|alias|bind|break|builtin|caller|cd|command|continue|declare|echo|enable|eval|exec|exit|export|getopts|hash|help|let|local|logout|mapfile|printf|pwd|read|readarray|readonly|return|set|shift|shopt|source|test|times|trap|type|typeset|ulimit|umask|unalias|unset)(?=$|[)\s;|&])/,
      lookbehind: !0,
      // Alias added to make those easier to distinguish from strings.
      alias: "class-name"
    },
    boolean: {
      pattern: /(^|[\s;|&]|[<>]\()(?:false|true)(?=$|[)\s;|&])/,
      lookbehind: !0
    },
    "file-descriptor": {
      pattern: /\B&\d\b/,
      alias: "important"
    },
    operator: {
      // Lots of redirections here, but not just that.
      pattern: /\d?<>|>\||\+=|=[=~]?|!=?|<<[<-]?|[&\d]?>>|\d[<>]&?|[<>][&=]?|&[>&]?|\|[&|]?/,
      inside: {
        "file-descriptor": {
          pattern: /^\d/,
          alias: "important"
        }
      }
    },
    punctuation: /\$?\(\(?|\)\)?|\.\.|[{}[\];\\]/,
    number: {
      pattern: /(^|\s)(?:[1-9]\d*|0)(?:[.,]\d+)?\b/,
      lookbehind: !0
    }
  }, t.inside = i.languages.bash;
  for (var l = [
    "comment",
    "function-name",
    "for-or-select",
    "assign-left",
    "parameter",
    "string",
    "environment",
    "function",
    "keyword",
    "builtin",
    "boolean",
    "file-descriptor",
    "operator",
    "punctuation",
    "number"
  ], a = n.variable[1].inside, o = 0; o < l.length; o++)
    a[l[o]] = i.languages.bash[l[o]];
  i.languages.sh = i.languages.bash, i.languages.shell = i.languages.bash;
})(Prism);
const ir = '<svg class="md-link-icon" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true" fill="currentColor"><path d="m7.775 3.275 1.25-1.25a3.5 3.5 0 1 1 4.95 4.95l-2.5 2.5a3.5 3.5 0 0 1-4.95 0 .751.751 0 0 1 .018-1.042.751.751 0 0 1 1.042-.018 1.998 1.998 0 0 0 2.83 0l2.5-2.5a2.002 2.002 0 0 0-2.83-2.83l-1.25 1.25a.751.751 0 0 1-1.042-.018.751.751 0 0 1-.018-1.042Zm-4.69 9.64a1.998 1.998 0 0 0 2.83 0l1.25-1.25a.751.751 0 0 1 1.042.018.751.751 0 0 1 .018 1.042l-1.25 1.25a3.5 3.5 0 1 1-4.95-4.95l2.5-2.5a3.5 3.5 0 0 1 4.95 0 .751.751 0 0 1-.018 1.042.751.751 0 0 1-1.042.018 1.998 1.998 0 0 0-2.83 0l-2.5 2.5a1.998 1.998 0 0 0 0 2.83Z"></path></svg>', lr = `
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 15 15" color="currentColor" aria-hidden="true" aria-label="Copy" stroke-width="1.3" width="15" height="15">
  <path fill="currentColor" d="M12.728 4.545v8.182H4.545V4.545zm0 -0.909H4.545a0.909 0.909 0 0 0 -0.909 0.909v8.182a0.909 0.909 0 0 0 0.909 0.909h8.182a0.909 0.909 0 0 0 0.909 -0.909V4.545a0.909 0.909 0 0 0 -0.909 -0.909"/>
  <path fill="currentColor" d="M1.818 8.182H0.909V1.818a0.909 0.909 0 0 1 0.909 -0.909h6.364v0.909H1.818Z"/>
</svg>

`, ar = `<svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 17 17" aria-hidden="true" aria-label="Copied" fill="none" stroke="currentColor" stroke-width="1.3">
  <path d="m13.813 4.781 -7.438 7.438 -3.188 -3.188"/>
</svg>
`, Ai = `<button title="copy" class="copy_code_button">
  <span class="copy-text">${lr}</span>
  <span class="check">${ar}</span>
</button>`, la = /[&<>"']/, or = new RegExp(la.source, "g"), aa = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, rr = new RegExp(aa.source, "g"), sr = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, Si = (i) => sr[i] || "";
function Cn(i, e) {
  if (e) {
    if (la.test(i))
      return i.replace(or, Si);
  } else if (aa.test(i))
    return i.replace(rr, Si);
  return i;
}
function ur(i) {
  const e = i.map((t) => ({
    start: new RegExp(t.left.replace(/[-\/\\^$*+?.()|[\]{}]/g, "\\$&")),
    end: new RegExp(t.right.replace(/[-\/\\^$*+?.()|[\]{}]/g, "\\$&"))
  }));
  return {
    name: "latex",
    level: "block",
    start(t) {
      for (const n of e) {
        const l = t.match(n.start);
        if (l)
          return l.index;
      }
      return -1;
    },
    tokenizer(t, n) {
      for (const l of e) {
        const a = new RegExp(
          `${l.start.source}([\\s\\S]+?)${l.end.source}`
        ).exec(t);
        if (a)
          return {
            type: "latex",
            raw: a[0],
            text: a[1].trim()
          };
      }
    },
    renderer(t) {
      return `<div class="latex-block">${t.text}</div>`;
    }
  };
}
function cr() {
  return {
    name: "mermaid",
    level: "block",
    start(i) {
      var e;
      return (e = i.match(/^```mermaid\s*\n/)) == null ? void 0 : e.index;
    },
    tokenizer(i) {
      const e = /^```mermaid\s*\n([\s\S]*?)```\s*(?:\n|$)/.exec(i);
      if (e)
        return {
          type: "mermaid",
          raw: e[0],
          text: e[1].trim()
        };
    },
    renderer(i) {
      return `<div class="mermaid">${i.text}</div>
`;
    }
  };
}
const _r = {
  code(i, e, t) {
    var l;
    const n = ((l = (e ?? "").match(/\S*/)) == null ? void 0 : l[0]) ?? "";
    return i = i.replace(/\n$/, "") + `
`, !n || n === "mermaid" ? '<div class="code_wrap">' + Ai + "<pre><code>" + (t ? i : Cn(i, !0)) + `</code></pre></div>
` : '<div class="code_wrap">' + Ai + '<pre><code class="language-' + Cn(n) + '">' + (t ? i : Cn(i, !0)) + `</code></pre></div>
`;
  }
}, dr = new ri();
function fr({
  header_links: i,
  line_breaks: e,
  latex_delimiters: t
}) {
  const n = new Kl();
  n.use(
    {
      gfm: !0,
      pedantic: !1,
      breaks: e
    },
    Xo({
      highlight: (o, r) => {
        var u;
        return (u = $n.languages) != null && u[r] ? $n.highlight(o, $n.languages[r], r) : o;
      }
    }),
    { renderer: _r }
  ), i && (n.use(tr()), n.use({
    extensions: [
      {
        name: "heading",
        level: "block",
        renderer(o) {
          const r = o.raw.toLowerCase().trim().replace(/<[!\/a-z].*?>/gi, ""), u = "h" + dr.slug(r), c = o.depth, s = this.parser.parseInline(o.tokens);
          return `<h${c} id="${u}"><a class="md-header-anchor" href="#${u}">${ir}</a>${s}</h${c}>
`;
        }
      }
    ]
  }));
  const l = cr(), a = ur(t);
  return n.use({
    extensions: [l, a]
  }), n;
}
const Gn = (i) => JSON.parse(JSON.stringify(i)), hr = (i) => i.nodeType === 1, pr = (i) => Ir.has(i.tagName), mr = (i) => "action" in i, gr = (i) => i.tagName === "IFRAME", br = (i) => "formAction" in i, vr = (i) => "protocol" in i, Kt = /* @__PURE__ */ (() => {
  const i = /^(?:\w+script|data):/i;
  return (e) => i.test(e);
})(), Dr = /* @__PURE__ */ (() => {
  const i = /(?:script|data):/i;
  return (e) => i.test(e);
})(), wr = (i) => {
  const e = {};
  for (let t = 0, n = i.length; t < n; t++) {
    const l = i[t];
    for (const a in l)
      e[a] ? e[a] = e[a].concat(l[a]) : e[a] = l[a];
  }
  return e;
}, oa = (i, e) => {
  let t = i.firstChild;
  for (; t; ) {
    const n = t.nextSibling;
    hr(t) && (e(t, i), t.parentNode && oa(t, e)), t = n;
  }
}, yr = (i, e) => {
  const t = document.createNodeIterator(i, NodeFilter.SHOW_ELEMENT);
  let n;
  for (; n = t.nextNode(); ) {
    const l = n.parentNode;
    l && e(n, l);
  }
}, kr = (i, e) => !!globalThis.document && !!globalThis.document.createNodeIterator ? yr(i, e) : oa(i, e), ra = [
  "a",
  "abbr",
  "acronym",
  "address",
  "area",
  "article",
  "aside",
  "audio",
  "b",
  "bdi",
  "bdo",
  "bgsound",
  "big",
  "blockquote",
  "body",
  "br",
  "button",
  "canvas",
  "caption",
  "center",
  "cite",
  "code",
  "col",
  "colgroup",
  "datalist",
  "dd",
  "del",
  "details",
  "dfn",
  "dialog",
  "dir",
  "div",
  "dl",
  "dt",
  "em",
  "fieldset",
  "figcaption",
  "figure",
  "font",
  "footer",
  "form",
  "h1",
  "h2",
  "h3",
  "h4",
  "h5",
  "h6",
  "head",
  "header",
  "hgroup",
  "hr",
  "html",
  "i",
  "img",
  "input",
  "ins",
  "kbd",
  "keygen",
  "label",
  "layer",
  "legend",
  "li",
  "link",
  "listing",
  "main",
  "map",
  "mark",
  "marquee",
  "menu",
  "meta",
  "meter",
  "nav",
  "nobr",
  "ol",
  "optgroup",
  "option",
  "output",
  "p",
  "picture",
  "popup",
  "pre",
  "progress",
  "q",
  "rb",
  "rp",
  "rt",
  "rtc",
  "ruby",
  "s",
  "samp",
  "section",
  "select",
  "selectmenu",
  "small",
  "source",
  "span",
  "strike",
  "strong",
  "style",
  "sub",
  "summary",
  "sup",
  "table",
  "tbody",
  "td",
  "tfoot",
  "th",
  "thead",
  "time",
  "tr",
  "track",
  "tt",
  "u",
  "ul",
  "var",
  "video",
  "wbr"
], Fr = [
  "basefont",
  "command",
  "data",
  "iframe",
  "image",
  "plaintext",
  "portal",
  "slot",
  // 'template', //TODO: Not exactly correct to never allow this, too strict
  "textarea",
  "title",
  "xmp"
], $r = /* @__PURE__ */ new Set([
  ...ra,
  ...Fr
]), sa = [
  "svg",
  "a",
  "altglyph",
  "altglyphdef",
  "altglyphitem",
  "animatecolor",
  "animatemotion",
  "animatetransform",
  "circle",
  "clippath",
  "defs",
  "desc",
  "ellipse",
  "filter",
  "font",
  "g",
  "glyph",
  "glyphref",
  "hkern",
  "image",
  "line",
  "lineargradient",
  "marker",
  "mask",
  "metadata",
  "mpath",
  "path",
  "pattern",
  "polygon",
  "polyline",
  "radialgradient",
  "rect",
  "stop",
  "style",
  "switch",
  "symbol",
  "text",
  "textpath",
  "title",
  "tref",
  "tspan",
  "view",
  "vkern",
  /* FILTERS */
  "feBlend",
  "feColorMatrix",
  "feComponentTransfer",
  "feComposite",
  "feConvolveMatrix",
  "feDiffuseLighting",
  "feDisplacementMap",
  "feDistantLight",
  "feFlood",
  "feFuncA",
  "feFuncB",
  "feFuncG",
  "feFuncR",
  "feGaussianBlur",
  "feImage",
  "feMerge",
  "feMergeNode",
  "feMorphology",
  "feOffset",
  "fePointLight",
  "feSpecularLighting",
  "feSpotLight",
  "feTile",
  "feTurbulence"
], Cr = [
  "animate",
  "color-profile",
  "cursor",
  "discard",
  "fedropshadow",
  "font-face",
  "font-face-format",
  "font-face-name",
  "font-face-src",
  "font-face-uri",
  "foreignobject",
  "hatch",
  "hatchpath",
  "mesh",
  "meshgradient",
  "meshpatch",
  "meshrow",
  "missing-glyph",
  "script",
  "set",
  "solidcolor",
  "unknown",
  "use"
], Er = /* @__PURE__ */ new Set([
  ...sa,
  ...Cr
]), ua = [
  "math",
  "menclose",
  "merror",
  "mfenced",
  "mfrac",
  "mglyph",
  "mi",
  "mlabeledtr",
  "mmultiscripts",
  "mn",
  "mo",
  "mover",
  "mpadded",
  "mphantom",
  "mroot",
  "mrow",
  "ms",
  "mspace",
  "msqrt",
  "mstyle",
  "msub",
  "msup",
  "msubsup",
  "mtable",
  "mtd",
  "mtext",
  "mtr",
  "munder",
  "munderover"
], Ar = [
  "maction",
  "maligngroup",
  "malignmark",
  "mlongdiv",
  "mscarries",
  "mscarry",
  "msgroup",
  "mstack",
  "msline",
  "msrow",
  "semantics",
  "annotation",
  "annotation-xml",
  "mprescripts",
  "none"
], Sr = /* @__PURE__ */ new Set([
  ...ua,
  ...Ar
]), Br = [
  "abbr",
  "accept",
  "accept-charset",
  "accesskey",
  "action",
  "align",
  "alink",
  "allow",
  "allowfullscreen",
  "alt",
  "anchor",
  "archive",
  "as",
  "async",
  "autocapitalize",
  "autocomplete",
  "autocorrect",
  "autofocus",
  "autopictureinpicture",
  "autoplay",
  "axis",
  "background",
  "behavior",
  "bgcolor",
  "border",
  "bordercolor",
  "capture",
  "cellpadding",
  "cellspacing",
  "challenge",
  "char",
  "charoff",
  "charset",
  "checked",
  "cite",
  "class",
  "classid",
  "clear",
  "code",
  "codebase",
  "codetype",
  "color",
  "cols",
  "colspan",
  "compact",
  "content",
  "contenteditable",
  "controls",
  "controlslist",
  "conversiondestination",
  "coords",
  "crossorigin",
  "csp",
  "data",
  "datetime",
  "declare",
  "decoding",
  "default",
  "defer",
  "dir",
  "direction",
  "dirname",
  "disabled",
  "disablepictureinpicture",
  "disableremoteplayback",
  "disallowdocumentaccess",
  "download",
  "draggable",
  "elementtiming",
  "enctype",
  "end",
  "enterkeyhint",
  "event",
  "exportparts",
  "face",
  "for",
  "form",
  "formaction",
  "formenctype",
  "formmethod",
  "formnovalidate",
  "formtarget",
  "frame",
  "frameborder",
  "headers",
  "height",
  "hidden",
  "high",
  "href",
  "hreflang",
  "hreftranslate",
  "hspace",
  "http-equiv",
  "id",
  "imagesizes",
  "imagesrcset",
  "importance",
  "impressiondata",
  "impressionexpiry",
  "incremental",
  "inert",
  "inputmode",
  "integrity",
  "invisible",
  "ismap",
  "keytype",
  "kind",
  "label",
  "lang",
  "language",
  "latencyhint",
  "leftmargin",
  "link",
  "list",
  "loading",
  "longdesc",
  "loop",
  "low",
  "lowsrc",
  "manifest",
  "marginheight",
  "marginwidth",
  "max",
  "maxlength",
  "mayscript",
  "media",
  "method",
  "min",
  "minlength",
  "multiple",
  "muted",
  "name",
  "nohref",
  "nomodule",
  "nonce",
  "noresize",
  "noshade",
  "novalidate",
  "nowrap",
  "object",
  "open",
  "optimum",
  "part",
  "pattern",
  "ping",
  "placeholder",
  "playsinline",
  "policy",
  "poster",
  "preload",
  "pseudo",
  "readonly",
  "referrerpolicy",
  "rel",
  "reportingorigin",
  "required",
  "resources",
  "rev",
  "reversed",
  "role",
  "rows",
  "rowspan",
  "rules",
  "sandbox",
  "scheme",
  "scope",
  "scopes",
  "scrollamount",
  "scrolldelay",
  "scrolling",
  "select",
  "selected",
  "shadowroot",
  "shadowrootdelegatesfocus",
  "shape",
  "size",
  "sizes",
  "slot",
  "span",
  "spellcheck",
  "src",
  "srclang",
  "srcset",
  "standby",
  "start",
  "step",
  "style",
  "summary",
  "tabindex",
  "target",
  "text",
  "title",
  "topmargin",
  "translate",
  "truespeed",
  "trusttoken",
  "type",
  "usemap",
  "valign",
  "value",
  "valuetype",
  "version",
  "virtualkeyboardpolicy",
  "vlink",
  "vspace",
  "webkitdirectory",
  "width",
  "wrap"
], xr = [
  "accent-height",
  "accumulate",
  "additive",
  "alignment-baseline",
  "ascent",
  "attributename",
  "attributetype",
  "azimuth",
  "basefrequency",
  "baseline-shift",
  "begin",
  "bias",
  "by",
  "class",
  "clip",
  "clippathunits",
  "clip-path",
  "clip-rule",
  "color",
  "color-interpolation",
  "color-interpolation-filters",
  "color-profile",
  "color-rendering",
  "cx",
  "cy",
  "d",
  "dx",
  "dy",
  "diffuseconstant",
  "direction",
  "display",
  "divisor",
  "dominant-baseline",
  "dur",
  "edgemode",
  "elevation",
  "end",
  "fill",
  "fill-opacity",
  "fill-rule",
  "filter",
  "filterunits",
  "flood-color",
  "flood-opacity",
  "font-family",
  "font-size",
  "font-size-adjust",
  "font-stretch",
  "font-style",
  "font-variant",
  "font-weight",
  "fx",
  "fy",
  "g1",
  "g2",
  "glyph-name",
  "glyphref",
  "gradientunits",
  "gradienttransform",
  "height",
  "href",
  "id",
  "image-rendering",
  "in",
  "in2",
  "k",
  "k1",
  "k2",
  "k3",
  "k4",
  "kerning",
  "keypoints",
  "keysplines",
  "keytimes",
  "lang",
  "lengthadjust",
  "letter-spacing",
  "kernelmatrix",
  "kernelunitlength",
  "lighting-color",
  "local",
  "marker-end",
  "marker-mid",
  "marker-start",
  "markerheight",
  "markerunits",
  "markerwidth",
  "maskcontentunits",
  "maskunits",
  "max",
  "mask",
  "media",
  "method",
  "mode",
  "min",
  "name",
  "numoctaves",
  "offset",
  "operator",
  "opacity",
  "order",
  "orient",
  "orientation",
  "origin",
  "overflow",
  "paint-order",
  "path",
  "pathlength",
  "patterncontentunits",
  "patterntransform",
  "patternunits",
  "points",
  "preservealpha",
  "preserveaspectratio",
  "primitiveunits",
  "r",
  "rx",
  "ry",
  "radius",
  "refx",
  "refy",
  "repeatcount",
  "repeatdur",
  "restart",
  "result",
  "rotate",
  "scale",
  "seed",
  "shape-rendering",
  "specularconstant",
  "specularexponent",
  "spreadmethod",
  "startoffset",
  "stddeviation",
  "stitchtiles",
  "stop-color",
  "stop-opacity",
  "stroke-dasharray",
  "stroke-dashoffset",
  "stroke-linecap",
  "stroke-linejoin",
  "stroke-miterlimit",
  "stroke-opacity",
  "stroke",
  "stroke-width",
  "style",
  "surfacescale",
  "systemlanguage",
  "tabindex",
  "targetx",
  "targety",
  "transform",
  "transform-origin",
  "text-anchor",
  "text-decoration",
  "text-rendering",
  "textlength",
  "type",
  "u1",
  "u2",
  "unicode",
  "values",
  "viewbox",
  "visibility",
  "version",
  "vert-adv-y",
  "vert-origin-x",
  "vert-origin-y",
  "width",
  "word-spacing",
  "wrap",
  "writing-mode",
  "xchannelselector",
  "ychannelselector",
  "x",
  "x1",
  "x2",
  "xmlns",
  "y",
  "y1",
  "y2",
  "z",
  "zoomandpan"
], Tr = [
  "accent",
  "accentunder",
  "align",
  "bevelled",
  "close",
  "columnsalign",
  "columnlines",
  "columnspan",
  "denomalign",
  "depth",
  "dir",
  "display",
  "displaystyle",
  "encoding",
  "fence",
  "frame",
  "height",
  "href",
  "id",
  "largeop",
  "length",
  "linethickness",
  "lspace",
  "lquote",
  "mathbackground",
  "mathcolor",
  "mathsize",
  "mathvariant",
  "maxsize",
  "minsize",
  "movablelimits",
  "notation",
  "numalign",
  "open",
  "rowalign",
  "rowlines",
  "rowspacing",
  "rowspan",
  "rspace",
  "rquote",
  "scriptlevel",
  "scriptminsize",
  "scriptsizemultiplier",
  "selection",
  "separator",
  "separators",
  "stretchy",
  "subscriptshift",
  "supscriptshift",
  "symmetric",
  "voffset",
  "width",
  "xmlns"
], Te = {
  HTML: "http://www.w3.org/1999/xhtml",
  SVG: "http://www.w3.org/2000/svg",
  MATH: "http://www.w3.org/1998/Math/MathML"
}, qr = {
  [Te.HTML]: $r,
  [Te.SVG]: Er,
  [Te.MATH]: Sr
}, Lr = {
  [Te.HTML]: "html",
  [Te.SVG]: "svg",
  [Te.MATH]: "math"
}, zr = {
  [Te.HTML]: "",
  [Te.SVG]: "svg:",
  [Te.MATH]: "math:"
}, Ir = /* @__PURE__ */ new Set([
  "A",
  "AREA",
  "BUTTON",
  "FORM",
  "IFRAME",
  "INPUT"
]), ca = {
  allowComments: !0,
  allowCustomElements: !1,
  allowUnknownMarkup: !1,
  allowElements: [
    ...ra,
    ...sa.map((i) => `svg:${i}`),
    ...ua.map((i) => `math:${i}`)
  ],
  allowAttributes: wr([
    Object.fromEntries(Br.map((i) => [i, ["*"]])),
    Object.fromEntries(xr.map((i) => [i, ["svg:*"]])),
    Object.fromEntries(Tr.map((i) => [i, ["math:*"]]))
  ])
};
var En = function(i, e, t, n, l) {
  if (n === "m") throw new TypeError("Private method is not writable");
  if (n === "a" && !l) throw new TypeError("Private accessor was defined without a setter");
  if (typeof e == "function" ? i !== e || !l : !e.has(i)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? l.call(i, t) : l ? l.value = t : e.set(i, t), t;
}, Je = function(i, e, t, n) {
  if (t === "a" && !n) throw new TypeError("Private accessor was defined without a getter");
  if (typeof e == "function" ? i !== e || !n : !e.has(i)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return t === "m" ? n : t === "a" ? n.call(i) : n ? n.value : e.get(i);
}, Xe, cn, _n;
class _a {
  /* CONSTRUCTOR */
  constructor(e = {}) {
    Xe.set(this, void 0), cn.set(this, void 0), _n.set(this, void 0), this.getConfiguration = () => Gn(Je(this, Xe, "f")), this.sanitize = (s) => {
      const d = Je(this, cn, "f"), f = Je(this, _n, "f");
      return kr(s, (h, p) => {
        const v = h.namespaceURI || Te.HTML, k = p.namespaceURI || Te.HTML, C = qr[v], m = Lr[v], _ = zr[v], g = h.tagName.toLowerCase(), D = `${_}${g}`, w = `${_}*`;
        if (!C.has(g) || !d.has(D) || v !== k && g !== m)
          p.removeChild(h);
        else {
          const E = h.getAttributeNames(), y = E.length;
          if (y) {
            for (let B = 0; B < y; B++) {
              const q = E[B], z = f[q];
              (!z || !z.has(w) && !z.has(D)) && h.removeAttribute(q);
            }
            if (pr(h))
              if (vr(h)) {
                const B = h.getAttribute("href");
                B && Dr(B) && Kt(h.protocol) && h.removeAttribute("href");
              } else mr(h) ? Kt(h.action) && h.removeAttribute("action") : br(h) ? Kt(h.formAction) && h.removeAttribute("formaction") : gr(h) && (Kt(h.src) && h.removeAttribute("formaction"), h.setAttribute("sandbox", "allow-scripts"));
          }
        }
      }), s;
    }, this.sanitizeFor = (s, d) => {
      throw new Error('"sanitizeFor" is not implemented yet');
    };
    const { allowComments: t, allowCustomElements: n, allowUnknownMarkup: l, blockElements: a, dropElements: o, dropAttributes: r } = e;
    if (t === !1)
      throw new Error('A false "allowComments" is not supported yet');
    if (n)
      throw new Error('A true "allowCustomElements" is not supported yet');
    if (l)
      throw new Error('A true "allowUnknownMarkup" is not supported yet');
    if (a)
      throw new Error('"blockElements" is not supported yet, use "allowElements" instead');
    if (o)
      throw new Error('"dropElements" is not supported yet, use "allowElements" instead');
    if (r)
      throw new Error('"dropAttributes" is not supported yet, use "allowAttributes" instead');
    En(this, Xe, Gn(ca), "f");
    const { allowElements: u, allowAttributes: c } = e;
    u && (Je(this, Xe, "f").allowElements = e.allowElements), c && (Je(this, Xe, "f").allowAttributes = e.allowAttributes), En(this, cn, new Set(Je(this, Xe, "f").allowElements), "f"), En(this, _n, Object.fromEntries(Object.entries(Je(this, Xe, "f").allowAttributes || {}).map(([s, d]) => [s, new Set(d)])), "f");
  }
}
Xe = /* @__PURE__ */ new WeakMap(), cn = /* @__PURE__ */ new WeakMap(), _n = /* @__PURE__ */ new WeakMap();
_a.getDefaultConfiguration = () => Gn(ca);
const Mr = (i, e = location.href) => {
  try {
    return !!i && new URL(i).origin !== new URL(e).origin;
  } catch {
    return !1;
  }
};
function Bi(i) {
  const e = new _a(), t = new DOMParser().parseFromString(i, "text/html");
  return da(t.body, "A", (n) => {
    n instanceof HTMLElement && "target" in n && Mr(n.getAttribute("href"), location.href) && (n.setAttribute("target", "_blank"), n.setAttribute("rel", "noopener noreferrer"));
  }), e.sanitize(t).body.innerHTML;
}
function da(i, e, t) {
  i && (i.nodeName === e || typeof e == "function") && t(i);
  const n = (i == null ? void 0 : i.childNodes) || [];
  for (let l = 0; l < n.length; l++)
    da(n[l], e, t);
}
const xi = [
  "!--",
  "!doctype",
  "a",
  "abbr",
  "acronym",
  "address",
  "applet",
  "area",
  "article",
  "aside",
  "audio",
  "b",
  "base",
  "basefont",
  "bdi",
  "bdo",
  "big",
  "blockquote",
  "body",
  "br",
  "button",
  "canvas",
  "caption",
  "center",
  "cite",
  "code",
  "col",
  "colgroup",
  "data",
  "datalist",
  "dd",
  "del",
  "details",
  "dfn",
  "dialog",
  "dir",
  "div",
  "dl",
  "dt",
  "em",
  "embed",
  "fieldset",
  "figcaption",
  "figure",
  "font",
  "footer",
  "form",
  "frame",
  "frameset",
  "h1",
  "h2",
  "h3",
  "h4",
  "h5",
  "h6",
  "head",
  "header",
  "hgroup",
  "hr",
  "html",
  "i",
  "iframe",
  "img",
  "input",
  "ins",
  "kbd",
  "label",
  "legend",
  "li",
  "link",
  "main",
  "map",
  "mark",
  "menu",
  "meta",
  "meter",
  "nav",
  "noframes",
  "noscript",
  "object",
  "ol",
  "optgroup",
  "option",
  "output",
  "p",
  "param",
  "picture",
  "pre",
  "progress",
  "q",
  "rp",
  "rt",
  "ruby",
  "s",
  "samp",
  "script",
  "search",
  "section",
  "select",
  "small",
  "source",
  "span",
  "strike",
  "strong",
  "style",
  "sub",
  "summary",
  "sup",
  "svg",
  "table",
  "tbody",
  "td",
  "template",
  "textarea",
  "tfoot",
  "th",
  "thead",
  "time",
  "title",
  "tr",
  "track",
  "tt",
  "u",
  "ul",
  "var",
  "video",
  "wbr"
], Rr = [
  // Base structural elements
  "g",
  "defs",
  "use",
  "symbol",
  // Shape elements
  "rect",
  "circle",
  "ellipse",
  "line",
  "polyline",
  "polygon",
  "path",
  "image",
  // Text elements
  "text",
  "tspan",
  "textPath",
  // Gradient and effects
  "linearGradient",
  "radialGradient",
  "stop",
  "pattern",
  "clipPath",
  "mask",
  "filter",
  // Filter effects
  "feBlend",
  "feColorMatrix",
  "feComponentTransfer",
  "feComposite",
  "feConvolveMatrix",
  "feDiffuseLighting",
  "feDisplacementMap",
  "feGaussianBlur",
  "feMerge",
  "feMorphology",
  "feOffset",
  "feSpecularLighting",
  "feTurbulence",
  "feMergeNode",
  "feFuncR",
  "feFuncG",
  "feFuncB",
  "feFuncA",
  "feDistantLight",
  "fePointLight",
  "feSpotLight",
  "feFlood",
  "feTile",
  // Animation elements
  "animate",
  "animateTransform",
  "animateMotion",
  "mpath",
  "set",
  // Interactive and other elements
  "view",
  "cursor",
  "foreignObject",
  "desc",
  "title",
  "metadata",
  "switch"
], Or = [
  ...xi,
  ...Rr.filter((i) => !xi.includes(i))
], {
  HtmlTagHydration: Nr,
  SvelteComponent: Pr,
  attr: Hr,
  binding_callbacks: Zr,
  children: jr,
  claim_element: Ur,
  claim_html_tag: Gr,
  detach: Ti,
  element: Vr,
  init: Xr,
  insert_hydration: Wr,
  noop: qi,
  safe_not_equal: Yr,
  toggle_class: Qt
} = window.__gradio__svelte__internal, { afterUpdate: Kr, tick: Qr, onMount: x_ } = window.__gradio__svelte__internal;
function Jr(i) {
  let e, t;
  return {
    c() {
      e = Vr("span"), t = new Nr(!1), this.h();
    },
    l(n) {
      e = Ur(n, "SPAN", { class: !0 });
      var l = jr(e);
      t = Gr(l, !1), l.forEach(Ti), this.h();
    },
    h() {
      t.a = null, Hr(e, "class", "md svelte-1m32c2s"), Qt(
        e,
        "chatbot",
        /*chatbot*/
        i[0]
      ), Qt(
        e,
        "prose",
        /*render_markdown*/
        i[1]
      );
    },
    m(n, l) {
      Wr(n, e, l), t.m(
        /*html*/
        i[3],
        e
      ), i[11](e);
    },
    p(n, [l]) {
      l & /*html*/
      8 && t.p(
        /*html*/
        n[3]
      ), l & /*chatbot*/
      1 && Qt(
        e,
        "chatbot",
        /*chatbot*/
        n[0]
      ), l & /*render_markdown*/
      2 && Qt(
        e,
        "prose",
        /*render_markdown*/
        n[1]
      );
    },
    i: qi,
    o: qi,
    d(n) {
      n && Ti(e), i[11](null);
    }
  };
}
function Li(i) {
  return i.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function es(i, e, t) {
  var n = this && this.__awaiter || function(b, w, E, y) {
    function B(q) {
      return q instanceof E ? q : new E(function(z) {
        z(q);
      });
    }
    return new (E || (E = Promise))(function(q, z) {
      function le(M) {
        try {
          N(y.next(M));
        } catch (V) {
          z(V);
        }
      }
      function G(M) {
        try {
          N(y.throw(M));
        } catch (V) {
          z(V);
        }
      }
      function N(M) {
        M.done ? q(M.value) : B(M.value).then(le, G);
      }
      N((y = y.apply(b, w || [])).next());
    });
  };
  let { chatbot: l = !0 } = e, { message: a } = e, { sanitize_html: o = !0 } = e, { latex_delimiters: r = [] } = e, { render_markdown: u = !0 } = e, { line_breaks: c = !0 } = e, { header_links: s = !1 } = e, { allow_tags: d = !1 } = e, { theme_mode: f = "system" } = e, h, p, v = !1;
  const k = fr({
    header_links: s,
    line_breaks: c,
    latex_delimiters: r || []
  });
  function C(b) {
    return !r || r.length === 0 ? !1 : r.some((w) => b.includes(w.left) && b.includes(w.right));
  }
  function m(b, w) {
    if (w === !0) {
      const E = /<\/?([a-zA-Z][a-zA-Z0-9-]*)([\s>])/g;
      return b.replace(E, (y, B, q) => Or.includes(B.toLowerCase()) ? y : y.replace(/</g, "&lt;").replace(/>/g, "&gt;"));
    }
    if (Array.isArray(w)) {
      const E = w.map((B) => ({
        open: new RegExp(`<(${B})(\\s+[^>]*)?>`, "gi"),
        close: new RegExp(`</(${B})>`, "gi")
      }));
      let y = b;
      return E.forEach((B) => {
        y = y.replace(B.open, (q) => q.replace(/</g, "&lt;").replace(/>/g, "&gt;")), y = y.replace(B.close, (q) => q.replace(/</g, "&lt;").replace(/>/g, "&gt;"));
      }), y;
    }
    return b;
  }
  function _(b) {
    let w = b;
    if (u) {
      const E = [];
      r.forEach((y, B) => {
        const q = Li(y.left), z = Li(y.right), le = new RegExp(`${q}([\\s\\S]+?)${z}`, "g");
        w = w.replace(le, (G, N) => (E.push(G), `%%%LATEX_BLOCK_${E.length - 1}%%%`));
      }), w = k.parse(w), w = w.replace(/%%%LATEX_BLOCK_(\d+)%%%/g, (y, B) => E[parseInt(B, 10)]);
    }
    return d && (w = m(w, d)), o && Bi && (w = Bi(w)), w;
  }
  function g(b) {
    return n(this, void 0, void 0, function* () {
      if (r.length > 0 && b && C(b))
        if (!v)
          yield Promise.all([
            Promise.resolve({              }),
            import("./auto-render-BwaQGe8P.js")
          ]).then(([, { default: w }]) => {
            v = !0, w(h, {
              delimiters: r,
              throwOnError: !1
            });
          });
        else {
          const { default: w } = yield import("./auto-render-BwaQGe8P.js");
          w(h, {
            delimiters: r,
            throwOnError: !1
          });
        }
      if (h) {
        const w = h.querySelectorAll(".mermaid");
        if (w.length > 0) {
          yield Qr();
          const { default: E } = yield import("./mermaid.core-DEsmg04W.js").then((y) => y.bB);
          E.initialize({
            startOnLoad: !1,
            theme: f === "dark" ? "dark" : "default",
            securityLevel: "antiscript"
          }), yield E.run({
            nodes: Array.from(w).map((y) => y)
          });
        }
      }
    });
  }
  Kr(() => n(void 0, void 0, void 0, function* () {
    h && document.body.contains(h) ? yield g(a) : console.error("Element is not in the DOM");
  }));
  function D(b) {
    Zr[b ? "unshift" : "push"](() => {
      h = b, t(2, h);
    });
  }
  return i.$$set = (b) => {
    "chatbot" in b && t(0, l = b.chatbot), "message" in b && t(4, a = b.message), "sanitize_html" in b && t(5, o = b.sanitize_html), "latex_delimiters" in b && t(6, r = b.latex_delimiters), "render_markdown" in b && t(1, u = b.render_markdown), "line_breaks" in b && t(7, c = b.line_breaks), "header_links" in b && t(8, s = b.header_links), "allow_tags" in b && t(9, d = b.allow_tags), "theme_mode" in b && t(10, f = b.theme_mode);
  }, i.$$.update = () => {
    i.$$.dirty & /*message*/
    16 && (a && a.trim() ? t(3, p = _(a)) : t(3, p = ""));
  }, [
    l,
    u,
    h,
    p,
    a,
    o,
    r,
    c,
    s,
    d,
    f,
    D
  ];
}
class ts extends Pr {
  constructor(e) {
    super(), Xr(this, e, es, Jr, Yr, {
      chatbot: 0,
      message: 4,
      sanitize_html: 5,
      latex_delimiters: 6,
      render_markdown: 1,
      line_breaks: 7,
      header_links: 8,
      allow_tags: 9,
      theme_mode: 10
    });
  }
}
const {
  SvelteComponent: ns,
  attr: is,
  children: ls,
  claim_component: as,
  claim_element: os,
  create_component: rs,
  destroy_component: ss,
  detach: zi,
  element: us,
  init: cs,
  insert_hydration: _s,
  mount_component: ds,
  safe_not_equal: fs,
  transition_in: hs,
  transition_out: ps
} = window.__gradio__svelte__internal;
function ms(i) {
  let e, t, n;
  return t = new ts({
    props: {
      message: (
        /*info*/
        i[0]
      ),
      sanitize_html: !0
    }
  }), {
    c() {
      e = us("div"), rs(t.$$.fragment), this.h();
    },
    l(l) {
      e = os(l, "DIV", { class: !0 });
      var a = ls(e);
      as(t.$$.fragment, a), a.forEach(zi), this.h();
    },
    h() {
      is(e, "class", "svelte-17qq50w");
    },
    m(l, a) {
      _s(l, e, a), ds(t, e, null), n = !0;
    },
    p(l, [a]) {
      const o = {};
      a & /*info*/
      1 && (o.message = /*info*/
      l[0]), t.$set(o);
    },
    i(l) {
      n || (hs(t.$$.fragment, l), n = !0);
    },
    o(l) {
      ps(t.$$.fragment, l), n = !1;
    },
    d(l) {
      l && zi(e), ss(t);
    }
  };
}
function gs(i, e, t) {
  let { info: n } = e;
  return i.$$set = (l) => {
    "info" in l && t(0, n = l.info);
  }, [n];
}
class bs extends ns {
  constructor(e) {
    super(), cs(this, e, gs, ms, fs, { info: 0 });
  }
}
const {
  SvelteComponent: vs,
  attr: Jt,
  check_outros: Ds,
  children: ws,
  claim_component: ys,
  claim_element: ks,
  claim_space: Fs,
  create_component: $s,
  create_slot: Cs,
  destroy_component: Es,
  detach: en,
  element: As,
  empty: Ii,
  get_all_dirty_from_scope: Ss,
  get_slot_changes: Bs,
  group_outros: xs,
  init: Ts,
  insert_hydration: An,
  mount_component: qs,
  safe_not_equal: Ls,
  space: zs,
  toggle_class: ct,
  transition_in: St,
  transition_out: dn,
  update_slot_base: Is
} = window.__gradio__svelte__internal;
function Mi(i) {
  let e, t;
  return e = new bs({ props: { info: (
    /*info*/
    i[1]
  ) } }), {
    c() {
      $s(e.$$.fragment);
    },
    l(n) {
      ys(e.$$.fragment, n);
    },
    m(n, l) {
      qs(e, n, l), t = !0;
    },
    p(n, l) {
      const a = {};
      l & /*info*/
      2 && (a.info = /*info*/
      n[1]), e.$set(a);
    },
    i(n) {
      t || (St(e.$$.fragment, n), t = !0);
    },
    o(n) {
      dn(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Es(e, n);
    }
  };
}
function Ms(i) {
  let e, t, n, l, a;
  const o = (
    /*#slots*/
    i[4].default
  ), r = Cs(
    o,
    i,
    /*$$scope*/
    i[3],
    null
  );
  let u = (
    /*info*/
    i[1] && Mi(i)
  );
  return {
    c() {
      e = As("span"), r && r.c(), n = zs(), u && u.c(), l = Ii(), this.h();
    },
    l(c) {
      e = ks(c, "SPAN", {
        "data-testid": !0,
        dir: !0,
        class: !0
      });
      var s = ws(e);
      r && r.l(s), s.forEach(en), n = Fs(c), u && u.l(c), l = Ii(), this.h();
    },
    h() {
      Jt(e, "data-testid", "block-info"), Jt(e, "dir", t = /*rtl*/
      i[2] ? "rtl" : "ltr"), Jt(e, "class", "svelte-zgrq3"), ct(e, "sr-only", !/*show_label*/
      i[0]), ct(e, "hide", !/*show_label*/
      i[0]), ct(
        e,
        "has-info",
        /*info*/
        i[1] != null
      );
    },
    m(c, s) {
      An(c, e, s), r && r.m(e, null), An(c, n, s), u && u.m(c, s), An(c, l, s), a = !0;
    },
    p(c, [s]) {
      r && r.p && (!a || s & /*$$scope*/
      8) && Is(
        r,
        o,
        c,
        /*$$scope*/
        c[3],
        a ? Bs(
          o,
          /*$$scope*/
          c[3],
          s,
          null
        ) : Ss(
          /*$$scope*/
          c[3]
        ),
        null
      ), (!a || s & /*rtl*/
      4 && t !== (t = /*rtl*/
      c[2] ? "rtl" : "ltr")) && Jt(e, "dir", t), (!a || s & /*show_label*/
      1) && ct(e, "sr-only", !/*show_label*/
      c[0]), (!a || s & /*show_label*/
      1) && ct(e, "hide", !/*show_label*/
      c[0]), (!a || s & /*info*/
      2) && ct(
        e,
        "has-info",
        /*info*/
        c[1] != null
      ), /*info*/
      c[1] ? u ? (u.p(c, s), s & /*info*/
      2 && St(u, 1)) : (u = Mi(c), u.c(), St(u, 1), u.m(l.parentNode, l)) : u && (xs(), dn(u, 1, 1, () => {
        u = null;
      }), Ds());
    },
    i(c) {
      a || (St(r, c), St(u), a = !0);
    },
    o(c) {
      dn(r, c), dn(u), a = !1;
    },
    d(c) {
      c && (en(e), en(n), en(l)), r && r.d(c), u && u.d(c);
    }
  };
}
function Rs(i, e, t) {
  let { $$slots: n = {}, $$scope: l } = e, { show_label: a = !0 } = e, { info: o = void 0 } = e, { rtl: r = !1 } = e;
  return i.$$set = (u) => {
    "show_label" in u && t(0, a = u.show_label), "info" in u && t(1, o = u.info), "rtl" in u && t(2, r = u.rtl), "$$scope" in u && t(3, l = u.$$scope);
  }, [a, o, r, l, n];
}
class Os extends vs {
  constructor(e) {
    super(), Ts(this, e, Rs, Ms, Ls, { show_label: 0, info: 1, rtl: 2 });
  }
}
const {
  SvelteComponent: T_,
  append_hydration: q_,
  attr: L_,
  children: z_,
  claim_component: I_,
  claim_element: M_,
  claim_space: R_,
  claim_text: O_,
  create_component: N_,
  destroy_component: P_,
  detach: H_,
  element: Z_,
  init: j_,
  insert_hydration: U_,
  mount_component: G_,
  safe_not_equal: V_,
  set_data: X_,
  space: W_,
  text: Y_,
  toggle_class: K_,
  transition_in: Q_,
  transition_out: J_
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ns,
  append_hydration: fn,
  attr: Ze,
  bubble: Ps,
  check_outros: Hs,
  children: Vn,
  claim_component: Zs,
  claim_element: Xn,
  claim_space: Ri,
  claim_text: js,
  construct_svelte_component: Oi,
  create_component: Ni,
  create_slot: Us,
  destroy_component: Pi,
  detach: qt,
  element: Wn,
  get_all_dirty_from_scope: Gs,
  get_slot_changes: Vs,
  group_outros: Xs,
  init: Ws,
  insert_hydration: fa,
  listen: Ys,
  mount_component: Hi,
  safe_not_equal: Ks,
  set_data: Qs,
  set_style: tn,
  space: Zi,
  text: Js,
  toggle_class: se,
  transition_in: Sn,
  transition_out: Bn,
  update_slot_base: eu
} = window.__gradio__svelte__internal;
function ji(i) {
  let e, t;
  return {
    c() {
      e = Wn("span"), t = Js(
        /*label*/
        i[1]
      ), this.h();
    },
    l(n) {
      e = Xn(n, "SPAN", { class: !0 });
      var l = Vn(e);
      t = js(
        l,
        /*label*/
        i[1]
      ), l.forEach(qt), this.h();
    },
    h() {
      Ze(e, "class", "svelte-qgco6m");
    },
    m(n, l) {
      fa(n, e, l), fn(e, t);
    },
    p(n, l) {
      l & /*label*/
      2 && Qs(
        t,
        /*label*/
        n[1]
      );
    },
    d(n) {
      n && qt(e);
    }
  };
}
function tu(i) {
  let e, t, n, l, a, o, r, u, c = (
    /*show_label*/
    i[2] && ji(i)
  );
  var s = (
    /*Icon*/
    i[0]
  );
  function d(p, v) {
    return {};
  }
  s && (l = Oi(s, d()));
  const f = (
    /*#slots*/
    i[14].default
  ), h = Us(
    f,
    i,
    /*$$scope*/
    i[13],
    null
  );
  return {
    c() {
      e = Wn("button"), c && c.c(), t = Zi(), n = Wn("div"), l && Ni(l.$$.fragment), a = Zi(), h && h.c(), this.h();
    },
    l(p) {
      e = Xn(p, "BUTTON", {
        "aria-label": !0,
        "aria-haspopup": !0,
        title: !0,
        class: !0
      });
      var v = Vn(e);
      c && c.l(v), t = Ri(v), n = Xn(v, "DIV", { class: !0 });
      var k = Vn(n);
      l && Zs(l.$$.fragment, k), a = Ri(k), h && h.l(k), k.forEach(qt), v.forEach(qt), this.h();
    },
    h() {
      Ze(n, "class", "svelte-qgco6m"), se(
        n,
        "x-small",
        /*size*/
        i[4] === "x-small"
      ), se(
        n,
        "small",
        /*size*/
        i[4] === "small"
      ), se(
        n,
        "large",
        /*size*/
        i[4] === "large"
      ), se(
        n,
        "medium",
        /*size*/
        i[4] === "medium"
      ), e.disabled = /*disabled*/
      i[7], Ze(
        e,
        "aria-label",
        /*label*/
        i[1]
      ), Ze(
        e,
        "aria-haspopup",
        /*hasPopup*/
        i[8]
      ), Ze(
        e,
        "title",
        /*label*/
        i[1]
      ), Ze(e, "class", "svelte-qgco6m"), se(
        e,
        "pending",
        /*pending*/
        i[3]
      ), se(
        e,
        "padded",
        /*padded*/
        i[5]
      ), se(
        e,
        "highlight",
        /*highlight*/
        i[6]
      ), se(
        e,
        "transparent",
        /*transparent*/
        i[9]
      ), tn(e, "color", !/*disabled*/
      i[7] && /*_color*/
      i[11] ? (
        /*_color*/
        i[11]
      ) : "var(--block-label-text-color)"), tn(e, "--bg-color", /*disabled*/
      i[7] ? "auto" : (
        /*background*/
        i[10]
      ));
    },
    m(p, v) {
      fa(p, e, v), c && c.m(e, null), fn(e, t), fn(e, n), l && Hi(l, n, null), fn(n, a), h && h.m(n, null), o = !0, r || (u = Ys(
        e,
        "click",
        /*click_handler*/
        i[15]
      ), r = !0);
    },
    p(p, [v]) {
      if (/*show_label*/
      p[2] ? c ? c.p(p, v) : (c = ji(p), c.c(), c.m(e, t)) : c && (c.d(1), c = null), v & /*Icon*/
      1 && s !== (s = /*Icon*/
      p[0])) {
        if (l) {
          Xs();
          const k = l;
          Bn(k.$$.fragment, 1, 0, () => {
            Pi(k, 1);
          }), Hs();
        }
        s ? (l = Oi(s, d()), Ni(l.$$.fragment), Sn(l.$$.fragment, 1), Hi(l, n, a)) : l = null;
      }
      h && h.p && (!o || v & /*$$scope*/
      8192) && eu(
        h,
        f,
        p,
        /*$$scope*/
        p[13],
        o ? Vs(
          f,
          /*$$scope*/
          p[13],
          v,
          null
        ) : Gs(
          /*$$scope*/
          p[13]
        ),
        null
      ), (!o || v & /*size*/
      16) && se(
        n,
        "x-small",
        /*size*/
        p[4] === "x-small"
      ), (!o || v & /*size*/
      16) && se(
        n,
        "small",
        /*size*/
        p[4] === "small"
      ), (!o || v & /*size*/
      16) && se(
        n,
        "large",
        /*size*/
        p[4] === "large"
      ), (!o || v & /*size*/
      16) && se(
        n,
        "medium",
        /*size*/
        p[4] === "medium"
      ), (!o || v & /*disabled*/
      128) && (e.disabled = /*disabled*/
      p[7]), (!o || v & /*label*/
      2) && Ze(
        e,
        "aria-label",
        /*label*/
        p[1]
      ), (!o || v & /*hasPopup*/
      256) && Ze(
        e,
        "aria-haspopup",
        /*hasPopup*/
        p[8]
      ), (!o || v & /*label*/
      2) && Ze(
        e,
        "title",
        /*label*/
        p[1]
      ), (!o || v & /*pending*/
      8) && se(
        e,
        "pending",
        /*pending*/
        p[3]
      ), (!o || v & /*padded*/
      32) && se(
        e,
        "padded",
        /*padded*/
        p[5]
      ), (!o || v & /*highlight*/
      64) && se(
        e,
        "highlight",
        /*highlight*/
        p[6]
      ), (!o || v & /*transparent*/
      512) && se(
        e,
        "transparent",
        /*transparent*/
        p[9]
      ), v & /*disabled, _color*/
      2176 && tn(e, "color", !/*disabled*/
      p[7] && /*_color*/
      p[11] ? (
        /*_color*/
        p[11]
      ) : "var(--block-label-text-color)"), v & /*disabled, background*/
      1152 && tn(e, "--bg-color", /*disabled*/
      p[7] ? "auto" : (
        /*background*/
        p[10]
      ));
    },
    i(p) {
      o || (l && Sn(l.$$.fragment, p), Sn(h, p), o = !0);
    },
    o(p) {
      l && Bn(l.$$.fragment, p), Bn(h, p), o = !1;
    },
    d(p) {
      p && qt(e), c && c.d(), l && Pi(l), h && h.d(p), r = !1, u();
    }
  };
}
function nu(i, e, t) {
  let n, { $$slots: l = {}, $$scope: a } = e, { Icon: o } = e, { label: r = "" } = e, { show_label: u = !1 } = e, { pending: c = !1 } = e, { size: s = "small" } = e, { padded: d = !0 } = e, { highlight: f = !1 } = e, { disabled: h = !1 } = e, { hasPopup: p = !1 } = e, { color: v = "var(--block-label-text-color)" } = e, { transparent: k = !1 } = e, { background: C = "var(--block-background-fill)" } = e;
  function m(_) {
    Ps.call(this, i, _);
  }
  return i.$$set = (_) => {
    "Icon" in _ && t(0, o = _.Icon), "label" in _ && t(1, r = _.label), "show_label" in _ && t(2, u = _.show_label), "pending" in _ && t(3, c = _.pending), "size" in _ && t(4, s = _.size), "padded" in _ && t(5, d = _.padded), "highlight" in _ && t(6, f = _.highlight), "disabled" in _ && t(7, h = _.disabled), "hasPopup" in _ && t(8, p = _.hasPopup), "color" in _ && t(12, v = _.color), "transparent" in _ && t(9, k = _.transparent), "background" in _ && t(10, C = _.background), "$$scope" in _ && t(13, a = _.$$scope);
  }, i.$$.update = () => {
    i.$$.dirty & /*highlight, color*/
    4160 && t(11, n = f ? "var(--color-accent)" : v);
  }, [
    o,
    r,
    u,
    c,
    s,
    d,
    f,
    h,
    p,
    k,
    C,
    n,
    v,
    a,
    l,
    m
  ];
}
class iu extends Ns {
  constructor(e) {
    super(), Ws(this, e, nu, tu, Ks, {
      Icon: 0,
      label: 1,
      show_label: 2,
      pending: 3,
      size: 4,
      padded: 5,
      highlight: 6,
      disabled: 7,
      hasPopup: 8,
      color: 12,
      transparent: 9,
      background: 10
    });
  }
}
const {
  SvelteComponent: ed,
  append_hydration: td,
  attr: nd,
  binding_callbacks: id,
  children: ld,
  claim_element: ad,
  create_slot: od,
  detach: rd,
  element: sd,
  get_all_dirty_from_scope: ud,
  get_slot_changes: cd,
  init: _d,
  insert_hydration: dd,
  safe_not_equal: fd,
  toggle_class: hd,
  transition_in: pd,
  transition_out: md,
  update_slot_base: gd
} = window.__gradio__svelte__internal, {
  SvelteComponent: bd,
  append_hydration: vd,
  attr: Dd,
  children: wd,
  claim_svg_element: yd,
  detach: kd,
  init: Fd,
  insert_hydration: $d,
  noop: Cd,
  safe_not_equal: Ed,
  svg_element: Ad
} = window.__gradio__svelte__internal, {
  SvelteComponent: Sd,
  append_hydration: Bd,
  attr: xd,
  children: Td,
  claim_svg_element: qd,
  detach: Ld,
  init: zd,
  insert_hydration: Id,
  noop: Md,
  safe_not_equal: Rd,
  svg_element: Od
} = window.__gradio__svelte__internal, {
  SvelteComponent: Nd,
  append_hydration: Pd,
  attr: Hd,
  children: Zd,
  claim_svg_element: jd,
  detach: Ud,
  init: Gd,
  insert_hydration: Vd,
  noop: Xd,
  safe_not_equal: Wd,
  svg_element: Yd
} = window.__gradio__svelte__internal, {
  SvelteComponent: Kd,
  append_hydration: Qd,
  attr: Jd,
  children: ef,
  claim_svg_element: tf,
  detach: nf,
  init: lf,
  insert_hydration: af,
  noop: of,
  safe_not_equal: rf,
  svg_element: sf
} = window.__gradio__svelte__internal, {
  SvelteComponent: uf,
  append_hydration: cf,
  attr: _f,
  children: df,
  claim_svg_element: ff,
  detach: hf,
  init: pf,
  insert_hydration: mf,
  noop: gf,
  safe_not_equal: bf,
  svg_element: vf
} = window.__gradio__svelte__internal, {
  SvelteComponent: Df,
  append_hydration: wf,
  attr: yf,
  children: kf,
  claim_svg_element: Ff,
  detach: $f,
  init: Cf,
  insert_hydration: Ef,
  noop: Af,
  safe_not_equal: Sf,
  svg_element: Bf
} = window.__gradio__svelte__internal, {
  SvelteComponent: xf,
  append_hydration: Tf,
  attr: qf,
  children: Lf,
  claim_svg_element: zf,
  detach: If,
  init: Mf,
  insert_hydration: Rf,
  noop: Of,
  safe_not_equal: Nf,
  svg_element: Pf
} = window.__gradio__svelte__internal, {
  SvelteComponent: Hf,
  append_hydration: Zf,
  attr: jf,
  children: Uf,
  claim_svg_element: Gf,
  detach: Vf,
  init: Xf,
  insert_hydration: Wf,
  noop: Yf,
  safe_not_equal: Kf,
  svg_element: Qf
} = window.__gradio__svelte__internal, {
  SvelteComponent: Jf,
  append_hydration: eh,
  attr: th,
  children: nh,
  claim_svg_element: ih,
  detach: lh,
  init: ah,
  insert_hydration: oh,
  noop: rh,
  safe_not_equal: sh,
  svg_element: uh
} = window.__gradio__svelte__internal, {
  SvelteComponent: ch,
  append_hydration: _h,
  attr: dh,
  children: fh,
  claim_svg_element: hh,
  detach: ph,
  init: mh,
  insert_hydration: gh,
  noop: bh,
  safe_not_equal: vh,
  svg_element: Dh
} = window.__gradio__svelte__internal, {
  SvelteComponent: lu,
  append_hydration: au,
  attr: be,
  children: Ui,
  claim_svg_element: Gi,
  detach: xn,
  init: ou,
  insert_hydration: ru,
  noop: Tn,
  safe_not_equal: su,
  svg_element: Vi
} = window.__gradio__svelte__internal;
function uu(i) {
  let e, t;
  return {
    c() {
      e = Vi("svg"), t = Vi("path"), this.h();
    },
    l(n) {
      e = Gi(n, "svg", {
        width: !0,
        height: !0,
        "stroke-width": !0,
        viewBox: !0,
        fill: !0,
        xmlns: !0,
        color: !0
      });
      var l = Ui(e);
      t = Gi(l, "path", {
        d: !0,
        stroke: !0,
        "stroke-width": !0,
        "stroke-linecap": !0,
        "stroke-linejoin": !0
      }), Ui(t).forEach(xn), l.forEach(xn), this.h();
    },
    h() {
      be(t, "d", "M5 13L9 17L19 7"), be(t, "stroke", "currentColor"), be(t, "stroke-width", "1.5"), be(t, "stroke-linecap", "round"), be(t, "stroke-linejoin", "round"), be(e, "width", "100%"), be(e, "height", "100%"), be(e, "stroke-width", "1.5"), be(e, "viewBox", "0 0 24 24"), be(e, "fill", "none"), be(e, "xmlns", "http://www.w3.org/2000/svg"), be(e, "color", "currentColor");
    },
    m(n, l) {
      ru(n, e, l), au(e, t);
    },
    p: Tn,
    i: Tn,
    o: Tn,
    d(n) {
      n && xn(e);
    }
  };
}
class cu extends lu {
  constructor(e) {
    super(), ou(this, e, null, uu, su, {});
  }
}
const {
  SvelteComponent: wh,
  append_hydration: yh,
  attr: kh,
  children: Fh,
  claim_svg_element: $h,
  detach: Ch,
  init: Eh,
  insert_hydration: Ah,
  noop: Sh,
  safe_not_equal: Bh,
  svg_element: xh
} = window.__gradio__svelte__internal, {
  SvelteComponent: _u,
  append_hydration: qn,
  attr: Ce,
  children: nn,
  claim_svg_element: ln,
  detach: $t,
  init: du,
  insert_hydration: fu,
  noop: Ln,
  safe_not_equal: hu,
  set_style: Le,
  svg_element: an
} = window.__gradio__svelte__internal;
function pu(i) {
  let e, t, n, l;
  return {
    c() {
      e = an("svg"), t = an("g"), n = an("path"), l = an("path"), this.h();
    },
    l(a) {
      e = ln(a, "svg", {
        width: !0,
        height: !0,
        viewBox: !0,
        version: !0,
        xmlns: !0,
        "xmlns:xlink": !0,
        "xml:space": !0,
        stroke: !0,
        style: !0
      });
      var o = nn(e);
      t = ln(o, "g", { transform: !0 });
      var r = nn(t);
      n = ln(r, "path", { d: !0, style: !0 }), nn(n).forEach($t), r.forEach($t), l = ln(o, "path", { d: !0, style: !0 }), nn(l).forEach($t), o.forEach($t), this.h();
    },
    h() {
      Ce(n, "d", "M18,6L6.087,17.913"), Le(n, "fill", "none"), Le(n, "fill-rule", "nonzero"), Le(n, "stroke-width", "2px"), Ce(t, "transform", "matrix(1.14096,-0.140958,-0.140958,1.14096,-0.0559523,0.0559523)"), Ce(l, "d", "M4.364,4.364L19.636,19.636"), Le(l, "fill", "none"), Le(l, "fill-rule", "nonzero"), Le(l, "stroke-width", "2px"), Ce(e, "width", "100%"), Ce(e, "height", "100%"), Ce(e, "viewBox", "0 0 24 24"), Ce(e, "version", "1.1"), Ce(e, "xmlns", "http://www.w3.org/2000/svg"), Ce(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), Ce(e, "xml:space", "preserve"), Ce(e, "stroke", "currentColor"), Le(e, "fill-rule", "evenodd"), Le(e, "clip-rule", "evenodd"), Le(e, "stroke-linecap", "round"), Le(e, "stroke-linejoin", "round");
    },
    m(a, o) {
      fu(a, e, o), qn(e, t), qn(t, n), qn(e, l);
    },
    p: Ln,
    i: Ln,
    o: Ln,
    d(a) {
      a && $t(e);
    }
  };
}
class mu extends _u {
  constructor(e) {
    super(), du(this, e, null, pu, hu, {});
  }
}
const {
  SvelteComponent: Th,
  append_hydration: qh,
  attr: Lh,
  children: zh,
  claim_svg_element: Ih,
  detach: Mh,
  init: Rh,
  insert_hydration: Oh,
  noop: Nh,
  safe_not_equal: Ph,
  svg_element: Hh
} = window.__gradio__svelte__internal, {
  SvelteComponent: Zh,
  append_hydration: jh,
  attr: Uh,
  children: Gh,
  claim_svg_element: Vh,
  detach: Xh,
  init: Wh,
  insert_hydration: Yh,
  noop: Kh,
  safe_not_equal: Qh,
  svg_element: Jh
} = window.__gradio__svelte__internal, {
  SvelteComponent: ep,
  append_hydration: tp,
  attr: np,
  children: ip,
  claim_svg_element: lp,
  detach: ap,
  init: op,
  insert_hydration: rp,
  noop: sp,
  safe_not_equal: up,
  svg_element: cp
} = window.__gradio__svelte__internal, {
  SvelteComponent: _p,
  append_hydration: dp,
  attr: fp,
  children: hp,
  claim_svg_element: pp,
  detach: mp,
  init: gp,
  insert_hydration: bp,
  noop: vp,
  safe_not_equal: Dp,
  svg_element: wp
} = window.__gradio__svelte__internal, {
  SvelteComponent: gu,
  append_hydration: Xi,
  attr: ze,
  children: zn,
  claim_svg_element: In,
  detach: on,
  init: bu,
  insert_hydration: vu,
  noop: Mn,
  safe_not_equal: Du,
  svg_element: Rn
} = window.__gradio__svelte__internal;
function wu(i) {
  let e, t, n;
  return {
    c() {
      e = Rn("svg"), t = Rn("path"), n = Rn("path"), this.h();
    },
    l(l) {
      e = In(l, "svg", {
        xmlns: !0,
        viewBox: !0,
        color: !0,
        "aria-hidden": !0,
        width: !0,
        height: !0
      });
      var a = zn(e);
      t = In(a, "path", { fill: !0, d: !0 }), zn(t).forEach(on), n = In(a, "path", { fill: !0, d: !0 }), zn(n).forEach(on), a.forEach(on), this.h();
    },
    h() {
      ze(t, "fill", "currentColor"), ze(t, "d", "M28 10v18H10V10h18m0-2H10a2 2 0 0 0-2 2v18a2 2 0 0 0 2 2h18a2 2 0 0 0 2-2V10a2 2 0 0 0-2-2Z"), ze(n, "fill", "currentColor"), ze(n, "d", "M4 18H2V4a2 2 0 0 1 2-2h14v2H4Z"), ze(e, "xmlns", "http://www.w3.org/2000/svg"), ze(e, "viewBox", "0 0 33 33"), ze(e, "color", "currentColor"), ze(e, "aria-hidden", "true"), ze(e, "width", "100%"), ze(e, "height", "100%");
    },
    m(l, a) {
      vu(l, e, a), Xi(e, t), Xi(e, n);
    },
    p: Mn,
    i: Mn,
    o: Mn,
    d(l) {
      l && on(e);
    }
  };
}
class yu extends gu {
  constructor(e) {
    super(), bu(this, e, null, wu, Du, {});
  }
}
const {
  SvelteComponent: yp,
  append_hydration: kp,
  attr: Fp,
  children: $p,
  claim_svg_element: Cp,
  detach: Ep,
  init: Ap,
  insert_hydration: Sp,
  noop: Bp,
  safe_not_equal: xp,
  svg_element: Tp
} = window.__gradio__svelte__internal, {
  SvelteComponent: qp,
  append_hydration: Lp,
  attr: zp,
  children: Ip,
  claim_svg_element: Mp,
  detach: Rp,
  init: Op,
  insert_hydration: Np,
  noop: Pp,
  safe_not_equal: Hp,
  svg_element: Zp
} = window.__gradio__svelte__internal, {
  SvelteComponent: jp,
  append_hydration: Up,
  attr: Gp,
  children: Vp,
  claim_svg_element: Xp,
  detach: Wp,
  init: Yp,
  insert_hydration: Kp,
  noop: Qp,
  safe_not_equal: Jp,
  svg_element: em
} = window.__gradio__svelte__internal, {
  SvelteComponent: tm,
  append_hydration: nm,
  attr: im,
  children: lm,
  claim_svg_element: am,
  detach: om,
  init: rm,
  insert_hydration: sm,
  noop: um,
  safe_not_equal: cm,
  svg_element: _m
} = window.__gradio__svelte__internal, {
  SvelteComponent: dm,
  append_hydration: fm,
  attr: hm,
  children: pm,
  claim_svg_element: mm,
  detach: gm,
  init: bm,
  insert_hydration: vm,
  noop: Dm,
  safe_not_equal: wm,
  svg_element: ym
} = window.__gradio__svelte__internal, {
  SvelteComponent: km,
  append_hydration: Fm,
  attr: $m,
  children: Cm,
  claim_svg_element: Em,
  detach: Am,
  init: Sm,
  insert_hydration: Bm,
  noop: xm,
  safe_not_equal: Tm,
  svg_element: qm
} = window.__gradio__svelte__internal, {
  SvelteComponent: Lm,
  append_hydration: zm,
  attr: Im,
  children: Mm,
  claim_svg_element: Rm,
  detach: Om,
  init: Nm,
  insert_hydration: Pm,
  noop: Hm,
  safe_not_equal: Zm,
  svg_element: jm
} = window.__gradio__svelte__internal, {
  SvelteComponent: Um,
  append_hydration: Gm,
  attr: Vm,
  children: Xm,
  claim_svg_element: Wm,
  detach: Ym,
  init: Km,
  insert_hydration: Qm,
  noop: Jm,
  safe_not_equal: e0,
  svg_element: t0
} = window.__gradio__svelte__internal, {
  SvelteComponent: n0,
  append_hydration: i0,
  attr: l0,
  children: a0,
  claim_svg_element: o0,
  detach: r0,
  init: s0,
  insert_hydration: u0,
  noop: c0,
  safe_not_equal: _0,
  svg_element: d0
} = window.__gradio__svelte__internal, {
  SvelteComponent: f0,
  append_hydration: h0,
  attr: p0,
  children: m0,
  claim_svg_element: g0,
  detach: b0,
  init: v0,
  insert_hydration: D0,
  noop: w0,
  safe_not_equal: y0,
  svg_element: k0
} = window.__gradio__svelte__internal, {
  SvelteComponent: F0,
  append_hydration: $0,
  attr: C0,
  children: E0,
  claim_svg_element: A0,
  detach: S0,
  init: B0,
  insert_hydration: x0,
  noop: T0,
  safe_not_equal: q0,
  svg_element: L0
} = window.__gradio__svelte__internal, {
  SvelteComponent: z0,
  append_hydration: I0,
  attr: M0,
  children: R0,
  claim_svg_element: O0,
  detach: N0,
  init: P0,
  insert_hydration: H0,
  noop: Z0,
  safe_not_equal: j0,
  svg_element: U0
} = window.__gradio__svelte__internal, {
  SvelteComponent: G0,
  append_hydration: V0,
  attr: X0,
  children: W0,
  claim_svg_element: Y0,
  detach: K0,
  init: Q0,
  insert_hydration: J0,
  noop: e1,
  safe_not_equal: t1,
  svg_element: n1
} = window.__gradio__svelte__internal, {
  SvelteComponent: i1,
  append_hydration: l1,
  attr: a1,
  children: o1,
  claim_svg_element: r1,
  detach: s1,
  init: u1,
  insert_hydration: c1,
  noop: _1,
  safe_not_equal: d1,
  svg_element: f1
} = window.__gradio__svelte__internal, {
  SvelteComponent: h1,
  append_hydration: p1,
  attr: m1,
  children: g1,
  claim_svg_element: b1,
  detach: v1,
  init: D1,
  insert_hydration: w1,
  noop: y1,
  safe_not_equal: k1,
  svg_element: F1
} = window.__gradio__svelte__internal, {
  SvelteComponent: $1,
  append_hydration: C1,
  attr: E1,
  children: A1,
  claim_svg_element: S1,
  detach: B1,
  init: x1,
  insert_hydration: T1,
  noop: q1,
  safe_not_equal: L1,
  svg_element: z1
} = window.__gradio__svelte__internal, {
  SvelteComponent: I1,
  append_hydration: M1,
  attr: R1,
  children: O1,
  claim_svg_element: N1,
  detach: P1,
  init: H1,
  insert_hydration: Z1,
  noop: j1,
  safe_not_equal: U1,
  svg_element: G1
} = window.__gradio__svelte__internal, {
  SvelteComponent: V1,
  append_hydration: X1,
  attr: W1,
  children: Y1,
  claim_svg_element: K1,
  detach: Q1,
  init: J1,
  insert_hydration: eg,
  noop: tg,
  safe_not_equal: ng,
  svg_element: ig
} = window.__gradio__svelte__internal, {
  SvelteComponent: lg,
  append_hydration: ag,
  attr: og,
  children: rg,
  claim_svg_element: sg,
  detach: ug,
  init: cg,
  insert_hydration: _g,
  noop: dg,
  safe_not_equal: fg,
  svg_element: hg
} = window.__gradio__svelte__internal, {
  SvelteComponent: pg,
  append_hydration: mg,
  attr: gg,
  children: bg,
  claim_svg_element: vg,
  detach: Dg,
  init: wg,
  insert_hydration: yg,
  noop: kg,
  safe_not_equal: Fg,
  svg_element: $g
} = window.__gradio__svelte__internal, {
  SvelteComponent: Cg,
  append_hydration: Eg,
  attr: Ag,
  children: Sg,
  claim_svg_element: Bg,
  detach: xg,
  init: Tg,
  insert_hydration: qg,
  noop: Lg,
  safe_not_equal: zg,
  svg_element: Ig
} = window.__gradio__svelte__internal, {
  SvelteComponent: Mg,
  append_hydration: Rg,
  attr: Og,
  children: Ng,
  claim_svg_element: Pg,
  detach: Hg,
  init: Zg,
  insert_hydration: jg,
  noop: Ug,
  safe_not_equal: Gg,
  svg_element: Vg
} = window.__gradio__svelte__internal, {
  SvelteComponent: Xg,
  append_hydration: Wg,
  attr: Yg,
  children: Kg,
  claim_svg_element: Qg,
  detach: Jg,
  init: eb,
  insert_hydration: tb,
  noop: nb,
  safe_not_equal: ib,
  svg_element: lb
} = window.__gradio__svelte__internal, {
  SvelteComponent: ab,
  append_hydration: ob,
  attr: rb,
  children: sb,
  claim_svg_element: ub,
  detach: cb,
  init: _b,
  insert_hydration: db,
  noop: fb,
  safe_not_equal: hb,
  svg_element: pb
} = window.__gradio__svelte__internal, {
  SvelteComponent: mb,
  append_hydration: gb,
  attr: bb,
  children: vb,
  claim_svg_element: Db,
  detach: wb,
  init: yb,
  insert_hydration: kb,
  noop: Fb,
  safe_not_equal: $b,
  svg_element: Cb
} = window.__gradio__svelte__internal, {
  SvelteComponent: Eb,
  append_hydration: Ab,
  attr: Sb,
  children: Bb,
  claim_svg_element: xb,
  detach: Tb,
  init: qb,
  insert_hydration: Lb,
  noop: zb,
  safe_not_equal: Ib,
  svg_element: Mb
} = window.__gradio__svelte__internal, {
  SvelteComponent: Rb,
  append_hydration: Ob,
  attr: Nb,
  children: Pb,
  claim_svg_element: Hb,
  detach: Zb,
  init: jb,
  insert_hydration: Ub,
  noop: Gb,
  safe_not_equal: Vb,
  svg_element: Xb
} = window.__gradio__svelte__internal, {
  SvelteComponent: Wb,
  append_hydration: Yb,
  attr: Kb,
  children: Qb,
  claim_svg_element: Jb,
  detach: ev,
  init: tv,
  insert_hydration: nv,
  noop: iv,
  safe_not_equal: lv,
  svg_element: av
} = window.__gradio__svelte__internal, {
  SvelteComponent: ov,
  append_hydration: rv,
  attr: sv,
  children: uv,
  claim_svg_element: cv,
  detach: _v,
  init: dv,
  insert_hydration: fv,
  noop: hv,
  safe_not_equal: pv,
  set_style: mv,
  svg_element: gv
} = window.__gradio__svelte__internal, {
  SvelteComponent: bv,
  append_hydration: vv,
  attr: Dv,
  children: wv,
  claim_svg_element: yv,
  detach: kv,
  init: Fv,
  insert_hydration: $v,
  noop: Cv,
  safe_not_equal: Ev,
  svg_element: Av
} = window.__gradio__svelte__internal, {
  SvelteComponent: Sv,
  append_hydration: Bv,
  attr: xv,
  children: Tv,
  claim_svg_element: qv,
  detach: Lv,
  init: zv,
  insert_hydration: Iv,
  noop: Mv,
  safe_not_equal: Rv,
  svg_element: Ov
} = window.__gradio__svelte__internal, {
  SvelteComponent: ku,
  append_hydration: rn,
  attr: fe,
  children: Ct,
  claim_svg_element: Et,
  detach: _t,
  init: Fu,
  insert_hydration: $u,
  noop: On,
  safe_not_equal: Cu,
  svg_element: At
} = window.__gradio__svelte__internal;
function Eu(i) {
  let e, t, n, l, a;
  return {
    c() {
      e = At("svg"), t = At("g"), n = At("g"), l = At("g"), a = At("path"), this.h();
    },
    l(o) {
      e = Et(o, "svg", {
        viewBox: !0,
        width: !0,
        height: !0,
        fill: !0,
        xmlns: !0
      });
      var r = Ct(e);
      t = Et(r, "g", { id: !0, "stroke-width": !0 }), Ct(t).forEach(_t), n = Et(r, "g", {
        id: !0,
        "stroke-linecap": !0,
        "stroke-linejoin": !0
      }), Ct(n).forEach(_t), l = Et(r, "g", { id: !0 });
      var u = Ct(l);
      a = Et(u, "path", { d: !0, fill: !0 }), Ct(a).forEach(_t), u.forEach(_t), r.forEach(_t), this.h();
    },
    h() {
      fe(t, "id", "SVGRepo_bgCarrier"), fe(t, "stroke-width", "0"), fe(n, "id", "SVGRepo_tracerCarrier"), fe(n, "stroke-linecap", "round"), fe(n, "stroke-linejoin", "round"), fe(a, "d", "M19.1168 12.1484C19.474 12.3581 19.9336 12.2384 20.1432 11.8811C20.3528 11.5238 20.2331 11.0643 19.8758 10.8547L19.1168 12.1484ZM6.94331 4.13656L6.55624 4.77902L6.56378 4.78344L6.94331 4.13656ZM5.92408 4.1598L5.50816 3.5357L5.50816 3.5357L5.92408 4.1598ZM5.51031 5.09156L4.76841 5.20151C4.77575 5.25101 4.78802 5.29965 4.80505 5.34671L5.51031 5.09156ZM7.12405 11.7567C7.26496 12.1462 7.69495 12.3477 8.08446 12.2068C8.47397 12.0659 8.67549 11.6359 8.53458 11.2464L7.12405 11.7567ZM19.8758 12.1484C20.2331 11.9388 20.3528 11.4793 20.1432 11.122C19.9336 10.7648 19.474 10.6451 19.1168 10.8547L19.8758 12.1484ZM6.94331 18.8666L6.56375 18.2196L6.55627 18.2241L6.94331 18.8666ZM5.92408 18.8433L5.50815 19.4674H5.50815L5.92408 18.8433ZM5.51031 17.9116L4.80505 17.6564C4.78802 17.7035 4.77575 17.7521 4.76841 17.8016L5.51031 17.9116ZM8.53458 11.7567C8.67549 11.3672 8.47397 10.9372 8.08446 10.7963C7.69495 10.6554 7.26496 10.8569 7.12405 11.2464L8.53458 11.7567ZM19.4963 12.2516C19.9105 12.2516 20.2463 11.9158 20.2463 11.5016C20.2463 11.0873 19.9105 10.7516 19.4963 10.7516V12.2516ZM7.82931 10.7516C7.4151 10.7516 7.07931 11.0873 7.07931 11.5016C7.07931 11.9158 7.4151 12.2516 7.82931 12.2516V10.7516ZM19.8758 10.8547L7.32284 3.48968L6.56378 4.78344L19.1168 12.1484L19.8758 10.8547ZM7.33035 3.49414C6.76609 3.15419 6.05633 3.17038 5.50816 3.5357L6.34 4.78391C6.40506 4.74055 6.4893 4.73863 6.55627 4.77898L7.33035 3.49414ZM5.50816 3.5357C4.95998 3.90102 4.67184 4.54987 4.76841 5.20151L6.25221 4.98161C6.24075 4.90427 6.27494 4.82727 6.34 4.78391L5.50816 3.5357ZM4.80505 5.34671L7.12405 11.7567L8.53458 11.2464L6.21558 4.83641L4.80505 5.34671ZM19.1168 10.8547L6.56378 18.2197L7.32284 19.5134L19.8758 12.1484L19.1168 10.8547ZM6.55627 18.2241C6.4893 18.2645 6.40506 18.2626 6.34 18.2192L5.50815 19.4674C6.05633 19.8327 6.76609 19.8489 7.33035 19.509L6.55627 18.2241ZM6.34 18.2192C6.27494 18.1759 6.24075 18.0988 6.25221 18.0215L4.76841 17.8016C4.67184 18.4532 4.95998 19.1021 5.50815 19.4674L6.34 18.2192ZM6.21558 18.1667L8.53458 11.7567L7.12405 11.2464L4.80505 17.6564L6.21558 18.1667ZM19.4963 10.7516H7.82931V12.2516H19.4963V10.7516Z"), fe(a, "fill", "currentColor"), fe(l, "id", "SVGRepo_iconCarrier"), fe(e, "viewBox", "0 0 22 24"), fe(e, "width", "100%"), fe(e, "height", "100%"), fe(e, "fill", "none"), fe(e, "xmlns", "http://www.w3.org/2000/svg");
    },
    m(o, r) {
      $u(o, e, r), rn(e, t), rn(e, n), rn(e, l), rn(l, a);
    },
    p: On,
    i: On,
    o: On,
    d(o) {
      o && _t(e);
    }
  };
}
class Au extends ku {
  constructor(e) {
    super(), Fu(this, e, null, Eu, Cu, {});
  }
}
const {
  SvelteComponent: Nv,
  append_hydration: Pv,
  attr: Hv,
  children: Zv,
  claim_svg_element: jv,
  detach: Uv,
  init: Gv,
  insert_hydration: Vv,
  noop: Xv,
  safe_not_equal: Wv,
  svg_element: Yv
} = window.__gradio__svelte__internal, {
  SvelteComponent: Kv,
  append_hydration: Qv,
  attr: Jv,
  children: e2,
  claim_svg_element: t2,
  detach: n2,
  init: i2,
  insert_hydration: l2,
  noop: a2,
  safe_not_equal: o2,
  svg_element: r2
} = window.__gradio__svelte__internal, {
  SvelteComponent: Su,
  append_hydration: Bu,
  attr: ie,
  children: Wi,
  claim_svg_element: Yi,
  detach: Nn,
  init: xu,
  insert_hydration: Tu,
  noop: Ki,
  safe_not_equal: qu,
  svg_element: Qi
} = window.__gradio__svelte__internal;
function Lu(i) {
  let e, t, n;
  return {
    c() {
      e = Qi("svg"), t = Qi("rect"), this.h();
    },
    l(l) {
      e = Yi(l, "svg", {
        xmlns: !0,
        width: !0,
        height: !0,
        viewBox: !0,
        fill: !0,
        stroke: !0,
        "stroke-width": !0,
        "stroke-linecap": !0,
        "stroke-linejoin": !0,
        class: !0
      });
      var a = Wi(e);
      t = Yi(a, "rect", {
        x: !0,
        y: !0,
        width: !0,
        height: !0,
        rx: !0,
        ry: !0
      }), Wi(t).forEach(Nn), a.forEach(Nn), this.h();
    },
    h() {
      ie(t, "x", "3"), ie(t, "y", "3"), ie(t, "width", "18"), ie(t, "height", "18"), ie(t, "rx", "2"), ie(t, "ry", "2"), ie(e, "xmlns", "http://www.w3.org/2000/svg"), ie(e, "width", "100%"), ie(e, "height", "100%"), ie(e, "viewBox", "0 0 24 24"), ie(
        e,
        "fill",
        /*fill*/
        i[0]
      ), ie(e, "stroke", "currentColor"), ie(e, "stroke-width", n = `${/*stroke_width*/
      i[1]}`), ie(e, "stroke-linecap", "round"), ie(e, "stroke-linejoin", "round"), ie(e, "class", "feather feather-square");
    },
    m(l, a) {
      Tu(l, e, a), Bu(e, t);
    },
    p(l, [a]) {
      a & /*fill*/
      1 && ie(
        e,
        "fill",
        /*fill*/
        l[0]
      ), a & /*stroke_width*/
      2 && n !== (n = `${/*stroke_width*/
      l[1]}`) && ie(e, "stroke-width", n);
    },
    i: Ki,
    o: Ki,
    d(l) {
      l && Nn(e);
    }
  };
}
function zu(i, e, t) {
  let { fill: n = "currentColor" } = e, { stroke_width: l = 1.5 } = e;
  return i.$$set = (a) => {
    "fill" in a && t(0, n = a.fill), "stroke_width" in a && t(1, l = a.stroke_width);
  }, [n, l];
}
class Iu extends Su {
  constructor(e) {
    super(), xu(this, e, zu, Lu, qu, { fill: 0, stroke_width: 1 });
  }
}
const {
  SvelteComponent: s2,
  append_hydration: u2,
  attr: c2,
  children: _2,
  claim_svg_element: d2,
  detach: f2,
  init: h2,
  insert_hydration: p2,
  noop: m2,
  safe_not_equal: g2,
  svg_element: b2
} = window.__gradio__svelte__internal, {
  SvelteComponent: v2,
  append_hydration: D2,
  attr: w2,
  children: y2,
  claim_svg_element: k2,
  detach: F2,
  init: $2,
  insert_hydration: C2,
  noop: E2,
  safe_not_equal: A2,
  svg_element: S2
} = window.__gradio__svelte__internal, {
  SvelteComponent: B2,
  append_hydration: x2,
  attr: T2,
  children: q2,
  claim_svg_element: L2,
  claim_text: z2,
  detach: I2,
  init: M2,
  insert_hydration: R2,
  noop: O2,
  safe_not_equal: N2,
  svg_element: P2,
  text: H2
} = window.__gradio__svelte__internal, {
  SvelteComponent: Z2,
  append_hydration: j2,
  attr: U2,
  children: G2,
  claim_svg_element: V2,
  detach: X2,
  init: W2,
  insert_hydration: Y2,
  noop: K2,
  safe_not_equal: Q2,
  svg_element: J2
} = window.__gradio__svelte__internal, {
  SvelteComponent: eD,
  append_hydration: tD,
  attr: nD,
  children: iD,
  claim_svg_element: lD,
  detach: aD,
  init: oD,
  insert_hydration: rD,
  noop: sD,
  safe_not_equal: uD,
  svg_element: cD
} = window.__gradio__svelte__internal, {
  SvelteComponent: _D,
  append_hydration: dD,
  attr: fD,
  children: hD,
  claim_svg_element: pD,
  detach: mD,
  init: gD,
  insert_hydration: bD,
  noop: vD,
  safe_not_equal: DD,
  svg_element: wD
} = window.__gradio__svelte__internal, {
  SvelteComponent: yD,
  append_hydration: kD,
  attr: FD,
  children: $D,
  claim_svg_element: CD,
  detach: ED,
  init: AD,
  insert_hydration: SD,
  noop: BD,
  safe_not_equal: xD,
  svg_element: TD
} = window.__gradio__svelte__internal, {
  SvelteComponent: qD,
  append_hydration: LD,
  attr: zD,
  children: ID,
  claim_svg_element: MD,
  detach: RD,
  init: OD,
  insert_hydration: ND,
  noop: PD,
  safe_not_equal: HD,
  svg_element: ZD
} = window.__gradio__svelte__internal, {
  SvelteComponent: jD,
  append_hydration: UD,
  attr: GD,
  children: VD,
  claim_svg_element: XD,
  detach: WD,
  init: YD,
  insert_hydration: KD,
  noop: QD,
  safe_not_equal: JD,
  svg_element: ew
} = window.__gradio__svelte__internal, {
  SvelteComponent: tw,
  append_hydration: nw,
  attr: iw,
  children: lw,
  claim_svg_element: aw,
  detach: ow,
  init: rw,
  insert_hydration: sw,
  noop: uw,
  safe_not_equal: cw,
  svg_element: _w
} = window.__gradio__svelte__internal, {
  SvelteComponent: dw,
  append_hydration: fw,
  attr: hw,
  children: pw,
  claim_svg_element: mw,
  claim_text: gw,
  detach: bw,
  init: vw,
  insert_hydration: Dw,
  noop: ww,
  safe_not_equal: yw,
  svg_element: kw,
  text: Fw
} = window.__gradio__svelte__internal, {
  SvelteComponent: $w,
  append_hydration: Cw,
  attr: Ew,
  children: Aw,
  claim_svg_element: Sw,
  claim_text: Bw,
  detach: xw,
  init: Tw,
  insert_hydration: qw,
  noop: Lw,
  safe_not_equal: zw,
  svg_element: Iw,
  text: Mw
} = window.__gradio__svelte__internal, {
  SvelteComponent: Rw,
  append_hydration: Ow,
  attr: Nw,
  children: Pw,
  claim_svg_element: Hw,
  claim_text: Zw,
  detach: jw,
  init: Uw,
  insert_hydration: Gw,
  noop: Vw,
  safe_not_equal: Xw,
  svg_element: Ww,
  text: Yw
} = window.__gradio__svelte__internal, {
  SvelteComponent: Kw,
  append_hydration: Qw,
  attr: Jw,
  children: ey,
  claim_svg_element: ty,
  detach: ny,
  init: iy,
  insert_hydration: ly,
  noop: ay,
  safe_not_equal: oy,
  svg_element: ry
} = window.__gradio__svelte__internal, {
  SvelteComponent: sy,
  append_hydration: uy,
  attr: cy,
  children: _y,
  claim_svg_element: dy,
  detach: fy,
  init: hy,
  insert_hydration: py,
  noop: my,
  safe_not_equal: gy,
  svg_element: by
} = window.__gradio__svelte__internal, {
  SvelteComponent: vy,
  append_hydration: Dy,
  attr: wy,
  children: yy,
  claim_svg_element: ky,
  detach: Fy,
  init: $y,
  insert_hydration: Cy,
  noop: Ey,
  safe_not_equal: Ay,
  svg_element: Sy
} = window.__gradio__svelte__internal, {
  SvelteComponent: By,
  append_hydration: xy,
  attr: Ty,
  children: qy,
  claim_svg_element: Ly,
  detach: zy,
  init: Iy,
  insert_hydration: My,
  noop: Ry,
  safe_not_equal: Oy,
  svg_element: Ny
} = window.__gradio__svelte__internal, {
  SvelteComponent: Py,
  append_hydration: Hy,
  attr: Zy,
  children: jy,
  claim_svg_element: Uy,
  detach: Gy,
  init: Vy,
  insert_hydration: Xy,
  noop: Wy,
  safe_not_equal: Yy,
  svg_element: Ky
} = window.__gradio__svelte__internal, {
  SvelteComponent: Qy,
  append_hydration: Jy,
  attr: ek,
  children: tk,
  claim_svg_element: nk,
  detach: ik,
  init: lk,
  insert_hydration: ak,
  noop: ok,
  safe_not_equal: rk,
  svg_element: sk
} = window.__gradio__svelte__internal, {
  SvelteComponent: uk,
  append_hydration: ck,
  attr: _k,
  children: dk,
  claim_svg_element: fk,
  detach: hk,
  init: pk,
  insert_hydration: mk,
  noop: gk,
  safe_not_equal: bk,
  svg_element: vk
} = window.__gradio__svelte__internal, {
  SvelteComponent: Dk,
  append_hydration: wk,
  attr: yk,
  children: kk,
  claim_svg_element: Fk,
  detach: $k,
  init: Ck,
  insert_hydration: Ek,
  noop: Ak,
  safe_not_equal: Sk,
  svg_element: Bk
} = window.__gradio__svelte__internal, {
  SvelteComponent: xk,
  append_hydration: Tk,
  attr: qk,
  children: Lk,
  claim_svg_element: zk,
  detach: Ik,
  init: Mk,
  insert_hydration: Rk,
  noop: Ok,
  safe_not_equal: Nk,
  svg_element: Pk
} = window.__gradio__svelte__internal, {
  SvelteComponent: Hk,
  append_hydration: Zk,
  attr: jk,
  children: Uk,
  claim_svg_element: Gk,
  detach: Vk,
  init: Xk,
  insert_hydration: Wk,
  noop: Yk,
  safe_not_equal: Kk,
  svg_element: Qk
} = window.__gradio__svelte__internal, {
  SvelteComponent: Jk,
  append_hydration: eF,
  attr: tF,
  children: nF,
  claim_svg_element: iF,
  detach: lF,
  init: aF,
  insert_hydration: oF,
  noop: rF,
  safe_not_equal: sF,
  svg_element: uF
} = window.__gradio__svelte__internal, Mu = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], Ji = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
Mu.reduce(
  (i, { color: e, primary: t, secondary: n }) => ({
    ...i,
    [e]: {
      primary: Ji[e][t],
      secondary: Ji[e][n]
    }
  }),
  {}
);
const {
  SvelteComponent: cF,
  claim_component: _F,
  create_component: dF,
  destroy_component: fF,
  init: hF,
  mount_component: pF,
  safe_not_equal: mF,
  transition_in: gF,
  transition_out: bF
} = window.__gradio__svelte__internal, { createEventDispatcher: vF } = window.__gradio__svelte__internal, {
  SvelteComponent: DF,
  append_hydration: wF,
  attr: yF,
  check_outros: kF,
  children: FF,
  claim_component: $F,
  claim_element: CF,
  claim_space: EF,
  claim_text: AF,
  create_component: SF,
  destroy_component: BF,
  detach: xF,
  element: TF,
  empty: qF,
  group_outros: LF,
  init: zF,
  insert_hydration: IF,
  mount_component: MF,
  safe_not_equal: RF,
  set_data: OF,
  space: NF,
  text: PF,
  toggle_class: HF,
  transition_in: ZF,
  transition_out: jF
} = window.__gradio__svelte__internal, {
  SvelteComponent: UF,
  attr: GF,
  children: VF,
  claim_element: XF,
  create_slot: WF,
  detach: YF,
  element: KF,
  get_all_dirty_from_scope: QF,
  get_slot_changes: JF,
  init: e4,
  insert_hydration: t4,
  safe_not_equal: n4,
  toggle_class: i4,
  transition_in: l4,
  transition_out: a4,
  update_slot_base: o4
} = window.__gradio__svelte__internal, {
  SvelteComponent: r4,
  append_hydration: s4,
  attr: u4,
  check_outros: c4,
  children: _4,
  claim_component: d4,
  claim_element: f4,
  claim_space: h4,
  create_component: p4,
  destroy_component: m4,
  detach: g4,
  element: b4,
  empty: v4,
  group_outros: D4,
  init: w4,
  insert_hydration: y4,
  listen: k4,
  mount_component: F4,
  safe_not_equal: $4,
  space: C4,
  toggle_class: E4,
  transition_in: A4,
  transition_out: S4
} = window.__gradio__svelte__internal, {
  SvelteComponent: B4,
  attr: x4,
  children: T4,
  claim_element: q4,
  create_slot: L4,
  detach: z4,
  element: I4,
  get_all_dirty_from_scope: M4,
  get_slot_changes: R4,
  init: O4,
  insert_hydration: N4,
  null_to_empty: P4,
  safe_not_equal: H4,
  transition_in: Z4,
  transition_out: j4,
  update_slot_base: U4
} = window.__gradio__svelte__internal, {
  SvelteComponent: G4,
  check_outros: V4,
  claim_component: X4,
  create_component: W4,
  destroy_component: Y4,
  detach: K4,
  empty: Q4,
  group_outros: J4,
  init: e3,
  insert_hydration: t3,
  mount_component: n3,
  noop: i3,
  safe_not_equal: l3,
  transition_in: a3,
  transition_out: o3
} = window.__gradio__svelte__internal, { createEventDispatcher: r3 } = window.__gradio__svelte__internal;
function hn() {
}
const Ru = (i) => i, ha = typeof window < "u";
let el = ha ? () => window.performance.now() : () => Date.now(), pa = ha ? (i) => requestAnimationFrame(i) : hn;
const gt = /* @__PURE__ */ new Set();
function ma(i) {
  gt.forEach((e) => {
    e.c(i) || (gt.delete(e), e.f());
  }), gt.size !== 0 && pa(ma);
}
function Ou(i) {
  let e;
  return gt.size === 0 && pa(ma), { promise: new Promise((t) => {
    gt.add(e = { c: i, f: t });
  }), abort() {
    gt.delete(e);
  } };
}
function Nu(i, { delay: e = 0, duration: t = 400, easing: n = Ru } = {}) {
  const l = +getComputedStyle(i).opacity;
  return { delay: e, duration: t, easing: n, css: (a) => "opacity: " + a * l };
}
const dt = [];
function Pu(i, e = hn) {
  let t;
  const n = /* @__PURE__ */ new Set();
  function l(o) {
    if (u = o, ((r = i) != r ? u == u : r !== u || r && typeof r == "object" || typeof r == "function") && (i = o, t)) {
      const c = !dt.length;
      for (const s of n) s[1](), dt.push(s, i);
      if (c) {
        for (let s = 0; s < dt.length; s += 2) dt[s][0](dt[s + 1]);
        dt.length = 0;
      }
    }
    var r, u;
  }
  function a(o) {
    l(o(i));
  }
  return { set: l, update: a, subscribe: function(o, r = hn) {
    const u = [o, r];
    return n.add(u), n.size === 1 && (t = e(l, a) || hn), o(i), () => {
      n.delete(u), n.size === 0 && t && (t(), t = null);
    };
  } };
}
function tl(i) {
  return Object.prototype.toString.call(i) === "[object Date]";
}
function Yn(i, e, t, n) {
  if (typeof t == "number" || tl(t)) {
    const l = n - t, a = (t - e) / (i.dt || 1 / 60), o = (a + (i.opts.stiffness * l - i.opts.damping * a) * i.inv_mass) * i.dt;
    return Math.abs(o) < i.opts.precision && Math.abs(l) < i.opts.precision ? n : (i.settled = !1, tl(t) ? new Date(t.getTime() + o) : t + o);
  }
  if (Array.isArray(t)) return t.map((l, a) => Yn(i, e[a], t[a], n[a]));
  if (typeof t == "object") {
    const l = {};
    for (const a in t) l[a] = Yn(i, e[a], t[a], n[a]);
    return l;
  }
  throw new Error(`Cannot spring ${typeof t} values`);
}
function nl(i, e = {}) {
  const t = Pu(i), { stiffness: n = 0.15, damping: l = 0.8, precision: a = 0.01 } = e;
  let o, r, u, c = i, s = i, d = 1, f = 0, h = !1;
  function p(k, C = {}) {
    s = k;
    const m = u = {};
    return i == null || C.hard || v.stiffness >= 1 && v.damping >= 1 ? (h = !0, o = el(), c = k, t.set(i = s), Promise.resolve()) : (C.soft && (f = 1 / (60 * (C.soft === !0 ? 0.5 : +C.soft)), d = 0), r || (o = el(), h = !1, r = Ou((_) => {
      if (h) return h = !1, r = null, !1;
      d = Math.min(d + f, 1);
      const g = { inv_mass: d, opts: v, settled: !0, dt: 60 * (_ - o) / 1e3 }, D = Yn(g, c, i, s);
      return o = _, c = i, t.set(i = D), g.settled && (r = null), !g.settled;
    })), new Promise((_) => {
      r.promise.then(() => {
        m === u && _();
      });
    }));
  }
  const v = { set: p, update: (k, C) => p(k(s, i), C), subscribe: t.subscribe, stiffness: n, damping: l, precision: a };
  return v;
}
const {
  SvelteComponent: Hu,
  action_destroyer: ga,
  add_render_callback: Zu,
  append_hydration: pe,
  attr: F,
  binding_callbacks: ft,
  bubble: Ve,
  check_outros: bt,
  children: we,
  claim_component: Rt,
  claim_element: ce,
  claim_space: et,
  claim_text: Ot,
  create_component: Nt,
  create_in_transition: ju,
  destroy_component: Pt,
  detach: O,
  element: _e,
  empty: bn,
  get_svelte_dataset: Uu,
  group_outros: vt,
  init: Gu,
  insert_hydration: re,
  is_function: Vu,
  listen: Z,
  mount_component: Ht,
  noop: Ye,
  run_all: Zt,
  safe_not_equal: Xu,
  set_data: jt,
  set_input_value: Ke,
  space: tt,
  text: Ut,
  toggle_class: je,
  transition_in: J,
  transition_out: oe
} = window.__gradio__svelte__internal, { beforeUpdate: Wu, afterUpdate: Yu, createEventDispatcher: Ku, tick: Pn } = window.__gradio__svelte__internal;
function il(i) {
  let e, t, n, l;
  const a = [Ju, Qu], o = [];
  function r(u, c) {
    return (
      /*copied*/
      u[20] ? 0 : 1
    );
  }
  return e = r(i), t = o[e] = a[e](i), {
    c() {
      t.c(), n = bn();
    },
    l(u) {
      t.l(u), n = bn();
    },
    m(u, c) {
      o[e].m(u, c), re(u, n, c), l = !0;
    },
    p(u, c) {
      let s = e;
      e = r(u), e === s ? o[e].p(u, c) : (vt(), oe(o[s], 1, 1, () => {
        o[s] = null;
      }), bt(), t = o[e], t ? t.p(u, c) : (t = o[e] = a[e](u), t.c()), J(t, 1), t.m(n.parentNode, n));
    },
    i(u) {
      l || (J(t), l = !0);
    },
    o(u) {
      oe(t), l = !1;
    },
    d(u) {
      u && O(n), o[e].d(u);
    }
  };
}
function Qu(i) {
  let e, t, n, l, a;
  return t = new yu({}), {
    c() {
      e = _e("button"), Nt(t.$$.fragment), this.h();
    },
    l(o) {
      e = ce(o, "BUTTON", {
        class: !0,
        "aria-label": !0,
        "aria-roledescription": !0
      });
      var r = we(e);
      Rt(t.$$.fragment, r), r.forEach(O), this.h();
    },
    h() {
      F(e, "class", "copy-button svelte-myok72"), F(e, "aria-label", "Copy"), F(e, "aria-roledescription", "Copy text");
    },
    m(o, r) {
      re(o, e, r), Ht(t, e, null), n = !0, l || (a = Z(
        e,
        "click",
        /*handle_copy*/
        i[26]
      ), l = !0);
    },
    p: Ye,
    i(o) {
      n || (J(t.$$.fragment, o), n = !0);
    },
    o(o) {
      oe(t.$$.fragment, o), n = !1;
    },
    d(o) {
      o && O(e), Pt(t), l = !1, a();
    }
  };
}
function Ju(i) {
  let e, t, n, l;
  return t = new cu({}), {
    c() {
      e = _e("button"), Nt(t.$$.fragment), this.h();
    },
    l(a) {
      e = ce(a, "BUTTON", {
        class: !0,
        "aria-label": !0,
        "aria-roledescription": !0
      });
      var o = we(e);
      Rt(t.$$.fragment, o), o.forEach(O), this.h();
    },
    h() {
      F(e, "class", "copy-button svelte-myok72"), F(e, "aria-label", "Copied"), F(e, "aria-roledescription", "Text copied");
    },
    m(a, o) {
      re(a, e, o), Ht(t, e, null), l = !0;
    },
    p: Ye,
    i(a) {
      l || (J(t.$$.fragment, a), a && (n || Zu(() => {
        n = ju(e, Nu, { duration: 300 }), n.start();
      })), l = !0);
    },
    o(a) {
      oe(t.$$.fragment, a), l = !1;
    },
    d(a) {
      a && O(e), Pt(t);
    }
  };
}
function ec(i) {
  let e;
  return {
    c() {
      e = Ut(
        /*label*/
        i[3]
      );
    },
    l(t) {
      e = Ot(
        t,
        /*label*/
        i[3]
      );
    },
    m(t, n) {
      re(t, e, n);
    },
    p(t, n) {
      n[0] & /*label*/
      8 && jt(
        e,
        /*label*/
        t[3]
      );
    },
    d(t) {
      t && O(e);
    }
  };
}
function ll(i) {
  let e, t, n = "?", l, a, o, r = (
    /*show_tooltip*/
    i[21] && al(i)
  );
  return {
    c() {
      e = _e("div"), t = _e("span"), t.textContent = n, l = tt(), r && r.c(), this.h();
    },
    l(u) {
      e = ce(u, "DIV", {
        class: !0,
        role: !0,
        tabindex: !0,
        "aria-label": !0
      });
      var c = we(e);
      t = ce(c, "SPAN", { class: !0, "data-svelte-h": !0 }), Uu(t) !== "svelte-ekz8yf" && (t.textContent = n), l = et(c), r && r.l(c), c.forEach(O), this.h();
    },
    h() {
      F(t, "class", "tooltip-icon svelte-myok72"), F(e, "class", "tooltip-container svelte-myok72"), F(e, "role", "button"), F(e, "tabindex", "0"), F(e, "aria-label", "Help");
    },
    m(u, c) {
      re(u, e, c), pe(e, t), i[44](t), pe(e, l), r && r.m(e, null), a || (o = [
        Z(
          e,
          "mouseenter",
          /*handle_show_tooltip*/
          i[25]
        ),
        Z(
          e,
          "mouseleave",
          /*mouseleave_handler*/
          i[46]
        ),
        Z(
          e,
          "focusin",
          /*handle_show_tooltip*/
          i[25]
        ),
        Z(
          e,
          "focusout",
          /*focusout_handler*/
          i[47]
        )
      ], a = !0);
    },
    p(u, c) {
      /*show_tooltip*/
      u[21] ? r ? r.p(u, c) : (r = al(u), r.c(), r.m(e, null)) : r && (r.d(1), r = null);
    },
    d(u) {
      u && O(e), i[44](null), r && r.d(), a = !1, Zt(o);
    }
  };
}
function al(i) {
  let e, t, n, l;
  return {
    c() {
      e = _e("span"), t = Ut(
        /*help*/
        i[5]
      ), this.h();
    },
    l(a) {
      e = ce(a, "SPAN", { class: !0 });
      var o = we(e);
      t = Ot(
        o,
        /*help*/
        i[5]
      ), o.forEach(O), this.h();
    },
    h() {
      F(e, "class", "tooltip-text svelte-myok72");
    },
    m(a, o) {
      re(a, e, o), pe(e, t), i[45](e), n || (l = ga(_c.call(null, e)), n = !0);
    },
    p(a, o) {
      o[0] & /*help*/
      32 && jt(
        t,
        /*help*/
        a[5]
      );
    },
    d(a) {
      a && O(e), i[45](null), n = !1, l();
    }
  };
}
function ol(i) {
  let e, t;
  return {
    c() {
      e = _e("div"), t = Ut(
        /*info*/
        i[4]
      ), this.h();
    },
    l(n) {
      e = ce(n, "DIV", { class: !0 });
      var l = we(e);
      t = Ot(
        l,
        /*info*/
        i[4]
      ), l.forEach(O), this.h();
    },
    h() {
      F(e, "class", "info-text svelte-myok72");
    },
    m(n, l) {
      re(n, e, l), pe(e, t);
    },
    p(n, l) {
      l[0] & /*info*/
      16 && jt(
        t,
        /*info*/
        n[4]
      );
    },
    d(n) {
      n && O(e);
    }
  };
}
function tc(i) {
  let e, t, n, l, a, o, r, u, c, s, d, f, h;
  return {
    c() {
      e = _e("textarea"), this.h();
    },
    l(p) {
      e = ce(p, "TEXTAREA", {
        "data-testid": !0,
        dir: !0,
        placeholder: !0,
        rows: !0,
        maxlength: !0,
        style: !0,
        autocapitalize: !0,
        autocorrect: !0,
        spellcheck: !0,
        autocomplete: !0,
        tabindex: !0,
        enterkeyhint: !0,
        lang: !0,
        class: !0
      }), we(e).forEach(O), this.h();
    },
    h() {
      var p, v, k, C, m, _, g;
      F(e, "data-testid", "textbox"), F(e, "dir", t = /*rtl*/
      i[13] ? "rtl" : "ltr"), F(
        e,
        "placeholder",
        /*placeholder*/
        i[2]
      ), F(
        e,
        "rows",
        /*lines*/
        i[1]
      ), e.disabled = /*disabled*/
      i[6], e.autofocus = /*autofocus*/
      i[14], F(
        e,
        "maxlength",
        /*max_length*/
        i[16]
      ), F(e, "style", n = /*text_align*/
      i[15] ? "text-align: " + /*text_align*/
      i[15] : ""), F(e, "autocapitalize", l = /*html_attributes*/
      (p = i[17]) == null ? void 0 : p.autocapitalize), F(e, "autocorrect", a = /*html_attributes*/
      (v = i[17]) == null ? void 0 : v.autocorrect), F(e, "spellcheck", o = /*html_attributes*/
      (k = i[17]) == null ? void 0 : k.spellcheck), F(e, "autocomplete", r = /*html_attributes*/
      (C = i[17]) == null ? void 0 : C.autocomplete), F(e, "tabindex", u = /*html_attributes*/
      (m = i[17]) == null ? void 0 : m.tabindex), F(e, "enterkeyhint", c = /*html_attributes*/
      (_ = i[17]) == null ? void 0 : _.enterkeyhint), F(e, "lang", s = /*html_attributes*/
      (g = i[17]) == null ? void 0 : g.lang), F(e, "class", "svelte-myok72"), je(e, "no-label", !/*show_label*/
      i[7] && /*submit_btn*/
      (i[11] || /*stop_btn*/
      i[12]));
    },
    m(p, v) {
      re(p, e, v), Ke(
        e,
        /*value*/
        i[0]
      ), i[55](e), /*autofocus*/
      i[14] && e.focus(), f || (h = [
        ga(d = /*text_area_resize*/
        i[32].call(
          null,
          e,
          /*value*/
          i[0]
        )),
        Z(
          e,
          "input",
          /*textarea_input_handler*/
          i[54]
        ),
        Z(
          e,
          "keypress",
          /*handle_keypress*/
          i[28]
        ),
        Z(
          e,
          "blur",
          /*blur_handler_3*/
          i[42]
        ),
        Z(
          e,
          "select",
          /*handle_select*/
          i[27]
        ),
        Z(
          e,
          "focus",
          /*focus_handler_3*/
          i[43]
        ),
        Z(
          e,
          "scroll",
          /*handle_scroll*/
          i[29]
        )
      ], f = !0);
    },
    p(p, v) {
      var k, C, m, _, g, D, b;
      v[0] & /*rtl*/
      8192 && t !== (t = /*rtl*/
      p[13] ? "rtl" : "ltr") && F(e, "dir", t), v[0] & /*placeholder*/
      4 && F(
        e,
        "placeholder",
        /*placeholder*/
        p[2]
      ), v[0] & /*lines*/
      2 && F(
        e,
        "rows",
        /*lines*/
        p[1]
      ), v[0] & /*disabled*/
      64 && (e.disabled = /*disabled*/
      p[6]), v[0] & /*autofocus*/
      16384 && (e.autofocus = /*autofocus*/
      p[14]), v[0] & /*max_length*/
      65536 && F(
        e,
        "maxlength",
        /*max_length*/
        p[16]
      ), v[0] & /*text_align*/
      32768 && n !== (n = /*text_align*/
      p[15] ? "text-align: " + /*text_align*/
      p[15] : "") && F(e, "style", n), v[0] & /*html_attributes*/
      131072 && l !== (l = /*html_attributes*/
      (k = p[17]) == null ? void 0 : k.autocapitalize) && F(e, "autocapitalize", l), v[0] & /*html_attributes*/
      131072 && a !== (a = /*html_attributes*/
      (C = p[17]) == null ? void 0 : C.autocorrect) && F(e, "autocorrect", a), v[0] & /*html_attributes*/
      131072 && o !== (o = /*html_attributes*/
      (m = p[17]) == null ? void 0 : m.spellcheck) && F(e, "spellcheck", o), v[0] & /*html_attributes*/
      131072 && r !== (r = /*html_attributes*/
      (_ = p[17]) == null ? void 0 : _.autocomplete) && F(e, "autocomplete", r), v[0] & /*html_attributes*/
      131072 && u !== (u = /*html_attributes*/
      (g = p[17]) == null ? void 0 : g.tabindex) && F(e, "tabindex", u), v[0] & /*html_attributes*/
      131072 && c !== (c = /*html_attributes*/
      (D = p[17]) == null ? void 0 : D.enterkeyhint) && F(e, "enterkeyhint", c), v[0] & /*html_attributes*/
      131072 && s !== (s = /*html_attributes*/
      (b = p[17]) == null ? void 0 : b.lang) && F(e, "lang", s), d && Vu(d.update) && v[0] & /*value*/
      1 && d.update.call(
        null,
        /*value*/
        p[0]
      ), v[0] & /*value*/
      1 && Ke(
        e,
        /*value*/
        p[0]
      ), v[0] & /*show_label, submit_btn, stop_btn*/
      6272 && je(e, "no-label", !/*show_label*/
      p[7] && /*submit_btn*/
      (p[11] || /*stop_btn*/
      p[12]));
    },
    d(p) {
      p && O(e), i[55](null), f = !1, Zt(h);
    }
  };
}
function nc(i) {
  let e;
  function t(a, o) {
    if (
      /*type*/
      a[9] === "text"
    ) return ac;
    if (
      /*type*/
      a[9] === "password"
    ) return lc;
    if (
      /*type*/
      a[9] === "email"
    ) return ic;
  }
  let n = t(i), l = n && n(i);
  return {
    c() {
      l && l.c(), e = bn();
    },
    l(a) {
      l && l.l(a), e = bn();
    },
    m(a, o) {
      l && l.m(a, o), re(a, e, o);
    },
    p(a, o) {
      n === (n = t(a)) && l ? l.p(a, o) : (l && l.d(1), l = n && n(a), l && (l.c(), l.m(e.parentNode, e)));
    },
    d(a) {
      a && O(e), l && l.d(a);
    }
  };
}
function ic(i) {
  let e, t, n, l, a, o, r, u, c;
  return {
    c() {
      e = _e("input"), this.h();
    },
    l(s) {
      e = ce(s, "INPUT", {
        "data-testid": !0,
        type: !0,
        class: !0,
        placeholder: !0,
        maxlength: !0,
        autocomplete: !0,
        autocapitalize: !0,
        autocorrect: !0,
        spellcheck: !0,
        tabindex: !0,
        enterkeyhint: !0,
        lang: !0
      }), this.h();
    },
    h() {
      var s, d, f, h, p, v;
      F(e, "data-testid", "textbox"), F(e, "type", "email"), F(e, "class", "scroll-hide svelte-myok72"), F(
        e,
        "placeholder",
        /*placeholder*/
        i[2]
      ), e.disabled = /*disabled*/
      i[6], e.autofocus = /*autofocus*/
      i[14], F(
        e,
        "maxlength",
        /*max_length*/
        i[16]
      ), F(e, "autocomplete", "email"), F(e, "autocapitalize", t = /*html_attributes*/
      (s = i[17]) == null ? void 0 : s.autocapitalize), F(e, "autocorrect", n = /*html_attributes*/
      (d = i[17]) == null ? void 0 : d.autocorrect), F(e, "spellcheck", l = /*html_attributes*/
      (f = i[17]) == null ? void 0 : f.spellcheck), F(e, "tabindex", a = /*html_attributes*/
      (h = i[17]) == null ? void 0 : h.tabindex), F(e, "enterkeyhint", o = /*html_attributes*/
      (p = i[17]) == null ? void 0 : p.enterkeyhint), F(e, "lang", r = /*html_attributes*/
      (v = i[17]) == null ? void 0 : v.lang);
    },
    m(s, d) {
      re(s, e, d), Ke(
        e,
        /*value*/
        i[0]
      ), i[53](e), /*autofocus*/
      i[14] && e.focus(), u || (c = [
        Z(
          e,
          "input",
          /*input_input_handler_2*/
          i[52]
        ),
        Z(
          e,
          "keypress",
          /*handle_keypress*/
          i[28]
        ),
        Z(
          e,
          "blur",
          /*blur_handler_2*/
          i[40]
        ),
        Z(
          e,
          "select",
          /*handle_select*/
          i[27]
        ),
        Z(
          e,
          "focus",
          /*focus_handler_2*/
          i[41]
        )
      ], u = !0);
    },
    p(s, d) {
      var f, h, p, v, k, C;
      d[0] & /*placeholder*/
      4 && F(
        e,
        "placeholder",
        /*placeholder*/
        s[2]
      ), d[0] & /*disabled*/
      64 && (e.disabled = /*disabled*/
      s[6]), d[0] & /*autofocus*/
      16384 && (e.autofocus = /*autofocus*/
      s[14]), d[0] & /*max_length*/
      65536 && F(
        e,
        "maxlength",
        /*max_length*/
        s[16]
      ), d[0] & /*html_attributes*/
      131072 && t !== (t = /*html_attributes*/
      (f = s[17]) == null ? void 0 : f.autocapitalize) && F(e, "autocapitalize", t), d[0] & /*html_attributes*/
      131072 && n !== (n = /*html_attributes*/
      (h = s[17]) == null ? void 0 : h.autocorrect) && F(e, "autocorrect", n), d[0] & /*html_attributes*/
      131072 && l !== (l = /*html_attributes*/
      (p = s[17]) == null ? void 0 : p.spellcheck) && F(e, "spellcheck", l), d[0] & /*html_attributes*/
      131072 && a !== (a = /*html_attributes*/
      (v = s[17]) == null ? void 0 : v.tabindex) && F(e, "tabindex", a), d[0] & /*html_attributes*/
      131072 && o !== (o = /*html_attributes*/
      (k = s[17]) == null ? void 0 : k.enterkeyhint) && F(e, "enterkeyhint", o), d[0] & /*html_attributes*/
      131072 && r !== (r = /*html_attributes*/
      (C = s[17]) == null ? void 0 : C.lang) && F(e, "lang", r), d[0] & /*value*/
      1 && e.value !== /*value*/
      s[0] && Ke(
        e,
        /*value*/
        s[0]
      );
    },
    d(s) {
      s && O(e), i[53](null), u = !1, Zt(c);
    }
  };
}
function lc(i) {
  let e, t, n, l, a, o, r, u, c;
  return {
    c() {
      e = _e("input"), this.h();
    },
    l(s) {
      e = ce(s, "INPUT", {
        "data-testid": !0,
        type: !0,
        class: !0,
        placeholder: !0,
        maxlength: !0,
        autocomplete: !0,
        autocapitalize: !0,
        autocorrect: !0,
        spellcheck: !0,
        tabindex: !0,
        enterkeyhint: !0,
        lang: !0
      }), this.h();
    },
    h() {
      var s, d, f, h, p, v;
      F(e, "data-testid", "password"), F(e, "type", "password"), F(e, "class", "scroll-hide svelte-myok72"), F(
        e,
        "placeholder",
        /*placeholder*/
        i[2]
      ), e.disabled = /*disabled*/
      i[6], e.autofocus = /*autofocus*/
      i[14], F(
        e,
        "maxlength",
        /*max_length*/
        i[16]
      ), F(e, "autocomplete", ""), F(e, "autocapitalize", t = /*html_attributes*/
      (s = i[17]) == null ? void 0 : s.autocapitalize), F(e, "autocorrect", n = /*html_attributes*/
      (d = i[17]) == null ? void 0 : d.autocorrect), F(e, "spellcheck", l = /*html_attributes*/
      (f = i[17]) == null ? void 0 : f.spellcheck), F(e, "tabindex", a = /*html_attributes*/
      (h = i[17]) == null ? void 0 : h.tabindex), F(e, "enterkeyhint", o = /*html_attributes*/
      (p = i[17]) == null ? void 0 : p.enterkeyhint), F(e, "lang", r = /*html_attributes*/
      (v = i[17]) == null ? void 0 : v.lang);
    },
    m(s, d) {
      re(s, e, d), Ke(
        e,
        /*value*/
        i[0]
      ), i[51](e), /*autofocus*/
      i[14] && e.focus(), u || (c = [
        Z(
          e,
          "input",
          /*input_input_handler_1*/
          i[50]
        ),
        Z(
          e,
          "keypress",
          /*handle_keypress*/
          i[28]
        ),
        Z(
          e,
          "blur",
          /*blur_handler_1*/
          i[38]
        ),
        Z(
          e,
          "select",
          /*handle_select*/
          i[27]
        ),
        Z(
          e,
          "focus",
          /*focus_handler_1*/
          i[39]
        )
      ], u = !0);
    },
    p(s, d) {
      var f, h, p, v, k, C;
      d[0] & /*placeholder*/
      4 && F(
        e,
        "placeholder",
        /*placeholder*/
        s[2]
      ), d[0] & /*disabled*/
      64 && (e.disabled = /*disabled*/
      s[6]), d[0] & /*autofocus*/
      16384 && (e.autofocus = /*autofocus*/
      s[14]), d[0] & /*max_length*/
      65536 && F(
        e,
        "maxlength",
        /*max_length*/
        s[16]
      ), d[0] & /*html_attributes*/
      131072 && t !== (t = /*html_attributes*/
      (f = s[17]) == null ? void 0 : f.autocapitalize) && F(e, "autocapitalize", t), d[0] & /*html_attributes*/
      131072 && n !== (n = /*html_attributes*/
      (h = s[17]) == null ? void 0 : h.autocorrect) && F(e, "autocorrect", n), d[0] & /*html_attributes*/
      131072 && l !== (l = /*html_attributes*/
      (p = s[17]) == null ? void 0 : p.spellcheck) && F(e, "spellcheck", l), d[0] & /*html_attributes*/
      131072 && a !== (a = /*html_attributes*/
      (v = s[17]) == null ? void 0 : v.tabindex) && F(e, "tabindex", a), d[0] & /*html_attributes*/
      131072 && o !== (o = /*html_attributes*/
      (k = s[17]) == null ? void 0 : k.enterkeyhint) && F(e, "enterkeyhint", o), d[0] & /*html_attributes*/
      131072 && r !== (r = /*html_attributes*/
      (C = s[17]) == null ? void 0 : C.lang) && F(e, "lang", r), d[0] & /*value*/
      1 && e.value !== /*value*/
      s[0] && Ke(
        e,
        /*value*/
        s[0]
      );
    },
    d(s) {
      s && O(e), i[51](null), u = !1, Zt(c);
    }
  };
}
function ac(i) {
  let e, t, n, l, a, o, r, u, c, s, d, f;
  return {
    c() {
      e = _e("input"), this.h();
    },
    l(h) {
      e = ce(h, "INPUT", {
        "data-testid": !0,
        type: !0,
        class: !0,
        dir: !0,
        placeholder: !0,
        maxlength: !0,
        style: !0,
        autocapitalize: !0,
        autocorrect: !0,
        spellcheck: !0,
        autocomplete: !0,
        tabindex: !0,
        enterkeyhint: !0,
        lang: !0
      }), this.h();
    },
    h() {
      var h, p, v, k, C, m, _;
      F(e, "data-testid", "textbox"), F(e, "type", "text"), F(e, "class", "scroll-hide svelte-myok72"), F(e, "dir", t = /*rtl*/
      i[13] ? "rtl" : "ltr"), F(
        e,
        "placeholder",
        /*placeholder*/
        i[2]
      ), e.disabled = /*disabled*/
      i[6], e.autofocus = /*autofocus*/
      i[14], F(
        e,
        "maxlength",
        /*max_length*/
        i[16]
      ), F(e, "style", n = /*text_align*/
      i[15] ? "text-align: " + /*text_align*/
      i[15] : ""), F(e, "autocapitalize", l = /*html_attributes*/
      (h = i[17]) == null ? void 0 : h.autocapitalize), F(e, "autocorrect", a = /*html_attributes*/
      (p = i[17]) == null ? void 0 : p.autocorrect), F(e, "spellcheck", o = /*html_attributes*/
      (v = i[17]) == null ? void 0 : v.spellcheck), F(e, "autocomplete", r = /*html_attributes*/
      (k = i[17]) == null ? void 0 : k.autocomplete), F(e, "tabindex", u = /*html_attributes*/
      (C = i[17]) == null ? void 0 : C.tabindex), F(e, "enterkeyhint", c = /*html_attributes*/
      (m = i[17]) == null ? void 0 : m.enterkeyhint), F(e, "lang", s = /*html_attributes*/
      (_ = i[17]) == null ? void 0 : _.lang);
    },
    m(h, p) {
      re(h, e, p), Ke(
        e,
        /*value*/
        i[0]
      ), i[49](e), /*autofocus*/
      i[14] && e.focus(), d || (f = [
        Z(
          e,
          "input",
          /*input_input_handler*/
          i[48]
        ),
        Z(
          e,
          "keypress",
          /*handle_keypress*/
          i[28]
        ),
        Z(
          e,
          "blur",
          /*blur_handler*/
          i[36]
        ),
        Z(
          e,
          "select",
          /*handle_select*/
          i[27]
        ),
        Z(
          e,
          "focus",
          /*focus_handler*/
          i[37]
        )
      ], d = !0);
    },
    p(h, p) {
      var v, k, C, m, _, g, D;
      p[0] & /*rtl*/
      8192 && t !== (t = /*rtl*/
      h[13] ? "rtl" : "ltr") && F(e, "dir", t), p[0] & /*placeholder*/
      4 && F(
        e,
        "placeholder",
        /*placeholder*/
        h[2]
      ), p[0] & /*disabled*/
      64 && (e.disabled = /*disabled*/
      h[6]), p[0] & /*autofocus*/
      16384 && (e.autofocus = /*autofocus*/
      h[14]), p[0] & /*max_length*/
      65536 && F(
        e,
        "maxlength",
        /*max_length*/
        h[16]
      ), p[0] & /*text_align*/
      32768 && n !== (n = /*text_align*/
      h[15] ? "text-align: " + /*text_align*/
      h[15] : "") && F(e, "style", n), p[0] & /*html_attributes*/
      131072 && l !== (l = /*html_attributes*/
      (v = h[17]) == null ? void 0 : v.autocapitalize) && F(e, "autocapitalize", l), p[0] & /*html_attributes*/
      131072 && a !== (a = /*html_attributes*/
      (k = h[17]) == null ? void 0 : k.autocorrect) && F(e, "autocorrect", a), p[0] & /*html_attributes*/
      131072 && o !== (o = /*html_attributes*/
      (C = h[17]) == null ? void 0 : C.spellcheck) && F(e, "spellcheck", o), p[0] & /*html_attributes*/
      131072 && r !== (r = /*html_attributes*/
      (m = h[17]) == null ? void 0 : m.autocomplete) && F(e, "autocomplete", r), p[0] & /*html_attributes*/
      131072 && u !== (u = /*html_attributes*/
      (_ = h[17]) == null ? void 0 : _.tabindex) && F(e, "tabindex", u), p[0] & /*html_attributes*/
      131072 && c !== (c = /*html_attributes*/
      (g = h[17]) == null ? void 0 : g.enterkeyhint) && F(e, "enterkeyhint", c), p[0] & /*html_attributes*/
      131072 && s !== (s = /*html_attributes*/
      (D = h[17]) == null ? void 0 : D.lang) && F(e, "lang", s), p[0] & /*value*/
      1 && e.value !== /*value*/
      h[0] && Ke(
        e,
        /*value*/
        h[0]
      );
    },
    d(h) {
      h && O(e), i[49](null), d = !1, Zt(f);
    }
  };
}
function rl(i) {
  let e, t, n, l, a, o;
  const r = [rc, oc], u = [];
  function c(s, d) {
    return (
      /*submit_btn*/
      s[11] === !0 ? 0 : 1
    );
  }
  return t = c(i), n = u[t] = r[t](i), {
    c() {
      e = _e("button"), n.c(), this.h();
    },
    l(s) {
      e = ce(s, "BUTTON", { class: !0 });
      var d = we(e);
      n.l(d), d.forEach(O), this.h();
    },
    h() {
      F(e, "class", "submit-button svelte-myok72"), je(
        e,
        "padded-button",
        /*submit_btn*/
        i[11] !== !0
      );
    },
    m(s, d) {
      re(s, e, d), u[t].m(e, null), l = !0, a || (o = Z(
        e,
        "click",
        /*handle_submit*/
        i[31]
      ), a = !0);
    },
    p(s, d) {
      let f = t;
      t = c(s), t === f ? u[t].p(s, d) : (vt(), oe(u[f], 1, 1, () => {
        u[f] = null;
      }), bt(), n = u[t], n ? n.p(s, d) : (n = u[t] = r[t](s), n.c()), J(n, 1), n.m(e, null)), (!l || d[0] & /*submit_btn*/
      2048) && je(
        e,
        "padded-button",
        /*submit_btn*/
        s[11] !== !0
      );
    },
    i(s) {
      l || (J(n), l = !0);
    },
    o(s) {
      oe(n), l = !1;
    },
    d(s) {
      s && O(e), u[t].d(), a = !1, o();
    }
  };
}
function oc(i) {
  let e;
  return {
    c() {
      e = Ut(
        /*submit_btn*/
        i[11]
      );
    },
    l(t) {
      e = Ot(
        t,
        /*submit_btn*/
        i[11]
      );
    },
    m(t, n) {
      re(t, e, n);
    },
    p(t, n) {
      n[0] & /*submit_btn*/
      2048 && jt(
        e,
        /*submit_btn*/
        t[11]
      );
    },
    i: Ye,
    o: Ye,
    d(t) {
      t && O(e);
    }
  };
}
function rc(i) {
  let e, t;
  return e = new Au({}), {
    c() {
      Nt(e.$$.fragment);
    },
    l(n) {
      Rt(e.$$.fragment, n);
    },
    m(n, l) {
      Ht(e, n, l), t = !0;
    },
    p: Ye,
    i(n) {
      t || (J(e.$$.fragment, n), t = !0);
    },
    o(n) {
      oe(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Pt(e, n);
    }
  };
}
function sl(i) {
  let e, t, n, l, a, o;
  const r = [uc, sc], u = [];
  function c(s, d) {
    return (
      /*stop_btn*/
      s[12] === !0 ? 0 : 1
    );
  }
  return t = c(i), n = u[t] = r[t](i), {
    c() {
      e = _e("button"), n.c(), this.h();
    },
    l(s) {
      e = ce(s, "BUTTON", { class: !0 });
      var d = we(e);
      n.l(d), d.forEach(O), this.h();
    },
    h() {
      F(e, "class", "stop-button svelte-myok72"), je(
        e,
        "padded-button",
        /*stop_btn*/
        i[12] !== !0
      );
    },
    m(s, d) {
      re(s, e, d), u[t].m(e, null), l = !0, a || (o = Z(
        e,
        "click",
        /*handle_stop*/
        i[30]
      ), a = !0);
    },
    p(s, d) {
      let f = t;
      t = c(s), t === f ? u[t].p(s, d) : (vt(), oe(u[f], 1, 1, () => {
        u[f] = null;
      }), bt(), n = u[t], n ? n.p(s, d) : (n = u[t] = r[t](s), n.c()), J(n, 1), n.m(e, null)), (!l || d[0] & /*stop_btn*/
      4096) && je(
        e,
        "padded-button",
        /*stop_btn*/
        s[12] !== !0
      );
    },
    i(s) {
      l || (J(n), l = !0);
    },
    o(s) {
      oe(n), l = !1;
    },
    d(s) {
      s && O(e), u[t].d(), a = !1, o();
    }
  };
}
function sc(i) {
  let e;
  return {
    c() {
      e = Ut(
        /*stop_btn*/
        i[12]
      );
    },
    l(t) {
      e = Ot(
        t,
        /*stop_btn*/
        i[12]
      );
    },
    m(t, n) {
      re(t, e, n);
    },
    p(t, n) {
      n[0] & /*stop_btn*/
      4096 && jt(
        e,
        /*stop_btn*/
        t[12]
      );
    },
    i: Ye,
    o: Ye,
    d(t) {
      t && O(e);
    }
  };
}
function uc(i) {
  let e, t;
  return e = new Iu({
    props: { fill: "none", stroke_width: 2.5 }
  }), {
    c() {
      Nt(e.$$.fragment);
    },
    l(n) {
      Rt(e.$$.fragment, n);
    },
    m(n, l) {
      Ht(e, n, l), t = !0;
    },
    p: Ye,
    i(n) {
      t || (J(e.$$.fragment, n), t = !0);
    },
    o(n) {
      oe(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Pt(e, n);
    }
  };
}
function cc(i) {
  let e, t, n, l, a, o, r, u, c, s, d, f, h = (
    /*show_label*/
    i[7] && /*show_copy_button*/
    i[10] && il(i)
  );
  a = new Os({
    props: {
      show_label: (
        /*show_label*/
        i[7]
      ),
      info: void 0,
      $$slots: { default: [ec] },
      $$scope: { ctx: i }
    }
  });
  let p = (
    /*help*/
    i[5] && /*show_label*/
    i[7] && ll(i)
  ), v = (
    /*info*/
    i[4] && /*show_label*/
    i[7] && ol(i)
  );
  function k(D, b) {
    return (
      /*lines*/
      D[1] === 1 && /*_max_lines*/
      D[19] === 1 ? nc : tc
    );
  }
  let C = k(i), m = C(i), _ = (
    /*submit_btn*/
    i[11] && rl(i)
  ), g = (
    /*stop_btn*/
    i[12] && sl(i)
  );
  return {
    c() {
      e = _e("label"), h && h.c(), t = tt(), n = _e("div"), l = _e("div"), Nt(a.$$.fragment), o = tt(), p && p.c(), r = tt(), v && v.c(), u = tt(), c = _e("div"), m.c(), s = tt(), _ && _.c(), d = tt(), g && g.c(), this.h();
    },
    l(D) {
      e = ce(D, "LABEL", { class: !0 });
      var b = we(e);
      h && h.l(b), t = et(b), n = ce(b, "DIV", { class: !0 });
      var w = we(n);
      l = ce(w, "DIV", { class: !0 });
      var E = we(l);
      Rt(a.$$.fragment, E), o = et(E), p && p.l(E), E.forEach(O), r = et(w), v && v.l(w), w.forEach(O), u = et(b), c = ce(b, "DIV", { class: !0 });
      var y = we(c);
      m.l(y), s = et(y), _ && _.l(y), d = et(y), g && g.l(y), y.forEach(O), b.forEach(O), this.h();
    },
    h() {
      F(l, "class", "title-line svelte-myok72"), F(n, "class", "label-container svelte-myok72"), F(c, "class", "input-container svelte-myok72"), F(e, "class", "svelte-myok72"), je(
        e,
        "container",
        /*container*/
        i[8]
      ), je(
        e,
        "show_textbox_border",
        /*show_textbox_border*/
        i[24]
      );
    },
    m(D, b) {
      re(D, e, b), h && h.m(e, null), pe(e, t), pe(e, n), pe(n, l), Ht(a, l, null), pe(l, o), p && p.m(l, null), pe(n, r), v && v.m(n, null), pe(e, u), pe(e, c), m.m(c, null), pe(c, s), _ && _.m(c, null), pe(c, d), g && g.m(c, null), f = !0;
    },
    p(D, b) {
      /*show_label*/
      D[7] && /*show_copy_button*/
      D[10] ? h ? (h.p(D, b), b[0] & /*show_label, show_copy_button*/
      1152 && J(h, 1)) : (h = il(D), h.c(), J(h, 1), h.m(e, t)) : h && (vt(), oe(h, 1, 1, () => {
        h = null;
      }), bt());
      const w = {};
      b[0] & /*show_label*/
      128 && (w.show_label = /*show_label*/
      D[7]), b[0] & /*label*/
      8 | b[2] & /*$$scope*/
      32 && (w.$$scope = { dirty: b, ctx: D }), a.$set(w), /*help*/
      D[5] && /*show_label*/
      D[7] ? p ? p.p(D, b) : (p = ll(D), p.c(), p.m(l, null)) : p && (p.d(1), p = null), /*info*/
      D[4] && /*show_label*/
      D[7] ? v ? v.p(D, b) : (v = ol(D), v.c(), v.m(n, null)) : v && (v.d(1), v = null), C === (C = k(D)) && m ? m.p(D, b) : (m.d(1), m = C(D), m && (m.c(), m.m(c, s))), /*submit_btn*/
      D[11] ? _ ? (_.p(D, b), b[0] & /*submit_btn*/
      2048 && J(_, 1)) : (_ = rl(D), _.c(), J(_, 1), _.m(c, d)) : _ && (vt(), oe(_, 1, 1, () => {
        _ = null;
      }), bt()), /*stop_btn*/
      D[12] ? g ? (g.p(D, b), b[0] & /*stop_btn*/
      4096 && J(g, 1)) : (g = sl(D), g.c(), J(g, 1), g.m(c, null)) : g && (vt(), oe(g, 1, 1, () => {
        g = null;
      }), bt()), (!f || b[0] & /*container*/
      256) && je(
        e,
        "container",
        /*container*/
        D[8]
      );
    },
    i(D) {
      f || (J(h), J(a.$$.fragment, D), J(_), J(g), f = !0);
    },
    o(D) {
      oe(h), oe(a.$$.fragment, D), oe(_), oe(g), f = !1;
    },
    d(D) {
      D && O(e), h && h.d(), Pt(a), p && p.d(), v && v.d(), m.d(), _ && _.d(), g && g.d();
    }
  };
}
function _c(i) {
  return document.body.appendChild(i), {
    destroy() {
      i.parentNode && i.parentNode.removeChild(i);
    }
  };
}
function dc(i) {
  const e = i.scrollHeight, t = i.clientHeight, n = parseFloat(window.getComputedStyle(i).lineHeight);
  e > t + n ? i.style.overflowY = "scroll" : i.style.overflowY = "hidden";
}
function fc(i, e, t) {
  var n = this && this.__awaiter || function($, te, de, ge) {
    function kt(Ue) {
      return Ue instanceof de ? Ue : new de(function(Ge) {
        Ge(Ue);
      });
    }
    return new (de || (de = Promise))(function(Ue, Ge) {
      function Vt(Qe) {
        try {
          wn(ge.next(Qe));
        } catch (yn) {
          Ge(yn);
        }
      }
      function ut(Qe) {
        try {
          wn(ge.throw(Qe));
        } catch (yn) {
          Ge(yn);
        }
      }
      function wn(Qe) {
        Qe.done ? Ue(Qe.value) : kt(Qe.value).then(Vt, ut);
      }
      wn((ge = ge.apply($, te || [])).next());
    });
  };
  let { value: l = "" } = e, { value_is_output: a = !1 } = e, { lines: o = 1 } = e, { placeholder: r = "Type here..." } = e, { label: u } = e, { info: c = void 0 } = e, { help: s = void 0 } = e, { disabled: d = !1 } = e, { show_label: f = !0 } = e, { container: h = !0 } = e, { max_lines: p = void 0 } = e, { type: v = "text" } = e, { show_copy_button: k = !1 } = e, { submit_btn: C = null } = e, { stop_btn: m = null } = e, { rtl: _ = !1 } = e, { autofocus: g = !1 } = e, { text_align: D = void 0 } = e, { autoscroll: b = !0 } = e, { max_length: w = void 0 } = e, { html_attributes: E = null } = e, y, B = !1, q, z, le = 0, G = !1, N, M = !1, V, P;
  const ee = !C, K = Ku();
  Wu(() => {
    !G && y && y.offsetHeight + y.scrollTop > y.scrollHeight - 100 && (z = !0);
  });
  const A = () => {
    z && b && !G && y.scrollTo(0, y.scrollHeight);
  };
  function Q() {
    if (!V || !P) return;
    const $ = P.getBoundingClientRect();
    t(22, V.style.position = "fixed", V), t(22, V.style.left = `${$.right + 8}px`, V), t(22, V.style.top = `${$.top}px`, V);
  }
  function qe() {
    t(21, M = !0), Pn().then(Q);
  }
  function ae() {
    K("change", l), a || K("input");
  }
  Yu(() => {
    g && y.focus(), z && b && A(), t(33, a = !1);
  });
  function x() {
    return n(this, void 0, void 0, function* () {
      "clipboard" in navigator && (yield navigator.clipboard.writeText(l), K("copy", { value: l }), S());
    });
  }
  function S() {
    t(20, B = !0), q && clearTimeout(q), q = setTimeout(
      () => {
        t(20, B = !1);
      },
      1e3
    );
  }
  function ot($) {
    const te = $.target, de = te.value, ge = [te.selectionStart, te.selectionEnd];
    K("select", { value: de.substring(...ge), index: ge });
  }
  function Dt($) {
    return n(this, void 0, void 0, function* () {
      yield Pn(), ($.key === "Enter" && $.shiftKey && o > 1 || $.key === "Enter" && !$.shiftKey && o === 1 && N >= 1) && ($.preventDefault(), K("submit"));
    });
  }
  function Gt($) {
    const te = $.target, de = te.scrollTop;
    de < le && (G = !0), le = de;
    const ge = te.scrollHeight - te.clientHeight;
    de >= ge && (G = !1);
  }
  function wt() {
    K("stop");
  }
  function rt() {
    K("submit");
  }
  function st($) {
    return n(this, void 0, void 0, function* () {
      if (yield Pn(), o === N) return;
      const te = $.target, de = window.getComputedStyle(te), ge = parseFloat(de.paddingTop), kt = parseFloat(de.paddingBottom), Ue = parseFloat(de.lineHeight);
      let Ge = N === void 0 ? !1 : ge + kt + Ue * N, Vt = ge + kt + o * Ue;
      te.style.height = "1px";
      let ut;
      Ge && te.scrollHeight > Ge ? ut = Ge : te.scrollHeight < Vt ? ut = Vt : ut = te.scrollHeight, te.style.height = `${ut}px`, dc(te);
    });
  }
  function yt($, te) {
    if (o !== N && ($.style.overflowY = "scroll", $.addEventListener("input", st), !!te.trim()))
      return st({ target: $ }), {
        destroy: () => $.removeEventListener("input", st)
      };
  }
  function Aa($) {
    Ve.call(this, i, $);
  }
  function Sa($) {
    Ve.call(this, i, $);
  }
  function Ba($) {
    Ve.call(this, i, $);
  }
  function xa($) {
    Ve.call(this, i, $);
  }
  function Ta($) {
    Ve.call(this, i, $);
  }
  function qa($) {
    Ve.call(this, i, $);
  }
  function La($) {
    Ve.call(this, i, $);
  }
  function za($) {
    Ve.call(this, i, $);
  }
  function Ia($) {
    ft[$ ? "unshift" : "push"](() => {
      P = $, t(23, P);
    });
  }
  function Ma($) {
    ft[$ ? "unshift" : "push"](() => {
      V = $, t(22, V);
    });
  }
  const Ra = () => t(21, M = !1), Oa = () => t(21, M = !1);
  function Na() {
    l = this.value, t(0, l);
  }
  function Pa($) {
    ft[$ ? "unshift" : "push"](() => {
      y = $, t(18, y);
    });
  }
  function Ha() {
    l = this.value, t(0, l);
  }
  function Za($) {
    ft[$ ? "unshift" : "push"](() => {
      y = $, t(18, y);
    });
  }
  function ja() {
    l = this.value, t(0, l);
  }
  function Ua($) {
    ft[$ ? "unshift" : "push"](() => {
      y = $, t(18, y);
    });
  }
  function Ga() {
    l = this.value, t(0, l);
  }
  function Va($) {
    ft[$ ? "unshift" : "push"](() => {
      y = $, t(18, y);
    });
  }
  return i.$$set = ($) => {
    "value" in $ && t(0, l = $.value), "value_is_output" in $ && t(33, a = $.value_is_output), "lines" in $ && t(1, o = $.lines), "placeholder" in $ && t(2, r = $.placeholder), "label" in $ && t(3, u = $.label), "info" in $ && t(4, c = $.info), "help" in $ && t(5, s = $.help), "disabled" in $ && t(6, d = $.disabled), "show_label" in $ && t(7, f = $.show_label), "container" in $ && t(8, h = $.container), "max_lines" in $ && t(34, p = $.max_lines), "type" in $ && t(9, v = $.type), "show_copy_button" in $ && t(10, k = $.show_copy_button), "submit_btn" in $ && t(11, C = $.submit_btn), "stop_btn" in $ && t(12, m = $.stop_btn), "rtl" in $ && t(13, _ = $.rtl), "autofocus" in $ && t(14, g = $.autofocus), "text_align" in $ && t(15, D = $.text_align), "autoscroll" in $ && t(35, b = $.autoscroll), "max_length" in $ && t(16, w = $.max_length), "html_attributes" in $ && t(17, E = $.html_attributes);
  }, i.$$.update = () => {
    i.$$.dirty[0] & /*type, lines*/
    514 | i.$$.dirty[1] & /*max_lines*/
    8 && (p == null ? v === "text" ? t(19, N = Math.max(o, 20)) : t(19, N = 1) : t(19, N = Math.max(p, o))), i.$$.dirty[0] & /*value*/
    1 && l === null && t(0, l = ""), i.$$.dirty[0] & /*value, el, lines, _max_lines*/
    786435 && y && o !== N && st({ target: y }), i.$$.dirty[0] & /*value*/
    1 && ae();
  }, [
    l,
    o,
    r,
    u,
    c,
    s,
    d,
    f,
    h,
    v,
    k,
    C,
    m,
    _,
    g,
    D,
    w,
    E,
    y,
    N,
    B,
    M,
    V,
    P,
    ee,
    qe,
    x,
    ot,
    Dt,
    Gt,
    wt,
    rt,
    yt,
    a,
    p,
    b,
    Aa,
    Sa,
    Ba,
    xa,
    Ta,
    qa,
    La,
    za,
    Ia,
    Ma,
    Ra,
    Oa,
    Na,
    Pa,
    Ha,
    Za,
    ja,
    Ua,
    Ga,
    Va
  ];
}
class hc extends Hu {
  constructor(e) {
    super(), Gu(
      this,
      e,
      fc,
      cc,
      Xu,
      {
        value: 0,
        value_is_output: 33,
        lines: 1,
        placeholder: 2,
        label: 3,
        info: 4,
        help: 5,
        disabled: 6,
        show_label: 7,
        container: 8,
        max_lines: 34,
        type: 9,
        show_copy_button: 10,
        submit_btn: 11,
        stop_btn: 12,
        rtl: 13,
        autofocus: 14,
        text_align: 15,
        autoscroll: 35,
        max_length: 16,
        html_attributes: 17
      },
      null,
      [-1, -1, -1]
    );
  }
}
function pt(i) {
  let e = ["", "k", "M", "G", "T", "P", "E", "Z"], t = 0;
  for (; i > 1e3 && t < e.length - 1; )
    i /= 1e3, t++;
  let n = e[t];
  return (Number.isInteger(i) ? i : i.toFixed(1)) + n;
}
const {
  SvelteComponent: pc,
  append_hydration: Ee,
  attr: I,
  children: ve,
  claim_element: mc,
  claim_svg_element: Ae,
  component_subscribe: ul,
  detach: he,
  element: gc,
  init: bc,
  insert_hydration: vc,
  noop: cl,
  safe_not_equal: Dc,
  set_style: sn,
  svg_element: Se,
  toggle_class: _l
} = window.__gradio__svelte__internal, { onMount: wc } = window.__gradio__svelte__internal;
function yc(i) {
  let e, t, n, l, a, o, r, u, c, s, d, f;
  return {
    c() {
      e = gc("div"), t = Se("svg"), n = Se("g"), l = Se("path"), a = Se("path"), o = Se("path"), r = Se("path"), u = Se("g"), c = Se("path"), s = Se("path"), d = Se("path"), f = Se("path"), this.h();
    },
    l(h) {
      e = mc(h, "DIV", { class: !0 });
      var p = ve(e);
      t = Ae(p, "svg", {
        viewBox: !0,
        fill: !0,
        xmlns: !0,
        class: !0
      });
      var v = ve(t);
      n = Ae(v, "g", { style: !0 });
      var k = ve(n);
      l = Ae(k, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), ve(l).forEach(he), a = Ae(k, "path", { d: !0, fill: !0, class: !0 }), ve(a).forEach(he), o = Ae(k, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), ve(o).forEach(he), r = Ae(k, "path", { d: !0, fill: !0, class: !0 }), ve(r).forEach(he), k.forEach(he), u = Ae(v, "g", { style: !0 });
      var C = ve(u);
      c = Ae(C, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), ve(c).forEach(he), s = Ae(C, "path", { d: !0, fill: !0, class: !0 }), ve(s).forEach(he), d = Ae(C, "path", {
        d: !0,
        fill: !0,
        "fill-opacity": !0,
        class: !0
      }), ve(d).forEach(he), f = Ae(C, "path", { d: !0, fill: !0, class: !0 }), ve(f).forEach(he), C.forEach(he), v.forEach(he), p.forEach(he), this.h();
    },
    h() {
      I(l, "d", "M255.926 0.754768L509.702 139.936V221.027L255.926 81.8465V0.754768Z"), I(l, "fill", "#FF7C00"), I(l, "fill-opacity", "0.4"), I(l, "class", "svelte-43sxxs"), I(a, "d", "M509.69 139.936L254.981 279.641V361.255L509.69 221.55V139.936Z"), I(a, "fill", "#FF7C00"), I(a, "class", "svelte-43sxxs"), I(o, "d", "M0.250138 139.937L254.981 279.641V361.255L0.250138 221.55V139.937Z"), I(o, "fill", "#FF7C00"), I(o, "fill-opacity", "0.4"), I(o, "class", "svelte-43sxxs"), I(r, "d", "M255.923 0.232622L0.236328 139.936V221.55L255.923 81.8469V0.232622Z"), I(r, "fill", "#FF7C00"), I(r, "class", "svelte-43sxxs"), sn(n, "transform", "translate(" + /*$top*/
      i[1][0] + "px, " + /*$top*/
      i[1][1] + "px)"), I(c, "d", "M255.926 141.5L509.702 280.681V361.773L255.926 222.592V141.5Z"), I(c, "fill", "#FF7C00"), I(c, "fill-opacity", "0.4"), I(c, "class", "svelte-43sxxs"), I(s, "d", "M509.69 280.679L254.981 420.384V501.998L509.69 362.293V280.679Z"), I(s, "fill", "#FF7C00"), I(s, "class", "svelte-43sxxs"), I(d, "d", "M0.250138 280.681L254.981 420.386V502L0.250138 362.295V280.681Z"), I(d, "fill", "#FF7C00"), I(d, "fill-opacity", "0.4"), I(d, "class", "svelte-43sxxs"), I(f, "d", "M255.923 140.977L0.236328 280.68V362.294L255.923 222.591V140.977Z"), I(f, "fill", "#FF7C00"), I(f, "class", "svelte-43sxxs"), sn(u, "transform", "translate(" + /*$bottom*/
      i[2][0] + "px, " + /*$bottom*/
      i[2][1] + "px)"), I(t, "viewBox", "-1200 -1200 3000 3000"), I(t, "fill", "none"), I(t, "xmlns", "http://www.w3.org/2000/svg"), I(t, "class", "svelte-43sxxs"), I(e, "class", "svelte-43sxxs"), _l(
        e,
        "margin",
        /*margin*/
        i[0]
      );
    },
    m(h, p) {
      vc(h, e, p), Ee(e, t), Ee(t, n), Ee(n, l), Ee(n, a), Ee(n, o), Ee(n, r), Ee(t, u), Ee(u, c), Ee(u, s), Ee(u, d), Ee(u, f);
    },
    p(h, [p]) {
      p & /*$top*/
      2 && sn(n, "transform", "translate(" + /*$top*/
      h[1][0] + "px, " + /*$top*/
      h[1][1] + "px)"), p & /*$bottom*/
      4 && sn(u, "transform", "translate(" + /*$bottom*/
      h[2][0] + "px, " + /*$bottom*/
      h[2][1] + "px)"), p & /*margin*/
      1 && _l(
        e,
        "margin",
        /*margin*/
        h[0]
      );
    },
    i: cl,
    o: cl,
    d(h) {
      h && he(e);
    }
  };
}
function kc(i, e, t) {
  let n, l;
  var a = this && this.__awaiter || function(h, p, v, k) {
    function C(m) {
      return m instanceof v ? m : new v(function(_) {
        _(m);
      });
    }
    return new (v || (v = Promise))(function(m, _) {
      function g(w) {
        try {
          b(k.next(w));
        } catch (E) {
          _(E);
        }
      }
      function D(w) {
        try {
          b(k.throw(w));
        } catch (E) {
          _(E);
        }
      }
      function b(w) {
        w.done ? m(w.value) : C(w.value).then(g, D);
      }
      b((k = k.apply(h, p || [])).next());
    });
  };
  let { margin: o = !0 } = e;
  const r = nl([0, 0]);
  ul(i, r, (h) => t(1, n = h));
  const u = nl([0, 0]);
  ul(i, u, (h) => t(2, l = h));
  let c;
  function s() {
    return a(this, void 0, void 0, function* () {
      yield Promise.all([r.set([125, 140]), u.set([-125, -140])]), yield Promise.all([r.set([-125, 140]), u.set([125, -140])]), yield Promise.all([r.set([-125, 0]), u.set([125, -0])]), yield Promise.all([r.set([125, 0]), u.set([-125, 0])]);
    });
  }
  function d() {
    return a(this, void 0, void 0, function* () {
      yield s(), c || d();
    });
  }
  function f() {
    return a(this, void 0, void 0, function* () {
      yield Promise.all([r.set([125, 0]), u.set([-125, 0])]), d();
    });
  }
  return wc(() => (f(), () => c = !0)), i.$$set = (h) => {
    "margin" in h && t(0, o = h.margin);
  }, [o, n, l, r, u];
}
class Fc extends pc {
  constructor(e) {
    super(), bc(this, e, kc, yc, Dc, { margin: 0 });
  }
}
const {
  SvelteComponent: $c,
  append_hydration: nt,
  attr: xe,
  binding_callbacks: dl,
  check_outros: Kn,
  children: Oe,
  claim_component: ba,
  claim_element: Ne,
  claim_space: ye,
  claim_text: W,
  create_component: va,
  create_slot: Da,
  destroy_component: wa,
  destroy_each: ya,
  detach: T,
  element: Pe,
  empty: Fe,
  ensure_array_like: vn,
  get_all_dirty_from_scope: ka,
  get_slot_changes: Fa,
  group_outros: Qn,
  init: Cc,
  insert_hydration: L,
  mount_component: $a,
  noop: Jn,
  safe_not_equal: Ec,
  set_data: $e,
  set_style: We,
  space: ke,
  text: Y,
  toggle_class: De,
  transition_in: Be,
  transition_out: He,
  update_slot_base: Ca
} = window.__gradio__svelte__internal, { tick: Ac } = window.__gradio__svelte__internal, { onDestroy: Sc } = window.__gradio__svelte__internal, { createEventDispatcher: Bc } = window.__gradio__svelte__internal, xc = (i) => ({}), fl = (i) => ({}), Tc = (i) => ({}), hl = (i) => ({});
function pl(i, e, t) {
  const n = i.slice();
  return n[40] = e[t], n[42] = t, n;
}
function ml(i, e, t) {
  const n = i.slice();
  return n[40] = e[t], n;
}
function qc(i) {
  let e, t, n, l, a = (
    /*i18n*/
    i[1]("common.error") + ""
  ), o, r, u;
  t = new iu({
    props: {
      Icon: mu,
      label: (
        /*i18n*/
        i[1]("common.clear")
      ),
      disabled: !1
    }
  }), t.$on(
    "click",
    /*click_handler*/
    i[32]
  );
  const c = (
    /*#slots*/
    i[30].error
  ), s = Da(
    c,
    i,
    /*$$scope*/
    i[29],
    fl
  );
  return {
    c() {
      e = Pe("div"), va(t.$$.fragment), n = ke(), l = Pe("span"), o = Y(a), r = ke(), s && s.c(), this.h();
    },
    l(d) {
      e = Ne(d, "DIV", { class: !0 });
      var f = Oe(e);
      ba(t.$$.fragment, f), f.forEach(T), n = ye(d), l = Ne(d, "SPAN", { class: !0 });
      var h = Oe(l);
      o = W(h, a), h.forEach(T), r = ye(d), s && s.l(d), this.h();
    },
    h() {
      xe(e, "class", "clear-status svelte-17v219f"), xe(l, "class", "error svelte-17v219f");
    },
    m(d, f) {
      L(d, e, f), $a(t, e, null), L(d, n, f), L(d, l, f), nt(l, o), L(d, r, f), s && s.m(d, f), u = !0;
    },
    p(d, f) {
      const h = {};
      f[0] & /*i18n*/
      2 && (h.label = /*i18n*/
      d[1]("common.clear")), t.$set(h), (!u || f[0] & /*i18n*/
      2) && a !== (a = /*i18n*/
      d[1]("common.error") + "") && $e(o, a), s && s.p && (!u || f[0] & /*$$scope*/
      536870912) && Ca(
        s,
        c,
        d,
        /*$$scope*/
        d[29],
        u ? Fa(
          c,
          /*$$scope*/
          d[29],
          f,
          xc
        ) : ka(
          /*$$scope*/
          d[29]
        ),
        fl
      );
    },
    i(d) {
      u || (Be(t.$$.fragment, d), Be(s, d), u = !0);
    },
    o(d) {
      He(t.$$.fragment, d), He(s, d), u = !1;
    },
    d(d) {
      d && (T(e), T(n), T(l), T(r)), wa(t), s && s.d(d);
    }
  };
}
function Lc(i) {
  let e, t, n, l, a, o, r, u, c, s = (
    /*variant*/
    i[8] === "default" && /*show_eta_bar*/
    i[18] && /*show_progress*/
    i[6] === "full" && gl(i)
  );
  function d(_, g) {
    if (
      /*progress*/
      _[7]
    ) return Mc;
    if (
      /*queue_position*/
      _[2] !== null && /*queue_size*/
      _[3] !== void 0 && /*queue_position*/
      _[2] >= 0
    ) return Ic;
    if (
      /*queue_position*/
      _[2] === 0
    ) return zc;
  }
  let f = d(i), h = f && f(i), p = (
    /*timer*/
    i[5] && Dl(i)
  );
  const v = [Pc, Nc], k = [];
  function C(_, g) {
    return (
      /*last_progress_level*/
      _[15] != null ? 0 : (
        /*show_progress*/
        _[6] === "full" ? 1 : -1
      )
    );
  }
  ~(a = C(i)) && (o = k[a] = v[a](i));
  let m = !/*timer*/
  i[5] && El(i);
  return {
    c() {
      s && s.c(), e = ke(), t = Pe("div"), h && h.c(), n = ke(), p && p.c(), l = ke(), o && o.c(), r = ke(), m && m.c(), u = Fe(), this.h();
    },
    l(_) {
      s && s.l(_), e = ye(_), t = Ne(_, "DIV", { class: !0 });
      var g = Oe(t);
      h && h.l(g), n = ye(g), p && p.l(g), g.forEach(T), l = ye(_), o && o.l(_), r = ye(_), m && m.l(_), u = Fe(), this.h();
    },
    h() {
      xe(t, "class", "progress-text svelte-17v219f"), De(
        t,
        "meta-text-center",
        /*variant*/
        i[8] === "center"
      ), De(
        t,
        "meta-text",
        /*variant*/
        i[8] === "default"
      );
    },
    m(_, g) {
      s && s.m(_, g), L(_, e, g), L(_, t, g), h && h.m(t, null), nt(t, n), p && p.m(t, null), L(_, l, g), ~a && k[a].m(_, g), L(_, r, g), m && m.m(_, g), L(_, u, g), c = !0;
    },
    p(_, g) {
      /*variant*/
      _[8] === "default" && /*show_eta_bar*/
      _[18] && /*show_progress*/
      _[6] === "full" ? s ? s.p(_, g) : (s = gl(_), s.c(), s.m(e.parentNode, e)) : s && (s.d(1), s = null), f === (f = d(_)) && h ? h.p(_, g) : (h && h.d(1), h = f && f(_), h && (h.c(), h.m(t, n))), /*timer*/
      _[5] ? p ? p.p(_, g) : (p = Dl(_), p.c(), p.m(t, null)) : p && (p.d(1), p = null), (!c || g[0] & /*variant*/
      256) && De(
        t,
        "meta-text-center",
        /*variant*/
        _[8] === "center"
      ), (!c || g[0] & /*variant*/
      256) && De(
        t,
        "meta-text",
        /*variant*/
        _[8] === "default"
      );
      let D = a;
      a = C(_), a === D ? ~a && k[a].p(_, g) : (o && (Qn(), He(k[D], 1, 1, () => {
        k[D] = null;
      }), Kn()), ~a ? (o = k[a], o ? o.p(_, g) : (o = k[a] = v[a](_), o.c()), Be(o, 1), o.m(r.parentNode, r)) : o = null), /*timer*/
      _[5] ? m && (Qn(), He(m, 1, 1, () => {
        m = null;
      }), Kn()) : m ? (m.p(_, g), g[0] & /*timer*/
      32 && Be(m, 1)) : (m = El(_), m.c(), Be(m, 1), m.m(u.parentNode, u));
    },
    i(_) {
      c || (Be(o), Be(m), c = !0);
    },
    o(_) {
      He(o), He(m), c = !1;
    },
    d(_) {
      _ && (T(e), T(t), T(l), T(r), T(u)), s && s.d(_), h && h.d(), p && p.d(), ~a && k[a].d(_), m && m.d(_);
    }
  };
}
function gl(i) {
  let e, t = `translateX(${/*eta_level*/
  (i[17] || 0) * 100 - 100}%)`;
  return {
    c() {
      e = Pe("div"), this.h();
    },
    l(n) {
      e = Ne(n, "DIV", { class: !0 }), Oe(e).forEach(T), this.h();
    },
    h() {
      xe(e, "class", "eta-bar svelte-17v219f"), We(e, "transform", t);
    },
    m(n, l) {
      L(n, e, l);
    },
    p(n, l) {
      l[0] & /*eta_level*/
      131072 && t !== (t = `translateX(${/*eta_level*/
      (n[17] || 0) * 100 - 100}%)`) && We(e, "transform", t);
    },
    d(n) {
      n && T(e);
    }
  };
}
function zc(i) {
  let e;
  return {
    c() {
      e = Y("processing |");
    },
    l(t) {
      e = W(t, "processing |");
    },
    m(t, n) {
      L(t, e, n);
    },
    p: Jn,
    d(t) {
      t && T(e);
    }
  };
}
function Ic(i) {
  let e, t = (
    /*queue_position*/
    i[2] + 1 + ""
  ), n, l, a, o;
  return {
    c() {
      e = Y("queue: "), n = Y(t), l = Y("/"), a = Y(
        /*queue_size*/
        i[3]
      ), o = Y(" |");
    },
    l(r) {
      e = W(r, "queue: "), n = W(r, t), l = W(r, "/"), a = W(
        r,
        /*queue_size*/
        i[3]
      ), o = W(r, " |");
    },
    m(r, u) {
      L(r, e, u), L(r, n, u), L(r, l, u), L(r, a, u), L(r, o, u);
    },
    p(r, u) {
      u[0] & /*queue_position*/
      4 && t !== (t = /*queue_position*/
      r[2] + 1 + "") && $e(n, t), u[0] & /*queue_size*/
      8 && $e(
        a,
        /*queue_size*/
        r[3]
      );
    },
    d(r) {
      r && (T(e), T(n), T(l), T(a), T(o));
    }
  };
}
function Mc(i) {
  let e, t = vn(
    /*progress*/
    i[7]
  ), n = [];
  for (let l = 0; l < t.length; l += 1)
    n[l] = vl(ml(i, t, l));
  return {
    c() {
      for (let l = 0; l < n.length; l += 1)
        n[l].c();
      e = Fe();
    },
    l(l) {
      for (let a = 0; a < n.length; a += 1)
        n[a].l(l);
      e = Fe();
    },
    m(l, a) {
      for (let o = 0; o < n.length; o += 1)
        n[o] && n[o].m(l, a);
      L(l, e, a);
    },
    p(l, a) {
      if (a[0] & /*progress*/
      128) {
        t = vn(
          /*progress*/
          l[7]
        );
        let o;
        for (o = 0; o < t.length; o += 1) {
          const r = ml(l, t, o);
          n[o] ? n[o].p(r, a) : (n[o] = vl(r), n[o].c(), n[o].m(e.parentNode, e));
        }
        for (; o < n.length; o += 1)
          n[o].d(1);
        n.length = t.length;
      }
    },
    d(l) {
      l && T(e), ya(n, l);
    }
  };
}
function bl(i) {
  let e, t = (
    /*p*/
    i[40].unit + ""
  ), n, l, a = " ", o;
  function r(s, d) {
    return (
      /*p*/
      s[40].length != null ? Oc : Rc
    );
  }
  let u = r(i), c = u(i);
  return {
    c() {
      c.c(), e = ke(), n = Y(t), l = Y(" | "), o = Y(a);
    },
    l(s) {
      c.l(s), e = ye(s), n = W(s, t), l = W(s, " | "), o = W(s, a);
    },
    m(s, d) {
      c.m(s, d), L(s, e, d), L(s, n, d), L(s, l, d), L(s, o, d);
    },
    p(s, d) {
      u === (u = r(s)) && c ? c.p(s, d) : (c.d(1), c = u(s), c && (c.c(), c.m(e.parentNode, e))), d[0] & /*progress*/
      128 && t !== (t = /*p*/
      s[40].unit + "") && $e(n, t);
    },
    d(s) {
      s && (T(e), T(n), T(l), T(o)), c.d(s);
    }
  };
}
function Rc(i) {
  let e = pt(
    /*p*/
    i[40].index || 0
  ) + "", t;
  return {
    c() {
      t = Y(e);
    },
    l(n) {
      t = W(n, e);
    },
    m(n, l) {
      L(n, t, l);
    },
    p(n, l) {
      l[0] & /*progress*/
      128 && e !== (e = pt(
        /*p*/
        n[40].index || 0
      ) + "") && $e(t, e);
    },
    d(n) {
      n && T(t);
    }
  };
}
function Oc(i) {
  let e = pt(
    /*p*/
    i[40].index || 0
  ) + "", t, n, l = pt(
    /*p*/
    i[40].length
  ) + "", a;
  return {
    c() {
      t = Y(e), n = Y("/"), a = Y(l);
    },
    l(o) {
      t = W(o, e), n = W(o, "/"), a = W(o, l);
    },
    m(o, r) {
      L(o, t, r), L(o, n, r), L(o, a, r);
    },
    p(o, r) {
      r[0] & /*progress*/
      128 && e !== (e = pt(
        /*p*/
        o[40].index || 0
      ) + "") && $e(t, e), r[0] & /*progress*/
      128 && l !== (l = pt(
        /*p*/
        o[40].length
      ) + "") && $e(a, l);
    },
    d(o) {
      o && (T(t), T(n), T(a));
    }
  };
}
function vl(i) {
  let e, t = (
    /*p*/
    i[40].index != null && bl(i)
  );
  return {
    c() {
      t && t.c(), e = Fe();
    },
    l(n) {
      t && t.l(n), e = Fe();
    },
    m(n, l) {
      t && t.m(n, l), L(n, e, l);
    },
    p(n, l) {
      /*p*/
      n[40].index != null ? t ? t.p(n, l) : (t = bl(n), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(n) {
      n && T(e), t && t.d(n);
    }
  };
}
function Dl(i) {
  let e, t = (
    /*eta*/
    i[0] ? `/${/*formatted_eta*/
    i[19]}` : ""
  ), n, l;
  return {
    c() {
      e = Y(
        /*formatted_timer*/
        i[20]
      ), n = Y(t), l = Y("s");
    },
    l(a) {
      e = W(
        a,
        /*formatted_timer*/
        i[20]
      ), n = W(a, t), l = W(a, "s");
    },
    m(a, o) {
      L(a, e, o), L(a, n, o), L(a, l, o);
    },
    p(a, o) {
      o[0] & /*formatted_timer*/
      1048576 && $e(
        e,
        /*formatted_timer*/
        a[20]
      ), o[0] & /*eta, formatted_eta*/
      524289 && t !== (t = /*eta*/
      a[0] ? `/${/*formatted_eta*/
      a[19]}` : "") && $e(n, t);
    },
    d(a) {
      a && (T(e), T(n), T(l));
    }
  };
}
function Nc(i) {
  let e, t;
  return e = new Fc({
    props: { margin: (
      /*variant*/
      i[8] === "default"
    ) }
  }), {
    c() {
      va(e.$$.fragment);
    },
    l(n) {
      ba(e.$$.fragment, n);
    },
    m(n, l) {
      $a(e, n, l), t = !0;
    },
    p(n, l) {
      const a = {};
      l[0] & /*variant*/
      256 && (a.margin = /*variant*/
      n[8] === "default"), e.$set(a);
    },
    i(n) {
      t || (Be(e.$$.fragment, n), t = !0);
    },
    o(n) {
      He(e.$$.fragment, n), t = !1;
    },
    d(n) {
      wa(e, n);
    }
  };
}
function Pc(i) {
  let e, t, n, l, a, o = `${/*last_progress_level*/
  i[15] * 100}%`, r = (
    /*progress*/
    i[7] != null && wl(i)
  );
  return {
    c() {
      e = Pe("div"), t = Pe("div"), r && r.c(), n = ke(), l = Pe("div"), a = Pe("div"), this.h();
    },
    l(u) {
      e = Ne(u, "DIV", { class: !0 });
      var c = Oe(e);
      t = Ne(c, "DIV", { class: !0 });
      var s = Oe(t);
      r && r.l(s), s.forEach(T), n = ye(c), l = Ne(c, "DIV", { class: !0 });
      var d = Oe(l);
      a = Ne(d, "DIV", { class: !0 }), Oe(a).forEach(T), d.forEach(T), c.forEach(T), this.h();
    },
    h() {
      xe(t, "class", "progress-level-inner svelte-17v219f"), xe(a, "class", "progress-bar svelte-17v219f"), We(a, "width", o), xe(l, "class", "progress-bar-wrap svelte-17v219f"), xe(e, "class", "progress-level svelte-17v219f");
    },
    m(u, c) {
      L(u, e, c), nt(e, t), r && r.m(t, null), nt(e, n), nt(e, l), nt(l, a), i[31](a);
    },
    p(u, c) {
      /*progress*/
      u[7] != null ? r ? r.p(u, c) : (r = wl(u), r.c(), r.m(t, null)) : r && (r.d(1), r = null), c[0] & /*last_progress_level*/
      32768 && o !== (o = `${/*last_progress_level*/
      u[15] * 100}%`) && We(a, "width", o);
    },
    i: Jn,
    o: Jn,
    d(u) {
      u && T(e), r && r.d(), i[31](null);
    }
  };
}
function wl(i) {
  let e, t = vn(
    /*progress*/
    i[7]
  ), n = [];
  for (let l = 0; l < t.length; l += 1)
    n[l] = Cl(pl(i, t, l));
  return {
    c() {
      for (let l = 0; l < n.length; l += 1)
        n[l].c();
      e = Fe();
    },
    l(l) {
      for (let a = 0; a < n.length; a += 1)
        n[a].l(l);
      e = Fe();
    },
    m(l, a) {
      for (let o = 0; o < n.length; o += 1)
        n[o] && n[o].m(l, a);
      L(l, e, a);
    },
    p(l, a) {
      if (a[0] & /*progress_level, progress*/
      16512) {
        t = vn(
          /*progress*/
          l[7]
        );
        let o;
        for (o = 0; o < t.length; o += 1) {
          const r = pl(l, t, o);
          n[o] ? n[o].p(r, a) : (n[o] = Cl(r), n[o].c(), n[o].m(e.parentNode, e));
        }
        for (; o < n.length; o += 1)
          n[o].d(1);
        n.length = t.length;
      }
    },
    d(l) {
      l && T(e), ya(n, l);
    }
  };
}
function yl(i) {
  let e, t, n, l, a = (
    /*i*/
    i[42] !== 0 && Hc()
  ), o = (
    /*p*/
    i[40].desc != null && kl(i)
  ), r = (
    /*p*/
    i[40].desc != null && /*progress_level*/
    i[14] && /*progress_level*/
    i[14][
      /*i*/
      i[42]
    ] != null && Fl()
  ), u = (
    /*progress_level*/
    i[14] != null && $l(i)
  );
  return {
    c() {
      a && a.c(), e = ke(), o && o.c(), t = ke(), r && r.c(), n = ke(), u && u.c(), l = Fe();
    },
    l(c) {
      a && a.l(c), e = ye(c), o && o.l(c), t = ye(c), r && r.l(c), n = ye(c), u && u.l(c), l = Fe();
    },
    m(c, s) {
      a && a.m(c, s), L(c, e, s), o && o.m(c, s), L(c, t, s), r && r.m(c, s), L(c, n, s), u && u.m(c, s), L(c, l, s);
    },
    p(c, s) {
      /*p*/
      c[40].desc != null ? o ? o.p(c, s) : (o = kl(c), o.c(), o.m(t.parentNode, t)) : o && (o.d(1), o = null), /*p*/
      c[40].desc != null && /*progress_level*/
      c[14] && /*progress_level*/
      c[14][
        /*i*/
        c[42]
      ] != null ? r || (r = Fl(), r.c(), r.m(n.parentNode, n)) : r && (r.d(1), r = null), /*progress_level*/
      c[14] != null ? u ? u.p(c, s) : (u = $l(c), u.c(), u.m(l.parentNode, l)) : u && (u.d(1), u = null);
    },
    d(c) {
      c && (T(e), T(t), T(n), T(l)), a && a.d(c), o && o.d(c), r && r.d(c), u && u.d(c);
    }
  };
}
function Hc(i) {
  let e;
  return {
    c() {
      e = Y(" /");
    },
    l(t) {
      e = W(t, " /");
    },
    m(t, n) {
      L(t, e, n);
    },
    d(t) {
      t && T(e);
    }
  };
}
function kl(i) {
  let e = (
    /*p*/
    i[40].desc + ""
  ), t;
  return {
    c() {
      t = Y(e);
    },
    l(n) {
      t = W(n, e);
    },
    m(n, l) {
      L(n, t, l);
    },
    p(n, l) {
      l[0] & /*progress*/
      128 && e !== (e = /*p*/
      n[40].desc + "") && $e(t, e);
    },
    d(n) {
      n && T(t);
    }
  };
}
function Fl(i) {
  let e;
  return {
    c() {
      e = Y("-");
    },
    l(t) {
      e = W(t, "-");
    },
    m(t, n) {
      L(t, e, n);
    },
    d(t) {
      t && T(e);
    }
  };
}
function $l(i) {
  let e = (100 * /*progress_level*/
  (i[14][
    /*i*/
    i[42]
  ] || 0)).toFixed(1) + "", t, n;
  return {
    c() {
      t = Y(e), n = Y("%");
    },
    l(l) {
      t = W(l, e), n = W(l, "%");
    },
    m(l, a) {
      L(l, t, a), L(l, n, a);
    },
    p(l, a) {
      a[0] & /*progress_level*/
      16384 && e !== (e = (100 * /*progress_level*/
      (l[14][
        /*i*/
        l[42]
      ] || 0)).toFixed(1) + "") && $e(t, e);
    },
    d(l) {
      l && (T(t), T(n));
    }
  };
}
function Cl(i) {
  let e, t = (
    /*p*/
    (i[40].desc != null || /*progress_level*/
    i[14] && /*progress_level*/
    i[14][
      /*i*/
      i[42]
    ] != null) && yl(i)
  );
  return {
    c() {
      t && t.c(), e = Fe();
    },
    l(n) {
      t && t.l(n), e = Fe();
    },
    m(n, l) {
      t && t.m(n, l), L(n, e, l);
    },
    p(n, l) {
      /*p*/
      n[40].desc != null || /*progress_level*/
      n[14] && /*progress_level*/
      n[14][
        /*i*/
        n[42]
      ] != null ? t ? t.p(n, l) : (t = yl(n), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(n) {
      n && T(e), t && t.d(n);
    }
  };
}
function El(i) {
  let e, t, n, l;
  const a = (
    /*#slots*/
    i[30]["additional-loading-text"]
  ), o = Da(
    a,
    i,
    /*$$scope*/
    i[29],
    hl
  );
  return {
    c() {
      e = Pe("p"), t = Y(
        /*loading_text*/
        i[9]
      ), n = ke(), o && o.c(), this.h();
    },
    l(r) {
      e = Ne(r, "P", { class: !0 });
      var u = Oe(e);
      t = W(
        u,
        /*loading_text*/
        i[9]
      ), u.forEach(T), n = ye(r), o && o.l(r), this.h();
    },
    h() {
      xe(e, "class", "loading svelte-17v219f");
    },
    m(r, u) {
      L(r, e, u), nt(e, t), L(r, n, u), o && o.m(r, u), l = !0;
    },
    p(r, u) {
      (!l || u[0] & /*loading_text*/
      512) && $e(
        t,
        /*loading_text*/
        r[9]
      ), o && o.p && (!l || u[0] & /*$$scope*/
      536870912) && Ca(
        o,
        a,
        r,
        /*$$scope*/
        r[29],
        l ? Fa(
          a,
          /*$$scope*/
          r[29],
          u,
          Tc
        ) : ka(
          /*$$scope*/
          r[29]
        ),
        hl
      );
    },
    i(r) {
      l || (Be(o, r), l = !0);
    },
    o(r) {
      He(o, r), l = !1;
    },
    d(r) {
      r && (T(e), T(n)), o && o.d(r);
    }
  };
}
function Zc(i) {
  let e, t, n, l, a;
  const o = [Lc, qc], r = [];
  function u(c, s) {
    return (
      /*status*/
      c[4] === "pending" ? 0 : (
        /*status*/
        c[4] === "error" ? 1 : -1
      )
    );
  }
  return ~(t = u(i)) && (n = r[t] = o[t](i)), {
    c() {
      e = Pe("div"), n && n.c(), this.h();
    },
    l(c) {
      e = Ne(c, "DIV", { class: !0 });
      var s = Oe(e);
      n && n.l(s), s.forEach(T), this.h();
    },
    h() {
      xe(e, "class", l = "wrap " + /*variant*/
      i[8] + " " + /*show_progress*/
      i[6] + " svelte-17v219f"), De(e, "hide", !/*status*/
      i[4] || /*status*/
      i[4] === "complete" || /*show_progress*/
      i[6] === "hidden" || /*status*/
      i[4] == "streaming"), De(
        e,
        "translucent",
        /*variant*/
        i[8] === "center" && /*status*/
        (i[4] === "pending" || /*status*/
        i[4] === "error") || /*translucent*/
        i[11] || /*show_progress*/
        i[6] === "minimal"
      ), De(
        e,
        "generating",
        /*status*/
        i[4] === "generating" && /*show_progress*/
        i[6] === "full"
      ), De(
        e,
        "border",
        /*border*/
        i[12]
      ), We(
        e,
        "position",
        /*absolute*/
        i[10] ? "absolute" : "static"
      ), We(
        e,
        "padding",
        /*absolute*/
        i[10] ? "0" : "var(--size-8) 0"
      );
    },
    m(c, s) {
      L(c, e, s), ~t && r[t].m(e, null), i[33](e), a = !0;
    },
    p(c, s) {
      let d = t;
      t = u(c), t === d ? ~t && r[t].p(c, s) : (n && (Qn(), He(r[d], 1, 1, () => {
        r[d] = null;
      }), Kn()), ~t ? (n = r[t], n ? n.p(c, s) : (n = r[t] = o[t](c), n.c()), Be(n, 1), n.m(e, null)) : n = null), (!a || s[0] & /*variant, show_progress*/
      320 && l !== (l = "wrap " + /*variant*/
      c[8] + " " + /*show_progress*/
      c[6] + " svelte-17v219f")) && xe(e, "class", l), (!a || s[0] & /*variant, show_progress, status, show_progress*/
      336) && De(e, "hide", !/*status*/
      c[4] || /*status*/
      c[4] === "complete" || /*show_progress*/
      c[6] === "hidden" || /*status*/
      c[4] == "streaming"), (!a || s[0] & /*variant, show_progress, variant, status, translucent, show_progress*/
      2384) && De(
        e,
        "translucent",
        /*variant*/
        c[8] === "center" && /*status*/
        (c[4] === "pending" || /*status*/
        c[4] === "error") || /*translucent*/
        c[11] || /*show_progress*/
        c[6] === "minimal"
      ), (!a || s[0] & /*variant, show_progress, status, show_progress*/
      336) && De(
        e,
        "generating",
        /*status*/
        c[4] === "generating" && /*show_progress*/
        c[6] === "full"
      ), (!a || s[0] & /*variant, show_progress, border*/
      4416) && De(
        e,
        "border",
        /*border*/
        c[12]
      ), s[0] & /*absolute*/
      1024 && We(
        e,
        "position",
        /*absolute*/
        c[10] ? "absolute" : "static"
      ), s[0] & /*absolute*/
      1024 && We(
        e,
        "padding",
        /*absolute*/
        c[10] ? "0" : "var(--size-8) 0"
      );
    },
    i(c) {
      a || (Be(n), a = !0);
    },
    o(c) {
      He(n), a = !1;
    },
    d(c) {
      c && T(e), ~t && r[t].d(), i[33](null);
    }
  };
}
var jc = function(i, e, t, n) {
  function l(a) {
    return a instanceof t ? a : new t(function(o) {
      o(a);
    });
  }
  return new (t || (t = Promise))(function(a, o) {
    function r(s) {
      try {
        c(n.next(s));
      } catch (d) {
        o(d);
      }
    }
    function u(s) {
      try {
        c(n.throw(s));
      } catch (d) {
        o(d);
      }
    }
    function c(s) {
      s.done ? a(s.value) : l(s.value).then(r, u);
    }
    c((n = n.apply(i, e || [])).next());
  });
};
let un = [], Hn = !1;
const Uc = typeof window < "u", Ea = Uc ? window.requestAnimationFrame : (i) => {
};
function Gc(i) {
  return jc(this, arguments, void 0, function* (e, t = !0) {
    if (!(window.__gradio_mode__ === "website" || window.__gradio_mode__ !== "app" && t !== !0)) {
      if (un.push(e), !Hn) Hn = !0;
      else return;
      yield Ac(), Ea(() => {
        let n = [0, 0];
        for (let l = 0; l < un.length; l++) {
          const o = un[l].getBoundingClientRect();
          (l === 0 || o.top + window.scrollY <= n[0]) && (n[0] = o.top + window.scrollY, n[1] = l);
        }
        window.scrollTo({ top: n[0] - 20, behavior: "smooth" }), Hn = !1, un = [];
      });
    }
  });
}
function Vc(i, e, t) {
  let n, { $$slots: l = {}, $$scope: a } = e;
  const o = Bc();
  let { i18n: r } = e, { eta: u = null } = e, { queue_position: c } = e, { queue_size: s } = e, { status: d } = e, { scroll_to_output: f = !1 } = e, { timer: h = !0 } = e, { show_progress: p = "full" } = e, { message: v = null } = e, { progress: k = null } = e, { variant: C = "default" } = e, { loading_text: m = "Loading..." } = e, { absolute: _ = !0 } = e, { translucent: g = !1 } = e, { border: D = !1 } = e, { autoscroll: b } = e, w, E = !1, y = 0, B = 0, q = null, z = null, le = 0, G = null, N, M = null, V = !0;
  const P = () => {
    t(0, u = t(27, q = t(19, A = null))), t(25, y = performance.now()), t(26, B = 0), E = !0, ee();
  };
  function ee() {
    Ea(() => {
      t(26, B = (performance.now() - y) / 1e3), E && ee();
    });
  }
  function K() {
    t(26, B = 0), t(0, u = t(27, q = t(19, A = null))), E && (E = !1);
  }
  Sc(() => {
    E && K();
  });
  let A = null;
  function Q(x) {
    dl[x ? "unshift" : "push"](() => {
      M = x, t(16, M), t(7, k), t(14, G), t(15, N);
    });
  }
  const qe = () => {
    o("clear_status");
  };
  function ae(x) {
    dl[x ? "unshift" : "push"](() => {
      w = x, t(13, w);
    });
  }
  return i.$$set = (x) => {
    "i18n" in x && t(1, r = x.i18n), "eta" in x && t(0, u = x.eta), "queue_position" in x && t(2, c = x.queue_position), "queue_size" in x && t(3, s = x.queue_size), "status" in x && t(4, d = x.status), "scroll_to_output" in x && t(22, f = x.scroll_to_output), "timer" in x && t(5, h = x.timer), "show_progress" in x && t(6, p = x.show_progress), "message" in x && t(23, v = x.message), "progress" in x && t(7, k = x.progress), "variant" in x && t(8, C = x.variant), "loading_text" in x && t(9, m = x.loading_text), "absolute" in x && t(10, _ = x.absolute), "translucent" in x && t(11, g = x.translucent), "border" in x && t(12, D = x.border), "autoscroll" in x && t(24, b = x.autoscroll), "$$scope" in x && t(29, a = x.$$scope);
  }, i.$$.update = () => {
    i.$$.dirty[0] & /*eta, old_eta, timer_start, eta_from_start*/
    436207617 && (u === null && t(0, u = q), u != null && q !== u && (t(28, z = (performance.now() - y) / 1e3 + u), t(19, A = z.toFixed(1)), t(27, q = u))), i.$$.dirty[0] & /*eta_from_start, timer_diff*/
    335544320 && t(17, le = z === null || z <= 0 || !B ? null : Math.min(B / z, 1)), i.$$.dirty[0] & /*progress*/
    128 && k != null && t(18, V = !1), i.$$.dirty[0] & /*progress, progress_level, progress_bar, last_progress_level*/
    114816 && (k != null ? t(14, G = k.map((x) => {
      if (x.index != null && x.length != null)
        return x.index / x.length;
      if (x.progress != null)
        return x.progress;
    })) : t(14, G = null), G ? (t(15, N = G[G.length - 1]), M && (N === 0 ? t(16, M.style.transition = "0", M) : t(16, M.style.transition = "150ms", M))) : t(15, N = void 0)), i.$$.dirty[0] & /*status*/
    16 && (d === "pending" ? P() : K()), i.$$.dirty[0] & /*el, scroll_to_output, status, autoscroll*/
    20979728 && w && f && (d === "pending" || d === "complete") && Gc(w, b), i.$$.dirty[0] & /*status, message*/
    8388624, i.$$.dirty[0] & /*timer_diff*/
    67108864 && t(20, n = B.toFixed(1));
  }, [
    u,
    r,
    c,
    s,
    d,
    h,
    p,
    k,
    C,
    m,
    _,
    g,
    D,
    w,
    G,
    N,
    M,
    le,
    V,
    A,
    n,
    o,
    f,
    v,
    b,
    y,
    B,
    q,
    z,
    a,
    l,
    Q,
    qe,
    ae
  ];
}
class Xc extends $c {
  constructor(e) {
    super(), Cc(
      this,
      e,
      Vc,
      Zc,
      Ec,
      {
        i18n: 1,
        eta: 0,
        queue_position: 2,
        queue_size: 3,
        status: 4,
        scroll_to_output: 22,
        timer: 5,
        show_progress: 6,
        message: 23,
        progress: 7,
        variant: 8,
        loading_text: 9,
        absolute: 10,
        translucent: 11,
        border: 12,
        autoscroll: 24
      },
      null,
      [-1, -1]
    );
  }
}
const {
  HtmlTagHydration: s3,
  SvelteComponent: u3,
  add_render_callback: c3,
  append_hydration: _3,
  attr: d3,
  bubble: f3,
  check_outros: h3,
  children: p3,
  claim_component: m3,
  claim_element: g3,
  claim_html_tag: b3,
  claim_space: v3,
  claim_text: D3,
  create_component: w3,
  create_in_transition: y3,
  create_out_transition: k3,
  destroy_component: F3,
  detach: $3,
  element: C3,
  get_svelte_dataset: E3,
  group_outros: A3,
  init: S3,
  insert_hydration: B3,
  listen: x3,
  mount_component: T3,
  run_all: q3,
  safe_not_equal: L3,
  set_data: z3,
  space: I3,
  stop_propagation: M3,
  text: R3,
  toggle_class: O3,
  transition_in: N3,
  transition_out: P3
} = window.__gradio__svelte__internal, { createEventDispatcher: H3, onMount: Z3 } = window.__gradio__svelte__internal, {
  SvelteComponent: j3,
  append_hydration: U3,
  attr: G3,
  bubble: V3,
  check_outros: X3,
  children: W3,
  claim_component: Y3,
  claim_element: K3,
  claim_space: Q3,
  create_animation: J3,
  create_component: e5,
  destroy_component: t5,
  detach: n5,
  element: i5,
  ensure_array_like: l5,
  fix_and_outro_and_destroy_block: a5,
  fix_position: o5,
  group_outros: r5,
  init: s5,
  insert_hydration: u5,
  mount_component: c5,
  noop: _5,
  safe_not_equal: d5,
  set_style: f5,
  space: h5,
  transition_in: p5,
  transition_out: m5,
  update_keyed_each: g5
} = window.__gradio__svelte__internal, {
  SvelteComponent: b5,
  attr: v5,
  children: D5,
  claim_element: w5,
  detach: y5,
  element: k5,
  empty: F5,
  init: $5,
  insert_hydration: C5,
  noop: E5,
  safe_not_equal: A5,
  set_style: S5
} = window.__gradio__svelte__internal, {
  SvelteComponent: Wc,
  add_iframe_resize_listener: Yc,
  add_render_callback: Kc,
  append_hydration: Qc,
  attr: Jc,
  binding_callbacks: e_,
  children: t_,
  claim_element: n_,
  claim_text: i_,
  detach: Al,
  element: l_,
  init: a_,
  insert_hydration: o_,
  noop: Sl,
  safe_not_equal: r_,
  set_data: s_,
  text: u_,
  toggle_class: ht
} = window.__gradio__svelte__internal, { onMount: c_ } = window.__gradio__svelte__internal;
function __(i) {
  let e, t = Bl(
    /*value*/
    i[0]
  ) + "", n, l;
  return {
    c() {
      e = l_("div"), n = u_(t), this.h();
    },
    l(a) {
      e = n_(a, "DIV", { class: !0 });
      var o = t_(e);
      n = i_(o, t), o.forEach(Al), this.h();
    },
    h() {
      Jc(e, "class", "svelte-1eljuyu"), Kc(() => (
        /*div_elementresize_handler*/
        i[5].call(e)
      )), ht(
        e,
        "table",
        /*type*/
        i[1] === "table"
      ), ht(
        e,
        "gallery",
        /*type*/
        i[1] === "gallery"
      ), ht(
        e,
        "selected",
        /*selected*/
        i[2]
      );
    },
    m(a, o) {
      o_(a, e, o), Qc(e, n), l = Yc(
        e,
        /*div_elementresize_handler*/
        i[5].bind(e)
      ), i[6](e);
    },
    p(a, [o]) {
      o & /*value*/
      1 && t !== (t = Bl(
        /*value*/
        a[0]
      ) + "") && s_(n, t), o & /*type*/
      2 && ht(
        e,
        "table",
        /*type*/
        a[1] === "table"
      ), o & /*type*/
      2 && ht(
        e,
        "gallery",
        /*type*/
        a[1] === "gallery"
      ), o & /*selected*/
      4 && ht(
        e,
        "selected",
        /*selected*/
        a[2]
      );
    },
    i: Sl,
    o: Sl,
    d(a) {
      a && Al(e), l(), i[6](null);
    }
  };
}
function d_(i, e) {
  i.style.setProperty("--local-text-width", `${e && e < 150 ? e : 200}px`), i.style.whiteSpace = "unset";
}
function Bl(i, e = 60) {
  if (!i) return "";
  const t = String(i);
  return t.length <= e ? t : t.slice(0, e) + "...";
}
function f_(i, e, t) {
  let { value: n } = e, { type: l } = e, { selected: a = !1 } = e, o, r;
  c_(() => {
    d_(r, o);
  });
  function u() {
    o = this.clientWidth, t(3, o);
  }
  function c(s) {
    e_[s ? "unshift" : "push"](() => {
      r = s, t(4, r);
    });
  }
  return i.$$set = (s) => {
    "value" in s && t(0, n = s.value), "type" in s && t(1, l = s.type), "selected" in s && t(2, a = s.selected);
  }, [n, l, a, o, r, u, c];
}
class B5 extends Wc {
  constructor(e) {
    super(), a_(this, e, f_, __, r_, { value: 0, type: 1, selected: 2 });
  }
}
const {
  SvelteComponent: h_,
  add_flush_callback: xl,
  assign: p_,
  bind: Tl,
  binding_callbacks: ql,
  check_outros: m_,
  claim_component: si,
  claim_space: g_,
  create_component: ui,
  destroy_component: ci,
  detach: b_,
  flush: H,
  get_spread_object: v_,
  get_spread_update: D_,
  group_outros: w_,
  init: y_,
  insert_hydration: k_,
  mount_component: _i,
  safe_not_equal: F_,
  space: $_,
  transition_in: mt,
  transition_out: Lt
} = window.__gradio__svelte__internal;
function Ll(i) {
  let e, t;
  const n = [
    { autoscroll: (
      /*gradio*/
      i[2].autoscroll
    ) },
    { i18n: (
      /*gradio*/
      i[2].i18n
    ) },
    /*loading_status*/
    i[20]
  ];
  let l = {};
  for (let a = 0; a < n.length; a += 1)
    l = p_(l, n[a]);
  return e = new Xc({ props: l }), e.$on(
    "clear_status",
    /*clear_status_handler*/
    i[28]
  ), {
    c() {
      ui(e.$$.fragment);
    },
    l(a) {
      si(e.$$.fragment, a);
    },
    m(a, o) {
      _i(e, a, o), t = !0;
    },
    p(a, o) {
      const r = o[0] & /*gradio, loading_status*/
      1048580 ? D_(n, [
        o[0] & /*gradio*/
        4 && { autoscroll: (
          /*gradio*/
          a[2].autoscroll
        ) },
        o[0] & /*gradio*/
        4 && { i18n: (
          /*gradio*/
          a[2].i18n
        ) },
        o[0] & /*loading_status*/
        1048576 && v_(
          /*loading_status*/
          a[20]
        )
      ]) : {};
      e.$set(r);
    },
    i(a) {
      t || (mt(e.$$.fragment, a), t = !0);
    },
    o(a) {
      Lt(e.$$.fragment, a), t = !1;
    },
    d(a) {
      ci(e, a);
    }
  };
}
function C_(i) {
  let e, t, n, l, a, o = (
    /*loading_status*/
    i[20] && Ll(i)
  );
  function r(s) {
    i[29](s);
  }
  function u(s) {
    i[30](s);
  }
  let c = {
    label: (
      /*label*/
      i[3]
    ),
    info: (
      /*info*/
      i[4]
    ),
    help: (
      /*help*/
      i[5]
    ),
    show_label: (
      /*show_label*/
      i[11]
    ),
    lines: (
      /*lines*/
      i[9]
    ),
    type: (
      /*type*/
      i[13]
    ),
    rtl: (
      /*rtl*/
      i[21]
    ),
    text_align: (
      /*text_align*/
      i[22]
    ),
    max_lines: (
      /*max_lines*/
      i[12]
    ),
    placeholder: (
      /*placeholder*/
      i[10]
    ),
    submit_btn: (
      /*submit_btn*/
      i[17]
    ),
    stop_btn: (
      /*stop_btn*/
      i[18]
    ),
    show_copy_button: (
      /*show_copy_button*/
      i[19]
    ),
    autofocus: (
      /*autofocus*/
      i[23]
    ),
    container: (
      /*container*/
      i[14]
    ),
    autoscroll: (
      /*autoscroll*/
      i[24]
    ),
    max_length: (
      /*max_length*/
      i[26]
    ),
    html_attributes: (
      /*html_attributes*/
      i[27]
    ),
    disabled: !/*interactive*/
    i[25]
  };
  return (
    /*value*/
    i[0] !== void 0 && (c.value = /*value*/
    i[0]), /*value_is_output*/
    i[1] !== void 0 && (c.value_is_output = /*value_is_output*/
    i[1]), t = new hc({ props: c }), ql.push(() => Tl(t, "value", r)), ql.push(() => Tl(t, "value_is_output", u)), t.$on(
      "change",
      /*change_handler*/
      i[31]
    ), t.$on(
      "input",
      /*input_handler*/
      i[32]
    ), t.$on(
      "submit",
      /*submit_handler*/
      i[33]
    ), t.$on(
      "blur",
      /*blur_handler*/
      i[34]
    ), t.$on(
      "select",
      /*select_handler*/
      i[35]
    ), t.$on(
      "focus",
      /*focus_handler*/
      i[36]
    ), t.$on(
      "stop",
      /*stop_handler*/
      i[37]
    ), t.$on(
      "copy",
      /*copy_handler*/
      i[38]
    ), {
      c() {
        o && o.c(), e = $_(), ui(t.$$.fragment);
      },
      l(s) {
        o && o.l(s), e = g_(s), si(t.$$.fragment, s);
      },
      m(s, d) {
        o && o.m(s, d), k_(s, e, d), _i(t, s, d), a = !0;
      },
      p(s, d) {
        /*loading_status*/
        s[20] ? o ? (o.p(s, d), d[0] & /*loading_status*/
        1048576 && mt(o, 1)) : (o = Ll(s), o.c(), mt(o, 1), o.m(e.parentNode, e)) : o && (w_(), Lt(o, 1, 1, () => {
          o = null;
        }), m_());
        const f = {};
        d[0] & /*label*/
        8 && (f.label = /*label*/
        s[3]), d[0] & /*info*/
        16 && (f.info = /*info*/
        s[4]), d[0] & /*help*/
        32 && (f.help = /*help*/
        s[5]), d[0] & /*show_label*/
        2048 && (f.show_label = /*show_label*/
        s[11]), d[0] & /*lines*/
        512 && (f.lines = /*lines*/
        s[9]), d[0] & /*type*/
        8192 && (f.type = /*type*/
        s[13]), d[0] & /*rtl*/
        2097152 && (f.rtl = /*rtl*/
        s[21]), d[0] & /*text_align*/
        4194304 && (f.text_align = /*text_align*/
        s[22]), d[0] & /*max_lines*/
        4096 && (f.max_lines = /*max_lines*/
        s[12]), d[0] & /*placeholder*/
        1024 && (f.placeholder = /*placeholder*/
        s[10]), d[0] & /*submit_btn*/
        131072 && (f.submit_btn = /*submit_btn*/
        s[17]), d[0] & /*stop_btn*/
        262144 && (f.stop_btn = /*stop_btn*/
        s[18]), d[0] & /*show_copy_button*/
        524288 && (f.show_copy_button = /*show_copy_button*/
        s[19]), d[0] & /*autofocus*/
        8388608 && (f.autofocus = /*autofocus*/
        s[23]), d[0] & /*container*/
        16384 && (f.container = /*container*/
        s[14]), d[0] & /*autoscroll*/
        16777216 && (f.autoscroll = /*autoscroll*/
        s[24]), d[0] & /*max_length*/
        67108864 && (f.max_length = /*max_length*/
        s[26]), d[0] & /*html_attributes*/
        134217728 && (f.html_attributes = /*html_attributes*/
        s[27]), d[0] & /*interactive*/
        33554432 && (f.disabled = !/*interactive*/
        s[25]), !n && d[0] & /*value*/
        1 && (n = !0, f.value = /*value*/
        s[0], xl(() => n = !1)), !l && d[0] & /*value_is_output*/
        2 && (l = !0, f.value_is_output = /*value_is_output*/
        s[1], xl(() => l = !1)), t.$set(f);
      },
      i(s) {
        a || (mt(o), mt(t.$$.fragment, s), a = !0);
      },
      o(s) {
        Lt(o), Lt(t.$$.fragment, s), a = !1;
      },
      d(s) {
        s && b_(e), o && o.d(s), ci(t, s);
      }
    }
  );
}
function E_(i) {
  let e, t;
  return e = new fo({
    props: {
      visible: (
        /*visible*/
        i[8]
      ),
      elem_id: (
        /*elem_id*/
        i[6]
      ),
      elem_classes: (
        /*elem_classes*/
        i[7]
      ),
      scale: (
        /*scale*/
        i[15]
      ),
      min_width: (
        /*min_width*/
        i[16]
      ),
      allow_overflow: !1,
      padding: (
        /*container*/
        i[14]
      ),
      $$slots: { default: [C_] },
      $$scope: { ctx: i }
    }
  }), {
    c() {
      ui(e.$$.fragment);
    },
    l(n) {
      si(e.$$.fragment, n);
    },
    m(n, l) {
      _i(e, n, l), t = !0;
    },
    p(n, l) {
      const a = {};
      l[0] & /*visible*/
      256 && (a.visible = /*visible*/
      n[8]), l[0] & /*elem_id*/
      64 && (a.elem_id = /*elem_id*/
      n[6]), l[0] & /*elem_classes*/
      128 && (a.elem_classes = /*elem_classes*/
      n[7]), l[0] & /*scale*/
      32768 && (a.scale = /*scale*/
      n[15]), l[0] & /*min_width*/
      65536 && (a.min_width = /*min_width*/
      n[16]), l[0] & /*container*/
      16384 && (a.padding = /*container*/
      n[14]), l[0] & /*label, info, help, show_label, lines, type, rtl, text_align, max_lines, placeholder, submit_btn, stop_btn, show_copy_button, autofocus, container, autoscroll, max_length, html_attributes, interactive, value, value_is_output, gradio, loading_status*/
      268336703 | l[1] & /*$$scope*/
      256 && (a.$$scope = { dirty: l, ctx: n }), e.$set(a);
    },
    i(n) {
      t || (mt(e.$$.fragment, n), t = !0);
    },
    o(n) {
      Lt(e.$$.fragment, n), t = !1;
    },
    d(n) {
      ci(e, n);
    }
  };
}
function A_(i, e, t) {
  let { gradio: n } = e, { label: l = "Textbox" } = e, { info: a = void 0 } = e, { help: o = void 0 } = e, { elem_id: r = "" } = e, { elem_classes: u = [] } = e, { visible: c = !0 } = e, { value: s = "" } = e, { lines: d } = e, { placeholder: f = "" } = e, { show_label: h } = e, { max_lines: p = void 0 } = e, { type: v = "text" } = e, { container: k = !0 } = e, { scale: C = null } = e, { min_width: m = void 0 } = e, { submit_btn: _ = null } = e, { stop_btn: g = null } = e, { show_copy_button: D = !1 } = e, { loading_status: b = void 0 } = e, { value_is_output: w = !1 } = e, { rtl: E = !1 } = e, { text_align: y = void 0 } = e, { autofocus: B = !1 } = e, { autoscroll: q = !0 } = e, { interactive: z } = e, { max_length: le = void 0 } = e, { html_attributes: G = null } = e;
  const N = () => n.dispatch("clear_status", b);
  function M(S) {
    s = S, t(0, s);
  }
  function V(S) {
    w = S, t(1, w);
  }
  const P = () => n.dispatch("change", s), ee = () => n.dispatch("input"), K = () => n.dispatch("submit"), A = () => n.dispatch("blur"), Q = (S) => n.dispatch("select", S.detail), qe = () => n.dispatch("focus"), ae = () => n.dispatch("stop"), x = (S) => n.dispatch("copy", S.detail);
  return i.$$set = (S) => {
    "gradio" in S && t(2, n = S.gradio), "label" in S && t(3, l = S.label), "info" in S && t(4, a = S.info), "help" in S && t(5, o = S.help), "elem_id" in S && t(6, r = S.elem_id), "elem_classes" in S && t(7, u = S.elem_classes), "visible" in S && t(8, c = S.visible), "value" in S && t(0, s = S.value), "lines" in S && t(9, d = S.lines), "placeholder" in S && t(10, f = S.placeholder), "show_label" in S && t(11, h = S.show_label), "max_lines" in S && t(12, p = S.max_lines), "type" in S && t(13, v = S.type), "container" in S && t(14, k = S.container), "scale" in S && t(15, C = S.scale), "min_width" in S && t(16, m = S.min_width), "submit_btn" in S && t(17, _ = S.submit_btn), "stop_btn" in S && t(18, g = S.stop_btn), "show_copy_button" in S && t(19, D = S.show_copy_button), "loading_status" in S && t(20, b = S.loading_status), "value_is_output" in S && t(1, w = S.value_is_output), "rtl" in S && t(21, E = S.rtl), "text_align" in S && t(22, y = S.text_align), "autofocus" in S && t(23, B = S.autofocus), "autoscroll" in S && t(24, q = S.autoscroll), "interactive" in S && t(25, z = S.interactive), "max_length" in S && t(26, le = S.max_length), "html_attributes" in S && t(27, G = S.html_attributes);
  }, [
    s,
    w,
    n,
    l,
    a,
    o,
    r,
    u,
    c,
    d,
    f,
    h,
    p,
    v,
    k,
    C,
    m,
    _,
    g,
    D,
    b,
    E,
    y,
    B,
    q,
    z,
    le,
    G,
    N,
    M,
    V,
    P,
    ee,
    K,
    A,
    Q,
    qe,
    ae,
    x
  ];
}
class x5 extends h_ {
  constructor(e) {
    super(), y_(
      this,
      e,
      A_,
      E_,
      F_,
      {
        gradio: 2,
        label: 3,
        info: 4,
        help: 5,
        elem_id: 6,
        elem_classes: 7,
        visible: 8,
        value: 0,
        lines: 9,
        placeholder: 10,
        show_label: 11,
        max_lines: 12,
        type: 13,
        container: 14,
        scale: 15,
        min_width: 16,
        submit_btn: 17,
        stop_btn: 18,
        show_copy_button: 19,
        loading_status: 20,
        value_is_output: 1,
        rtl: 21,
        text_align: 22,
        autofocus: 23,
        autoscroll: 24,
        interactive: 25,
        max_length: 26,
        html_attributes: 27
      },
      null,
      [-1, -1]
    );
  }
  get gradio() {
    return this.$$.ctx[2];
  }
  set gradio(e) {
    this.$$set({ gradio: e }), H();
  }
  get label() {
    return this.$$.ctx[3];
  }
  set label(e) {
    this.$$set({ label: e }), H();
  }
  get info() {
    return this.$$.ctx[4];
  }
  set info(e) {
    this.$$set({ info: e }), H();
  }
  get help() {
    return this.$$.ctx[5];
  }
  set help(e) {
    this.$$set({ help: e }), H();
  }
  get elem_id() {
    return this.$$.ctx[6];
  }
  set elem_id(e) {
    this.$$set({ elem_id: e }), H();
  }
  get elem_classes() {
    return this.$$.ctx[7];
  }
  set elem_classes(e) {
    this.$$set({ elem_classes: e }), H();
  }
  get visible() {
    return this.$$.ctx[8];
  }
  set visible(e) {
    this.$$set({ visible: e }), H();
  }
  get value() {
    return this.$$.ctx[0];
  }
  set value(e) {
    this.$$set({ value: e }), H();
  }
  get lines() {
    return this.$$.ctx[9];
  }
  set lines(e) {
    this.$$set({ lines: e }), H();
  }
  get placeholder() {
    return this.$$.ctx[10];
  }
  set placeholder(e) {
    this.$$set({ placeholder: e }), H();
  }
  get show_label() {
    return this.$$.ctx[11];
  }
  set show_label(e) {
    this.$$set({ show_label: e }), H();
  }
  get max_lines() {
    return this.$$.ctx[12];
  }
  set max_lines(e) {
    this.$$set({ max_lines: e }), H();
  }
  get type() {
    return this.$$.ctx[13];
  }
  set type(e) {
    this.$$set({ type: e }), H();
  }
  get container() {
    return this.$$.ctx[14];
  }
  set container(e) {
    this.$$set({ container: e }), H();
  }
  get scale() {
    return this.$$.ctx[15];
  }
  set scale(e) {
    this.$$set({ scale: e }), H();
  }
  get min_width() {
    return this.$$.ctx[16];
  }
  set min_width(e) {
    this.$$set({ min_width: e }), H();
  }
  get submit_btn() {
    return this.$$.ctx[17];
  }
  set submit_btn(e) {
    this.$$set({ submit_btn: e }), H();
  }
  get stop_btn() {
    return this.$$.ctx[18];
  }
  set stop_btn(e) {
    this.$$set({ stop_btn: e }), H();
  }
  get show_copy_button() {
    return this.$$.ctx[19];
  }
  set show_copy_button(e) {
    this.$$set({ show_copy_button: e }), H();
  }
  get loading_status() {
    return this.$$.ctx[20];
  }
  set loading_status(e) {
    this.$$set({ loading_status: e }), H();
  }
  get value_is_output() {
    return this.$$.ctx[1];
  }
  set value_is_output(e) {
    this.$$set({ value_is_output: e }), H();
  }
  get rtl() {
    return this.$$.ctx[21];
  }
  set rtl(e) {
    this.$$set({ rtl: e }), H();
  }
  get text_align() {
    return this.$$.ctx[22];
  }
  set text_align(e) {
    this.$$set({ text_align: e }), H();
  }
  get autofocus() {
    return this.$$.ctx[23];
  }
  set autofocus(e) {
    this.$$set({ autofocus: e }), H();
  }
  get autoscroll() {
    return this.$$.ctx[24];
  }
  set autoscroll(e) {
    this.$$set({ autoscroll: e }), H();
  }
  get interactive() {
    return this.$$.ctx[25];
  }
  set interactive(e) {
    this.$$set({ interactive: e }), H();
  }
  get max_length() {
    return this.$$.ctx[26];
  }
  set max_length(e) {
    this.$$set({ max_length: e }), H();
  }
  get html_attributes() {
    return this.$$.ctx[27];
  }
  set html_attributes(e) {
    this.$$set({ html_attributes: e }), H();
  }
}
export {
  B5 as E,
  x5 as I,
  hc as T,
  Ei as c,
  B_ as g
};
