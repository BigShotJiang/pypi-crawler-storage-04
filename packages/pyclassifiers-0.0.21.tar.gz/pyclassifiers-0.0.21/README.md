# *pyclassifiers* project by Mark Veltzer

description: classifiers from pypi

project website: https://veltzer.github.io/pyclassifiers

author: Mark Veltzer

version: 0.0.21

![Code style: black](https://img.shields.io/badge/code%20style-black-000000.svg)

## github

![License](https://img.shields.io/github/license/veltzer/pyclassifiers)

## build

![build](https://github.com/veltzer/pyclassifiers/workflows/build/badge.svg)

## pypi

![PyPI - Status](https://img.shields.io/pypi/status/pyclassifiers)
![PyPI - Python Version](https://img.shields.io/pypi/pyversions/pyclassifiers)
![PyPI - License](https://img.shields.io/pypi/l/pyclassifiers)
![PyPI - Package Name](https://img.shields.io/pypi/v/pyclassifiers)
![PyPI - Format](https://img.shields.io/pypi/format/pyclassifiers)

## pypi download

![PyPI - Downloads](https://img.shields.io/pypi/dd/pyclassifiers)
![PyPI - Downloads](https://img.shields.io/pypi/dw/pyclassifiers)
![PyPI - Downloads](https://img.shields.io/pypi/dm/pyclassifiers)



## contact me
[mailto](mailto:mark.veltzer@gmail.com)
![gitter](https://img.shields.io/gitter/room/veltzer/mark.veltzer)
![discord](https://img.shields.io/discord/719336281624281119)
![discord](https://img.shields.io/discord/719336282194444302)

Mark Veltzer, Copyright © 2017, 2018, 2019, 2020, 2021, 2022, 2023, 2024, 2025
