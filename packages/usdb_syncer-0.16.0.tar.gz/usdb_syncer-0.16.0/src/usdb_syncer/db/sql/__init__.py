"""Data directory for SQL scripts."""
