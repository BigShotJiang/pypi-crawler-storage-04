PRAGMA journal_mode = WAL;

BEGIN;

PRAGMA foreign_keys = ON;

COMMIT;