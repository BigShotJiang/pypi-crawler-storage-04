"""Data directory for files generated during the release workflow."""
