"""This file was generated using `write_resource_files.py`."""

from importlib import resources

METRONOME_TICK_WAV = resources.files() / "metronome-tick.wav"
