"""This file was generated using `write_resource_files.py`."""

from importlib import resources

NOTOSANS_BLACK_TTF = resources.files() / "NotoSans-Black.ttf"
NOTOSANS_BOLD_TTF = resources.files() / "NotoSans-Bold.ttf"
NOTOSANS_REGULAR_TTF = resources.files() / "NotoSans-Regular.ttf"
