"""
We are actively recruiting core contributors! MiPi provides a wonderful opportunity for new contributors. The package
is already being used by our team, and it has proven to be valuable. However, there is alot of opportunity to contribute
meaningful code!
"""