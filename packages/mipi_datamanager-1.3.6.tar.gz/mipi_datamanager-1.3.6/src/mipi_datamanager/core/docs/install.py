"""
## Install MiPi

Install MiPi using pip `pip install mipi_datamanager`


## IDE Notes

### Spyder

- potential known error when viewing objects in variable explorer

### Jet Brains IDE's (Pycharm/DataSpell)

- known error when viewing data in variable explorer. Only a problem in version ^2024

"""