class DomainEvent:
    pass
