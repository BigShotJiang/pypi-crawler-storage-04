"""
Text search tools for janito.
"""

from .core import SearchText

__all__ = ["SearchText"]
