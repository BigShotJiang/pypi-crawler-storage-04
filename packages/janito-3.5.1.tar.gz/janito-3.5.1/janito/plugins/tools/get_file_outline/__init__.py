"""
File outline tools for janito.
"""

from .core import GetFileOutline

__all__ = ["GetFileOutline"]
