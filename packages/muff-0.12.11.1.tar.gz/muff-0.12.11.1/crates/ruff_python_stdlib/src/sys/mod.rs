mod builtin_modules;
mod known_stdlib;

pub use builtin_modules::is_builtin_module;
pub use known_stdlib::is_known_standard_library;
