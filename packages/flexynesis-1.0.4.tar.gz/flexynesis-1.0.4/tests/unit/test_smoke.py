def test_smoke():
    import flexynesis
