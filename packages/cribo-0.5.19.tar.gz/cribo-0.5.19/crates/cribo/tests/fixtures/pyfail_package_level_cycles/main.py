#!/usr/bin/env python

import pkg1


def main():
    result = pkg1.main_function()
    print(f"Package cycle result: {result}")


if __name__ == "__main__":
    main()
