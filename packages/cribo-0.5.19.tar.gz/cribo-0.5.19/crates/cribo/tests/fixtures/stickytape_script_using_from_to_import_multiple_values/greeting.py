message = "Hello"


def print_stdout(value):
    print(value)
