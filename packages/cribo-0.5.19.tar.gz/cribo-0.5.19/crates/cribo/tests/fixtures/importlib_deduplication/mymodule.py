# Simple module to test import deduplication
print("mymodule.py is being executed!")
counter = 1
test_value = "Original"
