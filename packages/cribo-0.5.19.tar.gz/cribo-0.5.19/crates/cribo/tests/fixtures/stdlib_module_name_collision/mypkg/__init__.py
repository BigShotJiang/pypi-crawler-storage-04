"""Package with modules including one named 'abc' (same as stdlib)."""

from . import abc
from . import console

__all__ = ["abc", "console"]
