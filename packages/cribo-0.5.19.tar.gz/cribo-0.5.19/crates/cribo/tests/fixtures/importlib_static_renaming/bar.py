# bar.py - Another module for testing


def process(data):
    return f"Processed: {data}"


class Calculator:
    def add(self, a, b):
        return a + b

    def multiply(self, a, b):
        return a * b


VERSION = "1.0.0"
