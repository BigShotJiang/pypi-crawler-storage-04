# foo.py - Simple module to test importlib renaming


def greet(name):
    return f"Hello, {name}!"


def get_value():
    return 42


MESSAGE = "This is foo module"
