#!/usr/bin/env python3
"""Test package with __main__.py entry point."""


def main():
    print("Running from __main__.py")


if __name__ == "__main__":
    main()
