# Module init that imports from a submodule that has dependencies

from .exceptions import MyError

__all__ = ["MyError"]
