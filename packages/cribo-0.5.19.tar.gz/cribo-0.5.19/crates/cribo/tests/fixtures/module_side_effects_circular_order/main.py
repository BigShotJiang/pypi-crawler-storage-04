from my_package import TOP_LEVEL_VAL

print(f"Result: {TOP_LEVEL_VAL}")
