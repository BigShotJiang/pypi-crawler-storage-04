from . import mod_a

TOP_LEVEL_VAL = mod_a.A_VALUE
print(TOP_LEVEL_VAL)
