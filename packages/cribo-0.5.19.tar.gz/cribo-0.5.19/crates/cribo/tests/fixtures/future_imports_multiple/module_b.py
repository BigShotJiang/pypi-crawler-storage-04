from __future__ import annotations, print_function


def func_b():
    print("Function B")
