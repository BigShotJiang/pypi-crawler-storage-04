from __future__ import annotations, division


def func_a():
    print("Function A")
