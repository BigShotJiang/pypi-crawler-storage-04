import yaml_pkg

# Test the aliased class
obj = yaml_pkg.YO()
print(f"YO object: {obj}")
print(f"Tag: {obj.yaml_tag}")
