#!/usr/bin/env python

import first

print("Hello")
