"""Constants module."""

MAX_ITEMS = 100
DEFAULT_VALUE = "default"
