"""Data formatting module."""


def format_data(data):
    """Format the processed data."""
    return f"Formatted: {data}"
