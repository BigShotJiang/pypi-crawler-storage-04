"""Version information for the package"""

__version__ = "1.0.0"
__title__ = "Test Package"
__author__ = "Test Author"
