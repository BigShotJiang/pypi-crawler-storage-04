# Re-export with conflicts
from .helpers import process, validate, Logger

# Add module-level conflicts
User = "utils_user_string"
