#!/usr/bin/env python

import greetings.irrelevant

print(greetings.message)
