class MyClass:
    def __init__(self):
        self.value = "Hello from MyClass"


def my_func():
    return "Hello from my_func"
