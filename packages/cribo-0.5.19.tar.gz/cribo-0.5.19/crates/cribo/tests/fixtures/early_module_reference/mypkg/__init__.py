"""Package that demonstrates early module reference issue."""

# Import our modules
from . import api, sessions
