#!/usr/bin/env python

import hashlib

print(hashlib.sha1(b"Hello").hexdigest())
