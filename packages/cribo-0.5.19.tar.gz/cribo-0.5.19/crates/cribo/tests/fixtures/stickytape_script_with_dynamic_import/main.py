#!/usr/bin/env python

import importlib

greeting = importlib.import_module("greeting")

print(greeting.message)
