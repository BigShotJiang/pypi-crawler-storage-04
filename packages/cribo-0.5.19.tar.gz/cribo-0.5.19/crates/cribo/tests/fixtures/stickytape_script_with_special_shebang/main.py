#!/usr/bin/python3 -E

import sys

print(sys.flags.ignore_environment)
