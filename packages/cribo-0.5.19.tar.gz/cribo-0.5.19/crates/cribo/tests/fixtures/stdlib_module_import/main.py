"""Test case for stdlib module-level imports being incorrectly transformed."""

import helper

# Use the imported module
helper.process()
