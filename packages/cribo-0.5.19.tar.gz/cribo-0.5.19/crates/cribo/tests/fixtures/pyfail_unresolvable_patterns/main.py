#!/usr/bin/env python

import constants_a


def main():
    print(f"A_VALUE: {constants_a.A_VALUE}")


if __name__ == "__main__":
    main()
