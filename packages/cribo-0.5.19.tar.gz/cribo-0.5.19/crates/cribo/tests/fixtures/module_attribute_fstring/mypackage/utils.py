# Import specific attribute from constants module
from .constants import VERSION


def get_version():
    return VERSION
