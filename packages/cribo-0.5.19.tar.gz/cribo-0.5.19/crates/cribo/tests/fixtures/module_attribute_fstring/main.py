# Main entry point
import mypackage

print(f"Version: {mypackage.get_version()}")
