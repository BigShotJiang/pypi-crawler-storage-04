def format_result(operation, result):
    """Format operation result for display."""
    return f"{operation}: {result}"
