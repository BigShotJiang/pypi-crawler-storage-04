#!/usr/bin/env python

from greetings import greeting as g

print(g.message)
