"""Utils & function for implementations."""

from .server import DEFAULT_PROTOCOL_VERSION, PROTOCOL_VERSION

__all__ = ("DEFAULT_PROTOCOL_VERSION", "PROTOCOL_VERSION")
