Easyapp_don 0.2.3
Welcome to the Easyapp_don Library!
-------------------- Part 1: Introduction to Easyapp_don --------------------
1. What is Easyapp_don?
[1] Easyapp_don is a simple library designed for Python beginners. Its core dependencies are Kivy and KivyMD.
[2] The current version of Easyapp_don is 0.2.3, which is relatively stable. This is the third version released.
[3] The developer of Easyapp_don is LvYanHua, with a development date of August 12, 2025. It is patented and protected by intellectual property rights.
[4] Easyapp_don is mainly developed to solve the problem of overly complex code in Kivy and KivyMD. It can be fully used in combination with Kivy and KivyMD.
[5] Easyapp_don is developed entirely based on Kivy and KivyMD, with no other dependencies. It relies on Python standard libraries such as typing, sys, os, and queue.
2. What is the Development Purpose of Easyapp_don?
[1] To simplify code for beginners, reduce code workload, make coding easier for users, and significantly save time.
[2] To create simple apps while minimizing all costs.
3. What are the Dependencies and Other Requirements of Easyapp_don?
[1] The dependent libraries are Kivy and KivyMD, with minimum required versions: Kivy 2.2.0 and KivyMD 1.2.0.
[2] It depends on the Python language, with a minimum required Python version of 3.7.9.
4. How to Install Easyapp_don?
First, ensure you have installed Python with a version of 3.7.9 or higher. If not, download Python from the website below.
https://www.python.org/
(1) On Windows PCs:
[1] Press Win+R on your keyboard to open the Run dialog box, type "cmd", and open Command Prompt;
[2] In Command Prompt, enter the command "pip install easyapp_don" to install the Easyapp_don library;
[3] If the download speed is extremely slow or the download fails, enter the following command:
pip install easyapp_don -i https://mirrors.tuna.tsinghua.edu.cn/
(2) On Mobile Phones:
[1] If you have a Python IDE or other compiler, open it;
[2] Tap {My}, then tap {Install Module}, enter the library name: "easyapp_don", and install it. Alternatively, open its Python console and enter the following content:
pip install easyapp_don
[3] If the download speed is extremely slow or the download fails, enter the following content:
pip install easyapp_don -i https://mirrors.tuna.tsinghua.edu.cn/
5. What Functions Does Easyapp_don Have?
[1] It supports app creation. Similar to the EasyGUI library, it enables simple app and GUI interaction interface creation.
[2] It allows image uploads. As long as the image is in the same directory as the code file, it can be displayed in the app.
[3] It can create tools such as questionnaires or answer sheets, reducing code volume by 99%.
6. What is the Basic Information of Easyapp_don?
[1] Version Number: 0.2.3
[2] Author: LvYanHua
[3] Publisher: Individual
[4] Website: EasyApp_english_version.html
-------------------- Part 2: Usage of Easyapp_don --------------------
7. What App-related Functions Does Easyapp_don Provide?
[1] The msg() function: Displays a window with text, a title, and OK/Cancel buttons. A prompt box will pop up automatically when the window is closed;
[2] The esmsg() function: Displays multiple lines of text and inherits other functionalities from the msg() function;
[3] The fillmsg() function: Inherits from the esmsg() function and adds selection boxes, enabling functions for answer sheets and questionnaires;
[4] The btn() function: Inherits from the msg() function and replaces the original OK/Cancel buttons with a customizable button list for more flexible button settings;
[5] The esbtn() function: Inherits from the esmsg() function, replaces the original OK/Cancel buttons with a button list, and supports multiple lines of text;
[6] The fillbtn() function: Inherits from the fillmsg() function, replaces the original OK/Cancel buttons with a button list, and includes text and selection buttons;
[7] The ent() function: Inherits from the msg() function and adds an input box to capture user input;
[8] The esent() function: Inherits from both the esmsg() and ent() functions, combining their advantages to support multiple lines of text and multiple input boxes;
[9] The fillent() function: Inherits from both the fillmsg() and esent() functions. Based on multiple lines of text and input boxes, it adds a list of selection buttons, suitable for all types of answer sheets (though image upload is not supported);
[10] The img() function: Inherits from the msg() function and adds image support, which can be set as a background image;
[11] The fill_img() function: Inherits from both the img() and fillmsg() functions. Based on image support, it adds selection buttons, fully implementing the answer sheet function and providing return values;
[12] The btn_img() function: Inherits from both the img() and btn() functions. Based on image support, it adds image buttons for customizable button styles;
[13] The fill_btn_img() function: Inherits from both the fill_img() and btn_img() functions, combining their components. It supports both image buttons and image-based selection buttons (clicking an image switches it to another image, and clicking again switches it back), and provides return values;
[14] The page() function: Integrates all the functionalities of the aforementioned functions but only displays a single page;
[15] The pages() function: Note that it is different from the page() function and has distinct functionalities. It can create multi-page apps but does not support image uploads, making it convenient for users without image materials;
[16] The img_pages() function: Built on the pages() function and adds image material support. It is the most powerful function in the Easyapp_don library with relatively complex syntax, but it still reduces code volume by 80%.
8. What Parameters Do These Functions of Easyapp_don Have?
[1] msg():
(1) t: Abbreviation for "text". This is the text information displayed in the app page, in the form of a list: [page text content (does not need to be a string, as we will automatically convert it to a string), text center position]. The text center position is a tuple or list consisting of 2 numbers (ranging from 0 to 1), representing the proportion within the parent container. The position can be omitted, and the default is the center of the page (0.5, 0.5);
(2) tie: Abbreviation for "title". On Windows PCs, this will be displayed as the window title, but not on mobile phones, so it can sometimes be omitted. It supports any data type and will be automatically converted to a string;
(3) color: Abbreviation for "background_color". It is the background color in the form of an RGBA tuple with 4 elements. You need to import Easyapp_don (i.e., enter "import easyapp_don" in the Python file) to use its color tools. Colors are represented by uppercase letters of color names (e.g., RED8 for red, BLUE1 for blue), where the number after the color name indicates the shade (larger numbers mean darker shades). Supported colors include: RED, GREEN, BLUE, YELLOW, ORANGE, INDIGO, PURPLE, BLACK, WHITE, GREY, PINK, BROWN, CYAN, SILVER, GOLD, etc.;
(4) theme: This sets the page theme, with two options: light and dark. You need to import Easyapp_don (i.e., enter "import easyapp_don" in the Python file) to use its theme tools. The light theme is represented by the variable LIGHT, and the dark theme by DARK. Note that themes do not change the screen brightness but only the text color: text is black in light theme and white in dark theme;
(5) ok: This configures the OK button of the page, in the form of a list: [button text, button color (using the color module), button size, button position, whether to close the current page after clicking the button]. The last element (closing the page after clicking) is a boolean value, with a default of True. It is recommended to keep it as True, as setting it to False will result in no response when the button is clicked. You can simplify the parameter to ["button text"] to save time. If you do not want to use the OK button, set it to an empty list [];
(6) cal: Abbreviation for "cancel". It has the same configuration as the ok parameter, so detailed explanation is omitted here;
(7) tip: This is a dictionary of parameters for the prompt box that pops up after closing the page. If you do not want the prompt box to pop up, set it to an empty dictionary {}. All secondary parameters have default values and can be modified as needed. The secondary parameters are as follows:
((1)). "txt": Abbreviation for "text". It is the text of the prompt box, supporting any data type (the program will automatically convert it to a string);
((2)). "tie": Abbreviation for "title". It is the title of the prompt box, supporting any data type (the program will automatically convert it to a string);
((3)). "ok": The OK button of the prompt box, in the form of a list [button text, button color]. It can be simplified to [button text], with a default text of "Yes";
((4)). "cal": Abbreviation for "cancel". It has the same configuration as the ok parameter, with a default text of "No";
(8) Return Value: Returns True when the OK button is clicked, False when the Cancel button is clicked, and None when the page is closed with tip={}.
[2] esmsg():
(1) ts: Abbreviation for "texts". It is a 2D list for multiple lines of text, in the format: [["Text 1", text position tuple], ["Text 2", text position tuple], ..., ["Text n", text position tuple]]. The default text position tuple is (0.5, 0.5), but it is not recommended to simplify this parameter, otherwise the texts will overlap;
(2) Others (including return value): Same as the msg() function.
[3] fillmsg():
(1) fs: Abbreviation for "fill_buttons". It is a 2D list for answer sheet functions, in the format: [["Selection button text", selection button color, color after clicking, size, position], [...], ...]. It can collect user information and is suitable for scenarios such as questionnaires and answer sheets (e.g., selecting options A, B, C, D). After selecting an option and clicking OK or Cancel, it will record the selection. All parameters have default values and can be simplified, but simplification is not recommended to avoid button overlap;
(2) Others (excluding return value): Same as the msg() function.
(3) Return Value: A list in the format: [boolean or None (refer to the return value of msg()), [list of indices of selected fill buttons]]. For example, if you set three options A, B, C, and the user selects B and clicks OK, it will return [True, [1]] (where 1 is the index of option B in the fs list). This design allows repeated setting of options A, B, C and is more accurate than capturing text.
[4] btn():
(1) bs: Abbreviation for "buttons". It is a 2D list for storing buttons. Clicking a button closes the current page and returns the index of the clicked button. The format is: [["Button text", button color, button size, button position], ..., [...]]. It can be simplified, but simplification is not recommended to avoid button overlap;
(2) Others (excluding return value): Same as mentioned earlier;
(3) Return Value: The index of the clicked button.
[5] esbtn():
Parameters: Same as mentioned earlier. Return Value: Same as the btn() function.
[6] fillbtn():
Parameters: Same as mentioned earlier. Return Value: A list in the format: [index of the clicked button, [list of indices of selected fill buttons]].
[7] ent():
(1) e: Abbreviation for "enter". It represents an input box (only one input box is supported), in the format: [input box prompt text, input box size, input box position]. It is suitable for scenarios such as content input and essay answering;
(2) Other parameters: Same as mentioned earlier.
(3) Return Value: A list in the format: [boolean or None, user input string]. The boolean value is True when the user clicks OK, False when the user clicks Cancel, and None when the page is closed with tip={}.
[8] esent():
Parameters: Same as mentioned earlier. Return Value: Similar to the ent() function, in the format: [boolean or None, [list of user input contents]].
Special Parameter: es: An extended version of the "e" parameter. Based on the original "e" parameter, it is a 2D list in the format: [[input box prompt text, input box size, input box position], ..., [...]].
[9] fillent():
(1) Parameters: Same as mentioned earlier;
(2) Return Value: A list in the format: [boolean or None, [list of user input contents], [list of indices of selected fill buttons]].
[10] img():
(1) i: Abbreviation for "images". Used to create multiple images, located at the bottom layer of the page, which can be used as background images. Format: [[image path (relative path recommended), image size, image position, image transparency], ..., [...]]. Images cannot be used as buttons;
(2) Other parameters: Same as mentioned earlier;
(3) Return Value: Same as msg().
[11] fill_img():
(1) Parameters: Same as mentioned earlier;
(2) Return Value: Same as fillmsg().
[12] btn_msg():
(1) bi: Abbreviation for "button_images". Used to create image buttons, which exit the current page and return their index when clicked. Format: [["image path", image size tuple, image position tuple, image transparency], ..., [...]]. It is recommended to use local paths and relative paths for image paths;
(2) Other parameters: Same as mentioned earlier;
(3) Return Value: Returns True when OK is clicked, False when Cancel is clicked, returns its index when clicking bi images, and returns None when the user closes with tip={}.
[13] fill_btn_img():
(1) fi: Abbreviation for "fill_images_buttons". Based on fs, it converts color changes into image changes. Format: [[image path, image path after clicking, image size, image position]], making fs more flexible for user needs;
(2) Other parameters: Same as mentioned earlier;
(3) Return Value: A list in the format: [boolean or None, [list of indices of selected buttons in fs], [list of indices of selected buttons in fi]].
[14] page():
(1) Parameters: Same as mentioned earlier;
(2) Return Value: [index of clicked button list, [list of user input contents], [list of indices of selected fs fill buttons], [list of indices of selected fi fill buttons]];
(3) Special Note: The parameters include indices of bs and bi. The program places bi indices after bs indices. The index of the clicked button in the return value is the index of bs or bi. For example: when there are 3 bs with indices 0, 1, 2, the first index of bi becomes 3.
[15] pages():
(1) ps: Abbreviation for "pages". It is a dictionary that stores multiple pages but has no images, suitable for users without image materials. For examples, please see the dictionary p_mode in easyapp_don.supermarket.tools.Checker. For detailed information, please refer to pages().
[16] img_pages():
(1) ps: Abbreviation for "images_pages". It is a dictionary that stores multiple pages with images, suitable for users with image materials. Users without image materials don't need to worry - just copy the easyapp_don.images folder to the same directory as your code, and you can use the image materials inside. For examples, please see the dictionary i_mode in easyapp_don.supermarket.tools.Checker. For detailed information, please refer to img_pages().
-------------------- Part 3: Notes for Easyapp_don --------------------
9. What are the Common Problems and Solutions for Easyapp_don?
[1] UserWarning: This is the most common warning in easyapp_don. Possible issues are as follows:
(1) You entered the wrong parameter type when filling in parameters. For example, you entered a string instead of a list. A warning will be displayed but no error will occur, and system default values will be used. You need to correct it;
(2) The size and position you wrote are not tuples with 2 data points, or the color you used is not from our color library;
(3) When filling in two-dimensional list parameters such as buttons, the parameters in the list are incomplete. For example, the correct format should be ["Button1", RED8, (0.1,0.1), (0.5,0.5)], but you wrote ["Button1"] or other incorrect formats;
[2] Components in the app page are not displayed or buttons and images abnormally fill the entire screen: This is due to incorrect size and position settings. Explanation:
Kivy's position and size are based on the proportion of the parent container, where the center is (0.5, 0.5) and the maximum is 1. If it exceeds 1, it will go out of the visible range, so the above situation will occur. Change the size and position to decimals between 0 and 1.
[3] The image is clearly uploaded but not displayed in the app:
There should be a prompt on the terminal in the Windows system: [ERROR] Not found "image path". This is because the image path you entered is incorrect or there is no image. Check if the spelling is correct. This error does not come from easyapp_don but from kivy. You need to follow kivy's image upload rules.
[4] Others:
My email address is at034000@qq.com. Email me to consult, but do not ask me during the school semester. I may not reply to you for 2 weeks. It's best to ask during vacation.
-------------------- Part 4: About Us, Easyapp_don 0.2.3 --------------------
10. What is the Background of the Easyapp_don Library?
On August 15, 2025, developer LvYanHua developed this library during summer vacation, finding Kivy and KivyMD syntax too difficult and cumbersome, so simplified the code to make the library more versatile and practical, and freely available to the public. LvYanHua developed this library for two reasons: first, to expand the scope of EasyGUI, a third-party library limited to computers that doesn't work well on mobile phones and lacks features like returning to previous pages; second, to provide AI-generated images as materials for users.
11. What is the Original Intention of Easyapp_don?
To enable app developers to avoid frequent code handling, save time, speed up development, reduce development costs, solve the problem of excessive code in Kivy and KivyMD, make development more convenient for developers, greatly reduce app development difficulty and thresholds, and allow developers to create personalized web pages without tedious work!
12. What Improvements Does Easyapp_don 0.2.3 Have Over 0.2.2?
Fixed minor issues with images and reduced the required Kivy version to 2.2.0 for better mobile compatibility.
13. What is the Improvement Direction of Easyapp_don?
[1] Currently, the latest version of our easyapp_don is 0.2.3. Future versions will include 0.2.4, 0.2.5, 0.2.6, 0.2.7, 0.2.8, 0.2.9, 0.3.0, 0.3.1, 0.3.2, etc. Within version 0.2, different versions have different mobile compatibility. The initial version 0.2.1 has good computer compatibility, while this version has better mobile compatibility. Future versions will enhance mobile compatibility. Version 0.2.3 also has good mobile compatibility and is suitable for mobile users, but it has the disadvantage of not displaying prompts and warnings;
[2] Version 0.2.3 does not have scrollbar settings, meaning that when text exceeds the window, scrollbars cannot be set. This feature will be added in future versions;
[3] Version 0.2.3 cannot handle videos and music because the ffmpeg version for audio parsing is too old. Future updates will include images and music. Currently, network images cannot be uploaded, which will be improved in future versions;
[4] For other improvement directions, please contact me at at034000@qq.com, but do not contact me during the school semester or winter vacation as I am busy. Please contact me during summer vacation!
14. What are the Advantages of Easyapp_don?
[1] Reduces code volume and saves time on repetitive work;
[2] Lowers app development thresholds, suitable for beginners, and transforms app components into familiar forms like lists and dictionaries;
[3] High flexibility, suitable for 99% of needs. For example, writing an electronic novel using the pages() function saves code volume; it can also perfectly handle electronic answer sheets and create personalized images;
[4] Easy to use, no other dependencies except Kivy and KivyMD, which are automatically installed during installation.
15. What is the Core Concept of Easyapp_don?
Reduce code volume, lower app development thresholds, reduce costs and increase efficiency.
16. What is the Developer Information of Easyapp_don?
[1] Nationality: Mainland China;
[2] Biological species: Human;
[3] Job position: Middle school student;
[4] Location: Observable Universe - Milky Way - Solar System - Earth-Moon System - Earth - Biosphere;
[5] Programming field: Hobby;
[6] Other information: Next summer vacation, contact me through the email at034000@qq.com!
17. Acknowledgements
Thank you to my users, my parents, my teachers, and every friend who uses easyapp_don. Please remember to leave a good review and follow!
-------------------- Part 5: Easyapp_don Privacy Policy --------------------
I. Statement and Scope of Application
18. This agreement aims to explain the usage, operation, and processing rules of the easyapp_don library (hereinafter referred to as "this library") and protect the right to know of developers and end users who use this library.
19. This agreement applies to all developers who integrate and use this library, as well as end users who use related functions through applications that integrate this library (hereinafter referred to as "sub-applications").
20. This library only provides technical support as a functional component and does not independently collect, store, or transmit any user data. Related data processing behaviors are executed by sub-applications in accordance with their own privacy policies.
II. Data Processing and Usage Rules
21. No Active Data Collection: This library itself does not actively collect, store, upload data or any personal information of users (including but not limited to name, phone number, device identifier, location information, etc.), nor does it require sub-applications to provide such information. If data theft is discovered, it is caused by the sub-application and has nothing to do with this library.
22. Data Processing: To implement image data processing functions, this library places image materials in a directory under easyapp_don named "images". This folder does not involve any user personal information and mostly contains image materials. These images must not be used for profit-making purposes.
23. No Data Sharing: This library will not share any processed data with third parties, nor will it transmit data to any server.
III. Data Security Assurance
24. This library only runs locally on the user's device. All data processing is performed on the device side, and images can only be uploaded locally, without involving network transmission, reducing the risk of data leakage.
25. It is recommended that developers integrating this library strengthen data security protection for their sub-applications, comply with relevant laws and regulations, and properly handle user data.
IV. Third-Party Service Description
This library does not integrate any third-party SDKs, statistical tools, or services, and there are no third-party data processing behaviors.
V. User Rights and Developer Responsibilities
26. User Rights: If end users have questions about data processing, they can refer to the sub-application's privacy policy or contact the sub-application developer directly.
27. Developer Responsibilities: Developers integrating this library should clearly state in their privacy policies that they have used this library and clearly inform end users of data processing rules to ensure compliance with relevant laws and regulations.
VI. Agreement Update and Effectiveness
28. This agreement shall take effect from the date of release. If subsequent adjustments to the library's functions result in changes to data processing rules, it will be announced through official update channels of this library (such as official website, version update logs), and the updated agreement shall take effect from the date of update.
29. Continuing to use this library shall be deemed as agreeing to this agreement and subsequent updates.
VII. Contact Us
If you have any questions about this agreement, contact us through the following method:
at034000@qq.com
VIII. Others
The final interpretation right of this library belongs to LvYanHua.