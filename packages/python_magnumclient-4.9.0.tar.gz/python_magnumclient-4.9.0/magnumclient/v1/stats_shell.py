#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

from magnumclient.common import cliutils as utils
from magnumclient.i18n import _


@utils.arg('--project-id',
           required=False,
           metavar='<project-id>',
           help=_('Project ID'))
@utils.deprecated(utils.MAGNUM_CLIENT_DEPRECATION_WARNING)
def do_stats_list(cs, args):
    """Show stats for the given project_id"""
    opts = {
        'project_id': args.project_id
    }

    stats = cs.stats.list(**opts)
    utils.print_dict(stats._info)
