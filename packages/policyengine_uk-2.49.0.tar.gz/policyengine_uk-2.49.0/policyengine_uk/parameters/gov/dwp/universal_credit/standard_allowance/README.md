# Standard allowance
