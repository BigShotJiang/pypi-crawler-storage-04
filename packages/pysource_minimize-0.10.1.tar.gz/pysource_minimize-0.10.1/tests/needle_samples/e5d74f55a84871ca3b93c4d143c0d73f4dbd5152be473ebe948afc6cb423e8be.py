for needle_17597 in name_5:
    pass