try:
    pass
except* (name_3 for name_5 in name_0 if name_0):
    needle_17597