for name_4 in needle_17597:
    pass