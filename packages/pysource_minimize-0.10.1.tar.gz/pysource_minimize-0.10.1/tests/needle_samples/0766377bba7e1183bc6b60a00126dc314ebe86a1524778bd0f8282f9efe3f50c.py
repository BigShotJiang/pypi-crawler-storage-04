def name_3() -> needle_17597:
    pass