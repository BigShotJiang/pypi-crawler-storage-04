

async def name_3():
    (yield needle_17597)
