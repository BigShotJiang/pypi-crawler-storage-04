for name_2 in 0:
    needle_17597