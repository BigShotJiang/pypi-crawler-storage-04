while something:
    needle_17597