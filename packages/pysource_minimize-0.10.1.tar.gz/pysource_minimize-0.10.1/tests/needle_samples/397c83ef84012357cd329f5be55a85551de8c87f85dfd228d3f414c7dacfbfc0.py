async def name_0(*, name_2=needle_17597):
    pass