with name_0 as needle_17597:
    pass