class name_0(needle_17597):
    pass