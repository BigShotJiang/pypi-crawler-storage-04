
(name_3, needle_17597)
