class name_3[name_5: needle_17597]:
    pass