

def name_4():
    (yield from needle_17597)
