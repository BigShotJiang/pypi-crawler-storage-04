

async def name_3():
    (await name_4)
