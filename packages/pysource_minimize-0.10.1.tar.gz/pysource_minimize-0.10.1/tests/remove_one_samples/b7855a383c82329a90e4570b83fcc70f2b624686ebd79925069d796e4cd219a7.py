
(name_1 < name_2 > name_2)
