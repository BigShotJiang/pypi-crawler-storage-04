def name_2(name_5=f'{name_1!s}'):
    pass