if name_1:
    pass