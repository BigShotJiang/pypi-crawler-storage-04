
[(lambda name_2=name_5, *, name_4=name_2, **name_1: name_0)]
