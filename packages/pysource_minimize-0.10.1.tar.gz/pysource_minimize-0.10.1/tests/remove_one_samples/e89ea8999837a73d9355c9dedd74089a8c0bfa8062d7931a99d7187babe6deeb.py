
[name_4 for name_4 in name_0]
