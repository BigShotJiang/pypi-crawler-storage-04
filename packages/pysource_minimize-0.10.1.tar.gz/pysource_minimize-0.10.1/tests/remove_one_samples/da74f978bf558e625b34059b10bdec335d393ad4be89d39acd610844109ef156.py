try:
    pass
except name_4 as name_4:
    pass
else:
    pass
finally:
    pass