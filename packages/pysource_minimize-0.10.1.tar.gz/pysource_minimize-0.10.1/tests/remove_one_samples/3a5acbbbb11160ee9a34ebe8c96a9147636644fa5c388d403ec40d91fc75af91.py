
(name_3 if name_1 else name_1)
