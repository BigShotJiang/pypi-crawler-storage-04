
(+ 'some const text')
