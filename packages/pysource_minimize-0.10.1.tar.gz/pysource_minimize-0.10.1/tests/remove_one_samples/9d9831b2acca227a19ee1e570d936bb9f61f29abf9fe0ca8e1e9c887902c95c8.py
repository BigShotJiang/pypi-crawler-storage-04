match name_0:
    case name_0(-0.1, name_5=name_5.name_3, name_0=b''):
        pass