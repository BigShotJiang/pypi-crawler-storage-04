match {}:
    case True as name_2:
        pass
    case 7 | b'':
        pass