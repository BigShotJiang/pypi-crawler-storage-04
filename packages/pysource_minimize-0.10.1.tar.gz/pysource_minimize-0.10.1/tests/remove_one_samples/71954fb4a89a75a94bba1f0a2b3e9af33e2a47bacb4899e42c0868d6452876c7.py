try:
    pass
except:
    pass
else:
    pass
finally:
    pass