
(name_4 for name_1 in name_2)
