
f'{None:{False!s}}'
