
{name_3: name_4 for name_0 in name_2}
