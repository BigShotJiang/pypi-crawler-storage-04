
(name_4 if name_2 else name_3)
