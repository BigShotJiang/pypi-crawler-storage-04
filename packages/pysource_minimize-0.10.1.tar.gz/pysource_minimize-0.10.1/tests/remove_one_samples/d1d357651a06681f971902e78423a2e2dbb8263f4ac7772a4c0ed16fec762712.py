
(name_3 * name_1)
