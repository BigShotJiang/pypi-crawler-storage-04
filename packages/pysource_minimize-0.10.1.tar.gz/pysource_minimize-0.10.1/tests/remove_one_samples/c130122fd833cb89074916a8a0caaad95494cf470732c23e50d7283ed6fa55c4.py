async def name_0(): # type: ignoresome text
    async for name_0 in name_5: # type: ignoresome text
        pass
    else:
        pass