def name_1(*, name_3={name_2: name_0 for name_2 in name_1}):
    pass