
(lambda name_3=name_4, name_4=name_3, name_0=name_5, name_5=name_5, *, name_1=name_1, **name_2: (name_0,))
