match name_4:
    case name_2(name_4=name_3.name_3):
        pass