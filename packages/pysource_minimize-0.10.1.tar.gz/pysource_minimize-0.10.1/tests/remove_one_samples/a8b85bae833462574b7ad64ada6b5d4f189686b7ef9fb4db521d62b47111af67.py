with name_0 as (name_2, name_4, name_0, name_4, name_0): # type: ignore
    pass