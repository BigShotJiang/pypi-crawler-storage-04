
(lambda name_2=name_3, *name_5, name_1=name_4, **name_0: name_5)
