def name_0() -> lambda: name_4:
    pass