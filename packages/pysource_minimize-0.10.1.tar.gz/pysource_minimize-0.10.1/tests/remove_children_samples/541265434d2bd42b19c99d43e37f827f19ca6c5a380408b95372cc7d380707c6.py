while f'':
    pass
else:
    pass