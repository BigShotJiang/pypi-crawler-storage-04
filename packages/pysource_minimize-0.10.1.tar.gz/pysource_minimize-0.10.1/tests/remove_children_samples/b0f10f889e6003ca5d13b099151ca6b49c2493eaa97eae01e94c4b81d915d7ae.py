match name_5:
    case [0, '']:
        pass