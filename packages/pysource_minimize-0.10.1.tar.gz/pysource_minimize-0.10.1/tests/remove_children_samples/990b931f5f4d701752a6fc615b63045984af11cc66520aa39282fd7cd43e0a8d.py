match name_1:
    case None:
        pass