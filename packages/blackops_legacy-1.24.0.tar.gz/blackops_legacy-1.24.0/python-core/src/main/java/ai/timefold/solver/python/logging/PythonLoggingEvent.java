package ai.timefold.solver.python.logging;

public record PythonLoggingEvent(PythonLogLevel level, String message) {
}
