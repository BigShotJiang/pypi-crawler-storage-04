"""pytest-delta: Run only tests impacted by your code changes."""

__all__ = ["__version__"]
__version__ = "0.1.1"
