# 将源文件复制到包中
import shutil
import os
from pathlib import Path

def copy_ai_assistant():
    # 此函数已不再需要，因为我们直接使用rule.py
    print("注意：此函数已不再需要，现在直接使用rule.py作为规则文件")
    return True

if __name__ == "__main__":
    copy_ai_assistant()
