from .paths import router


__all__ = [
    "router",
]
