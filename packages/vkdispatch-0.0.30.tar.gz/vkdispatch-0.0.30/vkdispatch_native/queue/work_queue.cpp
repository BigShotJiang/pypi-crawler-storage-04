#include <chrono>
#include <cstring>

#include "work_queue.hh"
#include "../objects/command_list.hh"
#include "../objects/objects_extern.hh"


static size_t __work_id = 0;

WorkQueue::WorkQueue(int max_work_items, int max_programs) {
    work_infos = new WorkInfo[max_work_items];
    program_infos = new ProgramInfo[max_programs];
    work_info_count = max_work_items;
    program_info_count = max_programs;
    running = true;

    for(int i = 0; i < max_work_items; i++) {
        work_infos[i].dirty = false;
        work_infos[i].header = (struct WorkHeader*)malloc(sizeof(struct WorkHeader) + 16 * 1024);
        memset(work_infos[i].header, 0, sizeof(struct WorkHeader) + 16 * 1024);
        work_infos[i].header->array_size = 16 * 1024;
        work_infos[i].header->info_index = i;
    }

    for(int i = 0; i < max_programs; i++) {
        program_infos[i].ref_count = 0;
        program_infos[i].commands = std::make_shared<std::vector<struct CommandInfo>>();
        program_infos[i].program_id = 0;
    }
}

void WorkQueue::stop() {
    std::unique_lock<std::mutex> lock(this->mutex);
    this->running = false;
    this->cv_push.notify_all();
}

void WorkQueue::push(struct CommandList* command_list, void* instance_buffer, unsigned int instance_count, int queue_index, int record_type) {
    std::unique_lock<std::mutex> lock(this->mutex);
    
    auto start = std::chrono::high_resolution_clock::now();

    int found_indicies[2] = {-1, -1};

    this->cv_pop.wait(lock, [this, start, command_list, &found_indicies] () {
        if(!running) {
            return true;
        }

        auto end = std::chrono::high_resolution_clock::now();
        std::chrono::duration<double> elapsed = end - start;
        
        if(elapsed.count() > 500) {
            set_error("Timed out waiting for room in queue");
            return true;
        }

        int program_index = -1;

        for(int i = 0; i < this->program_info_count; i++) {
            if(this->program_infos[i].ref_count < 0) {
                set_error("Program reference count (%d) is negative!!!!", this->program_infos[i].ref_count);
                return true;
            }

            if(this->program_infos[i].program_id == command_list->program_id) {
                program_index = i;
                break;
            }

            if(this->program_infos[i].ref_count == 0) {
                program_index = i;
            }
        }

        if(program_index == -1) {
            return false;
        }

        int work_index = -1;

        for(int i = 0; i < this->work_info_count; i++) {
            if(!this->work_infos[i].dirty) {
                work_index = i;
                break;
            }
        }

        if(work_index == -1) {
            return false;
        }

        found_indicies[0] = program_index;
        found_indicies[1] = work_index;

        return true;
    });

    if(!running) {
        return;
    }

    RETURN_ON_ERROR(;)

    auto end = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> elapsed = end - start;

    if(elapsed.count() >= 5) {
        return;
    }

    work_infos[found_indicies[1]].program_index = found_indicies[0];
    work_infos[found_indicies[1]].queue_index = queue_index;
    work_infos[found_indicies[1]].dirty = true;
    work_infos[found_indicies[1]].state = WORK_STATE_PENDING;
    work_infos[found_indicies[1]].work_id = __work_id;
    __work_id += 1;

    struct WorkHeader* work_header = this->work_infos[found_indicies[1]].header;

    if(this->program_infos[found_indicies[0]].program_id != command_list->program_id) {
        if(this->program_infos[found_indicies[0]].ref_count != 0) {
            set_error("Program ID mismatch!!");
            return;
        }

        this->program_infos[found_indicies[0]].commands->clear();
        for(CommandInfo command : command_list->commands) {
            this->program_infos[found_indicies[0]].commands->push_back(command);
        }

        this->program_infos[found_indicies[0]].program_id = command_list->program_id;
    }

    size_t work_size = command_list_get_instance_size_extern(command_list) * instance_count;

    if(work_size > work_header->array_size) {
        work_header = (struct WorkHeader*)realloc(work_header, sizeof(struct WorkHeader) + work_size);
        work_header->array_size = work_size;
        work_header->info_index = found_indicies[1];
        this->work_infos[found_indicies[1]].header = work_header;
    }

    work_header->instance_count = instance_count;
    work_header->instance_size = command_list_get_instance_size_extern(command_list);
    work_header->commands = this->program_infos[found_indicies[0]].commands;
    work_header->program_info_index = found_indicies[0];
    work_header->record_type = (RecordType)record_type; 
    
    if(work_size > 0)
        memcpy(&work_header[1], instance_buffer, work_size);
    
    this->program_infos[found_indicies[0]].ref_count += 1;

    this->cv_push.notify_all();
}

bool WorkQueue::pop(struct WorkHeader** header, int queue_index) {
    std::unique_lock<std::mutex> lock(this->mutex);

    LOG_VERBOSE("Waiting for work item for queue %d", queue_index);

    this->cv_push.wait(lock, [this, queue_index, header] () {
        LOG_VERBOSE("IN CV: running = %d, work_info_count = %d, program_info_count = %d", running, work_info_count, program_info_count);
        if(!running) {
            return true;
        }

        int selected_index = -1;
        size_t work_id = ~((size_t)0);

        for(int i = 0; i < this->work_info_count; i++) {
            if(this->work_infos[i].dirty &&
               this->work_infos[i].state == WORK_STATE_PENDING &&
               this->work_infos[i].work_id < work_id &&
               (this->work_infos[i].queue_index == queue_index ||
                this->work_infos[i].queue_index == -1))
            {
                work_id = this->work_infos[i].work_id;
                selected_index = i;
            }
        }

        LOG_VERBOSE("Selected index: %d", selected_index);

        if(selected_index == -1) {
            return false;
        }

        *header = this->work_infos[selected_index].header;
        this->work_infos[selected_index].state = WORK_STATE_ACTIVE;

        LOG_VERBOSE("Returning work header %p for queue %d", *header, queue_index);

        return true;
    });

    return running;
}

void WorkQueue::finish(struct WorkHeader* header) {
    std::unique_lock<std::mutex> lock(this->mutex);
    program_infos[header->program_info_index].ref_count -= 1;
    work_infos[header->info_index].dirty = false;
    this->cv_pop.notify_all();
}