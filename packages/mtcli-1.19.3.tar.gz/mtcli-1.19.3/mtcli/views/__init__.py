"""Módulos da View do mtcli."""
