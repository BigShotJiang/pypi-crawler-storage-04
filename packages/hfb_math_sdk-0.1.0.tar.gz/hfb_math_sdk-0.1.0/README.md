# Math SDK

一个简单的数学运算SDK，提供基本的数学运算功能。

## 功能

- 加法运算
- 减法运算
- 乘法运算
- 除法运算
- 幂运算

## 安装

```bash
pip install math_sdk