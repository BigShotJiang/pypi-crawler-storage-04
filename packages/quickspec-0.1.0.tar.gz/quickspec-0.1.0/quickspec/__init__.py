# quickspec 套件初始化檔案
