# VideoSDK Navana Plugin

Agent Framework plugin for STT services from Navana Tech.

## Installation

```bash
pip install videosdk-plugins-navana
```