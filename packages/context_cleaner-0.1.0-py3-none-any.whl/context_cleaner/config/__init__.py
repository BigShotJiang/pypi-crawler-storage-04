"""Configuration management for Context Cleaner."""

from .settings import ContextCleanerConfig

__all__ = ["ContextCleanerConfig"]