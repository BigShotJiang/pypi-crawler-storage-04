"""Visualization and dashboard functionality."""

from .basic_dashboard import BasicDashboard

__all__ = ["BasicDashboard"]