"""Command-line interface for Context Cleaner."""

from .main import main

__all__ = ["main"]