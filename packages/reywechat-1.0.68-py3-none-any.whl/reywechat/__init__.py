# !/usr/bin/env python
# -*- coding: utf-8 -*-

"""
@Time    : 2023-10-17 20:24:04
@Author  : Rey
@Contact : reyxbo@163.com
@Explain : WeChat method set.

Folders
-------
data : Data file.

Modules
-------
rall : All methods.
rbase : Base methods.
rclient : Client methods.
rdb : Database methods.
rcache : Cache methods.
rlog : Log methods.
rreceive : Receive methods.
rsend : Send methods.
rtrigger : Trigger methods.
rwechat : WeChat methods.
"""
