class State:
    """A class to annotate state parameters in task functions"""

    def __init__(self, key: str):
        self.key = key
