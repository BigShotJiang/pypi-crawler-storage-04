# mcp_kinetica/__init__.py
__version__ = "7.2.3.1"

