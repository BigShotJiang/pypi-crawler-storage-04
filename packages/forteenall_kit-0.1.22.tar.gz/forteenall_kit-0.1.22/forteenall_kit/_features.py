# This file is auto-generated. Do not edit manually.
# For upadte this file pls run 'bash update.sh' on main forteenall project

# Invokers import
from forteenall_kit.invokers.djangoModel import Feature as Feature_djangoModel
from forteenall_kit.invokers.spaceDup import Feature as Feature_spaceDup

features = {
    'djangoModel': Feature_djangoModel,
    'spaceDup': Feature_spaceDup,
}

