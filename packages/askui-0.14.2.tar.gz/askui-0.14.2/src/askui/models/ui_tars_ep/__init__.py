"""UI TARS model implementations."""
