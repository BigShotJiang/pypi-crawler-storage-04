# DataTensor v0.2

**DataTensor** 

## Fitur
- `DataFrameLite`: manipulasi data 
- `SeriesLite`: kolom tunggal seperti
- `DataTensor`: tensor dengan autograd sederhana
- Layers & Optimizers: `LinearLite`, `ReLU`, `SGD Lite`

## Instalasi
```bash
pip install datatensor
