"""Datareader package for finquotes."""
