"""
Beque - Asynchronous In-Memory Batch Queue Processor
"""

from .beque import Beque

__version__ = "0.1.0"
__all__ = ["Beque"]
