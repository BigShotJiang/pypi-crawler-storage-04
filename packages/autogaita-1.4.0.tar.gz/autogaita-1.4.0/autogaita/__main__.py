# This script makes it so you can run "python -m autogaita" and get the main gui

from .gui.main_gui import run_gui

if __name__ == "__main__":
    run_gui()
