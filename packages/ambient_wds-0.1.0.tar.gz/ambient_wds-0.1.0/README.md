# Ambient WDS (Weather Data Shipper)
*A tool to query data from Ambient Weather's API, convert it, and upload it to APRS.fi*
<img src="images/ambient-wds-logo.png" alt="ambient-wds-logo" width="50%">



## Parameters

This tool supports configuration from four sources, checked in the following priority order:

1. **Command-line options** — Passed with `--kebab-case` flags (e.g., `--app-key my_app_key`).  
2. **Environment variables** — Uppercase snake case (e.g., `APP_KEY=my_app_key`).  
3. **YAML config file (`config.yaml`)** — Keys in uppercase snake case (e.g., `APP_KEY: my_app_key`).  
4. **Default value** (see table)

If a parameter is provided in multiple places, the command-line option will override the environment variable, which will override the YAML config file.  

| Parameter       | CLI Option        | Environment Variable | YAML Config Key | Default Value    | Description                                                    |
|-----------------|-------------------|----------------------|-----------------|------------------|----------------------------------------------------------------|
| API_KEY         | `--api-key`       | `API_KEY`            | `API_KEY`       |                  | Your API key for accessing Ambient Weather's API.              |
| APP_KEY         | `--app-key`       | `APP_KEY`            | `APP_KEY`       |                  | Your application key for accessing Ambient Weather's API.      |
| APRS_PASSCODE   | `--aprs-passcode` | `APRS_PASSCODE`      | `APRS_PASSCODE` |                  | The APRS passcode for your callsign.                           |
| APRS_SERVER     | `--aprs-server`   | `APRS_SERVER`        | `APRS_SERVER`   | `noam.aprs2.net` | The APRS server to connect to (e.g., `noam.aprs2.net`).        |
| APRS_PORT       | `--aprs-port`     | `APRS_PORT`          | `APRS_PORT`     | `14580`          | The port number for the APRS server (e.g., `14580`).           |
| CALLSIGN        | `--callsign`      | `CALLSIGN`           | `CALLSIGN`      |                  | Your APRS callsign.                                            |
| SSID            | `--ssid`          | `SSID`               | `SSID`          | `13`             | The SSID (Secondary Station Identifier) for your APRS station. |
| POLL_SECONDS    | `--poll-seconds`  | `POLL_SECONDS`       | `POLL_SECONDS`  | `300`            | The interval (in seconds) for polling data from the API.       |
| CONFIG_FILE     | `--config-file`   | `CONFIG_FILE`        | N/A             | `config.yaml`    | Path to the YAML config file.                                  |

### Station Configuration
You must set a location for your station in order for this tool to work. [These instructions](https://ambientweather.com/faqs/question/view/id/2047/?srsltid=AfmBOopk7lzXCvZPrvehDkFvc7z-5se9eF-iYKxHhQnByONaAEl3K-Im) go through that process.

### Obtaining an APRS Passcode
To obtain an APRS passcode, go to https://apps.magicbug.co.uk/passcode/, and enter your callsign.

### Obtaining an App Key and API Key
To obtain your Ambient Weather App and API keys, log into your Ambient Weather account and navigate to https://ambientweather.net/account/keys. From there you can create both an API key and an APP key. They are both necessary.