"""Public module exposing the results analyzer"""

from asyncflow.metrics.analyzer import ResultsAnalyzer

__all__ = ["ResultsAnalyzer"]
