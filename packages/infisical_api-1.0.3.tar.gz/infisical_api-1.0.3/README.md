# infisical_api

## ⚠️ DEPRECATED ⚠️

**This library is deprecated in favor of the official Infisical Python SDK.**

Please migrate to the official SDK: <https://infisical.com/docs/documentation/guides/python>

The official SDK provides better performance, security, and ongoing support from the Infisical team.

---

## Legacy Documentation

infisical_api was a python client for the infisical REST API. I found some of the dependencies in the infisical_python client incompatible with some of my applications so I built this very simple version that utilizes the REST API.

### Migration Guide

Instead of using this deprecated library:

```python
from infisical_api import infisical_api

secrets = infisical_api(service_token=token,infisical_url=url) # infisical_url is only needed if using self-hosted
username = secrets.get_secret(secret_name="USERNAME", path="/MYSQL").secretValue # path defaults to "/" when not specified
```

Please use the official Infisical Python SDK as documented at: <https://infisical.com/docs/documentation/guides/python>

### Legacy Usage (Deprecated)

Get Secret

```python
from infisical_api import infisical_api

secrets = infisical_api(service_token=token,infisical_url=url) # infisical_url is only needed if using self-hosted
username = secrets.get_secret(secret_name="USERNAME", path="/MYSQL").secretValue # path defaults to "/" when not specified
```
