.. _get:

===============
mater.Mater.get
===============

.. automethod:: mater.model.Mater.get