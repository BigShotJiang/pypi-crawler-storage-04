.. _api_reference:

=============
API reference
=============

You can find here the public API references of the `mater` package.

.. toctree:: 
    :maxdepth: 1

    get
    parameter_from_json
    parameter_from_db
    parameter_from_df
    run
    run_from_excel
    set_input_dir
    set_output_dir
    set_run_name