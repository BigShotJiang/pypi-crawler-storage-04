.. _run_from_excel:

===============================
mater.Mater.run_from_excel
===============================

.. automethod:: mater.model.Mater.run_from_excel