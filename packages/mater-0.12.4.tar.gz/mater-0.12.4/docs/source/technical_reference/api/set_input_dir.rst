.. _set_input_dir:

=========================
mater.Mater.set_input_dir
=========================

.. automethod:: mater.model.Mater.set_input_dir