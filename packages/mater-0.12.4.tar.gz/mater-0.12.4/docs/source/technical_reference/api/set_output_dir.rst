.. _set_output_dir:

==========================
mater.Mater.set_output_dir
==========================

.. automethod:: mater.model.Mater.set_output_dir