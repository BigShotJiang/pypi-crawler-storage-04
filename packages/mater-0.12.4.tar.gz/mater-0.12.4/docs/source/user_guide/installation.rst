.. _user_guide_installation:

============
Installation
============

MATER can be installed via pip from `PyPI <https://pypi.org/project/mater/>`_.

.. code-block:: bash

   pip install mater