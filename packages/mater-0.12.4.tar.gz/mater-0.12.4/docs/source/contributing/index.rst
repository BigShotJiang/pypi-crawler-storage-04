.. _contributing:

============
Contributing
============

You are welcome to contribute to the mater project ! 
See the `CONTRIBUTING.md <https://gricad-gitlab.univ-grenoble-alpes.fr/isterre-dynamic-modeling/mater-project/mater/-/blob/main/CONTRIBUTING.md>`_ for the contributing guidelines of the project.

Contact
-------

If you have any question on the project please contact us : francois.verzier@univ-grenoble-alpes.fr.