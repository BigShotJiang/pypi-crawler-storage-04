"""
Schema definitions for the Mimeia AI Agent Platform.

This package contains platform-specific webhook schemas for processing
messages from various messaging platforms (WhatsApp, Telegram, Teams, Instagram).
"""
