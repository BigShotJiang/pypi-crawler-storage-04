# -*- coding: utf-8 -*-
"""
@Author: HuangJianYi
@Date: 2024-11-22 17:23:58
@LastEditTime: 2024-11-22 17:25:30
@LastEditors: HuangJianYi
@Description: 
"""
__all__ = ["prefix_info_model"]
