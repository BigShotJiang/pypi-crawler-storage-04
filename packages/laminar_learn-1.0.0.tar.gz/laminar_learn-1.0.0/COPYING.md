This is the list of copyright holders of LAMINAR.

For information on the license, see LICENSE.md.


* Christian Kleiber, 2025