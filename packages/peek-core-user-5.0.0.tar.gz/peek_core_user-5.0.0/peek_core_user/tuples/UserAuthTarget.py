class UserAuthTarget:
    INTERNAL = "INTERNAL"
    LDAP = "LDAP"
