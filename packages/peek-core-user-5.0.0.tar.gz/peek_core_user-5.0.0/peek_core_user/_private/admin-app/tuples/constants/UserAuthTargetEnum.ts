export enum UserAuthTargetEnum {
    INTERNAL = "INTERNAL",
    LDAP = "LDAP",
}
