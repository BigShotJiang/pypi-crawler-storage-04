"""Exceptions raised from the library."""
