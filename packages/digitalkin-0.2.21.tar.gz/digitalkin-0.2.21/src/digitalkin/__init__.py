"""DigitalKin SDK!

This package implements the DigitalKin agentic mesh standards.
"""

from digitalkin.__version__ import __version__

__all__ = ["__version__"]
