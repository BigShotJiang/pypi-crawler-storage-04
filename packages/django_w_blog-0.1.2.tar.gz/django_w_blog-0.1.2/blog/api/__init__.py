"""Django Blog APIs"""
