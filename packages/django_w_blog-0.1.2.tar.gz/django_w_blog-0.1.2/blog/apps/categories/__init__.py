"""Blog article categories"""
