"""Tests for blog.home"""
