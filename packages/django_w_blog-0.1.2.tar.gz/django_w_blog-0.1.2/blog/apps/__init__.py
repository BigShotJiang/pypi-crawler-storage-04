"""Django blog Apps"""
