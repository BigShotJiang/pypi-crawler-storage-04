"""blog UI"""
