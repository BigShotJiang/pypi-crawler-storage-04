class NormalDocstring:

    """This is a docstring."""


class DocstringWithComment0:
    # This is a comment
    """This is a docstring."""


class DocstringWithComment1:
    # This is a comment

    """This is a docstring."""


class DocstringWithComment2:

    # This is a comment
    """This is a docstring."""


class DocstringWithComment3:

    # This is a comment

    """This is a docstring."""


class DocstringWithComment4:


    # This is a comment


    """This is a docstring."""


