from pyasic.miners.backends.bitaxe import BitAxe
from pyasic.miners.device.models.bitaxe import Max


class BitAxeMax(BitAxe, Max):
    pass
