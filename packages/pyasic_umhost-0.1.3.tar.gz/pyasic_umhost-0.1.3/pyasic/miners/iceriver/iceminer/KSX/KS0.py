from pyasic.miners.backends.iceriver import IceRiver
from pyasic.miners.device.models import KS0


class IceRiverKS0(IceRiver, KS0):
    pass
