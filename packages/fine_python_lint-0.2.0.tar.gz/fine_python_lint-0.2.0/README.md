# Recommended FineCode preset for linting in Python projects
