# markdownish

Rust library to render Markdown-ish input into Signal-friendly output: a plain text message and text style ranges suitable for `signal-cli` JSON-RPC `send`.

- Spec: see `spec.md` for rules and future implementation details
- Status: baseline working — headings + bold/italic + JSON-RPC helper
- Parser: `markdown-it`
- Python: optional `pyo3` bindings behind `python` feature

## Quick Start (Rust)

- Call `render(&str) -> Rendered` to get:
  - `Rendered.text: String` — final message text (headings converted to `hN ...`).
  - `Rendered.styles: Vec<TextStyle>` — style spans with UTF‑16 offsets.
- Call `make_jsonrpc_send(account, recipients, &rendered, id)` to produce the JSON-RPC `send` payload with:
  - `message = rendered.text`
  - `textStyles = ["<start>:<len>:<KIND>", ...]` (always an array)

## Example

```rust
use markdownish::{render, Style, TextStyle, make_jsonrpc_send};

let rendered = render("# **Hello** _world_\n\nHello **bold** and *it*.");
// rendered.text => "h1 Hello world\n\nHello bold and it."
// rendered.styles => spans for bold/italic in the paragraph (none inside headings)

let payload = make_jsonrpc_send(
    "+10000000000",
    &vec!["+12223334444".into()],
    &rendered,
    "req-1",
);

println!("{}", serde_json::to_string_pretty(&payload)?);
```

## What gets translated (high level)

- Headings: ATX/Setext → `hN <raw text>` plus a blank line after. Inline styles inside headings are not emitted.
- Bold/Italic: `**text**`/`__text__`, `*text*`/`_text_` → spans over the inner text.
- Paragraphs/Breaks: paragraphs separated by a blank line; soft/hard breaks → `\n`.
- Newlines: input CR/CRLF normalized to `\n`.
- JSON-RPC: always uses `textStyles` array (even for 1 span).

Note: Strikethrough and monospace (inline/code blocks) are planned next.

## Features

- `python`: enables optional Python bindings via `pyo3` (module scaffolding pending). Build with:
  - `cargo build --features python`
  - Or install the Python extension via `maturin`:
    - `pip install maturin` (once)
    - `maturin develop -F python` (installs `markdownish` into your current venv)

## Python usage

After `maturin develop -F python`, try:

- `python scripts/render.py "# **Hello** _world_ and **b** *i*"`
  - Outputs JSON with `text` and `textStyles` (array of `"<start>:<len>:<KIND>"`).
- `python scripts/repl.py`
  - Interactive: type lines, then `:go` to render current buffer.

Python API (high level):
- `import markdownish; markdownish.render(text: str) -> dict` with keys:
  - `text: str` — final message string
  - `textStyles: list[str]` — array of `"<start>:<len>:<KIND>"`

## Docs

- Generate Rust docs: `cargo doc --open`
- Signal send mechanics are handled by `signal-cli`; see their documentation for setup and usage.
