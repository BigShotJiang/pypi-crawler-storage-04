#!/usr/bin/env python3
import os
import json
import uuid
import socket
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()


def signal_send_direct_message(recipient: str, message: str) -> str:
    """
    Send a Signal message to an individual recipient.

    Args:
        recipient: Phone number (e.g., "+12025550123") or UUID of the recipient.
        message: The text message to send.

    Returns:
        Success message with server timestamp.
    """
    
    # Get credentials from environment
    socket_path = "/run/user/1000/signal-cli/socket"
    account = os.getenv("SIGNAL_ACCOUNT")
    
    if not account:
        raise ValueError("SIGNAL_ACCOUNT environment variable must be set")
    
    req_id = str(uuid.uuid4())
    
    frame = {
        "jsonrpc": "2.0",
        "method": "send",
        "params": {
            "account": account,
            "recipient": [recipient],
            "message": message
        },
        "id": req_id,
    }
    
    try:
        with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as s:
            s.connect(socket_path)
            s.sendall((json.dumps(frame) + "\n").encode())
            
            # Read until newline
            buf = b""
            while not buf.endswith(b"\n"):
                buf += s.recv(1024)
        
        reply = json.loads(buf)
        if reply.get("id") != req_id:
            raise RuntimeError("Mismatching JSON-RPC id")
        if "error" in reply:
            raise RuntimeError(f"Signal error: {reply['error']}")
        
        timestamp = reply.get("result", {}).get("timestamp", "unknown")
        return f"Direct message sent successfully. Server timestamp: {timestamp}"
        
    except Exception as e:
        raise RuntimeError(f"Failed to send direct message: {e}")