#!/usr/bin/env python3
"""
Interactive REPL to test the markdownish PyO3 extension.

Build first:
  pip install maturin
  maturin develop -F python

Then run:
  python scripts/repl.py
"""
import json

try:
    import markdownish
except Exception as e:
    print("Import error: Did you run `maturin develop -F python`?", e)
    raise

print("markdownish REPL — type Markdown, Ctrl-D to exit")
print("(Heading, italics, bold supported; spans returned as textStyles)")

buf = []
while True:
    try:
        line = input(">>> ")
    except EOFError:
        break
    if line.strip() == ":go":
        text = "\n".join(buf)
        buf.clear()
        out = markdownish.render(text)
        print(json.dumps(out, ensure_ascii=False, indent=2))
        continue
    buf.append(line)

if buf:
    out = markdownish.render("\n".join(buf))
    print(json.dumps(out, ensure_ascii=False, indent=2))

