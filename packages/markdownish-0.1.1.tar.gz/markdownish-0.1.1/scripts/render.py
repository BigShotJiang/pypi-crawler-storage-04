#!/usr/bin/env python3
"""
Quick test script for the markdownish PyO3 extension.

Usage:
  python scripts/render.py "markdown text"
  echo "markdown text" | python scripts/render.py
"""
import sys
import json

try:
    import markdownish  # built with `maturin develop -F python`
except Exception as e:
    print("Failed to import markdownish extension. Did you run 'maturin develop -F python'?", file=sys.stderr)
    raise

def main():
    if len(sys.argv) > 1:
        text = " ".join(sys.argv[1:])
    else:
        text = sys.stdin.read()

    result = markdownish.render(text)
    print(json.dumps(result, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()

