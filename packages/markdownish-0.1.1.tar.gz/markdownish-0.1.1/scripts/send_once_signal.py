#!/usr/bin/env python3
import os
import sys
import json
import uuid
import socket

# Optional: load .env if python-dotenv is available
try:
    from dotenv import load_dotenv  # type: ignore
    load_dotenv()
except Exception:
    pass

try:
    import markdownish  # built via `maturin develop -F python`
except Exception as e:
    print("Import error: ensure markdownish is installed (maturin develop -F python)", file=sys.stderr)
    raise

RECIPIENT = os.getenv("SIGNAL_RECIPIENT", "c898d032-6925-4993-be53-6b987ab28af3")
ACCOUNT = os.getenv("SIGNAL_ACCOUNT")
SOCKET_PATH = os.getenv("SIGNAL_SOCKET_PATH", "/run/user/1000/signal-cli/socket")

if not ACCOUNT:
    print("SIGNAL_ACCOUNT must be set in the environment (or .env)", file=sys.stderr)
    sys.exit(2)

def main():
    if len(sys.argv) > 1:
        text = " ".join(sys.argv[1:])
    else:
        text = sys.stdin.read()
        if not text:
            print("Provide message text as arg or stdin", file=sys.stderr)
            sys.exit(2)

    rendered = markdownish.render(text)

    # Always use array form for styles
    styles = list(rendered.get("textStyles", []))

    req_id = str(uuid.uuid4())
    frame = {
        "jsonrpc": "2.0",
        "method": "send",
        "params": {
            "account": ACCOUNT,
            "recipient": [RECIPIENT],
            "message": rendered["text"],
            "textStyles": styles,
        },
        "id": req_id,
    }

    with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as s:
        s.connect(SOCKET_PATH)
        s.sendall((json.dumps(frame, ensure_ascii=False) + "\n").encode())
        buf = b""
        while not buf.endswith(b"\n"):
            chunk = s.recv(4096)
            if not chunk:
                break
            buf += chunk

    reply = json.loads(buf or b"{}")
    if reply.get("id") != req_id:
        print("Unexpected JSON-RPC id", file=sys.stderr)
        print(json.dumps(reply, indent=2), file=sys.stderr)
        sys.exit(1)
    if "error" in reply:
        print("Signal error:", json.dumps(reply["error"], indent=2), file=sys.stderr)
        sys.exit(1)
    ts = reply.get("result", {}).get("timestamp")
    print(f"Sent. Server timestamp: {ts}")

if __name__ == "__main__":
    main()

