#!/usr/bin/env python3
import sys
from pathlib import Path
import json

try:
    import markdownish
except Exception as e:
    print("Import error: Did you run `maturin develop -F python` in a venv?", file=sys.stderr)
    raise

def main():
    text = " ".join(sys.argv[1:]) if len(sys.argv) > 1 else "# **Hello** _world_ and **b** *i*"
    res = markdownish.render(text)
    out = Path("python_test_output.txt")
    with out.open("w", encoding="utf-8") as f:
        # INPUT section: raw provided text
        f.write("INPUT\n")
        f.write(text)
        f.write("\n\n")

        # OUTPUT section: rendered text
        f.write("OUTPUT\n")
        f.write(res["text"]) 
        f.write("\n\n")

        # TEXTSTYLES section: one per line
        f.write("TEXTSTYLES\n")
        for s in res.get("textStyles", []):
            f.write(str(s))
            f.write("\n")
    print(f"Wrote {out.resolve()}")

if __name__ == "__main__":
    main()
