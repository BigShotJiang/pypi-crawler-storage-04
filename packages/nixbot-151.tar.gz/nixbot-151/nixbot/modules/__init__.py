# This file is placed in the Public Domain.


"modules"


from ..command import modules


def __dir__():
    return modules()