Configure the policies and policy levels in
`Invoicing  > Configuration > Credit Control > Credit Control Policies`.
You can define as many policy levels as you need. You must set on which
accounts are applied every Credit Control Policy under Accounts tab.

Configure a tolerance for the Credit control and a default policy
applied on all partners in each company, under the General Information
tab in your company form.

You are able to specify a particular policy for one partner or one
invoice.
