class InvalidCaptcha(Exception):
    pass


class ServerReturnedEmptyData(Exception):
    pass
