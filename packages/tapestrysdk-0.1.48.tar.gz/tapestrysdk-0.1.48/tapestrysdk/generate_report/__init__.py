from .generate_report import generate_report

__all__ = ["generate_report"]
