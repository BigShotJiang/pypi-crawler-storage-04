# -*- coding: utf-8 -*-
# @Author  : Lodge
"""
      ┏┛ ┻━━━━━┛ ┻┓
      ┃　　　　　　 ┃
      ┃　　　━　　　┃
      ┃　┳┛　  ┗┳　┃
      ┃　　　　　　 ┃
      ┃　　　┻　　　┃
      ┃　　　　　　 ┃
      ┗━┓　　　┏━━━┛
        ┃　　　┃   神兽保佑
        ┃　　　┃   代码无BUG！
        ┃　　　┗━━━━━━━━━┓
        ┃　　　　　　　    ┣┓
        ┃　　　　         ┏┛
        ┗━┓ ┓ ┏━━━┳ ┓ ┏━┛
          ┃ ┫ ┫   ┃ ┫ ┫
          ┗━┻━┛   ┗━┻━┛
"""


class HttpXTimeOutError(Exception):
    def __init__(self, error: str = ""):
        self.error = error

    def __str__(self):
        return self.error


class TimeFormatException(Exception):
    def __init__(self, error: str = ""):
        self.error = error

    def __str__(self):
        return self.error


class ErrorTimeRange(Exception):
    def __init__(self, msg):
        self.error = msg

    def __str__(self):
        return self.error
