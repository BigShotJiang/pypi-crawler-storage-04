from ._openghg import parse_openghg
