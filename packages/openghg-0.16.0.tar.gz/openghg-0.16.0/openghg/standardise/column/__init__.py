from ._openghg import parse_openghg
from ._tccon import parse_tccon
