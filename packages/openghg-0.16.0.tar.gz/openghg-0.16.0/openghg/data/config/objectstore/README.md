This contains the default keys OpenGHG uses to create unique Datasources from data
during the standardisation process.

The `defaults.toml` file will be copied in an object store's `config` directory
when first setup.
