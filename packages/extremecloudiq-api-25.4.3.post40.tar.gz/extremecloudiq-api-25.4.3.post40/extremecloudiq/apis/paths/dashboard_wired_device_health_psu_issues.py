from extremecloudiq.paths.dashboard_wired_device_health_psu_issues.post import ApiForpost


class DashboardWiredDeviceHealthPsuIssues(
    ApiForpost,
):
    pass
