from extremecloudiq.paths.ip_firewall_policies_id_ip_firewall_rule_attach.post import ApiForpost


class IpFirewallPoliciesIdIpFirewallRuleAttach(
    ApiForpost,
):
    pass
