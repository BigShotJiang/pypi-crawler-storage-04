from extremecloudiq.paths.pcgs_key_based_network_policy_policy_id_onboard.post import ApiForpost


class PcgsKeyBasedNetworkPolicyPolicyIdOnboard(
    ApiForpost,
):
    pass
