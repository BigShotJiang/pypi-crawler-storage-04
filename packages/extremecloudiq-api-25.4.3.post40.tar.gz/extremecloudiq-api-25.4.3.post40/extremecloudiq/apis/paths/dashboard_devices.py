from extremecloudiq.paths.dashboard_devices.post import ApiForpost


class DashboardDevices(
    ApiForpost,
):
    pass
