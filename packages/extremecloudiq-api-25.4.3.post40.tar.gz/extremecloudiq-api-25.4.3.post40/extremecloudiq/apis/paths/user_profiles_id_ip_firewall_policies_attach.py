from extremecloudiq.paths.user_profiles_id_ip_firewall_policies_attach.post import ApiForpost


class UserProfilesIdIpFirewallPoliciesAttach(
    ApiForpost,
):
    pass
