from extremecloudiq.paths.dashboard_wired_device_health_temperature_issues.post import ApiForpost


class DashboardWiredDeviceHealthTemperatureIssues(
    ApiForpost,
):
    pass
