from extremecloudiq.paths.devices_id_reboot.post import ApiForpost


class DevicesIdReboot(
    ApiForpost,
):
    pass
