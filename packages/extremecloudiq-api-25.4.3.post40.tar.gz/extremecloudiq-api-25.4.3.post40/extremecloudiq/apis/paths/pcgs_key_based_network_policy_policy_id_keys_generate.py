from extremecloudiq.paths.pcgs_key_based_network_policy_policy_id_keys_generate.post import ApiForpost


class PcgsKeyBasedNetworkPolicyPolicyIdKeysGenerate(
    ApiForpost,
):
    pass
