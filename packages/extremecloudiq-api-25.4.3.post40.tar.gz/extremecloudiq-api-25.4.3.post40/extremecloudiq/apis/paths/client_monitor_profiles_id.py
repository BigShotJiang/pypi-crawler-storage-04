from extremecloudiq.paths.client_monitor_profiles_id.get import ApiForget
from extremecloudiq.paths.client_monitor_profiles_id.put import ApiForput
from extremecloudiq.paths.client_monitor_profiles_id.delete import ApiFordelete


class ClientMonitorProfilesId(
    ApiForget,
    ApiForput,
    ApiFordelete,
):
    pass
