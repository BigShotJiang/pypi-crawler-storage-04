from extremecloudiq.paths.copilot_anomalies_wifi_efficiency_stats.get import ApiForget


class CopilotAnomaliesWifiEfficiencyStats(
    ApiForget,
):
    pass
