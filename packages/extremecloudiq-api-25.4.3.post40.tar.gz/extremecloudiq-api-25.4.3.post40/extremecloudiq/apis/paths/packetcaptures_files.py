from extremecloudiq.paths.packetcaptures_files.get import ApiForget


class PacketcapturesFiles(
    ApiForget,
):
    pass
