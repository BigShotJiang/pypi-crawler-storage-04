from extremecloudiq.paths.user_profiles_id_ip_firewall_policies_detach.post import ApiForpost


class UserProfilesIdIpFirewallPoliciesDetach(
    ApiForpost,
):
    pass
