from extremecloudiq.paths.locations_wall_type_references_id.get import ApiForget


class LocationsWallTypeReferencesId(
    ApiForget,
):
    pass
