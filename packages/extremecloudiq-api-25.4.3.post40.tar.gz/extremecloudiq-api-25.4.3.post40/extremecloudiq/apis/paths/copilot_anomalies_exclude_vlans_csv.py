from extremecloudiq.paths.copilot_anomalies_exclude_vlans_csv.post import ApiForpost


class CopilotAnomaliesExcludeVlansCsv(
    ApiForpost,
):
    pass
