from extremecloudiq.paths.classification_rules.get import ApiForget
from extremecloudiq.paths.classification_rules.post import ApiForpost


class ClassificationRules(
    ApiForget,
    ApiForpost,
):
    pass
