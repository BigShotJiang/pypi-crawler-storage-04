from extremecloudiq.paths.ssids_id_mode_dot1x.put import ApiForput


class SsidsIdModeDot1x(
    ApiForput,
):
    pass
