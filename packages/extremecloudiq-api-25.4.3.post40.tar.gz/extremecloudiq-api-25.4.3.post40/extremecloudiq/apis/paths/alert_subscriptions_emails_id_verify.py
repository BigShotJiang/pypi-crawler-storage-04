from extremecloudiq.paths.alert_subscriptions_emails_id_verify.post import ApiForpost


class AlertSubscriptionsEmailsIdVerify(
    ApiForpost,
):
    pass
