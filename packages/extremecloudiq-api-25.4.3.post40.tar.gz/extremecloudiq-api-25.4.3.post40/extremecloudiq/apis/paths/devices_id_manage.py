from extremecloudiq.paths.devices_id_manage.post import ApiForpost


class DevicesIdManage(
    ApiForpost,
):
    pass
