from extremecloudiq.paths.devices_location_query.post import ApiForpost


class DevicesLocationQuery(
    ApiForpost,
):
    pass
