from extremecloudiq.paths.copilot_connectivity_wired_locations_hardware.get import ApiForget


class CopilotConnectivityWiredLocationsHardware(
    ApiForget,
):
    pass
