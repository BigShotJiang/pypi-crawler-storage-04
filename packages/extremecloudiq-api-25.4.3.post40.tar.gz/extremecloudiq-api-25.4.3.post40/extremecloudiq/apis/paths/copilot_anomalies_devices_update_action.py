from extremecloudiq.paths.copilot_anomalies_devices_update_action.put import ApiForput


class CopilotAnomaliesDevicesUpdateAction(
    ApiForput,
):
    pass
