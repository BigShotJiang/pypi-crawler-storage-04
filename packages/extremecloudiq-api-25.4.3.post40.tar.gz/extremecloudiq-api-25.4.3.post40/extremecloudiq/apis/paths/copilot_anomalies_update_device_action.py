from extremecloudiq.paths.copilot_anomalies_update_device_action.put import ApiForput


class CopilotAnomaliesUpdateDeviceAction(
    ApiForput,
):
    pass
