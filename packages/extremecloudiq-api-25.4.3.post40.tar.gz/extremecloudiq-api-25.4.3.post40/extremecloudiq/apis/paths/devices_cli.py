from extremecloudiq.paths.devices_cli.post import ApiForpost


class DevicesCli(
    ApiForpost,
):
    pass
