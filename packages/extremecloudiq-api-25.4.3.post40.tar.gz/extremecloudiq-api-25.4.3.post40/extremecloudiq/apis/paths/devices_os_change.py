from extremecloudiq.paths.devices_os_change.post import ApiForpost


class DevicesOsChange(
    ApiForpost,
):
    pass
