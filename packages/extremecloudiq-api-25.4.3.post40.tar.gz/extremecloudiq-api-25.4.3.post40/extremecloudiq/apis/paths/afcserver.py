from extremecloudiq.paths.afcserver.get import ApiForget


class Afcserver(
    ApiForget,
):
    pass
