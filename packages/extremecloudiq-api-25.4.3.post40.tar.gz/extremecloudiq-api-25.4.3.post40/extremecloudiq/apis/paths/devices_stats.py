from extremecloudiq.paths.devices_stats.get import ApiForget


class DevicesStats(
    ApiForget,
):
    pass
