from extremecloudiq.paths.d360_device_stats.get import ApiForget


class D360DeviceStats(
    ApiForget,
):
    pass
