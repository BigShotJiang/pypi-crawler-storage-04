from extremecloudiq.paths.devices_id_hostname.put import ApiForput


class DevicesIdHostname(
    ApiForput,
):
    pass
