from extremecloudiq.paths.radius_client_objects.get import ApiForget
from extremecloudiq.paths.radius_client_objects.post import ApiForpost


class RadiusClientObjects(
    ApiForget,
    ApiForpost,
):
    pass
