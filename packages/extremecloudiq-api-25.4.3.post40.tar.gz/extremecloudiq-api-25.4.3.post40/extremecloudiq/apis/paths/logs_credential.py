from extremecloudiq.paths.logs_credential.get import ApiForget


class LogsCredential(
    ApiForget,
):
    pass
