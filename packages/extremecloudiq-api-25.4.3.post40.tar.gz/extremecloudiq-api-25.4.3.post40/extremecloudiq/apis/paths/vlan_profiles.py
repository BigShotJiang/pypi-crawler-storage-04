from extremecloudiq.paths.vlan_profiles.get import ApiForget
from extremecloudiq.paths.vlan_profiles.post import ApiForpost


class VlanProfiles(
    ApiForget,
    ApiForpost,
):
    pass
