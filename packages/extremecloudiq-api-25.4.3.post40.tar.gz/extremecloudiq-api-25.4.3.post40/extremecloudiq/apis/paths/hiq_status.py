from extremecloudiq.paths.hiq_status.get import ApiForget


class HiqStatus(
    ApiForget,
):
    pass
