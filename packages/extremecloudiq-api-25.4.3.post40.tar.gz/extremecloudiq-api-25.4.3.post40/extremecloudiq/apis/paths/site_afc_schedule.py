from extremecloudiq.paths.site_afc_schedule.get import ApiForget
from extremecloudiq.paths.site_afc_schedule.put import ApiForput
from extremecloudiq.paths.site_afc_schedule.post import ApiForpost


class SiteAfcSchedule(
    ApiForget,
    ApiForput,
    ApiForpost,
):
    pass
