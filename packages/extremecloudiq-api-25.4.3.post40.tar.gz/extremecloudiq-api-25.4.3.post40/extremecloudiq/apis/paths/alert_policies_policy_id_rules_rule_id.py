from extremecloudiq.paths.alert_policies_policy_id_rules_rule_id.get import ApiForget
from extremecloudiq.paths.alert_policies_policy_id_rules_rule_id.put import ApiForput


class AlertPoliciesPolicyIdRulesRuleId(
    ApiForget,
    ApiForput,
):
    pass
