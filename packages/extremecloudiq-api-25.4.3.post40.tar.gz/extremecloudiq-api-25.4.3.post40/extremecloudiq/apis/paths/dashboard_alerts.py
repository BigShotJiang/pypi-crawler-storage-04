from extremecloudiq.paths.dashboard_alerts.post import ApiForpost


class DashboardAlerts(
    ApiForpost,
):
    pass
