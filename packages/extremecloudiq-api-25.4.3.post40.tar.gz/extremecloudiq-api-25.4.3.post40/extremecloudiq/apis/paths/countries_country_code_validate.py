from extremecloudiq.paths.countries_country_code_validate.get import ApiForget


class CountriesCountryCodeValidate(
    ApiForget,
):
    pass
