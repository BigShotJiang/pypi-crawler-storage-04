from extremecloudiq.paths.locations_id.put import ApiForput
from extremecloudiq.paths.locations_id.delete import ApiFordelete


class LocationsId(
    ApiForput,
    ApiFordelete,
):
    pass
