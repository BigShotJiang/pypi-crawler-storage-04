from extremecloudiq.paths.clients_active.get import ApiForget


class ClientsActive(
    ApiForget,
):
    pass
