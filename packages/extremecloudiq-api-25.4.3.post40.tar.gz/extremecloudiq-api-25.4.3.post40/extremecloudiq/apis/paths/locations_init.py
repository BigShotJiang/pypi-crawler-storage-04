from extremecloudiq.paths.locations_init.post import ApiForpost


class LocationsInit(
    ApiForpost,
):
    pass
