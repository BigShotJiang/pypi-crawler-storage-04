from extremecloudiq.paths.d360_client_stats.get import ApiForget


class D360ClientStats(
    ApiForget,
):
    pass
