from extremecloudiq.paths.d360_client_graph.post import ApiForpost


class D360ClientGraph(
    ApiForpost,
):
    pass
