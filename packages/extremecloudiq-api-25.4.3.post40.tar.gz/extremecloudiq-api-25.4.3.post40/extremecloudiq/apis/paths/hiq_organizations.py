from extremecloudiq.paths.hiq_organizations.get import ApiForget
from extremecloudiq.paths.hiq_organizations.post import ApiForpost


class HiqOrganizations(
    ApiForget,
    ApiForpost,
):
    pass
