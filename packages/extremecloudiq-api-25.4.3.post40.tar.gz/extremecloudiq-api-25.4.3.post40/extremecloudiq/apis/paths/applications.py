from extremecloudiq.paths.applications.get import ApiForget


class Applications(
    ApiForget,
):
    pass
