from extremecloudiq.paths.hiq_organizations_id.delete import ApiFordelete


class HiqOrganizationsId(
    ApiFordelete,
):
    pass
