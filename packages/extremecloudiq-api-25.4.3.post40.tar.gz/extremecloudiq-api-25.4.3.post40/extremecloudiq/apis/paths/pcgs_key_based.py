from extremecloudiq.paths.pcgs_key_based.get import ApiForget
from extremecloudiq.paths.pcgs_key_based.post import ApiForpost


class PcgsKeyBased(
    ApiForget,
    ApiForpost,
):
    pass
