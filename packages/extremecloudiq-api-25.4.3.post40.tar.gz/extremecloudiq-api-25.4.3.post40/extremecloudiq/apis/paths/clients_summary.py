from extremecloudiq.paths.clients_summary.get import ApiForget


class ClientsSummary(
    ApiForget,
):
    pass
