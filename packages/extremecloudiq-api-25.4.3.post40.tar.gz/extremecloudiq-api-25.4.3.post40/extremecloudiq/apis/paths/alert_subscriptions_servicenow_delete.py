from extremecloudiq.paths.alert_subscriptions_servicenow_delete.post import ApiForpost


class AlertSubscriptionsServicenowDelete(
    ApiForpost,
):
    pass
