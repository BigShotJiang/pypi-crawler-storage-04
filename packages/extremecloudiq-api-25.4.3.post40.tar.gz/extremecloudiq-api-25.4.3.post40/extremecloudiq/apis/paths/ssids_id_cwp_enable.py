from extremecloudiq.paths.ssids_id_cwp_enable.post import ApiForpost


class SsidsIdCwpEnable(
    ApiForpost,
):
    pass
