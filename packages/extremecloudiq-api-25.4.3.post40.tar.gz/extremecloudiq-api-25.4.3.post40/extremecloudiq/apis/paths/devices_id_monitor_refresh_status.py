from extremecloudiq.paths.devices_id_monitor_refresh_status.get import ApiForget


class DevicesIdMonitorRefreshStatus(
    ApiForget,
):
    pass
