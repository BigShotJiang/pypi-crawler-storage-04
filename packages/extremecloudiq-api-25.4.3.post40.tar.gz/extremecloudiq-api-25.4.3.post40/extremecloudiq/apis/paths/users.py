from extremecloudiq.paths.users.get import ApiForget
from extremecloudiq.paths.users.post import ApiForpost


class Users(
    ApiForget,
    ApiForpost,
):
    pass
