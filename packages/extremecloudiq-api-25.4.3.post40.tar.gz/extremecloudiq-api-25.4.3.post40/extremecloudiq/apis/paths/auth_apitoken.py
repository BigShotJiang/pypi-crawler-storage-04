from extremecloudiq.paths.auth_apitoken.post import ApiForpost


class AuthApitoken(
    ApiForpost,
):
    pass
