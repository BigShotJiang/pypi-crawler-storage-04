from extremecloudiq.paths.dashboard_wired_usage_capacity_wired_congestion.post import ApiForpost


class DashboardWiredUsageCapacityWiredCongestion(
    ApiForpost,
):
    pass
