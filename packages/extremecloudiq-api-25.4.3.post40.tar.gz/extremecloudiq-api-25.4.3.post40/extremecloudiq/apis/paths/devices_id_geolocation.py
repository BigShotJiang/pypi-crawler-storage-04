from extremecloudiq.paths.devices_id_geolocation.get import ApiForget


class DevicesIdGeolocation(
    ApiForget,
):
    pass
