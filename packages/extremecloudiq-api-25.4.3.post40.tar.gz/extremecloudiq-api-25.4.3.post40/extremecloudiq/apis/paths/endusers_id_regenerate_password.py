from extremecloudiq.paths.endusers_id_regenerate_password.post import ApiForpost


class EndusersIdRegeneratePassword(
    ApiForpost,
):
    pass
