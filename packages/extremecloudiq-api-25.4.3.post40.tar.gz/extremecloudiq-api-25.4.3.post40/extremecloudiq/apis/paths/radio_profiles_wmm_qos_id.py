from extremecloudiq.paths.radio_profiles_wmm_qos_id.get import ApiForget
from extremecloudiq.paths.radio_profiles_wmm_qos_id.put import ApiForput


class RadioProfilesWmmQosId(
    ApiForget,
    ApiForput,
):
    pass
