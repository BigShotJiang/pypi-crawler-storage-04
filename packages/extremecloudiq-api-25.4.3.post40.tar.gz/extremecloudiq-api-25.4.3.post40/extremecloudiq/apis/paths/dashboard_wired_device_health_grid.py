from extremecloudiq.paths.dashboard_wired_device_health_grid.post import ApiForpost


class DashboardWiredDeviceHealthGrid(
    ApiForpost,
):
    pass
