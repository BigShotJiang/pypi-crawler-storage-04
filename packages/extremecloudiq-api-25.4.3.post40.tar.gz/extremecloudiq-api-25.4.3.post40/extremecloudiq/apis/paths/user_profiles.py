from extremecloudiq.paths.user_profiles.get import ApiForget
from extremecloudiq.paths.user_profiles.post import ApiForpost


class UserProfiles(
    ApiForget,
    ApiForpost,
):
    pass
