from extremecloudiq.paths.clients_id.get import ApiForget


class ClientsId(
    ApiForget,
):
    pass
