from extremecloudiq.paths.copilot_assurance_scans_overview.get import ApiForget


class CopilotAssuranceScansOverview(
    ApiForget,
):
    pass
