from extremecloudiq.paths.tunnel_concentrators_id.get import ApiForget
from extremecloudiq.paths.tunnel_concentrators_id.put import ApiForput
from extremecloudiq.paths.tunnel_concentrators_id.delete import ApiFordelete


class TunnelConcentratorsId(
    ApiForget,
    ApiForput,
    ApiFordelete,
):
    pass
