from extremecloudiq.paths.nos_device_device_id_nos_api.post import ApiForpost


class NosDeviceDeviceIdNosApi(
    ApiForpost,
):
    pass
