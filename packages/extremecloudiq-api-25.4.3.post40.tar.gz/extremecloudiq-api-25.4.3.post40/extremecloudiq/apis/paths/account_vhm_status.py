from extremecloudiq.paths.account_vhm_status.get import ApiForget


class AccountVhmStatus(
    ApiForget,
):
    pass
