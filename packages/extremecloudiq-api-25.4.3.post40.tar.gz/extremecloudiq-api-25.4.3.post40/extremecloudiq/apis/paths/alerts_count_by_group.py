from extremecloudiq.paths.alerts_count_by_group.get import ApiForget


class AlertsCountByGroup(
    ApiForget,
):
    pass
