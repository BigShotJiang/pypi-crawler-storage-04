from extremecloudiq.paths.radius_client_objects_id.get import ApiForget
from extremecloudiq.paths.radius_client_objects_id.put import ApiForput
from extremecloudiq.paths.radius_client_objects_id.delete import ApiFordelete


class RadiusClientObjectsId(
    ApiForget,
    ApiForput,
    ApiFordelete,
):
    pass
