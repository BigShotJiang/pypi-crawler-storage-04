from extremecloudiq.paths.account_viq_backup.post import ApiForpost


class AccountViqBackup(
    ApiForpost,
):
    pass
