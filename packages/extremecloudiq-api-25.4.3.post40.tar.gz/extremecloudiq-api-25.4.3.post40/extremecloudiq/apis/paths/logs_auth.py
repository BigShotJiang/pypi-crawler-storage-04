from extremecloudiq.paths.logs_auth.get import ApiForget


class LogsAuth(
    ApiForget,
):
    pass
