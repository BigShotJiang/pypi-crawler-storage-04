from extremecloudiq.paths.copilot_anomalies_locations.get import ApiForget


class CopilotAnomaliesLocations(
    ApiForget,
):
    pass
