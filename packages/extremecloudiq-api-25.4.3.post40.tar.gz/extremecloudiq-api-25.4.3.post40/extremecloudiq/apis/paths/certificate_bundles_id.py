from extremecloudiq.paths.certificate_bundles_id.get import ApiForget
from extremecloudiq.paths.certificate_bundles_id.put import ApiForput
from extremecloudiq.paths.certificate_bundles_id.delete import ApiFordelete


class CertificateBundlesId(
    ApiForget,
    ApiForput,
    ApiFordelete,
):
    pass
