from extremecloudiq.paths.devices_id_unmanage.post import ApiForpost


class DevicesIdUnmanage(
    ApiForpost,
):
    pass
