from extremecloudiq.paths.mac_object_profiles.get import ApiForget
from extremecloudiq.paths.mac_object_profiles.post import ApiForpost


class MacObjectProfiles(
    ApiForget,
    ApiForpost,
):
    pass
