from extremecloudiq.paths.d360_device_interfaces.get import ApiForget


class D360DeviceInterfaces(
    ApiForget,
):
    pass
