from extremecloudiq.paths.site_spectrum_.post import ApiForpost


class SiteSpectrum(
    ApiForpost,
):
    pass
