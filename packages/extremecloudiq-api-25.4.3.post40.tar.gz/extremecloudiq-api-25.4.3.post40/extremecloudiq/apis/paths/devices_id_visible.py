from extremecloudiq.paths.devices_id_visible.put import ApiForput


class DevicesIdVisible(
    ApiForput,
):
    pass
