from extremecloudiq.paths.radio_profiles_radio_usage_opt_id.get import ApiForget
from extremecloudiq.paths.radio_profiles_radio_usage_opt_id.put import ApiForput


class RadioProfilesRadioUsageOptId(
    ApiForget,
    ApiForput,
):
    pass
