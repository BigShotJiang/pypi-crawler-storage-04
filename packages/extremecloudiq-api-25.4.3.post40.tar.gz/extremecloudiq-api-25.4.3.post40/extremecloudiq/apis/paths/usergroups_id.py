from extremecloudiq.paths.usergroups_id.put import ApiForput
from extremecloudiq.paths.usergroups_id.delete import ApiFordelete


class UsergroupsId(
    ApiForput,
    ApiFordelete,
):
    pass
