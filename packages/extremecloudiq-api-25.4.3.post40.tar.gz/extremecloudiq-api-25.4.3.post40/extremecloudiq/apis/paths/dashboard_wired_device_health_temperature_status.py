from extremecloudiq.paths.dashboard_wired_device_health_temperature_status.post import ApiForpost


class DashboardWiredDeviceHealthTemperatureStatus(
    ApiForpost,
):
    pass
