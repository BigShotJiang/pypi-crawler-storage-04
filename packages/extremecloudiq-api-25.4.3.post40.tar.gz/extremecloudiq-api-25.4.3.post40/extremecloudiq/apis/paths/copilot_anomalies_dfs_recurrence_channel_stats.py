from extremecloudiq.paths.copilot_anomalies_dfs_recurrence_channel_stats.get import ApiForget


class CopilotAnomaliesDfsRecurrenceChannelStats(
    ApiForget,
):
    pass
