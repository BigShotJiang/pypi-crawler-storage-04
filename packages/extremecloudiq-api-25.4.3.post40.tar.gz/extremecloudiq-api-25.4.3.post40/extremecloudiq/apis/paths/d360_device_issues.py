from extremecloudiq.paths.d360_device_issues.get import ApiForget


class D360DeviceIssues(
    ApiForget,
):
    pass
