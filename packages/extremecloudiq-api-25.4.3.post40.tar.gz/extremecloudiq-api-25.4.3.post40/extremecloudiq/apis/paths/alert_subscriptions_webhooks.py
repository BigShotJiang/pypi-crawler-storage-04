from extremecloudiq.paths.alert_subscriptions_webhooks.get import ApiForget
from extremecloudiq.paths.alert_subscriptions_webhooks.post import ApiForpost


class AlertSubscriptionsWebhooks(
    ApiForget,
    ApiForpost,
):
    pass
