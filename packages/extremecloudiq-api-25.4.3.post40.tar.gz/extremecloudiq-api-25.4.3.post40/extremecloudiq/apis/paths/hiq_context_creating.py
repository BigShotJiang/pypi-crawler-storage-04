from extremecloudiq.paths.hiq_context_creating.get import ApiForget
from extremecloudiq.paths.hiq_context_creating.put import ApiForput


class HiqContextCreating(
    ApiForget,
    ApiForput,
):
    pass
