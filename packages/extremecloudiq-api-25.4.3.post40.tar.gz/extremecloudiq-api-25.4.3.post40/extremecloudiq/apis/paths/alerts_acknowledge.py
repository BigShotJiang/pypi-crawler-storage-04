from extremecloudiq.paths.alerts_acknowledge.post import ApiForpost


class AlertsAcknowledge(
    ApiForpost,
):
    pass
