from extremecloudiq.paths.devices_id_gallery_image.get import ApiForget


class DevicesIdGalleryImage(
    ApiForget,
):
    pass
