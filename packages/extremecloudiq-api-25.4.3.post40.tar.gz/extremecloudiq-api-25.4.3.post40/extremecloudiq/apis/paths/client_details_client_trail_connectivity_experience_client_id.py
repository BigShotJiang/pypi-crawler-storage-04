from extremecloudiq.paths.client_details_client_trail_connectivity_experience_client_id.get import ApiForget


class ClientDetailsClientTrailConnectivityExperienceClientId(
    ApiForget,
):
    pass
