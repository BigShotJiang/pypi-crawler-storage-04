from extremecloudiq.paths.rtts_id.delete import ApiFordelete


class RttsId(
    ApiFordelete,
):
    pass
