from extremecloudiq.paths.deployments_status.get import ApiForget


class DeploymentsStatus(
    ApiForget,
):
    pass
