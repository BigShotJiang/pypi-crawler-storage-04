from extremecloudiq.paths.alerts_reports_id.get import ApiForget


class AlertsReportsId(
    ApiForget,
):
    pass
