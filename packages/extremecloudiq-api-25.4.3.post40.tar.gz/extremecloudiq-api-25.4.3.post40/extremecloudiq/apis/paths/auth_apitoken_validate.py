from extremecloudiq.paths.auth_apitoken_validate.post import ApiForpost


class AuthApitokenValidate(
    ApiForpost,
):
    pass
