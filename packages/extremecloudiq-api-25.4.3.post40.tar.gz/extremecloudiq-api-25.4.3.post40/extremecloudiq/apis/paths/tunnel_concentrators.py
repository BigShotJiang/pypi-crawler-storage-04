from extremecloudiq.paths.tunnel_concentrators.get import ApiForget
from extremecloudiq.paths.tunnel_concentrators.post import ApiForpost


class TunnelConcentrators(
    ApiForget,
    ApiForpost,
):
    pass
