from extremecloudiq.paths.account_viq.get import ApiForget


class AccountViq(
    ApiForget,
):
    pass
