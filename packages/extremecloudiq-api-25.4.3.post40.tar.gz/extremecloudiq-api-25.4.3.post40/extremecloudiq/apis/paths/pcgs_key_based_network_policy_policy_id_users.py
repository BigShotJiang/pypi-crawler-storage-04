from extremecloudiq.paths.pcgs_key_based_network_policy_policy_id_users.get import ApiForget
from extremecloudiq.paths.pcgs_key_based_network_policy_policy_id_users.put import ApiForput
from extremecloudiq.paths.pcgs_key_based_network_policy_policy_id_users.post import ApiForpost
from extremecloudiq.paths.pcgs_key_based_network_policy_policy_id_users.delete import ApiFordelete


class PcgsKeyBasedNetworkPolicyPolicyIdUsers(
    ApiForget,
    ApiForput,
    ApiForpost,
    ApiFordelete,
):
    pass
