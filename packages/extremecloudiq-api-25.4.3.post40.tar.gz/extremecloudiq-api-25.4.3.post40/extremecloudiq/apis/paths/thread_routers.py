from extremecloudiq.paths.thread_routers.get import ApiForget


class ThreadRouters(
    ApiForget,
):
    pass
