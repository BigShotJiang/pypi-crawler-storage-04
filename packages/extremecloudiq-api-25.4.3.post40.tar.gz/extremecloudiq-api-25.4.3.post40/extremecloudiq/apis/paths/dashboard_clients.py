from extremecloudiq.paths.dashboard_clients.post import ApiForpost


class DashboardClients(
    ApiForpost,
):
    pass
