from extremecloudiq.paths.devices_client_monitor_query.post import ApiForpost


class DevicesClientMonitorQuery(
    ApiForpost,
):
    pass
