from extremecloudiq.paths.dashboard_wired_device_health_poe_usage_status.post import ApiForpost


class DashboardWiredDeviceHealthPoeUsageStatus(
    ApiForpost,
):
    pass
