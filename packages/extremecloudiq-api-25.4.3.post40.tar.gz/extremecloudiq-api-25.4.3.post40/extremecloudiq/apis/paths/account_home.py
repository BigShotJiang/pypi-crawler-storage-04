from extremecloudiq.paths.account_home.get import ApiForget


class AccountHome(
    ApiForget,
):
    pass
