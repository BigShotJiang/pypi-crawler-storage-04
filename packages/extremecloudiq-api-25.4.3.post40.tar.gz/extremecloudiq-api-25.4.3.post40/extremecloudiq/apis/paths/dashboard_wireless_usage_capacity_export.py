from extremecloudiq.paths.dashboard_wireless_usage_capacity_export.post import ApiForpost


class DashboardWirelessUsageCapacityExport(
    ApiForpost,
):
    pass
