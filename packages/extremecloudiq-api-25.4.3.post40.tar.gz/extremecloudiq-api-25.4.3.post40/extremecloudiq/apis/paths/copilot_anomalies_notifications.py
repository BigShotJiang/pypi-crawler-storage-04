from extremecloudiq.paths.copilot_anomalies_notifications.get import ApiForget


class CopilotAnomaliesNotifications(
    ApiForget,
):
    pass
