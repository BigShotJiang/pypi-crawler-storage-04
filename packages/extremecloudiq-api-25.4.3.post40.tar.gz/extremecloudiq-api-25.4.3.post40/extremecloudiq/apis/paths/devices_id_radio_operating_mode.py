from extremecloudiq.paths.devices_id_radio_operating_mode.get import ApiForget
from extremecloudiq.paths.devices_id_radio_operating_mode.put import ApiForput


class DevicesIdRadioOperatingMode(
    ApiForget,
    ApiForput,
):
    pass
