# ugbio_cnv

This module includes CNV python scripts for bioinformatics pipelines.

More details on the module's scripts can be found [here](germline_cnv_calling.md)
