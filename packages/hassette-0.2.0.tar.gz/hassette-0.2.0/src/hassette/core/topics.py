# service events

HASSETTE_EVENT_SERVICE_STATUS = "hassette.event.service_status"
HASSETTE_EVENT_WEBSOCKET_STATUS = "hassette.event.websocket"

# Home Assistant events
HASS_EVENT_STATE_CHANGED = "hass.event.state_changed"
HASS_EVENT_CALL_SERVICE = "hass.event.call_service"
HASS_EVENT_COMPONENT_LOADED = "hass.event.component_loaded"
HASS_EVENT_SERVICE_REGISTERED = "hass.event.service_registered"
HASS_EVENT_SERVICE_REMOVED = "hass.event.service_removed"
HASS_EVENT_LOGBOOK_ENTRY = "hass.event.logbook_entry"
HASS_EVENT_USER_ADDED = "hass.event.user_added"
HASS_EVENT_USER_REMOVED = "hass.event.user_removed"
HASS_EVENT_AUTOMATION_TRIGGERED = "hass.event.automation_triggered"
HASS_EVENT_SCRIPT_STARTED = "hass.event.script_started"


KNOWN_TOPICS = {
    HASS_EVENT_STATE_CHANGED,
    HASS_EVENT_CALL_SERVICE,
    HASS_EVENT_COMPONENT_LOADED,
    HASS_EVENT_SERVICE_REGISTERED,
    HASSETTE_EVENT_WEBSOCKET_STATUS,
    HASSETTE_EVENT_SERVICE_STATUS,
}
