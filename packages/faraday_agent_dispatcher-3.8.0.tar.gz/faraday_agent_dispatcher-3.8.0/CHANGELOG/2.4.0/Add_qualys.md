Add Qualys executor
