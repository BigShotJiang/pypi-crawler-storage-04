"""Utility functions for bhut."""
