"""Spatial utilities for bhut."""
