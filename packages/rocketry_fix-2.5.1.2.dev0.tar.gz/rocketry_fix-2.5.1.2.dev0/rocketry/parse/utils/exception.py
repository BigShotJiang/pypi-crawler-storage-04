class ParserError(Exception):
    pass
