This module restores account reconciliation models functions moved from Odoo community to enterpise in V. 17.0
