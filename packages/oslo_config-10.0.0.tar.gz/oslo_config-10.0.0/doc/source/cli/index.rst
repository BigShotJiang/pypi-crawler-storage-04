================================
 oslo.config Command Line Tools
================================

.. toctree::
   :maxdepth: 2

   generator
   validator

