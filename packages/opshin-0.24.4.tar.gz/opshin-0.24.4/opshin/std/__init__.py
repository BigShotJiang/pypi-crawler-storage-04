"""
OpShin provides a few features in its standard libary.
You can import modules from there (i.e. the `fractions` module) with

```python
from opshin.std.fractions import *
```
"""
