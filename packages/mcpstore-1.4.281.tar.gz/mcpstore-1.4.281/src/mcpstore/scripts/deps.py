"""
Global application state and dependencies
"""
from typing import Dict, Any

# Global application state
app_state: Dict[str, Any] = {} 
