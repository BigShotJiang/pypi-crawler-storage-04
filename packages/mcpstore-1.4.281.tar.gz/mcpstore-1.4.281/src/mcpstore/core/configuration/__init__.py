"""
Configuration layer modules consolidating config processors and builders.
"""

