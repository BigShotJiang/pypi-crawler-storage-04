// SPDX-License-Identifier: (Apache-2.0 OR MIT) AND CC0-1.0

#include "sig_stfl_xmss_xmssmt.c"

// ======================== XMSSMT-SHAKE_20/4_256 ======================== //

XMSS_ALG(mt, mt_shake128_h20_4, MT_SHAKE128_H20_4)
