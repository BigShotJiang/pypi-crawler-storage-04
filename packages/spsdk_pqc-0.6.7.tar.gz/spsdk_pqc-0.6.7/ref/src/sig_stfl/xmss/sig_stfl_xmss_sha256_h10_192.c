// SPDX-License-Identifier: (Apache-2.0 OR MIT) AND CC0-1.0

#include "sig_stfl_xmss_xmssmt.c"

// ======================== XMSS-SHA2_10_192 ======================== //

XMSS_ALG(, _sha256_h10_192, _SHA256_H10_192)
