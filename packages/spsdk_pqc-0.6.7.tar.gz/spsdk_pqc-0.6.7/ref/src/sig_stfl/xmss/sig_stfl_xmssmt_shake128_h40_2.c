// SPDX-License-Identifier: (Apache-2.0 OR MIT) AND CC0-1.0

#include "sig_stfl_xmss_xmssmt.c"

// ======================== XMSSMT-SHAKE_40/2_256 ======================== //

XMSS_ALG(mt, mt_shake128_h40_2, MT_SHAKE128_H40_2)
