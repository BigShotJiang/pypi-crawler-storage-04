// SPDX-License-Identifier: (Apache-2.0 OR MIT) AND CC0-1.0

#include "sig_stfl_xmss_xmssmt.c"

// ======================== XMSS-SHA2_16_512 ======================== //

XMSS_ALG(, _sha512_h16, _SHA512_H16)
