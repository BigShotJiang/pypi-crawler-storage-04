from .sdl2_alpha import *

__doc__ = sdl2_alpha.__doc__
if hasattr(sdl2_alpha, "__all__"):
    __all__ = sdl2_alpha.__all__