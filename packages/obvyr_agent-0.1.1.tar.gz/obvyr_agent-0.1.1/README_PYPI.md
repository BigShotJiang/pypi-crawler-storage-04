# obvyr-agent

Command-line wrapper to run Obvyr agents locally or in CI.

## Installation

    pip install obvyr-agent

## Usage

    obvyr-agent --help

## Python Support

Python 3.12+

## Licence

Proprietary © Wyrd Technology Ltd
