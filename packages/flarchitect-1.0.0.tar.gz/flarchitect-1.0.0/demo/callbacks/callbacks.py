"""Entry point for running the callback demonstration app."""

from demo.callbacks.model import create_app

app = create_app()

if __name__ == "__main__":
    app.run("0.0.0.0", 5000, debug=True)
