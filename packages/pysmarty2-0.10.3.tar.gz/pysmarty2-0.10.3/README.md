# pysmarty2

Python API for Salda Smarty 2X/3X/4X P/V Ventilation Unit. This is used in [Home Assistant](https://home-assistant.io).

This package, `pysmarty2`, is a fork of the original [`pysmarty`](https://github.com/z0mbieprocess/pysmarty) created by [z0mbieprocess](https://github.com/z0mbieprocess).

The package was renamed to `pysmarty2` to allow for publishing it to PyPI without conflicting with the existing `pysmarty` package.

## Install

```bash
pip install pysmarty2
```

## Publish

1. Make sure that `setup.py` is updated with the new version, commit and push it before version is tagged.
2. Tag the new version.
3. Start python container:

```sh
docker run --rm -it -v $(pwd):/pystmarty2 python:3.13 bash
```

4. Then from within container run:

```sh
cd /pystmarty2
pip install build twine
python -m build
twine upload dist/*
```

## Acknowledgments

Please give credit to the original author for their work on `pysmarty`. This fork was created to make minor modifications and improvements, but the majority of the work remains the original author's.
