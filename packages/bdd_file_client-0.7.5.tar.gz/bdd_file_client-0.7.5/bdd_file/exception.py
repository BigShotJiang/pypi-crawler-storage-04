class BddFileError(Exception):
    pass
