.. _peek_admin_app_documentation:

++++++++++++++++++++++++
Peek Admin Documentation
++++++++++++++++++++++++


This Peek Admin documentation will provide documentation for administering and
developing peek plugins.

.. warning:: Some admin tasks described in this documentation are descructive and should
    not be performed on a production environment.

    Ensure that all commands are tested thouroughly in TEST or DEVELOPMENT environments
    first.
