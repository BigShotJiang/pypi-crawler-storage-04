"""Python package for managing file upload/download via selected file system."""

__version__ = "1.8.3"
