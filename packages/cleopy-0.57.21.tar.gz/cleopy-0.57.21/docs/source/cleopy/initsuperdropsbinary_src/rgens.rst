RGENS
=====

.. automodule:: cleopy.initsuperdropsbinary_src.rgens
   :members:
