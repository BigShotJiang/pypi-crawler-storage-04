ResourceData
============

.. currentmodule:: plutoprint

.. autoclass:: ResourceData
    :members:

    .. automethod:: __init__
