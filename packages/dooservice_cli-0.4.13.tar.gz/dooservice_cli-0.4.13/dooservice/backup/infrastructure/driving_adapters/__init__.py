"""Backup infrastructure driving adapters."""
