"""Configuration and validation utilities."""
