"""Webhook infrastructure adapters."""
