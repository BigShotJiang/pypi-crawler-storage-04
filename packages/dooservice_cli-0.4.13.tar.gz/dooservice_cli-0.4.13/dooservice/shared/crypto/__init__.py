"""Cryptographic and serialization utilities."""
