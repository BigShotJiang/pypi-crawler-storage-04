"""GitHub infrastructure driving adapters."""
