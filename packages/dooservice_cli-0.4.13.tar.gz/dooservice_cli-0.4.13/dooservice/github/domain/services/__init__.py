"""GitHub domain services."""
