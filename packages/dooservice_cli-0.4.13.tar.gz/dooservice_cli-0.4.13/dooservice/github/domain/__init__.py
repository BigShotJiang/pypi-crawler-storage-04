"""GitHub domain layer."""
