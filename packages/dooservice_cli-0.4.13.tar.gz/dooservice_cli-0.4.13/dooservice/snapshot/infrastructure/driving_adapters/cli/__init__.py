"""Snapshot CLI commands."""
