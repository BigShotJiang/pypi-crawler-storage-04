"""Snapshot use cases."""
