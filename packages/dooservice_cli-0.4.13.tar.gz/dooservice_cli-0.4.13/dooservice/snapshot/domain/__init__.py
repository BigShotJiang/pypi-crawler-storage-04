"""Snapshot domain layer."""
