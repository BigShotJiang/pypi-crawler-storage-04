# TODO List

## For the Webspirit

- Utiliser le décorateur CheckType sans parenthèses

- Créer une classe gestion de contexte pour gérer les erreurs