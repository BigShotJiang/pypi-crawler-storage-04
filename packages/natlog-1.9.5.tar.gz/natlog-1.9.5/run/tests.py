from natlog.test.tests import *

if __name__ == "__main__":
    libtest()
