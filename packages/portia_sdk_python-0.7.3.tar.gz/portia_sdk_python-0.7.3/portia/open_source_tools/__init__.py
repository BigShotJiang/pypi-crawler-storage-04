"""Sample example tools."""
