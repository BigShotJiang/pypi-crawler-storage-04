# Show help for available MPM commands

Display help information for Claude MPM commands.

Usage: /mpm-help [command]

Examples:
- /mpm-help - Show all MPM commands
- /mpm-help doctor - Show detailed help for doctor command
- /mpm-help agents - Show detailed help for agents command