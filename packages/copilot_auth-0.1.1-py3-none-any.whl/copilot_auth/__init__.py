__name__ = 'copilot-auth'
__version__ = '0.1.1'
__owner__ = 'bhachauk'

from .auth import authenticate_github_access_token, authenticate_copilot_token