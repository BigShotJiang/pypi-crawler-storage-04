.. fluxfootprint documentation master file, created by
   sphinx-quickstart on Fri May  2 07:30:12 2025.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

fluxfootprint documentation
===========================


.. toctree::
   :maxdepth: 2
   :caption: Contents:
   
   fluxfootprints
   modules
   exp
   modeltypes
   Quick-start notebook 1 <notebooks/ffp_getting_started.ipynb>
   Quick-start notebook 2 <notebooks/footprint_package_calc.ipynb>


