fluxfootprints package
======================

Submodules
----------

fluxfootprints.compare module
-----------------------------

.. automodule:: fluxfootprints.compare
   :members:
   :show-inheritance:
   :undoc-members:

fluxfootprints.ep\_footprint module
-----------------------------------

.. automodule:: fluxfootprints.ep_footprint
   :members:
   :show-inheritance:
   :undoc-members:

fluxfootprints.ffp\_xr module
-----------------------------

.. automodule:: fluxfootprints.ffp_xr
   :members:
   :show-inheritance:
   :undoc-members:

fluxfootprints.footprint\_plotting module
-----------------------------------------

.. automodule:: fluxfootprints.footprint_plotting
   :members:
   :show-inheritance:
   :undoc-members:

fluxfootprints.improved\_ffp module
-----------------------------------

.. automodule:: fluxfootprints.improved_ffp
   :members:
   :show-inheritance:
   :undoc-members:

fluxfootprints.tools module
---------------------------

.. automodule:: fluxfootprints.tools
   :members:
   :show-inheritance:
   :undoc-members:

fluxfootprints.volk module
--------------------------

.. automodule:: fluxfootprints.volk
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: fluxfootprints
   :members:
   :show-inheritance:
   :undoc-members:
