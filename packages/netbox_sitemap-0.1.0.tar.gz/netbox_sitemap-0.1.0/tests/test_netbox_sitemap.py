#!/usr/bin/env python

"""Tests for `netbox_sitemap` package."""

from netbox_sitemap import netbox_sitemap
