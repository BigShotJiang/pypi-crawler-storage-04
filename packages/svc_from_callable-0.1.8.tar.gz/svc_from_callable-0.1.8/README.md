# svc-from-callable
