from .many_class_classifier import ManyClassClassifier

__all__ = ["ManyClassClassifier"]
