from .vad import SileroVAD

__all__ = ["SileroVAD"]