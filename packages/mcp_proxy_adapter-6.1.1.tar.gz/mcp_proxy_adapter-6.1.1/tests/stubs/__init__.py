"""
Test stub modules for framework tests.
"""

from .echo_command import EchoCommand, EchoResult

__all__ = [
    "EchoCommand",
    "EchoResult"
]
