__all__ = [
    'query',
]


__version__ = '0.1.0'

from .api import query
