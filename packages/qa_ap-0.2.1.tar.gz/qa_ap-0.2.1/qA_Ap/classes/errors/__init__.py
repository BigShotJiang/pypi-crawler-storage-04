class ExistsError(Exception):
    pass

class NotFoundError(Exception):
    pass

class RegisterError(Exception):
    pass