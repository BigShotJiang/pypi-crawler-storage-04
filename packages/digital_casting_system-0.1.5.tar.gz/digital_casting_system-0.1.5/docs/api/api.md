# Architecture

TODO: Add the architecture

```markdown
---
CLASS NAME
---
`Class Name`
`Function Name`
args:
return:

```

# API 
## hal (hardware abstraction layer)

a hardware abstraction layer (HAL) is a layer of programming that allows a computer operating system to interact with a hardware device at a general or abstract level rather than at a detailed hardware level. 

In general, the HAL is the layer of a programming that is close to the physical hardware, but allows a device driver to be written for a specific hardware device. The HAL provides a consistent interface for hardware components, and provides a layer of protection between the operating system and the hardware.


### PLC
### Device
### Interface

## abb_rob
### AbbConfig
### DcsRosClient

## data_processing

## gui

## utilities

