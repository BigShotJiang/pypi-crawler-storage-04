# dcs.infrastructure.config_manager

::: dcs.infrastructure.config_manager
    options:
      show_source: false
      show_root_heading: false
