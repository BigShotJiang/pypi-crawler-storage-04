# dcs.robot.abb_config

::: dcs.robot.abb_config
    options:
      show_source: false
      show_root_heading: false
