
{%
    include-markdown "../README.md"
    start='<!-- PROJECT USAGE -->'
    end='<!-- PROJECT DEVELOPMENT -->'
%}
