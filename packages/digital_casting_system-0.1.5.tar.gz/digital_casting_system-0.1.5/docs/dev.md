
{%
    include-markdown "../README.md"
    start='<!-- PROJECT DEVELOPMENT -->'
    end='<!-- Misc -->'
%}
