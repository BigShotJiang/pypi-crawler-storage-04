{%
    include-markdown "../README.md"
    start='<!-- PROJECT SHIELDS -->'
    end='<!-- PROJECT USAGE -->'
%}
