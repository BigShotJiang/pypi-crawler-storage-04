"""Digital Casting System (DCS) - A Python-based robotic digital casting control system."""

__author__ = ["Wei-Ting Chen"]
__copyright__ = "2024 FFMA"
__license__ = "MIT License"
__email__ = "chenwei@arch.ethz.ch"
__version__ = "0.1.5"
