### Global data from PLC "

```json

"inline_mixer":
"id":"100",
"Input":[
  { "id":"",
    "var_name": "",
    "var_name_IN" : "",
    "type":"",
    "active":true
  },
],
```
