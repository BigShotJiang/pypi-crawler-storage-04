"""Infrastructure layer for digital casting system."""

from .config_manager import ConfigManager

__all__ = ["ConfigManager"]
