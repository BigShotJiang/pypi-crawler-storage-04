# Authors

- WeiTingChen <<chenw@usi.ch>> <<chenwei@arch.ethz.ch>> [@WeiTing1991](https://github.com/WeiTing1991)

<br>

# Contributors

- Seyma Gürel <sguerel@ethz.ch>


<br>

> This package was created under [USI-FMAA](https://github.com/USI-FMAA) and [ETHZurich DFab](https://dfab.ch/)
