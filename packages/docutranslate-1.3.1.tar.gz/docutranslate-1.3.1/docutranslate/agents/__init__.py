# SPDX-FileCopyrightText: 2025 QinHan
# SPDX-License-Identifier: MPL-2.0

from .agent import Agent, AgentConfig
from .markdown_agent import  MDTranslateAgent
