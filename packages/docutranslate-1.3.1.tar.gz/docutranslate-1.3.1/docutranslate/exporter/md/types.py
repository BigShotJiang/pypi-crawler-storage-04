# SPDX-FileCopyrightText: 2025 QinHan
# SPDX-License-Identifier: MPL-2.0
from typing import Literal

ConvertEngineType = Literal["mineru", "docling", "identity"]