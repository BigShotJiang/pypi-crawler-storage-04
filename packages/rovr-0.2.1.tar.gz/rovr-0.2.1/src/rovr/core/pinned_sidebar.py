from os import path
from typing import ClassVar

from textual import events, on, work
from textual.binding import Binding, BindingType
from textual.widgets import Input, OptionList
from textual.widgets.option_list import Option

from rovr import utils
from rovr.exceptions import FolderNotFileError
from rovr.options import PinnedSidebarOption
from rovr.utils import config


class PinnedSidebar(OptionList, inherit_bindings=False):
    # Just so that I can disable space
    BINDINGS: ClassVar[list[BindingType]] = (
        [
            Binding(bind, "cursor_down", "Down", show=False)
            for bind in config["keybinds"]["down"]
        ]
        + [
            Binding(bind, "last", "Last", show=False)
            for bind in config["keybinds"]["end"]
        ]
        + [
            Binding(bind, "select", "Select", show=False)
            for bind in config["keybinds"]["down_tree"]
        ]
        + [
            Binding(bind, "first", "First", show=False)
            for bind in config["keybinds"]["home"]
        ]
        + [
            Binding(bind, "page_down", "Page Down", show=False)
            for bind in config["keybinds"]["page_down"]
        ]
        + [
            Binding(bind, "page_up", "Page Up", show=False)
            for bind in config["keybinds"]["page_up"]
        ]
        + [
            Binding(bind, "cursor_up", "Up", show=False)
            for bind in config["keybinds"]["up"]
        ]
    )

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)

    @work(exclusive=True)
    async def reload_pins(self) -> None:
        """Reload pins shown

        Raises:
            FolderNotFileError: If the pin location is a file, and not a folder.
        """
        # be extra sure
        available_pins = utils.load_pins()
        pins = available_pins["pins"]
        default = available_pins["default"]
        self.list_of_options = []
        print(f"Reloading pins: {available_pins}")
        print(f"Reloading default folders: {default}")
        self.clear_options()
        for default_folder in default:
            if not path.isdir(default_folder["path"]):
                if path.exists(default_folder["path"]):
                    raise FolderNotFileError(
                        f"Expected a folder but got a file: {default_folder['path']}"
                    )
                else:
                    pass
            if "icon" in default_folder:
                icon = default_folder["icon"]
            elif path.isdir(default_folder["path"]):
                icon = utils.get_icon_for_folder(default_folder["name"])
            else:
                icon = utils.get_icon_for_file(default_folder["name"])
            self.list_of_options.append(
                PinnedSidebarOption(
                    icon=icon,
                    label=default_folder["name"],
                    id=f"{utils.compress(default_folder['path'])}-default",
                )
            )
        self.list_of_options.append(
            Option(" Pinned", id="pinned-header", disabled=True)
        )
        for pin in pins:
            try:
                pin["path"]
            except KeyError:
                break
            if not path.isdir(pin["path"]):
                if path.exists(pin["path"]):
                    raise FolderNotFileError(
                        f"Expected a folder but got a file: {pin['path']}"
                    )
                else:
                    pass
            if "icon" in pin:
                icon = pin["icon"]
            elif path.isdir(pin["path"]):
                icon = utils.get_icon_for_folder(pin["name"])
            else:
                icon = utils.get_icon_for_file(pin["name"])
            self.list_of_options.append(
                PinnedSidebarOption(
                    icon=icon,
                    label=pin["name"],
                    id=f"{utils.compress(pin['path'])}-pinned",
                )
            )
        self.list_of_options.append(
            Option(" Drives", id="drives-header", disabled=True)
        )
        drives = utils.get_mounted_drives()
        for drive in drives:
            self.list_of_options.append(
                PinnedSidebarOption(
                    icon=utils.get_icon("folder", ":/drive:"),
                    label=drive,
                    id=f"{utils.compress(drive)}-drives",
                )
            )
        self.add_options(self.list_of_options)

    async def on_mount(self) -> None:
        """Reload the pinned files from the config."""
        self.input: Input = self.parent.query_one(Input)
        self.reload_pins()

    @on(events.Enter)
    @work
    async def show_input_when_hover(self, event: events.Focus) -> None:
        self.input.add_class("show")

    @on(events.Leave)
    @work
    async def hide_input_when_leave(self, event: events.Leave) -> None:
        self.input.remove_class("show")

    async def on_option_list_option_selected(
        self, event: OptionList.OptionSelected
    ) -> None:
        """Handle the selection of an option in the pinned sidebar.
        Args:
            event (OptionList.OptionSelected): The event

        Raises:
            FolderNotFileError: If the pin found is a file and not a folder.
        """
        selected_option = event.option
        # Get the file path from the option id
        assert selected_option.id is not None
        file_path = utils.decompress(selected_option.id.split("-")[0])
        if not path.isdir(file_path):
            if path.exists(file_path):
                raise FolderNotFileError(
                    f"Expected a folder but got a file: {file_path}"
                )
            else:
                return
        self.app.cd(file_path)
        self.app.query_one("#file_list").focus()
        self.input.clear()
        self.clear_options()
        self.add_options(self.list_of_options)

    def on_key(self, event: events.Key) -> None:
        if event.key in config["keybinds"]["focus_search"]:
            self.input.focus()
