from .main import QTextEditLogger
