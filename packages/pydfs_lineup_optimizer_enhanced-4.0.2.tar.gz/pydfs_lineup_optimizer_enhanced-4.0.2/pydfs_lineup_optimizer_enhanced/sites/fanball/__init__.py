from pydfs_lineup_optimizer_enhanced.sites.fanball.settings import FanBallFootballSettings

__all__ = [
    'FanBallFootballSettings',
]
