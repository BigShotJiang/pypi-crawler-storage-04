"""
Name : mytst.py.py
Author  : 写上自己的名字
Contact : 邮箱地址
Time    : 2024-04-24 22:04
Desc:
"""


def my_test_1():
    print("hello world!")
    pass
