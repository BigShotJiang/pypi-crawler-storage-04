#!/usr/bin/env python3
"""
Setup script for ClipStack - A powerful clipboard manager for developers.
"""

from setuptools import setup

if __name__ == "__main__":
    setup()
