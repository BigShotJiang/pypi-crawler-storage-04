# CHANGELOG

<!-- version list -->

## v1.0.1 (2025-08-30)

### Bug Fixes

- **ci**: Set correct pypi repository-url
  ([`6cc6791`](https://github.com/sidisinsane/scaffold-kit/commit/6cc67910d190b72469708748ff2b5067677f85d2))


## v1.0.0 (2025-08-30)

- Initial Release
