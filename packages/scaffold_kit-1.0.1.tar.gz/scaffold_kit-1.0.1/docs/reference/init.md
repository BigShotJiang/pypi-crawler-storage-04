---
title: scaffold_kit.init
weight: 3
---

::: scaffold_kit.init
