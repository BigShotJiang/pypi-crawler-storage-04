---
title: scaffold_kit.config
weight: 7
---

::: scaffold_kit.config
