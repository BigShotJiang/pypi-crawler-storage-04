---
title: Reference
weight: 1
---

```asciidoc
--8<-- "docs/trees/tree-src-scaffold-kit-examples.txt"
```

`.scaffoldkitrc.yaml`, `scaffoldkitrc.yaml`, `.scaffoldkitrc`

```yaml
--8<-- "src/scaffold_kit/examples/configs/.scaffoldkitrc.yaml"
```

`.scaffoldkitrc.json`, `scaffoldkitrc.json`

```json
--8<-- "src/scaffold_kit/examples/configs/.scaffoldkitrc.json"
```
