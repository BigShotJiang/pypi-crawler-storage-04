scaffold\_kit.utils package
===========================

Submodules
----------

scaffold\_kit.utils.ignore\_parser module
-----------------------------------------

.. automodule:: scaffold_kit.utils.ignore_parser
   :members:
   :show-inheritance:
   :undoc-members:

scaffold\_kit.utils.pattern\_processor module
---------------------------------------------

.. automodule:: scaffold_kit.utils.pattern_processor
   :members:
   :show-inheritance:
   :undoc-members:

scaffold\_kit.utils.string\_utils module
----------------------------------------

.. automodule:: scaffold_kit.utils.string_utils
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: scaffold_kit.utils
   :members:
   :show-inheritance:
   :undoc-members:
