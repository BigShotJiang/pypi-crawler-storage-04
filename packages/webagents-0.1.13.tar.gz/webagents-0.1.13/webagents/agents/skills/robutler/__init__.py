"""
Robutler Platform Skills

Skills that integrate with Robutler platform services.
"""

from .crm import CRMAnalyticsSkill

__all__ = [
    'CRMAnalyticsSkill',
]