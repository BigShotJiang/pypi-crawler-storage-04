from .hooks import VisaionPipelineSwitchHook
__all__ = ['VisaionPipelineSwitchHook']