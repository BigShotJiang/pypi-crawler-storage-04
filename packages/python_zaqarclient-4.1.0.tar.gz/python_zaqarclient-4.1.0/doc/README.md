Zaqar service's python library documentation
============================================
