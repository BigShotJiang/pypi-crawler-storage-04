from fastembed.image.image_embedding import ImageEmbedding

__all__ = ["ImageEmbedding"]
