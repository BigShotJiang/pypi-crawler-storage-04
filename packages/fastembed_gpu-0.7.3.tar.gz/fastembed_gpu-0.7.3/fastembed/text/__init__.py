from fastembed.text.text_embedding import TextEmbedding

__all__ = ["TextEmbedding"]
