from fastembed.late_interaction.late_interaction_text_embedding import (
    LateInteractionTextEmbedding,
)

__all__ = ["LateInteractionTextEmbedding"]
