from fastembed.late_interaction_multimodal.late_interaction_multimodal_embedding import (
    LateInteractionMultimodalEmbedding,
)

__all__ = ["LateInteractionMultimodalEmbedding"]
