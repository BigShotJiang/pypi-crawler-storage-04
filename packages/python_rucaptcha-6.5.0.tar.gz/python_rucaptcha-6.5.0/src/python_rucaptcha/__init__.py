from python_rucaptcha.__version__ import __version__  # noqa
