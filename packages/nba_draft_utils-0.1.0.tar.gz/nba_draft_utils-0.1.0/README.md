# nba-draft-utils

Utilities for NBA draft probability modeling (data loading, preprocessing, model training/evaluation, and Kaggle submission).

## Install (local)
```bash
pip install -e .
