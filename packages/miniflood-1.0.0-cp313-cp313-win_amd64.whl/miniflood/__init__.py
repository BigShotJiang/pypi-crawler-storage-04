#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
init
To do:
@author: wly
"""

# src/__init__.py

from .version import __version__

__all__ = [
  '__version__',
]