class InvalidEmailUrlScheme(Exception):
    pass
