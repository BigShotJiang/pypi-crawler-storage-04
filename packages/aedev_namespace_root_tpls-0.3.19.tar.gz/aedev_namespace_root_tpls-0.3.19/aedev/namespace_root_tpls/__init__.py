""" templates and outsourced files for namespace root projects. """

__version__ = '0.3.19'
