### Discord
`https://discord.gg/Bf3dpBRJHj`
### About lib
`Fix Amino.py 1.2.17`
### How to install?
`pip install amino.fix`
### API Reference
[Read the Docs Link](https://aminopy.readthedocs.io/en/latest/)