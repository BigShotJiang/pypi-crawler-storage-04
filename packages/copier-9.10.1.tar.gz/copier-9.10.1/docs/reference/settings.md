::: copier.settings
