"""Request schemas for the CommonGrants API."""

from .opportunity import OpportunitySearchRequest

__all__ = [
    "OpportunitySearchRequest",
]
