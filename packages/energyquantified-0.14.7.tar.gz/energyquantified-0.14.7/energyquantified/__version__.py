# Basic package info

__title__ = "energyquantified"
__description__ = "Energy Quantified Time series API client."
__url__ = "https://github.com/energyquantified/eq-python-client"
__version__ = "0.14.7"
__author__ = "Energy Quantified AS"
__license__ = "Apache License 2.0"
__copyright__ = "Copyright \u00A9 Energy Quantified AS"
