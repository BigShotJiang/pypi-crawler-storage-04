class _BaseServerMessage:

    @staticmethod
    def from_message(_):
        raise NotImplementedError