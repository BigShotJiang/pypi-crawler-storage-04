def test_package_imports():
    import sc_orchestrator
