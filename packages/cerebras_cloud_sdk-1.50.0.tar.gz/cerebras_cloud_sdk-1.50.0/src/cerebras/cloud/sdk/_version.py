# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

__title__ = "cerebras.cloud.sdk"
__version__ = "1.50.0"  # x-release-please-version
