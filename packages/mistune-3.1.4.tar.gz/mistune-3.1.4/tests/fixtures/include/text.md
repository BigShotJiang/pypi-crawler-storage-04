# Include

.. include:: ./text.md

.. include:: ./not-exist.md

.. include:: ./text.html
   :encoding: utf-8

.. include:: ./hello.md

.. include:: ../rst_toc.txt
