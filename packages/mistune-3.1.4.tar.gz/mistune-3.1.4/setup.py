from setuptools import setup

setup(name="mistune")
