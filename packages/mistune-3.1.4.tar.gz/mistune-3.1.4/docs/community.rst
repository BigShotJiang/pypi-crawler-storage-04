Community Extensions
====================

Here is the list of plugins and directives created by the community.

* `mistune-telegram <https://github.com/impocode/mistune-telegram>`_ - Plugin mistune for converting Markdown into Telegram format.
* `mistune-json <https://github.com/fernandonino/mistune-json>`_ - Plugin for converting Markdown into HTML-based JSON objects.
