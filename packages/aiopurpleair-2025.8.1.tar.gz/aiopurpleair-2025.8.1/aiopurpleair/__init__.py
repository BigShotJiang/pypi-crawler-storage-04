"""Define the aiopurpleair package."""

from .api import API  # noqa
