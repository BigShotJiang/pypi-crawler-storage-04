
Changelog
=========

0.0.0 (2024-03-24)
------------------

* First release on PyPI.
