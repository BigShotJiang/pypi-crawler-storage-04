class SyncError(Exception):
    """Raised for general errors during the sync process."""
