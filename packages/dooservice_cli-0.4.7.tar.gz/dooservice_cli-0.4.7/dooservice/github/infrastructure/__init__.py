"""GitHub infrastructure layer."""
