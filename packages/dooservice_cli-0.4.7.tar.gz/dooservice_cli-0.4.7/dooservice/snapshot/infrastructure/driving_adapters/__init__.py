"""Snapshot driving adapters."""
