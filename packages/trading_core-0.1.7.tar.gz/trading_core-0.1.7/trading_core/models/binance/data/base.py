from sqlalchemy.orm import declarative_base
ExchangeInfoSymbol = declarative_base()