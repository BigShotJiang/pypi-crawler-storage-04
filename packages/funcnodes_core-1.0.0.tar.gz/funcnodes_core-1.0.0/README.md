Core package for funcnodes.
for detailed instructions go to the funcnodes repo
