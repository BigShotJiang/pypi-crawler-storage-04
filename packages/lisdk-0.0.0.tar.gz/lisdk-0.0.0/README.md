# lisdk Package

This is a simple example package. You can use
[GitHub-flavored Markdown](https://guides.github.com/features/mastering-markdown/)
to write your content.

## First package
[PACKAGING-METHOD](https://packaging.python.org/en/latest/tutorials/packaging-projects/)

## Update package
1. 删除dist目录
2. python3 -m build
3. twine upload dist/*