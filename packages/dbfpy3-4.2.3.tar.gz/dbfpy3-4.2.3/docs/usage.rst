=====
Usage
=====

To use dbfpy3 in a project::

    import dbfpy3
