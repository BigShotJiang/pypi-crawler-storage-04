#!/usr/bin/env python

"""Tests for `dbfpy3` package."""


import unittest

from dbfpy3 import dbfpy3


class TestDbfpy3(unittest.TestCase):
    """Tests for `dbfpy3` package."""

    def setUp(self):
        """Set up test fixtures, if any."""

    def tearDown(self):
        """Tear down test fixtures, if any."""

    def test_000_something(self):
        """Test something."""
