**Italiano**

Suggeriamo di eseguire l'azione pianificata "Aggiornamento tassi di
cambio (OCA) giornaliero" alla fine del giorno, per essere sicuri che la
Banca d'Italia abbia aggiornato i dati.

**English**

We suggest to execute the "Currency Rates Update (OCA) daily" cron at
the end of the day, to be sure that Bank of Italy updated the data.
