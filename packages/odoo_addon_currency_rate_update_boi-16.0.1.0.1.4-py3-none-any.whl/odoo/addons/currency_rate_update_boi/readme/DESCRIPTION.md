**Italiano**

Questo modulo aggiunge la [Banca
d'Italia](https://tassidicambio.bancaditalia.it/) come fornitore dei
tassi di cambio.

Le istruzioni per l'esportazione dei dati sono disponibili all'indirizzo
<https://tassidicambio.bancaditalia.it/terzevalute-wf-ui-web/assets/files/Operating_Instructions.pdf>

I tassi di cambio sono esportati nel formato JSON.

**English**

This module adds [Bank of Italy](https://tassidicambio.bancaditalia.it/)
currency exchange rates provider.

Data export instructions are available at
<https://tassidicambio.bancaditalia.it/terzevalute-wf-ui-web/assets/files/Operating_Instructions.pdf>

Exchange rates are exported in JSON format.
