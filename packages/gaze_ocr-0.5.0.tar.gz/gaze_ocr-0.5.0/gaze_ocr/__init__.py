from ._gaze_ocr import *  # noqa: F403
