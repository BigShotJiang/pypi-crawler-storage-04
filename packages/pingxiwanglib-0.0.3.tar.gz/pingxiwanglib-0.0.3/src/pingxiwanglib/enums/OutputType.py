from enum import Enum


class OutputType(Enum):
    Console = "console",
    File = "file"