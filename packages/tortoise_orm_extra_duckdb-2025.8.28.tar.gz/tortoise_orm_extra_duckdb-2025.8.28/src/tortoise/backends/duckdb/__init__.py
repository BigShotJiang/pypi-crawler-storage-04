# -*- coding: utf-8 -*-

from .client import DuckDBClient

client_class = DuckDBClient
