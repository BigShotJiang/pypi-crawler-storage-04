from .pavdedutor import deduzivel, deduzivel_corrigido, patologias
