# qqtools

A small tool package for qq


# TODO
qsearch

# longterm 
qplot
