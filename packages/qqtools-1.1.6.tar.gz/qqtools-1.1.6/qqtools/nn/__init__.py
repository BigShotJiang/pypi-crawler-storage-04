from qqtools.torch.nn import DoNothing, Donothing, donothing, get_nonlinear, qMLP
