# Anyforce Runtime

## Lint

- Lint [flask8](https://flake8.pycqa.org/en/latest/)
- Type Check [pyright](https://github.com/microsoft/pyright)
