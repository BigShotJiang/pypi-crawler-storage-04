#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on 12/08/2025 16:16:33

@author: psakic
"""

SPEED_OF_LIGHT = 299792458.0  # m/s

