### desactivated MAYOBS25 230925
#from scipy.signal import butter, lfilter, freqz
