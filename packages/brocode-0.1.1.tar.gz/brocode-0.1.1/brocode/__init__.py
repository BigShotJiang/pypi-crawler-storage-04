"""BroCode package initialization.

This package provides a CLI tool for managing and running LLM-based chat agents.
"""

__version__ = '0.1.1'