# OCPI Pydantic

OCPI (Open Charge Point Interface) Pydantic models.

⚠️ Work in progress. Not production ready. ⚠️