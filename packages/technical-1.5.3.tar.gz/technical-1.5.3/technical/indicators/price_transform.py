"""
Cycle indicators
"""

########################################
#
# Price Transform Functions
#

# AVGPRICE             Average Price
# MEDPRICE             Median Price
# TYPPRICE             Typical Price
# WCLPRICE             Weighted Close Price
