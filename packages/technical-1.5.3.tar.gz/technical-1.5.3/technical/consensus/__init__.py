from technical.consensus.consensus import Consensus  # noqa: F401
from technical.consensus.movingaverage import MovingAverageConsensus  # noqa: F401
from technical.consensus.oscillator import OscillatorConsensus  # noqa: F401
