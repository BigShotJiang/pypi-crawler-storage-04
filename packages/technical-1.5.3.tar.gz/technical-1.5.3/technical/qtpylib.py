# Import here for easy access
# Keep the original file in vendor to make the origin clear
from technical.vendor.qtpylib.indicators import *  # noqa
