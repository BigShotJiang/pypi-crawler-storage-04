---
meta:
    title: Data Rods
    description:
layout: component
---

```html:preview
<terra-data-rods
    variable-entry-id="NLDAS_FORA0125_H_2_0_CRainf_frac"
    location="38.96, -78.75"
    start-date="2013-10-29"
    end-date="2013-11-29"
></terra-data-rods>
```

## Examples

### First Example

TODO

### Second Example

TODO

[component-metadata:terra-data-rods]
