"""
https://slurm.schedmd.com/rest_api.html
"""
