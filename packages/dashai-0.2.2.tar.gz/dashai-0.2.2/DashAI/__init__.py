from DashAI.__main__ import run

if __name__ == "__main__":
    run()
