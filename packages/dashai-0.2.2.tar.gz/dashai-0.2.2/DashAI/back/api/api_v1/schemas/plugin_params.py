from typing import List

from pydantic import BaseModel

from DashAI.back.core.enums.plugin_tags import PluginTag
from DashAI.back.core.enums.status import PluginStatus


class TagParams(BaseModel):
    name: PluginTag


class PluginParams(BaseModel):
    name: str
    author: str
    installed_version: str
    lastest_version: str
    tags: List[TagParams]
    summary: str
    description: str
    description_content_type: str


class PluginUpdateParams(BaseModel):
    new_status: PluginStatus
