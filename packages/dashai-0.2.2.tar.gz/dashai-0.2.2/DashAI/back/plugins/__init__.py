# flake8: noqa
from DashAI.back.plugins.utils import get_plugins_from_pypi
