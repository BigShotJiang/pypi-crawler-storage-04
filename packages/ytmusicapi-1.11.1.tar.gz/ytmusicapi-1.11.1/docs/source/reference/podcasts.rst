Podcasts
--------

.. currentmodule:: ytmusicapi
.. automethod:: YTMusic.get_channel
.. automethod:: YTMusic.get_channel_episodes
.. automethod:: YTMusic.get_podcast
.. automethod:: YTMusic.get_episode
.. automethod:: YTMusic.get_episodes_playlist
