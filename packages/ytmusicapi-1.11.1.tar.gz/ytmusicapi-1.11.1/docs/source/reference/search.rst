Search
------

.. currentmodule:: ytmusicapi
.. automethod:: YTMusic.search
.. automethod:: YTMusic.get_search_suggestions
.. automethod:: YTMusic.remove_search_suggestions
