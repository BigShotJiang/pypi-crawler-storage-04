Setup
-----

See also the :doc:`Setup <../setup/index>` page

.. currentmodule:: ytmusicapi
.. autofunction:: setup
.. autofunction:: setup_oauth
