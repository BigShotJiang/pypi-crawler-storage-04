# Copyright (c) Alibaba, Inc. and its affiliates.
from swift.ui.llm_train.quantization import Quantization


class RLHFQuantization(Quantization):

    group = 'llm_rlhf'
