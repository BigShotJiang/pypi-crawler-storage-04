# Copyright (c) Alibaba, Inc. and its affiliates.
from swift.ui.llm_train.lora import LoRA


class RLHFLoRA(LoRA):

    group = 'llm_rlhf'
