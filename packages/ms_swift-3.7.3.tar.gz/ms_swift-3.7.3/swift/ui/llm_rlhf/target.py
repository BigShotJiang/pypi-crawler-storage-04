# Copyright (c) Alibaba, Inc. and its affiliates.
from swift.ui.llm_train.target import Target


class RLHFTarget(Target):

    group = 'llm_rlhf'
