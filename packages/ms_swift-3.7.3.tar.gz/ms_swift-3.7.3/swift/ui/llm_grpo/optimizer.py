# Copyright (c) Alibaba, Inc. and its affiliates.
from swift.ui.llm_train.optimizer import Optimizer


class GRPOOptimizer(Optimizer):

    group = 'llm_grpo'
