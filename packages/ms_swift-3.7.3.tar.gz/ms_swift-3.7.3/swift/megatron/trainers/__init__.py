# Copyright (c) Alibaba, Inc. and its affiliates.
from .dpo_trainer import MegatronDPOTrainer
from .trainer import MegatronTrainer
