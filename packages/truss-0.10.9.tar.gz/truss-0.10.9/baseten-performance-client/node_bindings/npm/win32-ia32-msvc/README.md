# `@basetenlabs/performance-client-win32-ia32-msvc`

This is the **i686-pc-windows-msvc** binary for `@basetenlabs/performance-client`
