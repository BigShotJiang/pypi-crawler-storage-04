from enum import Enum


class CompactorVersion(str, Enum):
    V1 = "V1"
    V2 = "V2"
