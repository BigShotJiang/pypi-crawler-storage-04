"""
Main entry point for the libgossip package
"""

def main():
    print("libgossip Python package")
    print("This is a Python binding for the libgossip C++ library")
    print("Import with: import libgossip")

if __name__ == "__main__":
    main()