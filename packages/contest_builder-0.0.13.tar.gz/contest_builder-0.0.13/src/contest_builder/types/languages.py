from enum import Enum


class Languages(Enum):
    CPP = "cpp"
    PYTHON = "python"

