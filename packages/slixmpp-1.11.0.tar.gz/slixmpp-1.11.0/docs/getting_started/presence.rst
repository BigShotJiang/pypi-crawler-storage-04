Manage Presence Subscriptions
=============================
