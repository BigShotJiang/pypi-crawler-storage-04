"""Testing for builder-io."""


def test_dummy() -> None:
    """Dummy test."""
