# CHANGELOG


## v0.2.0 (2025-08-28)

### Features

- `get_paths` util
  ([`336923c`](https://github.com/MicaelJarniac/builder-io/commit/336923c6f2f65abf973d75529ddac20bbb4f6b26))


## v0.1.0 (2025-08-27)

### Chores

- Basic layout
  ([`e7fa201`](https://github.com/MicaelJarniac/builder-io/commit/e7fa20195a800bb7d11acea7174cd82aea517100))

### Features

- Basic functionality
  ([`13e9945`](https://github.com/MicaelJarniac/builder-io/commit/13e9945d6aaa1d5287253a7ce841aeb19f521296))


## v0.0.0 (2025-08-21)

### Chores

- Empty project template
  ([`7c2510b`](https://github.com/MicaelJarniac/builder-io/commit/7c2510bf916f0ec6d16285231d1be6e787dde034))
