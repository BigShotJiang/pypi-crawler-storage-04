"""init file"""
from .flow_rife import FlowRife
