# pylint: disable=all
"""init file"""
from .tasks import BaseModel, DetectionModel, SegmentationModel
