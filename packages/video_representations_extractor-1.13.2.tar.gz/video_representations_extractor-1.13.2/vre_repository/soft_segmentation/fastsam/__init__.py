# pylint: disable=all
"""init file"""
from .fastsam import FastSam
