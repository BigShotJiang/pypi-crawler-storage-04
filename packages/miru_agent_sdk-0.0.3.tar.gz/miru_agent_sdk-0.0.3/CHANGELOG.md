# Changelog

## 0.0.3 (2025-09-02)

Full Changelog: [v0.0.2...v0.0.3](https://github.com/miruml/python-agent-sdk/compare/v0.0.2...v0.0.3)

### Features

* **api:** update via SDK Studio ([09a3ac8](https://github.com/miruml/python-agent-sdk/commit/09a3ac812ec658482a0d0ce9613433d3ce38d9b5))


### Bug Fixes

* avoid newer type syntax ([109c894](https://github.com/miruml/python-agent-sdk/commit/109c8946281a861d2ebc74ddd4656ae45c1714d7))


### Chores

* **internal:** add Sequence related utils ([e324172](https://github.com/miruml/python-agent-sdk/commit/e3241722ac3c30c92627710c8876327abba33deb))
* **internal:** update pyright exclude list ([3e1a631](https://github.com/miruml/python-agent-sdk/commit/3e1a631c29d33f8e3af40665f12b7359af13c3b7))

## 0.0.2 (2025-08-26)

Full Changelog: [v0.0.1...v0.0.2](https://github.com/miruml/python-agent-sdk/compare/v0.0.1...v0.0.2)

### Features

* adjust client to connect over the unix socket ([2e820b2](https://github.com/miruml/python-agent-sdk/commit/2e820b215ae5aff5546eb746e55e96c0e70cae6e))
* **api:** update via SDK Studio ([3531015](https://github.com/miruml/python-agent-sdk/commit/353101533aff094a902eabf9f543341f86e5b2b8))
* **api:** update via SDK Studio ([599a293](https://github.com/miruml/python-agent-sdk/commit/599a293911f28f1e8d39f4e46f1c838b637a1535))
* **api:** update via SDK Studio ([6df3e72](https://github.com/miruml/python-agent-sdk/commit/6df3e720d9b152339b2ba1b36a52dcf24a04ba7e))
* **api:** update via SDK Studio ([c8b85e4](https://github.com/miruml/python-agent-sdk/commit/c8b85e465b83ff4d971533cec98d9e80224a9b38))

## 0.0.1 (2025-08-26)

Full Changelog: [v0.1.0...v0.0.1](https://github.com/miruml/python-agent-sdk/compare/v0.1.0...v0.0.1)

### Features

* **api:** update via SDK Studio ([e6681a4](https://github.com/miruml/python-agent-sdk/commit/e6681a4aee46d96aad90d8271bdd4977ab93cb89))
* **api:** update via SDK Studio ([e5e488b](https://github.com/miruml/python-agent-sdk/commit/e5e488b38fa1b68b2c48869ac4a85a798e733b58))
* **api:** update via SDK Studio ([a1abe5b](https://github.com/miruml/python-agent-sdk/commit/a1abe5b8de243b7c107543c07a0d1033aa6a05c3))
* **api:** update via SDK Studio ([06bef97](https://github.com/miruml/python-agent-sdk/commit/06bef9755fd2db20aaf0e71073c9f0e27fa6a45d))
* **api:** update via SDK Studio ([24498b4](https://github.com/miruml/python-agent-sdk/commit/24498b480190f443c84a637ccdd32119966b8fd5))
* **api:** update via SDK Studio ([d95fe9d](https://github.com/miruml/python-agent-sdk/commit/d95fe9d1240958316b08e3a2f98fb06b0eb5af0e))


### Chores

* update SDK settings ([82fc32b](https://github.com/miruml/python-agent-sdk/commit/82fc32bf575c48ba7e67a030e33c24bb7d07c40d))
* update SDK settings ([c06d72b](https://github.com/miruml/python-agent-sdk/commit/c06d72bf4db17caf5dd6b7015db5880b565b6f1e))

## 0.1.0 (2025-08-26)

Full Changelog: [v0.0.1...v0.1.0](https://github.com/miruml/python-agent-sdk/compare/v0.0.1...v0.1.0)

### Chores

* update SDK settings ([82fc32b](https://github.com/miruml/python-agent-sdk/commit/82fc32bf575c48ba7e67a030e33c24bb7d07c40d))
* update SDK settings ([c06d72b](https://github.com/miruml/python-agent-sdk/commit/c06d72bf4db17caf5dd6b7015db5880b565b6f1e))
