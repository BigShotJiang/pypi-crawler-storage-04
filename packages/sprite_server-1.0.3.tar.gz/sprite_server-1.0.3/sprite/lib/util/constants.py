PROJECT_VERSION = '1.0.3'
PROJECT_DESCRIPTION = 'A simple server for uploading and downloading files.'

PROJECT_AUTHOR = 'Joey'
PROJECT_AUTHOR_EMAIL = 'zhaojingyu126@126.com'