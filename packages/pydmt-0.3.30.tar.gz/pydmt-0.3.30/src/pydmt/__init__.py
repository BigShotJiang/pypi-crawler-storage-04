"""
Initialize the module
"""
