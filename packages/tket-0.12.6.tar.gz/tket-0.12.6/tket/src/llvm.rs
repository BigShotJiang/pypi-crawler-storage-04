//! `hugr-llvm` codegen extensions for extensions defined in `tket`.
pub mod bool;
pub mod rotation;
