pygnosis.composed_indicator module
==================================

.. automodule:: pygnosis.composed_indicator
   :members:
   :undoc-members:
   :show-inheritance:
