# Forex and Crypto Prefixes are no longer needed on the streaming API
STREAM_CLUSTER_PREFIX_MAP = {"options": "O:", "forex": "C:", "crypto": "X:", "indices": "I:"}
