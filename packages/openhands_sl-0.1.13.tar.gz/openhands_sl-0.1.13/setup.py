import pathlib
import setuptools
import pkg_resources

# The directory containing this file
HERE = pathlib.Path(__file__).parent

# The text of the README file
README = (HERE / "README.md").read_text(encoding='utf-8')

with pathlib.Path('docs/requirements.txt').open() as requirements_txt:
    install_requires = [
        str(requirement)
        for requirement
        in pkg_resources.parse_requirements(requirements_txt)
    ]

# Read meta-data
about = {}
exec(open('openhands/__version.py').read(), about)

# Install
setuptools.setup(
    name="openhands_sl",
    version=about["__version__"],
    description="👐OpenHands : Making Sign Language Recognition Accessible",
    long_description=README,
    long_description_content_type="text/markdown",
    url="https://openhands.ai4bharat.org",
    download_url="https://pypi.org/project/openhands_sl",
    project_urls={
        'Source': "https://github.com/AI4Bharat/OpenHands",
        'Issues': "https://github.com/AI4Bharat/OpenHands/issues",
        'Documentation': "https://openhands.readthedocs.io",
    },
    author="AI4Bhārat",
    # packages=["openhands"],
    packages=setuptools.find_packages(),
    # packages=setuptools.find_packages(exclude=("tests",)),
    include_package_data=True,
    package_data={
        'openhands': ['datasets/assets/**/*'],
    },
    install_requires=install_requires,
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Software Development :: Libraries"
    ],
)
