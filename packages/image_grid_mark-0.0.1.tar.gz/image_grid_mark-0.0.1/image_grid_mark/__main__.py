# coding: utf-8

from image_grid_mark.main import main


if __name__ == "__main__":
    main()
