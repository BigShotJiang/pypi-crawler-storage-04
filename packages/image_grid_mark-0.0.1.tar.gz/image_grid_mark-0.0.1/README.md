# image_grid_mark

Mark up a grid on the image.

![](img/preview.png)

