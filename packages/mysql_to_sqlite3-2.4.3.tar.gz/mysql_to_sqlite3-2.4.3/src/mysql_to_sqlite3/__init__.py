"""Utility to transfer data from MySQL to SQLite 3."""

__version__ = "2.4.3"

from .transporter import MySQLtoSQLite
