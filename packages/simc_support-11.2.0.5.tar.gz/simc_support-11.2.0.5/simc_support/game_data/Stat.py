import enum


class Stat(enum.Enum):
    STRENGTH = "str"
    AGILITY = "agi"
    INTELLECT = "int"
