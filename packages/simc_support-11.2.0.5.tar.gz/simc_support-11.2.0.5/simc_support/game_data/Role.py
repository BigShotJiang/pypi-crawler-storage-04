import enum


class Role(enum.Enum):
    MELEE = "melee"
    # MID_RANGED = "midranged"
    RANGED = "ranged"
