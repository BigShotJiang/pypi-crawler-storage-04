- [Tecnativa](https://www.tecnativa.com):
  - Víctor Martínez
  - Pedro M. Baeza

- `Quartile <https://www.quartile.co>`_:

  - Yoshi Tashiro
  - Aung Ko Ko Lin
