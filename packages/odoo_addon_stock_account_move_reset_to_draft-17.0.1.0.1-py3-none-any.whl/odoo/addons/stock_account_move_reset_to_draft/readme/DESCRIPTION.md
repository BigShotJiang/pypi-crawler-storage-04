This module allows a vendor bill to be reverted to draft status even
when an SVL (Stock Valuation Layer) record is created due to a price
difference between the receipt and the vendor bill, when inventory from
the receipt has yet to be consumed. When a vendor bill is reset to
draft, as applicable, a new SVL record is generated to offset the
valuation difference that was generated upon the bill's confirmation.
