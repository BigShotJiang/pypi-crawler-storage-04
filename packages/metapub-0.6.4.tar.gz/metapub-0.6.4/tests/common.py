import os 
CWD = os.path.dirname(os.path.realpath(__file__))

TEST_CACHEDIR = 'tests/cachedir'