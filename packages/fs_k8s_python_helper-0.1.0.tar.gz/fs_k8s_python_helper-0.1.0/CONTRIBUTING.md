# 贡献指南

感谢您对 `fs-k8s-python-helper` 项目的关注！我们欢迎所有形式的贡献。

## 开发环境设置

1. **克隆仓库**
   ```bash
   git clone https://git.firstshare.cn/devops/fs-k8s-python-helper.git
   cd fs-k8s-python-helper
   ```

2. **创建虚拟环境**
   ```bash
   python3 -m venv venv
   source venv/bin/activate  # Linux/macOS
   # 或
   venv\Scripts\activate  # Windows
   ```

3. **安装开发依赖**
   ```bash
   pip install -e .[dev]
   ```

## 开发流程

### 1. 创建功能分支
```bash
git checkout -b feature/your-feature-name
```

### 2. 编写代码
- 遵循 PEP 8 代码风格
- 添加适当的类型注解
- 编写清晰的文档字符串
- 确保代码通过所有测试

### 3. 运行测试
```bash
# 运行所有测试
pytest

# 运行测试并生成覆盖率报告
pytest --cov=fs_k8s_python_helper

# 运行代码格式化
black .
isort .
```

### 4. 提交代码
```bash
git add .
git commit -m "feat: 添加新功能描述"
```

### 5. 推送并创建合并请求
```bash
git push origin feature/your-feature-name
```

## 代码规范

### Python 代码风格
- 使用 [Black](https://black.readthedocs.io/) 进行代码格式化
- 使用 [isort](https://pycqa.github.io/isort/) 排序导入
- 遵循 PEP 8 规范

### 提交信息格式
我们使用 [约定式提交](https://www.conventionalcommits.org/zh-hans/) 格式：

- `feat:` 新功能
- `fix:` 修复 bug
- `docs:` 文档更新
- `style:` 代码格式调整
- `refactor:` 代码重构
- `test:` 测试相关
- `chore:` 构建过程或辅助工具的变动

### 测试要求
- 所有新功能必须包含测试
- 测试覆盖率不应低于 80%
- 确保所有测试通过

## 报告问题

如果您发现了 bug 或有功能建议，请：

1. 检查是否已有相关 issue
2. 创建新的 issue，包含：
   - 问题描述
   - 复现步骤
   - 期望行为
   - 实际行为
   - 环境信息（Python 版本、操作系统等）

## 功能请求

如果您有功能请求，请：

1. 检查是否已有相关讨论
2. 创建 issue 描述您的需求
3. 说明使用场景和预期效果

## 发布流程

1. 更新 `CHANGELOG.md`
2. 更新版本号（在 `fs_k8s_python_helper/__init__.py` 中）
3. 创建发布标签
4. 构建并发布到 PyPI

## 联系方式

如果您有任何问题，请通过以下方式联系我们：

- 创建 GitHub Issue
- 发送邮件至：wuzh@fxiaoke.com

感谢您的贡献！🎉
