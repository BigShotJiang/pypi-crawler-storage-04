NumberType = int | float
