.. _spkg_cppzmq:

cppzmq: Header-only C++ binding for libzmq
==========================================

Description
-----------

C++ binding for libzmq


License
-------

MIT


Upstream Contact
----------------

https://github.com/zeromq/cppzmq


Type
----

optional


Dependencies
------------

- :ref:`spkg_cmake`
- :ref:`spkg_ninja_build`
- :ref:`spkg_zeromq`

Version Information
-------------------

package-version.txt::

    4.11.0

Equivalent System Packages
--------------------------

(none known)
