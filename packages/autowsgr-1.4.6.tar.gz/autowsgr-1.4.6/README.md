<div align=center>
<img src="https://raw.githubusercontent.com/OpenWSGR/AutoWSGR/main/docs/logo.png">
</div>

# QQ 群炸了，新群 1062450071，入群口令本项目最新 commid hash 前六位。

## 项目简介

![Repo Size](https://img.shields.io/github/repo-size/OpenWSGR/AutoWSGR) ![Pypi Version](https://img.shields.io/pypi/v/autowsgr) ![Pypi Downloads](https://img.shields.io/pypi/dm/autowsgr) ![Github Issues](https://img.shields.io/github/issues/OpenWSGR/AutoWSGR) ![Github Last Commit](https://img.shields.io/github/last-commit/OpenWSGR/AutoWSGR) ![MIT licensed](https://img.shields.io/badge/license-MIT-brightgreen.svg)

用 python 与 c++ 实现的 战舰少女R 的自动化流水线 & 数据统计一体化脚本, 提供 `WSGR` 游戏级别接口以及部分图像和原子操作接口.

## 安装使用

**访问用户文档：**[https://docs-autowsgr.notion.site](https://docs-autowsgr.notion.site)


## 参与开发

欢迎有一定python基础的同学加入开发，共同完善这个项目。您可以实现新的功能，也可以改进现有功能，或者修复bug。如果您有好的想法，也可以提出issue或加qq群讨论。一些经过讨论确定需要实现的任务在 [Projects](https://github.com/orgs/OpenWSGR/projects/2) 中有列出，你可以从中选择能力之内的项目着手贡献。

开发前请仔细阅读 [贡献指南](.github/CONTRIBUTING.md) 和 [用户文档](https://docs-autowsgr.notion.site)。特别注意： 开发者请**不要从pypi安装autowsgr**，改为 [本地模式](https://docs-autowsgr.notion.site/2-AutoWSGR-efeb69811b544604b944d5b5727317a4) 安装。

本项目使用 [Lunar](https://github.com/0xWelt/Lunar) 进行代码自动审查，所有pr都有概率触发AI的评论。

## 贡献者

<a href="https://github.com/OpenWSGR/AutoWSGR/graphs/contributors">
  <img src="https://contrib.rocks/image?repo=OpenWSGR/AutoWSGR" />
</a>

## Star History

[![Star History Chart](https://api.star-history.com/svg?repos=OpenWSGR/AutoWSGR&type=Date)](https://star-history.com/#OpenWSGR/AutoWSGR&Date)
