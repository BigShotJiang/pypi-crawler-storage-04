#General Information

username: triplethreading
email: triplethreading@uah.edu

Etymology: Triple Threat is a stance in basketball, where a player who
has just received a pass, can immediatey shoot, dribble or pass. In we
switch a 'threat' to 'thread' we get triple threading.

Description: This is my initial triplethreading package.

