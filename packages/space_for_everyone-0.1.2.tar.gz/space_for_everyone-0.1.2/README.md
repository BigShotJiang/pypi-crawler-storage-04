# HOST

<img src="https://i.ibb.co/JW8JZzWn/logo-nobg.png" alt="space-for-everyone Logo" width="200" height="200">


![PyPI](https://img.shields.io/pypi/v/space-for-everyone)
![Python](https://img.shields.io/pypi/pyversions/space-for-everyone)
![License](https://img.shields.io/badge/License-MIT-blue)

Host anywhere and anytime — get **instant direct links** for your files

---

## Features

- Upload files to **Catbox.moe** directly.
- Supports optional **userhash** for account uploads.
- Copy returned link to clipboard using `--copy` (requires `pyperclip`).
- Configurable request **timeout**.
- Returns **direct URLs** for immediate sharing.

---

## Install

```bash
pip install space-for-everyone
```

> Make sure you have Python 3.8+ installed.

---

## Usage

Upload a single file and get the direct link:

```bash
host myfile.png
```

Upload a file and **copy the link to clipboard**:

```bash
host myfile.png --copy
```

Upload a file using your **userhash**:

```bash
host myfile.png --userhash YOUR_USERHASH
```

Set a custom **timeout** in seconds:

```bash
host myfile.png --timeout 120
```

---

## Demo

![Demo Screenshot](https://i.ibb.co/your-demo-link/demo.png)

Upload a file and instantly get the direct link in your terminal.

---

## Author

Sid & Kan — sofiyasenthilkumar@gmail.com

---

## License

This project is licensed under the **MIT License**. See the LICENSE file for details.

