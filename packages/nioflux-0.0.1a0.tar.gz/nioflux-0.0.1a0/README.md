# *NioFlux*

*A lightweight asynchronous scalable TCP frame protocol server.*
