ERROR_MESSAGES = {
    'missing': '필수 값을 확인해주세요.',
    'blank': '필수 값을 확인해주세요.',
}
