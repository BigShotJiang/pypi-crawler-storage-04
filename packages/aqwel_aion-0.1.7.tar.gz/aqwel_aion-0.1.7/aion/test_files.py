from unittest import TestCase


class Test(TestCase):
    def test_write_file(self):
        self.fail()
