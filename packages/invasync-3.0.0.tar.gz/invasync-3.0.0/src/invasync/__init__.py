FLASH_GALLERY_ENDPOINT = "https://api.space-invaders.com/flashinvaders_v3_pas_trop_predictif/api/gallery?uid="
MAP_URL = "https://invaders.code-rhapsodie.com"
MAP_RESTORE_ENDPOINT = f"{MAP_URL}/restore"
MAP_LOGIN_ENDPOINT = f"{MAP_URL}/login"

from .__main__ import main  # noqa: D104, F401
