from . import test_stock_split_picking_kit
