# DatasetBag Class

::: deriva_ml.dataset.dataset_bag
    handler: python
