# sage_setup: distribution = sagemath-topcom
# delvewheel: patch

from sage.all__sagemath_polyhedra import *
