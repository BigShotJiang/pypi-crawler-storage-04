selectolax.parser module
======================================

.. automodule:: selectolax.parser

HtmlParser
----------

.. autoclass:: HTMLParser
    :members:


Node
----

.. autoclass:: Node
    :members:

Selector
--------

.. autoclass:: Selector
    :members:
