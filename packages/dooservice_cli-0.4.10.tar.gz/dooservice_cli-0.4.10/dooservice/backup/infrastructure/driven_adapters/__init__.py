"""Backup infrastructure driven adapters."""
