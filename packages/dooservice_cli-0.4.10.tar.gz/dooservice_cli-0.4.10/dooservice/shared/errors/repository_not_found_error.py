class RepositoryNotFoundError(Exception):
    """Raised when a repository is not found in the lock file."""
