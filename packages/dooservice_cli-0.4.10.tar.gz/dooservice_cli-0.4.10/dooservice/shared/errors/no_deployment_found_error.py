class NoDeploymentFoundError(Exception):
    """Raised when no deployment configuration is found for an instance."""
