class LockfileNotFoundError(Exception):
    """Raised when the lockfile cannot be found."""
