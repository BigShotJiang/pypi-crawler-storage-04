"""Snapshot domain entities."""
