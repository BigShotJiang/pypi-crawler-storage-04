"""Snapshot infrastructure layer."""
