# cattle_grid_reports

These are reports created by [cattle_grid](https://codeberg.org/helge/cattle_grid)
using its reporter functionality for feature tests. The main goal of this is to
illustrate how ActivityPub related information flows.

One should note that the messages are shown are not ActivityPub, but an
internal AMQP based messaging.
