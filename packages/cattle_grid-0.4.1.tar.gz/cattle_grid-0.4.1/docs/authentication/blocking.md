# Blocking

::: mkdocs-click
    :module: cattle_grid.auth.__main__
    :command: auth_cli
    :prog_name: python -m cattle_grid.auth
    :depth: 2
