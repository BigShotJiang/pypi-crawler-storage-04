# Copyright 2019 Ecosoft Co., Ltd. (http://ecosoft.co.th)
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

{
    "name": "Purchase Work Acceptance",
    "version": "18.0.1.0.0",
    "category": "Purchase Management",
    "author": "Ecosoft, Odoo Community Association (OCA)",
    "license": "AGPL-3",
    "website": "https://github.com/OCA/purchase-workflow",
    "depends": ["purchase_stock"],
    "data": [
        "data/work_acceptance_sequence.xml",
        "security/ir.model.access.csv",
        "security/security.xml",
        "views/account_move_views.xml",
        "views/purchase_views.xml",
        "views/res_config_settings_views.xml",
        "views/stock_picking_views.xml",
        "views/stock_picking_type_views.xml",
        "views/work_acceptance_views.xml",
        "wizard/select_work_acceptance_wizard_views.xml",
        "wizard/work_accepted_date_wizard.xml",
    ],
    "maintainers": ["ps-tubtim"],
    "installable": True,
    "development_status": "Alpha",
}
