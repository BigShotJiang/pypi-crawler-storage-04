# Set IDEX software version here
__version__ = "01"
