# -*- coding: utf-8 -*-
# 这是一个redis数据库