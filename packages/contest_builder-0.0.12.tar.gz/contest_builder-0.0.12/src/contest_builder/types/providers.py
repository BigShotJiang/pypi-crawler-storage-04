from enum import Enum


class Providers(Enum):
    CODEFORCES = "codeforces"
    LEETCODE = "leetcode"
    LOCAL = "local"
